-- Turquality: every cost of a trip / fair carries what kind of document it is (invoice, payment proof, boarding pass ...) and whether it goes
-- into the Turquality claim. The person who travelled types in their own costs on the trip / the fair, so who entered it matters.
ALTER TABLE budget_expenses ADD COLUMN doc_type TEXT;
ALTER TABLE budget_expenses ADD COLUMN turquality INTEGER NOT NULL DEFAULT 1;
-- more documents for the same cost (the invoice of a flight, its payment proof, the boarding passes): kept next to the expense, never counted twice
CREATE TABLE IF NOT EXISTS budget_expense_files (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  expense_id INTEGER NOT NULL REFERENCES budget_expenses(id) ON DELETE CASCADE,
  doc_type TEXT NOT NULL DEFAULT 'other',
  file_path TEXT NOT NULL,
  file_name TEXT,
  uploaded_by INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_budget_expense_files_expense ON budget_expense_files(expense_id);
