// Trips: the trips on the road now, the ones that come, and the ones that are done - each with its customers, its countries and its budget.
import { h, Fragment, useState, useEffect, useMemo, api, useNavigate, Link, useAuth, useT, Icon, cx, errText, eur, todayIso, dayDiff, dateRange, Chip, Stat, Skel, Empty } from "./x-kit-br2FMvy0.js";
import { BudgetLine } from "./x-budget-2YACrUIl.js";

const lengthOf = (t) => (t.startDate ? dayDiff(t.startDate, t.endDate || t.startDate) + 1 : 0);
function phase(t, today) {
  if (!t.startDate) return "draft";
  const end = t.endDate || t.startDate;
  if (end < today) return "done";
  return t.startDate <= today ? "now" : "next";
}

function TripCard({ trip, money, today, showOwner }) {
  const t = useT();
  const ph = phase(trip, today);
  const days = lengthOf(trip);
  const stops = trip.stopCount || 0;
  const countries = trip.countries || [];
  const when = ph === "now" ? t("Day {a} of {b}", { a: dayDiff(trip.startDate, today) + 1, b: days }) : ph === "next" ? (dayDiff(today, trip.startDate) === 1 ? t("tomorrow") : t("in {n} days", { n: dayDiff(today, trip.startDate) })) : ph === "done" ? t("{n} days ago", { n: dayDiff(trip.endDate || trip.startDate, today) }) : t("no dates yet");
  const soon = ph === "next" && dayDiff(today, trip.startDate) <= 14;
  return h(Link, { to: `/trips/${trip.id}`, className: cx("xt-card", "xt-card--" + ph) },
    h("div", { className: "xt-card-top" },
      h("div", { className: "xt-when" }, ph === "now" ? h(Chip, { tone: "live", icon: "flight" }, t("On the road")) : null, h(Chip, { tone: soon ? "warn" : undefined }, when), stops === 0 ? h(Chip, { tone: "bad" }, t("no customers yet")) : null),
      h(Icon, { n: "arrow-forward", size: 20, className: "xt-go" }),
    ),
    h("h3", null, trip.title),
    h("p", { className: "xt-dates" }, trip.startDate ? dateRange(trip.startDate, trip.endDate) + " · " + (days === 1 ? t("1 day") : t("{n} days", { n: days })) : t("Set the dates to plan the days.")),
    h("div", { className: "xt-nums" },
      h("span", null, h("b", null, stops), stops === 1 ? t("customer") : t("customers")),
      h("span", null, h("b", null, countries.length), countries.length === 1 ? t("country") : t("countries")),
      days > 0 && stops > 0 ? h("span", null, h("b", null, (stops / days).toFixed(1)), t("visits a day")) : null,
      money && money.spent > 0 && stops > 0 ? h("span", null, h("b", null, eur(money.spent / stops)), t("per customer")) : null,
    ),
    countries.length ? h("div", { className: "xt-countries" }, countries.slice(0, 6).map((c) => h("span", { key: c }, c)), countries.length > 6 ? h("span", { className: "xt-more" }, "+" + (countries.length - 6)) : null) : null,
    money ? h(BudgetLine, { planned: money.planned, spent: money.spent }) : ph !== "done" ? h("div", { className: "xt-nobudget" }, h(Icon, { n: "savings", size: 16 }), t("No budget planned yet")) : null,
    showOwner && trip.ownerName ? h("small", { className: "xt-owner" }, trip.ownerName) : null,
  );
}

export function TripsHome() {
  const t = useT();
  const nav = useNavigate();
  const { user } = useAuth();
  const [all, setAll] = useState(false);
  const [trips, setTrips] = useState(null);
  const [money, setMoney] = useState({});
  const [err, setErr] = useState(null);
  const [f, setF] = useState({ title: "", from: "", to: "" });
  const [busy, setBusy] = useState(false);
  const today = todayIso();
  useEffect(() => {
    let alive = true;
    setTrips(null);
    api.get(`/trips${all ? "?all=1" : ""}`).then((d) => alive && setTrips(d)).catch((e) => alive && setErr(errText(e, t("Could not load"))));
    api.get("/budget/events").then((d) => alive && setMoney(d.trip || {})).catch(() => undefined);
    return () => { alive = false; };
  }, [all]);
  async function create(e) {
    e.preventDefault();
    setBusy(true);
    setErr(null);
    try {
      const made = await api.post("/trips", { title: f.title.trim() || t("New trip"), startDate: f.from || null, endDate: f.to || f.from || null });
      nav(`/trips/${made.id}`);
    } catch (e2) {
      setErr(errText(e2, t("Could not save")));
      setBusy(false);
    }
  }
  const groups = useMemo(() => {
    const g = { now: [], next: [], draft: [], done: [] };
    for (const tr of trips || []) g[phase(tr, today)].push(tr);
    g.next.sort((a, b) => a.startDate.localeCompare(b.startDate));
    return g;
  }, [trips, today]);
  const year = today.slice(0, 4);
  const sum = useMemo(() => {
    const mine = (trips || []).filter((tr) => (tr.startDate || "").startsWith(year));
    return { n: mine.length, customers: mine.reduce((s, tr) => s + (tr.stopCount || 0), 0), days: mine.reduce((s, tr) => s + lengthOf(tr), 0), spent: mine.reduce((s, tr) => s + ((money[tr.id] && money[tr.id].spent) || 0), 0), planned: mine.reduce((s, tr) => s + ((money[tr.id] && money[tr.id].planned) || 0), 0) };
  }, [trips, money, year]);
  const next = groups.now[0] || groups.next[0] || null;
  const section = (key, title, list) => (list.length ? h("section", { key, className: "xt-group" }, h("h3", { className: "xt-group-title" }, title, h("span", null, list.length)), h("div", { className: "xt-grid" }, list.map((tr) => h(TripCard, { key: tr.id, trip: tr, money: money[tr.id], today, showOwner: all })))) : null);
  return h("div", { className: "xt" },
    h("div", { className: "tx-ph" },
      h("div", { className: "tx-ph-main" },
        h("h1", { className: "tc-title tc-title--sm" }, h("b", null, t("Trips"))),
        h("p", { className: "tx-lead" }, t("Choose the countries and the customers, let the route be planned, set a budget, write to the customers and print the plan.")),
      ),
      user && user.role === "admin" ? h("label", { className: "xt-all" }, h("input", { type: "checkbox", checked: all, onChange: (e) => setAll(e.target.checked) }), t("Show everybody's trips")) : null,
    ),
    h("div", { className: "xt-top" },
      h("section", { className: "xt-hero" },
        next
          ? h(Fragment, null,
              h("span", { className: "xt-hero-kicker" }, phase(next, today) === "now" ? t("On the road now") : t("Next trip")),
              h("h2", null, next.title),
              h("p", null, dateRange(next.startDate, next.endDate), " · ", (next.stopCount || 0) + " " + t("customers"), (next.countries || []).length ? " · " + next.countries.slice(0, 3).join(", ") + (next.countries.length > 3 ? " …" : "") : ""),
              h("div", { className: "xt-hero-count" }, phase(next, today) === "now" ? h(Fragment, null, h("b", null, dayDiff(next.startDate, today) + 1), h("span", null, t("day of {n}", { n: lengthOf(next) }))) : h(Fragment, null, h("b", null, dayDiff(today, next.startDate)), h("span", null, dayDiff(today, next.startDate) === 1 ? t("day to go") : t("days to go")))),
              h(Link, { className: "tc-btn tc-btn--md xf-btn-onink", to: `/trips/${next.id}` }, h(Icon, { n: "route", size: 20 }), t("Open the plan")),
            )
          : h(Fragment, null, h("span", { className: "xt-hero-kicker" }, t("Next trip")), h("h2", null, t("Nothing is planned.")), h("p", null, t("The customers you visit buy more. Plan the next trip on the right."))),
        h("div", { className: "xt-hero-stats" },
          h(Stat, { n: sum.n, label: t("trips in {year}", { year }) }),
          h(Stat, { n: sum.customers, label: t("customers on them") }),
          h(Stat, { n: sum.days, label: t("days on the road") }),
          sum.spent > 0 || sum.planned > 0 ? h(Stat, { n: eur(sum.spent, { short: true }), label: t("spent"), sub: sum.planned > 0 ? t("of {a} planned", { a: eur(sum.planned, { short: true }) }) : null }) : null,
        ),
      ),
      h("form", { className: "xt-new", onSubmit: create },
        h("h3", null, h(Icon, { n: "add", size: 20 }), t("Plan a new trip")),
        h("label", null, h("span", null, t("Name of the trip")), h("input", { value: f.title, onChange: (e) => setF({ ...f, title: e.target.value }), placeholder: t("South America, December") })),
        h("div", { className: "xt-new-dates" },
          h("label", null, h("span", null, t("From")), h("input", { type: "date", value: f.from, onChange: (e) => setF({ ...f, from: e.target.value, to: f.to && f.to < e.target.value ? e.target.value : f.to }) })),
          h("label", null, h("span", null, t("Until")), h("input", { type: "date", value: f.to, min: f.from || undefined, onChange: (e) => setF({ ...f, to: e.target.value }) })),
        ),
        f.from && f.to ? h("small", { className: "tx-muted" }, t("{n} days", { n: dayDiff(f.from, f.to) + 1 })) : null,
        h("button", { type: "submit", className: "tc-btn tc-btn--md", disabled: busy }, busy ? t("Saving ...") : t("Start planning"), h(Icon, { n: "arrow-forward", size: 20 })),
      ),
    ),
    err ? h("p", { className: "tx-err", role: "alert" }, err) : null,
    trips === null ? h(Skel, { height: 220 }) : trips.length === 0 ? h(Empty, { icon: "luggage", title: t("No trips yet.") }, t("Plan the first one above: give it a name and the dates.")) : h(Fragment, null,
      section("now", t("On the road now"), groups.now),
      section("next", t("Coming up"), groups.next),
      section("draft", t("Without dates"), groups.draft),
      section("done", t("Done"), groups.done),
    ),
  );
}
