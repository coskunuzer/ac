import { db } from '../db/connection';
import { usdPerEur } from './perfAnalytics';
import { openAsks, readyList } from './shipDispatch';
import { latestExports } from './shipExports';
import { mailboxReady, shipConfig } from './shipMail';
import { countryName, listForwarders, matchPlace, MODES, proposedFor, serves } from './shipPlaces';

// The freight desk: the open work of Operations in the order it is done - ask for quotes, wait for the answers, decide, look at the e-mails
// nobody could read, send the documents. One call gives the whole first screen; a second one gives everything to compare the quotes of a request.

// ---- one currency to compare with ---------------------------------------------------------------------------------------------------------------
// Prices are never changed: the amount the firm wrote is always shown. For comparing, an amount is also given in euro, with the rates the CRM
// already keeps (the dollar rate of Performance, the lira rate of the marketing budget). A currency without a rate is not compared.
export interface Rates { base: 'EUR'; usdPerEur: number; tryPerEur: number | null; tryMonth: string | null }
export function rates(): Rates {
  const t = db.prepare('SELECT ym, try_per_eur FROM budget_rates WHERE try_per_eur > 0 ORDER BY ym DESC LIMIT 1').get() as { ym: string; try_per_eur: number } | undefined;
  return { base: 'EUR', usdPerEur: usdPerEur(), tryPerEur: t?.try_per_eur ?? null, tryMonth: t?.ym ?? null };
}
export function toEur(amount: number | null | undefined, currency: string | null | undefined, r: Rates): number | null {
  if (amount == null || !(amount > 0)) return null;
  const c = String(currency ?? '').toUpperCase();
  if (c === 'EUR') return amount;
  if (c === 'USD' && r.usdPerEur > 0) return amount / r.usdPerEur;
  if (c === 'TRY' && r.tryPerEur) return amount / r.tryPerEur;
  return null;
}
const r2 = (v: number) => Math.round(v * 100) / 100;
const hoursSince = (stamp: string | null | undefined): number | null => (stamp ? Math.max(0, Math.round((Date.now() - Date.parse(`${stamp.replace(' ', 'T')}Z`)) / 3600000)) : null);
const cfgOut = () => { const c = shipConfig(); return { mailboxReady: mailboxReady(), testMode: c.testMode, testEmail: c.testMode ? c.testEmail : '', remindHours: c.remindHours, lateDays: c.lateDays, managerEmail: c.managerEmail, from: c.user, rates: rates() }; };

interface ReqRow { id: string; city: string | null; country: string | null; country_iso: string | null; mode: string; pallets: number | null; weight_kg: number | null; card_id: number | null; created_at: string; customer: string | null }
interface FwRow { request_id: string; forwarder_id: number; forwarder_name: string; sent_at: string | null; reminded_at: string | null; answered_at: string | null; cancelled_at: string | null; emails: string }
interface QRow { id: number; request_id: string; forwarder_id: number | null; forwarder_name: string; base: number | null; extra: number | null; total: number | null; currency: string | null; out_items: string | null; status: string; review_reason: string | null; counter: number | null; received_at: string; updated_at: string }

// the last freight that was accepted for this customer, or else for this country (what it cost, with whom)
function lastFreight(cardId: number | null, iso: string | null): { firm: string; total: number; currency: string; date: string; mode: string; pallets: number | null; kg: number | null; same: 'customer' | 'country' } | null {
  const q = (where: string, v: string | number) => db.prepare(`SELECT q.forwarder_name AS firm, q.total, q.currency, r.closed_at AS date, r.created_at, r.mode, r.pallets, r.weight_kg AS kg FROM ship_requests r JOIN ship_quotes q ON q.id = r.accepted_quote WHERE ${where} AND q.total > 0 ORDER BY r.created_at DESC LIMIT 1`).get(v) as { firm: string; total: number; currency: string | null; date: string | null; created_at: string; mode: string; pallets: number | null; kg: number | null } | undefined;
  const a = cardId ? q('r.card_id = ?', cardId) : undefined;
  const b = !a && iso ? q('r.country_iso = ?', iso) : undefined;
  const x = a ?? b;
  return x ? { firm: x.firm, total: x.total, currency: x.currency ?? '', date: (x.date ?? x.created_at).slice(0, 10), mode: x.mode, pallets: x.pallets, kg: x.kg, same: a ? 'customer' : 'country' } : null;
}

export function desk() {
  const cfg = cfgOut();
  const reqs = db.prepare("SELECT r.id, r.city, r.country, r.country_iso, r.mode, r.pallets, r.weight_kg, r.card_id, r.created_at, c.company AS customer FROM ship_requests r LEFT JOIN cards c ON c.id = r.card_id WHERE r.status = 'open' AND r.archived = 0 ORDER BY r.id").all() as unknown as ReqRow[];
  const ids = reqs.map((r) => r.id);
  const marks = ids.map(() => '?').join(',') || 'NULL';
  const fws = db.prepare(`SELECT request_id, forwarder_id, forwarder_name, sent_at, reminded_at, answered_at, cancelled_at, emails FROM ship_request_fw WHERE request_id IN (${marks})`).all(...ids) as unknown as FwRow[];
  const qs = db.prepare(`SELECT * FROM ship_quotes WHERE request_id IN (${marks})`).all(...ids) as unknown as QRow[];
  const decide: unknown[] = []; const waiting: unknown[] = [];
  for (const r of reqs) {
    const firms = fws.filter((f) => f.request_id === r.id && f.sent_at && !f.cancelled_at);
    const quotes = qs.filter((q) => q.request_id === r.id);
    const live = quotes.filter((q) => ['open', 'countered', 'manual'].includes(q.status));
    const answeredIds = new Set(quotes.map((q) => q.forwarder_id));
    const silent = firms.filter((f) => !answeredIds.has(f.forwarder_id) && !f.answered_at).map((f) => ({ name: f.forwarder_name, hours: hoursSince(f.sent_at), reminded: !!f.reminded_at }));
    const priced = live.filter((q) => q.status !== 'manual' && q.total && q.total > 0).map((q) => ({ quoteId: q.id, firm: q.forwarder_name, total: q.total!, currency: q.currency ?? '', eur: (() => { const e = toEur(q.total, q.currency, cfg.rates); return e === null ? null : r2(e); })(), status: q.status }))
      .sort((a, b) => (a.eur ?? Infinity) - (b.eur ?? Infinity));
    const hours = hoursSince(r.created_at) ?? 0;
    const head = { id: r.id, city: r.city, country: r.country, mode: r.mode, pallets: r.pallets, kg: r.weight_kg, customer: r.customer, cardId: r.card_id, createdAt: r.created_at, hours, asked: firms.length, answered: firms.length - silent.length, silent, canRemind: hours >= cfg.remindHours ? silent.filter((s) => !s.reminded).length : 0 };
    if (live.length) {
      const best = priced[0] ?? null; const second = priced[1] ?? null;
      decide.push({ ...head, quotes: live.length, manual: live.filter((q) => q.status === 'manual').length, notAllIn: live.filter((q) => q.status === 'open' && !(q.total && q.total > 0)).length, countered: live.filter((q) => q.status === 'countered').length,
        best: best ? { ...best, perKg: best.eur && r.weight_kg ? r2(best.eur / r.weight_kg) : null } : null, second,
        savingEur: best?.eur != null && second?.eur != null ? r2(second.eur - best.eur) : null, allAnswered: silent.length === 0 });
    } else waiting.push(head);
  }
  (decide as { allAnswered: boolean; hours: number }[]).sort((a, b) => Number(b.allAnswered) - Number(a.allAnswered) || b.hours - a.hours);
  (waiting as { hours: number }[]).sort((a, b) => b.hours - a.hours);

  // what has to be asked: the asks of Sales first, then the goods that are ready and have no open request
  const ready = readyList(false).customers;
  const asks = openAsks() as unknown as { id: number; sap_no: string; customer: string | null; card_id: number | null; note: string | null; from_name: string | null; created_at: string }[];
  const askBySap = new Map(asks.map((a) => [a.sap_no, a]));
  const ask: unknown[] = [];
  const row = (sap: string, c: (typeof ready)[number] | undefined, a: (typeof asks)[number] | undefined) => {
    const place = c?.country ? matchPlace(c.country) : null;
    const iso = place?.type === 'country' ? place.iso : null;
    return { kind: a ? 'ask' : 'ready', sap, customer: c?.customer ?? a?.customer ?? sap, cardId: c?.cardId ?? a?.card_id ?? null, country: iso ? countryName(iso) : c?.country ?? null, city: c?.city ?? null,
      lots: c?.rows.length ?? 0, kg: Math.round(c?.weight ?? 0), value: Math.round(c?.value ?? 0), currency: c?.currency ?? '', days: c ? Math.max(0, ...c.rows.map((x) => x.days ?? 0)) : null,
      askId: a?.id ?? null, note: a?.note ?? null, from: a?.from_name ?? null, askedHours: a ? hoursSince(a.created_at) : null, openRequest: c?.request?.status === 'open' ? c.request.id : null, last: lastFreight(c?.cardId ?? a?.card_id ?? null, iso) };
  };
  for (const a of asks) ask.push(row(a.sap_no, ready.find((c) => c.sap === a.sap_no), a));
  for (const c of ready) if (!askBySap.has(c.sap) && c.request?.status !== 'open') ask.push(row(c.sap, c, undefined));
  const readyTotal = ask.length;

  const mails = (db.prepare("SELECT m.id, m.direction, m.kind, m.request_id AS requestId, m.address, m.subject, m.status, m.error, m.quote_id AS quoteId, m.created_at AS at, substr(m.body, 1, 400) AS snippet, f.forwarder_name AS firm FROM ship_messages m LEFT JOIN ship_request_fw f ON f.request_id = m.request_id AND f.forwarder_id = m.forwarder_id WHERE (m.direction = 'in' AND m.status IN ('held', 'review', 'failed')) OR (m.direction = 'out' AND m.status = 'failed') ORDER BY (m.direction = 'in') DESC, m.id DESC LIMIT 12").all() as unknown as { direction: string; status: string }[])
    .map((m) => ({ ...m, what: m.direction === 'out' ? 'failed_out' : m.status }));
  const exp = latestExports(45, cfg.lateDays).rows.filter((r) => r.docs.state !== 'sent' && r.docs.state !== 'ignored').sort((a, b) => Number(b.late) - Number(a.late) || b.days - a.days);
  const n = (sql: string) => (db.prepare(sql).get() as { n: number }).n;
  return {
    cfg,
    counts: { ask: readyTotal, asks: asks.length, waiting: waiting.length, decide: decide.length, mails: n("SELECT COUNT(*) AS n FROM ship_messages WHERE (direction = 'in' AND status IN ('held', 'review', 'failed')) OR (direction = 'out' AND status = 'failed')"), docs: exp.length, docsLate: exp.filter((r) => r.late).length },
    decide, waiting, ask: ask.slice(0, 12), mails, docs: exp.slice(0, 8),
  };
}

// ---- everything to compare the quotes of one request, and to decide ---------------------------------------------------------------------------------
export function compare(id: string) {
  const request = db.prepare('SELECT r.*, c.company AS customer FROM ship_requests r LEFT JOIN cards c ON c.id = r.card_id WHERE r.id = ?').get(id) as (ReqRow & { status: string; original_text: string; size: string | null; ready: string | null; accepted_quote: number | null }) | undefined;
  if (!request) return null;
  const cfg = cfgOut();
  const fws = db.prepare('SELECT * FROM ship_request_fw WHERE request_id = ? ORDER BY forwarder_name').all(id) as unknown as FwRow[];
  const qs = db.prepare('SELECT * FROM ship_quotes WHERE request_id = ? ORDER BY id').all(id) as unknown as QRow[];
  const msgs = db.prepare("SELECT id, direction, kind, forwarder_id, quote_id, status, error, created_at, substr(body, 1, 1500) AS body FROM ship_messages WHERE request_id = ? ORDER BY id DESC").all(id) as unknown as { id: number; direction: string; kind: string; forwarder_id: number | null; quote_id: number | null; status: string; error: string | null; created_at: string; body: string | null }[];
  const stats = new Map(listForwarders().map((f) => [f.id, f]));
  const kg = request.weight_kg && request.weight_kg > 0 ? request.weight_kg : null;
  const pallets = request.pallets && request.pallets > 0 ? request.pallets : null;
  const quotes = qs.map((q) => {
    const allIn = !!(q.total && q.total > 0);
    const eur = allIn ? toEur(q.total, q.currency, cfg.rates) : null;
    const reply = msgs.find((m) => m.direction === 'in' && (m.quote_id === q.id || (q.forwarder_id !== null && m.forwarder_id === q.forwarder_id)));
    const failed = msgs.find((m) => m.direction === 'out' && m.status === 'failed' && q.forwarder_id !== null && m.forwarder_id === q.forwarder_id);
    const f = q.forwarder_id ? stats.get(q.forwarder_id) : undefined;
    return { id: q.id, firm: q.forwarder_name, forwarderId: q.forwarder_id, status: q.status, base: q.base, extra: q.extra, total: q.total, currency: q.currency, outItems: q.out_items, counter: q.counter, reviewReason: q.review_reason, receivedAt: q.received_at,
      allIn, eur: eur === null ? null : r2(eur), noRate: allIn && eur === null, perKg: eur !== null && kg ? r2(eur / kg) : null, perPallet: eur !== null && pallets ? r2(eur / pallets) : null,
      reply: reply ? { text: reply.body ?? '', at: reply.created_at } : null, mailFailed: failed ? { id: failed.id, kind: failed.kind, error: failed.error } : null,
      history: f ? { asked: f.asked, answered: f.answered, won: f.won } : null, rank: 0, diffBest: null as number | null, diffBestPct: null as number | null };
  });
  // the ranking: only quotes that can still be accepted (open, with an all-in price that can be compared)
  const ranked = quotes.filter((q) => q.status === 'open' && q.eur !== null).sort((a, b) => a.eur! - b.eur!);
  ranked.forEach((q, i) => { q.rank = i + 1; q.diffBest = i ? r2(q.eur! - ranked[0].eur!) : 0; q.diffBestPct = i && ranked[0].eur! > 0 ? Math.round(((q.eur! - ranked[0].eur!) / ranked[0].eur!) * 100) : 0; });
  const avg = ranked.length ? r2(ranked.reduce((a, q) => a + q.eur!, 0) / ranked.length) : null;
  const answered = new Set(qs.map((q) => q.forwarder_id));
  const silent = fws.filter((f) => f.sent_at && !f.cancelled_at && !answered.has(f.forwarder_id)).map((f) => ({ forwarderId: f.forwarder_id, name: f.forwarder_name, hours: hoursSince(f.sent_at), remindedAt: f.reminded_at, emails: JSON.parse(f.emails || '[]') as string[], mailFailed: (() => { const m = msgs.find((x) => x.direction === 'out' && x.forwarder_id === f.forwarder_id); return m && m.status === 'failed' ? { id: m.id, kind: m.kind, error: m.error } : null; })() }));
  const notSent = fws.filter((f) => !f.sent_at).map((f) => ({ forwarderId: f.forwarder_id, name: f.forwarder_name }));
  const askedIds = new Set(fws.map((f) => f.forwarder_id));
  const more = request.status === 'open' ? proposedFor(request.country_iso, request.mode).filter((f) => !askedIds.has(f.id)).slice(0, 12).map((f) => ({ id: f.id, name: f.name, why: f.why, asked: f.asked, answered: f.answered, won: f.won })) : [];
  const hours = hoursSince(request.created_at) ?? 0;
  return {
    request: { id: request.id, status: request.status, city: request.city, country: request.country, mode: request.mode, pallets, kg, size: request.size, ready: request.ready, customer: request.customer, cardId: request.card_id, text: request.original_text, createdAt: request.created_at, hours, acceptedQuote: request.accepted_quote },
    cfg, quotes: [...ranked, ...quotes.filter((q) => !ranked.includes(q))], best: ranked[0]?.id ?? null, avgEur: avg, spreadEur: ranked.length > 1 ? r2(ranked[ranked.length - 1].eur! - ranked[0].eur!) : null,
    asked: fws.filter((f) => f.sent_at).length, silent, notSent, canRemind: hours >= cfg.remindHours ? silent.filter((s) => !s.remindedAt).length : 0, remindAfterHours: Math.max(0, cfg.remindHours - hours), more,
    last: lastFreight(request.card_id, request.country_iso),
    events: db.prepare('SELECT e.kind, e.text, e.created_at AS at, u.display_name AS by FROM ship_events e LEFT JOIN users u ON u.id = e.user_id WHERE e.request_id = ? ORDER BY e.id DESC LIMIT 8').all(id),
  };
}

// ---- ready goods of one customer -> a request that only has to be confirmed -----------------------------------------------------------------------
export function readyPlan(sap: string, wantMode?: string | null) {
  const rows = db.prepare('SELECT sd_no, billing_date, customer, country, city, net_value, currency, weight FROM export_dispatch_queue WHERE sap_no = ? ORDER BY billing_date').all(sap) as unknown as { sd_no: string; billing_date: string | null; customer: string; country: string | null; city: string | null; net_value: number | null; currency: string; weight: number | null }[];
  const card = db.prepare("SELECT id, company, country, city FROM cards WHERE TRIM(sap) = ? LIMIT 1").get(sap.trim()) as { id: number; company: string | null; country: string | null; city: string | null } | undefined;
  const ask = db.prepare("SELECT a.id, a.note, a.customer, u.display_name AS from_name FROM ship_asks a LEFT JOIN users u ON u.id = a.from_user WHERE a.sap_no = ? AND a.status = 'open' ORDER BY a.id DESC LIMIT 1").get(sap) as { id: number; note: string | null; customer: string | null; from_name: string | null } | undefined;
  if (!rows.length && !ask) return null;
  const countryRaw = rows[0]?.country || card?.country || '';
  const place = countryRaw ? matchPlace(countryRaw) : null;
  const iso = place?.type === 'country' ? place.iso : null;
  const city = rows[0]?.city || card?.city || '';
  const firms = listForwarders().filter((f) => f.active);
  // the way of transport: what was used for this customer before, else for this country, else road when a road firm goes there, else a container
  const before = card ? (db.prepare('SELECT mode FROM ship_requests WHERE card_id = ? ORDER BY created_at DESC LIMIT 1').get(card.id) as { mode: string } | undefined) : undefined;
  const beforeCountry = !before && iso ? (db.prepare('SELECT mode FROM ship_requests WHERE country_iso = ? ORDER BY created_at DESC LIMIT 1').get(iso) as { mode: string } | undefined) : undefined;
  const guessed = before?.mode ?? beforeCountry?.mode ?? (firms.some((f) => serves(f, iso, 'Karayolu')) ? 'Karayolu' : 'Denizyolu (Konteyner)');
  const mode = MODES.find((m) => m === wantMode) ?? MODES.find((m) => m === guessed) ?? 'Karayolu';
  const kg = Math.round(rows.reduce((a, r) => a + (r.weight ?? 0), 0));
  const customer = rows[0]?.customer ?? card?.company ?? ask?.customer ?? sap;
  const country = iso ? countryName(iso) : countryRaw;
  const dest = [city, country].filter(Boolean).join(', ');
  const proposals = proposedFor(iso, mode).map((f) => ({ id: f.id, name: f.name, why: f.why, emails: f.emails, lang: f.lang, asked: f.asked, answered: f.answered, won: f.won, lastPrice: f.lastPrice }));
  return {
    sap, customer, cardId: card?.id ?? null, askId: ask?.id ?? null, askNote: ask?.note ?? null, askFrom: ask?.from_name ?? null,
    country, iso, city, mode, modes: MODES, modeWhy: before ? 'customer' : beforeCountry ? 'country' : 'coverage', kg,
    lots: rows.map((r) => ({ sd: r.sd_no, date: r.billing_date, kg: Math.round(r.weight ?? 0), value: r.net_value ?? 0, currency: r.currency })),
    text: rows.length ? `${customer} için sevke hazır sipariş (${rows.map((r) => r.sd_no).join(', ')}). Varış: ${dest || '-'}. Toplam ${kg ? `${kg.toLocaleString('tr-TR')} kg` : 'ağırlık belirtilmemiş'}. ${mode}.` : `${customer} için nakliye teklifi. Varış: ${dest || '-'}. ${mode}.`,
    proposals, last: lastFreight(card?.id ?? null, iso), cfg: cfgOut(),
  };
}
