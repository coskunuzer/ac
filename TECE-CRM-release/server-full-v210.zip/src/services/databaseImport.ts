import * as XLSX from 'xlsx';
import { db } from '../db/connection';
import { cardModel } from '../models/cardModel';
import { cityModel } from '../models/cityModel';
import { countryKey, countryModel } from '../models/countryModel';
import { tidyPhones } from './phone';
import { resolveCity } from '../data/turkeyPlaces';
import type { ExtractedCardFields, FieldStatusMap } from '../schema/cardSchema';
import { resolveCountry } from './badgeImport';
import { contactModel } from '../models/contactModel';
import { activityModel } from '../models/activityModel';
import { addOpportunity } from './opportunities';
import { followLegacyStage, leadSources, LOST_REASONS } from './pipeline';

// The customer database in three tabs:
//   1 Existing Customers        companies that already buy from us
//   2 Potential - Email or Web  potential customers we can reach (an e-mail address or a web site)
//   3 Potential - No Contact    potential customers with neither: to be checked (does the company have a web site?) or removed
// A tab can also carry more per company: Role / position, What do they do, Kind of customer, Lead source, Looked after by, Stage (lead, contacted, interested, quoted, customer),
// Exit status (lost) with Exit reason, Notes. And more tabs are read: Extra contacts (more people of a company), Offers, Samples and Proformas (the history of a company:
// every line becomes an entry in its history, a proforma also an opportunity). Companies are found by name and country.
// Each company becomes a customer in its group. Companies that are already in are left alone.

type Group = 'existing' | 'reachable' | 'no_contact';

const norm = (s: string) => s.normalize('NFD').replace(/\p{Diacritic}/gu, '').toLowerCase().replace(/[^a-z0-9]/g, '');
const clean = (v: unknown) => String(v ?? '').replace(/\s+/g, ' ').trim();

const COLS: Record<string, string[]> = {
  company: ['company', 'companyname'],
  sap: ['sapnumber', 'sapno', 'sap'],
  exhibition: ['exhibition', 'fair'],
  country: ['country'],
  city: ['city'],
  tier: ['tier'],
  score: ['score'],
  businessType: ['businesstype'],
  salesAngle: ['salesangle'],
  suppliers: ['knownsuppliers', 'suppliers'],
  tradeValue: ['tradevalueusd', 'tradevalue'],
  sources: ['datasources'],
  email: ['email'],
  phone: ['phone'],
  contact: ['contactperson', 'contact'],
  website: ['website', 'web'],
  original: ['originalcompanyname'],
  webCheck: ['webcheck'],
  position: ['roleposition', 'position', 'role'],
  whatTheyDo: ['whatdotheydo', 'whattheydo'],
  kind: ['kindofcustomer', 'kind'],
  leadSource: ['leadsource'],
  owner: ['lookedafterby', 'salesrepresentative', 'owner'],
  stage: ['stage'],
  exitStatus: ['exitstatus'],
  exitReason: ['exitreason'],
  notes: ['notes'],
};
const STAGE_WORDS: Record<string, string> = { lead: 'lead', contacted: 'contacted', interested: 'interested', quoted: 'quoted', customer: 'customer' };
const stageOf = (raw: string, group: Group): string => STAGE_WORDS[clean(raw).toLowerCase()] ?? (group === 'existing' ? 'customer' : 'lead');

function groupOf(sheetName: string): Group | null {
  const n = sheetName.toLowerCase();
  if (/existing/.test(n)) return 'existing';
  if (/no\s*contact/.test(n)) return 'no_contact';
  if (/email|web|reach/.test(n)) return 'reachable';
  return null;
}

export interface DatabaseImportReport {
  dryRun: boolean;
  sheets: { name: string; group: Group | null; rows: number; created: number; duplicates: number }[];
  created: number;
  duplicates: number;
  skipped: number;
  withEmail: number;
  withWebsite: number;
  unknownCountries: string[];
  domestic: number;
  contacts: number;
  activities: number;
  opportunities: number;
  historyUnmatched: string[];
  // companies with no country (the page asks which country they belong to before the real upload)
  missingCountry: number;
}

const emails = (raw: string) => [...new Set(raw.split(/[;,|\s]+/).filter((e) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)).map((e) => e.toLowerCase()))];
const bar = (raw: string) => raw.split('|').map((s) => s.trim()).filter(Boolean);

export async function importDatabase(opts: { buffer: Buffer; exhibitionId: number; userId: number; dryRun: boolean; defaultCountry?: string | null }): Promise<DatabaseImportReport> {
  const wb = XLSX.read(opts.buffer, { type: 'buffer' });
  const report: DatabaseImportReport = { dryRun: opts.dryRun, sheets: [], created: 0, duplicates: 0, skipped: 0, withEmail: 0, withWebsite: 0, unknownCountries: [], domestic: 0, missingCountry: 0, contacts: 0, activities: 0, opportunities: 0, historyUnmatched: [] };
  const have = new Set((db.prepare("SELECT badge_id FROM cards WHERE badge_id LIKE 'db:%'").all() as { badge_id: string }[]).map((r) => r.badge_id));
  const unknown = new Map<string, number>();
  const ids = new Map<string, number>();
  const sources = new Set(leadSources());
  const owners = new Map<string, string | null>();
  const FOUND: FieldStatusMap = {
    name: 'found', company: 'found', address: 'found', country: 'found', tel: 'found', email: 'found', position: 'found', interestedIn: 'found',
    workArea: 'found', date: 'found', person: 'found', rate: 'found', notes: 'found',
  };

  if (!opts.dryRun) db.exec('BEGIN');
  try {
    for (const name of wb.SheetNames) {
      const group = groupOf(name);
      const rows = XLSX.utils.sheet_to_json<unknown[]>(wb.Sheets[name], { header: 1, defval: '', blankrows: false });
      const head = (rows[0] ?? []).map((h) => norm(String(h)));
      const col: Record<string, number> = {};
      for (const [key, names] of Object.entries(COLS)) {
        const i = head.findIndex((h) => names.includes(h));
        if (i >= 0) col[key] = i;
      }
      const entry = { name, group, rows: Math.max(0, rows.length - 1), created: 0, duplicates: 0 };
      report.sheets.push(entry);
      if (!group || col.company === undefined) continue; // a tab that is not one of the three (a summary ...) is left out
      const get = (r: unknown[], key: string) => (col[key] === undefined ? '' : clean(r[col[key]]));

      for (let i = 1; i < rows.length; i += 1) {
        const r = rows[i];
        const company = get(r, 'company');
        if (!company) {
          report.skipped += 1;
          continue;
        }
        const rawCountry = get(r, 'country') || (opts.defaultCountry ?? '');
        const resolved = rawCountry ? resolveCountry(rawCountry) : null;
        const country = resolved ?? (rawCountry || null);
        if (rawCountry && !resolved) unknown.set(rawCountry, (unknown.get(rawCountry) ?? 0) + 1);
        const key = `db:${norm(company)}|${country ? countryKey(country) : ''}`;
        if (have.has(key)) {
          entry.duplicates += 1;
          report.duplicates += 1;
          continue;
        }
        have.add(key);

        const domestic = !!country && countryKey(country) === 'turkey';
        const place = domestic ? resolveCity(get(r, 'city')).city : null;
        const owner = domestic ? cityModel.findByCity(place)?.responsible ?? null : country ? (owners.has(countryKey(country)) ? owners.get(countryKey(country)) ?? null : (owners.set(countryKey(country), countryModel.findByCountry(country)?.responsible ?? null), owners.get(countryKey(country)) ?? null)) : null;
        const mails = emails(get(r, 'email'));
        const website = get(r, 'website');
        const fields: ExtractedCardFields = {
          name: get(r, 'contact') || null,
          company,
          address: null,
          country,
          tel: tidyPhones(get(r, 'phone'), country),
          email: mails.join(', ') || null,
          position: get(r, 'position') || null,
          interestedIn: null,
          workArea: get(r, 'whatTheyDo') || get(r, 'kind') || get(r, 'businessType') || null,
          date: null,
          person: get(r, 'owner') || owner,
          rate: null,
          notes: get(r, 'notes') || null,
        };
        entry.created += 1;
        report.created += 1;
        if (mails.length) report.withEmail += 1;
        if (website) report.withWebsite += 1;
        if (domestic) report.domestic += 1;
        if (!country) report.missingCountry += 1;

        if (!opts.dryRun) {
          const card = cardModel.createFromExtraction({
            exhibitionId: opts.exhibitionId,
            uploadedBy: opts.userId,
            imagePath: '',
            fields,
            fieldStatus: FOUND,
            extractionModel: 'customer-database',
            status: 'confirmed',
            badgeId: key,
            stage: stageOf(get(r, 'stage'), group),
            website: website || null,
            sap: get(r, 'sap') || null,
            market: domestic ? 'domestic' : 'export',
            city: place,
            contactGroup: group,
            source: 'database',
            leadInfo: {
              tier: get(r, 'tier') || null,
              score: Number(get(r, 'score')) || null,
              businessType: get(r, 'kind') || get(r, 'businessType') || null,
              salesAngle: get(r, 'salesAngle') || null,
              suppliers: bar(get(r, 'suppliers')).slice(0, 10),
              tradeValue: Number(get(r, 'tradeValue')) || null,
              sources: bar(get(r, 'sources')).slice(0, 10),
              sap: get(r, 'sap') || null,
              exhibition: get(r, 'exhibition') || null,
              originalName: get(r, 'original') || null,
              webCheck: get(r, 'webCheck') || null,
            },
          });
          ids.set(key, card.id);
          // where the customer came from (the app's list), the pipeline step, and a lost sale
          const src = get(r, 'leadSource');
          if (src && sources.has(src)) db.prepare('UPDATE cards SET lead_source = ? WHERE id = ?').run(src, card.id);
          if (stageOf(get(r, 'stage'), group) !== 'lead') followLegacyStage(card.id);
          if (clean(get(r, 'exitStatus')).toLowerCase() === 'lost') {
            const why = get(r, 'exitReason');
            const reason = LOST_REASONS.includes(why) ? why : /answer/i.test(why) ? 'Unresponsive' : LOST_REASONS[0];
            db.prepare("UPDATE cards SET exit_status = 'lost', exit_reason = ?, exit_note = ?, stage = 'lost', pipeline_stage = COALESCE(pipeline_stage, 1), updated_at = datetime('now') WHERE id = ?").run(reason, why && reason !== why ? why.slice(0, 500) : null, card.id);
          }
        }
        if (i % 1500 === 0) {
          if (!opts.dryRun) db.exec('COMMIT');
          await new Promise((resolve) => setImmediate(resolve));
          if (!opts.dryRun) db.exec('BEGIN');
        }
      }
    }
    // the other tabs: more people of a company, and its history
    const cardOf = (company: string, rawCountry: string): { key: string; id: number | null } => {
      const resolved = rawCountry ? resolveCountry(rawCountry) : null;
      const key = `db:${norm(company)}|${resolved ? countryKey(resolved) : rawCountry ? countryKey(rawCountry) : ''}`;
      return { key, id: ids.get(key) ?? ((db.prepare('SELECT id FROM cards WHERE badge_id = ? LIMIT 1').get(key) as { id: number } | undefined)?.id ?? null) };
    };
    const missing = new Set<string>();
    for (const name of wb.SheetNames) {
      const kindOfSheet = /extra\s*contact/i.test(name) ? 'extra' : /^offers?$/i.test(name.trim()) ? 'offers' : /^samples?$/i.test(name.trim()) ? 'samples' : /^proformas?$/i.test(name.trim()) ? 'proformas' : null;
      if (!kindOfSheet) continue;
      const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(wb.Sheets[name], { defval: '', raw: false });
      const entry = report.sheets.find((s) => s.name === name) ?? (() => { const e = { name, group: null as Group | null, rows: rows.length, created: 0, duplicates: 0 }; report.sheets.push(e); return e; })();
      const col = (r: Record<string, unknown>, ...names: string[]) => { for (const k of Object.keys(r)) if (names.includes(norm(k))) return clean(r[k]); return ''; };
      for (const r of rows) {
        const company = col(r, 'companyname', 'company');
        if (!company) continue;
        const { key, id } = cardOf(company, col(r, 'country'));
        const found = opts.dryRun ? have.has(key) : id !== null;
        if (!found) { missing.add(company); continue; }
        if (kindOfSheet === 'extra') {
          entry.created += 1; report.contacts += 1;
          if (opts.dryRun || id === null) continue;
          const mail = emails(col(r, 'email')).join(', ');
          const known = contactModel.list(id).some((c) => (mail && (c.email ?? '').toLowerCase() === mail.toLowerCase()) || (!mail && c.name && c.name === col(r, 'contactperson')));
          if (known) { entry.duplicates += 1; report.contacts -= 1; entry.created -= 1; continue; }
          contactModel.add(id, { name: col(r, 'contactperson', 'contact'), position: col(r, 'roleposition', 'position'), email: mail, tel: col(r, 'phone') });
          continue;
        }
        const date = col(r, 'date');
        const line = (label: string, v: string) => (v ? `${label}: ${v}` : '');
        let type: 'offer' | 'sample' | 'note' = 'note'; let text = '';
        if (kindOfSheet === 'offers') { type = 'offer'; text = ['Offer sent', line('Status', col(r, 'status')), line('Products', col(r, 'products')), line('Contact', col(r, 'contactperson')), line('Received the prices', col(r, 'receivedtheprices')), line('When received', col(r, 'whenreceived')), line('Buying decision', col(r, 'buyingdecision')), line('Did they buy', col(r, 'didtheybuy')), line('Missed opportunity', col(r, 'missedopportunityreason')), line('What happened', col(r, 'whathappened'))].filter(Boolean).join(' | '); }
        if (kindOfSheet === 'samples') { type = 'sample'; text = ['Samples sent', line('Products', col(r, 'products')), line('Contact', col(r, 'contactperson')), line('Tracking', col(r, 'tracking')), line('Received the samples', col(r, 'receivedthesamples')), line('When received', col(r, 'whenreceived')), line('Buying decision', col(r, 'buyingdecision')), line('Did they buy', col(r, 'didtheybuy')), line('What happened', col(r, 'whathappened'))].filter(Boolean).join(' | '); }
        const amount = Number(col(r, 'amountusd').replace(/[^0-9.]/g, '')) || null;
        const pno = col(r, 'proformano');
        if (kindOfSheet === 'proformas') { text = [`Proforma ${pno}`, amount ? `USD ${amount.toLocaleString('en-US')}` : '', line('Status', col(r, 'status')), line('Products', col(r, 'products')), line('Received the quotation', col(r, 'receivedthequotation')), line('Buying decision', col(r, 'buyingdecision')), line('Did they buy', col(r, 'didtheybuy'))].filter(Boolean).join(' | '); }
        entry.created += 1; report.activities += 1;
        if (opts.dryRun || id === null) { if (kindOfSheet === 'proformas') report.opportunities += 1; continue; }
        const same = db.prepare('SELECT id FROM activities WHERE card_id = ? AND type = ? AND text = ?').get(id, type, text.slice(0, 4000));
        if (same) { entry.duplicates += 1; entry.created -= 1; report.activities -= 1; continue; }
        const aid = activityModel.add({ userId: opts.userId, cardId: id, type, text, imported: true });
        if (/^\d{4}-\d{2}-\d{2}$/.test(date)) db.prepare('UPDATE activities SET created_at = ? WHERE id = ?').run(`${date} 12:00:00`, aid);
        if (kindOfSheet === 'proformas' && pno) {
          const oid = addOpportunity({ cardId: id, kind: 'proforma', title: `Proforma ${pno}`, value: amount, currency: 'USD', sourceRef: `import:${pno}`, userId: opts.userId, note: col(r, 'products') });
          if (oid && /sold/i.test(col(r, 'status'))) db.prepare("UPDATE opportunities SET status = 'won', closed_at = ? WHERE id = ?").run(`${date || new Date().toISOString().slice(0, 10)} 12:00:00`, oid);
          if (oid) report.opportunities += 1;
        }
      }
    }
    report.historyUnmatched = [...missing].slice(0, 30);
    if (!opts.dryRun) db.exec('COMMIT');
  } catch (err) {
    if (!opts.dryRun) db.exec('ROLLBACK');
    throw err;
  }
  report.unknownCountries = [...unknown.entries()].sort((a, b) => b[1] - a[1]).slice(0, 20).map(([c, n]) => `${c} (${n})`);
  return report;
}
