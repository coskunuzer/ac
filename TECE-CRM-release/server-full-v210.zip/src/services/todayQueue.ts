// Today: one ranked queue. Every open item of a customer (money owed, an order waiting for the advance, a lot ready to
// dispatch, an offer nobody followed up, a to-do, a meeting) is folded into ONE row, with the reason it ranks there,
// the money at stake and one action. Generated sentences are NOT written here: the rows carry facts, the screen
// writes the words in the user's own language.
import { db } from '../db/connection';
import { memoByData } from '../db/dataVersion';
import { viewMode } from './viewMode';
import { settingsModel } from '../models/settingsModel';
import { cardModel, SQL_IMPORTANT } from '../models/cardModel';
import { visibilitySql, type Viewer } from './visibility';
import { asksFor, accountOfSap, canonicalReps, dataFiles, usdPerEur, type Ask } from './perfAnalytics';
import { followUps } from './opportunities';
import { todayIstanbul } from './todos';

export type RowKind = 'payment' | 'advance' | 'dispatch' | 'offer' | 'slipping' | 'todo' | 'meeting' | 'hold';

export type Fact =
  | { t: 'overdue'; amount: number; cur: string; days: number }
  | { t: 'advance'; orders: number; amount: number; cur: string; days: number | null }
  | { t: 'dispatch'; lots: number; kg: number; amount: number; cur: string }
  | { t: 'offer'; days: number; title: string }
  | { t: 'quiet'; days: number | null; prevYear: number; cur: string }
  | { t: 'todo'; id: number; text: string; daysLate: number; due: string }
  | { t: 'meeting'; id: number; at: string; tz: string | null; title: string }
  | { t: 'hold'; amount: number; cur: string }
  | { t: 'pays_late' };

export interface QueueRow {
  key: string; // c:<card id> | s:<sap>
  cardId: number | null;
  sap: string | null;
  name: string;
  country: string;
  rep: string;
  kind: RowKind;
  primary: Fact;
  also: Fact[];
  eur: number; // money at stake, in euro
  score: number;
  todoId: number | null;
}

interface Item { key: string; cardId: number | null; sap: string | null; name: string; country: string; rep: string; kind: RowKind; fact: Fact; eur: number; score: number; todoId?: number }

const DAY = 86_400_000;
const daysBetween = (a: string, b: string) => Math.round((Date.parse(b.slice(0, 10)) - Date.parse(a.slice(0, 10))) / DAY);
const addDays = (iso: string, n: number) => new Date(Date.parse(`${iso}T12:00:00Z`) + n * DAY).toISOString().slice(0, 10);

const toEur = (amount: number, cur: string): number => (cur === 'USD' ? amount / usdPerEur() : amount);

// Why the order is what it is (the screen says it too): money at stake first, then how late; things without money
// (a to-do, a meeting, an offer nobody followed up) rank by how long they have waited or how near they are.
const PRIORITY: Record<RowKind, number> = { payment: 7, dispatch: 6, advance: 5, hold: 4, offer: 3, meeting: 3, slipping: 2, todo: 1 };

export function pointsGoal(): number { return Math.max(5, Math.min(200, parseInt(settingsModel.get('goal_points_day') ?? '20', 10) || 20)); }

const POINTS: Record<string, number> = { call: 3, visit: 5, meeting: 4, note: 1, offer: 3, email: 2, sample: 2 };

export function goalToday(userId: number): { points: number; target: number } {
  const rows = db
    .prepare("SELECT type, COUNT(*) AS n FROM activities WHERE user_id = ? AND imported = 0 AND date(datetime(created_at, '+3 hours')) = ? GROUP BY type")
    .all(userId, todayIstanbul()) as { type: string; n: number }[];
  let points = rows.reduce((a, r) => a + (POINTS[r.type] ?? 0) * r.n, 0);
  const done = (db.prepare("SELECT COUNT(*) AS n FROM todos WHERE user_id = ? AND date(datetime(done_at, '+3 hours')) = ?").get(userId, todayIstanbul()) as { n: number }).n;
  points += done * 2;
  return { points, target: pointsGoal() };
}

export interface TodayReport {
  asOf: string; // today
  sapAsOf: string; // when the SAP files were uploaded (ISO, UTC)
  scope: 'mine' | 'team';
  canTeam: boolean;
  total: number; // rows in the queue (after snooze and "not mine")
  rows: QueueRow[]; // all rows, ranked (the screen shows about ten, the rest behind "Show all")
  everything: { latePayments: number; hotLeads: number; advances: number; slipping: number; dispatch: number; offers: number; todos: number; meetings: number };
  week: { date: string; label: string; kind: 'todo' | 'meeting'; at: string | null; cardId: number | null; name: string | null }[];
  numbers: { overdueEur: number; overdueCustomers: number; dispatchEur: number; dispatchCustomers: number; slipping: number };
  goal: { points: number; target: number };
  batches: { thankYous: number; statements: number };
  snoozed: { key: string; label: string | null; until: string | null; kind: string }[];
}

// "SAP figures as of": the OLDEST of the latest uploads, so no figure on a page is older than this (ISO, UTC); '' when nothing was uploaded
export function sapAsOf(): string {
  const at = dataFiles().map((f) => f.at).filter(Boolean).sort();
  return at[0] ?? '';
}

export function canSeeTeam(viewer: Viewer): boolean {
  if (viewer.role === 'admin') return true;
  const r = db.prepare('SELECT can_oversee FROM users WHERE id = ?').get(viewer.id) as { can_oversee?: number } | undefined;
  return !!r?.can_oversee;
}

function stateOf(userId: number): Map<string, { kind: string; until: string | null; label: string | null }> {
  const today = todayIstanbul();
  const rows = db.prepare('SELECT key, kind, until, label FROM queue_state WHERE user_id = ?').all(userId) as { key: string; kind: string; until: string | null; label: string | null }[];
  const out = new Map<string, { kind: string; until: string | null; label: string | null }>();
  for (const r of rows) {
    // a snooze or a "done" ends on its day; "not mine" stays until the person changes it
    if ((r.kind === 'snooze' || r.kind === 'done') && r.until && r.until <= today) continue;
    out.set(r.key, r);
  }
  return out;
}

export function setQueueState(userId: number, key: string, action: 'snooze' | 'not_mine' | 'done' | 'undo', days: number, label: string | null): void {
  const today = todayIstanbul();
  const until = action === 'snooze' || action === 'done' ? addDays(today, Math.max(1, Math.min(60, Math.round(days)))) : null;
  if (action === 'undo') db.prepare('DELETE FROM queue_state WHERE user_id = ? AND key = ?').run(userId, key);
  else db.prepare('INSERT INTO queue_state (user_id, key, kind, until, label) VALUES (?, ?, ?, ?, ?) ON CONFLICT(user_id, key) DO UPDATE SET kind = excluded.kind, until = excluded.until, label = excluded.label, created_at = datetime(\'now\')').run(userId, key, action, until, label);
  // the log is only ever added to
  db.prepare('INSERT INTO queue_log (user_id, key, action, until, label) VALUES (?, ?, ?, ?, ?)').run(userId, key, action, until, label);
}

// The Today list is asked by the menu of every open tab every two minutes (for the small numbers) and by the Today page itself. It is made from
// the database only, so it is kept for each person (and each view of that person) until something is written - a minute at most, because it counts
// days and the next meetings. Before, every one of those questions added the whole list up again.
const reportsKept = new Map<number | string, { v: number; at: number; day?: string; mark?: string; data: TodayReport }>();
export function todayReport(viewer: Viewer, scope: 'mine' | 'team'): TodayReport {
  const key = [viewer.id, viewer.role, viewer.display_name ?? '', viewer.market ?? '', scope, viewMode.team(viewer.id).names.join('\u0001')].join('|');
  return memoByData(reportsKept, key, () => todayReportRaw(viewer, scope), 60_000);
}
function todayReportRaw(viewer: Viewer, scope: 'mine' | 'team'): TodayReport {
  const today = todayIstanbul();
  const canTeam = canSeeTeam(viewer);
  const asks = asksFor(viewer, true);
  const canon = canonicalReps();
  const me = canon(viewer.display_name ?? '');
  const items: Item[] = [];

  const accountInfo = (sap: string) => accountOfSap(viewer, sap);
  const base = (a: Ask) => {
    const acc = accountInfo(a.sap);
    const cardId = a.cardId ?? acc?.cardId ?? null;
    return { key: cardId ? `c:${cardId}` : `s:${a.sap}`, cardId, sap: a.sap, name: acc?.name || a.customer, country: acc?.country ?? '', rep: acc?.rep ?? '' };
  };

  for (const a of asks.payment) {
    const eur = toEur(a.value, a.currency);
    items.push({ ...base(a), kind: 'payment', fact: { t: 'overdue', amount: a.value, cur: a.currency, days: a.days ?? 0 }, eur, score: eur + (a.days ?? 0) * 100 });
  }
  for (const a of asks.confirmation) {
    const eur = toEur(a.value, a.currency);
    items.push({ ...base(a), kind: 'advance', fact: { t: 'advance', orders: parseInt(a.line, 10) || 1, amount: a.value, cur: a.currency, days: a.days }, eur, score: eur * 0.9 + (a.days ?? 0) * 50 });
  }
  for (const a of asks.dispatch) {
    const eur = toEur(a.value, a.currency);
    const m = /^(\d+) lots?, ([\d,]+) kg/.exec(a.line);
    items.push({ ...base(a), kind: 'dispatch', fact: { t: 'dispatch', lots: m ? parseInt(m[1], 10) : 1, kg: m ? parseInt(m[2].replace(/,/g, ''), 10) : 0, amount: a.value, cur: a.currency }, eur, score: eur * 0.95 });
  }
  for (const a of asks.order) {
    items.push({ ...base(a), kind: 'slipping', fact: { t: 'quiet', days: a.days, prevYear: a.value, cur: a.currency }, eur: 0, score: toEur(a.value, a.currency) * 0.05 });
  }
  for (const a of asks.hold) {
    items.push({ ...base(a), kind: 'hold', fact: { t: 'hold', amount: a.value, cur: a.currency }, eur: toEur(a.value, a.currency), score: toEur(a.value, a.currency) * 0.4 });
  }

  // offers nobody answered
  for (const o of followUps(viewer)) {
    const card = cardModel.findById(o.card_id);
    items.push({ key: `c:${o.card_id}`, cardId: o.card_id, sap: card?.sap ?? null, name: o.customer, country: o.country ?? '', rep: card?.person ?? '', kind: 'offer', fact: { t: 'offer', days: o.days, title: o.title }, eur: o.currency === 'USD' ? (o.value ?? 0) / usdPerEur() : o.value ?? 0, score: 20_000 + o.days * 500 + (o.value ?? 0) * 0.2 });
  }

  // my own to-dos: today and late (to-dos are personal, so "team" does not add anyone else's)
  const todos = db.prepare(`SELECT t.id, t.card_id, t.text, t.due_date, COALESCE(c.company, c.name) AS customer, c.country, c.person, c.sap FROM todos t LEFT JOIN cards c ON c.id = t.card_id WHERE t.user_id = ? AND t.done_at IS NULL AND t.due_date <= ? ORDER BY t.due_date`).all(viewer.id, today) as { id: number; card_id: number | null; text: string; due_date: string; customer: string | null; country: string | null; person: string | null; sap: string | null }[];
  for (const t of todos) {
    const late = Math.max(0, daysBetween(t.due_date, today));
    items.push({ key: t.card_id ? `c:${t.card_id}` : `t:${t.id}`, cardId: t.card_id, sap: t.sap, name: t.customer ?? t.text.slice(0, 40), country: t.country ?? '', rep: t.person ?? me, kind: 'todo', fact: { t: 'todo', id: t.id, text: t.text, daysLate: late, due: t.due_date }, eur: 0, score: 10_000 + Math.min(late, 40) * 1_000, todoId: t.id });
  }

  // meetings in the next 7 days
  const meetings = db.prepare(`SELECT m.id, m.card_id, m.title, m.starts_at, m.tz, COALESCE(c.company, c.name) AS customer, c.country, c.person, c.sap FROM meetings m LEFT JOIN cards c ON c.id = m.card_id WHERE m.user_id = ? AND m.done_at IS NULL AND date(m.starts_at) >= ? AND date(m.starts_at) <= ? ORDER BY m.starts_at`).all(viewer.id, today, addDays(today, 7)) as { id: number; card_id: number | null; title: string; starts_at: string; tz: string | null; customer: string | null; country: string | null; person: string | null; sap: string | null }[];
  for (const m of meetings) {
    const away = Math.max(0, daysBetween(today, m.starts_at));
    items.push({ key: m.card_id ? `c:${m.card_id}` : `m:${m.id}`, cardId: m.card_id, sap: m.sap, name: m.customer ?? m.title, country: m.country ?? '', rep: m.person ?? me, kind: 'meeting', fact: { t: 'meeting', id: m.id, at: m.starts_at, tz: m.tz, title: m.title }, eur: 0, score: away <= 1 ? 200_000 : away <= 3 ? 100_000 : 40_000 });
  }

  // fold: one row per customer
  const byKey = new Map<string, Item[]>();
  for (const it of items) (byKey.get(it.key) ?? byKey.set(it.key, []).get(it.key)!).push(it);
  const state = stateOf(viewer.id);
  const rows: QueueRow[] = [];
  let hidden = 0;
  for (const [key, list] of byKey) {
    list.sort((a, b) => PRIORITY[b.kind] - PRIORITY[a.kind] || b.score - a.score);
    // the first item that carries money or the highest score leads
    const lead = [...list].sort((a, b) => b.score - a.score)[0];
    const others = list.filter((x) => x !== lead);
    const st = state.get(key);
    if (st) { hidden += 1; continue; }
    // "mine": what is looked after by this person (a staff member's scope is already their own)
    if (scope === 'mine' && (viewer.role === 'admin' || canTeam) && lead.rep && canon(lead.rep) !== me && lead.kind !== 'todo' && lead.kind !== 'meeting') continue;
    const risky = lead.sap ? accountInfo(lead.sap)?.risk?.level : null;
    const also: Fact[] = others.map((o) => o.fact);
    if (lead.kind === 'dispatch' && risky && risky !== 'good') also.push({ t: 'pays_late' });
    rows.push({ key, cardId: lead.cardId, sap: lead.sap, name: lead.name, country: lead.country, rep: lead.rep, kind: lead.kind, primary: lead.fact, also, eur: Math.round(list.reduce((a, x) => a + x.eur, 0)), score: lead.score + others.reduce((a, x) => a + x.score * 0.2, 0), todoId: lead.todoId ?? null });
  }
  rows.sort((a, b) => b.score - a.score);

  const count = (k: RowKind) => items.filter((i) => i.kind === k).length;
  const params: Record<string, string | number> = {};
  const vis = visibilitySql(viewer as never, params);
  const hotLeads = (db.prepare(`SELECT COUNT(*) AS n FROM cards WHERE ${SQL_IMPORTANT} AND COALESCE(stage, '') != 'customer'${vis ? ` AND ${vis}` : ''}`).get(params) as { n: number }).n;

  const next = db.prepare(`SELECT 'todo' AS kind, t.due_date AS date, NULL AS at, t.text AS label, t.card_id, COALESCE(c.company, c.name) AS name FROM todos t LEFT JOIN cards c ON c.id = t.card_id WHERE t.user_id = ? AND t.done_at IS NULL AND t.due_date > ? AND t.due_date <= ?
    UNION ALL SELECT 'meeting', date(m.starts_at), m.starts_at, m.title, m.card_id, COALESCE(c.company, c.name) FROM meetings m LEFT JOIN cards c ON c.id = m.card_id WHERE m.user_id = ? AND m.done_at IS NULL AND date(m.starts_at) >= ? AND date(m.starts_at) <= ? ORDER BY 2, 3 LIMIT 12`).all(viewer.id, today, addDays(today, 7), viewer.id, today, addDays(today, 7)) as { kind: 'todo' | 'meeting'; date: string; at: string | null; label: string; card_id: number | null; name: string | null }[];

  const overdue = asks.payment;
  const thankYous = (db.prepare(`SELECT COUNT(*) AS n FROM cards c JOIN exhibitions e ON e.id = c.exhibition_id WHERE c.thank_you_sent_at IS NULL AND c.email IS NOT NULL AND TRIM(c.email) != '' AND lower(e.name) NOT IN ('direct contacts', 'domestic customers') AND COALESCE(e.is_default, 0) = 0${vis ? ` AND ${vis.replace(/\bcards\./g, 'c.')}` : ''}`).get(params) as { n: number }).n;

  return {
    asOf: asks.through,
    sapAsOf: sapAsOf(),
    scope,
    canTeam,
    total: rows.length,
    rows,
    everything: { latePayments: count('payment'), hotLeads, advances: count('advance'), slipping: count('slipping'), dispatch: count('dispatch'), offers: count('offer'), todos: count('todo'), meetings: count('meeting') },
    week: next.map((n) => ({ date: n.date, label: n.label, kind: n.kind, at: n.at, cardId: n.card_id, name: n.name })),
    numbers: {
      overdueEur: Math.round(overdue.reduce((a, x) => a + toEur(x.value, x.currency), 0)),
      overdueCustomers: asks.totals.payment,
      dispatchEur: Math.round(asks.dispatch.reduce((a, x) => a + toEur(x.value, x.currency), 0)),
      dispatchCustomers: asks.totals.dispatch,
      slipping: asks.totals.order,
    },
    goal: goalToday(viewer.id),
    batches: { thankYous, statements: asks.totals.payment },
    snoozed: [...state].map(([key, s]) => ({ key, label: s.label, until: s.until, kind: s.kind })).slice(0, 50),
  };
}
