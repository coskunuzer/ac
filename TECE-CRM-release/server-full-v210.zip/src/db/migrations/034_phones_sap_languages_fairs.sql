-- SAP customer number, and three kinds of phone: mobile (WhatsApp), telephone (the old "tel" column) and fax.
ALTER TABLE cards ADD COLUMN sap TEXT;
ALTER TABLE cards ADD COLUMN mobile TEXT;
ALTER TABLE cards ADD COLUMN fax TEXT;
CREATE INDEX IF NOT EXISTS idx_cards_sap ON cards(sap);
UPDATE cards SET sap = json_extract(lead_info, '$.sap')
  WHERE sap IS NULL AND lead_info IS NOT NULL AND json_valid(lead_info) AND COALESCE(json_extract(lead_info, '$.sap'), '') != '';

-- The admin's e-mail texts in other languages (not every language: the ones that were written; English is the base text).
CREATE TABLE IF NOT EXISTS email_template_translations (
  template_id INTEGER NOT NULL REFERENCES email_templates(id) ON DELETE CASCADE,
  lang TEXT NOT NULL,
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  PRIMARY KEY (template_id, lang)
);

-- Fairs that are coming: do we take part (a stand) or do we visit, and who from the team will be there.
ALTER TABLE exhibitions ADD COLUMN presence TEXT NOT NULL DEFAULT 'visiting';
CREATE TABLE IF NOT EXISTS exhibition_attendees (
  exhibition_id INTEGER NOT NULL REFERENCES exhibitions(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  PRIMARY KEY (exhibition_id, user_id)
);

-- A person's own rating changes are kept as activities ("rated"), for the points of the mission board.
-- (no schema change: the activity type is text)
