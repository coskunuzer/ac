ALTER TABLE cards ADD COLUMN extraction_error TEXT;
