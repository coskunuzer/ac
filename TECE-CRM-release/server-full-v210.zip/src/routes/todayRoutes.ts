import { Router } from 'express';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { setQueueState, todayReport } from '../services/todayQueue';
import { db } from '../db/connection';

// Today: one ranked queue per person. Reading it changes nothing; Done, Snooze and "Not mine" are written to the append-only log.
const router = Router();
router.use(requireAuth);

router.get('/', (req: AuthedRequest, res) => {
  const scope = req.query.scope === 'team' ? 'team' : 'mine';
  const report = todayReport(req.user!, scope);
  if (scope === 'team' && !report.canTeam) return res.status(403).json({ error: 'The team view is for people who oversee a team.' });
  res.json(report);
});

// the small numbers on the menu: only where work is waiting
router.get('/counts', (req: AuthedRequest, res) => {
  const r = todayReport(req.user!, 'mine');
  res.json({ today: r.total, money: r.numbers.overdueCustomers, orders: r.everything.dispatch + r.everything.advances, followUps: r.everything.offers + r.batches.thankYous, sapAsOf: r.sapAsOf });
});

router.post('/state', (req: AuthedRequest, res) => {
  const b = (req.body ?? {}) as { key?: unknown; action?: unknown; days?: unknown; label?: unknown };
  const key = typeof b.key === 'string' ? b.key.slice(0, 60) : '';
  const action = b.action;
  if (!/^[csmt]:[\w.-]+$/.test(key) || (action !== 'snooze' && action !== 'not_mine' && action !== 'done' && action !== 'undo')) return res.status(400).json({ error: 'Not a valid action.' });
  const days = typeof b.days === 'number' ? b.days : action === 'done' ? 7 : 3;
  setQueueState(req.user!.id, key, action, days, typeof b.label === 'string' ? b.label.slice(0, 120) : null);
  res.json({ ok: true });
});

// my last actions on the queue (for the "snoozed" list)
router.get('/log', (req: AuthedRequest, res) => {
  res.json(db.prepare('SELECT key, action, until, label, at FROM queue_log WHERE user_id = ? ORDER BY id DESC LIMIT 50').all(req.user!.id));
});

export default router;
