import { db } from '../db/connection';
import { fill, getTemplate } from './shipTemplates';
import { askJson } from './perfActions';
import { logEvent, sendShipMail } from './shipMail';
import { subjectOf } from './shipQuotes';
import { chargeLines } from './shipCharges';
import { countryName, findForwarder, matchPlace, MODES, parseRequest, type ParsedRequest } from './shipPlaces';

// A freight request: the original text is kept word for word; the fields are read from it (rules first, DeepSeek for the rest), checked by a person, then one
// e-mail per firm goes out. The number is the date and a running number of the day (20261114-03): it is in every subject, and the replies are found by it.

export function nextRequestId(today = new Date()): string {
  const d = new Date(today.getTime() + 3 * 3600_000).toISOString().slice(0, 10).replace(/-/g, '');
  const last = db.prepare("SELECT id FROM ship_requests WHERE id LIKE ? ORDER BY id DESC LIMIT 1").get(`${d}-%`) as { id: string } | undefined;
  const n = last ? parseInt(last.id.split('-')[1], 10) + 1 : 1;
  return `${d}-${String(n).padStart(2, '0')}`;
}

const SCHEMA = { type: 'OBJECT', properties: { country: { type: 'STRING' }, city: { type: 'STRING' }, pallets: { type: 'NUMBER' }, weight_kg: { type: 'NUMBER' }, size: { type: 'STRING' }, ready: { type: 'STRING' } }, required: ['country', 'city', 'pallets', 'weight_kg', 'size', 'ready'] };

// the rules first; DeepSeek makes ONE short attempt at what they missed (and only then). Nothing it says replaces what the rules found.
export async function readRequest(text: string, useAi: boolean): Promise<ParsedRequest & { ai: boolean }> {
  const p = parseRequest(text);
  let ai = false;
  if (useAi && p.missing.length && text.trim().length > 15) {
    try {
      const j = await askJson(`A freight request was pasted (Turkish or English). Extract the delivery destination (country name and city, in English), the number of pallets, the total weight in kg, the size of a pallet or the cargo (as written), and when the goods are ready. If something is not written, leave it empty (or 0 for numbers). Never guess.\n\n${text.slice(0, 2500)}`, SCHEMA);
      if (j) {
        ai = true;
        if (!p.iso && j.country) { const pl = matchPlace(String(j.country)); if (pl?.type === 'country') { p.iso = pl.iso; p.country = pl.name; } }
        if (!p.city && j.city) p.city = String(j.city).slice(0, 60);
        if (!p.pallets && Number(j.pallets) > 0) p.pallets = String(Math.round(Number(j.pallets)));
        if (!p.weight && Number(j.weight_kg) > 0) p.weight = String(Math.round(Number(j.weight_kg)));
        if (!p.size && j.size) p.size = String(j.size).slice(0, 60);
        if (!p.ready && j.ready) p.ready = String(j.ready).slice(0, 60);
        p.found = ['country', 'city', 'pallets', 'weight', 'size', 'ready'].filter((k) => (p as unknown as Record<string, string>)[k]);
        p.missing = ['country', 'city', 'pallets', 'weight', 'size', 'ready'].filter((k) => !(p as unknown as Record<string, string>)[k]);
      }
    } catch { /* the rules' answer stands */ }
  }
  p.ready = trReady(p.ready);
  return { ...p, ai };
}

// the AI (or a person) may write the ready date in English: the screens and the e-mails are Turkish
export function trReady(v: string | null | undefined): string {
  const s = String(v ?? '').trim();
  if (!s) return '';
  const t = s.toLowerCase();
  if (/^(ready( for (shipment|dispatch|loading|pickup))?|ready now|immediately|now|available( now)?)$/.test(t)) return 'Sevke hazır';
  let m = /^ready (in|within) (\d+) (day|days|week|weeks)$/.exec(t);
  if (m) return `${m[2]} ${m[3].startsWith('week') ? 'hafta' : 'gün'} içinde hazır`;
  m = /^(in )?(\d+) (day|days|week|weeks)$/.exec(t);
  if (m) return `${m[2]} ${m[3].startsWith('week') ? 'hafta' : 'gün'} içinde hazır`;
  return s.replace(/\bready\b/gi, 'hazır').replace(/\bfor shipment\b/gi, '').replace(/\bshipment\b/gi, 'sevk').replace(/\s+/g, ' ').trim();
}

export interface NewRequest { text: string; country: string; countryIso?: string | null; city?: string; mode: string; pallets?: number | null; weightKg?: number | null; size?: string; ready?: string; pickup?: string; cardId?: number | null; exportKey?: string | null; forwarderIds: number[]; userId: number; askId?: number | null; cargo?: string; charges?: string[] }

// creates the request and sends one e-mail to each chosen firm
export async function sendRequest(input: NewRequest): Promise<{ id: string; sent: number; failed: { name: string; error: string }[] }> {
  const mode = MODES.find((m) => m === input.mode) ?? 'Karayolu';
  const place = input.countryIso ? null : matchPlace(input.country);
  const iso = input.countryIso ?? (place?.type === 'country' ? place.iso : null);
  const country = iso ? countryName(iso) : input.country.trim();
  const id = nextRequestId();
  db.prepare('INSERT INTO ship_requests (id, original_text, country, country_iso, city, mode, pallets, weight_kg, size, ready, pickup, owner_id, card_id, export_key, charges) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
    .run(id, input.text, country, iso, input.city?.trim() || null, mode, input.pallets ?? null, input.weightKg ?? null, input.size?.trim() || null, trReady(input.ready) || null, input.pickup?.trim() || 'Bursa, Türkiye', input.userId, input.cardId ?? null, input.exportKey ?? null, input.charges?.length ? JSON.stringify(input.charges) : null);
  logEvent(id, null, 'created', `Talep oluşturuldu: ${[input.city, country].filter(Boolean).join(', ')} · ${mode}`, input.userId);
  if (input.cargo?.trim()) logEvent(id, null, 'cargo', `Firmalara giden yük bilgisi: ${input.cargo.trim().replace(/\s*\n\s*/g, ' / ').slice(0, 400)}`, input.userId);
  const r = { id, mode, country, city: input.city?.trim() || null };
  const failed: { name: string; error: string }[] = [];
  let sent = 0;
  for (const fid of [...new Set(input.forwarderIds)]) {
    const f = findForwarder(fid);
    if (!f || !f.active || !f.emails.length) continue;
    db.prepare('INSERT OR IGNORE INTO ship_request_fw (request_id, forwarder_id, forwarder_name, emails, lang) VALUES (?, ?, ?, ?, ?)').run(id, f.id, f.name, JSON.stringify(f.emails), f.lang);
    const body = requestBody({ ...r, pallets: input.pallets ?? null, weightKg: input.weightKg ?? null, size: input.size ?? '', ready: trReady(input.ready), pickup: input.pickup || 'Bursa, Türkiye', text: input.text, cargo: input.cargo, charges: input.charges }, f.contact, f.lang);
    const res = await sendShipMail({ to: f.emails, subject: subjectOf(r), body, kind: 'rfq', requestId: id, forwarderId: f.id, userId: input.userId });
    if (res.ok) { sent++; db.prepare("UPDATE ship_request_fw SET sent_at = datetime('now') WHERE request_id = ? AND forwarder_id = ?").run(id, f.id); }
    else failed.push({ name: f.name, error: res.error ?? 'Gönderilemedi' });
  }
  if (input.askId) db.prepare("UPDATE ship_asks SET status = 'done', request_id = ?, handled_at = datetime('now'), handled_by = ? WHERE id = ?").run(id, input.userId, input.askId);
  logEvent(id, null, 'sent', `${sent} firmaya gönderildi${failed.length ? `, ${failed.length} gönderilemedi` : ''}`, input.userId);
  return { id, sent, failed };
}

// (the cargo text a person confirms on the screen is built in the browser; whatever they leave there goes to the firms word for word)
type BodyInput = { country: string | null; city: string | null; pallets: number | null; weightKg: number | null; size: string; ready: string; pickup: string; text: string; cargo?: string; charges?: string[] };
// the e-mail one firm gets; the ticked charges (port, inland transport, YDG ...) are listed before the request for the all-in price
export function requestBody(r: BodyInput, contact: string | null, lang: string): string {
  const en = lang === 'en';
  const dest = [r.city, r.country].filter(Boolean).join(', ');
  const load = [r.pallets ? `${r.pallets} ${en ? 'pallets' : 'palet'}` : '', r.weightKg ? `${Number(r.weightKg).toLocaleString('tr-TR')} kg` : '', r.size].filter(Boolean).join(', ');
  const noteHead = en ? 'Request note (original, in Turkish):' : 'Talep notu:';
  let details: string;
  if (r.cargo && r.cargo.trim()) details = `${r.cargo.trim()}${r.text.trim() ? `\n\n${noteHead}\n"${r.text.trim()}"` : ''}`;
  else details = en ? `From: ${r.pickup}\nTo: ${dest}\nCargo: ${load}\nReady: ${r.ready || '-'}\n\n${noteHead}\n"${r.text.trim()}"` : `Çıkış: ${r.pickup}\nVarış: ${dest}\nYük: ${load}\nHazır olma tarihi: ${r.ready || '-'}\n\n${noteHead}\n"${r.text.trim()}"`;
  const chg = chargeLines(r.charges ?? [], en);
  let tpl = getTemplate('rfq', lang).body;
  const noSlot = !!chg && !tpl.includes('{charges}');
  if (noSlot) tpl = tpl.replace('{details}', '{details}\n\n{charges}');
  const out = fill(tpl, { hello: en ? `Dear ${contact || 'Sir or Madam'},` : `Sayın ${contact || 'yetkili'},`, details, charges: chg ? `${chg}\n\n` : '', sign: en ? 'Best regards,\nTECE Dekor - Operations' : 'Saygılarımızla,\nTECE Dekor - Operasyon' });
  return noSlot ? out.replace(/\n{3,}/g, '\n\n') : out;
}

// "Update" instead of a second request: more quantity, one more supplier, a changed term. The firms that were asked get the change (same subject, Re:), added firms get the full request.
export async function updateRequest(requestId: string, input: { note: string; cargo?: string; charges?: string[]; addForwarderIds?: number[]; userId: number }): Promise<{ updated: number; added: number; failed: { name: string; error: string }[] }> {
  const r = db.prepare('SELECT * FROM ship_requests WHERE id = ?').get(requestId) as unknown as { id: string; mode: string; country: string | null; city: string | null; status: string; original_text: string; pallets: number | null; weight_kg: number | null; size: string | null; ready: string | null; pickup: string | null; charges: string | null } | undefined;
  if (!r || r.status !== 'open') throw new Error('Bu talep açık değil; güncellenemez.');
  const subj = subjectOf({ id: r.id, mode: r.mode, country: r.country, city: r.city });
  const charges = input.charges ?? (r.charges ? (JSON.parse(r.charges) as string[]) : []);
  if (input.charges) db.prepare('UPDATE ship_requests SET charges = ? WHERE id = ?').run(JSON.stringify(input.charges), r.id);
  const failed: { name: string; error: string }[] = [];
  let updated = 0, added = 0;
  const asked = db.prepare('SELECT * FROM ship_request_fw WHERE request_id = ? AND sent_at IS NOT NULL AND cancelled_at IS NULL').all(r.id) as unknown as { forwarder_id: number; forwarder_name: string; emails: string; lang: string }[];
  for (const w of asked) {
    const en = w.lang === 'en';
    const contact = (db.prepare('SELECT contact FROM ship_forwarders WHERE id = ?').get(w.forwarder_id) as { contact: string | null } | undefined)?.contact ?? null;
    const chg = chargeLines(charges, en);
    const text = en
      ? `Dear ${contact || 'Sir or Madam'},\n\nThere is an update to our request #${r.id}:\n\n${input.note.trim()}${input.cargo?.trim() ? `\n\n${input.cargo.trim()}` : ''}${chg ? `\n\n${chg}` : ''}\n\nPlease send your updated total price (all-in). Reply without changing the subject line.\n\nBest regards,\nTECE Dekor - Operations`
      : `Sayın ${contact || 'yetkili'},\n\n#${r.id} numaralı talebimizde güncelleme var:\n\n${input.note.trim()}${input.cargo?.trim() ? `\n\n${input.cargo.trim()}` : ''}${chg ? `\n\n${chg}` : ''}\n\nGüncel koşullara göre toplam fiyatınızı (all-in) yeniden iletmenizi rica ederiz. Yanıtınızı konu satırını değiştirmeden iletiniz.\n\nSaygılarımızla,\nTECE Dekor - Operasyon`;
    const res = await sendShipMail({ to: JSON.parse(w.emails) as string[], subject: `Re: ${subj}`, body: text, kind: 'update', requestId: r.id, forwarderId: w.forwarder_id, userId: input.userId });
    if (res.ok) { updated++; db.prepare("UPDATE ship_request_fw SET answered_at = NULL, reminded_at = NULL WHERE request_id = ? AND forwarder_id = ? AND NOT EXISTS (SELECT 1 FROM ship_quotes q WHERE q.request_id = ? AND q.forwarder_id = ? AND q.status IN ('open','countered'))").run(r.id, w.forwarder_id, r.id, w.forwarder_id); }
    else failed.push({ name: w.forwarder_name, error: res.error ?? 'Gönderilemedi' });
  }
  for (const fid of [...new Set(input.addForwarderIds ?? [])]) {
    const f = findForwarder(fid);
    if (!f || !f.active || !f.emails.length || asked.some((a) => a.forwarder_id === f.id)) continue;
    db.prepare('INSERT OR IGNORE INTO ship_request_fw (request_id, forwarder_id, forwarder_name, emails, lang) VALUES (?, ?, ?, ?, ?)').run(r.id, f.id, f.name, JSON.stringify(f.emails), f.lang);
    const body = requestBody({ country: r.country, city: r.city, pallets: r.pallets, weightKg: r.weight_kg, size: r.size ?? '', ready: trReady(r.ready), pickup: r.pickup || 'Bursa, Türkiye', text: `${r.original_text}${input.note.trim() ? `\n\n(Güncelleme: ${input.note.trim()})` : ''}`, cargo: input.cargo, charges }, f.contact, f.lang);
    const res = await sendShipMail({ to: f.emails, subject: subj, body, kind: 'rfq', requestId: r.id, forwarderId: f.id, userId: input.userId });
    if (res.ok) { added++; db.prepare("UPDATE ship_request_fw SET sent_at = datetime('now') WHERE request_id = ? AND forwarder_id = ?").run(r.id, f.id); }
    else failed.push({ name: f.name, error: res.error ?? 'Gönderilemedi' });
  }
  logEvent(r.id, null, 'updated', `Talep güncellendi: ${input.note.trim().replace(/\s*\n\s*/g, ' / ').slice(0, 300)} (${updated} firmaya bildirildi${added ? `, ${added} yeni firma eklendi` : ''})`, input.userId);
  return { updated, added, failed };
}

// More firms for an open request: only the new firms get the (full) request - the firms that were already asked hear nothing.
export async function addFirms(requestId: string, forwarderIds: number[], userId: number): Promise<{ added: number; failed: { name: string; error: string }[] }> {
  const r = db.prepare('SELECT * FROM ship_requests WHERE id = ?').get(requestId) as unknown as { id: string; mode: string; country: string | null; city: string | null; status: string; original_text: string; pallets: number | null; weight_kg: number | null; size: string | null; ready: string | null; pickup: string | null; charges: string | null } | undefined;
  if (!r || r.status !== 'open') throw new Error('Bu talep açık değil; firma eklenemez.');
  const subj = subjectOf({ id: r.id, mode: r.mode, country: r.country, city: r.city });
  const charges = r.charges ? (JSON.parse(r.charges) as string[]) : [];
  const cargo = (db.prepare("SELECT text FROM ship_events WHERE request_id = ? AND kind = 'cargo' ORDER BY id DESC LIMIT 1").get(r.id) as { text: string } | undefined)?.text.replace(/^Firmalara giden yük bilgisi:\s*/, '').replace(/ \/ /g, '\n');
  const have = new Set((db.prepare('SELECT forwarder_id FROM ship_request_fw WHERE request_id = ? AND sent_at IS NOT NULL').all(r.id) as { forwarder_id: number }[]).map((x) => x.forwarder_id));
  const failed: { name: string; error: string }[] = [];
  let added = 0;
  for (const fid of [...new Set(forwarderIds)]) {
    const f = findForwarder(fid);
    if (!f || !f.active || !f.emails.length || have.has(f.id)) continue;
    db.prepare('INSERT OR IGNORE INTO ship_request_fw (request_id, forwarder_id, forwarder_name, emails, lang) VALUES (?, ?, ?, ?, ?)').run(r.id, f.id, f.name, JSON.stringify(f.emails), f.lang);
    const body = requestBody({ country: r.country, city: r.city, pallets: r.pallets, weightKg: r.weight_kg, size: r.size ?? '', ready: trReady(r.ready), pickup: r.pickup || 'Bursa, Türkiye', text: r.original_text, cargo, charges }, f.contact, f.lang);
    const res = await sendShipMail({ to: f.emails, subject: subj, body, kind: 'rfq', requestId: r.id, forwarderId: f.id, userId });
    if (res.ok) { added++; db.prepare("UPDATE ship_request_fw SET sent_at = datetime('now') WHERE request_id = ? AND forwarder_id = ?").run(r.id, f.id); }
    else failed.push({ name: f.name, error: res.error ?? 'Gönderilemedi' });
  }
  if (added || failed.length) logEvent(r.id, null, 'sent', `${added} yeni firmaya gönderildi${failed.length ? `, ${failed.length} gönderilemedi` : ''}`, userId);
  return { added, failed };
}
