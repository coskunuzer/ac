import fs from 'fs';
import { renderDocumentPdf } from '../services/offerPdf';
import { isLang } from '../services/translate';
import { archivePdf } from '../services/archive';
import { filePath as priceListFile } from '../services/priceBook/store';
import path from 'path';
import { Router, type Request, type Response } from 'express';
import multer from 'multer';
import { requireAuth, requireAdmin, requireAdminOr, type AuthedRequest } from '../middleware/auth';
import { paths } from '../config/env';
import { DOCUMENT_KINDS, libraryModel, priceListModel, type DocumentKind, type LibraryDocument } from '../models/pricingModels';
import { userModel } from '../models/userModel';
import { activePriceBook, installPriceList, PriceListRejected } from '../services/priceBook/store';
import { sanitiseOffer } from '../services/offerRequest';
import { settingsModel } from '../models/settingsModel';
import { priceMarketFor } from '../services/priceMarket';
import { enabledTabs, offerCatalog, setEnabledTabs } from '../services/offerTabs';
import { PRODUCT_TABS } from '../services/priceBook';
import { cardModel } from '../models/cardModel';
import { canSeeCard } from '../services/visibility';
import { offerMemoryFor } from '../services/pricingAnalysis';
import { ownPrices } from '../services/offerOverrides';

const router = Router();
router.use(requireAuth);

fs.mkdirSync(paths.libraryDir, { recursive: true });

const priceListUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 25 * 1024 * 1024 } });

const LIBRARY_EXTENSIONS = new Set(['.pdf', '.png', '.jpg', '.jpeg', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx']);
const libraryUpload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, paths.libraryDir),
    filename: (_req, file, cb) =>
      cb(null, `${Date.now()}-${Math.round(Math.random() * 1e9)}${path.extname(file.originalname).toLowerCase()}`),
  }),
  limits: { fileSize: 15 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (!LIBRARY_EXTENSIONS.has(path.extname(file.originalname).toLowerCase())) {
      return cb(new Error('Allowed file types: PDF, images, Word, Excel, PowerPoint'));
    }
    cb(null, true);
  },
});

function publicDocument(d: LibraryDocument) {
  return { id: d.id, title: d.title, kind: d.kind, originalName: d.original_name, sizeBytes: d.size_bytes, createdAt: d.created_at };
}

// ---- price list ---------------------------------------------------------

// Each market has its own live list. An admin can ask for either (?market=domestic); everybody else gets their own
// team's list and never the other one.
function marketOf(req: AuthedRequest): string | null {
  const asked = typeof req.query.market === 'string' ? req.query.market : typeof req.body?.market === 'string' ? req.body.market : undefined;
  return priceMarketFor(req.user!, asked ?? req.user!.market);
}

router.get('/status', (req: AuthedRequest, res) => {
  const market = marketOf(req);
  if (!market) return res.json({ active: null, history: [], market: null });
  const active = priceListModel.findActive(market);
  const toJson = (row: typeof active) =>
    row && {
      id: row.id,
      originalName: row.original_name,
      uploadedAt: row.uploaded_at,
      uploadedBy: row.uploaded_by ? userModel.findById(row.uploaded_by)?.display_name ?? null : null,
      summary: JSON.parse(row.summary),
      isActive: !!row.is_active,
    };
  res.json({
    market,
    active: toJson(active) ?? null,
    history: req.user!.role === 'admin' ? priceListModel.listRecent(8, market).map(toJson) : [],
  });
});

router.post('/price-list', requireAdmin, (req: AuthedRequest, res) => {
  priceListUpload.single('file')(req, res, (uploadErr) => {
    if (uploadErr) return res.status(400).json({ error: uploadErr.message });
    if (!req.file) return res.status(400).json({ error: 'Choose the price workbook (.xls or .xlsx) to upload.' });
    try {
      const row = installPriceList(req.file.buffer, req.file.originalname, req.user!.id, req.body?.market === 'domestic' ? 'domestic' : 'export');
      res.status(201).json({ id: row.id, originalName: row.original_name, summary: JSON.parse(row.summary) });
    } catch (err) {
      if (err instanceof PriceListRejected) return res.status(422).json({ error: err.message });
      console.error('Price list upload failed:', err);
      res.status(500).json({ error: 'Could not process this workbook.' });
    }
  });
});

// The look of the offer PDFs: 'tece' (the TECE design, the same pages and rows) or 'classic' (each worksheet as Excel draws it).
router.get('/offer-style', (_req, res) => {
  res.json({ style: settingsModel.get('offer_style') === 'classic' ? 'classic' : 'tece' });
});
router.put('/offer-style', requireAdmin, (req, res) => {
  const style = req.body?.style === 'classic' ? 'classic' : 'tece';
  settingsModel.set('offer_style', style);
  res.json({ style });
});

function requireBook(req: AuthedRequest, res: Response) {
  const market = marketOf(req);
  if (!market) {
    res.status(403).json({ error: 'Your account does not have access to that price list.' });
    return null;
  }
  const active = activePriceBook(market);
  if (!active) {
    res.status(404).json({ error: `No ${market === 'domestic' ? 'domestic ' : ''}price list has been uploaded yet - ask an admin to upload it under Price list.` });
    return null;
  }
  return active;
}

// The whole price list as one PDF, in one click: every offered product with its standard rows and widths, at the list prices.
// an earlier uploaded price workbook, as it was uploaded (admin)
router.get('/price-list/:id/file', requireAdmin, (req, res) => {
  const row = priceListModel.findById(parseInt(String(req.params.id), 10));
  if (!row) return res.status(404).json({ error: 'Not found' });
  res.download(priceListFile(row), row.original_name);
});

router.get('/price-list.pdf', async (req: AuthedRequest, res) => {
  const active = requireBook(req, res);
  if (!active) return;
  try {
    const book = active.book;
    const selections = offerCatalog(book.catalog).map((sec) => ({ sheet: sec.sheet, rows: sec.rows.filter((r) => !r.hidden).map((r) => r.id), columns: sec.columns.filter((c) => !c.hidden).map((c) => c.id) }));
    // for one customer: the whole list at THEIR level (the price level set on the customer, or what they pay today when their SAP proformas were uploaded)
    const cardId = parseInt(String(req.query.card ?? ''), 10);
    const card = Number.isInteger(cardId) ? cardModel.findById(cardId) : undefined;
    if (card && !canSeeCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
    const mem = card ? offerMemoryFor(req.user!, card.id, null) : null;
    // their own prices (from their SAP proformas) win over everything; rows they never bought follow their general level
    const own = card ? ownPrices(book, card.id) : null;
    const params = { ...book.defaults, ...(own ? { currency: own.currency, usdRate: own.currency === 'USD' ? book.defaults.usdRate : 1, cellOverrides: own.cellOverrides } : {}), transportPct: mem?.overall ?? card?.offer_percent ?? book.defaults.transportPct, pagePct: mem && Object.keys(mem.pagePct).length ? mem.pagePct : book.defaults.pagePct };
    const cs = card?.offer_style;
    const style = (cs === 'classic' || cs === 'tece' ? cs : settingsModel.get('offer_style') === 'classic' ? 'classic' : 'tece') as 'classic' | 'tece';
    const pdf = await book.render(params, { name: card?.name ?? '', company: card?.company ?? '', address: card?.address ?? '', country: card?.country ?? '', tel: card?.tel ?? '', email: card?.email ?? '', preparedBy: req.user!.display_name || req.user!.username, date: new Date() }, selections, true, style);
    archivePdf({ kind: 'price_list', priceListId: active.row?.id ?? null, title: `Price list ${active.row?.original_name ?? ''} (${marketOf(req) ?? 'export'})`, fileName: `TECE-Price-List-${new Date().toISOString().slice(0, 10)}.pdf`, pdf, userId: req.user!.id });
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="TECE-Price-List${card ? '-' + (card.company || card.name || card.id).toString().replace(/[^w-]+/g, '_') : ''}-${new Date().toISOString().slice(0, 10)}.pdf"`);
    res.send(pdf);
  } catch (err) {
    console.error('Price list PDF failed:', err);
    res.status(500).json({ error: 'The price list could not be made.' });
  }
});

router.get('/catalog', (req: AuthedRequest, res) => {
  const active = requireBook(req, res);
  if (!active) return;
  res.json({ priceListId: active.row.id, defaults: active.book.defaults, sections: offerCatalog(active.book.catalog), hasMoq: active.book.hasMoq, hasPackaging: active.book.hasPackaging });
});

// The documents that are made from the price list itself (MOQ pages, packaging details): ticked with the other documents of an e-mail.
router.get('/extras', (req: AuthedRequest, res) => {
  const market = marketOf(req);
  const active = market ? activePriceBook(market) : null;
  res.json({ hasMoq: !!active?.book.hasMoq, hasPackaging: !!active?.book.hasPackaging });
});

router.get('/document/:kind', async (req: AuthedRequest, res) => {
  const kind = req.params.kind === 'moq' ? 'moq' : req.params.kind === 'packaging' ? 'packaging' : null;
  const active = kind ? requireBook(req, res) : null;
  if (!kind || !active) return kind ? undefined : res.status(404).json({ error: 'Not found' });
  try {
    const lang = isLang(req.query.language) ? req.query.language : undefined;
    const pdf = await renderDocumentPdf(active.book, kind, active.book.defaults, { name: '', company: '', address: '', country: '', tel: '', email: '', preparedBy: req.user!.display_name || req.user!.username, date: new Date() }, lang);
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="tece-${kind}.pdf"`);
    res.send(pdf);
  } catch (err) {
    res.status(404).json({ error: (err as Error).message });
  }
});

// Which products of the price list are offered to everybody (admin). Everything else stays in the workbook but is not shown.
router.get('/tabs', requireAdmin, (req: AuthedRequest, res) => {
  const market = marketOf(req);
  const active = market ? activePriceBook(market) : null;
  const on = new Set(enabledTabs());
  res.json({
    tabs: PRODUCT_TABS.map((sheet) => {
      const section = active?.book.catalog.find((c) => c.sheet === sheet);
      return { sheet, title: section ? section.title.replace(/^offer for\s+/i, '').split('|')[0].trim() : sheet, inWorkbook: !!section, rows: section?.rows.length ?? 0, enabled: on.has(sheet) };
    }),
  });
});
router.put('/tabs', requireAdmin, (req, res) => {
  const list = Array.isArray(req.body?.enabled) ? req.body.enabled.filter((x: unknown): x is string => typeof x === 'string') : [];
  res.json({ enabled: setEnabledTabs(list) });
});

// Prices every row/column with the offer's percentages applied - this is what
// the builder shows while staff adjust surcharge/discount.
router.post('/price', (req: AuthedRequest, res) => {
  const active = requireBook(req, res);
  if (!active) return;
  const { params } = sanitiseOffer({ params: req.body?.params }, active.book);
  res.json({ sections: active.book.preview(params) });
});

// ---- document library ---------------------------------------------------

router.get('/library', (_req, res) => {
  res.json(libraryModel.list().map(publicDocument));
});

router.post('/library', requireAdminOr('catalog'), (req: AuthedRequest, res) => {
  libraryUpload.single('file')(req, res, (uploadErr) => {
    if (uploadErr) return res.status(400).json({ error: uploadErr.message });
    if (!req.file) return res.status(400).json({ error: 'Choose a file to add.' });
    const kind = DOCUMENT_KINDS.includes(req.body?.kind) ? (req.body.kind as DocumentKind) : 'other';
    const title = String(req.body?.title || '').trim().slice(0, 120) || path.parse(req.file.originalname).name;
    const doc = libraryModel.create({
      title,
      kind,
      originalName: req.file.originalname,
      storedName: req.file.filename,
      mimeType: req.file.mimetype,
      sizeBytes: req.file.size,
      uploadedBy: req.user!.id,
    });
    res.status(201).json(publicDocument(doc));
  });
});

router.delete('/library/:id', requireAdminOr('catalog'), (req, res) => {
  const doc = libraryModel.findById(parseInt(String(req.params.id), 10));
  if (!doc) return res.status(404).json({ error: 'Not found' });
  fs.unlink(path.join(paths.libraryDir, doc.stored_name), (err) => {
    if (err && err.code !== 'ENOENT') console.error('Failed to delete library file:', err);
  });
  libraryModel.delete(doc.id);
  res.json({ ok: true });
});

router.get('/library/:id/file', (req, res) => {
  const doc = libraryModel.findById(parseInt(String(req.params.id), 10));
  if (!doc) return res.status(404).json({ error: 'Not found' });
  res.setHeader('Content-Disposition', `inline; filename*=UTF-8''${encodeURIComponent(doc.original_name)}`);
  res.sendFile(path.join(paths.libraryDir, doc.stored_name), { headers: { 'Content-Type': doc.mime_type } });
});

export default router;
