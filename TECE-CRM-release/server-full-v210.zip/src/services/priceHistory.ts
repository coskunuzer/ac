import { db } from '../db/connection';
import type { CardRow } from '../models/cardModel';
import { offerLogModel, type OfferEntry } from '../models/pricingModels';

// A customer's price history, kept as its own file in their folder ("Price changes.txt"): every offer
// that went out with the price level of each page, and every time the customer's discount level was
// changed on the record - so it is always clear what this customer was quoted, when, and why it moved.

export function logDiscountChange(cardId: number, by: string | null, from: number | null, to: number | null): void {
  if ((from ?? 0) === (to ?? 0)) return;
  db.prepare('INSERT INTO price_changes (card_id, changed_by, old_percent, new_percent) VALUES (?, ?, ?, ?)').run(cardId, by, from, to);
}

interface ChangeRow {
  changed_at: string;
  changed_by: string | null;
  old_percent: number | null;
  new_percent: number | null;
}

const pct = (n: number | null | undefined) => {
  if (n === null || n === undefined || n === 0) return 'list price';
  const v = Math.round(n * 1000) / 10;
  return `${v > 0 ? '+' : ''}${v} %`;
};
const stamp = (utc: string) => utc.slice(0, 16).replace('T', ' ');

export function priceHistoryText(card: CardRow): string {
  const changes = db.prepare('SELECT changed_at, changed_by, old_percent, new_percent FROM price_changes WHERE card_id = ?').all(card.id) as unknown as ChangeRow[];
  const offers = offerLogModel.listForCard(card.id).filter((o) => o.kind === 'offer').reverse(); // oldest first

  type Event = { at: string; order: number; lines: string[] };
  const events: Event[] = [];
  for (const c of changes) {
    events.push({
      at: c.changed_at,
      order: 0,
      lines: [`DISCOUNT LEVEL CHANGED on the record: ${pct(c.old_percent)} -> ${pct(c.new_percent)}${c.changed_by ? `  (by ${c.changed_by})` : ''}`],
    });
  }
  let previous: OfferEntry | null = null;
  for (const o of offers) {
    const was = new Map((previous?.pages ?? []).map((p) => [p.title, p.percent ?? previous!.percent]));
    const lines: string[] = [`OFFER SENT${o.sentBy ? ` by ${o.sentBy}` : ''}${o.priceList ? `   (price list: ${o.priceList})` : ''}`];
    lines.push(`    Whole offer: ${pct(o.percent)}    Currency: ${o.currency ?? 'EUR'}${o.widths?.length ? `    Edge widths: ${o.widths.join(', ')} mm` : ''}`);
    let moved = 0;
    for (const p of o.pages) {
      const own = p.percent ?? o.percent;
      const before = was.get(p.title);
      const note = !previous ? '' : before === undefined ? '  (new page)' : (before ?? 0) === (own ?? 0) ? '' : `  <- CHANGED, was ${pct(before)}`;
      if (note.includes('CHANGED')) moved += 1;
      const separate = p.percent !== undefined && p.percent !== null && p.percent !== o.percent ? '  (its own discount)' : '';
      lines.push(`    ${p.title}: ${pct(own)}${separate}${p.products ? `   [${p.products}]` : ''}${note}`);
    }
    if (o.includeMoq) lines.push('    MOQ pages');
    lines.push(previous ? (moved ? `    Price level changed since the previous offer on ${moved} page${moved === 1 ? '' : 's'}.` : '    Same price level as the previous offer.') : '    First offer to this customer.');
    events.push({ at: o.sentAt, order: 1, lines });
    previous = o;
  }
  events.sort((a, b) => (a.at === b.at ? a.order - b.order : a.at < b.at ? -1 : 1));

  const head = [
    `PRICE CHANGES - ${[card.company, card.name].filter(Boolean).join(' / ') || `customer ${card.id}`}${card.country ? ` (${card.country})` : ''}`,
    'Every offer sent to this customer, with the price level of each page, and every change of their discount level.',
    `Discount level on the record now: ${pct(card.offer_percent)}`,
    '',
  ];
  if (!events.length) return [...head, 'Nothing yet.'].join('\n') + '\n';
  return [...head, ...events.flatMap((e) => [`${stamp(e.at)} UTC`, ...e.lines.map((l) => (l.startsWith('    ') ? l : `  ${l}`)), ''])].join('\n');
}
