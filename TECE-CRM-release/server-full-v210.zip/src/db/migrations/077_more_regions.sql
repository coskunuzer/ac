-- More regions, so a longer firm list ("North Africa", "Far East", "South America" ...) is understood. A region that exists already is left alone.
INSERT OR IGNORE INTO ship_regions (name, countries, parts, aliases) VALUES
  ('Kuzey Afrika', '["TN","MA","DZ","EG","LY"]', '[]', '["north africa","kuzey afrika","maghreb","magrip"]'),
  ('Güney Amerika', '["CO","VE","BR","AR","CL","PE","EC","UY","PY","BO"]', '[]', '["south america","latin america","latin amerika"]'),
  ('Uzak Doğu', '["CN","TW","JP","KR","HK","SG","MY","TH","VN","ID","PH"]', '[]', '["far east","asia","asya","east asia"]'),
  ('İskandinavya', '["DK","SE","NO","FI"]', '[]', '["scandinavia","nordic","nordics","iskandinav"]'),
  ('Baltık', '["LT","LV","EE"]', '[]', '["baltic","baltics","baltik"]');
