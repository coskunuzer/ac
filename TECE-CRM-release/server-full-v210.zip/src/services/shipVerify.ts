import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { db } from '../db/connection';
import { env, paths } from '../config/env';
import { findForwarder, listForwarders } from './shipPlaces';
import { sendShipMail, shipConfig } from './shipMail';
import { fill, getTemplate } from './shipTemplates';

// Verifying the transport firms: ONE e-mail to every address of a firm (so we learn which address is right, and that our e-mail arrives), with the short video that
// shows how to answer a request. A firm confirms by clicking the link, by replying, or a person marks it after a phone call. Wrong addresses show as "failed".

const dir = () => path.join(paths.uploadsDir, '..', 'shipping');
export const videoFile = () => path.join(dir(), 'nakliye-video.mp4');
export function videoInfo(): { exists: boolean; size: number; at: string | null } {
  try { const s = fs.statSync(videoFile()); return { exists: true, size: s.size, at: s.mtime.toISOString() }; } catch { return { exists: false, size: 0, at: null }; }
}
export function saveVideo(buf: Buffer): void { fs.mkdirSync(dir(), { recursive: true }); fs.writeFileSync(videoFile(), buf); }

interface Ver { id: number; forwarder_id: number; email: string; status: string; sent_at: string | null; confirmed_at: string | null; confirmed_via: string | null; reply_from: string | null; error: string | null }
export interface FirmVerify { id: number; name: string; lang: string; active: boolean; confirmed: boolean; addresses: { email: string; status: 'none' | 'sent' | 'failed' | 'confirmed'; sentAt: string | null; confirmedAt: string | null; via: string | null; replyFrom: string | null; error: string | null }[] }

export function overview(): { video: ReturnType<typeof videoInfo>; firms: FirmVerify[]; testMode: boolean; testEmail: string; mailReady: boolean } {
  const rows = db.prepare('SELECT * FROM ship_verifications ORDER BY id').all() as unknown as Ver[];
  const last = new Map<string, Ver>();
  const confirmedKey = new Set<string>();
  for (const r of rows) { const k = `${r.forwarder_id}|${r.email}`; last.set(k, r); if (r.status === 'confirmed') confirmedKey.add(k); }
  const c = shipConfig();
  const firms = listForwarders().map((f) => {
    const addresses = f.emails.map((e) => {
      const k = `${f.id}|${e.toLowerCase()}`; const r = last.get(k);
      const confirmed = confirmedKey.has(k);
      const conf = confirmed ? rows.find((x) => `${x.forwarder_id}|${x.email}` === k && x.status === 'confirmed') : undefined;
      return { email: e, status: (confirmed ? 'confirmed' : r ? (r.status === 'failed' ? 'failed' : 'sent') : 'none') as FirmVerify['addresses'][number]['status'], sentAt: r?.sent_at ?? null, confirmedAt: conf?.confirmed_at ?? null, via: conf?.confirmed_via ?? null, replyFrom: conf?.reply_from ?? null, error: !confirmed && r?.status === 'failed' ? r.error : null };
    });
    return { id: f.id, name: f.name, lang: f.lang, active: f.active, confirmed: addresses.some((a) => a.status === 'confirmed'), addresses };
  });
  return { video: videoInfo(), firms, testMode: c.testMode, testEmail: c.testEmail, mailReady: !!c.user };
}

// ---- the text ---------------------------------------------------------------------------------------------------------------------------------------
export const confirmUrl = (token: string) => `${env.publicUrl}/api/ship-verify/${token}`;
export const videoUrl = (token: string) => `${env.publicUrl}/api/ship-verify/video/${token}`;
const code = (token: string) => `V-${token.slice(0, 8)}`;
export function mailText(firm: string, email: string, token: string, lang: string, attached: boolean): { subject: string; body: string } {
  const en = lang === 'en';
  const t = getTemplate('verify', lang);
  const video = attached ? '' : (en ? `\n\nThe 1-minute video: ${videoUrl(token)}` : `\n\n1 dakikalık video: ${videoUrl(token)}`);
  const vars = { firm, email, link: confirmUrl(token), videoWord: en ? (attached ? 'attached to this e-mail' : 'below') : (attached ? 'Ekteki' : 'Aşağıdaki'), video, code: `[${code(token)}]` };
  let subject = fill(t.subject ?? '', vars);
  if (!subject.includes(vars.code)) subject = `${subject} ${vars.code}`; // the code tells which e-mail a reply belongs to: it is always there
  return { subject, body: fill(t.body, vars) };
}

// ---- sending (a background job: one e-mail at a time) ---------------------------------------------------------------------------------------------------------
export interface Job { running: boolean; total: number; done: number; sent: number; failed: number; startedAt: string | null; finishedAt: string | null; batch: string | null }
const job: Job = { running: false, total: 0, done: 0, sent: 0, failed: 0, startedAt: null, finishedAt: null, batch: null };
export const jobStatus = (): Job => ({ ...job });
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export function startSending(userId: number, opts: { forwarderIds: number[]; attach: boolean; onlyUnconfirmed: boolean }): { ok: boolean; error?: string; total?: number } {
  if (job.running) return { ok: false, error: 'A sending is already running.' };
  if (opts.attach && !videoInfo().exists) return { ok: false, error: 'Upload the video first, or send it as a link.' };
  const ov = overview();
  const want = new Set(opts.forwarderIds);
  const pairs: { fw: number; name: string; lang: string; email: string }[] = [];
  for (const f of ov.firms) {
    if (!f.active || (want.size && !want.has(f.id))) continue;
    for (const a of f.addresses) { if (opts.onlyUnconfirmed && a.status === 'confirmed') continue; pairs.push({ fw: f.id, name: f.name, lang: f.lang, email: a.email }); }
  }
  if (!pairs.length) return { ok: false, error: 'Nothing to send: every address is confirmed or no firm is chosen.' };
  const batch = `B${new Date().toISOString().slice(0, 16).replace(/\D/g, '')}`;
  Object.assign(job, { running: true, total: pairs.length, done: 0, sent: 0, failed: 0, startedAt: new Date().toISOString(), finishedAt: null, batch });
  void (async () => {
    try {
      for (const p of pairs) {
        const token = crypto.randomBytes(16).toString('hex');
        const vid = Number(db.prepare('INSERT INTO ship_verifications (batch, forwarder_id, email, token, user_id) VALUES (?, ?, ?, ?, ?)').run(batch, p.fw, p.email.toLowerCase(), token, userId).lastInsertRowid);
        const t = mailText(p.name, p.email, token, p.lang, opts.attach);
        const res = await sendShipMail({ to: [p.email], subject: t.subject, body: t.body, kind: 'verify', forwarderId: p.fw, userId, attachments: opts.attach ? [{ filename: 'TECE-Nakliye-video.mp4', path: videoFile() }] : undefined });
        db.prepare("UPDATE ship_verifications SET status = ?, error = ?, message_id = ?, sent_at = CASE WHEN ? = 1 THEN datetime('now') ELSE NULL END WHERE id = ?").run(res.ok ? 'sent' : 'failed', res.ok ? null : (res.error ?? '').slice(0, 300), res.id, res.ok ? 1 : 0, vid);
        job.done++; if (res.ok) job.sent++; else job.failed++;
        await sleep(400);
      }
    } finally { job.running = false; job.finishedAt = new Date().toISOString(); }
  })();
  return { ok: true, total: pairs.length };
}

// ---- confirming ------------------------------------------------------------------------------------------------------------------------------------------
const logFirm = (fw: number, text: string, userId: number | null) => { const f = findForwarder(fw); db.prepare('INSERT INTO ship_firm_log (forwarder_id, name, action, snapshot, user_id) VALUES (?, ?, ?, ?, ?)').run(fw, f?.name ?? null, text, '{}', userId); };
export function confirmByToken(token: string, via: 'link' | 'reply' | 'manual', replyFrom: string | null = null, userId: number | null = null): { firm: string; lang: string } | null {
  const r = db.prepare('SELECT * FROM ship_verifications WHERE token = ?').get(token) as unknown as (Ver & { token: string }) | undefined;
  if (!r) return null;
  const f = findForwarder(r.forwarder_id);
  if (r.status !== 'confirmed') {
    db.prepare("UPDATE ship_verifications SET status = 'confirmed', confirmed_at = datetime('now'), confirmed_via = ?, reply_from = ? WHERE id = ?").run(via, replyFrom, r.id);
    logFirm(r.forwarder_id, `verified (${via}): ${r.email}${replyFrom ? ` - answered from ${replyFrom}` : ''}`, userId);
  }
  return { firm: f?.name ?? '', lang: f?.lang ?? 'tr' };
}
// a person marks an address as right (after a phone call, for example)
export function confirmManually(forwarderId: number, email: string, userId: number): boolean {
  const e = email.trim().toLowerCase();
  const r = db.prepare('SELECT token FROM ship_verifications WHERE forwarder_id = ? AND email = ? ORDER BY id DESC LIMIT 1').get(forwarderId, e) as { token: string } | undefined;
  if (r) return !!confirmByToken(r.token, 'manual', null, userId);
  const token = crypto.randomBytes(16).toString('hex');
  db.prepare("INSERT INTO ship_verifications (batch, forwarder_id, email, token, status, confirmed_at, confirmed_via, user_id) VALUES ('manual', ?, ?, ?, 'confirmed', datetime('now'), 'manual', ?)").run(forwarderId, e, token, userId);
  logFirm(forwarderId, `verified (manual): ${e}`, userId);
  return true;
}
// a reply to a verification e-mail: the code in the subject tells which one; the mailbox reading calls this
export function confirmByReply(subject: string, sender: string): boolean {
  const m = /\[V-([0-9a-f]{8})\]/i.exec(subject);
  if (!m) return false;
  const r = db.prepare("SELECT token, email FROM ship_verifications WHERE token LIKE ? || '%'").get(m[1].toLowerCase()) as { token: string; email: string } | undefined;
  if (!r) return false;
  confirmByToken(r.token, 'reply', sender.trim().toLowerCase() !== r.email ? sender.trim().toLowerCase() : null);
  return true;
}
export const tokenExists = (token: string): boolean => !!db.prepare('SELECT 1 FROM ship_verifications WHERE token = ?').get(token);
