-- The screen theme of a person: light, dark or auto (follows the computer).
ALTER TABLE users ADD COLUMN theme TEXT;
