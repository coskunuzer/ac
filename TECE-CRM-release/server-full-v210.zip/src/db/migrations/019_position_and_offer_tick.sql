-- The visitor's job title, and the tick "send this customer an offer" (NULL = not decided yet,
-- the AI's suggestion is shown; 1 = yes, 0 = no).
ALTER TABLE cards ADD COLUMN position TEXT;
ALTER TABLE cards ADD COLUMN send_offer INTEGER;

-- Badge imports used to keep the job title in the notes as a line "Role: ..." - move it to the new field.
UPDATE cards
   SET position = trim(
         CASE
           WHEN instr(substr(notes, instr(notes, 'Role: ') + 6), char(10)) > 0
             THEN substr(notes, instr(notes, 'Role: ') + 6, instr(substr(notes, instr(notes, 'Role: ') + 6), char(10)) - 1)
           ELSE substr(notes, instr(notes, 'Role: ') + 6)
         END)
 WHERE badge_id IS NOT NULL AND notes LIKE '%Role: %' AND position IS NULL;

UPDATE cards
   SET notes = nullif(trim(replace(replace(notes, char(10) || 'Role: ' || position, ''), 'Role: ' || position, '')), '')
 WHERE badge_id IS NOT NULL AND position IS NOT NULL AND notes LIKE '%Role: %';
