import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import nodemailer from 'nodemailer';
import { db } from '../db/connection';
import { env } from '../config/env';
import { settingsModel } from '../models/settingsModel';
import { cardModel } from '../models/cardModel';
import { setsFor } from './perfAnalytics';
import { isLang, LANGS, translateStrings, type Lang } from './translate';
import { htmlToPlain, mapTextNodes, sanitizeHtml, styleForEmail, textNodes } from './sanitizeHtml';
import { languageOf } from './offerLanguage';

// The customer newsletter. Who gets it is decided by rules (the "white list"), the HTML is built from a few blocks (new colours, colours removed, the decor
// list), and it goes out in small batches with a pause between them, so the mailbox is never flooded or blocked.

// `body` is the rich text (safe HTML: bold, lists, links, headings); the rest are the simple blocks
export interface NlContent { intro: string; body: string; added: string[]; removed: string[]; decorNote: string; decorUrl: string; closing: string }
export const emptyContent = (): NlContent => ({ intro: '', body: '', added: [], removed: [], decorNote: '', decorUrl: '', closing: '' });

const num = (k: string, d: number, min: number, max: number) => { const n = parseInt(settingsModel.get(k) ?? '', 10); return Number.isFinite(n) ? Math.max(min, Math.min(max, n)) : d; };
export const maxRecipients = () => num('newsletter_max', 250, 1, 1000);
export const dailyCap = () => num('newsletter_daily_cap', 250, 1, 2000);

const todayIso = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });
const daysSince = (iso: string | null) => (iso ? Math.round((Date.parse(todayIso()) - Date.parse(iso.slice(0, 10))) / 86_400_000) : null);

// ---- the white list --------------------------------------------------------------------------------------------------------------------------------
export interface AudienceRow {
  cardId: number | null; sap: string; company: string; country: string; email: string; lang: Lang;
  lastInvoice: string | null; ytd: number; currency: string; overdue: number; risk: string;
  eligible: boolean; reasons: string[]; override: 'include' | 'exclude' | null; overLimit: boolean;
}
const validMail = (s: string | null | undefined) => !!s && /^[^\s@,;]+@[^\s@,;]+\.[^\s@,;]+$/.test(s.trim());

// A customer is on the list when: it bought in the last 24 months, it pays (no hold, not a black account, nothing more than 60 days overdue), it has an
// e-mail address and did not unsubscribe. The person in charge can put a customer in or out by hand. At most `maxRecipients` customers (the biggest first).
export function audience(): AudienceRow[] {
  const admin = { id: 0, role: 'admin', display_name: null as string | null };
  const accounts = setsFor(admin, null).live;
  const optout = new Set((db.prepare('SELECT email FROM newsletter_optout').all() as { email: string }[]).map((r) => r.email.toLowerCase()));
  const overrides = new Map((db.prepare('SELECT card_id, mode FROM newsletter_overrides').all() as { card_id: number; mode: 'include' | 'exclude' }[]).map((r) => [r.card_id, r.mode]));
  const rows: AudienceRow[] = [];
  const seenCards = new Set<number>();
  const mailOf = (cardId: number): string => {
    const c = cardModel.findById(cardId);
    if (validMail(c?.email)) return c!.email!.trim();
    const x = db.prepare("SELECT email FROM card_contacts WHERE card_id = ? AND email LIKE '%@%' ORDER BY id LIMIT 1").get(cardId) as { email: string } | undefined;
    return x?.email?.trim() ?? '';
  };
  const build = (a: { sap: string; name: string; country: string; cardId: number | null; lastInvoice: string | null; ytd: number; currency: string; overdue: number; oldestOver: number; hold: boolean; riskLevel: string }, base: boolean): void => {
    if (!a.cardId) {
      const why = ['Not in the CRM yet (no e-mail address)'];
      if (!base) return;
      rows.push({ cardId: null, sap: a.sap, company: a.name, country: a.country, email: '', lang: 'en', lastInvoice: a.lastInvoice, ytd: a.ytd, currency: a.currency, overdue: a.overdue, risk: a.riskLevel, eligible: false, reasons: why, override: null, overLimit: false });
      return;
    }
    if (seenCards.has(a.cardId)) return;
    seenCards.add(a.cardId);
    const card = cardModel.findById(a.cardId);
    if (!card) return;
    const email = mailOf(a.cardId);
    const reasons: string[] = [];
    const idle = daysSince(a.lastInvoice);
    if (base) {
      if (idle === null || idle > 730) reasons.push('No order in the last 2 years');
      if (a.hold) reasons.push('Debt hold');
      if (a.riskLevel === 'black') reasons.push('Black account (pays very late)');
      if (a.oldestOver > 60) reasons.push(`Has a payment ${Math.round(a.oldestOver)} days overdue`);
    } else reasons.push('No payment data (only by hand)');
    if (!email) reasons.push('No e-mail address');
    const opted = !!email && optout.has(email.toLowerCase());
    if (opted) reasons.push('Unsubscribed');
    const ov = overrides.get(a.cardId) ?? null;
    if (ov === 'exclude') reasons.unshift('Taken out by hand');
    let eligible = reasons.length === 0;
    // by hand "in" beats the rules, but never a missing address or an unsubscribe
    if (ov === 'include' && email && !opted) { eligible = true; }
    if (ov === 'exclude') eligible = false;
    rows.push({ cardId: a.cardId, sap: a.sap, company: card.company || card.name || a.name, country: (card.market === 'domestic' ? card.city : card.country) ?? a.country ?? '', email, lang: card.market === 'domestic' ? 'tr' : languageOf(card),
      lastInvoice: a.lastInvoice, ytd: a.ytd, currency: a.currency, overdue: a.overdue, risk: a.riskLevel, eligible, reasons: eligible ? (ov === 'include' ? ['Put in by hand'] : []) : reasons, override: ov, overLimit: false });
  };
  for (const a of accounts) build({ sap: a.sap, name: a.name, country: a.country, cardId: a.cardId, lastInvoice: a.lastInvoice, ytd: a.ytd, currency: a.currency, overdue: a.overdue, oldestOver: a.oldestOver, hold: a.hold, riskLevel: a.risk.level }, true);
  // customers put in by hand that have no ledger (the domestic ones)
  for (const [cardId, mode] of overrides) if (mode === 'include' && !seenCards.has(cardId)) { const c = cardModel.findById(cardId); if (c) build({ sap: c.sap ?? '', name: c.company ?? '', country: c.country ?? '', cardId, lastInvoice: null, ytd: 0, currency: 'EUR', overdue: 0, oldestOver: 0, hold: false, riskLevel: 'good' }, false); }
  rows.sort((x, y) => Number(y.eligible) - Number(x.eligible) || y.ytd - x.ytd || x.company.localeCompare(y.company));
  let n = 0; const cap = maxRecipients();
  for (const r of rows) if (r.eligible) { n += 1; if (n > cap) { r.eligible = false; r.overLimit = true; r.reasons = [`Over the limit of ${cap} customers`]; } }
  return rows;
}

// ---- the HTML ---------------------------------------------------------------------------------------------------------------------------------------------
const T: Record<Lang, { added: string; removed: string; decor: string; open: string; hello: string; why: string; unsub: string; sent: string }> = {
  en: { added: 'New colours', removed: 'Colours removed from the range', decor: 'Decor list updated', open: 'Open the decor list', hello: 'Dear', why: 'You get this e-mail because you are a TECE customer.', unsub: 'Unsubscribe', sent: 'Sent by TECE Dekor' },
  tr: { added: 'Yeni renkler', removed: 'Koleksiyondan çıkan renkler', decor: 'Dekor listesi güncellendi', open: 'Dekor listesini aç', hello: 'Sayın', why: 'Bu e-postayı TECE müşterisi olduğunuz için alıyorsunuz.', unsub: 'Listeden çık', sent: 'TECE Dekor tarafından gönderildi' },
  ru: { added: 'Новые цвета', removed: 'Цвета, снятые с производства', decor: 'Каталог декоров обновлён', open: 'Открыть каталог декоров', hello: 'Уважаемый(ая)', why: 'Вы получили это письмо, так как являетесь клиентом TECE.', unsub: 'Отписаться', sent: 'Отправлено TECE Dekor' },
  es: { added: 'Colores nuevos', removed: 'Colores retirados de la gama', decor: 'Lista de decorados actualizada', open: 'Abrir la lista de decorados', hello: 'Estimado/a', why: 'Recibe este correo porque es cliente de TECE.', unsub: 'Darse de baja', sent: 'Enviado por TECE Dekor' },
  fr: { added: 'Nouvelles couleurs', removed: 'Couleurs retirées de la gamme', decor: 'Liste des décors mise à jour', open: 'Ouvrir la liste des décors', hello: 'Cher/Chère', why: 'Vous recevez cet e-mail car vous êtes client de TECE.', unsub: 'Se désabonner', sent: 'Envoyé par TECE Dekor' },
};
const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const para = (s: string) => esc(s).replace(/\n/g, '<br>');
const HEADER = path.join(__dirname, '..', '..', 'assets', 'letterhead-header.png');

export function renderHtml(c: NlContent, lang: Lang, o: { name?: string; unsubUrl: string; headerSrc: string; preview?: boolean }): string {
  const t = T[lang] ?? T.en;
  const NAVY = '#17243E'; const RED = '#8B1931'; const STEEL = '#5E6676'; const MIST = '#F3F4F7';
  const list = (items: string[]) => `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 4px">${items.filter(Boolean).map((i) => `<tr><td style="padding:7px 0;border-bottom:1px solid #E3E6EC;font-size:15px;color:${NAVY}">${esc(i)}</td></tr>`).join('')}</table>`;
  const section = (title: string, inner: string) => `<tr><td style="padding:22px 32px 0"><div style="font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:${STEEL};padding-bottom:6px;border-bottom:2px solid ${NAVY}">${esc(title)}</div><div style="padding-top:8px">${inner}</div></td></tr>`;
  const added = c.added.filter(Boolean); const removed = c.removed.filter(Boolean);
  return `<!doctype html><html lang="${lang}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TECE</title></head>
<body style="margin:0;padding:0;background:${MIST};font-family:Montserrat,Arial,Helvetica,sans-serif;color:${NAVY}">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:${MIST}"><tr><td align="center" style="padding:20px 10px">
<table role="presentation" width="600" cellpadding="0" cellspacing="0" style="width:100%;max-width:600px;background:#fff">
<tr><td style="padding:0"><img src="${o.headerSrc}" width="600" alt="TECE - The Edgebanding Company" style="display:block;width:100%;height:auto;border:0"></td></tr>
<tr><td style="padding:26px 32px 0;font-size:16px;line-height:1.6;color:${NAVY}">${o.name ? `<p style="margin:0 0 12px;font-weight:600">${esc(t.hello)} ${esc(o.name)},</p>` : ''}${c.intro ? `<p style="margin:0">${para(c.intro)}</p>` : ''}</td></tr>
${c.body ? `<tr><td style="padding:14px 32px 0;font-size:15px;line-height:1.6;color:${NAVY}">${styleForEmail(sanitizeHtml(c.body), { navy: NAVY, red: RED })}</td></tr>` : ''}
${added.length ? section(t.added, list(added)) : ''}
${removed.length ? section(t.removed, list(removed)) : ''}
${c.decorNote || c.decorUrl ? section(t.decor, `${c.decorNote ? `<p style="margin:0 0 12px;font-size:15px;line-height:1.6">${para(c.decorNote)}</p>` : ''}${c.decorUrl ? `<a href="${esc(c.decorUrl)}" style="display:inline-block;background:${RED};color:#fff;text-decoration:none;font-weight:600;font-size:14px;padding:12px 26px;border-radius:999px">${esc(t.open)}</a>` : ''}`) : ''}
${c.closing ? `<tr><td style="padding:24px 32px 0;font-size:15px;line-height:1.6">${para(c.closing)}</td></tr>` : ''}
<tr><td style="padding:28px 32px 26px"><div style="height:4px;background:${RED};width:60px"></div></td></tr>
<tr><td style="padding:0 32px 26px;font-size:12px;line-height:1.6;color:${STEEL}">${esc(t.why)} ${o.preview ? `<u>${esc(t.unsub)}</u>` : `<a href="${esc(o.unsubUrl)}" style="color:${STEEL}">${esc(t.unsub)}</a>`}<br>${esc(t.sent)} · tece.com.tr</td></tr>
</table></td></tr></table></body></html>`;
}
export function renderText(c: NlContent, lang: Lang, name: string, unsubUrl: string): string {
  const t = T[lang] ?? T.en;
  return [name ? `${t.hello} ${name},` : '', c.intro, c.body ? htmlToPlain(sanitizeHtml(c.body)) : '', c.added.filter(Boolean).length ? `\n${t.added}:\n${c.added.filter(Boolean).map((x) => `- ${x}`).join('\n')}` : '', c.removed.filter(Boolean).length ? `\n${t.removed}:\n${c.removed.filter(Boolean).map((x) => `- ${x}`).join('\n')}` : '',
    c.decorNote || c.decorUrl ? `\n${t.decor}: ${[c.decorNote, c.decorUrl].filter(Boolean).join(' ')}` : '', c.closing ? `\n${c.closing}` : '', `\n--\n${t.why}\n${t.unsub}: ${unsubUrl}`].filter((x) => x !== '').join('\n');
}
export const headerDataUri = (): string => { try { return `data:image/png;base64,${fs.readFileSync(HEADER).toString('base64')}`; } catch { return ''; } };

// ---- files attached to a campaign (a PDF catalogue ...): they go with every e-mail ----------------------------------------------------------------------
export const filesDir = path.resolve(__dirname, '../../data/newsletter');
export interface NlFile { id: number; newsletter_id: number; original_name: string; stored_name: string; size: number }
export const filesOf = (id: number) => db.prepare('SELECT * FROM newsletter_files WHERE newsletter_id = ? ORDER BY id').all(id) as unknown as NlFile[];

// ---- the content of a campaign in a language -----------------------------------------------------------------------------------------------------------
export interface Campaign { id: number; title: string; subject: string; content_json: string; content_tr_json: string | null; translations_json: string | null; status: string; batch_size: number; interval_min: number; last_batch_at: string | null; note: string | null; created_by: number | null; created_at: string; started_at: string | null; finished_at: string | null }
const parse = <T,>(s: string | null | undefined, fb: T): T => { try { return s ? (JSON.parse(s) as T) : fb; } catch { return fb; } };
export const campaignOf = (id: number) => db.prepare('SELECT * FROM newsletters WHERE id = ?').get(id) as Campaign | undefined;

type Texts = { subject: string; intro: string; body: string; decorNote: string; closing: string };
export function contentFor(c: Campaign, lang: Lang): { subject: string; content: NlContent } {
  const en = { ...emptyContent(), ...parse<Partial<NlContent>>(c.content_json, {}) };
  if (lang === 'en') return { subject: c.subject, content: en };
  const tr = parse<(Partial<NlContent> & { subject?: string }) | null>(c.content_tr_json, null);
  if (lang === 'tr' && tr && (tr.intro || tr.subject)) return { subject: tr.subject || c.subject, content: { ...en, ...tr, added: tr.added?.length ? tr.added : en.added, removed: tr.removed?.length ? tr.removed : en.removed } };
  const tx = parse<Record<string, Partial<Texts>>>(c.translations_json, {})[lang];
  if (!tx) return { subject: c.subject, content: en };
  return { subject: tx.subject || c.subject, content: { ...en, intro: tx.intro ?? en.intro, body: tx.body ?? en.body, decorNote: tx.decorNote ?? en.decorNote, closing: tx.closing ?? en.closing } };
}
// the AI translates the texts that were written (colour names stay as they are), once, when the campaign starts
export async function prepareTranslations(c: Campaign, langs: Lang[]): Promise<void> {
  const en = { ...emptyContent(), ...parse<Partial<NlContent>>(c.content_json, {}) };
  const saved = parse<Record<string, Partial<Texts>>>(c.translations_json, {});
  for (const lang of langs) {
    if (lang === 'en' || (lang === 'tr' && c.content_tr_json) || saved[lang]) continue;
    const src = [c.subject, en.intro, en.decorNote, en.closing];
    try {
      const m = await translateStrings(src.filter(Boolean), lang);
      const clean = sanitizeHtml(en.body);
      const nodes = clean ? await translateStrings(textNodes(clean), lang) : new Map<string, string>();
      saved[lang] = { subject: m.get(c.subject) ?? c.subject, intro: m.get(en.intro) ?? en.intro, body: clean ? mapTextNodes(clean, (t) => nodes.get(t.trim()) ?? t) : '', decorNote: m.get(en.decorNote) ?? en.decorNote, closing: m.get(en.closing) ?? en.closing };
    } catch { /* stays English */ }
  }
  db.prepare('UPDATE newsletters SET translations_json = ? WHERE id = ?').run(JSON.stringify(saved), c.id);
}

// ---- unsubscribe -----------------------------------------------------------------------------------------------------------------------------------------------
const sign = (email: string) => crypto.createHmac('sha256', env.jwtSecret).update(`nl:${email.toLowerCase()}`).digest('hex').slice(0, 24);
export const unsubUrl = (email: string) => `${env.publicUrl}/api/newsletter-public/unsubscribe?e=${Buffer.from(email.toLowerCase()).toString('base64url')}&t=${sign(email)}`;
export function unsubscribe(e: string, t: string, via = 'link'): boolean {
  let email = '';
  try { email = Buffer.from(e, 'base64url').toString('utf8'); } catch { return false; }
  if (!validMail(email) || sign(email) !== t) return false;
  const card = db.prepare("SELECT id FROM cards WHERE LOWER(email) = ? LIMIT 1").get(email.toLowerCase()) as { id: number } | undefined;
  db.prepare('INSERT OR REPLACE INTO newsletter_optout (email, card_id, via) VALUES (?, ?, ?)').run(email.toLowerCase(), card?.id ?? null, via);
  return true;
}

// ---- sending: small batches, a pause between them ------------------------------------------------------------------------------------------------------
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
export const smtpReady = () => !!(env.smtp.host && env.smtp.user && env.smtp.password);
const transport = () => nodemailer.createTransport({ host: env.smtp.host, port: env.smtp.port, secure: env.smtp.port === 465, auth: { user: env.smtp.user, pass: env.smtp.password } });

export async function sendOne(c: Campaign, to: { email: string; name: string; lang: Lang }, opts: { testTag?: boolean; transport?: nodemailer.Transporter } = {}): Promise<void> {
  const { subject, content } = contentFor(c, to.lang);
  const url = unsubUrl(to.email);
  const html = renderHtml(content, to.lang, { name: to.name, unsubUrl: url, headerSrc: 'cid:tecehead' });
  const text = renderText(content, to.lang, to.name, url);
  const tp = opts.transport ?? transport();
  await tp.sendMail({
    from: env.smtp.from || env.smtp.user, to: to.email, subject: `${opts.testTag ? '[TEST] ' : ''}${subject}`, text, html,
    headers: { 'List-Unsubscribe': `<${url}>`, 'List-Unsubscribe-Post': 'List-Unsubscribe=One-Click', 'Precedence': 'bulk' },
    attachments: [...(fs.existsSync(HEADER) ? [{ filename: 'tece.png', path: HEADER, cid: 'tecehead' }] : []), ...filesOf(c.id).map((f) => ({ filename: f.original_name, path: path.join(filesDir, String(c.id), path.basename(f.stored_name)) }))],
  });
}

const sentToday = () => (db.prepare("SELECT COUNT(*) AS n FROM newsletter_recipients WHERE status = 'sent' AND substr(sent_at, 1, 10) = ?").get(todayIso()) as { n: number }).n;
let running = false;

// one batch of one campaign
export async function runBatch(id: number): Promise<{ sent: number; failed: number; left: number; note?: string }> {
  const c = campaignOf(id);
  if (!c || c.status !== 'sending') return { sent: 0, failed: 0, left: 0, note: 'Not sending.' };
  if (running) return { sent: 0, failed: 0, left: 0, note: 'Another batch is running.' };
  running = true;
  try {
    if (settingsModel.get('test_mode') === '1') { db.prepare("UPDATE newsletters SET status = 'paused', note = ? WHERE id = ?").run('Test mode is on: switch it off to send.', id); return { sent: 0, failed: 0, left: 0, note: 'Test mode is on.' }; }
    if (!smtpReady()) { db.prepare("UPDATE newsletters SET status = 'paused', note = ? WHERE id = ?").run('The mail server (SMTP) is not set up.', id); return { sent: 0, failed: 0, left: 0, note: 'SMTP is not set up.' }; }
    const room = Math.max(0, dailyCap() - sentToday());
    const take = Math.min(c.batch_size, room);
    if (take <= 0) { db.prepare("UPDATE newsletters SET note = ?, last_batch_at = datetime('now') WHERE id = ?").run(`Daily limit of ${dailyCap()} reached: it goes on tomorrow.`, id); return { sent: 0, failed: 0, left: 0, note: 'Daily limit.' }; }
    const rows = db.prepare("SELECT * FROM newsletter_recipients WHERE newsletter_id = ? AND status = 'queued' ORDER BY id LIMIT ?").all(id, take) as { id: number; card_id: number | null; company: string | null; email: string; lang: string }[];
    const tp = transport();
    let sent = 0; let failed = 0; let streak = 0;
    const optout = new Set((db.prepare('SELECT email FROM newsletter_optout').all() as { email: string }[]).map((r) => r.email));
    for (const r of rows) {
      if (optout.has(r.email.toLowerCase())) { db.prepare("UPDATE newsletter_recipients SET status = 'failed', error = 'Unsubscribed meanwhile' WHERE id = ?").run(r.id); continue; }
      try {
        const lang = isLang(r.lang) ? r.lang : 'en';
        await sendOne(c, { email: r.email, name: '', lang }, { transport: tp });
        db.prepare("UPDATE newsletter_recipients SET status = 'sent', sent_at = datetime('now'), error = NULL WHERE id = ?").run(r.id);
        db.prepare("INSERT INTO sent_emails (card_id, user_id, kind, internal, to_addr, subject, body) VALUES (?, ?, 'newsletter', 0, ?, ?, ?)").run(r.card_id, c.created_by, r.email, contentFor(c, lang).subject, `Newsletter: ${c.title}`);
        sent += 1; streak = 0;
      } catch (err) {
        db.prepare("UPDATE newsletter_recipients SET status = 'failed', error = ? WHERE id = ?").run((err as Error).message.slice(0, 200), r.id);
        failed += 1; streak += 1;
        // three failures in a row: something is wrong with the mailbox - stop and let a person look
        if (streak >= 3) { db.prepare("UPDATE newsletters SET status = 'paused', note = ? WHERE id = ?").run(`Stopped after 3 failures in a row: ${(err as Error).message.slice(0, 120)}`, id); break; }
      }
      await sleep(1500);
    }
    const left = (db.prepare("SELECT COUNT(*) AS n FROM newsletter_recipients WHERE newsletter_id = ? AND status = 'queued'").get(id) as { n: number }).n;
    db.prepare("UPDATE newsletters SET last_batch_at = datetime('now') WHERE id = ?").run(id);
    if (left === 0 && campaignOf(id)?.status === 'sending') db.prepare("UPDATE newsletters SET status = 'done', finished_at = datetime('now') WHERE id = ?").run(id);
    return { sent, failed, left };
  } finally { running = false; }
}

export function startNewsletterScheduler(): void {
  const tick = () => {
    const list = db.prepare("SELECT * FROM newsletters WHERE status = 'sending'").all() as unknown as Campaign[];
    for (const c of list) {
      const waited = c.last_batch_at ? (Date.now() - Date.parse(`${c.last_batch_at.replace(' ', 'T')}Z`)) / 60_000 : 1e9;
      if (waited >= c.interval_min) void runBatch(c.id).catch((e) => console.error('Newsletter batch failed:', e));
    }
  };
  setInterval(tick, 60_000);
}
export const langName = (l: string) => LANGS[l as Lang] ?? l;
