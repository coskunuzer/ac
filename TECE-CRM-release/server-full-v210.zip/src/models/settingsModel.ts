import { db } from '../db/connection';
import { memoTables } from '../db/dataVersion';

// read on almost every request (AI switches, price settings, texts): one read of the small table, kept until it is written to
const keptSettings = memoTables(['app_settings'], () => new Map((db.prepare('SELECT key, value FROM app_settings').all() as unknown as { key: string; value: string | null }[]).map((r) => [r.key, r.value])));

// Small company-wide settings (for example the default signature layout).
export const settingsModel = {
  get(key: string): string | null {
    return keptSettings().get(key) ?? null;
  },

  set(key: string, value: string): void {
    db.prepare(
      'INSERT INTO app_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value'
    ).run(key, value);
  },
};
