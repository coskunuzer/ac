import PDFDocument from 'pdfkit';
import { drawLogo, registerDesignFonts } from './priceBook/designed';

// The domestic (Turkey) PVC price lists A, B and C of 23.03.2026. A customer is fixed to one of the three; the discount (or addition) is typed on top.
// Prices are in euro per running metre (m.tül) and per m², without VAT. Only these products are sold on the domestic lists.

export type Tier = 'A' | 'B' | 'C';
export const TIERS: Tier[] = ['A', 'B', 'C'];
export const LIST_DATE = '23.03.2026';

interface Cell { mt: number; m2: number }
export interface PriceRow { finish: 'Düz' | 'Desenli'; pvc: Cell; hg: Cell }
export interface Thickness { mm: string; roll: string; box: string; rows: PriceRow[] }
export interface PriceList { tier: Tier; date: string; thicknesses: Thickness[]; metalMirror: number }

const t = (mm: string, roll: string, box: string, rows: [number, number, number, number, number, number, number, number][]): Thickness => ({
  mm, roll, box,
  rows: rows.map((r, i) => ({ finish: i === 0 ? 'Düz' : 'Desenli', pvc: { mt: r[0], m2: r[1] }, hg: { mt: r[2], m2: r[3] } })),
});
// [pvc m.tül, pvc m², hg m.tül, hg m²] for plain (Düz) and patterned (Desenli)
const row = (a: number, b: number, c: number, d: number): [number, number, number, number] => [a, b, c, d];
const mk = (rows: [number, number, number, number][]): [number, number, number, number, number, number, number, number][] => rows.map((r) => [r[0], r[1], r[2], r[3], 0, 0, 0, 0]);

const LISTS: Record<Tier, PriceList> = {
  A: { tier: 'A', date: LIST_DATE, metalMirror: 0.432, thicknesses: [
    t('0,40 mm', '300 metre', '7 rulo', mk([row(0.048, 2.1816, 0.0552, 2.508), row(0.0576, 2.617, 0.0648, 2.945)])),
    t('0,80 mm', '150 metre', '7 rulo', mk([row(0.096, 4.3632, 0.1104, 5.016), row(0.1152, 5.235, 0.1296, 5.89)])),
    t('2 mm', '100 metre', '5 rulo', mk([row(0.2112, 9.6, 0.2544, 11.55), row(0.2735, 12.43, 0.306, 13.909)])),
  ] },
  B: { tier: 'B', date: LIST_DATE, metalMirror: 0.456, thicknesses: [
    t('0,40 mm', '300 metre', '7 rulo', mk([row(0.0504, 2.29, 0.058, 2.63), row(0.06, 2.727, 0.0684, 3.109)])),
    t('0,80 mm', '150 metre', '7 rulo', mk([row(0.1008, 4.581, 0.116, 5.27), row(0.12, 5.454, 0.1368, 6.218)])),
    t('2 mm', '100 metre', '5 rulo', mk([row(0.222, 10.09, 0.2676, 12.16), row(0.288, 13.09, 0.3216, 14.61)])),
  ] },
  C: { tier: 'C', date: LIST_DATE, metalMirror: 0.48, thicknesses: [
    t('0,40 mm', '300 metre', '7 rulo', mk([row(0.0528, 2.4, 0.0612, 2.781), row(0.0636, 2.89, 0.072, 3.272)])),
    t('0,80 mm', '150 metre', '7 rulo', mk([row(0.1056, 4.8, 0.1224, 5.563), row(0.1272, 5.781, 0.144, 6.5448)])),
    t('2 mm', '100 metre', '5 rulo', mk([row(0.2316, 10.52, 0.2796, 12.7), row(0.3, 13.63, 0.336, 15.272)])),
  ] },
};
export const priceList = (tier: Tier): PriceList => LISTS[tier];
export const asTier = (v: unknown): Tier | null => (v === 'A' || v === 'B' || v === 'C' ? v : null);

// the discount is typed as a percentage: -10 = ten percent off, +5 = five percent more (the same way as on the export offers)
const factor = (pct: number) => 1 + pct / 100;
const r = (n: number, d: number) => Math.round(n * 10 ** d) / 10 ** d;
export const netCell = (c: Cell, pct: number): Cell => ({ mt: r(c.mt * factor(pct), 4), m2: r(c.m2 * factor(pct), 3) });
export const netMetal = (n: number, pct: number): number => r(n * factor(pct), 4);

const NAVY = '#17243E';
const RED = '#8B1931';
const STEEL = '#5E6676';
const LINE = '#E3E6EC';
const num = (n: number, d: number) => n.toLocaleString('tr-TR', { minimumFractionDigits: d, maximumFractionDigits: d });

export interface OfferFor { company: string; contact: string; preparedBy: string }

// the price list of the tier as a PDF: A4 portrait, TECE navy band, the three thicknesses, plain and patterned, PVC and high gloss
export async function renderDomesticOfferPdf(tier: Tier, pct: number, who: OfferFor): Promise<Buffer> {
  const list = LISTS[tier];
  const doc = new PDFDocument({ size: 'A4', margin: 0, info: { Title: 'TECE PVC fiyat listesi', Author: 'TECE' } });
  registerDesignFonts(doc);
  const chunks: Buffer[] = [];
  doc.on('data', (c: Buffer) => chunks.push(c));
  const done = new Promise<Buffer>((res) => doc.on('end', () => res(Buffer.concat(chunks))));
  const W = 595; const M = 36;
  doc.rect(0, 0, W, 70).fill(NAVY);
  drawLogo(doc, 'TECE_SloganliLogo_Beyaz_RGB.svg', M, 20, 190);
  doc.fillColor('#FFFFFF').font('TD-600').fontSize(14).text('PVC fiyat listesi', M, 20, { width: W - 2 * M, align: 'right' });
  doc.font('TD-400').fontSize(9).text(list.date, M, 40, { width: W - 2 * M, align: 'right' });

  let y = 92;
  doc.fillColor(NAVY).font('TD-600').fontSize(11).text(who.company || '', M, y, { lineBreak: false });
  doc.rect(M, y + 17, Math.min(260, doc.widthOfString(who.company || '') || 40), 1.6).fill(RED);
  y += 30;
  doc.fillColor(STEEL).font('TD-400').fontSize(8.5).text([who.contact ? `İlgili: ${who.contact}` : '', `Hazırlayan: ${who.preparedBy}`].filter(Boolean).join('   ·   '), M, y, { lineBreak: false });
  y += 22;
  if (pct) {
    doc.fillColor(NAVY).font('TD-600').fontSize(9).text(`${pct < 0 ? 'İskonto' : 'İlave'}: % ${num(Math.abs(pct), 1)} uygulanmıştır. Aşağıdaki fiyatlar net fiyatlardır.`, M, y, { lineBreak: false });
    y += 20;
  }

  const widths = [88, 62, 62, 62, 62, 60, 60];
  const head = ['', 'PVC m.tül', 'PVC m²', 'HG PVC m.tül', 'HG PVC m²', 'Rulo', 'Koli'];
  const total = widths.reduce((a, b) => a + b, 0);
  for (const th of list.thicknesses) {
    doc.fillColor(NAVY).font('TD-700').fontSize(10).text(`${th.mm} PVC kenar bantları`, M, y, { lineBreak: false });
    y += 16;
    let x = M;
    head.forEach((h, i) => { doc.fillColor(STEEL).font('TD-600').fontSize(7).text(h.toUpperCase(), x + 4, y + 2, { width: widths[i] - 8, align: i === 0 ? 'left' : 'right', lineBreak: false }); x += widths[i]; });
    doc.moveTo(M, y + 14).lineTo(M + total, y + 14).lineWidth(1).strokeColor(NAVY).stroke();
    y += 18;
    th.rows.forEach((rw) => {
      const p = netCell(rw.pvc, pct); const h = netCell(rw.hg, pct);
      const cells = [`22 mm ${rw.finish}`, num(p.mt, 4), num(p.m2, 3), num(h.mt, 4), num(h.m2, 3), th.roll, th.box];
      let xx = M;
      cells.forEach((c, i) => { doc.fillColor(NAVY).font(i === 0 ? 'TD-600' : 'TD-400').fontSize(9).text(c, xx + 4, y + 4, { width: widths[i] - 8, align: i === 0 ? 'left' : 'right', lineBreak: false }); xx += widths[i]; });
      doc.moveTo(M, y + 20).lineTo(M + total, y + 20).lineWidth(0.5).strokeColor(LINE).stroke();
      y += 22;
    });
    y += 12;
  }
  doc.fillColor(NAVY).font('TD-600').fontSize(9).text(`22 mm Metal / Ayna fiyatı: ${num(netMetal(list.metalMirror, pct), 3)} Euro + KDV`, M, y, { lineBreak: false });
  y += 28;
  doc.fillColor(STEEL).font('TD-400').fontSize(8);
  for (const n of [
    '* 22 mm harici ürünlerde %10 özel ölçü fiyat farkı uygulanacaktır.',
    '** Fiyatlar Euro cinsindendir ve KDV dahil değildir.',
    '*** 0,40 ve 0,80 mm için koli rulo adetleri: 33 mm 5 rulo, 44 mm 4 rulodur.',
    '**** 2 mm için koli rulo adetleri: 33 mm 3 rulo, 42 mm 2 rulodur.',
  ]) { doc.text(n, M, y, { width: W - 2 * M }); y += 13; }
  doc.moveTo(M, 800).lineTo(W - M, 800).lineWidth(0.4).strokeColor(LINE).stroke();
  doc.fillColor(STEEL).font('TD-400').fontSize(7).text('TECE · The Edgebanding Company', M, 806, { lineBreak: false });
  doc.end();
  return done;
}
