import { Router } from 'express';
import { db } from '../db/connection';
import { requireAdmin, requireAuth } from '../middleware/auth';
import { renderTablePdf, type PdfSection } from '../services/tablePdf';

// Admin only: what each employee did, day by day, in detail (notes, meetings, e-mails sent, customers added). Times are Turkish time.
const router = Router();
router.use(requireAuth, requireAdmin);

const day = (v: unknown, fallback: string) => (/^\d{4}-\d{2}-\d{2}$/.test(String(v ?? '')) ? String(v) : fallback);
const trCol = (c: string) => `datetime(${c}, '+3 hours')`;
const todayTr = () => new Date(Date.now() + 3 * 3600000).toISOString().slice(0, 10);

interface Act { user_id: number; at: string; type: string; company: string | null; text: string | null }
interface Mail { user_id: number; at: string; kind: string; company: string | null; to_addr: string | null; subject: string | null; attachments: string | null }
interface NewCard { user_id: number; at: string; company: string | null; country: string | null }

function collect(from: string, to: string, userId: number | null) {
  const range = (col: string) => `date(${trCol(col)}) >= ? AND date(${trCol(col)}) <= ?`;
  const u = (col: string) => (userId ? ` AND ${col} = ${Math.trunc(userId)}` : '');
  const acts = db.prepare(`SELECT a.user_id, ${trCol('a.created_at')} AS at, a.type, c.company AS company, a.text FROM activities a LEFT JOIN cards c ON c.id = a.card_id WHERE ${range('a.created_at')}${u('a.user_id')} ORDER BY a.created_at`).all(from, to) as unknown as Act[];
  const mails = db.prepare(`SELECT m.user_id, ${trCol('m.sent_at')} AS at, m.kind, c.company AS company, m.to_addr, m.subject, m.attachments FROM sent_emails m LEFT JOIN cards c ON c.id = m.card_id WHERE m.internal = 0 AND ${range('m.sent_at')}${u('m.user_id')} ORDER BY m.sent_at`).all(from, to) as unknown as Mail[];
  const added = db.prepare(`SELECT c.uploaded_by AS user_id, ${trCol('c.created_at')} AS at, c.company, c.country FROM cards c WHERE ${range('c.created_at')}${u('c.uploaded_by')} ORDER BY c.created_at`).all(from, to) as unknown as NewCard[];
  const users = db.prepare('SELECT id, COALESCE(display_name, username) AS name FROM users WHERE is_active = 1 ORDER BY name').all() as unknown as { id: number; name: string }[];
  return { acts, mails, added, users: userId ? users.filter((x) => x.id === userId) : users };
}

router.get('/', (req, res) => {
  const from = day(req.query.from, todayTr()), to = day(req.query.to, from);
  const d = collect(from, to, Number(req.query.user) || null);
  res.json({ from, to, people: d.users.map((p) => ({ id: p.id, name: p.name, activities: d.acts.filter((a) => a.user_id === p.id).length, emails: d.mails.filter((m) => m.user_id === p.id).length, newCustomers: d.added.filter((a) => a.user_id === p.id).length })) });
});

router.get('/pdf', async (req, res) => {
  const from = day(req.query.from, todayTr()), to = day(req.query.to, from);
  const uid = Number(req.query.user) || null;
  const d = collect(from, to, uid);
  const clip = (s: string | null, n: number) => { const t = (s ?? '').replace(/\s+/g, ' ').trim(); return t.length > n ? `${t.slice(0, n - 1)}…` : t; };
  const people = d.users.map((p) => ({ p, a: d.acts.filter((x) => x.user_id === p.id), m: d.mails.filter((x) => x.user_id === p.id), n: d.added.filter((x) => x.user_id === p.id) }));
  const sections: PdfSection[] = [{
    heading: 'Summary', columns: [{ label: 'Employee', w: 200 }, { label: 'Notes, calls, meetings', w: 110, right: true }, { label: 'E-mails sent', w: 90, right: true }, { label: 'New customers', w: 90, right: true }],
    rows: people.map(({ p, a, m, n }) => [p.name, String(a.length), String(m.length), String(n.length)]),
  }];
  for (const { p, a, m, n } of people) {
    if (!a.length && !m.length && !n.length) continue;
    sections.push({ heading: `${p.name} - activities`, empty: 'No notes or meetings.', columns: [{ label: 'Time', w: 90 }, { label: 'Type', w: 70 }, { label: 'Customer', w: 130 }, { label: 'Detail', w: 270 }], rows: a.map((x) => [x.at.slice(0, 16), x.type, clip(x.company, 40), clip(x.text, 400)]) });
    if (m.length) sections.push({ heading: `${p.name} - e-mails sent`, columns: [{ label: 'Time', w: 90 }, { label: 'Kind', w: 70 }, { label: 'Customer', w: 110 }, { label: 'To', w: 110 }, { label: 'Subject / files', w: 180 }], rows: m.map((x) => [x.at.slice(0, 16), x.kind, clip(x.company, 30), clip(x.to_addr, 40), clip(`${x.subject ?? ''}${x.attachments ? ` [${x.attachments}]` : ''}`, 160)]) });
    if (n.length) sections.push({ heading: `${p.name} - customers added`, columns: [{ label: 'Time', w: 90 }, { label: 'Customer', w: 250 }, { label: 'Country', w: 120 }], rows: n.map((x) => [x.at.slice(0, 16), clip(x.company, 60), x.country ?? '']) });
  }
  const pdf = await renderTablePdf({ title: 'Daily activity report', subtitle: `${from}${to !== from ? ` - ${to}` : ''} (Turkish time)${uid ? ` - ${d.users[0]?.name ?? ''}` : ' - all employees'}`, facts: [`${d.acts.length} notes, calls and meetings`, `${d.mails.length} e-mails sent`, `${d.added.length} customers added`], sections, landscape: false });
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `inline; filename="activity-${from}${to !== from ? `-${to}` : ''}.pdf"`);
  res.send(pdf);
});

export default router;
