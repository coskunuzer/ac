-- What each person at a company is for (purchasing, finance ...), and which SAP account a sent statement was about, so "statement sent 2 days ago" can be shown.
ALTER TABLE card_contacts ADD COLUMN roles TEXT;
ALTER TABLE cards ADD COLUMN contact_roles TEXT;
ALTER TABLE sent_emails ADD COLUMN sap TEXT;
CREATE INDEX IF NOT EXISTS idx_sent_emails_sap ON sent_emails (sap, kind);
CREATE INDEX IF NOT EXISTS idx_sent_emails_card_kind ON sent_emails (card_id, kind);
