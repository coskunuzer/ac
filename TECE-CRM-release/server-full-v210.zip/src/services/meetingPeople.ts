import { contactModel } from '../models/contactModel';
import type { CardRow } from '../models/cardModel';
import { analysePhone, splitNumbers } from './phone';

// The people of a customer that a meeting or a trip message can go to: the main contact and the others listed under the customer.
export interface MeetingPerson {
  name: string;
  position: string | null;
  emails: string[];
  // the mobile number in international form, when there is a real mobile: WhatsApp can be written to it
  whatsapp: string | null;
}

const EMAIL = /[^\s@,;<>]+@[^\s@,;<>]+\.[^\s@,;<>]+/g;
export const emailsIn = (raw: string | null | undefined): string[] => [...new Set((String(raw ?? '').match(EMAIL) ?? []).map((e) => e.toLowerCase()))];

function mobileOf(mobile: string | null, tel: string | null, country: string | null): string | null {
  for (const raw of [...splitNumbers(mobile), ...splitNumbers(tel)]) {
    const a = analysePhone(raw, country);
    if (a.e164 && a.kind === 'mobile') return a.e164;
  }
  return null;
}

export function peopleOf(card: CardRow): MeetingPerson[] {
  const out: MeetingPerson[] = [];
  const main = [card.name, card.last_name].filter(Boolean).join(' ').trim();
  const mainEmails = emailsIn(card.email);
  const mainWa = mobileOf(card.mobile ?? null, card.tel ?? null, card.country);
  if (main || mainEmails.length || mainWa) out.push({ name: main || card.company || '', position: card.position ?? null, emails: mainEmails, whatsapp: mainWa });
  for (const c of contactModel.list(card.id)) {
    const name = [c.name, c.lastName].filter(Boolean).join(' ').trim();
    const emails = emailsIn(c.email);
    const wa = mobileOf(c.mobile, c.tel, card.country);
    if (name || emails.length || wa) out.push({ name: name || '', position: c.position, emails, whatsapp: wa });
  }
  return out;
}
