import { db } from '../db/connection';
import type { CardRow } from '../models/cardModel';
import { cardModel } from '../models/cardModel';
import type { ExtractedCardFields, FieldStatusMap } from '../schema/cardSchema';

// The junk folder: customers that were taken out of the lists, kept for an admin (restore one, or delete for good). The files of a
// customer (the folder on disk) are not touched, so a restored customer finds them again.

interface Snapshot {
  card: Record<string, unknown>;
  contacts: Record<string, unknown>[];
  activities: Record<string, unknown>[];
  offers: Record<string, unknown>[];
  priceChanges: Record<string, unknown>[];
}

const all = (sql: string, id: number) => db.prepare(sql).all(id) as Record<string, unknown>[];

// Moves a customer to the junk folder (it disappears from every list).
export function moveToJunk(card: CardRow, reason: string, userId: number, insideTransaction = false): void {
  const snap: Snapshot = {
    card: card as unknown as Record<string, unknown>,
    contacts: all('SELECT * FROM card_contacts WHERE card_id = ?', card.id),
    activities: all('SELECT * FROM activities WHERE card_id = ?', card.id),
    offers: all('SELECT * FROM offers_sent WHERE card_id = ?', card.id),
    priceChanges: all('SELECT * FROM price_changes WHERE card_id = ?', card.id),
  };
  let sap: string | null = null;
  try { sap = (JSON.parse(card.lead_info ?? '{}') as { sap?: string }).sap ?? null; } catch { sap = null; }
  db.prepare('INSERT INTO junk_cards (company, city, sap, reason, origin, data, moved_by) VALUES (?, ?, ?, ?, ?, ?, ?)').run(card.company, card.city, sap, reason, 'moved', JSON.stringify(snap), userId);
  if (!insideTransaction) db.exec('BEGIN');
  try {
    db.prepare('DELETE FROM activities WHERE card_id = ?').run(card.id);
    db.prepare('DELETE FROM price_changes WHERE card_id = ?').run(card.id);
    db.prepare('DELETE FROM offers_sent WHERE card_id = ?').run(card.id);
    db.prepare('DELETE FROM card_contacts WHERE card_id = ?').run(card.id);
    cardModel.delete(card.id);
    if (!insideTransaction) db.exec('COMMIT');
  } catch (err) {
    if (!insideTransaction) db.exec('ROLLBACK');
    throw err;
  }
}

// A company that was never in the app, put in the junk folder straight from the row of a list.
export function addJunkRow(row: { company: string; city: string | null; sap: string | null; reason: string; data: Record<string, unknown> }, userId: number): void {
  db.prepare('INSERT INTO junk_cards (company, city, sap, reason, origin, data, moved_by) VALUES (?, ?, ?, ?, ?, ?, ?)').run(row.company, row.city, row.sap, row.reason, 'list', JSON.stringify(row.data), userId);
}

export function inJunk(sap: string | null, company: string): boolean {
  if (sap) return !!db.prepare('SELECT 1 FROM junk_cards WHERE sap = ?').get(sap);
  return !!db.prepare('SELECT 1 FROM junk_cards WHERE company = ?').get(company);
}

// the junk folder: an admin sees everything; a sales person sees only what they sent there themselves (mine = their user id)
export function listJunk(search: string, limit = 500, mine: number | null = null) {
  const like = `%${search}%`;
  const conds: string[] = [];
  const params: (string | number)[] = [];
  if (search) { conds.push('(j.company LIKE ? OR j.city LIKE ? OR j.sap LIKE ? OR j.reason LIKE ?)'); params.push(like, like, like, like); }
  if (mine !== null) { conds.push('j.moved_by = ?'); params.push(mine); }
  const where = conds.length ? `WHERE ${conds.join(' AND ')}` : '';
  const rows = db
    .prepare(`SELECT j.id, j.company, j.city, j.sap, j.reason, j.origin, j.created_at, u.display_name AS moved_by_name FROM junk_cards j LEFT JOIN users u ON u.id = j.moved_by ${where} ORDER BY j.created_at DESC, j.id DESC LIMIT ${limit}`)
    .all(...params) as { id: number; company: string | null; city: string | null; sap: string | null; reason: string | null; origin: string; created_at: string; moved_by_name: string | null }[];
  const total = mine === null ? (db.prepare('SELECT COUNT(*) AS n FROM junk_cards').get() as { n: number }).n : rows.length;
  return { rows, total };
}
export const junkOwner = (id: number): number | null => (db.prepare('SELECT moved_by FROM junk_cards WHERE id = ?').get(id) as { moved_by: number | null } | undefined)?.moved_by ?? null;

const insert = (table: string, row: Record<string, unknown>, extra: Record<string, unknown> = {}) => {
  const data = { ...row, ...extra };
  delete data.id;
  const cols = Object.keys(data);
  const r = db.prepare(`INSERT INTO ${table} (${cols.join(', ')}) VALUES (${cols.map((c) => `@${c}`).join(', ')})`).run(data as Record<string, string | number | null>);
  return Number(r.lastInsertRowid);
};

// Brings a customer back: the same record, with its people, notes and offers, under a new number.
export function restoreJunk(id: number, userId: number, exhibitionId: number): number | null {
  const row = db.prepare('SELECT * FROM junk_cards WHERE id = ?').get(id) as { origin: string; data: string; company: string | null; city: string | null; sap: string | null } | undefined;
  if (!row) return null;
  const data = JSON.parse(row.data);
  let cardId: number;
  db.exec('BEGIN');
  try {
    if (row.origin === 'moved') {
      const snap = data as Snapshot;
      cardId = insert('cards', snap.card);
      for (const c of snap.contacts) insert('card_contacts', c, { card_id: cardId });
      for (const a of snap.activities) insert('activities', a, { card_id: cardId });
      for (const o of snap.offers) insert('offers_sent', o, { card_id: cardId });
      for (const p of snap.priceChanges) insert('price_changes', p, { card_id: cardId });
    } else {
      const FOUND: FieldStatusMap = { name: 'found', company: 'found', address: 'found', country: 'found', tel: 'found', email: 'found', position: 'found', interestedIn: 'found', workArea: 'found', date: 'found', person: 'found', rate: 'found', notes: 'found' };
      const fields: ExtractedCardFields = { name: null, company: row.company, address: null, country: 'Turkey', tel: (data.phone as string) || null, email: (data.email as string) || null, position: null, interestedIn: null, workArea: null, date: null, person: null, rate: null, notes: (data.reason as string) || null };
      const card = cardModel.createFromExtraction({
        exhibitionId, uploadedBy: userId, imagePath: '', fields, fieldStatus: FOUND, extractionModel: 'domestic-list', status: 'confirmed', market: 'domestic', city: row.city,
        stage: 'customer', website: (data.website as string) || null, leadInfo: { sap: row.sap, source: 'junk folder' },
      });
      cardId = card.id;
    }
    db.prepare('DELETE FROM junk_cards WHERE id = ?').run(id);
    db.exec('COMMIT');
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
  return cardId;
}

export function purgeJunk(ids: number[] | 'all'): number {
  if (ids === 'all') return Number(db.prepare('DELETE FROM junk_cards').run().changes);
  let n = 0;
  for (const id of ids) n += Number(db.prepare('DELETE FROM junk_cards WHERE id = ?').run(id).changes);
  return n;
}
