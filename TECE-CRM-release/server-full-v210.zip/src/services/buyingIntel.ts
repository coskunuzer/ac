import { db } from '../db/connection';
import { memoTablesBy } from '../db/dataVersion';
import { setsFor, usdPerEur } from './perfAnalytics';
import { sheetsOfSap } from './ledgerMatch';
import { pricingAnalysis } from './pricingAnalysis';
import { colorBySap } from './colorDb';
import type { Viewer } from './visibility';

// Buying intelligence, from the ledger of every customer: how often they order, whether they are late, whether their volume is falling (and their price is below the
// standard at the same time), and what they could buy that similar customers buy.
export interface BuyingRow {
  sap: string; cardId: number | null; customer: string; country: string; rep: string; currency: string;
  orders: number; medianDays: number | null; lastOrder: string | null; expectedNext: string | null; daysLate: number | null;
  status: 'late' | 'due' | 'ok' | 'quiet' | 'new';
  last12: number; prev12: number; trendPct: number | null; indexPct: number | null; flags: string[]; missing: { group: string; sharePct: number }[]; bought: string[];
}
const today = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });
const dd = (a: string, b: string) => Math.round((Date.parse(b) - Date.parse(a)) / 86_400_000);
const median = (xs: number[]) => { const s = [...xs].sort((a, b) => a - b); const m = Math.floor(s.length / 2); return s.length ? (s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2) : null; };
const addDays = (iso: string, n: number) => { const d = new Date(`${iso}T00:00:00Z`); d.setUTCDate(d.getUTCDate() + Math.round(n)); return d.toISOString().slice(0, 10); };

const groupCache = new Map<string, string>();
const groupOf = (sap: string): string => {
  if (groupCache.has(sap)) return groupCache.get(sap)!;
  let g = '';
  try { g = colorBySap(sap).color?.productType ?? ''; } catch { /* the colour database may be empty */ }
  if (!g) g = /^\d{8}$/.test(sap) ? 'Veneer' : sap.endsWith('.012') ? 'PVC' : sap.endsWith('.042') ? 'ABS' : sap.endsWith('.023') ? 'Melamine' : 'Other';
  groupCache.set(sap, g);
  return g;
};

type Intel = { rows: BuyingRow[]; lateCount: number; asOf: string };

// The invoices of the last four years, by ledger tab. The same for everybody, so they are read once and kept until the ledger is written to
// (before, the Radar of each person read all of them again).
const invoicesKept = memoTablesBy(['ledger_transactions'], (since: string) => {
  const tx = db.prepare('SELECT sheet_name, tx_date, debit FROM ledger_transactions WHERE debit > 0 AND tx_date >= ? ORDER BY tx_date').all(since) as { sheet_name: string; tx_date: string; debit: number }[];
  const bySheet = new Map<string, { d: string; v: number }[]>();
  for (const r of tx) (bySheet.get(r.sheet_name) ?? bySheet.set(r.sheet_name, []).get(r.sheet_name)!).push({ d: r.tx_date, v: r.debit });
  return bySheet;
}, 3);
const invoicesSince = (since: string): Map<string, { d: string; v: number }[]> => invoicesKept(since);
// adds up the ledger of every customer and prices every proforma: asked by the Radar of each person, so it is kept for 3 minutes for each person
const intelKept = new Map<number, { at: number; v: Intel }>();
export function buyingIntel(viewer: Viewer): Intel {
  const hit = intelKept.get(viewer.id);
  if (hit && Date.now() - hit.at < 180_000) return hit.v;
  const v = buyingIntelRaw(viewer);
  intelKept.set(viewer.id, { at: Date.now(), v });
  return v;
}
function buyingIntelRaw(viewer: Viewer): Intel {
  const t = today();
  const accounts = setsFor(viewer, null).live;
  const since = addDays(t, -4 * 366);
  const bySheet = invoicesSince(since);
  const price = new Map(pricingAnalysis(viewer).rows.map((r) => [`${r.cardId}${r.currency}`, r.indexPct]));
  // what the customers with proforma history buy (groups), to find what each one does not buy yet
  const docs = db.prepare('SELECT card_id, lines_json FROM customer_price_docs').all() as { card_id: number; lines_json: string }[];
  const boughtBy = new Map<number, Set<string>>();
  for (const d of docs) { const s = boughtBy.get(d.card_id) ?? new Set<string>(); for (const l of JSON.parse(d.lines_json) as { sap: string }[]) s.add(groupOf(l.sap)); boughtBy.set(d.card_id, s); }
  const share = new Map<string, number>();
  for (const s of boughtBy.values()) for (const g of s) share.set(g, (share.get(g) ?? 0) + 1);
  const rows: BuyingRow[] = [];
  const y1 = addDays(t, -365); const y2 = addDays(t, -730);
  for (const a of accounts) {
    const sheets = sheetsOfSap(a.sap);
    const lines = sheets.flatMap((s) => bySheet.get(s) ?? []).sort((x, y) => x.d.localeCompare(y.d));
    if (!lines.length) continue;
    // an order = invoices within 10 days of each other
    const orders: string[] = [];
    for (const l of lines) if (!orders.length || dd(orders[orders.length - 1], l.d) > 10) orders.push(l.d);
    const gaps = orders.slice(1).map((d, i) => dd(orders[i], d));
    const med = orders.length >= 4 ? median(gaps) : null;
    const last = orders[orders.length - 1];
    const expected = med ? addDays(last, med) : null;
    const late = expected ? dd(expected, t) : null;
    const last12 = lines.filter((l) => l.d > y1).reduce((s, l) => s + l.v, 0);
    const prev12 = lines.filter((l) => l.d > y2 && l.d <= y1).reduce((s, l) => s + l.v, 0);
    const trend = prev12 > 0 ? Math.round(((last12 - prev12) / prev12) * 100) : null;
    const idle = dd(last, t);
    const status: BuyingRow['status'] = orders.length < 4 ? 'new' : idle > 540 ? 'quiet' : late !== null && late > Math.max(14, (med ?? 0) * 0.25) ? 'late' : late !== null && late > 0 ? 'due' : 'ok';
    const index = a.cardId ? price.get(`${a.cardId}${a.currency}`) ?? null : null;
    const flags: string[] = [];
    if (status === 'late') flags.push('Later than usual');
    if (trend !== null && trend <= -25 && prev12 > 0) flags.push('Volume is falling');
    if (trend !== null && trend <= -25 && index !== null && index <= -5) flags.push('Falling volume and a price below the standard');
    const have = a.cardId ? boughtBy.get(a.cardId) : undefined;
    const missing = have && boughtBy.size >= 3 ? [...share].filter(([g, n]) => !have.has(g) && g !== 'Other' && n / boughtBy.size >= 0.25).map(([group, n]) => ({ group, sharePct: Math.round((n / boughtBy.size) * 100) })).sort((x, y) => y.sharePct - x.sharePct) : [];
    rows.push({ sap: a.sap, cardId: a.cardId, customer: a.name, country: a.country, rep: a.rep, currency: a.currency, orders: orders.length, medianDays: med === null ? null : Math.round(med), lastOrder: last, expectedNext: expected, daysLate: late, status,
      last12: Math.round(last12), prev12: Math.round(prev12), trendPct: trend, indexPct: index, flags, missing, bought: have ? [...have] : [] });
  }
  void usdPerEur;
  const rank = (r: BuyingRow) => (r.flags.some((f) => f.startsWith('Falling volume and')) ? 0 : r.status === 'late' ? 1 : r.flags.length ? 2 : r.status === 'due' ? 3 : 4);
  rows.sort((a, b) => rank(a) - rank(b) || (b.daysLate ?? -999) - (a.daysLate ?? -999) || b.last12 - a.last12);
  return { rows, lateCount: rows.filter((r) => r.status === 'late').length, asOf: t };
}
