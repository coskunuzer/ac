-- Confirming an order closes the older proformas of the same customer too (they were drafts of the same order): they are "replaced", not waiting.
ALTER TABLE document_archive ADD COLUMN superseded_by INTEGER;

-- The radar can be silenced line by line (for a day, a week, or for good); each person has their own.
CREATE TABLE IF NOT EXISTS radar_silenced (
  user_id INTEGER NOT NULL,
  key TEXT NOT NULL,                 -- 'payments:1202000143', 'offers:12', 'proformas:8' ...
  until TEXT,                        -- NULL = for good
  label TEXT,                        -- what it was, to show it in the silenced list
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, key)
);
