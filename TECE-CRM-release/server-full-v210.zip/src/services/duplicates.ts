import fs from 'fs';
import path from 'path';
import { db } from '../db/connection';
import { cardModel, type CardRow } from '../models/cardModel';
import { contactModel } from '../models/contactModel';
import { activityModel } from '../models/activityModel';
import { countryKey } from '../models/countryModel';
import { placeKey } from '../data/turkeyPlaces';
import { absoluteFolder, removeCustomerFolder, syncCustomerFolder } from './customerFiles';
import { interestOf } from './interest';
import { visibilityFor, visibilitySql, type Viewer } from './visibility';
import { refreshOwnerOverride } from './ownership';
import { splitNumbers } from './phone';

// The same company scanned or added twice: keep one customer and put the other people under it.
// Records are taken to be the same company when they share the company name, the company's own e-mail domain, the web site or a telephone number.

export type DupReason = 'name' | 'email' | 'website' | 'phone';
export const REASON_TEXT: Record<DupReason, string> = {
  name: 'Same company name',
  email: 'Same company e-mail address',
  website: 'Same web site',
  phone: 'Same telephone number',
};

export interface DupMember {
  id: number;
  company: string | null;
  name: string | null;
  position: string | null;
  email: string | null;
  tel: string | null;
  country: string | null;
  city: string | null;
  market: string;
  stage: string | null;
  person: string | null;
  createdAt: string;
  activities: number;
  offers: number;
  contacts: number;
}

export interface DupGroup {
  key: string;
  members: DupMember[];
  keep: number; // the one that holds the most (the suggestion)
  reasons: string[]; // why these are thought to be one company
}

function counts(ids: number[]): { act: Map<number, number>; off: Map<number, number>; con: Map<number, number> } {
  const list = ids.map((n) => Math.trunc(Number(n))).join(',') || '0';
  const toMap = (sql: string) => new Map((db.prepare(sql).all() as { card_id: number; n: number }[]).map((r) => [r.card_id, r.n]));
  return {
    act: toMap(`SELECT card_id, COUNT(*) AS n FROM activities WHERE card_id IN (${list}) AND type != 'ai' GROUP BY card_id`),
    off: toMap(`SELECT card_id, COUNT(*) AS n FROM offers_sent WHERE card_id IN (${list}) GROUP BY card_id`),
    con: toMap(`SELECT card_id, COUNT(*) AS n FROM card_contacts WHERE card_id IN (${list}) GROUP BY card_id`),
  };
}

function member(c: CardRow, n: ReturnType<typeof counts>): DupMember {
  return {
    id: c.id, company: c.company, name: c.name, position: c.position, email: c.email, tel: [c.tel, c.mobile].filter(Boolean).join(' / ') || null, country: c.country, city: c.city, market: c.market, stage: c.stage,
    person: c.person, createdAt: c.created_at, activities: n.act.get(c.id) ?? 0, offers: n.off.get(c.id) ?? 0, contacts: n.con.get(c.id) ?? 0,
  };
}

type Place = { market: string; country: string | null; city: string | null };

// Same market, and the same country (or city) or one of them is not filled in.
function compatible(a: Place, b: Place): boolean {
  if (a.market !== b.market) return false;
  if (a.market === 'domestic') return !a.city || !b.city || placeKey(a.city) === placeKey(b.city);
  return !a.country || !b.country || countryKey(a.country) === countryKey(b.country);
}

const richness = (m: DupMember) => (m.stage && m.stage !== 'lead' ? 10 : 0) + m.activities + m.offers * 3 + m.contacts + (m.email ? 1 : 0);

export function suggestKeep(members: DupMember[]): number {
  return [...members].sort((a, b) => richness(b) - richness(a) || a.id - b.id)[0].id;
}

// ---- what makes two records "the same company" -------------------------------------------------------------------------------
// E-mail addresses everybody has (not a sign of one company), and our own.
const FREE_MAIL = new Set([
  'gmail.com', 'googlemail.com', 'hotmail.com', 'hotmail.co.uk', 'hotmail.es', 'hotmail.fr', 'hotmail.it', 'outlook.com', 'outlook.es', 'live.com', 'msn.com', 'yahoo.com', 'yahoo.com.tr',
  'yahoo.fr', 'yahoo.es', 'yahoo.it', 'yahoo.co.uk', 'ymail.com', 'icloud.com', 'me.com', 'aol.com', 'gmx.com', 'gmx.de', 'web.de', 'mail.ru', 'yandex.com', 'yandex.ru', 'proton.me',
  'protonmail.com', 'libero.it', 'tiscali.it', 'abv.bg', 'wp.pl', 'o2.pl', 'seznam.cz', 't-online.de', 'orange.fr', 'free.fr', 'sapo.pt', 'bol.com.br', 'uol.com.br', 'terra.com.br',
  'mynet.com', 'ttmail.com', 'tece.com.tr', 'tecedekor.com',
]);

interface Light {
  id: number;
  company_key: string | null;
  email: string | null;
  website: string | null;
  tel: string | null;
  mobile: string | null;
  market: string;
  country: string | null;
  city: string | null;
}

const mailDomains = (email: string | null): string[] =>
  (email ?? '')
    .toLowerCase()
    .split(/[,;\s]+/)
    .map((e) => /@([a-z0-9.-]+\.[a-z]{2,})$/.exec(e)?.[1])
    .filter((d): d is string => !!d && !FREE_MAIL.has(d));

export const hostOf = (website: string | null): string | null => {
  const h = (website ?? '').trim().toLowerCase().replace(/^[a-z]+:\/\//, '').replace(/^www\./, '').split(/[/?#\s]/)[0];
  return h && /\.[a-z]{2,}$/.test(h) ? h : null;
};

// Sites that thousands of companies share (social pages, link pages, marketplaces): the bare address says nothing about the company. Only a page of its own (facebook.com/madecenter) can.
const SHARED_SITES = new Set(['facebook.com', 'fb.com', 'fb.me', 'm.facebook.com', 'instagram.com', 'linkedin.com', 'twitter.com', 'x.com', 'youtube.com', 'youtu.be', 'tiktok.com', 'wa.me', 'whatsapp.com', 'api.whatsapp.com', 'linktr.ee', 'google.com', 'business.site', 'blogspot.com', 'wordpress.com', 'pinterest.com', 't.me', 'alibaba.com', 'made-in-china.com', 'mercadolibre.com', 'olx.com', 'yelp.com', 'sites.google.com', 'wixsite.com', 'weebly.com', 'godaddysites.com', 'example.com', 'example.org', 'example.net']);

// The web site as a key: the address AND the page. "shop.com/a" and "shop.com/b" are different companies; a shared site with no page of its own gives no key at all.
export function siteKey(website: string | null): string | null {
  const raw = (website ?? '').trim().toLowerCase().replace(/^[a-z]+:\/\//, '').replace(/^www\./, '').split(/[?#\s]/)[0];
  if (!raw) return null;
  const [host, ...rest] = raw.split('/');
  if (!/\.[a-z]{2,}$/.test(host)) return null;
  const path = rest.filter((p) => p && !/^index\.(html?|php)$/.test(p)).join('/');
  if (SHARED_SITES.has(host) && !path) return null;
  return path ? host + '/' + path : host;
}

// The last nine digits of a telephone number: the same number written with or without the country code.
const phoneKeys = (...values: (string | null)[]): string[] =>
  values.flatMap((v) => splitNumbers(v)).map((n) => n.replace(/\D/g, '')).filter((d) => d.length >= 8).map((d) => d.slice(-9));

function keysOf(c: Light): { reason: DupReason; key: string }[] {
  const out: { reason: DupReason; key: string }[] = [];
  if (c.company_key) out.push({ reason: 'name', key: c.company_key });
  for (const d of new Set(mailDomains(c.email))) out.push({ reason: 'email', key: d });
  const h = siteKey(c.website);
  if (h) out.push({ reason: 'website', key: h });
  for (const p of new Set(phoneKeys(c.tel, c.mobile))) out.push({ reason: 'phone', key: p });
  return out;
}

// ---- finding them -------------------------------------------------------------------------------------------------------------------
// Other records of the same company that this person may see.
export function findDuplicates(card: CardRow, viewer: Viewer): (DupMember & { why: string[] })[] {
  const mine = keysOf(card);
  if (!mine.length) return [];
  const where: string[] = [];
  const params: Record<string, string | number> = { id: card.id };
  mine.forEach((k, i) => {
    if (k.reason === 'name') where.push(`company_key = @k${i}`);
    else if (k.reason === 'email') where.push(`LOWER(email) LIKE @k${i}`);
    else if (k.reason === 'website') where.push(`LOWER(website) LIKE @k${i}`);
    else where.push(`(REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(tel, ''), ' ', ''), '+', ''), '-', ''), '/', '') LIKE @k${i} OR REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(mobile, ''), ' ', ''), '+', ''), '-', ''), '/', '') LIKE @k${i})`);
    params[`k${i}`] = k.reason === 'name' ? k.key : k.reason === 'email' ? `%@${k.key}%` : k.reason === 'website' ? `%${k.key}%` : `%${k.key}%`;
  });
  const ok = visibilityFor(viewer);
  const found: { c: CardRow; why: Set<DupReason> }[] = [];
  for (const c of db.prepare(`SELECT * FROM cards WHERE id != @id AND (${where.join(' OR ')})`).all(params) as unknown as CardRow[]) {
    if (!compatible(card, c) || !ok(c)) continue;
    const theirs = keysOf(c);
    const why = new Set<DupReason>(mine.filter((m) => theirs.some((t) => t.reason === m.reason && t.key === m.key)).map((m) => m.reason));
    if (why.size) found.push({ c, why });
  }
  // an e-mail domain, web site or phone that more than 10 companies share (a placeholder site, a distributor's number) says nothing about this one
  const per = new Map<DupReason, number>();
  for (const f of found) for (const r of f.why) per.set(r, (per.get(r) ?? 0) + 1);
  for (const f of found) for (const r of [...f.why]) if (r !== 'name' && (per.get(r) ?? 0) > 10) f.why.delete(r);
  // the clearest first (the same name, then the most reasons in common); never more than 20 (the duplicates screen has the rest)
  const kept = found.filter((f) => f.why.size).sort((a, b) => Number(b.why.has('name')) - Number(a.why.has('name')) || b.why.size - a.why.size || a.c.id - b.c.id).slice(0, 20);
  if (!kept.length) return [];
  const n = counts(kept.map((f) => f.c.id));
  return kept.map((f) => ({ ...member(f.c, n), why: [...f.why].map((r) => REASON_TEXT[r]) }));
}

// Every company that appears more than once among the customers this person may see.
export function duplicateGroups(viewer: Viewer, limit = 150): DupGroup[] {
  const params: Record<string, string | number> = {};
  const vis = visibilitySql(viewer, params);
  const rows = db
    .prepare(`SELECT id, company_key, email, website, tel, mobile, market, country, city FROM cards${vis ? ` WHERE ${vis}` : ''}`)
    .all(params) as unknown as Light[];
  const byId = new Map(rows.map((r) => [r.id, r]));

  const buckets = new Map<string, number[]>();
  for (const r of rows) {
    for (const k of keysOf(r)) {
      const b = `${k.reason}|${r.market}|${k.key}`;
      (buckets.get(b) ?? buckets.set(b, []).get(b)!).push(r.id);
    }
  }

  // union-find over the records that share a key (and are compatible)
  const parent = new Map<number, number>();
  const why = new Map<number, Set<DupReason>>();
  const find = (x: number): number => {
    let r = x;
    while ((parent.get(r) ?? r) !== r) r = parent.get(r)!;
    parent.set(x, r);
    return r;
  };
  for (const [b, ids] of buckets) {
    // a key that many records share (a generic domain) says nothing
    if (ids.length < 2 || ids.length > 40) continue;
    const reason = b.slice(0, b.indexOf('|')) as DupReason;
    const first = byId.get(ids[0])!;
    for (const id of ids.slice(1)) {
      const other = byId.get(id)!;
      if (!compatible(first, other)) continue;
      const ra = find(first.id);
      const rb = find(other.id);
      const merged = new Set<DupReason>([...(why.get(ra) ?? []), ...(why.get(rb) ?? []), reason]);
      if (ra !== rb) parent.set(rb, ra);
      why.set(ra, merged);
    }
  }
  const comps = new Map<number, number[]>();
  for (const id of parent.keys()) (comps.get(find(id)) ?? comps.set(find(id), []).get(find(id))!).push(id);
  for (const [root] of comps) if (!comps.get(root)!.includes(root)) comps.get(root)!.push(root);

  const order: DupReason[] = ['name', 'email', 'website', 'phone'];
  const list = [...comps.entries()]
    .filter(([, ids]) => ids.length >= 2)
    .map(([root, ids]) => ({ root, ids: ids.sort((a, b) => a - b), reasons: order.filter((r) => why.get(find(root))?.has(r)) }))
    // the clearest cases first (the same name), then the biggest
    .sort((a, b) => order.indexOf(a.reasons[0]) - order.indexOf(b.reasons[0]) || b.ids.length - a.ids.length || a.ids[0] - b.ids[0])
    .slice(0, limit);

  const groups: DupGroup[] = [];
  for (const g of list) {
    const full = (db.prepare(`SELECT * FROM cards WHERE id IN (${g.ids.join(',')}) ORDER BY id`).all() as unknown as CardRow[]);
    const n = counts(g.ids);
    const members = full.map((c) => member(c, n));
    groups.push({ key: `${g.reasons[0] ?? 'name'}-${g.ids[0]}`, members, keep: suggestKeep(members), reasons: g.reasons.map((r) => REASON_TEXT[r]) });
  }
  return groups;
}

// The number of groups, for the badge on the customer list (asked on every visit, so it is remembered for ten minutes).
const countCache = new Map<number, { at: number; n: number }>();
export function duplicateCount(viewer: Viewer): number {
  const hit = countCache.get(viewer.id);
  if (hit && Date.now() - hit.at < 600_000) return hit.n;
  const n = duplicateGroups(viewer, 500).length;
  countCache.set(viewer.id, { at: Date.now(), n });
  return n;
}
export const forgetDuplicateCounts = () => countCache.clear();

// ---- putting records together --------------------------------------------------------------------------------------------------------
const STAGE_ORDER = ['lead', 'contacted', 'interested', 'quoted', 'customer'];
const digitsOf = (s: string | null) => (s ?? '').replace(/\D/g, '');
// the same number, written with or without the country code
const sameNumber = (a: string, b: string) => {
  const x = digitsOf(a);
  const y = digitsOf(b);
  return x.length >= 6 && y.length >= 6 && x.slice(-9) === y.slice(-9);
};
// Adds the numbers of `extra` to the list of `base`, each only once ("0212 111 / 0532 222").
const addNumbers = (base: string | null, extra: string | null): string | null => {
  const have = splitNumbers(base);
  const out = [...have];
  for (const n of splitNumbers(extra)) if (!out.some((h) => sameNumber(h, n))) out.push(n);
  return out.length ? out.join(' / ') : base || extra || null;
};

// Puts the second record under the first: its person becomes another contact (with their own telephone number), its notes, offers, files
// and history move over, and the empty record is deleted. Returns the kept customer.
// What the person decided when two records of one company are put together: which prices to keep, what happens to the complaints, whose SAP number / owner / rating ...
export interface MergeOptions {
  prices?: 'both' | 'keep' | 'other' | 'newest';
  complaints?: 'move' | 'leave';
  fields?: Partial<Record<'sap' | 'person' | 'offer_percent' | 'rate' | 'website' | 'address', 'keep' | 'other'>>;
}
const COUNT_TABLES: [string, string][] = [['contacts', 'card_contacts'], ['notes', 'activities'], ['offers', 'offers_sent'], ['proformas', 'document_archive'], ['complaints', 'complaints'], ['opportunities', 'opportunities'], ['todos', 'todos'], ['suppliers', 'card_suppliers'], ['samples', 'card_samples']];
export interface MergeSide {
  id: number; company: string | null; name: string | null; email: string | null; country: string | null; stage: string | null; sap: string | null; person: string | null; rate: number | null; offerPercent: number | null; website: string | null; address: string | null;
  counts: Record<string, number>; priceProducts: number; priceDocs: number; priceLatest: string | null; priceCurrency: string | null;
}
const sideOf = (c: CardRow): MergeSide => {
  const counts: Record<string, number> = {};
  for (const [k, t] of COUNT_TABLES) counts[k] = (db.prepare(`SELECT COUNT(*) AS n FROM ${t} WHERE card_id = ?`).get(c.id) as { n: number }).n;
  const pr = db.prepare('SELECT COUNT(*) AS n, MAX(doc_date) AS d, MAX(currency) AS cur FROM customer_prices WHERE card_id = ?').get(c.id) as { n: number; d: string | null; cur: string | null };
  const docs = (db.prepare('SELECT COUNT(*) AS n FROM customer_price_docs WHERE card_id = ?').get(c.id) as { n: number }).n;
  return { id: c.id, company: c.company, name: c.name, email: c.email, country: c.country, stage: c.stage, sap: c.sap, person: c.person, rate: c.rate, offerPercent: c.offer_percent, website: c.website, address: c.address, counts, priceProducts: pr.n, priceDocs: docs, priceLatest: pr.d, priceCurrency: pr.cur };
};
// the two records side by side, so the person can decide what to keep where they differ
export function mergePreview(aId: number, bId: number): { a: MergeSide; b: MergeSide } | null {
  const a = cardModel.findById(aId); const b = cardModel.findById(bId);
  return a && b ? { a: sideOf(a), b: sideOf(b) } : null;
}

export function mergeCards(keepId: number, fromId: number, userId: number, opt: MergeOptions = {}): CardRow {
  const a = cardModel.findById(keepId);
  const b = cardModel.findById(fromId);
  if (!a || !b || a.id === b.id) throw new Error('Choose two different records of the same company.');
  const bName = (b.name ?? '').trim().toLowerCase();
  // somebody without a name, or with the same name, is the person we have already
  const samePerson = !bName || (a.name ?? '').trim().toLowerCase() === bName;
  const fromFolder = b.archive_dir ? absoluteFolder(b.archive_dir) : null;
  let tel = a.tel;
  let mobile = a.mobile;
  let fax = a.fax || b.fax;
  let how = '';

  db.exec('BEGIN');
  try {
    // the other person at the company
    if (b.name || b.email) {
      const known = new Set(
        [a.email ?? '', ...contactModel.list(a.id).map((c) => c.email ?? '')].flatMap((e) => e.toLowerCase().split(/[,;\s]+/)).filter(Boolean)
      );
      const newEmail = !!b.email && !b.email.toLowerCase().split(/[,;\s]+/).every((e) => known.has(e));
      // anybody else (or a new address) becomes a contact under the company, with their own numbers
      if (!samePerson || newEmail) {
        const added = contactModel.add(a.id, { name: b.name, position: b.position, email: b.email, tel: b.tel, mobile: b.mobile, scanPath: b.image_path });
        if (added) how = ` as another person${added.tel ? ' with their own telephone number' : ''}`;
      }
    }
    if (!how) {
      // the same person: their numbers are added to ours
      tel = addNumbers(tel, b.tel);
      mobile = addNumbers(mobile, b.mobile);
      if (b.tel || b.mobile) how = ' (the same person: their telephone numbers were added)';
    }
    db.prepare('UPDATE card_contacts SET card_id = ? WHERE card_id = ?').run(a.id, b.id);
    db.prepare('UPDATE activities SET card_id = ? WHERE card_id = ?').run(a.id, b.id);
    db.prepare('UPDATE offers_sent SET card_id = ? WHERE card_id = ?').run(a.id, b.id);
    db.prepare('UPDATE price_changes SET card_id = ? WHERE card_id = ?').run(a.id, b.id);
    // the AI tokens that were spent on the second record are booked on the kept one
    db.prepare('UPDATE ai_calls SET card_id = ? WHERE card_id = ?').run(a.id, b.id);
    // everything else that belongs to a customer moves over too: nothing is left behind (or lost with the deleted record)
    for (const t of ['todos', 'document_archive', 'proformas', 'sent_emails', 'card_samples', 'newsletter_recipients', 'internal_issues', 'audit_log', 'opportunities', 'price_reviews', 'card_suppliers', 'customer_aliases']) {
      db.prepare(`UPDATE ${t} SET card_id = ? WHERE card_id = ?`).run(a.id, b.id);
    }
    db.prepare('UPDATE OR IGNORE card_boards SET card_id = ? WHERE card_id = ?').run(a.id, b.id);
    for (const t of ['card_boards', 'card_approach', 'newsletter_overrides']) db.prepare(`DELETE FROM ${t} WHERE card_id = ?`).run(b.id);
    // complaints: they go with the customer (the default), or stay as typed complaints without a customer record
    if (opt.complaints === 'leave') db.prepare('UPDATE complaints SET card_id = NULL WHERE card_id = ?').run(b.id);
    else db.prepare('UPDATE complaints SET card_id = ? WHERE card_id = ?').run(a.id, b.id);
    // the customer's own prices (learned from their SAP proformas): whose, or both
    const prices = opt.prices ?? 'both';
    if (prices === 'other') {
      db.prepare('DELETE FROM customer_prices WHERE card_id = ?').run(a.id);
      db.prepare('DELETE FROM customer_price_docs WHERE card_id = ?').run(a.id);
    } else if (prices === 'newest') {
      db.prepare("DELETE FROM customer_prices WHERE card_id = ? AND EXISTS (SELECT 1 FROM customer_prices x WHERE x.card_id = ? AND x.sap = customer_prices.sap AND x.currency = customer_prices.currency AND COALESCE(x.doc_date, '') > COALESCE(customer_prices.doc_date, ''))").run(a.id, b.id);
    }
    if (prices !== 'keep') {
      db.prepare('UPDATE OR IGNORE customer_prices SET card_id = ? WHERE card_id = ?').run(a.id, b.id);
      db.prepare('UPDATE OR IGNORE customer_price_docs SET card_id = ? WHERE card_id = ?').run(a.id, b.id);
    }
    db.prepare('DELETE FROM customer_prices WHERE card_id = ?').run(b.id);
    db.prepare('DELETE FROM customer_price_docs WHERE card_id = ?').run(b.id);

    // the more advanced stage wins (somebody met at a fair counts as "contacted")
    const rank = (s: string | null) => (s === null ? 1 : STAGE_ORDER.indexOf(s));
    const stage = rank(b.stage) > rank(a.stage) ? b.stage : a.stage;
    const notes = b.notes && b.notes !== a.notes ? `${a.notes ? `${a.notes}\n\n` : ''}[From the merged record] ${b.notes}` : a.notes;
    db.prepare(
      `UPDATE cards SET tel = ?, mobile = ?, fax = ?, sap = ?, address = ?, website = ?, work_area = ?, position = ?, email = ?, notes = ?, stage = ?, rate = ?, lead_info = ?, send_offer = ?,
        thank_you_sent_at = ?, person = ?, offer_percent = ?, image_path = ?, ai_insight = ?, interested_in = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(
      // (another person's numbers stay with that person; only the numbers of the same person go on the customer)
      tel || (samePerson ? b.tel : null), mobile || (samePerson ? b.mobile : null), fax, a.sap || b.sap, a.address || b.address, a.website || b.website, a.work_area || b.work_area, a.position || (samePerson ? b.position : null), a.email || b.email,
      notes, stage, a.rate !== null && b.rate !== null ? Math.max(a.rate, b.rate) : a.rate ?? b.rate, a.lead_info || b.lead_info, a.send_offer ?? b.send_offer,
      a.thank_you_sent_at || b.thank_you_sent_at, a.person || b.person, a.offer_percent ?? b.offer_percent, a.image_path || b.image_path,
      a.ai_insight || b.ai_insight, a.interested_in || b.interested_in, a.id
    );

    // the fields where the person chose the other record's value
    const pick: Record<string, unknown> = { sap: b.sap, person: b.person, offer_percent: b.offer_percent, rate: b.rate, website: b.website, address: b.address };
    for (const [col, who] of Object.entries(opt.fields ?? {})) {
      if (who === 'other' && col in pick && pick[col] !== undefined && pick[col] !== null && pick[col] !== '') db.prepare(`UPDATE cards SET ${col} = ? WHERE id = ?`).run(pick[col] as string | number, a.id);
    }

    // what the AI found out about the second record is not lost: it comes over when the kept one has none, else it is written in the history
    if (b.company_score || b.company_check || b.ai_rate !== null) {
      if (!a.company_score && !a.company_check && a.ai_rate_source !== 'ai') {
        db.prepare('UPDATE cards SET company_score = ?, company_check = ?, ai_rate = ?, ai_rate_reason = ?, ai_rate_source = ?, ai_rated_at = ?, website_check = COALESCE(website_check, ?) WHERE id = ?').run(
          b.company_score, b.company_check, b.ai_rate, b.ai_rate_reason, b.ai_rate_source, b.ai_rated_at, b.website_check, a.id
        );
      } else if (b.ai_rate_source === 'ai') {
        activityModel.add({ userId, cardId: a.id, type: 'ai', imported: true, text: `AI check of the merged record: rating ${b.ai_rate}/10${b.ai_rate_reason ? ` - ${b.ai_rate_reason}` : ''}` });
      }
    }

    const bi = interestOf(b);
    cardModel.mergeInterest(a.id, bi.products, bi.widths);
    activityModel.add({
      userId, cardId: a.id, type: 'merged',
      text: `Merged another record of this company (${[b.name, b.position, b.email, [b.tel, b.mobile].filter(Boolean).join(' / ')].filter(Boolean).join(', ') || 'no details'}) into this customer${how}`,
    });
    // the second record is empty now (everything moved); its scan stays in the uploads folder
    db.prepare('DELETE FROM cards WHERE id = ?').run(b.id);
    db.exec('COMMIT');
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }

  forgetDuplicateCounts();
  refreshOwnerOverride(a.id);

  // the files of the deleted record go into the kept customer's folder
  try {
    const dir = syncCustomerFolder(a.id);
    if (dir && fromFolder && fs.existsSync(fromFolder)) {
      const dest = path.join(dir, 'Files', `From merged record [${b.id}]`);
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.cpSync(fromFolder, dest, { recursive: true });
    }
    removeCustomerFolder(b);
  } catch (err) {
    console.error('Moving the files of a merged record failed:', err);
  }
  syncCustomerFolder(a.id);
  return cardModel.findById(a.id)!;
}
