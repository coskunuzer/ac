import { DatabaseSync } from 'node:sqlite';
import { db } from '../db/connection';
import { paths } from '../config/env';
import { askJson } from './perfActions';

// The admin assistant. It can look at EVERYTHING in the system (customers, the SAP ledger and orders, activities per person, complaints, offers, AI costs ...):
// the AI writes read-only SQL from the question, the server checks it and runs it on a READ-ONLY connection, and the AI explains the figures when asked.
// A change is never made here: it is only proposed (a list of customers) and happens when the admin presses Apply.

export const EDIT_FIELDS: Record<string, { column: string; label: string; allowed?: (v: string) => boolean }> = {
  handling: { column: 'handling', label: 'Who works this customer (direct / distributor / empty = by country)', allowed: (v) => ['', 'direct', 'distributor'].includes(v) },
  person: { column: 'person', label: 'Responsible person (display name)', allowed: (v) => v.length > 1 && v.length < 80 },
  lead_source: { column: 'lead_source', label: 'Lead source', allowed: (v) => v.length < 80 },
  language: { column: 'language', label: 'Offer language', allowed: (v) => ['en', 'tr', 'ru', 'es', 'fr'].includes(v) },
};

// ---- what the AI may see: every table except the secret ones (the people are a safe view) -----------------------------------------------
const HIDDEN = new Set(['users', 'app_settings', 'google_calendar', 'schema_migrations', 'user_access', 'translations', 'color_codes', 'board_brands', 'email_template_translations', 'ai_usage', 'sqlite_sequence']);
const FORBIDDEN = /\b(attach|detach|pragma|insert|update|delete|drop|alter|create|vacuum|reindex|load_extension|begin|commit|rollback|savepoint)\b|password|refresh_token|\b(users|app_settings|google_calendar|schema_migrations|user_access|sqlite_master|sqlite_schema|sqlite_temp_master)\b/i;

const NOTES = `Meaning of the data (dates are ISO text, e.g. 2026-11-06):
- cards = customers and leads. stage: lead/contacted/interested/quoted/customer/lost. market: export/domestic. person = the responsible person (a display name). rate = the person's rating 0-10, ai_rate = the AI's. sap = the SAP customer number. handling: NULL by country / direct / distributor. lead_source, country, city, email, company, name.
- v_staff = the people (id, display_name, role, market). activities.user_id = who did it; activities.type: note, call, visit, meeting, sample, email, offer, thank_you, scan, created, stage, rated, ai (ai = the AI did it, not a person's work); activities.created_at = when; activities.card_id = which customer.
- sap_customers = the SAP customer master: sap_no, name, country, first_order, last_order, orders (count), m2, net_eur, net_usd, status_key.
- ledger_transactions = the current-account ledger per customer sheet: sheet_name, tx_date, debit (invoices), credit (payments), balance, currency. customer_aliases links sheet_name -> sap_no / card_id. customer_financial_summary = per sheet_name: balance (what they owe), total_invoiced, last_invoice_date, last_payment_date, currency.
- export_production_backlog = open orders in production (sap_no, customer, delivery_date, pending_qty, value_eur). export_dispatch_queue = ready to ship (sap_no, customer, net_value, weight). export_pipeline_blockers = order lines waiting.
- complaints / complaint_tasks / internal_issues = quality; offers_sent, proformas = what we sent; sent_emails; ai_calls = the AI usage and cost (total_tokens, purpose, user_id, created_at); todos; evaluations; exhibitions; distributors.
- Link customers to money: cards.sap = sap_customers.sap_no; customer_aliases.sap_no = cards.sap.`;

let schemaText: string | null = null;
function schema(): string {
  if (schemaText) return schemaText;
  const tables = (db.prepare("SELECT name, type FROM sqlite_master WHERE type IN ('table','view') AND name NOT LIKE 'sqlite_%' ORDER BY name").all() as { name: string }[]).filter((t) => !HIDDEN.has(t.name));
  schemaText = tables.map((t) => {
    const cols = (db.prepare(`PRAGMA table_info(${t.name})`).all() as { name: string }[]).map((c) => c.name).filter((c) => !/^(field_status|image_path|archive_dir|extraction_|ai_insight|lead_info|company_score|company_check|photos|scan_path|stored_name|hash|data)$/.test(c) && !/password|token/i.test(c));
    return `${t.name}(${cols.join(',')})`;
  }).join('\n');
  return schemaText;
}

// ---- running a query: read-only connection, one statement, a row limit -------------------------------------------------------------------------
let ro: DatabaseSync | null = null;
const readonly = (): DatabaseSync => (ro ??= new DatabaseSync(paths.dbFile, { readOnly: true }));

export interface Table { title: string; sql: string; columns: string[]; rows: (string | number | null)[][]; total: number; truncated: boolean }

export function runQuery(title: string, sqlRaw: string, limit = 300): Table {
  const sql = sqlRaw.trim().replace(/;+\s*$/, '');
  if (!/^(select|with)\b/i.test(sql)) throw new Error('Only a SELECT can be run.');
  if (sql.includes(';')) throw new Error('Only one statement can be run.');
  if (FORBIDDEN.test(sql.replace(/'(?:[^']|'')*'/g, "''"))) throw new Error('That query touches something that is not allowed.');
  const stmt = readonly().prepare(`SELECT * FROM (${sql}) LIMIT ${limit + 1}`);
  const objs = stmt.all() as Record<string, string | number | null>[];
  const columns = objs.length ? Object.keys(objs[0]) : ((stmt as unknown as { columns?: () => { name: string }[] }).columns?.().map((c) => c.name) ?? []);
  const truncated = objs.length > limit;
  const rows = objs.slice(0, limit).map((o) => columns.map((c) => (typeof o[c] === 'number' ? Math.round((o[c] as number) * 100) / 100 : (o[c] ?? null))));
  return { title, sql, columns, rows, total: rows.length, truncated };
}

// ---- the plan -----------------------------------------------------------------------------------------------------------------------------
export interface Plan { mode: 'query' | 'edit' | 'chat'; title: string; explain: boolean; queries: { title: string; sql: string }[]; editField: string; editValue: string; reply: string }

const PLAN_SCHEMA = {
  type: 'OBJECT',
  properties: {
    mode: { type: 'STRING', enum: ['query', 'edit', 'chat'] },
    title: { type: 'STRING' },
    explain: { type: 'BOOLEAN' },
    queries: { type: 'ARRAY', items: { type: 'OBJECT', properties: { title: { type: 'STRING' }, sql: { type: 'STRING' } }, required: ['title', 'sql'] } },
    editField: { type: 'STRING' },
    editValue: { type: 'STRING' },
    reply: { type: 'STRING' },
  },
  required: ['mode', 'title'],
};

const today = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });

function plannerPrompt(question: string, history: string, problem?: { sql: string; error: string }): string {
  return [
    'You are the data analyst of the TECE CRM (TECE makes edgebanding; customers are furniture makers and dealers). You can see the whole database through SQLite SELECT queries. Never answer facts from memory: query them.',
    `Today is ${today()}.`,
    'Reply with mode: "query" = show or analyse data (1-3 SELECT queries; give each a short title; keep each result small: use aggregates, GROUP BY, ORDER BY and LIMIT, at most 200 rows); "edit" = change one field of many customers (ONE query that selects only cards.id, plus editField and editValue); "chat" = only when no data is needed (answer in reply).',
    'Set explain=true when the admin wants a judgement, a ranking explained, advice or a strategy (a short written analysis is added from your figures); false for a plain list, count or report.',
    'SQLite syntax only: dates with date(), datetime(\'now\'), julianday(); text compare with LIKE; no semicolons. Use only the tables and columns below. Rows of "who works hardest" come from activities (exclude type \'ai\'). Money: a ledger balance is what the customer owes us.',
    `Editable fields: ${Object.entries(EDIT_FIELDS).map(([k, v]) => `${k} (${v.label})`).join('; ')}.`,
    NOTES,
    `Tables:\n${schema()}`,
    history ? `Earlier in this talk:\n${history}` : '',
    problem ? `Your earlier query failed.\nQuery: ${problem.sql}\nError: ${problem.error}\nWrite a corrected plan.` : '',
    `Request: ${question}`,
  ].filter(Boolean).join('\n\n');
}

export async function makePlan(question: string, history: string, problem?: { sql: string; error: string }): Promise<Plan | null> {
  const j = await askJson(plannerPrompt(question, history, problem), PLAN_SCHEMA);
  if (!j) return null;
  const queries = (Array.isArray(j.queries) ? j.queries : []).slice(0, 3).map((q) => ({ title: String((q as { title?: string }).title ?? '').slice(0, 100), sql: String((q as { sql?: string }).sql ?? '') })).filter((q) => q.sql.trim());
  return {
    mode: j.mode === 'edit' ? 'edit' : j.mode === 'chat' || !queries.length ? 'chat' : 'query',
    title: String(j.title ?? '').slice(0, 120), explain: j.explain === true, queries,
    editField: String(j.editField ?? ''), editValue: String(j.editValue ?? '').trim(), reply: String(j.reply ?? '').slice(0, 1500),
  };
}

// runs the queries; one failed query gets one repair by the AI
export async function runPlan(question: string, history: string, plan: Plan): Promise<{ plan: Plan; tables: Table[] }> {
  const attempt = (p: Plan): Table[] => p.queries.map((q) => runQuery(q.title, q.sql, p.mode === 'edit' ? 5000 : 300));
  try {
    return { plan, tables: attempt(plan) };
  } catch (first) {
    const bad = plan.queries[0];
    const fixed = await makePlan(question, history, { sql: bad?.sql ?? '', error: (first as Error).message });
    if (!fixed || !fixed.queries.length) throw first;
    return { plan: fixed, tables: attempt(fixed) };
  }
}

const compact = (t: Table, n = 40) => `## ${t.title} (${t.total}${t.truncated ? '+' : ''} rows)\n${t.columns.join(' | ')}\n${t.rows.slice(0, n).map((r) => r.map((v) => String(v ?? '').slice(0, 60)).join(' | ')).join('\n')}`;

export async function explain(question: string, tables: Table[]): Promise<string | null> {
  const j = await askJson(
    `You advise the sales management of TECE (edgebanding for furniture panels, Bursa). Answer the request in a short, practical way (at most 250 words) using ONLY the figures below: the finding first with the real names and numbers, then (if asked for advice) 3-5 concrete actions in order of value, and what data is missing. No invented facts; if the figures cannot answer it, say what is missing.\n\nRequest: ${question}\n\n${tables.map((t) => compact(t)).join('\n\n').slice(0, 9000)}`,
    { type: 'OBJECT', properties: { answer: { type: 'STRING' } }, required: ['answer'] },
  );
  return j?.answer ? String(j.answer).slice(0, 3500) : null;
}
