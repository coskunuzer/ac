import { Router } from 'express';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { askOwner, logPeek, peekCheck, peekHits, peekSummary } from '../services/peek';

// View only: the customers of my countries that another person looks after (see services/peek.ts). Nothing here changes a customer.
const router = Router();
router.use(requireAuth);

const who = (req: AuthedRequest) => req.actor ?? req.user!;
// the money figures follow the 'Sales figures' switch (no switches set = the defaults, which show them)
const money = (req: AuthedRequest) => { const p = (req.user as { perms?: { money: string[] } | null }).perms; return !p || req.user!.role === 'admin' || p.money.includes('ledger'); };

// exploring a country: the companies of my countries that I cannot normally open, with the name of who looks after them
router.get('/search', (req: AuthedRequest, res) => {
  try {
    const q = String(req.query.q ?? '').slice(0, 120);
    const country = String(req.query.country ?? '').slice(0, 80).trim() || undefined;
    const limit = Math.min(60, Math.max(3, parseInt(String(req.query.limit ?? '20'), 10) || 20));
    const rows = peekHits(req.user!, q, limit, { country });
    if (rows.length && (q.trim() || country)) logPeek(who(req), null, `search ${country ? `country=${country} ` : ''}q=${q}`.trim(), country ? `Looked at the customers of others in ${country} (view only)` : 'Searched the customers of others in my countries (view only)');
    res.json({ rows });
  } catch (e) { console.error('Peek search failed:', e); res.status(500).json({ error: 'The search failed.' }); }
});

// before saving a new customer: is it already somebody else's in my countries?
router.get('/check', (req: AuthedRequest, res) => {
  try {
    const rows = peekCheck(req.user!, { company: String(req.query.company ?? '').slice(0, 160), email: String(req.query.email ?? '').slice(0, 160), phone: String(req.query.phone ?? '').slice(0, 40) });
    if (rows.length) logPeek(who(req), rows[0].id, `add a customer: ${rows.length} match(es) (${rows.map((r) => r.id).join(', ')})`, 'Typed the same company on Add a customer (warned)');
    res.json({ rows });
  } catch (e) { console.error('Peek check failed:', e); res.status(500).json({ error: 'The check failed.' }); }
});

// the view-only summary of one customer
router.get('/:cardId', (req: AuthedRequest, res) => {
  const id = parseInt(String(req.params.cardId), 10);
  if (!Number.isFinite(id)) return res.status(404).json({ error: 'Not found' });
  try {
    const r = peekSummary(id, req.user!, money(req));
    if (r.kind === 'full') return res.json({ id, open: true });
    if (r.kind === 'none') return res.status(404).json({ error: 'This customer is not in your countries.' });
    logPeek(who(req), id, 'view');
    res.json(r.data);
  } catch (e) { console.error('Peek failed:', e); res.status(500).json({ error: 'Could not load it.' }); }
});

// "Ask <Name>": a to-do for the colleague who looks after it (or the admins when nobody does)
router.post('/:cardId/ask', (req: AuthedRequest, res) => {
  const id = parseInt(String(req.params.cardId), 10);
  try {
    const actor = who(req);
    const message = String(req.body?.message ?? '').trim().slice(0, 200);
    const r = askOwner(id, req.user!, actor.display_name || actor.username || 'A colleague', message);
    if (!r) return res.status(404).json({ error: 'This customer is not in your countries.' });
    logPeek(actor, id, `asked ${r.to.join(', ')}${message ? `: ${message}` : ''}`, `Asked ${r.to.join(', ')} about it (view only)`);
    res.json({ ok: true, to: r.to });
  } catch (e) { console.error('Peek ask failed:', e); res.status(500).json({ error: 'Could not send it.' }); }
});

export default router;
