import countryLib from 'i18n-iso-countries';
import trLocale from 'i18n-iso-countries/langs/tr.json';
import enLocale from 'i18n-iso-countries/langs/en.json';
import cityList from '../data/cities.json';
import { db } from '../db/connection';

countryLib.registerLocale(trLocale);
countryLib.registerLocale(enLocale);

// Countries, regions and the places in a request: names in Turkish and English, spelling mistakes ("Balkanlarrr", "romanyaa") put right, a region that holds
// other regions. Countries are kept as ISO codes in the data; the name shown is the Turkish one.
const NAME_OVERRIDE: Record<string, string> = { US: 'ABD', AE: 'Birleşik Arap Emirlikleri', GB: 'Birleşik Krallık', CZ: 'Çekya', MK: 'Kuzey Makedonya', XK: 'Kosova', BA: 'Bosna-Hersek' };
const EXTRA_ALIAS: Record<string, string[]> = {
  US: ['usa', 'amerika', 'united states', 'abd'], GB: ['uk', 'united kingdom', 'ingiltere', 'england', 'britanya'], AE: ['uae', 'bae', 'dubai', 'abu dhabi'], NL: ['holland', 'hollanda'],
  CZ: ['czech', 'czechia', 'cek cumhuriyeti', 'cekya'], BA: ['bosna', 'bosnia'], MK: ['macedonia', 'makedonya'], GR: ['yunan', 'greece'], SA: ['saudi', 'saudi arabia'], RU: ['russia', 'rusya'], CN: ['china', 'cin'], TW: ['taiwan', 'tayvan'], KR: ['south korea', 'guney kore'],
};
export const countryName = (iso: string): string => NAME_OVERRIDE[iso] ?? countryLib.getName(iso, 'tr') ?? countryLib.getName(iso, 'en') ?? iso;
export const allCountries = (): { iso: string; name: string }[] => Object.keys(countryLib.getAlpha2Codes()).map((iso) => ({ iso, name: countryName(iso) })).sort((a, b) => a.name.localeCompare(b.name, 'tr'));

export const asc = (s: string) => String(s).toLowerCase().replace(/ı/g, 'i').replace(/İ/g, 'i').replace(/ğ/g, 'g').replace(/ü/g, 'u').replace(/ş/g, 's').replace(/ö/g, 'o').replace(/ç/g, 'c').normalize('NFD').replace(/\p{Diacritic}/gu, '');
const squash = (s: string) => asc(s).replace(/\(.*?\)/g, ' ').replace(/[^a-z0-9]+/g, ' ').trim().replace(/(.)\1+/g, '$1');
function lev(a: string, b: string): number {
  const d: number[][] = Array.from({ length: a.length + 1 }, (_, i) => [i, ...Array(b.length).fill(0)]);
  for (let j = 1; j <= b.length; j++) d[0][j] = j;
  for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  return d[a.length][b.length];
}

// ---- regions (in the database; editable) ----------------------------------------------------------------------------------------------------
export interface Region { name: string; countries: string[]; parts: string[]; aliases: string[] }
const arr = (v: unknown): string[] => { try { const a = JSON.parse(String(v ?? '[]')); return Array.isArray(a) ? a.map(String) : []; } catch { return []; } };
export const regions = (): Region[] => (db.prepare('SELECT * FROM ship_regions ORDER BY name').all() as unknown as { name: string; countries: string; parts: string; aliases: string }[]).map((r) => ({ name: r.name, countries: arr(r.countries), parts: arr(r.parts), aliases: arr(r.aliases) }));
export function countriesOf(region: string, all: Region[] = regions(), seen: Set<string> = new Set()): string[] {
  if (seen.has(region)) return [];
  seen.add(region);
  const r = all.find((x) => x.name === region);
  if (!r) return [];
  return [...new Set([...r.countries, ...r.parts.flatMap((p) => countriesOf(p, all, seen))])];
}
export function saveRegion(name: string, countries: string[]): void {
  db.prepare('UPDATE ship_regions SET countries = ? WHERE name = ?').run(JSON.stringify([...new Set(countries)]), name);
}

// ---- recognising a place ---------------------------------------------------------------------------------------------------------------------
export type Place = { type: 'country'; iso: string; name: string; orig: string; corrected: boolean } | { type: 'region'; name: string; orig: string; corrected: boolean } | { type: 'all'; name: string; orig: string; corrected: boolean };
interface IndexEntry { key: string; kind: 'country' | 'region' | 'all'; iso?: string; name: string }
let index: IndexEntry[] | null = null;
let indexStamp = '';
function buildIndex(): IndexEntry[] {
  const regs = regions();
  const stamp = regs.map((r) => r.name + r.aliases.join()).join('|');
  if (index && stamp === indexStamp) return index;
  const out: IndexEntry[] = [];
  for (const iso of Object.keys(countryLib.getAlpha2Codes())) {
    for (const n of [countryName(iso), countryLib.getName(iso, 'tr') ?? '', countryLib.getName(iso, 'en') ?? '', ...(EXTRA_ALIAS[iso] ?? [])]) if (n) out.push({ key: squash(n), kind: 'country', iso, name: countryName(iso) });
  }
  for (const r of regs) for (const a of [r.name, ...r.aliases]) out.push({ key: squash(a), kind: 'region', name: r.name });
  for (const a of ['tum bolgeler', 'all regions', 'tum dunya', 'dunya geneli', 'worldwide']) out.push({ key: squash(a), kind: 'all', name: 'Tüm bölgeler' });
  index = out; indexStamp = stamp;
  return out;
}
export function matchPlace(raw: string): Place | null {
  const k = squash(raw);
  if (!k) return null;
  const idx = buildIndex();
  let hit = idx.find((x) => x.key === k);
  if (!hit && k.length >= 6) hit = idx.find((x) => x.key.length >= 6 && lev(x.key, k) <= 1);
  if (!hit) return null;
  const corrected = asc(raw.trim()) !== asc(hit.name);
  if (hit.kind === 'country') return { type: 'country', iso: hit.iso!, name: hit.name, orig: raw.trim(), corrected };
  return { type: hit.kind, name: hit.name, orig: raw.trim(), corrected };
}
export function splitPlaces(s: string): (Place | { type: 'unknown'; orig: string })[] {
  const whole = matchPlace(s);
  if (whole) return [whole];
  return String(s).split(/\s*(?:\/|,|;|\+| ve | and )\s*/i).filter(Boolean).map((p) => matchPlace(p) ?? { type: 'unknown' as const, orig: p.trim() });
}
export const MODES = ['Karayolu', 'Denizyolu (Konteyner)', 'Denizyolu (LCL)', 'Havayolu'] as const;
export type Mode = (typeof MODES)[number];
export function modesOf(s: string): Mode[] {
  const t = asc(s), out: Mode[] = [];
  if (/kamyon|tir\b|karayolu|\bkara\b|road|truck|yol/.test(t)) out.push('Karayolu');
  if (/konteyner|container|fcl/.test(t)) out.push('Denizyolu (Konteyner)');
  if (/lcl|parsiyel/.test(t)) out.push('Denizyolu (LCL)');
  if (/hava|\bair\b|ucak/.test(t)) out.push('Havayolu');
  return out;
}

// ---- forwarders ---------------------------------------------------------------------------------------------------------------------------------
export interface Forwarder {
  id: number; name: string; contact: string | null; emails: string[]; modes: Mode[]; lang: 'tr' | 'en'; active: boolean; note: string | null;
  covAll: boolean; covRegions: string[]; covCountries: string[];
  asked: number; answered: number; won: number; lastPrice: string | null;
}
interface FwRow { id: number; name: string; contact: string | null; emails: string; modes: string; lang: string; active: number; note: string | null; cov_all: number; cov_regions: string; cov_countries: string }
const toFw = (r: FwRow, stats: Map<number, { asked: number; answered: number; won: number; last: string | null }>): Forwarder => {
  const s = stats.get(r.id) ?? { asked: 0, answered: 0, won: 0, last: null };
  return { id: r.id, name: r.name, contact: r.contact, emails: arr(r.emails), modes: arr(r.modes) as Mode[], lang: r.lang === 'en' ? 'en' : 'tr', active: !!r.active, note: r.note, covAll: !!r.cov_all, covRegions: arr(r.cov_regions), covCountries: arr(r.cov_countries), asked: s.asked, answered: s.answered, won: s.won, lastPrice: s.last };
};
function statsByForwarder() {
  const m = new Map<number, { asked: number; answered: number; won: number; last: string | null }>();
  for (const r of db.prepare("SELECT forwarder_id AS id, COUNT(*) AS asked, SUM(answered_at IS NOT NULL) AS answered FROM ship_request_fw WHERE sent_at IS NOT NULL GROUP BY forwarder_id").all() as { id: number; asked: number; answered: number }[]) m.set(r.id, { asked: r.asked, answered: r.answered ?? 0, won: 0, last: null });
  for (const r of db.prepare("SELECT q.forwarder_id AS id, COUNT(*) AS won, MAX(q.total) AS t, q.currency AS c, f.pallets AS p FROM ship_quotes q JOIN ship_requests f ON f.id = q.request_id WHERE q.status = 'accepted' GROUP BY q.forwarder_id").all() as { id: number; won: number; t: number | null; c: string | null; p: number | null }[]) {
    const s = m.get(r.id) ?? { asked: 0, answered: 0, won: 0, last: null }; s.won = r.won; if (r.t) s.last = `${Math.round(r.t).toLocaleString('tr-TR')} ${r.c ?? ''}${r.p ? ` (${r.p} palet)` : ''}`.trim(); m.set(r.id, s);
  }
  return m;
}
export const listForwarders = (): Forwarder[] => { const st = statsByForwarder(); return (db.prepare('SELECT * FROM ship_forwarders ORDER BY name').all() as unknown as FwRow[]).map((r) => toFw(r, st)); };
export const findForwarder = (id: number): Forwarder | null => { const r = db.prepare('SELECT * FROM ship_forwarders WHERE id = ?').get(id) as FwRow | undefined; return r ? toFw(r, statsByForwarder()) : null; };

export interface FwInput { name: string; contact?: string | null; emails: string[]; modes: string[]; lang?: string; active?: boolean; note?: string | null; covAll?: boolean; covRegions?: string[]; covCountries?: string[] }
const clean = (i: FwInput) => ({
  name: i.name.trim().slice(0, 120), contact: (i.contact ?? '').trim().slice(0, 120) || null,
  emails: [...new Set(i.emails.map((e) => e.trim().toLowerCase()).filter((e) => /^[^\s@,;<>]+@[^\s@,;<>]+\.[^\s@,;<>]+$/.test(e)))],
  modes: MODES.filter((m) => i.modes.includes(m)), lang: i.lang === 'en' ? 'en' : 'tr', note: (i.note ?? '').trim().slice(0, 300) || null,
  covAll: !!i.covAll, covRegions: (i.covRegions ?? []).filter((r) => regions().some((x) => x.name === r)), covCountries: [...new Set((i.covCountries ?? []).filter((c) => /^[A-Z]{2}$/.test(c)))],
});
export function saveForwarder(id: number | null, input: FwInput): number {
  const c = clean(input);
  if (!c.name) throw new Error('Firma adı gerekli.');
  if (!c.emails.length) throw new Error('En az bir geçerli e-posta adresi gerekli.');
  if (!c.modes.length) throw new Error('En az bir taşıma türü seçin.');
  if (!c.covAll && !c.covRegions.length && !c.covCountries.length) throw new Error('Bir bölge, ülke ya da "Tüm bölgeler" seçin.');
  const vals = [c.name, squash(c.name), c.contact, JSON.stringify(c.emails), JSON.stringify(c.modes), c.lang, input.active === false ? 0 : 1, c.note, c.covAll ? 1 : 0, JSON.stringify(c.covRegions), JSON.stringify(c.covCountries)];
  if (id) { db.prepare("UPDATE ship_forwarders SET name = ?, name_key = ?, contact = ?, emails = ?, modes = ?, lang = ?, active = ?, note = ?, cov_all = ?, cov_regions = ?, cov_countries = ?, updated_at = datetime('now') WHERE id = ?").run(...vals, id); return id; }
  return Number(db.prepare('INSERT INTO ship_forwarders (name, name_key, contact, emails, modes, lang, active, note, cov_all, cov_regions, cov_countries) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').run(...vals).lastInsertRowid);
}

// why a firm is proposed for a destination (null = it is not)
export function serves(w: Forwarder, iso: string | null, mode: string, all: Region[] = regions()): string | null {
  if (!w.active || !w.modes.includes(mode as Mode)) return null;
  if (w.covAll) return 'Tüm bölgeler';
  if (!iso) return null;
  if (w.covCountries.includes(iso)) return `${countryName(iso)} için hizmet veriyor`;
  const r = w.covRegions.find((x) => countriesOf(x, all).includes(iso));
  return r ? `${r} bölgesi` : null;
}
export function proposedFor(iso: string | null, mode: string): (Forwarder & { why: string })[] {
  const all = regions();
  return listForwarders().map((w) => ({ w, why: serves(w, iso, mode, all) })).filter((x) => x.why).map((x) => ({ ...x.w, why: x.why! }))
    .sort((a, b) => (b.asked ? b.answered / b.asked : 0.5) - (a.asked ? a.answered / a.asked : 0.5));
}

// ---- the table of firms (Excel, CSV, pasted): cleaned and merged ----------------------------------------------------------------------------------
export interface ImportFirm { name: string; emails: string[]; modes: Mode[]; covAll: boolean; covRegions: string[]; covCountries: string[]; unknown: string[]; rows: number; notes: string[]; existing: number | null; variants: string[] }
export interface ImportResult { firms: ImportFirm[]; fixes: string[]; unknown: string[]; rowCount: number; merged: number; warnings: string[] }
export function processRows(rows: string[][]): ImportResult | null {
  if (!rows.length) return null;
  const head = rows[0].map(asc);
  let col = { name: 0, place: 1, email: 2, mode: 3 }, start = 0;
  const find = (re: RegExp) => head.findIndex((h) => re.test(h));
  if (find(/firma|sirket|company|^ad$/) > -1 || find(/e-?posta|email|mail/) > -1) {
    start = 1;
    const n = find(/firma|sirket|company|^ad$/), p = find(/ulke|bolge|country|region/), e = find(/e-?posta|email|mail/), m = find(/tasima|transport|tur/);
    col = { name: n > -1 ? n : 0, place: p > -1 ? p : 1, email: e > -1 ? e : 2, mode: m > -1 ? m : 3 };
  }
  const groups = new Map<string, ImportFirm>();
  const fixes: string[] = [];
  const unknown = new Set<string>();
  let rowCount = 0;
  for (const r of rows.slice(start)) {
    const name = (r[col.name] ?? '').trim();
    if (!name) continue;
    rowCount++;
    const key = squash(name);
    const g = groups.get(key) ?? { name, emails: [], modes: [], covAll: false, covRegions: [], covCountries: [], unknown: [], rows: 0, notes: [], existing: null, variants: [] };
    groups.set(key, g);
    g.rows++;
    for (const m of String(r[col.email] ?? '').match(/[^\s;,<>]+@[^\s;,<>]+\.[^\s;,<>]+/g) ?? []) { const e = m.toLowerCase(); if (!g.emails.includes(e)) g.emails.push(e); }
    for (const m of modesOf(String(r[col.mode] ?? ''))) if (!g.modes.includes(m)) g.modes.push(m);
    const paren = /\(([^)]*)\)/.exec(String(r[col.place] ?? ''));
    if (paren && !g.notes.includes(paren[1])) g.notes.push(paren[1]);
    for (const pl of splitPlaces(String(r[col.place] ?? ''))) {
      if (pl.type === 'all') g.covAll = true;
      else if (pl.type === 'region') { if (!g.covRegions.includes(pl.name)) g.covRegions.push(pl.name); }
      else if (pl.type === 'country') { if (!g.covCountries.includes(pl.iso)) g.covCountries.push(pl.iso); }
      else { g.unknown.push(pl.orig); unknown.add(pl.orig); continue; }
      if (pl.corrected) fixes.push(`${pl.orig} → ${pl.name}`);
    }
  }
  // a firm written in several ways: the name without "log / lojistik / transport / global ..." is the same, or one letter apart
  const core = (n: string) => squash(n).replace(/\b(logistics|logistic|logistik|lojistik|loj|log|transport|tasimacilik|global|group|grup|ltd|sti|as|san|tic|ve)\b/g, ' ').replace(/\s+/g, '').replace(/(.{4,})(log|loj)$/, '$1');
  const list = [...groups.entries()];
  const out: [string, ImportFirm][] = [];
  for (const [k, g] of list) {
    const c = core(g.name);
    const into = out.find(([, o]) => { const oc = core(o.name); return oc === c || (c.length >= 5 && oc.length >= 5 && lev(oc, c) <= 1); });
    if (!into) { out.push([k, g]); continue; }
    const o = into[1];
    if (!o.variants.includes(g.name) && g.name !== o.name) o.variants.push(g.name);
    for (const e of g.emails) if (!o.emails.includes(e)) o.emails.push(e);
    for (const m of g.modes) if (!o.modes.includes(m)) o.modes.push(m);
    o.covAll = o.covAll || g.covAll;
    for (const r of g.covRegions) if (!o.covRegions.includes(r)) o.covRegions.push(r);
    for (const c2 of g.covCountries) if (!o.covCountries.includes(c2)) o.covCountries.push(c2);
    for (const u of g.unknown) if (!o.unknown.includes(u)) o.unknown.push(u);
    for (const n of g.notes) if (!o.notes.includes(n)) o.notes.push(n);
    o.rows += g.rows;
  }
  const warnings: string[] = [];
  const byEmail = new Map<string, string[]>();
  for (const [, g] of out) for (const e of g.emails) byEmail.set(e, [...(byEmail.get(e) ?? []), g.name]);
  for (const [e, names] of byEmail) if (names.length > 1) warnings.push(`${e}: aynı e-posta, farklı firma adları (${names.join(' / ')}) — ayrı bırakıldı; aynı firmaysa listede tek ad kullanın`);
  const existing = listForwarders();
  const firms = out.map(([k, g]) => { const ex = existing.find((f) => squash(f.name) === k || f.emails.some((e) => g.emails.includes(e))); g.existing = ex?.id ?? null; return g; });
  return { firms, fixes: [...new Set(fixes)], unknown: [...unknown], rowCount, merged: rowCount - firms.length, warnings };
}
// apply: the person's answers for the unknown places ("Atlantis" -> a region or a country, or skipped)
export function applyImport(res: ImportResult, answers: Record<string, string>): { added: number; updated: number } {
  let added = 0, updated = 0;
  for (const g of res.firms) {
    for (const u of g.unknown) {
      const pl = answers[u] ? matchPlace(answers[u]) : null;
      if (!pl) continue;
      if (pl.type === 'all') g.covAll = true; else if (pl.type === 'region') { if (!g.covRegions.includes(pl.name)) g.covRegions.push(pl.name); } else if (!g.covCountries.includes(pl.iso)) g.covCountries.push(pl.iso);
    }
    const ex = g.existing ? findForwarder(g.existing) : null;
    if (ex) {
      saveForwarder(ex.id, { ...ex, emails: [...new Set([...ex.emails, ...g.emails])], modes: [...new Set([...ex.modes, ...g.modes])], covAll: ex.covAll || g.covAll, covRegions: [...new Set([...ex.covRegions, ...g.covRegions])], covCountries: [...new Set([...ex.covCountries, ...g.covCountries])], note: ex.note });
      updated++;
    } else if (g.emails.length && (g.covAll || g.covRegions.length || g.covCountries.length)) {
      saveForwarder(null, { name: g.name, emails: g.emails, modes: g.modes.length ? g.modes : ['Karayolu'], covAll: g.covAll, covRegions: g.covRegions, covCountries: g.covCountries, note: g.notes.join(', ') });
      added++;
    }
  }
  return { added, updated };
}

// ---- reading a pasted request (rules first; the AI only for what the rules miss, see shipRequests.ts) ---------------------------------------------------
export interface ParsedRequest { country: string; iso: string; city: string; mode: Mode; pallets: string; weight: string; size: string; ready: string; pickup: string; found: string[]; missing: string[] }
const cityIndex = (() => {
  let m: Map<string, string[]> | null = null;
  return () => {
    if (m) return m;
    m = new Map();
    for (const r of cityList as [string, string, number, number][]) { const k = r[1]; const names = m.get(k) ?? []; names.push(r[0]); m.set(k, names); }
    return m;
  };
})();
// Turkish names of the cities a request often names (the city list holds the English names)
const CITY_TR: Record<string, [string, string]> = {
  selanik: ['GR', 'Selanik'], atina: ['GR', 'Atina'], londra: ['GB', 'Londra'], viyana: ['AT', 'Viyana'], varsova: ['PL', 'Varşova'], bukres: ['RO', 'Bükreş'], belgrad: ['RS', 'Belgrad'], budapeste: ['HU', 'Budapeşte'],
  prag: ['CZ', 'Prag'], roma: ['IT', 'Roma'], munih: ['DE', 'Münih'], kolon: ['DE', 'Köln'], milano: ['IT', 'Milano'], cenevre: ['CH', 'Cenevre'], moskova: ['RU', 'Moskova'], kahire: ['EG', 'Kahire'], sofya: ['BG', 'Sofya'],
  uskup: ['MK', 'Üsküp'], saraybosna: ['BA', 'Saraybosna'], tiran: ['AL', 'Tiran'], pristine: ['XK', 'Priştine'], kisinev: ['MD', 'Kişinev'], kiev: ['UA', 'Kiev'], lizbon: ['PT', 'Lizbon'], bruksel: ['BE', 'Brüksel'],
  kopenhag: ['DK', 'Kopenhag'], stokholm: ['SE', 'Stokholm'], hamburg: ['DE', 'Hamburg'], berlin: ['DE', 'Berlin'], paris: ['FR', 'Paris'], madrid: ['ES', 'Madrid'], barselona: ['ES', 'Barselona'], amsterdam: ['NL', 'Amsterdam'],
};
export function parseRequest(text: string, today = new Date()): ParsedRequest {
  const t = text.toLowerCase().replace(/İ/g, 'i');
  const f: ParsedRequest = { country: '', iso: '', city: '', mode: 'Karayolu', pallets: '', weight: '', size: '', ready: '', pickup: 'Bursa, Türkiye', found: [], missing: [] };
  // the destination: the first country named in the text that is not Turkey; then a city of that country
  const words = asc(text).replace(/[^a-z0-9' ]+/g, ' ').split(/\s+/).filter(Boolean);
  const idx = buildIndex().filter((e) => e.kind === 'country' && e.iso !== 'TR');
  for (let n = 3; n >= 1 && !f.iso; n--) for (let i = 0; i + n <= words.length && !f.iso; i++) {
    const chunk = squash(words.slice(i, i + n).join(' ').replace(/'.*$/, ''));
    const hit = idx.find((e) => e.key === chunk);
    if (hit) { f.iso = hit.iso!; f.country = hit.name; }
  }
  // a two-letter country code ("Varış: SA", "Destination: DE")
  if (!f.iso) { const c = /(?:varis|destination|to|ulke|country)\s*[:=-]?\s*([a-z]{2})(?![a-z])/.exec(asc(text)); const iso = c ? c[1].toUpperCase() : ''; if (iso && iso !== 'TR' && allCountries().some((x) => x.iso === iso)) { f.iso = iso; f.country = countryName(iso); } }
  const cities = new Map<string, string>(); // squash(city) -> iso
  for (const [iso, names] of cityIndex()) for (const n of names) if (!cities.has(squash(n))) cities.set(squash(n), iso);
  for (let n = 3; n >= 1 && !f.city; n--) for (let i = 0; i + n <= words.length && !f.city; i++) {
    const chunk = squash(words.slice(i, i + n).join(' ').replace(/'.*$/, ''));
    const iso = cities.get(chunk);
    if (iso && iso !== 'TR' && (!f.iso || f.iso === iso)) { f.city = [...(cityIndex().get(iso) ?? [])].find((c) => squash(c) === chunk) ?? chunk; f.iso = iso; f.country = countryName(iso); }
  }
  if (!f.city) {
    for (let n = 2; n >= 1 && !f.city; n--) for (let i = 0; i + n <= words.length && !f.city; i++) {
      const hit = CITY_TR[squash(words.slice(i, i + n).join(' ').replace(/'.*$/, ''))];
      if (hit && (!f.iso || f.iso === hit[0])) { f.city = hit[1]; f.iso = hit[0]; f.country = countryName(hit[0]); }
    }
  }
  let m = /(\d+)\s*(pallets?|palet|plt)/.exec(t); if (m) f.pallets = m[1];
  m = /(\d{1,3}(?:[.,]\d{3})+|\d+)\s*kg/.exec(t); if (m) f.weight = m[1].replace(/[.,](?=\d{3}\b)/g, '');
  m = /(\d{2,3})\s*[x×]\s*(\d{2,3})(?:\s*[x×]\s*(\d{2,3}))?\s*(cm)?/.exec(t); if (m) f.size = `${m[1]} x ${m[2]}${m[3] ? ` x ${m[3]}` : ''} cm`;
  const mode = modesOf(t)[0]; if (mode) f.mode = mode;
  const d = new Date(today);
  const fmt = (x: Date) => x.toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric', weekday: 'long' });
  if (/ready for (shipment|dispatch|loading)|sevke hazir|sevke hazır|hemen hazir|hemen hazır|ready now/.test(t)) f.ready = 'Sevke hazır';
  else if (/pazartesi|monday/.test(t)) { d.setDate(d.getDate() + ((8 - d.getDay()) % 7 || 7)); f.ready = fmt(d); }
  else if (/yarın|tomorrow/.test(t)) { d.setDate(d.getDate() + 1); f.ready = fmt(d); }
  else if (/bugün|today/.test(t)) f.ready = fmt(d);
  // a date like 12.11 or 12/11 (a weight like 28.145 kg is not a date)
  else if ((m = /(?<![\d.,])(\d{1,2})[./](\d{1,2})(?![\d])(?:[./](\d{2,4}))?/.exec(t.replace(/\d{1,3}(?:[.,]\d{3})+\s*kg/g, ' ')))) f.ready = `${m[1]}.${m[2]}`;
  for (const k of ['country', 'city', 'pallets', 'weight', 'size', 'ready'] as const) (f[k] ? f.found : f.missing).push(k);
  return f;
}
