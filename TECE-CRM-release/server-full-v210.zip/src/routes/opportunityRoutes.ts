import { Router } from 'express';
import { db } from '../db/connection';
import { requireAdmin, requireAuth, type AuthedRequest } from '../middleware/auth';
import { cardModel } from '../models/cardModel';
import { canSeeCard } from '../services/visibility';
import { addOpportunity, expectedDays, followUpDays, followUps, oppsOfCard, overview, reviewerIds, reviewThreshold, sapCandidates, setOppSettings, setReviewerIds, snooze, updateOpportunity, type Opp } from '../services/opportunities';
import { audit } from '../services/audit';
import { userModel } from '../models/userModel';

// Opportunities (offers and proformas followed to a result), the reminders, the forecast, and the price reviews for Abdullah.
const router = Router();
router.use(requireAuth);

function cardOf(req: AuthedRequest, res: import('express').Response, id: unknown) {
  const c = cardModel.findById(parseInt(String(id), 10));
  if (!c) { res.status(404).json({ error: 'Customer not found' }); return null; }
  if (!canSeeCard(req.user, c)) { res.status(403).json({ error: 'You do not have access to this record' }); return null; }
  return c;
}
function oppOf(req: AuthedRequest, res: import('express').Response) {
  const o = db.prepare('SELECT * FROM opportunities WHERE id = ?').get(parseInt(String(req.params.id), 10)) as unknown as Opp | undefined;
  if (!o) { res.status(404).json({ error: 'Not found' }); return null; }
  return cardOf(req, res, o.card_id) ? o : null;
}

router.get('/card/:cardId', (req: AuthedRequest, res) => { const c = cardOf(req, res, req.params.cardId); if (c) res.json({ rows: oppsOfCard(c.id) }); });
router.post('/card/:cardId', (req: AuthedRequest, res) => {
  const c = cardOf(req, res, req.params.cardId);
  if (!c) return;
  const title = String(req.body?.title ?? '').trim();
  if (!title) return res.status(400).json({ error: 'Write what it is (for example "Offer PVC 22 mm").' });
  const id = addOpportunity({ cardId: c.id, kind: 'other', title, value: Number(req.body?.value) || null, currency: req.body?.currency, expected: req.body?.expected_date, userId: req.user!.id, note: req.body?.note });
  res.status(201).json({ id, rows: oppsOfCard(c.id) });
});
router.patch('/:id', (req: AuthedRequest, res) => {
  const o = oppOf(req, res);
  if (!o) return;
  updateOpportunity(o.id, (req.body ?? {}) as Record<string, unknown>, req.user!);
  res.json({ rows: oppsOfCard(o.card_id) });
});
router.delete('/:id', (req: AuthedRequest, res) => {
  const o = oppOf(req, res);
  if (!o) return;
  db.prepare('DELETE FROM opportunities WHERE id = ?').run(o.id);
  res.json({ rows: oppsOfCard(o.card_id) });
});
router.post('/:id/snooze', (req: AuthedRequest, res) => { const o = oppOf(req, res); if (!o) return; snooze(o.id, Number(req.body?.days) || 7); res.json({ ok: true }); });
router.get('/:id/sap-candidates', (req: AuthedRequest, res) => { const o = oppOf(req, res); if (o) res.json({ rows: sapCandidates(o) }); });

router.get('/follow-ups', (req: AuthedRequest, res) => res.json({ rows: followUps(req.user!), days: followUpDays() }));
router.get('/overview', (req: AuthedRequest, res) => res.json(overview(req.user!)));
router.get('/settings', (_req, res) => res.json({ followUpDays: followUpDays(), expectedDays: expectedDays(), reviewPct: reviewThreshold() }));
router.put('/settings', requireAdmin, (req, res) => { setOppSettings(Number(req.body?.followUpDays) || followUpDays(), Number(req.body?.expectedDays) || expectedDays()); res.json({ ok: true }); });

// ---- price reviews: only the people who are named see and close them
const isReviewer = (req: AuthedRequest) => reviewerIds().includes(req.user!.id);
router.get('/reviews', (req: AuthedRequest, res) => {
  if (!isReviewer(req)) return res.json({ rows: [], reviewer: false });
  const rows = db.prepare(`SELECT r.id, r.card_id AS cardId, COALESCE(c.company, c.name) AS customer, c.country, r.created_at AS at, r.index_pct AS indexPct, r.gap, r.currency, r.goods, r.note, r.reviewed_at AS reviewedAt, r.review_note AS reviewNote,
      (SELECT display_name FROM users WHERE id = r.created_by) AS by FROM price_reviews r JOIN cards c ON c.id = r.card_id ORDER BY (r.reviewed_at IS NOT NULL), r.id DESC LIMIT 100`).all();
  res.json({ rows, reviewer: true });
});
router.post('/reviews/:id/done', (req: AuthedRequest, res) => {
  if (!isReviewer(req)) return res.status(403).json({ error: 'Only the person who reviews prices can close a review.' });
  const r = db.prepare('SELECT card_id FROM price_reviews WHERE id = ?').get(parseInt(String(req.params.id), 10)) as { card_id: number } | undefined;
  if (!r) return res.status(404).json({ error: 'Not found' });
  db.prepare("UPDATE price_reviews SET reviewed_at = datetime('now'), reviewed_by = ?, review_note = ? WHERE id = ?").run(req.user!.id, String(req.body?.note ?? '').slice(0, 300) || null, parseInt(String(req.params.id), 10));
  audit(req.user, r.card_id, 'review', 'Price review', 'open', 'reviewed', String(req.body?.note ?? '').slice(0, 200) || null);
  res.json({ ok: true });
});
router.get('/reviewers', requireAdmin, (_req, res) => res.json({ ids: reviewerIds(), users: userModel.listAll().filter((u) => u.is_active && !u.area && u.display_name).map((u) => ({ id: u.id, name: u.display_name })) }));
router.put('/reviewers', requireAdmin, (req, res) => { setReviewerIds((Array.isArray(req.body?.ids) ? req.body.ids : []).map(Number)); res.json({ ids: reviewerIds() }); });

export default router;
