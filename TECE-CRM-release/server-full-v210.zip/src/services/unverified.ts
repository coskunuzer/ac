import crypto from 'crypto';
import ExcelJS from 'exceljs';
import { db } from '../db/connection';
import { cardModel, type CardRow } from '../models/cardModel';
import { visibilitySql, type Viewer } from './visibility';
import { moveToJunk } from './junk';
import { audit } from './audit';

// Unverified customers: records that are just a name (no e-mail, no web site, no phone, no SAP number, no orders, no offers, nobody wrote a
// note or called). An admin or the brand manager downloads them as an Excel file, deletes the rows of the companies that do not exist,
// fills an e-mail / web site / phone for the ones that do, and uploads the file back. Nothing happens before a preview is confirmed, and a
// deleted customer goes to the junk folder (services/junk.ts), from where it can be brought back.

export const RULE_KEYS = ['email', 'web', 'phone', 'sap', 'orders', 'offers', 'contacts', 'activity'] as const;
export type RuleKey = (typeof RULE_KEYS)[number];
export interface Criteria { rules: Record<RuleKey, boolean>; market: '' | 'export' | 'domestic'; country: string; source: string; before: string }

const empty = (col: string) => `TRIM(COALESCE(cards.${col}, '')) = ''`;
const none = (sql: string) => `NOT EXISTS (${sql})`;
// the work of a person (or something sent to the customer): a record with any of it is real
// (scan = a business card scanned at a fair, stage/rated = a person moved or rated it, merged = a person merged a duplicate into it)
const HUMAN = "'note','call','visit','meeting','sample','email','whatsapp','offer','documents','thank_you','bulgaria','file','scan','stage','rated','merged'";
const LEAD_SAP = "(json_valid(cards.lead_info) AND TRIM(COALESCE(json_extract(cards.lead_info, '$.sap'), '')) != '')";

const RULE_SQL: Record<RuleKey, string> = {
  email: empty('email'),
  web: empty('website'),
  phone: `${empty('tel')} AND ${empty('mobile')} AND ${empty('fax')}`,
  sap: `${empty('sap')} AND NOT ${LEAD_SAP}`,
  orders: [
    "COALESCE(cards.stage, 'lead') IN ('lead', 'contacted', 'lost')",
    none('SELECT 1 FROM customer_aliases x WHERE x.card_id = cards.id'),
    none('SELECT 1 FROM opportunities x WHERE x.card_id = cards.id'),
    none('SELECT 1 FROM proformas x WHERE x.card_id = cards.id'),
    none('SELECT 1 FROM document_archive x WHERE x.card_id = cards.id'),
    none('SELECT 1 FROM customer_prices x WHERE x.card_id = cards.id'),
    none('SELECT 1 FROM customer_price_docs x WHERE x.card_id = cards.id'),
    none('SELECT 1 FROM ship_requests x WHERE x.card_id = cards.id'),
    none('SELECT 1 FROM ship_asks x WHERE x.card_id = cards.id'),
  ].join(' AND '),
  offers: [
    none('SELECT 1 FROM offers_sent x WHERE x.card_id = cards.id'),
    none('SELECT 1 FROM sent_emails x WHERE x.card_id = cards.id'),
    none('SELECT 1 FROM newsletter_recipients x WHERE x.card_id = cards.id'),
  ].join(' AND '),
  contacts: none("SELECT 1 FROM card_contacts x WHERE x.card_id = cards.id AND (TRIM(COALESCE(x.email, '')) != '' OR TRIM(COALESCE(x.tel, '')) != '' OR TRIM(COALESCE(x.mobile, '')) != '')"),
  activity: [
    none(`SELECT 1 FROM activities x WHERE x.card_id = cards.id AND x.type IN (${HUMAN})`),
    none('SELECT 1 FROM meetings x WHERE x.card_id = cards.id'),
    none('SELECT 1 FROM todos x WHERE x.card_id = cards.id'),
    none('SELECT 1 FROM trip_stops x WHERE x.card_id = cards.id'),
    none('SELECT 1 FROM card_samples x WHERE x.card_id = cards.id'),
    // other work of a person on it: a complaint, an issue, an expense, a brand board, a watch list, a competitor or a price review
    none('SELECT 1 FROM complaints x WHERE x.card_id = cards.id'),
    none('SELECT 1 FROM internal_issues x WHERE x.card_id = cards.id'),
    none('SELECT 1 FROM budget_expenses x WHERE x.card_id = cards.id'),
    none('SELECT 1 FROM card_boards x WHERE x.card_id = cards.id'),
    none('SELECT 1 FROM watch_items x WHERE x.card_id = cards.id'),
    none('SELECT 1 FROM card_suppliers x WHERE x.card_id = cards.id'),
    none('SELECT 1 FROM price_reviews x WHERE x.card_id = cards.id'),
  ].join(' AND '),
};

const SOURCE_SQL = "COALESCE(NULLIF(TRIM(cards.lead_source), ''), NULLIF(TRIM(cards.source), ''), (SELECT e.name FROM exhibitions e WHERE e.id = cards.exhibition_id), '')";
const RATING_SQL = "COALESCE(cards.rate, CASE WHEN cards.ai_rate_source = 'ai' THEN cards.ai_rate END)";

export function cleanCriteria(input: unknown): Criteria {
  const o = (input && typeof input === 'object' ? input : {}) as Record<string, unknown>;
  const r = (o.rules && typeof o.rules === 'object' ? o.rules : {}) as Record<string, unknown>;
  const rules = Object.fromEntries(RULE_KEYS.map((k) => [k, r[k] !== false])) as Record<RuleKey, boolean>;
  const str = (v: unknown, n = 120) => (typeof v === 'string' ? v.trim().slice(0, n) : '');
  const market = o.market === 'export' || o.market === 'domestic' ? o.market : '';
  const before = /^\d{4}-\d{2}-\d{2}$/.test(str(o.before)) ? str(o.before) : '';
  return { rules, market, country: str(o.country), source: str(o.source), before };
}

// who may use the tool: an admin, or the brand manager (users.area = 'brand', or the 'brand' preset of the Permissions page). Not an assistant.
export function mayUse(user: { role: string; area?: string | null; perms?: { preset: string | null } | null } | undefined, actor?: unknown): boolean {
  if (!user || actor) return false;
  return user.role === 'admin' || user.area === 'brand' || user.perms?.preset === 'brand';
}

// the brand manager works on the customers they may see (the rule of the whole app) and the ones they brought in; an admin on everybody
function scopeSql(viewer: Viewer, params: Record<string, string | number>): string {
  if (viewer.role === 'admin') return '1=1';
  const vis = visibilitySql(viewer, params);
  params.uvMe = viewer.id;
  return `(${vis ?? '1=1'} OR cards.uploaded_by = @uvMe)`;
}

function whereOf(viewer: Viewer, c: Criteria, params: Record<string, string | number>, withFilters = true): string {
  const parts = [scopeSql(viewer, params)];
  for (const k of RULE_KEYS) if (c.rules[k]) parts.push(`(${RULE_SQL[k]})`);
  if (withFilters) {
    if (c.market) { parts.push(c.market === 'domestic' ? "cards.market = 'domestic'" : "cards.market != 'domestic'"); }
    if (c.country) { parts.push('cards.country = @uvCountry'); params.uvCountry = c.country; }
    if (c.source) { parts.push(`${SOURCE_SQL} = @uvSource`); params.uvSource = c.source; }
    if (c.before) { parts.push('cards.created_at < @uvBefore'); params.uvBefore = c.before; }
  }
  return parts.join(' AND ');
}

const COLS = `cards.id, cards.company, TRIM(COALESCE(cards.name, '') || ' ' || COALESCE(cards.last_name, '')) AS name, cards.country, cards.city, ${SOURCE_SQL} AS source,
  cards.created_at, cards.person AS owner, cards.updated_at, cards.market, cards.email, cards.website, cards.tel`;
interface ListRow { id: number; company: string | null; name: string; country: string | null; city: string | null; source: string; created_at: string; owner: string | null; updated_at: string; market: string; email: string | null; website: string | null; tel: string | null }

export function summary(viewer: Viewer, c: Criteria) {
  const p: Record<string, string | number> = {};
  const where = whereOf(viewer, c, p);
  const count = (db.prepare(`SELECT COUNT(*) AS n FROM cards WHERE ${where}`).get(p) as { n: number }).n;
  const sample = db.prepare(`SELECT ${COLS} FROM cards WHERE ${where} ORDER BY cards.created_at, cards.id LIMIT 12`).all(p) as unknown as ListRow[];
  // the choices of the filters: from the list without its own filters (only the rules), so a filter never hides its own choices
  const q: Record<string, string | number> = {};
  const base = whereOf(viewer, c, q, false);
  const all = (db.prepare(`SELECT COUNT(*) AS n FROM cards WHERE ${base}`).get(q) as { n: number }).n;
  const countries = db.prepare(`SELECT cards.country AS v, COUNT(*) AS n FROM cards WHERE ${base} AND TRIM(COALESCE(cards.country, '')) != '' GROUP BY cards.country ORDER BY n DESC LIMIT 150`).all(q) as { v: string; n: number }[];
  const sources = db.prepare(`SELECT ${SOURCE_SQL} AS v, COUNT(*) AS n FROM cards WHERE ${base} GROUP BY v HAVING v != '' ORDER BY n DESC LIMIT 60`).all(q) as { v: string; n: number }[];
  // of the list, how many could never be deleted by the file (kept in any case)
  const keptAnyway = (db.prepare(`SELECT COUNT(*) AS n FROM cards WHERE ${where} AND (${protectSql()})`).get(p) as { n: number }).n;
  const recent = db.prepare(`SELECT b.id, b.created_at, b.row_count, b.applied_at, b.result, u.display_name AS by_name FROM unverified_batches b LEFT JOIN users u ON u.id = b.created_by
    WHERE ${viewer.role === 'admin' ? '1=1' : 'b.created_by = @me'} ORDER BY b.id DESC LIMIT 6`).all(viewer.role === 'admin' ? {} : { me: viewer.id }) as { id: number; created_at: string; row_count: number; applied_at: string | null; result: string | null; by_name: string | null }[];
  return {
    count, all, keptAnyway, sample, countries, sources,
    recent: recent.map((r) => ({ ...r, result: r.result ? JSON.parse(r.result) : null })),
    scope: viewer.role === 'admin' ? 'everybody' : 'mine',
  };
}

// ---- the rules that keep a customer whatever the file says (checked again at the moment of deleting)
// a customer with a way to reach it is never deleted by a missing row, even when the rules were widened (unticked) for the list
const CONTACT_SQL = `${RULE_SQL.email} AND ${RULE_SQL.web} AND ${RULE_SQL.phone} AND ${RULE_SQL.contacts}`;
function protectSql(): string {
  return [
    'cards.delete_locked = 1',
    `NOT (${RULE_SQL.sap})`,
    `NOT (${RULE_SQL.orders})`,
    `NOT (${RULE_SQL.offers})`,
    `NOT (${RULE_SQL.activity})`,
    `${RATING_SQL} >= 5`,
    `NOT (${CONTACT_SQL})`,
  ].join(' OR ');
}
const REASONS: [string, string][] = [
  ['cards.delete_locked = 1', 'Locked by the admin who uploaded it'],
  [`NOT (${RULE_SQL.sap})`, 'Has a SAP number'],
  [`NOT (${RULE_SQL.orders})`, 'Has orders, a deal or prices'],
  [`NOT (${RULE_SQL.offers})`, 'An offer or an e-mail was sent'],
  [`NOT (${RULE_SQL.activity})`, 'Somebody worked on it (note, call, visit, task)'],
  [`${RATING_SQL} >= 5`, 'Rated 5 or higher'],
  [`NOT (${CONTACT_SQL})`, 'Has an e-mail, a web site, a phone or a contact person'],
];
const reasonStmt = () => db.prepare(`SELECT ${REASONS.map(([sql], i) => `CASE WHEN ${sql} THEN 1 ELSE 0 END AS r${i}`).join(', ')}, cards.updated_at FROM cards WHERE cards.id = ?`);
function protectReason(stmt: ReturnType<typeof reasonStmt>, id: number, downloadedAt: string | null, visible: ((id: number) => boolean) | null): string | null {
  const r = stmt.get(id) as Record<string, number | string> | undefined;
  if (!r) return 'gone';
  for (let i = 0; i < REASONS.length; i += 1) if (r[`r${i}`]) return REASONS[i][1];
  if (downloadedAt && String(r.updated_at ?? '') > downloadedAt) return 'Changed after the list was downloaded';
  if (visible && !visible(id)) return 'Not one of the customers you may see';
  return null;
}

// ---- download
const MAX_ROWS = 20000;
const HEAD = ['ID', 'Company', 'Name', 'Country', 'City', 'Source', 'Created', 'Owner', 'E-mail', 'Website', 'Phone', 'Note'];
// the file in the language of the person who downloads it (the upload reads both sets of titles)
const HEAD_TR = ['ID', 'Firma', 'Kişi', 'Ülke', 'Şehir', 'Kaynak', 'Oluşturma', 'Sorumlu', 'E-posta', 'Web sitesi', 'Telefon', 'Not'];
const HEAD_KEY = ['id', 'company', 'name', 'country', 'city', 'source', 'created', 'owner', 'email', 'website', 'phone', 'note'];
const SHEETS = { en: { readme: 'README', list: 'Customers' }, tr: { readme: 'BENİOKU', list: 'Müşteriler' } };
const istanbul = (utc: string) => { const d = new Date(`${utc.replace(' ', 'T')}Z`); return isNaN(d.getTime()) ? utc : new Intl.DateTimeFormat('tr-TR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', timeZone: 'Europe/Istanbul' }).format(d).replace(',', ''); };

export async function download(viewer: Viewer, c: Criteria, lang: 'en' | 'tr' = 'en'): Promise<{ buffer: Buffer; batchId: number; rows: number }> {
  const tr = lang === 'tr';
  const H = tr ? HEAD_TR : HEAD;
  const p: Record<string, string | number> = {};
  const rows = db.prepare(`SELECT ${COLS} FROM cards WHERE ${whereOf(viewer, c, p)} ORDER BY cards.country, cards.company, cards.id LIMIT ${MAX_ROWS}`).all(p) as unknown as ListRow[];
  if (!rows.length) return { buffer: Buffer.alloc(0), batchId: 0, rows: 0 }; // nothing to download: no batch is kept
  const token = crypto.randomBytes(12).toString('hex');
  let batchId = 0;
  db.exec('BEGIN');
  try {
    batchId = Number(db.prepare('INSERT INTO unverified_batches (token, created_by, criteria, row_count) VALUES (?, ?, ?, ?)').run(token, viewer.id, JSON.stringify(c), rows.length).lastInsertRowid);
    const ins = db.prepare('INSERT INTO unverified_batch_cards (batch_id, card_id, company, updated_at) VALUES (?, ?, ?, ?)');
    for (const r of rows) ins.run(batchId, r.id, r.company ?? r.name ?? '', r.updated_at);
    db.exec('COMMIT');
  } catch (err) { db.exec('ROLLBACK'); throw err; }
  const stamp = (db.prepare('SELECT created_at FROM unverified_batches WHERE id = ?').get(batchId) as { created_at: string }).created_at;

  const wb = new ExcelJS.Workbook();
  wb.creator = 'TECE CRM';
  wb.created = new Date();
  const readme = wb.addWorksheet(SHEETS[lang].readme, { properties: { tabColor: { argb: 'FF8B1931' } } });
  const ws = wb.addWorksheet(SHEETS[lang].list, { views: [{ state: 'frozen', ySplit: 1, xSplit: 2 }] });
  const meta = wb.addWorksheet('_batch');
  meta.state = 'veryHidden';
  meta.addRow(['token', token]);
  meta.addRow(['batch', batchId]);
  meta.addRow(['rows', rows.length]);

  const widths = [9, 34, 22, 16, 16, 20, 12, 18, 28, 26, 18, 34];
  ws.columns = H.map((h, i) => ({ header: h, key: HEAD[i], width: widths[i] }));
  const head = ws.getRow(1);
  head.font = { bold: true, color: { argb: 'FFFFFFFF' } };
  head.height = 22;
  H.forEach((h, i) => {
    const cell = head.getCell(i + 1);
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: i >= 8 ? 'FF1D6B4F' : i === 0 ? 'FF555555' : 'FF36589D' } };
    cell.alignment = { vertical: 'middle' };
  });
  for (const r of rows) {
    const row = ws.addRow([r.id, r.company ?? '', r.name ?? '', r.country ?? '', r.city ?? '', r.source ?? '', (r.created_at ?? '').slice(0, 10), r.owner ?? '', '', '', '', '']);
    const id = row.getCell(1);
    id.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE8E8E8' } };
    id.font = { color: { argb: 'FF555555' } };
    // the number cannot be typed over (Excel says no); the whole row can still be deleted
    id.dataValidation = { type: 'whole', operator: 'equal', formulae: [r.id], allowBlank: false, showErrorMessage: true, errorStyle: 'stop', errorTitle: tr ? 'ID değiştirilmez' : 'Do not change the ID', error: tr ? 'ID, bu satırın hangi müşteri olduğunu CRM\'e söyler. Müşteriyi silmek için satırın tamamını silin.' : 'The ID tells the CRM which customer this row is. To delete the customer, delete the whole row.' };
    for (let i = 9; i <= 12; i += 1) row.getCell(i).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFEFF7F1' } };
  }
  ws.autoFilter = { from: { row: 1, column: 1 }, to: { row: 1, column: HEAD.length } };

  readme.getColumn(1).width = 110;
  const lines: [string, Partial<ExcelJS.Font>?][] = tr ? [
    ['Doğrulanmamış müşteriler - bu dosya nasıl çalışır', { bold: true, size: 16, color: { argb: 'FF8B1931' } }],
    [`İndirildi ${istanbul(stamp)} (İstanbul saati) · ${rows.length} müşteri · liste #${batchId} · dosya kodu ${token}`, { color: { argb: 'FF666666' } }],
    [''],
    ['Bu müşteriler yalnızca bir isim: e-posta, web sitesi, telefon, SAP numarası, sipariş, teklif yok ve kimse üzerinde çalışmadı.', {}],
    [''],
    ['1. Bir müşteriyi silmek için SATIRI SİLİN (yoksa ya da gerçek bir firma değilse).', { bold: true }],
    ['2. Müşteriyi tutup tamamlamak için yeşil sütunları (E-posta, Web sitesi, Telefon) DOLDURUN. Müşterinin zaten olan bir bilgisinin üzerine asla yazılmaz.', { bold: true }],
    ['3. Not sütununa yazılan bir NOT müşteriye not olarak eklenir.', { bold: true }],
    ['4. Müşteriyi değiştirmeden tutmak için satırı olduğu gibi bırakın.', { bold: true }],
    ['5. Dosyayı "Doğrulanmamış müşteriler" sayfasından yükleyin. Hiçbir şey yapılmadan önce tam olarak ne olacağını görürsünüz.', { bold: true }],
    [''],
    ['Güvenlik', { bold: true, size: 13 }],
    ['- ID sütununu değiştirmeyin ve satır eklemeyin: CRM her müşteriyi ID\'sinden tanır.', {}],
    ['- Yalnızca BU dosyadaki müşteriler silinebilir. İndirmeden sonra eklenen müşterilere hiç dokunulmaz.', {}],
    ['- Üzerinde çalışılmış, 5 veya üzeri puanlı, SAP numaralı, siparişi ya da teklifi olan veya bir yöneticinin kilitlediği müşteri asla silinmez.', {}],
    ['- Bu indirmeden sonra CRM\'de değiştirilen müşteri tutulur.', {}],
    ['- Silinen müşteriler çöp kutusuna gider; bir yönetici onları geri getirebilir.', {}],
    ['- Bu dosya bir kez yüklenebilir. Yeni bir tur için yeni bir liste indirin.', {}],
  ] : [
    ['Unverified customers - how this file works', { bold: true, size: 16, color: { argb: 'FF8B1931' } }],
    [`Downloaded ${stamp} UTC · ${rows.length} customers · list #${batchId} · file code ${token}`, { color: { argb: 'FF666666' } }],
    [''],
    ['These customers are just a name: no e-mail, no web site, no phone, no SAP number, no orders, no offers and nobody worked on them.', {}],
    [''],
    ['1. DELETE A ROW to delete that customer (it does not exist, or it is not a real company).', { bold: true }],
    ['2. FILL the green columns (E-mail, Website, Phone) to keep a customer and complete it. A value the customer already has is never overwritten.', { bold: true }],
    ['3. A NOTE in the Note column is added to the customer as a note.', { bold: true }],
    ['4. Leave a row as it is to keep the customer unchanged.', { bold: true }],
    ['5. Upload the file on the "Unverified customers" page. You will see exactly what will happen before anything is done.', { bold: true }],
    [''],
    ['Safety', { bold: true, size: 13 }],
    ['- Do not change the ID column, and do not add rows: the CRM recognises each customer by its ID.', {}],
    ['- Only customers that are in THIS file can be deleted. Customers added after the download are never touched.', {}],
    ['- A customer that somebody worked on, rated 5 or higher, with a SAP number, orders or offers, or locked by an admin, is never deleted.', {}],
    ['- A customer that was changed in the CRM after this download is kept.', {}],
    ['- Deleted customers go to the junk folder, where an admin can bring them back.', {}],
    ['- This file can be uploaded once. For a new round, download a new list.', {}],
  ];
  for (const [text, font] of lines) { const row = readme.addRow([text]); if (font) row.getCell(1).font = font; row.getCell(1).alignment = { wrapText: true, vertical: 'top' }; }
  wb.views = [{ x: 0, y: 0, width: 20000, height: 12000, firstSheet: 0, activeTab: 1, visibility: 'visible' }];
  const buffer = Buffer.from(await wb.xlsx.writeBuffer());
  return { buffer, batchId, rows: rows.length };
}

// ---- upload: read the file back and work out what would happen (nothing is changed here)
const cellText = (v: ExcelJS.CellValue): string => {
  if (v === null || v === undefined) return '';
  if (typeof v === 'object') {
    if (v instanceof Date) return v.toISOString().slice(0, 10);
    const o = v as unknown as Record<string, unknown>;
    if ('result' in o) return cellText(o.result as ExcelJS.CellValue);
    if ('text' in o) return cellText(o.text as ExcelJS.CellValue);
    if ('hyperlink' in o) return String(o.hyperlink ?? '');
    if (Array.isArray(o.richText)) return (o.richText as { text: string }[]).map((x) => x.text).join('');
    return '';
  }
  return String(v).trim();
};
const norm = (s: string | null | undefined) => (s ?? '').toLowerCase().normalize('NFKD').replace(/[^\p{L}\p{N}]+/gu, '');
const EMAIL = /^[^\s@,;]+@[^\s@,;]+\.[^\s@,;]{2,}$/;
const cleanWeb = (s: string) => {
  const t = s.trim().replace(/\s+/g, '');
  if (!t || !/^[^\s]+\.[a-z]{2,}(\/.*)?$/i.test(t.replace(/^https?:\/\//i, ''))) return null;
  return /^https?:\/\//i.test(t) ? t : `https://${t}`;
};
const cleanPhone = (s: string) => { const t = s.trim(); return t.replace(/[^\d]/g, '').length >= 6 ? t.slice(0, 40) : null; };

export interface Plan {
  previewId: string; batchId: number; downloadedAt: string; downloadedBy: string | null; userId: number;
  fileRows: number; batchRows: number;
  kept: number; enrich: { id: number; company: string; fields: { field: string; value: string }[]; skipped: string[] }[];
  notes: { id: number; company: string; text: string }[];
  toDelete: { id: number; company: string; country: string | null }[];
  protectedRows: { id: number; company: string; reason: string }[];
  ignored: { row: number; id: string; company: string; reason: string }[];
  gone: number; missingShare: number; needConfirm: number | null; warnings: string[];
}
const previews = new Map<string, { plan: Plan; at: number }>();
const PREVIEW_TTL = 60 * 60 * 1000;
const BATCH_DAYS = 30;

export class UvError extends Error { constructor(public status: number, msg: string) { super(msg); } }

export async function preview(viewer: Viewer, file: Buffer): Promise<Plan> {
  const wb = new ExcelJS.Workbook();
  try { await wb.xlsx.load(file as unknown as ArrayBuffer); } catch { throw new UvError(400, 'This is not an Excel (.xlsx) file. Upload the file you downloaded here.'); }
  // which download the file comes from: the hidden sheet, or the code on the README sheet
  let token = '';
  const meta = wb.getWorksheet('_batch');
  if (meta) meta.eachRow((row) => { if (cellText(row.getCell(1).value) === 'token') token = cellText(row.getCell(2).value); });
  if (!token) { const rd = wb.getWorksheet('README') ?? wb.getWorksheet(SHEETS.tr.readme); rd?.eachRow((row) => { const m = /(?:file code|dosya kodu) ([a-f0-9]{24})/.exec(cellText(row.getCell(1).value)); if (m) token = m[1]; }); }
  if (!token) throw new UvError(400, 'This file was not downloaded from this page (its file code is missing). Download the list here, change it, and upload that file.');
  const batch = db.prepare(`SELECT b.*, u.display_name AS by_name, CAST(julianday('now') - julianday(b.created_at) AS REAL) AS age FROM unverified_batches b LEFT JOIN users u ON u.id = b.created_by WHERE b.token = ?`).get(token) as { id: number; created_by: number; created_at: string; row_count: number; applied_at: string | null; by_name: string | null; age: number } | undefined;
  if (!batch) throw new UvError(400, 'This file comes from a download this CRM does not know. Download a new list.');
  if (batch.applied_at) throw new UvError(409, `This file was already used on ${batch.applied_at.slice(0, 16)} UTC. Download a new list for the next round.`);
  if (batch.age > BATCH_DAYS) throw new UvError(409, `This file was downloaded ${Math.floor(batch.age)} days ago - too old to delete anything safely. Download a new list.`);
  if (viewer.role !== 'admin' && batch.created_by !== viewer.id) throw new UvError(403, 'This list was downloaded by somebody else. Download your own list.');

  const ws = wb.getWorksheet('Customers') ?? wb.getWorksheet(SHEETS.tr.list) ?? wb.worksheets.find((w) => w.name !== 'README' && w.name !== SHEETS.tr.readme && w.state === 'visible');
  if (!ws) throw new UvError(400, 'The sheet "Customers" is missing from the file.');
  const col: Record<string, number> = {};
  ws.getRow(1).eachCell((cell, n) => { const k = norm(cellText(cell.value)); if (k) col[k] = n; });
  // the Turkish titles of a file downloaded in Turkish
  HEAD_TR.forEach((h, i) => { const k = norm(h); if (col[k] && !col[HEAD_KEY[i]]) col[HEAD_KEY[i]] = col[k]; });
  if (!col.id) throw new UvError(400, 'The ID column is missing. Keep the first row (the titles) and the ID column as they were.');
  const get = (row: ExcelJS.Row, key: string) => (col[key] ? cellText(row.getCell(col[key]).value) : '');

  const inBatch = new Map<number, { company: string; updated_at: string | null }>();
  for (const r of db.prepare('SELECT card_id, company, updated_at FROM unverified_batch_cards WHERE batch_id = ?').all(batch.id) as { card_id: number; company: string | null; updated_at: string | null }[]) inBatch.set(r.card_id, { company: r.company ?? '', updated_at: r.updated_at });

  const present = new Set<number>();
  const ignored: Plan['ignored'] = [];
  // rows whose ID cannot be trusted (cleared, not a number, not in this download, or typed over with another customer's ID): matched back
  // by the company name once every good row is read, so the customer of that row is never taken for deleted
  const rescue: { row: number; id: string; company: string; vals: Record<string, string>; useVals: boolean; reason: string }[] = [];
  const edits = new Map<number, Record<string, string>>();
  let fileRows = 0;
  ws.eachRow((row, n) => {
    if (n === 1) return;
    const vals = { company: get(row, 'company'), email: get(row, 'email'), website: get(row, 'website'), phone: get(row, 'phone'), note: get(row, 'note') };
    const idText = get(row, 'id');
    if (!idText && !Object.values(vals).some(Boolean)) return; // an empty row
    fileRows += 1;
    const id = /^\d+$/.test(idText) ? Number(idText) : NaN;
    if (!idText) { rescue.push({ row: n, id: '', company: vals.company, vals, useVals: true, reason: 'No ID and not in this download: ignored' }); return; }
    if (!Number.isFinite(id)) { rescue.push({ row: n, id: idText, company: vals.company, vals, useVals: false, reason: 'The ID is not a number' }); return; }
    const b = inBatch.get(id);
    if (!b) { rescue.push({ row: n, id: idText, company: vals.company, vals, useVals: false, reason: 'Not in this download (added or changed by hand)' }); return; }
    if (present.has(id)) { rescue.push({ row: n, id: idText, company: vals.company, vals, useVals: false, reason: 'The same ID twice: only the first row is read' }); return; }
    if (vals.company && b.company && norm(vals.company) !== norm(b.company)) {
      present.add(id); // the customer of the ID is kept (its row may have been changed by hand)
      rescue.push({ row: n, id: idText, company: vals.company, vals, useVals: false, reason: `The ID belongs to "${b.company}": the row is kept, nothing in it is used` });
      return;
    }
    present.add(id);
    edits.set(id, vals);
  });
  for (const r of rescue) {
    const hits = r.company ? [...inBatch.entries()].filter(([id, b]) => !present.has(id) && norm(b.company) === norm(r.company)) : [];
    if (hits.length === 1) {
      present.add(hits[0][0]);
      if (r.useVals) { edits.set(hits[0][0], r.vals); continue; }
      ignored.push({ row: r.row, id: r.id, company: r.company, reason: `${r.reason} - recognised by its company name: that customer is kept, nothing in the row is used` });
    } else if (hits.length > 1) {
      // several customers of the download have this name: all of them are kept (never guess which one to delete)
      for (const [id] of hits) present.add(id);
      ignored.push({ row: r.row, id: r.id, company: r.company, reason: 'Several customers have this name: all of them are kept, nothing in the row is used' });
    } else ignored.push({ row: r.row, id: r.id, company: r.company, reason: r.reason });
  }

  const enrich: Plan['enrich'] = [];
  const notes: Plan['notes'] = [];
  let gone = 0;
  for (const [id, v] of edits) {
    const card = cardModel.findById(id);
    if (!card) { gone += 1; continue; }
    const fields: { field: string; value: string }[] = [];
    const skipped: string[] = [];
    const want = (field: 'email' | 'website' | 'tel', raw: string, clean: string | null, label: string) => {
      if (!raw) return;
      if (!clean) { skipped.push(`${label}: "${raw.slice(0, 60)}" does not look right`); return; }
      const now = (card[field] ?? '').toString().trim();
      if (now) { if (norm(now) !== norm(clean)) skipped.push(`${label}: already "${now}", not overwritten`); return; }
      fields.push({ field, value: clean });
    };
    want('email', v.email, EMAIL.test(v.email.trim()) ? v.email.trim().toLowerCase().slice(0, 200) : null, 'E-mail');
    want('website', v.website, cleanWeb(v.website), 'Website');
    want('tel', v.phone, cleanPhone(v.phone), 'Phone');
    const company = card.company || card.name || `#${id}`;
    if (fields.length || skipped.length) enrich.push({ id, company, fields, skipped });
    if (v.note.trim()) notes.push({ id, company, text: v.note.trim().slice(0, 2000) });
  }

  const missing = [...inBatch.keys()].filter((id) => !present.has(id));
  const stmt = reasonStmt();
  const visible = viewerFilter(viewer);
  const toDelete: Plan['toDelete'] = [];
  const protectedRows: Plan['protectedRows'] = [];
  for (const id of missing) {
    const why = protectReason(stmt, id, inBatch.get(id)?.updated_at ?? null, visible);
    if (why === 'gone') { gone += 1; continue; }
    const card = db.prepare('SELECT company, name, country FROM cards WHERE id = ?').get(id) as { company: string | null; name: string | null; country: string | null };
    const company = card.company || card.name || `#${id}`;
    if (why) protectedRows.push({ id, company, reason: why });
    else toDelete.push({ id, company, country: card.country });
  }
  const missingShare = batch.row_count > 0 ? missing.length / batch.row_count : 0;
  const warnings: string[] = [];
  const newer = db.prepare('SELECT created_at FROM unverified_batches WHERE id > ? AND created_by = ? ORDER BY id DESC LIMIT 1').get(batch.id, batch.created_by) as { created_at: string } | undefined;
  if (newer) warnings.push(`A newer list was downloaded on ${newer.created_at.slice(0, 16)} UTC. This file is the older one (${batch.created_at.slice(0, 16)}): only its own customers can be deleted.`);
  if (missingShare > 0.6) warnings.push(`${Math.round(missingShare * 100)}% of the rows are missing from the file. If the file was cut short by mistake, do not go on.`);
  const plan: Plan = {
    previewId: crypto.randomBytes(10).toString('hex'), batchId: batch.id, downloadedAt: batch.created_at, downloadedBy: batch.by_name, userId: viewer.id,
    fileRows, batchRows: batch.row_count, kept: present.size, enrich, notes, toDelete, protectedRows, ignored, gone, missingShare,
    needConfirm: missingShare > 0.6 && toDelete.length > 0 ? toDelete.length : null, warnings,
  };
  const now = Date.now();
  for (const [k, v] of previews) if (now - v.at > PREVIEW_TTL) previews.delete(k);
  previews.set(plan.previewId, { plan, at: now });
  return plan;
}

function viewerFilter(viewer: Viewer): ((id: number) => boolean) | null {
  if (viewer.role === 'admin') return null;
  const p: Record<string, string | number> = {};
  const stmt = db.prepare(`SELECT 1 FROM cards WHERE cards.id = @uvId AND ${scopeSql(viewer, p)}`);
  return (id) => !!stmt.get({ ...p, uvId: id });
}

// ---- apply: what the preview showed, checked again, in one transaction
export function apply(viewer: Viewer & { username?: string | null }, previewId: string, confirm: unknown) {
  const hit = previews.get(previewId);
  if (!hit || Date.now() - hit.at > PREVIEW_TTL) throw new UvError(410, 'The preview has expired. Upload the file again.');
  const plan = hit.plan;
  if (plan.userId !== viewer.id) throw new UvError(403, 'This preview belongs to somebody else.');
  if (plan.needConfirm !== null && Number(confirm) !== plan.needConfirm) throw new UvError(400, `Type ${plan.needConfirm} (the number of customers that will be deleted) to confirm.`);
  const batch = db.prepare('SELECT * FROM unverified_batches WHERE id = ?').get(plan.batchId) as { id: number; applied_at: string | null } | undefined;
  if (!batch || batch.applied_at) throw new UvError(409, 'This file was already used. Download a new list.');
  const stmt = reasonStmt();
  const visible = viewerFilter(viewer);
  const updAt = new Map((db.prepare('SELECT card_id, updated_at FROM unverified_batch_cards WHERE batch_id = ?').all(plan.batchId) as { card_id: number; updated_at: string | null }[]).map((r) => [r.card_id, r.updated_at]));
  const reason = `Unverified customers: not in the uploaded list #${plan.batchId}`;
  let moved = 0; let keptNow = 0; let enriched = 0; let filled = 0; let noted = 0;
  db.exec('BEGIN');
  try {
    for (const d of plan.toDelete) {
      // checked again: somebody may have worked on it since the preview
      if (protectReason(stmt, d.id, updAt.get(d.id) ?? null, visible)) { keptNow += 1; continue; }
      const card = cardModel.findById(d.id) as CardRow;
      moveToJunk(card, reason, viewer.id, true);
      audit(viewer, d.id, 'change', 'Moved to junk', card.company || card.name, null, `Unverified list #${plan.batchId}`);
      moved += 1;
    }
    for (const e of plan.enrich) {
      if (!e.fields.length) continue;
      let any = false;
      for (const f of e.fields) {
        // never overwrite: only a field that is still empty is filled
        const r = db.prepare(`UPDATE cards SET ${f.field} = ?, updated_at = datetime('now') WHERE id = ? AND TRIM(COALESCE(${f.field}, '')) = ''`).run(f.value, e.id);
        if (Number(r.changes)) { any = true; filled += 1; audit(viewer, e.id, 'change', f.field === 'tel' ? 'Phone' : f.field === 'email' ? 'E-mail' : 'Website', null, f.value, `Unverified list #${plan.batchId}`); }
      }
      if (any) enriched += 1;
    }
    for (const n of plan.notes) {
      if (!db.prepare('SELECT 1 FROM cards WHERE id = ?').get(n.id)) continue;
      db.prepare('INSERT INTO activities (user_id, card_id, type, text) VALUES (?, ?, ?, ?)').run(viewer.id, n.id, 'note', n.text);
      noted += 1;
    }
    const result = { moved, keptNow, enriched, filled, noted, kept: plan.kept, protected: plan.protectedRows.length, ignored: plan.ignored.length };
    db.prepare("UPDATE unverified_batches SET applied_at = datetime('now'), applied_by = ?, result = ? WHERE id = ?").run(viewer.id, JSON.stringify(result), plan.batchId);
    audit(viewer, null, 'change', 'Unverified customers cleanup', null, `${moved} moved to junk, ${enriched} completed, ${noted} notes`, `List #${plan.batchId} of ${plan.batchRows} customers`);
    db.exec('COMMIT');
    previews.delete(previewId);
    return result;
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}
