// The rich text of a newsletter: only a few safe tags are kept (the editor makes more, a pasted text may bring anything). No scripts, no styles, no
// events, only http(s) and mailto links. Applied when the text is saved AND when it is sent.
const KEEP: Record<string, string> = { p: 'p', div: 'p', br: 'br', b: 'strong', strong: 'strong', i: 'em', em: 'em', u: 'u', ul: 'ul', ol: 'ol', li: 'li', a: 'a', h1: 'h2', h2: 'h2', h3: 'h3', h4: 'h3', blockquote: 'blockquote', span: '', font: '', img: 'img' };
// a colour the editor may set: #rgb / #rrggbb or rgb(r,g,b) - turned into a plain #rrggbb (nothing else can get in through a style)
function hex(c: string): string | null {
  const v = c.trim().toLowerCase();
  const h = /^#([0-9a-f]{3}|[0-9a-f]{6})$/.exec(v);
  if (h) return h[1].length === 3 ? '#' + h[1].split('').map((x) => x + x).join('') : '#' + h[1];
  const r = /^rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})/.exec(v);
  return r ? '#' + [r[1], r[2], r[3]].map((n) => Math.min(255, Number(n)).toString(16).padStart(2, '0')).join('') : null;
}
function colours(attrs: string): { color: string | null; bg: string | null } {
  const st = /style\s*=\s*(?:"([^"]*)"|'([^']*)')/i.exec(attrs);
  const style = unesc(st?.[1] ?? st?.[2] ?? '');
  const c = /(?:^|;)\s*color\s*:\s*([^;]+)/i.exec(style)?.[1] ?? /\bcolor\s*=\s*"([^"]*)"/i.exec(attrs)?.[1] ?? null;
  const b = /background(?:-color)?\s*:\s*([^;]+)/i.exec(style)?.[1] ?? null;
  return { color: c ? hex(c) : null, bg: b ? hex(b) : null };
}
const VOID = new Set(['br']);
const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const unesc = (s: string) => s.replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&amp;/g, '&');

export function sanitizeHtml(input: string, max = 20000): string {
  const src = String(input ?? '').slice(0, max * 2).replace(/<(script|style|iframe|object|embed|svg|head)[\s\S]*?<\/\1\s*>/gi, '').replace(/<!--[\s\S]*?-->/g, '');
  const out: string[] = [];
  const open: string[] = [];
  const spans: boolean[] = []; // for every <span>/<font> opened: did it keep a colour (so its closing tag is kept too)
  const re = /<(\/?)([a-zA-Z0-9]+)([^>]*)>|([^<]+)|</g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(src))) {
    if (m[4] !== undefined) { out.push(esc(unesc(m[4]))); continue; }
    if (!m[2]) continue; // a stray "<"
    const name = m[2].toLowerCase();
    if (!(name in KEEP)) continue;
    const tag = KEEP[name];
    if (name === 'span' || name === 'font') {
      if (m[1]) { if (spans.pop()) out.push('</span>'); continue; }
      const c = colours(m[3] ?? '');
      if (!c.color && !c.bg) { spans.push(false); continue; } // no colour: dropped, its text stays
      out.push(`<span style="${c.color ? `color:${c.color};` : ''}${c.bg ? `background-color:${c.bg};` : ''}">`);
      spans.push(true);
      continue;
    }
    if (!tag) continue;
    if (tag === 'img') {
      const src = /src\s*=\s*(?:"([^"]*)"|'([^']*)')/i.exec(m[3] ?? '');
      const url = unesc(src?.[1] ?? src?.[2] ?? '').trim();
      if (m[1] || !/^https:\/\//i.test(url)) continue; // only pictures from an https address
      out.push(`<img src="${esc(url)}" alt="" style="max-width:100%;height:auto;border-radius:6px">`);
      continue;
    }
    if (m[1]) {
      const at = open.lastIndexOf(tag);
      if (at < 0 || VOID.has(tag)) continue;
      while (open.length > at) out.push(`</${open.pop()}>`);
      continue;
    }
    if (tag === 'br') { out.push('<br>'); continue; }
    if (tag === 'a') {
      const href = /href\s*=\s*(?:"([^"]*)"|'([^']*)')/i.exec(m[3] ?? '');
      const url = unesc(href?.[1] ?? href?.[2] ?? '').trim();
      if (!/^(https?:\/\/|mailto:)/i.test(url)) continue;
      out.push(`<a href="${esc(url)}" target="_blank" rel="noopener noreferrer">`);
      open.push('a');
      continue;
    }
    out.push(`<${tag}>`);
    open.push(tag);
  }
  while (spans.length) { if (spans.pop()) out.push('</span>'); }
  while (open.length) out.push(`</${open.pop()}>`);
  return out.join('').replace(/(<p>\s*<\/p>|<p><br><\/p>)+/g, '').slice(0, max).trim();
}

// the text without tags (the plain-text part of the e-mail)
export const htmlToPlain = (html: string): string => unesc(html.replace(/<\/(p|li|h2|h3|blockquote)>/gi, '\n').replace(/<br\s*\/?>/gi, '\n').replace(/<li>/gi, '- ').replace(/<[^>]+>/g, '')).replace(/\n{3,}/g, '\n\n').trim();

// inline styles for the mail programs (they ignore a style sheet)
export function styleForEmail(html: string, o: { navy: string; red: string }): string {
  return html
    .replace(/<p>/g, '<p style="margin:0 0 12px">')
    .replace(/<(ul|ol)>/g, '<$1 style="margin:0 0 12px;padding-left:22px">')
    .replace(/<li>/g, '<li style="margin:0 0 4px">')
    .replace(/<h2>/g, `<h2 style="margin:16px 0 8px;font-size:20px;font-weight:600;color:${o.navy}">`)
    .replace(/<h3>/g, `<h3 style="margin:14px 0 6px;font-size:17px;font-weight:600;color:${o.navy}">`)
    .replace(/<blockquote>/g, `<blockquote style="margin:0 0 12px;padding-left:12px;border-left:3px solid ${o.red}">`)
    .replace(/<a /g, `<a style="color:${o.red}" `);
}

// the text parts of an HTML text, to be translated one by one (the tags stay where they are)
export function mapTextNodes(html: string, f: (text: string) => string): string {
  return html.split(/(<[^>]+>)/).map((part) => (part.startsWith('<') ? part : (() => { const t = unesc(part); return /[A-Za-zÀ-ÿА-я]{2}/.test(t) ? esc(f(t)) : part; })())).join('');
}
export function textNodes(html: string): string[] {
  const out: string[] = [];
  mapTextNodes(html, (t) => { out.push(t.trim()); return t; });
  return [...new Set(out.filter(Boolean))];
}
