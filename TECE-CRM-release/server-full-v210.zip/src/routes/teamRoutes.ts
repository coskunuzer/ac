import { Router } from 'express';
import { requireAuth, requireAdmin, type AuthedRequest } from '../middleware/auth';
import { settingsModel } from '../models/settingsModel';
import { userModel } from '../models/userModel';
import { evaluationModel } from '../models/evaluationModel';
import { pointsBetween } from '../services/gamify';
import { dayRange, descendants, getGoals, peopleFor, reportForDay, sendDigests, setGoals, summaryFor, todayLocal, wouldLoop } from '../services/team';

const router = Router();
router.use(requireAuth);

// the Salesperson / Manager switch: in Salesperson mode a manager (not an admin) sees only their own work
const solo = (req: AuthedRequest) => req.user!.role !== 'admin' && req.headers['x-view-mode'] !== 'manager';

const asDate = (v: unknown) => (typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v) ? v : todayLocal());

// Does this person have people below them (so the Team page is worth showing)?
router.get('/me', (req: AuthedRequest, res) => {
  const everyone = req.user!.role === 'admin';
  res.json({ hasTeam: !req.actor && (everyone || (!solo(req) && descendants(req.user!.id).length > 0)), canSwitch: !req.actor && !everyone && descendants(req.user!.id).length > 0, canOversee: everyone, isAdmin: req.user!.role === 'admin', today: todayLocal() });
});

// What each person (me and my team; everybody for an admin) did on a day.
router.get('/report', (req: AuthedRequest, res) => {
  const date = asDate(req.query.date);
  const days = reportForDay(req.user!, date);
  // an assistant sees only the person they work for
  res.json({ date, range: dayRange(date), days: req.actor || solo(req) ? days.filter((d) => d.person.id === req.user!.id) : days });
});

// How much each person did over a day, a week or a month (the overview; for an admin it carries the latest evaluation).
router.get('/summary', (req: AuthedRequest, res) => {
  const date = asDate(req.query.date);
  // without ?days= this used to parse "undefined" and answer with an error
  const asked = parseInt(String(req.query.days ?? '1'), 10);
  const days = [1, 7, 30].includes(asked) ? asked : 1;
  const summary = summaryFor(req.user!, date, days);
  const from = new Date(Date.parse(`${date}T12:00:00Z`) - (days - 1) * 86400000).toISOString().slice(0, 10);
  const points = pointsBetween(summary.rows.map((r) => r.person.id), from, date);
  res.json({ date, days, goals: getGoals(), ...summary, rows: summary.rows.filter((r) => !(req.actor || solo(req)) || r.person.id === req.user!.id).map((r) => ({ ...r, points: points.get(r.person.id) ?? 0 })) });
});

// What people aim for each day / week (everybody sees it, an admin sets it).
router.get('/goals', (_req, res) => {
  res.json(getGoals());
});
router.put('/goals', requireAdmin, (req, res) => {
  res.json(setGoals(req.body ?? {}));
});

// ---- admin only: private evaluations of the people ----
router.get('/evaluations/:userId', requireAdmin, (req, res) => {
  res.json(evaluationModel.forUser(parseInt(String(req.params.userId), 10)));
});
router.post('/evaluations/:userId', requireAdmin, (req: AuthedRequest, res) => {
  const userId = parseInt(String(req.params.userId), 10);
  if (!userModel.findPublicById(userId)) return res.status(404).json({ error: 'Not found' });
  const text = String(req.body?.text ?? '').trim();
  const rating = req.body?.rating === null || req.body?.rating === undefined || req.body?.rating === '' ? null : parseInt(String(req.body.rating), 10);
  if (!text && !rating) return res.status(400).json({ error: 'Write a note or give a rating.' });
  evaluationModel.add({ userId, authorId: req.user!.id, rating, period: typeof req.body?.period === 'string' ? req.body.period : null, text });
  res.status(201).json(evaluationModel.forUser(userId));
});
router.delete('/evaluations/item/:id', requireAdmin, (req, res) => {
  evaluationModel.remove(parseInt(String(req.params.id), 10));
  res.json({ ok: true });
});

router.get('/people', (req: AuthedRequest, res) => {
  res.json(peopleFor(req.user!).filter((p) => !req.actor || p.id === req.user!.id));
});

// ---- admin: who reports to whom, and the evening e-mail -------------------------------------------

router.get('/settings', requireAdmin, (_req, res) => {
  res.json({ enabled: settingsModel.get('team_digest') === '1', hour: parseInt(settingsModel.get('team_digest_hour') ?? '18', 10), last: settingsModel.get('team_digest_last') });
});

router.put('/settings', requireAdmin, (req, res) => {
  const hour = Math.min(23, Math.max(0, parseInt(String(req.body?.hour ?? 18), 10) || 18));
  settingsModel.set('team_digest', req.body?.enabled ? '1' : '0');
  settingsModel.set('team_digest_hour', String(hour));
  res.json({ enabled: !!req.body?.enabled, hour });
});

// Send the report for a day now (to every manager, or one).
router.post('/digest/send', requireAdmin, async (req, res) => {
  try {
    const date = asDate(req.body?.date);
    const only = Array.isArray(req.body?.managerIds) ? (req.body.managerIds as number[]) : undefined;
    res.json(await sendDigests(date, only));
  } catch (err) {
    res.status(502).json({ error: 'Could not send', message: (err as Error).message });
  }
});

// Who reports to whom, one person at a time.
router.put('/manager/:userId', requireAdmin, (req, res) => {
  const userId = parseInt(String(req.params.userId), 10);
  const raw = req.body?.managerId;
  const managerId = raw === null || raw === '' || raw === undefined ? null : parseInt(String(raw), 10);
  if (!userModel.findPublicById(userId)) return res.status(404).json({ error: 'Not found' });
  if (managerId !== null) {
    if (!userModel.findPublicById(managerId)) return res.status(400).json({ error: 'That manager does not exist.' });
    if (wouldLoop(userId, managerId)) return res.status(400).json({ error: 'That would make a loop: the person would end up reporting to themselves.' });
  }
  res.json(userModel.update(userId, { managerId }));
});

// The reporting lines written in the Brand Playbook (Insaf and Aycin report to Sunay, Sunay to Abdullah ...),
// applied where both people exist here and nobody is set yet. Matching is by first name.
const PLAYBOOK: [string, string][] = [
  ['insaf', 'sunay'], ['aycin', 'sunay'], ['sunay', 'abdullah'], ['sena', 'abdullah'], ['emrah', 'sena'], ['asli', 'abdullah'], ['harun', 'abdullah'],
];
router.post('/playbook', requireAdmin, (req, res) => {
  const fold = (s: string) => s.normalize('NFD').replace(/\p{Diacritic}/gu, '').replace(/ı/g, 'i').toLowerCase();
  const people = userModel.listAll().filter((u) => !u.is_assistant && u.is_active);
  const find = (first: string) => people.find((u) => fold(u.display_name ?? u.username).split(/\s+/)[0] === first);
  const applied: string[] = [];
  const missing: string[] = [];
  for (const [who, boss] of PLAYBOOK) {
    const u = find(who);
    const m = find(boss);
    if (!u || !m) {
      missing.push(`${who} -> ${boss}`);
      continue;
    }
    if (u.manager_id || wouldLoop(u.id, m.id)) continue;
    if (req.body?.apply === false) applied.push(`${u.display_name} reports to ${m.display_name}`);
    else {
      userModel.update(u.id, { managerId: m.id });
      applied.push(`${u.display_name} reports to ${m.display_name}`);
    }
  }
  res.json({ applied, missing });
});

export default router;
