import * as XLSX from 'xlsx';

// Reads an EXCEL proforma (the older way proformas were made, one .xls per order) into what the price memory needs: who it is for, the date, and for every
// edgebanding line the SAP code, the thickness, the width, the quantity and the price per m2. The columns are found by their heads ("SAP Code" or "Tece Code",
// "Price for m2" ...), so the two layouts seen (with and without a SAP Code column) and small variations both work. Pure over the workbook, so it can be tested.
export interface ExcelLine { reference: string; code: string; sap: string; description: string; surface: string; thickness: number | null; width: number | null; rollLength: number | null; meters: number | null; priceM2: number; priceMt: number | null; section: string }
export interface ExcelDoc { proformaNo: string; date: string; customer: string; currency: 'EUR' | 'USD' | ''; adjustPct: number; subTotal: number | null; grand: number | null; lines: ExcelLine[]; skipped: number; warnings: string[] }

const SAP_RE = /^(\d{4,6}\.\d{3}|\d{8})$/;
const MONTHS = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'];

const txt = (v: unknown): string => (v === null || v === undefined ? '' : v instanceof Date ? v.toISOString().slice(0, 10) : String(v)).replace(/\s+/g, ' ').trim();
const toNum = (v: unknown): number | null => {
  if (typeof v === 'number') return Number.isFinite(v) ? v : null;
  const s = txt(v).replace(/[€$\s]/g, '').replace(/[a-zA-Z]+$/g, '');
  if (!/\d/.test(s)) return null;
  const lc = s.lastIndexOf(','); const ld = s.lastIndexOf('.');
  const t = lc >= 0 && ld >= 0 ? (lc > ld ? s.replace(/\./g, '').replace(',', '.') : s.replace(/,/g, '')) : lc >= 0 ? (/^\d{1,3}(,\d{3})+$/.test(s) ? s.replace(/,/g, '') : s.replace(',', '.')) : s;
  const n = Number(t);
  return Number.isFinite(n) ? n : null;
};
function toIso(v: unknown): string {
  if (v instanceof Date && !Number.isNaN(v.getTime())) return new Date(v.getTime() - v.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
  const s = txt(v);
  let m = /([A-Za-z]+)\.?\s+(\d{1,2}),\s*(\d{4})/.exec(s);
  if (m) { const i = MONTHS.findIndex((x) => x === m![1].toLowerCase() || (m![1].length === 3 && x.startsWith(m![1].toLowerCase()))); if (i >= 0) return `${m[3]}-${String(i + 1).padStart(2, '0')}-${m[2].padStart(2, '0')}`; }
  m = /(\d{1,2})[./-](\d{1,2})[./-](\d{4})/.exec(s);
  if (m) return `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`;
  return '';
}

export function parseExcelProforma(buf: Buffer): ExcelDoc {
  const doc: ExcelDoc = { proformaNo: '', date: '', customer: '', currency: '', adjustPct: 0, subTotal: null, grand: null, lines: [], skipped: 0, warnings: [] };
  const wb = XLSX.read(buf, { cellDates: true });
  for (const name of wb.SheetNames) {
    const ws = wb.Sheets[name];
    const rows = XLSX.utils.sheet_to_json<unknown[]>(ws, { header: 1, raw: true, defval: null, blankrows: true });
    // the head row: has "Price for m2" and a SAP / Tece code head
    const head = rows.findIndex((r) => r.some((c) => /^price for m2$/i.test(txt(c))) && r.some((c) => /^(sap code|tece code)$/i.test(txt(c))));
    if (head < 0) continue;
    const H = rows[head].map((c) => txt(c));
    const col = (re: RegExp) => H.findIndex((h) => re.test(h));
    const sapCol = col(/^sap code$/i) >= 0 ? col(/^sap code$/i) : col(/^tece code$/i);
    const c = {
      sap: sapCol, pm2: col(/^price for m2$/i), pmt: col(/^price for mt$/i), th: col(/^thickness/i), w: col(/^width/i), m: col(/^order in meters/i), roll: col(/^roll len/i),
      ref: col(/^customer code/i), desc: col(/^(description|name)$/i), surf: col(/^surface$/i), total: col(/^total pr/i),
    };
    // the top: who, when, which number (a label cell and its value to the right; the customer is the text under "Customer:")
    for (let i = 0; i < head; i += 1) {
      const r = rows[i];
      r.forEach((cell, j) => {
        const s = txt(cell);
        const next = () => r.slice(j + 1).find((x) => txt(x) !== '');
        if (!doc.proformaNo && /^proforma no\.?:?$/i.test(s)) doc.proformaNo = txt(next());
        if (!doc.date && /^date:?$/i.test(s)) doc.date = toIso(next());
        if (!doc.proformaNo && /^order ref\.? no\.?:?$/i.test(s) && !rows.slice(0, head).some((q) => q.some((x) => /^proforma no/i.test(txt(x))))) doc.proformaNo = txt(next());
      });
    }
    const ci = rows.slice(0, head).findIndex((r) => r.some((x) => /^customer:?$/i.test(txt(x))));
    if (ci >= 0) {
      const lines: string[] = [];
      for (let i = ci; i < Math.min(head, ci + 4); i += 1) {
        const first = rows[i].map(txt).filter((x) => x && !/^(customer:?|address:?|tel:?|email:?|mobile:?|proforma invoice|date:?)/i.test(x))[0];
        if (first && !/^(tel|e-?mail|mobile|address)/i.test(first) && !/@/.test(first)) lines.push(first);
        if (lines.length >= 2) break;
      }
      doc.customer = lines.join(' ').replace(/[‎‏]/g, '').slice(0, 120);
    }
    let section = '';
    for (let i = head + 1; i < rows.length; i += 1) {
      const r = rows[i];
      const first = txt(r.find((x) => txt(x) !== ''));
      if (first && r.filter((x) => txt(x) !== '').length === 1 && /^[A-Z][A-Z &/-]{3,}$/.test(first)) { section = first; continue; }
      const rowText = r.map(txt).join(' ');
      let m: RegExpExecArray | null;
      if ((m = /price adjustment\s*\/?\s*([-+]?\d+(?:[.,]\d+)?)\s*%/i.exec(rowText))) {
        const amount = r.map(toNum).filter((x): x is number => x !== null && Math.abs(x) > 0.5).pop();
        const pct = Number(m[1].replace(',', '.'));
        if (Number.isFinite(pct)) doc.adjustPct = (amount !== undefined && amount < 0 ? -1 : 1) * Math.abs(pct);
        continue;
      }
      if (/total price/i.test(rowText)) { const v = r.map(toNum).filter((x): x is number => x !== null).pop(); if (v) doc.grand = v; continue; }
      const sap = txt(r[c.sap]).replace(/\.0+$/, '');
      if (!SAP_RE.test(sap)) continue;
      const price = c.pm2 >= 0 ? toNum(r[c.pm2]) : null;
      if (price === null || price <= 0) { doc.skipped += 1; continue; }
      const priceCell = txt(r[c.pm2]);
      const cellObj = ws[XLSX.utils.encode_cell({ r: i, c: c.pm2 })] as XLSX.CellObject | undefined;
      const shown = `${priceCell} ${cellObj?.w ?? ''}`;
      if (/\$/.test(shown)) doc.currency ||= 'USD'; else if (/€|eur/i.test(shown)) doc.currency ||= 'EUR';
      doc.lines.push({
        reference: c.ref >= 0 ? txt(r[c.ref]) : '', code: '', sap,
        description: c.desc >= 0 ? txt(r[c.desc]) : '', surface: c.surf >= 0 ? txt(r[c.surf]) : '',
        thickness: c.th >= 0 ? toNum(r[c.th]) : null, width: c.w >= 0 ? toNum(r[c.w]) : null, rollLength: c.roll >= 0 ? toNum(r[c.roll]) : null, meters: c.m >= 0 ? toNum(r[c.m]) : null,
        priceM2: price, priceMt: c.pmt >= 0 ? toNum(r[c.pmt]) : null, section,
      });
    }
    if (doc.lines.length) break;
  }
  if (!doc.currency && doc.lines.length) {
    // no symbol in the price cells: look at the number formats of the sheet
    doc.currency = 'EUR';
  }
  if (!doc.lines.length) doc.warnings.push('No priced edgebanding lines were found in this Excel file.');
  if (!doc.proformaNo) doc.warnings.push('The proforma number was not found.');
  return doc;
}
