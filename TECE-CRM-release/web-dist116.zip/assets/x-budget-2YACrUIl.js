// The budget of one trip or one fair: the plan per kind of cost, what was spent, what is left, and what the money bought.
import { h, Fragment, useState, useEffect, useMemo, api, useT, Icon, cx, errText, eur, dayDiff, shortDate, Bar, Chip, Skel, toast, todayIso } from "./x-kit-br2FMvy0.js";

const CAT_ICON = { flights: "flight", hotel: "hotel", transport: "directions-car", meals: "restaurant", hosting: "handshake", visa: "badge", other: "more-horiz", stand: "storefront", build: "construction", logistics: "local-shipping", travel: "luggage", promo: "local-mall", fees: "receipt-long" };
const toneOf = (spent, planned) => (planned <= 0 ? "" : spent > planned ? "bad" : spent > planned * 0.85 ? "warn" : "good");
const num = (v) => {
  const n = Number(String(v == null ? "" : v).replace(/\s/g, "").replace(",", "."));
  return Number.isFinite(n) ? n : 0;
};

// a first guess for a trip of N days, so nobody starts from an empty sheet (the person changes it before saving)
function typicalTrip(days) {
  const d = Math.max(1, days);
  return { flights: 550, hotel: 120 * Math.max(1, d - 1), transport: 60 * d, meals: 45 * d, hosting: 150, visa: 0, other: 100 };
}

function ExpenseForm({ kind, id, categories, currencies, onSaved, onClose }) {
  const t = useT();
  const [f, setF] = useState({ spent_on: todayIso(), category: categories[0].key, amount: "", currency: "EUR", rate: "", amount_try: "", supplier: "", description: "", invoice_no: "" });
  const [file, setFile] = useState(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState(null);
  const set = (k) => (e) => setF((x) => ({ ...x, [k]: e.target.value }));
  const ym = f.spent_on.slice(0, 7);
  useEffect(() => {
    let alive = true;
    api.get(`/budget/event-rate?ym=${ym}`).then((r) => alive && r.rate && setF((x) => (x.rate ? x : { ...x, rate: String(r.rate) }))).catch(() => undefined);
    return () => {
      alive = false;
    };
  }, [ym]);
  async function save(e) {
    e.preventDefault();
    setErr(null);
    if (!num(f.amount)) return setErr(t("Type the amount on the invoice."));
    setBusy(true);
    try {
      const fd = new FormData();
      for (const [k, v] of Object.entries(f)) if (v !== "") fd.append(k, v);
      if (file) fd.append("file", file);
      const next = await api.post(`/budget/event/${kind}/${id}/expense`, fd);
      toast(t("Expense saved"), "good");
      onSaved(next);
    } catch (e2) {
      setErr(errText(e2, t("Could not save")));
    } finally {
      setBusy(false);
    }
  }
  const foreign = f.currency !== "TRY" && f.currency !== "EUR";
  return h(
    "form",
    { className: "xb-form", onSubmit: save },
    h("div", { className: "xb-form-grid" },
      h("label", null, h("span", null, t("Date of the invoice")), h("input", { type: "date", value: f.spent_on, onChange: set("spent_on"), required: true })),
      h("label", null, h("span", null, t("Kind of cost")), h("select", { value: f.category, onChange: set("category") }, categories.map((c) => h("option", { key: c.key, value: c.key }, t(c.label))))),
      h("label", null, h("span", null, t("Amount")), h("input", { inputMode: "decimal", value: f.amount, onChange: set("amount"), placeholder: "0.00", autoFocus: true })),
      h("label", null, h("span", null, t("Currency")), h("select", { value: f.currency, onChange: set("currency") }, (currencies || ["EUR", "TRY", "USD", "GBP"]).map((c) => h("option", { key: c, value: c }, c)))),
      h("label", null, h("span", null, t("Rate (TL for 1 €)")), h("input", { inputMode: "decimal", value: f.rate, onChange: set("rate"), placeholder: t("of the month") })),
      foreign ? h("label", null, h("span", null, t("Amount in TL (as booked)")), h("input", { inputMode: "decimal", value: f.amount_try, onChange: set("amount_try") })) : null,
      h("label", null, h("span", null, t("Supplier")), h("input", { value: f.supplier, onChange: set("supplier"), placeholder: t("Airline, hotel, stand builder ...") })),
      h("label", null, h("span", null, t("Invoice no.")), h("input", { value: f.invoice_no, onChange: set("invoice_no") })),
      h("label", { className: "xb-wide" }, h("span", null, t("What it was for")), h("input", { value: f.description, onChange: set("description") })),
      h("label", { className: "xb-wide" }, h("span", null, t("Invoice (PDF or picture)")), h("input", { type: "file", accept: ".pdf,.png,.jpg,.jpeg,.webp,.xlsx,.xls,.doc,.docx", onChange: (e) => setFile(e.target.files && e.target.files[0] ? e.target.files[0] : null) })),
    ),
    err ? h("p", { className: "tx-err", role: "alert" }, err) : null,
    h("div", { className: "xb-form-foot" },
      h("button", { type: "submit", className: "tc-btn tc-btn--md", disabled: busy }, busy ? t("Saving ...") : t("Save the expense")),
      h("button", { type: "button", className: "tc-btn tc-btn--ghost tc-btn--md", onClick: onClose }, t("Cancel")),
      h("small", { className: "tx-muted" }, t("It is booked on the right line of the marketing budget by itself.")),
    ),
  );
}

// kind: "trip" | "exhibition". days: the length of the trip (for the first guess). onChange: told the new totals.
export function EventBudget({ kind, id, days, onChange, embedded, collapsible }) {
  const t = useT();
  const [b, setB] = useState(null);
  const [err, setErr] = useState(null);
  const [edit, setEdit] = useState(false);
  const [draft, setDraft] = useState({});
  const [adding, setAdding] = useState(false);
  const [busy, setBusy] = useState(false);
  const [open, setOpen] = useState(false);
  const [shown, setShown] = useState(!collapsible);
  const take = (d) => {
    setB(d);
    setErr(null);
    if (onChange) onChange({ planned: d.planned, spent: d.spent });
  };
  useEffect(() => {
    let alive = true;
    setB(null);
    api.get(`/budget/event/${kind}/${id}`).then((d) => alive && take(d)).catch((e) => alive && setErr(e && e.status === 403 ? "hidden" : errText(e, t("Could not load the budget"))));
    return () => {
      alive = false;
    };
  }, [kind, id]);
  const startEdit = (preset) => {
    const d = {};
    for (const c of b.categories) d[c.key] = preset ? String(preset[c.key] || "") : c.planned ? String(c.planned) : "";
    setDraft(d);
    setEdit(true);
    setShown(true);
  };
  async function savePlan() {
    setBusy(true);
    try {
      take(await api.put(`/budget/event/${kind}/${id}/plan`, { lines: b.categories.map((c) => ({ category: c.key, planned: num(draft[c.key]) })) }));
      setEdit(false);
      toast(t("Budget saved"), "good");
    } catch (e) {
      setErr(errText(e, t("Could not save")));
    } finally {
      setBusy(false);
    }
  }
  async function remove(row) {
    if (!window.confirm(t("Remove this expense?"))) return;
    try {
      take(await api.delete(`/budget/event/${kind}/${id}/expense/${row.id}`));
    } catch (e) {
      toast(errText(e, t("Could not remove")), "bad");
    }
  }
  const draftTotal = useMemo(() => Object.values(draft).reduce((s, v) => s + num(v), 0), [draft]);
  if (err === "hidden") return null;
  if (err && !b) return h("p", { className: "tx-err" }, err);
  if (!b) return h(Skel, { height: 120 });
  const tone = toneOf(b.spent, b.planned);
  const empty = b.planned === 0 && b.spent === 0;
  const catLabel = (k) => { const c = b.categories.find((x) => x.key === k); return c ? t(c.label) : k; };
  if (!shown)
    return h("section", { className: "xb xb--closed", "aria-label": t("Budget") },
      h("button", { type: "button", className: "xb-closed", "aria-expanded": false, onClick: () => setShown(true) },
        h("span", { className: "xb-title" }, h(Icon, { n: "savings", size: 24 }), h("b", null, t("Budget"))),
        empty
          ? h("span", { className: "xb-closed-hint" }, b.canPlan ? t("Not planned yet. Set what this may cost.") : t("Nothing yet."))
          : h(Fragment, null,
              h("span", { className: "xb-closed-num" }, h("small", null, t("Spent")), h("b", { className: b.over ? "is-bad" : "" }, eur(b.spent))),
              h("span", { className: "xb-closed-num" }, h("small", null, t("Planned")), h("b", null, b.planned > 0 ? eur(b.planned) : "–")),
              b.planned > 0 ? h("span", { className: "xb-closed-bar" }, h(Bar, { value: b.spent, max: Math.max(b.planned, b.spent), mark: b.over ? b.planned : null, tone })) : h("span", { className: "xb-closed-bar" }),
              b.units[0] && b.units[0].each != null ? h("span", { className: "xb-closed-num" }, h("small", null, kind === "trip" ? t("Per customer visited") : t("Per person met")), h("b", null, eur(b.units[0].each))) : null,
            ),
        h("span", { className: "xb-closed-open" }, empty && b.canPlan ? t("Plan the budget") : t("Open"), h(Icon, { n: "keyboard-arrow-down", size: 20 })),
      ),
    );
  return h(
    "section",
    { className: cx("xb", embedded && "xb--embedded"), "aria-label": t("Budget") },
    h("header", { className: "xb-head" },
      h("div", { className: "xb-title" }, collapsible ? h("button", { type: "button", className: "xb-collapse", "aria-label": t("Close the budget"), onClick: () => { setShown(false); setEdit(false); setAdding(false); } }, h(Icon, { n: "keyboard-arrow-up", size: 20 })) : null, h(Icon, { n: "savings", size: 24 }), h("h3", null, t("Budget")), b.over ? h(Chip, { tone: "bad", icon: "warning" }, t("Over budget")) : b.planned > 0 && tone === "warn" ? h(Chip, { tone: "warn" }, t("Nearly used up")) : null),
      h("div", { className: "xb-actions" },
        b.canPlan && !edit ? h("button", { type: "button", className: "tc-btn tc-btn--secondary tc-btn--sm", onClick: () => startEdit() }, h(Icon, { n: "edit", size: 16 }), b.planned > 0 ? t("Change the plan") : t("Plan the budget")) : null,
        b.canSpend && !adding ? h("button", { type: "button", className: "tc-btn tc-btn--sm", onClick: () => setAdding(true) }, h(Icon, { n: "add", size: 16 }), t("Add an expense")) : null,
      ),
    ),
    empty && !edit
      ? h("div", { className: "xb-empty" },
          h("p", null, kind === "trip" ? t("No budget yet. Plan what this trip may cost, then see what it really cost next to it.") : t("No budget yet. Plan what this fair may cost, then see what it really cost next to it.")),
          b.canPlan && kind === "trip" && days ? h("button", { type: "button", className: "tc-link xb-linkbtn", onClick: () => startEdit(typicalTrip(days)) }, t("Start from typical costs for {n} days", { n: days })) : null,
        )
      : h(Fragment, null,
          h("div", { className: "xb-totals" },
            h("div", { className: "xb-total" }, h("span", null, t("Planned")), h("b", null, eur(edit ? draftTotal : b.planned))),
            h("div", { className: cx("xb-total", tone && "xb-total--" + tone) }, h("span", null, t("Spent")), h("b", null, eur(b.spent)), b.pct != null ? h("small", null, b.pct + "%") : null),
            h("div", { className: cx("xb-total", b.over && "xb-total--bad") }, h("span", null, b.over ? t("Over by") : t("Left")), h("b", null, b.planned > 0 ? eur(Math.abs(b.left)) : "–"), b.planned === 0 && b.spent > 0 ? h("small", null, t("nothing planned")) : null),
            b.units.filter((u) => u.each != null).slice(0, 2).map((u) => h("div", { key: u.label, className: "xb-total xb-total--unit" }, h("span", null, t("Per " + u.label.replace(/^customers on the trip$/, "customer visited").replace(/^people met$/, "person met").replace(/^offers sent$/, "offer").replace(/^customers won$/, "customer won"))), h("b", null, eur(u.each)), h("small", null, u.n + " " + t(u.label)))),
          ),
          b.planned > 0 ? h(Bar, { value: b.spent, max: Math.max(b.planned, b.spent), mark: b.spent > b.planned ? b.planned : null, tone, label: t("Spent of planned") }) : null,
          h("div", { className: "xb-cats", role: "table" },
            b.categories.filter((c) => edit || c.planned > 0 || c.spent > 0).map((c) => {
              const ct = toneOf(c.spent, c.planned);
              return h("div", { key: c.key, className: "xb-cat", role: "row" },
                h("span", { className: "xb-cat-name" }, h(Icon, { n: CAT_ICON[c.key] || "label", size: 20 }), t(c.label)),
                edit
                  ? h("span", { className: "xb-cat-input" }, "€", h("input", { inputMode: "decimal", value: draft[c.key] || "", placeholder: "0", "aria-label": t(c.label), onChange: (e) => setDraft((d) => ({ ...d, [c.key]: e.target.value })) }))
                  : h("span", { className: "xb-cat-bar" }, h(Bar, { value: c.spent, max: Math.max(c.planned, c.spent, 1), mark: c.spent > c.planned && c.planned > 0 ? c.planned : null, tone: ct })),
                h("span", { className: cx("xb-cat-num", ct === "bad" && "is-bad") }, h("b", null, eur(c.spent)), h("small", null, " / " + eur(edit ? num(draft[c.key]) : c.planned))),
              );
            }),
          ),
          edit
            ? h("div", { className: "xb-form-foot" },
                h("button", { type: "button", className: "tc-btn tc-btn--md", disabled: busy, onClick: savePlan }, busy ? t("Saving ...") : t("Save the plan")),
                h("button", { type: "button", className: "tc-btn tc-btn--ghost tc-btn--md", onClick: () => setEdit(false) }, t("Cancel")),
                h("small", { className: "tx-muted" }, t("Amounts in euro. Leave a line empty when nothing is planned for it.")),
              )
            : null,
        ),
    adding ? h(ExpenseForm, { kind, id, categories: b.categories, currencies: b.currencies, onClose: () => setAdding(false), onSaved: (d) => { take(d); setAdding(false); setOpen(true); } }) : null,
    b.rows.length > 0
      ? h("div", { className: "xb-rows" },
          h("button", { type: "button", className: "xb-rows-toggle", "aria-expanded": open, onClick: () => setOpen((o) => !o) }, h(Icon, { n: open ? "keyboard-arrow-up" : "keyboard-arrow-down", size: 20 }), t("{n} expenses", { n: b.rows.length }), h("span", null, eur(b.spent))),
          open
            ? h("ul", null, b.rows.map((r) => h("li", { key: r.id },
                h("span", { className: "xb-row-date" }, shortDate(r.date)),
                h("span", { className: "xb-row-what" }, h("b", null, r.supplier || catLabel(r.category)), h("small", null, [catLabel(r.category), r.description, r.invoiceNo].filter(Boolean).join(" · "))),
                h("span", { className: "xb-row-amt" }, h("b", null, eur(r.eur)), r.currency !== "EUR" ? h("small", null, r.amount.toLocaleString("en-US") + " " + r.currency) : null),
                r.hasFile && b.canSpend ? h("a", { className: "xb-row-file", href: api.downloadUrl(`/budget/expenses/${r.id}/file`), target: "_blank", rel: "noreferrer", title: t("Open the invoice") }, h(Icon, { n: "attach-file", size: 20 })) : h("span", { className: "xb-row-file" }),
                b.canSpend ? h("button", { type: "button", className: "xb-row-del", onClick: () => remove(r), "aria-label": t("Remove this expense") }, h(Icon, { n: "delete", size: 20 })) : null,
              )))
            : null,
        )
      : null,
    err && b ? h("p", { className: "tx-err", role: "alert" }, err) : null,
  );
}

// a line for lists: "€1,740 of €2,400" with a bar
export function BudgetLine({ planned, spent }) {
  const t = useT();
  if (!planned && !spent) return null;
  const tone = toneOf(spent, planned);
  return h("div", { className: "xb-line" },
    h("div", { className: "xb-line-top" }, h("span", null, h(Icon, { n: "savings", size: 16 }), " ", t("Budget")), h("b", { className: tone === "bad" ? "is-bad" : "" }, eur(spent), planned > 0 ? h("small", null, " / " + eur(planned)) : null)),
    planned > 0 ? h(Bar, { value: spent, max: Math.max(planned, spent), mark: spent > planned ? planned : null, tone }) : null,
  );
}

export { toneOf, dayDiff };
