import path from 'path';
import { Router } from 'express';
import { paths } from '../config/env';
import { requireAuth } from '../middleware/auth';

const router = Router();

router.get('/:filename', requireAuth, (req, res) => {
  const filename = path.basename(String(req.params.filename));
  res.sendFile(path.join(paths.uploadsDir, filename));
});

export default router;
