import { db } from '../db/connection';

export interface Evaluation {
  id: number;
  userId: number;
  authorName: string | null;
  rating: number | null;
  period: string | null;
  text: string | null;
  createdAt: string;
}

interface Row {
  id: number;
  user_id: number;
  author_name: string | null;
  rating: number | null;
  period: string | null;
  text: string | null;
  created_at: string;
}

const toEval = (r: Row): Evaluation => ({ id: r.id, userId: r.user_id, authorName: r.author_name, rating: r.rating, period: r.period, text: r.text, createdAt: r.created_at });

// An admin's private notes on how a person is doing.
export const evaluationModel = {
  forUser(userId: number, limit = 50): Evaluation[] {
    return (db
      .prepare(
        `SELECT e.id, e.user_id, COALESCE(a.display_name, a.username) AS author_name, e.rating, e.period, e.text, e.created_at
         FROM evaluations e LEFT JOIN users a ON a.id = e.author_id WHERE e.user_id = ? ORDER BY e.created_at DESC, e.id DESC LIMIT ?`
      )
      .all(userId, limit) as unknown as Row[]).map(toEval);
  },

  latestForAll(): Map<number, Evaluation> {
    const rows = db
      .prepare(
        `SELECT e.id, e.user_id, COALESCE(a.display_name, a.username) AS author_name, e.rating, e.period, e.text, e.created_at
         FROM evaluations e LEFT JOIN users a ON a.id = e.author_id
         WHERE e.id IN (SELECT MAX(id) FROM evaluations GROUP BY user_id)`
      )
      .all() as unknown as Row[];
    return new Map(rows.map((r) => [r.user_id, toEval(r)]));
  },

  add(input: { userId: number; authorId: number; rating?: number | null; period?: string | null; text?: string | null }): void {
    const rating = Number.isInteger(input.rating) && input.rating! >= 1 && input.rating! <= 5 ? input.rating! : null;
    db.prepare('INSERT INTO evaluations (user_id, author_id, rating, period, text) VALUES (?, ?, ?, ?, ?)').run(
      input.userId,
      input.authorId,
      rating,
      input.period?.trim().slice(0, 40) || null,
      input.text?.trim().slice(0, 3000) || null
    );
  },

  remove(id: number): void {
    db.prepare('DELETE FROM evaluations WHERE id = ?').run(id);
  },
};
