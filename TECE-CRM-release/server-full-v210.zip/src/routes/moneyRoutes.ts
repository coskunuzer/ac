import { Router } from 'express';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { setsFor, usdPerEur, unresolvedSheets, type Account } from '../services/perfAnalytics';
import { sapAsOf } from '../services/todayQueue';

// Money: one receivables page. Who owes us, how old it is (ageing), per currency; accounts on hold on their own list.
// Only the customers this person may see (an admin sees all). Reads only.
const router = Router();
router.use(requireAuth);

const r0 = (n: number) => Math.round(n);

function line(a: Account) {
  return {
    sap: a.sap, name: a.name, cardId: a.cardId, country: a.country, rep: a.rep, cur: a.currency,
    overdue: r0(a.overdue), balance: r0(a.balance), oldest: a.oldestOver,
    aging: { current: r0(a.aging.current), d30: r0(a.aging.d30), d60: r0(a.aging.d60), over60: r0(a.aging.over60), total: r0(a.aging.total) },
    risk: a.risk?.level ?? 'good', hold: a.hold, swift: a.swift ? { amount: r0(a.swift.amount), days: a.swift.days } : null, lastInvoice: a.lastInvoice, lastPayment: a.lastPayment,
  };
}

router.get('/', (req: AuthedRequest, res) => {
  const sets = setsFor(req.user!);
  const rate = usdPerEur();
  const toEur = (v: number, cur: string) => (cur === 'USD' ? v / rate : v);
  const owing = sets.live.filter((a) => a.overdue > 0.5 && !a.hold).map(line);
  // sorted by the overdue amount (in euro), then by how old the oldest invoice is
  owing.sort((a, b) => toEur(b.overdue, b.cur) - toEur(a.overdue, a.cur) || b.oldest - a.oldest);
  const hold = sets.live.filter((a) => a.hold).map(line).sort((a, b) => toEur(b.balance, b.cur) - toEur(a.balance, a.cur));
  const cur = new Map<string, { cur: string; overdue: number; total: number; customers: number; aging: { current: number; d30: number; d60: number; over60: number } }>();
  for (const a of sets.live) {
    if (a.overdue <= 0.5 && a.aging.total <= 0.5) continue;
    const c = cur.get(a.currency) ?? cur.set(a.currency, { cur: a.currency, overdue: 0, total: 0, customers: 0, aging: { current: 0, d30: 0, d60: 0, over60: 0 } }).get(a.currency)!;
    c.overdue += a.overdue; c.total += a.aging.total; if (a.overdue > 0.5) c.customers += 1;
    c.aging.current += a.aging.current; c.aging.d30 += a.aging.d30; c.aging.d60 += a.aging.d60; c.aging.over60 += a.aging.over60;
  }
  const currencies = [...cur.values()].map((c) => ({ ...c, overdue: r0(c.overdue), total: r0(c.total), aging: { current: r0(c.aging.current), d30: r0(c.aging.d30), d60: r0(c.aging.d60), over60: r0(c.aging.over60) } })).sort((a, b) => b.overdue - a.overdue);
  res.json({
    sapAsOf: sapAsOf(),
    rate,
    currencies,
    // one definition: every customer with an overdue invoice (the ones on hold too: they are only listed apart)
    customers: sets.live.filter((a) => a.overdue > 0.5).length,
    overdueEur: r0(sets.live.filter((a) => a.overdue > 0.5).reduce((a, x) => a + toEur(x.overdue, x.currency), 0)),
    holdOverdue: sets.live.filter((a) => a.hold && a.overdue > 0.5).length,
    rows: owing,
    hold,
    holdEur: r0(hold.reduce((a, x) => a + toEur(x.balance, x.cur), 0)),
    // ledger tabs that are not matched to a SAP customer are in no figure here: an admin is told how many, so they can be matched
    unmatched: (() => { if (req.user!.role !== 'admin') return null; const um = unresolvedSheets().filter((u) => Math.abs(u.balance) > 0.5); return { count: um.length, owedEur: r0(um.filter((u) => u.balance > 0).reduce((a, u) => a + toEur(u.balance, u.currency), 0)) }; })(),
  });
});

export default router;
