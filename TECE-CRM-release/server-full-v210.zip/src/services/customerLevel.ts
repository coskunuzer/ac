import { db } from '../db/connection';
import { cardModel } from '../models/cardModel';
import { activePriceBook } from './priceBook/store';
import { priceProforma, type ProformaData } from './proforma';
import { usdPerEur } from './perfAnalytics';
import type { DocLine } from './customerPrices';

// What a customer usually pays against our price list, per product (PVC, ABS, PP): learned from their own SAP proformas and commercial invoices.
// Real invoices show it is steady for a customer (one pays 0.82 of the list on 166 lines, another 0.93 on 122), so a colour or thickness they have never bought
// can be priced at their usual level instead of the full list. Only the last 13 months count (the price list moves), and only with at least 3 lines of a product.
const MIN_LINES = 3;
const WINDOW_DAYS = 400;

export function customerLevels(cardId: number, currency: 'EUR' | 'USD'): Record<string, number> {
  const card = cardModel.findById(cardId);
  if (!card) return {};
  const book = activePriceBook(card.market === 'domestic' ? 'domestic' : 'export')?.book ?? null;
  if (!book) return {};
  const docs = db.prepare('SELECT doc_date, lines_json FROM customer_price_docs WHERE card_id = ? AND currency = ? ORDER BY COALESCE(doc_date, \'\') DESC').all(cardId, currency) as { doc_date: string | null; lines_json: string }[];
  if (!docs.length) return {};
  const newest = docs.find((d) => d.doc_date)?.doc_date ?? null;
  const limit = newest ? new Date(newest).getTime() - WINDOW_DAYS * 86400000 : null;
  const use = docs.filter((d) => limit === null || !d.doc_date || new Date(d.doc_date).getTime() >= limit);
  const acc = new Map<string, { a: number; s: number; n: number }>();
  for (const d of use) {
    const lines = JSON.parse(d.lines_json) as DocLine[];
    const data: ProformaData = {
      header: { name: '', company: '', address: '', tel: '', email: '', sapNumber: '', preparedBy: '', date: d.doc_date ?? '', reference: '', deliveryTerm: '', paymentTerm: '', dispatchTime: '', notes: '' },
      currency, usdRate: usdPerEur(), transportPct: 0, useMemory: false,
      lines: lines.map((l) => ({ code: l.reference, description: l.description, sap: l.sap, meters: l.meters, thickness: l.thickness, width: l.width, rollLength: l.rollLength })),
    };
    const priced = priceProforma(data, book).lines;
    lines.forEach((l, i) => {
      const p = priced[i];
      const m2 = l.meters && l.width ? (l.meters * l.width) / 1000 : 0;
      if (!p?.product || !p.listPriceM2 || m2 <= 0 || !(l.priceM2 > 0)) return;
      const x = acc.get(p.product) ?? { a: 0, s: 0, n: 0 };
      x.a += l.priceM2 * m2; x.s += p.listPriceM2 * m2; x.n += 1; acc.set(p.product, x);
    });
  }
  const out: Record<string, number> = {};
  for (const [product, x] of acc) {
    if (x.n < MIN_LINES || x.s <= 0) continue;
    const level = x.a / x.s - 1;
    // a level far from the list means mixed products (special surfaces), not a discount: do not use it
    if (level < -0.5 || level > 0.5) continue;
    out[product] = Math.round(level * 1000) / 1000;
  }
  return out;
}
