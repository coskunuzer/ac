import { db } from '../db/connection';

// Per-person menu, money and actions. A person WITHOUT a row keeps exactly what they had before; an admin always has everything.
export const MENU_KEYS = ['home', 'cust', 'perf', 'cal', 'map', 'qual', 'nak', 'fairs', 'comp', 'leads', 'brand', 'intel', 'targets', 'reports', 'budget'] as const;
export const ACTION_KEYS = ['upLeads', 'upCust', 'del', 'exp', 'camp', 'catalog'] as const;
export const MONEY_KEYS = ['prices', 'ledger'] as const;

export interface Perms { menu: string[]; actions: string[]; money: string[]; start: string | null; preset: string | null }
interface Row { menu: string; actions: string; money: string; start_page: string | null; preset: string | null }

const parse = (s: string, allowed: readonly string[]): string[] => {
  try { const a = JSON.parse(s) as unknown; return Array.isArray(a) ? a.filter((x): x is string => typeof x === 'string' && allowed.includes(x)) : []; } catch { return []; }
};

// null = no row = unchanged legacy behaviour (and always null for an admin)
export function permsOf(user: { id: number; role: string }): Perms | null {
  if (user.role === 'admin') return null;
  const r = db.prepare('SELECT * FROM user_perms WHERE user_id = ?').get(user.id) as unknown as Row | undefined;
  if (!r) return null;
  return { menu: parse(r.menu, MENU_KEYS), actions: parse(r.actions, ACTION_KEYS), money: parse(r.money, MONEY_KEYS), start: r.start_page, preset: r.preset };
}

// What a brand manager has: the Brand dashboard, the leads and the customers they may see, their calendar and tasks, the map and the fairs; they upload leads
// and customers, send the campaigns, keep the catalogues and may export their own lists to Excel to analyse them. No prices, no sales figures.
export const BRAND_PERMS = { menu: ['brand', 'home', 'cust', 'leads', 'cal', 'map', 'fairs'], actions: ['upLeads', 'upCust', 'camp', 'catalog', 'exp'], money: [] as string[], start: '/brand', preset: 'brand' };

type WithPerms = { role: string; perms?: Perms | null };
export const hasAction = (u: WithPerms | undefined, a: string): boolean => !!u && (u.role === 'admin' || !!u.perms?.actions.includes(a));
// Sales intelligence is the other way round: it is OFF for everybody (a person without a permissions row too) until an admin switches it on.
export const hasIntel = (u: WithPerms | undefined): boolean => !!u && (u.role === 'admin' || !!u.perms?.menu.includes('intel'));
// Reports (Turquality, the customer list) and the marketing budget are opt-in as well: an admin switches them on for a person; Sales intelligence includes the reports.
export const hasReports = (u: WithPerms | undefined): boolean => !!u && (u.role === 'admin' || !!u.perms?.menu.includes('reports') || !!u.perms?.menu.includes('intel'));
export const hasBudget = (u: WithPerms | undefined): boolean => !!u && (u.role === 'admin' || !!u.perms?.menu.includes('budget'));
export const hasMenu = (u: WithPerms | undefined, m: string): boolean => !!u && (u.role === 'admin' || !u.perms || u.perms.menu.includes(m));

// API areas that follow a menu item / a money switch (only checked for a person who HAS a permissions row)
const MENU_API: [string, string][] = [
  ['/api/performance', 'perf'], ['/api/calendar', 'cal'], ['/api/trips', 'map'], ['/api/country-explorer', 'map'], ['/api/complaints', 'comp'], ['/api/brand', 'brand'], ['/api/intel', 'intel'], ['/api/targets', 'targets'],
];
export function blockedByPerms(u: WithPerms, baseUrl: string, originalUrl: string): string | null {
  const p = u.perms;
  if (!p || u.role === 'admin') return null;
  // the little numbers on the menu are asked by every open tab: a page that is switched off answers "nothing" there, not an error
  if (/^\/api\/complaints\/open-count(\?|$)/.test(originalUrl) && !p.menu.includes('comp')) return null;
  for (const [prefix, key] of MENU_API) if ((baseUrl === prefix || baseUrl.startsWith(`${prefix}/`)) && !p.menu.includes(key)) return 'This page is not switched on for you.';
  if ((baseUrl === '/api/pricing' || baseUrl.startsWith('/api/pricing/')) && !p.money.includes('prices')) return 'Prices are not switched on for you.';
  if (baseUrl === '/api/performance' && /\/(ledger|sales-report)/.test(originalUrl) && !p.money.includes('ledger')) return 'Sales figures are not switched on for you.';
  return null;
}

export function savePerms(userId: number, by: number, input: { menu: string[]; actions: string[]; money: string[]; start: string | null; preset: string | null }): Perms {
  const before = db.prepare('SELECT menu, actions, money, start_page, preset FROM user_perms WHERE user_id = ?').get(userId);
  const clean: Perms = { menu: input.menu.filter((x) => (MENU_KEYS as readonly string[]).includes(x)), actions: input.actions.filter((x) => (ACTION_KEYS as readonly string[]).includes(x)), money: input.money.filter((x) => (MONEY_KEYS as readonly string[]).includes(x)), start: input.start && /^\/[a-z0-9/_-]*$/i.test(input.start) ? input.start : null, preset: input.preset ?? null };
  db.prepare(`INSERT INTO user_perms (user_id, menu, actions, money, start_page, preset, updated_by, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
    ON CONFLICT(user_id) DO UPDATE SET menu = excluded.menu, actions = excluded.actions, money = excluded.money, start_page = excluded.start_page, preset = excluded.preset, updated_by = excluded.updated_by, updated_at = excluded.updated_at`)
    .run(userId, JSON.stringify(clean.menu), JSON.stringify(clean.actions), JSON.stringify(clean.money), clean.start, clean.preset, by);
  db.prepare('INSERT INTO perm_log (user_id, by_user, before, after) VALUES (?, ?, ?, ?)').run(userId, by, before ? JSON.stringify(before) : null, JSON.stringify(clean));
  return clean;
}
export function resetPerms(userId: number, by: number): void {
  const before = db.prepare('SELECT menu, actions, money, start_page, preset FROM user_perms WHERE user_id = ?').get(userId);
  db.prepare('DELETE FROM user_perms WHERE user_id = ?').run(userId);
  db.prepare('INSERT INTO perm_log (user_id, by_user, before, after) VALUES (?, ?, ?, NULL)').run(userId, by, before ? JSON.stringify(before) : null);
}
