import { cardModel } from '../models/cardModel';
import { normaliseInsight, parseInsight, ruleInsight } from './aiInsight';
import { interestOf } from './interest';
import { guessWebsite, lookupWebsite } from './websiteLookup';

// Finds out about the company without being asked: reads the company's own web site (from the
// e-mail domain or an address on the form) and keeps what it says with the record. An empty
// Work area is filled from it, marked as a guess. Never throws - it is a bonus, not a step.
export async function enrichCompany(cardId: number): Promise<void> {
  try {
    const card = cardModel.findById(cardId);
    if (!card) return;
    const existing = parseInsight(card.ai_insight);
    const site = existing?.website || guessWebsite(card);
    if (!site) return;
    const info = await lookupWebsite(site);
    const interest = interestOf(card);
    const base = existing ?? ruleInsight({ notes: card.notes, interested_in: card.interested_in, products: interest.products, widths: interest.widths, other: interest.other });
    cardModel.setInsight(cardId, normaliseInsight({ ...base, website: info.website, websiteSummary: info.suggestion }, base.source));
    if (info.suggestion) cardModel.setWorkAreaGuess(cardId, info.suggestion);
  } catch {
    /* no web site, or it would not answer: the record is complete without it */
  }
}

// A few at a time, so a big import does not hammer anybody.
export async function enrichCompanies(ids: number[], concurrency = 3): Promise<void> {
  const queue = [...ids];
  await Promise.all(
    Array.from({ length: Math.min(concurrency, queue.length) }, async () => {
      for (let id = queue.shift(); id !== undefined; id = queue.shift()) await enrichCompany(id);
    })
  );
}
