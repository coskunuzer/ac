import fs from 'fs';
import path from 'path';
import { DatabaseSync } from 'node:sqlite';
import { paths } from '../config/env';
import { timeStatements, watchServer } from './slowLog';

fs.mkdirSync(path.dirname(paths.dbFile), { recursive: true });

// Uses Node's built-in node:sqlite (stable since Node 22.5) instead of a
// native addon like better-sqlite3 - deliberately avoids requiring a C++
// build toolchain (Visual Studio Build Tools on Windows, build-essential on
// Linux) on every machine that runs or develops this app, including the
// user's VPS. Requires Node >= 22.5 wherever this runs - see deploy/DEPLOY.md.
export const db = new DatabaseSync(paths.dbFile);
timeStatements(db);
watchServer(db);
db.exec('PRAGMA journal_mode = WAL');
db.exec('PRAGMA foreign_keys = ON');
db.exec('PRAGMA synchronous = NORMAL');
db.exec('PRAGMA busy_timeout = 5000');
db.exec('PRAGMA cache_size = -65536'); // 64 MB of pages kept in memory
db.exec('PRAGMA temp_store = MEMORY');
db.exec('PRAGMA mmap_size = 268435456');
try { db.exec('PRAGMA optimize = 0x10002'); } catch { /* an older SQLite: fine */ }
setInterval(() => { try { db.exec('PRAGMA optimize'); } catch { /* busy: next time */ } }, 6 * 3600_000).unref();
