-- "Interested in" as ticked products + a free "other" text + edge widths (mm),
-- stored next to the words written on the form (interested_in, kept as is).
ALTER TABLE cards ADD COLUMN interest_products TEXT;
ALTER TABLE cards ADD COLUMN interest_other TEXT;
ALTER TABLE cards ADD COLUMN interest_widths TEXT;
