import { db } from '../db/connection';
import { memoTables, memoTablesBy } from '../db/dataVersion';
import { linkMap } from './perfAnalytics';

// The owner's price rule (OWNER-RULES, 21 Nov) - the ONE implementation. The customer purchases view (services/purchases.ts), Price performance
// (services/pricePerf.ts) and the team analysis (services/teamPerf.ts) all call this, so the same customer shows the same index everywhere.
//
//   unit        EUR per kg for PVC / ABS / PP (and their two-colour, laser and hot-air kinds, PMMA); EUR per m2 for melamine and veneer (Ahşap).
//               Other groups (caps, metal, accessories) have no price: they count in revenue, never in a price or an index.
//   benchmark   the volume-weighted average of ALL customers in the same product group within the same window: total EUR / total kg (or m2).
//               Group companies (TECE DEKOR / TEZER) and accounts marked "not a customer" (intel_excluded) are left out of it.
//   windows     rolling 12 months ending at the data cut (the month of the last invoice day in the sales list): 0 = the last 12 months,
//               1 = the 12 before, 2 = the 12 before that. Each window has its own average; years are never compared. Only windows the
//               monthly rows cover fully are used (the old years are yearly rows).
//   prices      sales lines only (doc_type 'S'): returns are shown separately, never in a price - in the customer's price and the benchmark alike.
//   minimum     a group counts with at least MIN_QTY kg/m2 and MIN_EUR in the window; below that the price is not called good or low.
//   index       the customer's EUR/unit in a group ÷ the benchmark × 100. Several groups: weighted by the customer's revenue per group (only the
//               groups with enough volume); "low confidence" when those are under half of the priced revenue.
//   cache       every answer is kept until one of the tables it is read from is written (db/dataVersion.ts).

export const PRICE_UNIT: Record<string, 'kg' | 'm2'> = { PVC: 'kg', ABS: 'kg', PP: 'kg', PMMA: 'kg', 'PVC Çift Renk': 'kg', 'ABS Çift Renk': 'kg', 'Lazer PP': 'kg', 'Lazer Abs': 'kg', 'HotAir-PP': 'kg', Melamin: 'm2', 'Ahşap': 'm2' };
export const MIN_QTY = 100, MIN_EUR = 300;
export const GROUPCOS = /TECE\s*DE[CK]|TEZER/i;
const TABLES = ['intel_fact', 'intel_mat', 'intel_cust', 'intel_excluded', 'perf_links'] as const;

export interface GSum { eur: number; kg: number; m2: number }
export interface Win12 { key: string; from: string; to: string }
export interface GroupPrice { grp: string; unit: 'kg' | 'm2'; eur: number; qty: number; price: number; avg: number; index: number; ok: boolean }
export interface PriceIdx { index: number | null; sure: boolean; groups: GroupPrice[] }
export interface WindowIdx extends PriceIdx { key: string; from: string; to: string }

export const shiftYm = (ym: string, n: number): string => { let y = +ym.slice(0, 4), m = +ym.slice(5, 7) + n; while (m < 1) { m += 12; y--; } while (m > 12) { m -= 12; y++; } return `${y}-${String(m).padStart(2, '0')}`; };
const r1 = (v: number) => Math.round(v * 10) / 10;

// the data cut and the first month that has monthly rows
export const priceCut = memoTables(['intel_fact', 'intel_cust'], () => {
  const cut = (db.prepare('SELECT MAX(last_date) d FROM intel_cust').get() as { d: string | null }).d;
  const first = (db.prepare("SELECT MIN(period) p FROM intel_fact WHERE period NOT LIKE '%-00'").get() as { p: string | null }).p;
  return { cut, cutYm: cut ? cut.slice(0, 7) : null, firstMonthly: first };
});
// a window is usable when the monthly rows cover all of it
export const covered = (from: string): boolean => { const c = priceCut(); return !!c.firstMonthly && from >= c.firstMonthly; };

// the rolling 12-month windows ending at the data cut, newest first (only fully covered ones)
export function windows12(n = 3): Win12[] {
  const c = priceCut(); if (!c.cutYm) return [];
  const out: Win12[] = [];
  for (let i = 0; i < n; i++) { const w = { key: i === 0 ? '12m' : i === 1 ? '12m_p' : `12m_p${i}`, from: shiftYm(c.cutYm, -12 * i - 11), to: shiftYm(c.cutYm, -12 * i) }; if (covered(w.from)) out.push(w); }
  return out;
}

// accounts that never count in a benchmark: "not a customer" and the group companies
export const notCounted = memoTables(['intel_cust', 'intel_excluded'], () => {
  const s = new Set((db.prepare('SELECT code FROM intel_excluded').all() as { code: string }[]).map((r) => r.code));
  for (const r of db.prepare('SELECT code, name FROM intel_cust').all() as { code: string; name: string | null }[]) if (GROUPCOS.test(r.name ?? '')) s.add(r.code);
  return s;
});

// the company average per product group in one window: group -> { eur, qty, avg } (empty for a window the monthly rows do not cover)
const benchKept = memoTablesBy(TABLES as unknown as string[], (key: string) => {
  const [from, to] = key.split('|');
  const out = new Map<string, { eur: number; qty: number; avg: number }>();
  if (!covered(from)) return out;
  const skip = notCounted();
  const rows = db.prepare(`SELECT f.customer c, m.grp g, SUM(f.eur) e, SUM(f.kg) kg, SUM(f.m2) m2 FROM intel_fact f JOIN intel_mat m ON m.code = f.material
    WHERE f.period >= ? AND f.period <= ? AND f.period NOT LIKE '%-00' AND f.doc_type = 'S' GROUP BY 1, 2`).all(from, to) as { c: string; g: string; e: number; kg: number; m2: number }[];
  for (const r of rows) {
    const u = PRICE_UNIT[r.g]; if (!u || skip.has(r.c)) continue;
    const o = out.get(r.g) ?? { eur: 0, qty: 0, avg: 0 }; o.eur += r.e; o.qty += u === 'kg' ? r.kg : r.m2; out.set(r.g, o);
  }
  for (const [g, o] of out) { if (o.qty > 0 && o.eur > 0) o.avg = o.eur / o.qty; else out.delete(g); }
  return out;
}, 60);
export const benchFor = (from: string, to: string) => benchKept(`${from}|${to}`);
// the same as group -> EUR per unit
export const benchAvg = (from: string, to: string): Map<string, number> => new Map([...benchFor(from, to)].map(([g, o]) => [g, o.avg]));

// the index of a set of group sums (sales lines only) against a benchmark (group -> EUR per unit)
export function priceIndexOf(groups: Map<string, GSum> | undefined, bench: Map<string, number> | undefined): PriceIdx {
  const out: GroupPrice[] = [];
  let okEur = 0, okIdx = 0, priced = 0;
  if (groups && bench) for (const [grp, s] of groups) {
    const unit = PRICE_UNIT[grp], avg = bench.get(grp); if (!unit || !avg) continue;
    const qty = unit === 'kg' ? s.kg : s.m2; if (!(qty > 0) || !(s.eur > 0)) continue;
    const price = s.eur / qty, index = (price / avg) * 100, ok = qty >= MIN_QTY && s.eur >= MIN_EUR;
    priced += s.eur; if (ok) { okEur += s.eur; okIdx += index * s.eur; }
    out.push({ grp, unit, eur: s.eur, qty, price, avg, index, ok });
  }
  out.sort((a, b) => b.eur - a.eur);
  // rounded once, here (to 0.1): every page shows this number (or this number rounded to a whole one)
  return { index: okEur > 0 ? r1(okIdx / okEur) : null, sure: okEur > 0 && okEur >= priced * 0.5, groups: out };
}

// the SAP numbers that count as one customer: a number, the numbers linked to it (perf_links) and the one it is linked to
export function clusterCodes(codes: string[]): string[] {
  const L = linkMap(); const P = (s: string) => L.get(s) ?? s;
  const tops = new Set(codes.map(P));
  const out = new Set<string>([...codes, ...tops]);
  for (const [child, parent] of L) if (tops.has(parent)) out.add(child);
  return [...out].sort();
}

// the sales (lines 'S') of a set of SAP numbers per window and group
export function salesByWindow(codes: string[], wins: Win12[]): Map<string, GSum>[] {
  const res = wins.map(() => new Map<string, GSum>());
  if (!codes.length || !wins.length) return res;
  const rows = db.prepare(`SELECT f.period p, COALESCE(NULLIF(m.grp, ''), 'Other') g, SUM(f.eur) e, SUM(f.kg) kg, SUM(f.m2) m2 FROM intel_fact f LEFT JOIN intel_mat m ON m.code = f.material
    WHERE f.customer IN (${codes.map(() => '?').join(',')}) AND f.doc_type = 'S' AND f.period >= ? AND f.period <= ? AND f.period NOT LIKE '%-00' GROUP BY 1, 2`).all(...codes, wins[wins.length - 1].from, wins[0].to) as { p: string; g: string; e: number; kg: number; m2: number }[];
  for (const r of rows) {
    const i = wins.findIndex((w) => r.p >= w.from && r.p <= w.to); if (i < 0) continue;
    const o = res[i].get(r.g) ?? { eur: 0, kg: 0, m2: 0 }; o.eur += r.e; o.kg += r.kg; o.m2 += r.m2; res[i].set(r.g, o);
  }
  return res;
}

// the index of one customer per 12-month window (newest first): what the customer page shows
const seriesKept = memoTablesBy(TABLES as unknown as string[], (key: string): WindowIdx[] => {
  const codes = key ? key.split(',') : [];
  const wins = windows12();
  const sums = salesByWindow(codes, wins);
  return wins.map((w, i) => ({ ...w, ...priceIndexOf(sums[i], benchAvg(w.from, w.to)) }));
}, 500);
export const indexSeries = (codes: string[]): WindowIdx[] => seriesKept(clusterCodes(codes).join(','));

export const PRICE_LIMITS = { minQty: MIN_QTY, minEur: MIN_EUR };
