import type { CardRow } from '../models/cardModel';
import type { CatalogSection, SectionSelection } from './priceBook';
import { INTEREST_PRODUCTS, interestOf } from './interest';

export interface Recommendation extends SectionSelection {
  reasons: string[];
}

function normalise(s: string): string {
  return s
    .normalize('NFD')
    .replace(/\p{Diacritic}/gu, '')
    .replace(/ı/g, 'i')
    .toLowerCase();
}

// The offer follows what is ticked under "Interested in": each ticked product
// that has a page in the price list suggests that page, and the ticked edge
// widths become the offer's edge widths. Staff can change everything before
// sending. Products without a price page (Metal) and anything typed under
// "Other" are returned as `uncovered`, so the screen can tell staff about them.
export function recommend(
  card: CardRow,
  catalog: CatalogSection[]
): { recommendations: Recommendation[]; suggestMoq: boolean; widths: number[]; uncovered: string[] } {
  const interest = interestOf(card);
  const text = normalise([card.interested_in, card.work_area, card.notes].filter(Boolean).join(' \n '));

  const recommendations: Recommendation[] = [];
  const uncovered: string[] = [];
  for (const product of INTEREST_PRODUCTS.filter((p) => interest.products.includes(p.key))) {
    const section = product.sheet ? catalog.find((s) => s.sheet === product.sheet) : undefined;
    if (!section) {
      uncovered.push(product.label);
      continue;
    }
    recommendations.push({
      sheet: section.sheet,
      rows: section.rows.filter((r) => !r.hidden).map((r) => r.id),
      columns: section.columns.filter((c) => !c.hidden).map((c) => c.id),
      reasons: [`${product.label} is ticked under "Interested in"`],
    });
  }
  if (interest.other) uncovered.push(`Other: ${interest.other}`);

  // Nothing ticked at all: PVC is the usual starting point.
  if (interest.products.length === 0 && !interest.other) {
    const pvc = catalog.find((s) => s.sheet === 'PVC M2+22');
    if (pvc) {
      recommendations.push({
        sheet: pvc.sheet,
        rows: pvc.rows.filter((r) => !r.hidden).map((r) => r.id),
        columns: pvc.columns.filter((c) => !c.hidden).map((c) => c.id),
        reasons: ['nothing ticked - PVC is the usual starting point'],
      });
    }
  }

  // Visitors who ask about minimum quantities get the MOQ page suggested.
  const suggestMoq = /\bmoq\b|minimum|min\.? order|asgari|minimum siparis|en az/.test(text);
  return { recommendations, suggestMoq, widths: interest.widths, uncovered };
}
