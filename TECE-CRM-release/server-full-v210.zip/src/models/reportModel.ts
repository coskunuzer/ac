import { db } from '../db/connection';
import { INTEREST_PRODUCTS, interestLabel, interestOf } from '../services/interest';

// A "hot lead" is a visitor the staff member rated 8/10 or higher on the
// printed form - the people worth following up first.
export const HOT_RATE = 5;

export interface DashboardTotals {
  captured: number;
  confirmed: number;
  needsReview: number;
  extractionErrors: number;
  hot: number;
  hotWithoutThankYou: number;
  thankYouSent: number;
  offersSent: number;
  avgRate: number | null;
}

export interface QueueCard {
  id: number;
  name: string | null;
  company: string | null;
  country: string | null;
  rate: number;
  person: string | null;
  interested_in: string | null;
  email: string | null;
  status: 'needs_review' | 'confirmed';
  created_at: string;
  thank_you_sent_at: string | null;
  offers: number;
}

// ids: the customers this viewer may see (undefined = everybody, for an admin).
function scope(exhibitionId?: number, ids?: number[]): { where: string; params: Record<string, number> } {
  const clauses: string[] = ["(c.stage IS NULL OR c.stage != 'lead')", "c.market != 'domestic'"];
  const params: Record<string, number> = {};
  if (exhibitionId) {
    clauses.push('c.exhibition_id = @exhibitionId');
    params.exhibitionId = exhibitionId;
  }
  if (ids) clauses.push(ids.length ? `c.id IN (${ids.map((n) => Math.trunc(Number(n))).join(',')})` : '0');
  return { where: clauses.length ? `WHERE ${clauses.join(' AND ')}` : '', params };
}

export const reportModel = {
  totals(exhibitionId?: number, ids?: number[]): DashboardTotals {
    const { where, params } = scope(exhibitionId, ids);
    const row = db
      .prepare(
        `SELECT
           COUNT(*) AS captured,
           SUM(CASE WHEN c.status = 'confirmed' THEN 1 ELSE 0 END) AS confirmed,
           SUM(CASE WHEN c.status = 'needs_review' THEN 1 ELSE 0 END) AS needsReview,
           SUM(CASE WHEN c.extraction_error IS NOT NULL AND c.extraction_error != '' THEN 1 ELSE 0 END) AS extractionErrors,
           SUM(CASE WHEN c.rate >= ${HOT_RATE} THEN 1 ELSE 0 END) AS hot,
           SUM(CASE WHEN c.rate >= ${HOT_RATE} AND c.thank_you_sent_at IS NULL THEN 1 ELSE 0 END) AS hotWithoutThankYou,
           SUM(CASE WHEN c.thank_you_sent_at IS NOT NULL THEN 1 ELSE 0 END) AS thankYouSent,
           SUM(CASE WHEN EXISTS (SELECT 1 FROM offers_sent o WHERE o.card_id = c.id AND o.kind = 'offer') THEN 1 ELSE 0 END) AS offersSent,
           ROUND(AVG(c.rate), 1) AS avgRate
         FROM cards c ${where}`
      )
      .get(params) as Record<string, number | null>;
    return {
      captured: row.captured ?? 0,
      confirmed: row.confirmed ?? 0,
      needsReview: row.needsReview ?? 0,
      extractionErrors: row.extractionErrors ?? 0,
      hot: row.hot ?? 0,
      hotWithoutThankYou: row.hotWithoutThankYou ?? 0,
      thankYouSent: row.thankYouSent ?? 0,
      offersSent: row.offersSent ?? 0,
      avgRate: row.avgRate,
    };
  },

  byDay(exhibitionId?: number, ids?: number[]): { day: string; cards: number; hot: number }[] {
    const { where, params } = scope(exhibitionId, ids);
    return db
      .prepare(
        `SELECT date(c.created_at) AS day, COUNT(*) AS cards,
                SUM(CASE WHEN c.rate >= ${HOT_RATE} THEN 1 ELSE 0 END) AS hot
         FROM cards c ${where} GROUP BY day ORDER BY day`
      )
      .all(params) as unknown as { day: string; cards: number; hot: number }[];
  },

  // Groups by one free-text column (country, interested_in), most cards first.
  byColumn(column: 'country' | 'interested_in', exhibitionId?: number, ids?: number[], limit = 10): { label: string; cards: number; hot: number }[] {
    const { where, params } = scope(exhibitionId, ids);
    const filter = `${where ? `${where} AND` : 'WHERE'} c.${column} IS NOT NULL AND TRIM(c.${column}) != ''`;
    return db
      .prepare(
        `SELECT TRIM(c.${column}) AS label, COUNT(*) AS cards,
                SUM(CASE WHEN c.rate >= ${HOT_RATE} THEN 1 ELSE 0 END) AS hot
         FROM cards c ${filter} GROUP BY label ORDER BY cards DESC LIMIT ${limit}`
      )
      .all(params) as unknown as { label: string; cards: number; hot: number }[];
  },

  // What visitors asked for: one count per ticked product (and "Other"), most cards first.
  byInterest(exhibitionId?: number, ids?: number[], limit = 10): { label: string; cards: number; hot: number }[] {
    const { where, params } = scope(exhibitionId, ids);
    const rows = db
      .prepare(
        `SELECT c.rate, c.interested_in, c.work_area, c.notes, c.interest_products, c.interest_other, c.interest_widths
         FROM cards c ${where}`
      )
      .all(params) as unknown as { rate: number | null; interested_in: string | null; work_area: string | null; notes: string | null; interest_products: string | null; interest_other: string | null; interest_widths: string | null }[];
    const tally = new Map<string, { cards: number; hot: number }>();
    for (const r of rows) {
      const i = interestOf(r);
      const labels = INTEREST_PRODUCTS.filter((p) => i.products.includes(p.key)).map((p) => p.label);
      if (i.other) labels.push('Other');
      for (const label of labels) {
        const t = tally.get(label) ?? { cards: 0, hot: 0 };
        t.cards += 1;
        if ((r.rate ?? 0) >= HOT_RATE) t.hot += 1;
        tally.set(label, t);
      }
    }
    return [...tally.entries()].map(([label, t]) => ({ label, ...t })).sort((a, b) => b.cards - a.cards).slice(0, limit);
  },

  // Per staff member, by the "Person" written on the form (falls back to the
  // uploader's name when the form left it blank).
  byStaff(exhibitionId?: number, ids?: number[]): { staff: string; cards: number; hot: number; avgRate: number | null; thankYouPct: number; offers: number }[] {
    const { where, params } = scope(exhibitionId, ids);
    return db
      .prepare(
        `SELECT COALESCE(NULLIF(TRIM(c.person), ''), u.display_name, u.username) AS staff,
                COUNT(*) AS cards,
                SUM(CASE WHEN c.rate >= ${HOT_RATE} THEN 1 ELSE 0 END) AS hot,
                ROUND(AVG(c.rate), 1) AS avgRate,
                CAST(ROUND(100.0 * SUM(CASE WHEN c.thank_you_sent_at IS NOT NULL THEN 1 ELSE 0 END) / COUNT(*)) AS INTEGER) AS thankYouPct,
                SUM(CASE WHEN EXISTS (SELECT 1 FROM offers_sent o WHERE o.card_id = c.id AND o.kind = 'offer') THEN 1 ELSE 0 END) AS offers
         FROM cards c LEFT JOIN users u ON u.id = c.uploaded_by ${where}
         GROUP BY staff ORDER BY cards DESC`
      )
      .all(params) as unknown as { staff: string; cards: number; hot: number; avgRate: number | null; thankYouPct: number; offers: number }[];
  },

  // Hot leads still waiting for a follow-up, best first. Non-admin staff only
  // see their own cards here, the same rule as the records list.
  followUpQueue(opts: { exhibitionId?: number; restrictToUploaderId?: number; restrictToPersonName?: string | null }): QueueCard[] {
    const clauses = [`c.rate >= ${HOT_RATE}`];
    const params: Record<string, string | number> = {};
    if (opts.exhibitionId) {
      clauses.push('c.exhibition_id = @exhibitionId');
      params.exhibitionId = opts.exhibitionId;
    }
    if (opts.restrictToUploaderId !== undefined) {
      if (opts.restrictToPersonName) {
        clauses.push('(c.uploaded_by = @uploaderId OR c.person = @personName)');
        params.personName = opts.restrictToPersonName;
      } else {
        clauses.push('c.uploaded_by = @uploaderId');
      }
      params.uploaderId = opts.restrictToUploaderId;
    }
    return db
      .prepare(
        `SELECT c.id, c.name, c.company, c.country, c.rate, c.person, c.interested_in, c.work_area, c.notes,
                c.interest_products, c.interest_other, c.interest_widths, c.email, c.status, c.created_at,
                c.thank_you_sent_at,
                (SELECT COUNT(*) FROM offers_sent o WHERE o.card_id = c.id AND o.kind = 'offer') AS offers
         FROM cards c WHERE ${clauses.join(' AND ')}
           AND (c.thank_you_sent_at IS NULL
                OR NOT EXISTS (SELECT 1 FROM offers_sent o WHERE o.card_id = c.id AND o.kind = 'offer'))
         ORDER BY c.rate DESC, c.created_at ASC LIMIT 200`
      )
      .all(params)
      .map((row) => {
        // the extra columns are only there to build the label
        const { work_area: _w, notes: _n, interest_products: _p, interest_other: _o, interest_widths: _i, ...rest } = row as Record<string, unknown>;
        return { ...rest, interested_in: interestLabel(row as never) };
      }) as unknown as QueueCard[];
  },
};
