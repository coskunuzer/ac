// Purchases: what a customer (on its page) or a whole country (in the Country explorer) bought - products, quantities, price per kg, colours -
// from the Sales intelligence summary. The server works everything out (GET /api/purchases/card/:id and /country/:name, kept per data version);
// this module only draws. Charts are plain SVG with the shared palette in 92-buys.css (validated for light and dark).
import { h, Fragment, useState, useEffect, useMemo, useRef, useCallback, api, Link, useT, Icon, cx, errText, eur, Skel, Empty, loc, pctTxt, idxTone } from "./x-kit-1W3jRMzJ.js";
import { i as useLang } from "./LanguageContext-xagkSN7f.js";

// ------------------------------------------------------------------ who sees the tab (the server checks it again)
// sales figures: admin, a person without a permissions row, a row with "ledger", or Sales intelligence
export const buysAllowed = (u) => !!u && (u.role === "admin" || !u.perms || (u.perms.money || []).includes("ledger") || (u.perms.menu || []).includes("intel"));

// ------------------------------------------------------------------ numbers
const num = (v, d = 0) => (v == null || !Number.isFinite(v) ? "–" : v.toLocaleString(loc(), { maximumFractionDigits: d, minimumFractionDigits: d }));
const compact = (v) => {
  if (v == null || !Number.isFinite(v)) return "–";
  const a = Math.abs(v);
  const f = (x, d) => x.toLocaleString(loc(), { maximumFractionDigits: d });
  if (a >= 1e6) return f(v / 1e6, a >= 1e7 ? 1 : 2) + "M";
  if (a >= 1e4) return Math.round(v / 1e3) + "k";
  if (a >= 1e3) return f(v / 1e3, 1) + "k";
  return String(Math.round(v));
};
const money = (v) => eur(v, { short: true });
const price = (v, unit) => (v == null ? "–" : "€" + num(v, v < 1 ? 3 : 2) + "/" + unit);
const change = (a, b) => (b > 0 ? (a - b) / b : null);
const signed = (r) => (r == null ? "" : (r > 0 ? "+" : r < 0 ? "−" : "±") + pctTxt(num(Math.abs(Math.round(r * 1000) / 10), 1)));
const shareTxt = (s) => (s >= 0.995 ? pctTxt(100) : s >= 0.1 ? pctTxt(Math.round(s * 100)) : pctTxt(num(Math.round(s * 1000) / 10, 1)));
const MEASURES = { eur: { label: "Revenue", fmt: money, axis: (v) => "€" + compact(v) }, kg: { label: "Kilograms", fmt: (v) => compact(v) + " kg", axis: compact }, m2: { label: "m²", fmt: (v) => compact(v) + " m²", axis: compact } };

// month and period names in the language of the person
const useFmt = () => {
  const lang = (useLang() || "en").startsWith("tr") ? "tr-TR" : "en-GB";
  return useMemo(() => {
    const mf = new Intl.DateTimeFormat(lang, { month: "short", timeZone: "UTC" });
    const mfy = new Intl.DateTimeFormat(lang, { month: "short", year: "numeric", timeZone: "UTC" });
    const df = new Intl.DateTimeFormat(lang, { day: "numeric", month: "short", year: "numeric", timeZone: "UTC" });
    const d = (ym) => new Date(Date.UTC(+ym.slice(0, 4), +ym.slice(5, 7) - 1, 1));
    return {
      tr: lang === "tr-TR",
      mon: (ym) => mf.format(d(ym)),
      monYear: (ym) => (!ym ? "" : ym.endsWith("-00") ? ym.slice(0, 4) : mfy.format(d(ym))),
      day: (iso) => (!iso ? "" : iso.length <= 7 || iso.endsWith("-00") ? (iso.endsWith("-00") ? iso.slice(0, 4) : mfy.format(d(iso))) : df.format(new Date(iso + "T12:00:00Z"))),
      quarter: (q) => q.slice(5) + " " + q.slice(2, 4),
    };
  }, [lang]);
};

// ------------------------------------------------------------------ product groups: a colour per group, always the same one (never by rank)
const SLOT = { PVC: 1, ABS: 2, PP: 3, Melamin: 4, "PVC - Tapa": 5, "Ahşap": 6, "Metal - Ayna": 7, "ABS - Tapa": 8 };
const GROUP_NAME = { Melamin: "Melamine", "Ahşap": "Wood veneer", "Metal - Ayna": "Metal / mirror", "PVC - Tapa": "PVC caps", "ABS - Tapa": "ABS caps", "PVC Çift Renk": "PVC two-colour", "ABS Çift Renk": "ABS two-colour", "Lazer PP": "Laser PP", Other: "Other" };
const gColor = (g) => (SLOT[g] ? `var(--by-${SLOT[g]})` : "var(--by-other)");
const useGroupName = () => { const t = useT(); return (g) => (GROUP_NAME[g] ? t(GROUP_NAME[g]) : g || t("Other")); };
const Dot = ({ color }) => h("i", { className: "by-dot", style: { background: color }, "aria-hidden": true });

// SAP return reasons are written in Turkish; in English they get a plain name
const REASON = {
  "KALİTESİZLİK İADESİ": "Quality problem", "TON FARKI İADESİ": "Shade difference", "YANLIŞ SİPARİŞ İADESİ": "Wrong order", "MÜŞTERİNİN SATAMADIĞI ÜRÜN İADESİ": "Customer could not sell it",
  "YANLIŞ SEVKİYAT İADESİ": "Wrong shipment", "NAKLİYE KAYNAKLI İADE": "Damaged in transport", "AL-SAT İADESİ": "Buy-sell return", "MÜŞTERİ KAYNAKLI YANLIŞ SİPARİŞ": "Customer ordered wrong",
  "KALINLIK FARKI İADESİ": "Thickness difference", "Unspecified": "No reason given",
};

// a swatch for a decor: the colour its name suggests (white, oak, anthracite ...), otherwise a neutral chip
const TONES = [
  [/beyaz|white|weiss|blanc|bianco|snow|kar\b|polar/i, "#f3f1ec"], [/siyah|black|schwarz|noir|nero|ebony/i, "#1f1f20"], [/antras|anthra|graphite|grafit/i, "#3c3f44"],
  [/gri|grey|gray|platin|cement|beton|concrete|stone|taş/i, "#9a9b9b"], [/krem|cream|ivory|fildi|vanil|kaşmir|cashmere|magnolia/i, "#ece2cc"], [/bej|beige|sand|kum\b|latte|cappuc|mocha|mocca/i, "#cdb796"],
  [/ceviz|walnut|nuss|noce|mahog|maun|wenge|wengue|koyu|dark|tobacco|tütün/i, "#5e4130"], [/kiraz|cherry|kirsch|ciliegio|kızıl|teak|tik\b|rosewood/i, "#94502f"],
  [/meşe|oak|eiche|rovere|sonoma|halifax|lancelot|navaro|bartın|bartin/i, "#bf9466"], [/akçaağaç|maple|ahorn|kayın|beech|buche|birch|huş|pine|çam|ash|dişbudak|elm|karaağaç|acacia|akasya|hickory|wood|ahşap|ağaç/i, "#d4ad7d"],
  [/mavi|blue|navy|lacivert|indigo|petrol/i, "#3d5f8e"], [/kırmızı|red|bordo|bordeaux|burgundy|rouge|rosso/i, "#a3322d"], [/yeşil|green|olive|zeytin|sage|mint/i, "#5b7d58"],
  [/sarı|yellow|gold|altın|hardal|mustard/i, "#d9b44a"], [/turuncu|orange|terra/i, "#cf7a3a"], [/pembe|pink|rose|pudra/i, "#d9a0a6"], [/mor|purple|lila|lilac|violet/i, "#7a5a8e"],
  [/alüm|alum|metal|inox|steel|çelik|krom|chrome|silver|gümüş|ayna|mirror|titan/i, "linear-gradient(135deg,#d8dadd,#a6a9ae 55%,#e8e9eb)"],
  [/kahve|brown|braun|chocolate|çikolata|bronz|bronze|copper|bakır/i, "#7a5236"],
];
const toneOf = (name) => { for (const [re, c] of TONES) if (re.test(name || "")) return c; return null; };
function Swatch({ name, size = 36 }) {
  const c = toneOf(name);
  return h("span", { className: cx("by-sw", !c && "by-sw--none"), style: { width: size, height: size, background: c || undefined }, "aria-hidden": true });
}

// ------------------------------------------------------------------ chart helpers
function useWidth() {
  const ref = useRef(null);
  const [w, setW] = useState(0);
  useEffect(() => {
    const el = ref.current; if (!el) return undefined;
    setW(el.clientWidth);
    if (typeof ResizeObserver === "undefined") return undefined;
    let raf = 0;
    const ro = new ResizeObserver((es) => { cancelAnimationFrame(raf); raf = requestAnimationFrame(() => setW(Math.round(es[0].contentRect.width))); });
    ro.observe(el);
    return () => { ro.disconnect(); cancelAnimationFrame(raf); };
  }, []);
  return [ref, w];
}
// the top of the axis: four equal steps of a round size (1, 2, 2.5 or 5 times a power of ten)
const niceMax = (v) => { if (!(v > 0)) return 1; const raw = v / 4, p = Math.pow(10, Math.floor(Math.log10(raw))); for (const m of [1, 2, 2.5, 5, 10]) if (m * p >= raw) return m * p * 4; return 40 * p; };
const ticks = (max, n = 4) => Array.from({ length: n + 1 }, (_, i) => (max / n) * i);
// a bar with a 4px rounded top, square on the baseline
const barPath = (x, y, w, hgt) => { const r = Math.min(4, w / 2, hgt); return `M${x},${y + hgt}V${y + r}Q${x},${y} ${x + r},${y}H${x + w - r}Q${x + w},${y} ${x + w},${y + r}V${y + hgt}Z`; };

// the floating card that says what is under the pointer
function useTip() {
  const [tip, setTip] = useState(null);
  const show = useCallback((e, lines, box) => {
    const host = box || e.currentTarget.closest(".by-plot");
    if (!host) return;
    const r = host.getBoundingClientRect();
    const src = e.clientX != null && e.type !== "focus" ? { x: e.clientX, y: e.clientY } : (() => { const b = e.currentTarget.getBoundingClientRect(); return { x: b.left + b.width / 2, y: b.top }; })();
    setTip({ x: src.x - r.left, y: src.y - r.top, w: r.width, lines });
  }, []);
  const hide = useCallback(() => setTip(null), []);
  const node = tip
    ? h("div", { className: "by-tip", role: "status", style: { left: Math.max(8, Math.min(tip.x + 14, tip.w - 200)), top: Math.max(0, tip.y - 12) } },
        tip.lines.map((l, i) => (i === 0 ? h("b", { key: i }, l) : h("span", { key: i }, l.color ? h(Dot, { color: l.color }) : null, l.text || l))))
    : null;
  return [node, show, hide];
}

// ------------------------------------------------------------------ the column chart (revenue / kg / m² by month or year)
function Columns({ items, measure, label }) {
  const t = useT();
  const [ref, W] = useWidth();
  const [tip, show, hide] = useTip();
  const H = 220, padL = 52, padB = 26, padT = 18;
  const M = MEASURES[measure];
  const max = niceMax(Math.max(...items.map((x) => x[measure] || 0)));
  const iw = Math.max(0, W - padL - 8), ih = H - padB - padT;
  const band = items.length ? iw / items.length : 0, bw = Math.min(24, Math.max(4, band * 0.62));
  const every = Math.max(1, Math.ceil(46 / Math.max(1, band)));
  const peak = items.reduce((m, x, i) => ((x[measure] || 0) > (items[m]?.[measure] || 0) ? i : m), 0);
  return h("div", { className: "by-plot", ref },
    W > 0 ? h("svg", { width: W, height: H, role: "img", "aria-label": label, className: "by-svg" },
      ticks(max).map((v, i) => h("g", { key: i },
        h("line", { x1: padL, x2: W - 4, y1: padT + ih - (v / max) * ih, y2: padT + ih - (v / max) * ih, className: i === 0 ? "by-base" : "by-gl" }),
        h("text", { x: padL - 8, y: padT + ih - (v / max) * ih + 4, textAnchor: "end", className: "by-axis" }, M.axis(v)))),
      items.map((x, i) => {
        const v = Math.max(0, x[measure] || 0), bh = (v / max) * ih, cx0 = padL + band * i + band / 2;
        const lines = [x.long, M.fmt(x[measure]), measure !== "eur" ? money(x.eur) : compact(x.kg) + " kg", x.pkg != null ? price(x.pkg, "kg") : null, x.partial ? t("so far") : null].filter(Boolean);
        return h("g", { key: x.key },
          bh > 0 ? h("path", { d: barPath(cx0 - bw / 2, padT + ih - bh, bw, bh), className: cx("by-col", x.partial && "by-col--partial") }) : null,
          i === peak && v > 0 && band >= 18 ? h("text", { x: cx0, y: padT + ih - bh - 6, textAnchor: "middle", className: "by-val" }, M.axis(v)) : null,
          i % every === 0 || i === items.length - 1 ? h("text", { x: cx0, y: H - 8, textAnchor: "middle", className: "by-axis" }, x.short) : null,
          h("rect", { x: padL + band * i, y: padT, width: band, height: ih, className: "by-hit", tabIndex: 0, "aria-label": lines.join(", "), onMouseMove: (e) => show(e, lines), onFocus: (e) => show(e, lines), onMouseLeave: hide, onBlur: hide }));
      })) : h("div", { style: { height: H } }),
    tip);
}

// ------------------------------------------------------------------ the donut of product groups (with its legend table)
function Donut({ parts, total, label, center, sub }) {
  const [tip, show, hide] = useTip();
  const S = 176, R = 84, r = 58, c = S / 2;
  let a0 = -Math.PI / 2;
  const arcs = parts.filter((p) => p.value > 0).map((p) => {
    const a = (p.value / total) * Math.PI * 2, a1 = a0 + a;
    const large = a > Math.PI ? 1 : 0;
    const P = (ang, rad) => `${c + rad * Math.cos(ang)},${c + rad * Math.sin(ang)}`;
    const d = a >= Math.PI * 2 - 1e-6
      ? `M${c - R},${c}A${R},${R} 0 1 1 ${c + R},${c}A${R},${R} 0 1 1 ${c - R},${c}M${c - r},${c}A${r},${r} 0 1 0 ${c + r},${c}A${r},${r} 0 1 0 ${c - r},${c}Z`
      : `M${P(a0, R)}A${R},${R} 0 ${large} 1 ${P(a1, R)}L${P(a1, r)}A${r},${r} 0 ${large} 0 ${P(a0, r)}Z`;
    a0 = a1;
    return { ...p, d };
  });
  return h("div", { className: "by-plot by-donut" },
    h("svg", { width: S, height: S, viewBox: `0 0 ${S} ${S}`, role: "img", "aria-label": label },
      arcs.map((p) => h("path", { key: p.key, d: p.d, fill: p.color, className: "by-arc", tabIndex: 0, "aria-label": p.tip.join(", "), onMouseMove: (e) => show(e, p.tip), onFocus: (e) => show(e, p.tip), onMouseLeave: hide, onBlur: hide })),
      h("text", { x: c, y: c - 2, textAnchor: "middle", className: "by-donut-n" }, center),
      h("text", { x: c, y: c + 16, textAnchor: "middle", className: "by-axis" }, sub)),
    tip);
}

// ------------------------------------------------------------------ price per kg over time, a line per product group
function Lines({ xLabels, series, fmt, label, axis = (v) => "€" + num(v, 2), refLine = null }) {
  const t = useT();
  const [ref, W] = useWidth();
  const [tip, show, hide] = useTip();
  const [at, setAt] = useState(null);
  const H = 230, padL = 52, padR = series.length <= 4 ? 64 : 12, padT = 14, padB = 26;
  const all = series.flatMap((s) => s.values.filter((v) => v != null));
  if (!all.length) return h("p", { className: "by-muted" }, t("Not enough months to draw a trend yet."));
  if (refLine != null) all.push(refLine);
  let lo = Math.min(...all), hi = Math.max(...all);
  const span = Math.max(hi - lo, hi * 0.08); lo = Math.max(0, lo - span * 0.2); hi = hi + span * 0.2;
  { const raw = (hi - lo) / 4, p = Math.pow(10, Math.floor(Math.log10(raw))), st = [1, 2, 2.5, 5, 10].map((m) => m * p).find((x) => x >= raw) || raw; lo = Math.floor(lo / st) * st; hi = lo + st * Math.max(1, Math.ceil((hi - lo) / st)); }
  const iw = Math.max(0, W - padL - padR), ih = H - padT - padB, n = xLabels.length;
  const X = (i) => padL + (n <= 1 ? iw / 2 : (iw * i) / (n - 1)), Y = (v) => padT + ih - ((v - lo) / (hi - lo)) * ih;
  const every = Math.max(1, Math.ceil(54 / Math.max(1, iw / Math.max(1, n - 1))));
  const paths = series.map((s) => { let d = "", pen = false; s.values.forEach((v, i) => { if (v == null) { pen = false; return; } d += (pen ? "L" : "M") + X(i).toFixed(1) + "," + Y(v).toFixed(1); pen = true; }); return { ...s, d }; });
  // end labels only when they do not run into each other
  const ends = series.map((s) => { let i = s.values.length - 1; while (i >= 0 && s.values[i] == null) i--; return i >= 0 ? { s, i, y: Y(s.values[i]) } : null; }).filter(Boolean).sort((a, b) => a.y - b.y);
  const labelsFit = series.length <= 4 && ends.every((e, k) => k === 0 || e.y - ends[k - 1].y >= 14);
  const move = (e) => {
    const r = e.currentTarget.getBoundingClientRect(); const x = e.clientX - r.left; const i = Math.max(0, Math.min(n - 1, Math.round(((x - padL) / Math.max(1, iw)) * (n - 1))));
    setAt(i);
    const lines = [xLabels[i], ...series.filter((s) => s.values[i] != null).sort((a, b) => b.values[i] - a.values[i]).map((s) => ({ color: s.color, text: s.label + "  " + fmt(s.values[i], s, i) }))];
    show(e, lines, e.currentTarget.closest(".by-plot"));
  };
  const tk = (() => { const raw = (hi - lo) / 4, p = Math.pow(10, Math.floor(Math.log10(raw))), st = [1, 2, 2.5, 5, 10].map((m) => m * p).find((x) => x >= raw - 1e-9) || raw; const a = []; for (let v = lo; v <= hi + 1e-9; v += st) a.push(v); return a; })();
  return h("div", { className: "by-plot", ref },
    W > 0 ? h("svg", { width: W, height: H, role: "img", "aria-label": label, className: "by-svg" },
      tk.map((v, i) => h("g", { key: i }, h("line", { x1: padL, x2: W - padR + 4, y1: Y(v), y2: Y(v), className: i === 0 ? "by-base" : "by-gl" }), h("text", { x: padL - 8, y: Y(v) + 4, textAnchor: "end", className: "by-axis" }, axis(v)))),
      refLine != null ? h("g", null, h("line", { x1: padL, x2: W - padR + 4, y1: Y(refLine), y2: Y(refLine), className: "by-ref" }), h("text", { x: padL + 6, y: Y(refLine) - 5, className: "by-axis" }, t("company average"))) : null,
      xLabels.map((l, i) => (i % every === 0 || i === n - 1 ? h("text", { key: i, x: X(i), y: H - 8, textAnchor: n > 1 && i === 0 ? "start" : n > 1 && i === n - 1 ? "end" : "middle", className: "by-axis" }, l) : null)),
      at != null ? h("line", { x1: X(at), x2: X(at), y1: padT, y2: padT + ih, className: "by-cross" }) : null,
      paths.map((s) => h("path", { key: s.key, d: s.d, stroke: s.color, className: "by-line" })),
      // a quarter on its own (nothing bought the quarter before and after) has no line: it gets a dot
      series.flatMap((s) => s.values.map((v, i) => (v != null && s.values[i - 1] == null && s.values[i + 1] == null && i !== s.values.length - 1 ? h("circle", { key: s.key + "o" + i, cx: X(i), cy: Y(v), r: 3, fill: s.color }) : null))),
      ends.map((e) => h("circle", { key: e.s.key, cx: X(e.i), cy: e.y, r: 4, fill: e.s.color, className: "by-end" })),
      at != null ? series.map((s) => (s.values[at] != null ? h("circle", { key: "h" + s.key, cx: X(at), cy: Y(s.values[at]), r: 4.5, fill: s.color, className: "by-end" }) : null)) : null,
      labelsFit ? ends.map((e) => h("text", { key: "l" + e.s.key, x: X(e.i) + 9, y: e.y + 4, className: "by-endlabel" }, e.s.short)) : null,
      h("rect", { x: padL, y: padT, width: iw, height: ih, className: "by-hit", onMouseMove: move, onMouseLeave: () => { setAt(null); hide(); } })) : h("div", { style: { height: H } }),
    tip);
}

// a tiny bar strip: the last 8 quarters of a product
function Spark({ values, label }) {
  const max = Math.max(...values, 1), w = 6, gap = 2;
  return h("svg", { width: values.length * (w + gap), height: 22, role: "img", "aria-label": label, className: "by-spark" },
    values.map((v, i) => { const bh = v > 0 ? Math.max(2, (v / max) * 20) : 0; return bh ? h("path", { key: i, d: barPath(i * (w + gap), 22 - bh, w, bh), className: i === values.length - 1 ? "by-spark-now" : "" }) : h("rect", { key: i, x: i * (w + gap), y: 21, width: w, height: 1, className: "by-spark-zero" }); }));
}

// ------------------------------------------------------------------ pieces of the page
function Kpi({ icon, label, value, sub, delta, deltaText, deltaLabel, good = true, title }) {
  const dir = delta == null ? 0 : delta > 0.0005 ? 1 : delta < -0.0005 ? -1 : 0;
  const tone = dir === 0 ? "" : (dir > 0) === good ? "good" : "bad";
  return h("div", { className: "by-kpi", title },
    h("span", { className: "by-kpi-label" }, h(Icon, { n: icon, size: 18 }), label),
    h("b", { className: "by-kpi-value" }, value),
    delta != null ? h("span", { className: cx("by-delta", tone && "by-delta--" + tone) }, h(Icon, { n: dir > 0 ? "trending-up" : dir < 0 ? "trending-down" : "arrow-forward", size: 16 }), deltaText || signed(delta), deltaLabel ? h("small", null, " " + deltaLabel) : null) : null,
    sub ? h("span", { className: "by-kpi-sub" }, sub) : null);
}
const Card = ({ title, icon, sub, actions, className, children }) =>
  h("section", { className: cx("by-card", className) },
    h("header", { className: "by-card-head" },
      h("div", null, h("h3", null, icon ? h(Icon, { n: icon, size: 20 }) : null, title), sub ? h("p", null, sub) : null),
      actions || null),
    children);
function Seg({ value, options, onChange, label }) {
  return h("div", { className: "by-seg", role: "group", "aria-label": label }, options.map(([k, l]) => h("button", { key: k, type: "button", "aria-pressed": value === k, onClick: () => onChange(k) }, l)));
}

// ------------------------------------------------------------------ the whole analysis (a customer or a country)
function Analysis({ d, scope, cardId }) {
  const t = useT(), F = useFmt(), gName = useGroupName();
  const [measure, setMeasure] = useState("eur");
  const [span, setSpan] = useState("months");
  const [asTable, setAsTable] = useState(false);
  const T = d.totals;
  const l12d = change(d.l12.eur, d.p12.eur), kgd = change(d.l12.kg, d.p12.kg), pkgd = d.l12.pkg != null && d.p12.pkg != null ? change(d.l12.pkg, d.p12.pkg) : null;
  const ytdd = change(d.ytd.eur, d.pytd.eur);
  // the owner's price rule: the price per kg (PVC/ABS/PP) or per m² (melamine, veneer) against the average of ALL customers in the same group and 12-month window
  const PW = d.price || [], P0 = PW[0] || null, P1 = PW[1] || null;
  const idxD = P0 && P1 && P0.index != null && P1.index != null ? P0.index - P1.index : null;
  const unitTxt = (u) => (u === "m2" ? "m²" : "kg");
  const idxOf = useMemo(() => new Map((P0 ? P0.groups : []).map((g) => [g.g, g])), [P0]);
  const winLabel = (w) => F.mon(w.from) + " " + w.from.slice(2, 4) + "–" + F.mon(w.to) + " " + w.to.slice(2, 4);
  const mainG = P0 && P0.groups.find((g) => g.ok);
  const firstYear = (T.first || "").slice(0, 4);

  const colItems = useMemo(() => (span === "months"
    ? d.months.map((m) => ({ key: m.ym, short: m.ym.endsWith("-01") || m === d.months[0] ? F.mon(m.ym) + " " + m.ym.slice(2, 4) : F.mon(m.ym), long: F.monYear(m.ym), ...m }))
    : d.years.map((y) => ({ key: String(y.y), short: String(y.y), long: String(y.y) + (y.partial ? " · " + t("year to date") : ""), ...y }))), [d, span, F, t]);

  // groups: the six biggest by name colour, the rest folded into "Other"
  const groups = useMemo(() => {
    const named = d.groups.filter((g) => SLOT[g.g]).slice(0, 6), rest = d.groups.filter((g) => !named.includes(g));
    const out = named.map((g) => ({ ...g, color: gColor(g.g), label: gName(g.g) }));
    if (rest.length) { const o = rest.reduce((s, g) => ({ eur: s.eur + g.eur, kg: s.kg + g.kg, m2: s.m2 + g.m2, l12: s.l12 + g.l12, p12: s.p12 + g.p12 }), { eur: 0, kg: 0, m2: 0, l12: 0, p12: 0 }); out.push({ g: "_other", label: rest.length === 1 ? gName(rest[0].g) : t("Other ({n} groups)", { n: rest.length }), color: "var(--by-other)", ...o, pkg: o.kg > 0 ? o.eur / o.kg : null, pm2: null, share: o.eur / (T.eur || 1) }); }
    return out;
  }, [d, gName, t, T.eur]);
  const gTotal = groups.reduce((s, g) => s + Math.max(0, g[measure]), 0) || 1;

  // the trend is the index per 12-month window (oldest first), never a raw price across years
  const trend = useMemo(() => {
    const ws = [...PW].reverse(), names = [];
    for (const w of ws) for (const g of w.groups) if (g.ok && !names.includes(g.g)) names.push(g.g);
    const gs = names.slice(0, 5).map((g) => ({ key: g, label: gName(g), short: gName(g), color: gColor(g), values: ws.map((w) => { const x = w.groups.find((y) => y.g === g); return x && x.ok ? x.index : null; }), info: ws.map((w) => w.groups.find((y) => y.g === g)) }));
    const all = { key: "_all", label: t("All groups"), short: t("All"), color: "var(--text)", values: ws.map((w) => w.index), info: ws.map(() => null) };
    return { x: ws.map(winLabel), series: gs.length > 1 ? [all, ...gs] : gs.length ? gs : [all] };
  }, [d, F, gName, t]);

  const topMax = Math.max(...d.top.map((p) => p.eur), 1);
  const [allTop, setAllTop] = useState(false), [allStop, setAllStop] = useState(false);
  const topRows = allTop ? d.top : d.top.slice(0, 12), stopRows = allStop ? d.stopped.decors : d.stopped.decors.slice(0, 6);
  const heat = useMemo(() => {
    const max = Math.max(...d.spec.cells.map((c) => c[2]), 1), tot = d.spec.cells.reduce((s, c) => s + c[2], 0) || 1;
    const at = new Map(d.spec.cells.map((c) => [c[0] + "|" + c[1], c]));
    return { max, tot, at };
  }, [d]);
  const [tipH, showH, hideH] = useTip();

  const unitWord = { eur: t("revenue"), kg: t("kilograms"), m2: t("m²") }[measure];
  return h("div", { className: "by-grid" },
    // ---- the headline figures
    h("div", { className: "by-kpis" },
      h(Kpi, { icon: "receipt-long", label: t("Bought since {y}", { y: firstYear }), value: money(T.eur), sub: t("{kg} kg · {lines} invoice lines", { kg: compact(T.kg), lines: num(T.lines) }) }),
      h(Kpi, { icon: "bar-chart", label: t("Last 12 months"), value: money(d.l12.eur), delta: l12d, deltaLabel: t("vs prior 12 mo."), sub: t("Year to date {v}", { v: money(d.ytd.eur) }) + (ytdd != null ? " (" + signed(ytdd) + ")" : "") }),
      h(Kpi, { icon: "scale", label: t("Kilograms, last 12 months"), value: compact(d.l12.kg) + " kg", delta: kgd, sub: compact(d.l12.m2) + " m² · " + compact(d.l12.meters) + " m" }),
      h(Kpi, { icon: "show-chart", label: t("Price index, last 12 months"), title: t("Price per kg (PVC, ABS, PP) or per m² (melamine, veneer) against the average of all customers in the same product group and the same 12 months. 100 = company average."),
        value: P0 && P0.index != null ? String(P0.index) : "–", delta: idxD, deltaText: idxD != null ? (idxD > 0 ? "+" : idxD < 0 ? "−" : "±") + Math.abs(idxD) + " " + t("pts") : null, deltaLabel: t("vs prior 12 mo."),
        sub: !P0 || P0.index == null ? t("Too little volume to judge the price") : (P0.index >= 100 ? t("Above the company average (100)") : t("Below the company average (100)")) + (P0.sure ? "" : " · " + t("low volume")) + (mainG ? " · " + gName(mainG.g) + " " + price(mainG.price, unitTxt(mainG.unit)) + " " + t("vs {p} avg", { p: price(mainG.avg, unitTxt(mainG.unit)) }) : "") }),
      h(Kpi, { icon: "palette", label: t("Colours"), value: num(d.colours.count), sub: t("{n} bought in the last 12 months", { n: d.colours.l12 }) }),
      h(Kpi, { icon: "history", label: scope === "country" ? t("Customers buying") : t("Last order"), value: scope === "country" ? num(d.activeCustomers) + " / " + num(d.customers) : F.day(T.last), sub: scope === "country" ? t("bought in the last 12 months / ever") : t("{n} invoice days · {m} active months", { n: num(T.orders), m: T.activeMonths }) })),

    // ---- revenue (or kg, m²) by month or year
    h(Card, {
      title: span === "months" ? t("By month, the last 24 months") : t("By year"), icon: "bar-chart", className: "by-span2",
      sub: t("{what} per {p}. The lighter column is the month that is still running.", { what: t(MEASURES[measure].label), p: span === "months" ? t("month") : t("year") }),
      actions: h("div", { className: "by-tools" },
        h(Seg, { value: measure, onChange: setMeasure, label: t("Measure"), options: [["eur", "€"], ["kg", "kg"], ["m2", "m²"]] }),
        h(Seg, { value: span, onChange: setSpan, label: t("Period"), options: [["months", t("Months")], ["years", t("Years")]] }),
        h("button", { type: "button", className: "by-link", "aria-pressed": asTable, onClick: () => setAsTable((x) => !x) }, h(Icon, { n: asTable ? "bar-chart" : "table-chart", size: 18 }), asTable ? t("Chart") : t("Table"))),
    },
      asTable
        ? h("div", { className: "by-tablewrap" }, h("table", { className: "by-table" },
            h("thead", null, h("tr", null, h("th", null, span === "months" ? t("Month") : t("Year")), h("th", { className: "n" }, t("Revenue")), h("th", { className: "n" }, "kg"), h("th", { className: "n" }, "m²"), h("th", { className: "n" }, t("Meters")), h("th", { className: "n" }, t("€ per kg")))),
            h("tbody", null, colItems.map((x) => h("tr", { key: x.key }, h("td", null, x.long), h("td", { className: "n" }, money(x.eur)), h("td", { className: "n" }, num(x.kg)), h("td", { className: "n" }, num(x.m2)), h("td", { className: "n" }, num(x.meters)), h("td", { className: "n" }, price(x.pkg, "kg")))))))
        : h(Columns, { items: colItems, measure, label: t("{what} per {p}", { what: t(MEASURES[measure].label), p: span === "months" ? t("month") : t("year") }) })),

    // ---- the customers of a country
    scope === "country" && d.topCustomers ? h(Card, { title: t("Top customers in {c}", { c: d.country }), icon: "public", className: "by-span2", sub: t("Share of the country's purchases, all years. Customers you cannot open are not named.") },
      h("div", { className: "by-tablewrap" }, h("table", { className: "by-table by-custs" },
        h("thead", null, h("tr", null, h("th", null, "#"), h("th", null, t("Customer")), h("th", null, t("Share")), h("th", { className: "n" }, t("All years")), h("th", { className: "n" }, t("Last 12 months")), h("th", { className: "n by-hide-s", title: t("100 = company average, last 12 months") }, t("Price index")), h("th", { className: "n by-hide-s" }, t("Last purchase")))),
        h("tbody", null, d.topCustomers.map((c) => { const ch = change(c.l12, c.p12); return h("tr", { key: c.rank, className: cx(!c.name && "by-anon") },
          h("td", { className: "by-muted" }, c.rank),
          h("td", null, c.cardId ? h(Link, { to: `/cards/${c.cardId}/review?tab=buys` }, c.name) : c.name ? h("span", null, c.name) : h("span", { className: "by-muted" }, h(Icon, { n: "lock", size: 14 }), " ", t("Another customer")), c.mine ? h("span", { className: "by-pill by-pill--me" }, t("yours")) : null),
          h("td", null, h("div", { className: "by-barcell" }, h("span", { className: "by-hbar" }, h("i", { style: { width: Math.max(2, (c.share / (d.topCustomers[0].share || 1)) * 100) + "%" } })), h("em", null, shareTxt(c.share)))),
          h("td", { className: "n" }, money(c.eur)),
          h("td", { className: cx("n", ch != null && (ch >= 0 ? "by-up" : "by-down")) }, c.l12 > 0 ? money(c.l12) + (ch != null ? " " + signed(ch) : "") : h("span", { className: "by-muted" }, t("nothing"))),
          h("td", { className: cx("n by-hide-s", c.index != null && c.indexSure && ({ good: "by-up", bad: "by-down" })[idxTone(c.index)]) }, c.index == null ? "–" : c.indexSure ? String(c.index) : h("span", { className: "by-muted", title: t("low volume") }, "~" + c.index)),
          h("td", { className: "n by-hide-s" }, F.monYear(c.last))); }),
          d.otherCustomersEur > 0 ? h("tr", { className: "by-anon" }, h("td", null), h("td", { className: "by-muted" }, t("{n} more customers", { n: num(d.customers - d.topCustomers.length) })), h("td", null), h("td", { className: "n" }, money(d.otherCustomersEur)), h("td", null), h("td", { className: "by-hide-s" }), h("td", { className: "by-hide-s" })) : null)))) : null,

    // ---- product groups
    h(Card, { title: t("Product groups"), icon: "pie-chart", sub: t("Share of {what}, all years", { what: unitWord }) },
      h("div", { className: "by-groups" },
        h(Donut, { parts: groups.map((g) => ({ key: g.g, value: Math.max(0, g[measure]), color: g.color, tip: [g.label, MEASURES[measure].fmt(g[measure]), shareTxt(Math.max(0, g[measure]) / gTotal), g.pkg != null ? price(g.pkg, "kg") : ""].filter(Boolean) })), total: gTotal, label: t("Product groups"), center: num(d.groups.length), sub: d.groups.length === 1 ? t("group") : t("groups") }),
        h("table", { className: "by-table by-legend" },
          h("thead", null, h("tr", null, h("th", null, t("Group")), h("th", { className: "n" }, t("Share")), h("th", { className: "n" }, t("Price")), h("th", { className: "n", title: t("100 = company average, last 12 months") }, t("Index")), h("th", { className: "n" }, t("12 months")))),
          h("tbody", null, groups.map((g) => { const ch = change(g.l12, g.p12), ix = idxOf.get(g.g); return h("tr", { key: g.g },
            h("td", null, h(Dot, { color: g.color }), g.label),
            h("td", { className: "n" }, shareTxt(Math.max(0, g[measure]) / gTotal)),
            h("td", { className: "n by-nowrap" }, ix ? price(ix.price, unitTxt(ix.unit)) : g.pkg != null ? price(g.pkg, "kg") : "–"),
            h("td", { className: cx("n", ix && ix.ok && ({ good: "by-up", bad: "by-down" })[idxTone(ix.index)]), title: ix ? t("vs {p} avg", { p: price(ix.avg, unitTxt(ix.unit)) }) + (ix.ok ? "" : " · " + t("low volume")) : undefined }, ix ? (ix.ok ? String(ix.index) : h("span", { className: "by-muted" }, "~" + ix.index)) : "–"),
            h("td", { className: cx("n", ch != null && (ch >= 0 ? "by-up" : "by-down")) }, g.l12 > 0 ? money(g.l12) + (ch != null ? " " + signed(ch) : "") : g.p12 > 0 ? t("stopped") : "–")); }))))),

    // ---- price per kg over time
    h(Card, { title: t("Price index by 12-month period"), icon: "show-chart", sub: t("Price per kg (PVC, ABS, PP) or per m² (melamine, veneer) against the average of all customers in the same group and rolling 12 months up to the last invoice day. 100 = company average; above is a good price. Sales only (returns are shown separately); group companies are not in the average. The same number as Price performance.") },
      PW.length ? h(Lines, { xLabels: trend.x, series: trend.series, refLine: 100, axis: (v) => String(Math.round(v)), label: t("Price index by 12-month period"),
        fmt: (v, s, i) => { const x = s.info && s.info[i]; return String(v) + (x ? " · " + price(x.price, unitTxt(x.unit)) + " " + t("vs {p} avg", { p: price(x.avg, unitTxt(x.unit)) }) : ""); } }) : h("p", { className: "by-muted" }, t("Not enough months to draw a trend yet.")),
      trend.series.length > 1 ? h("ul", { className: "by-keys" }, trend.series.map((s) => h("li", { key: s.key }, h("i", { className: "by-key-line", style: { background: s.color } }), s.label))) : null),

    // ---- top products
    h(Card, { title: t("Top products"), icon: "inventory", className: "by-span2", sub: t("{n} different products; the {k} biggest by revenue", { n: num(T.products), k: d.top.length }) },
      h("div", { className: "by-tablewrap" }, h("table", { className: "by-table by-products" },
        h("thead", null, h("tr", null, h("th", null, t("Product")), h("th", null, t("Size")), h("th", { className: "n" }, "kg"), h("th", { className: "n by-hide-s" }, "m²"), h("th", { className: "n by-hide-s" }, t("Meters")), h("th", null, t("Revenue")), h("th", { className: "n" }, t("€ per kg")), h("th", { className: "n by-hide-s" }, t("€ per m²")), h("th", { className: "n by-hide-s" }, t("€ per m")), h("th", { className: "by-hide-s" }, t("8 quarters")))),
        h("tbody", null, topRows.map((p) => h("tr", { key: p.mat },
          h("td", null, h("div", { className: "by-prod" }, h(Swatch, { name: (p.colour && p.colour.name) || p.desc, size: 28 }), h("div", null, h("b", null, p.desc || p.mat), h("small", null, h(Dot, { color: gColor(p.g) }), gName(p.g), " · ", p.mat, p.colour && p.colour.board ? " · " + p.colour.board : "")))),
          h("td", { className: "by-nowrap" }, p.th ? p.th + " × " + p.w + " mm" : "–", p.sizes > 1 ? h("small", { className: "by-muted" }, " +" + (p.sizes - 1)) : null),
          h("td", { className: "n" }, num(p.kg)), h("td", { className: "n by-hide-s" }, num(p.m2)), h("td", { className: "n by-hide-s" }, num(p.meters)),
          h("td", null, h("div", { className: "by-barcell" }, h("span", { className: "by-hbar" }, h("i", { style: { width: Math.max(2, (p.eur / topMax) * 100) + "%" } })), h("b", null, money(p.eur)))),
          h("td", { className: "n" }, p.pkg != null ? "€" + num(p.pkg, 2) : "–"), h("td", { className: "n by-hide-s" }, p.pm2 != null ? "€" + num(p.pm2, 2) : "–"), h("td", { className: "n by-hide-s" }, p.pm != null ? "€" + num(p.pm, 3) : "–"),
          h("td", { className: "by-hide-s" }, h(Spark, { values: p.q, label: t("Revenue of the last 8 quarters") }))))))),
      d.top.length > 12 ? h("button", { type: "button", className: "by-link by-more", "aria-expanded": allTop, onClick: () => setAllTop((x) => !x) }, h(Icon, { n: allTop ? "keyboard-arrow-up" : "keyboard-arrow-down", size: 18 }), allTop ? t("Show fewer") : t("Show all {n}", { n: d.top.length })) : null),

    // ---- colours
    h(Card, { title: t("Colours"), icon: "palette", className: "by-span2", sub: t("{n} different decors ({k} in the colour database); share of revenue", { n: num(d.colours.count), k: num(d.colours.known) }) },
      h("ul", { className: "by-colours" }, d.colours.top.map((c) => h("li", { key: c.dec, className: "by-colour", title: c.name },
        h(Swatch, { name: c.name }),
        h("div", { className: "by-colour-txt" }, h("b", null, c.name || c.dec), h("small", null, c.board ? c.board + " · " : "", c.dec, " · ", gName(c.g)),
          h("span", { className: "by-share" }, h("span", { className: "by-hbar" }, h("i", { style: { width: Math.max(2, (c.share / (d.colours.top[0].share || 1)) * 100) + "%" } })), h("em", null, shareTxt(c.share)), h("span", { className: "by-muted" }, money(c.eur))))))),
      d.colours.rest > 0 ? h("p", { className: "by-muted" }, t("{n} more decors: {v}", { n: num(d.colours.count - d.colours.top.length), v: money(d.colours.rest) })) : null),

    // ---- thickness x width
    d.spec.th.length ? h(Card, { title: t("Thickness × width"), icon: "straighten", className: "by-span2", sub: t("Meters bought by size since {m} (the months kept in detail); darker = more", { m: F.monYear(d.monthlyFrom) }) },
      h("div", { className: "by-plot by-heatwrap" },
        h("table", { className: "by-heat", role: "grid", "aria-label": t("Thickness × width") },
          h("thead", null, h("tr", null, h("th", null, "mm"), d.spec.w.map((w) => h("th", { key: w }, w >= 999 ? t("wide") : w)), h("th", { className: "n" }, t("Total")))),
          h("tbody", null, d.spec.th.map((th, ti) => { const row = d.spec.w.map((_, wi) => heat.at.get(ti + "|" + wi)); const rt = row.reduce((s, c) => s + (c ? c[2] : 0), 0); return h("tr", { key: th },
            h("th", null, th),
            row.map((c, wi) => { if (!c) return h("td", { key: wi, className: "by-heat-0" }); const f = Math.sqrt(c[2] / heat.max); const lines = [th + " × " + (d.spec.w[wi] >= 999 ? t("wide") : d.spec.w[wi]) + " mm", compact(c[2]) + " m · " + shareTxt(c[2] / heat.tot), money(c[3]), compact(c[4]) + " kg"];
              return h("td", { key: wi, tabIndex: 0, "aria-label": lines.join(", "), style: { "--f": Math.round(12 + f * 88) + "%" }, className: cx("by-heat-c", f > 0.55 && "by-heat-dark"), onMouseMove: (e) => showH(e, lines), onFocus: (e) => showH(e, lines), onMouseLeave: hideH, onBlur: hideH }, f > 0.25 ? shareTxt(c[2] / heat.tot) : ""); }),
            h("td", { className: "n by-muted" }, shareTxt(rt / heat.tot))); }))),
        tipH)) : null,

    // ---- stopped buying (opportunities)
    h(Card, { title: t("Bought before, not in the last 12 months"), icon: "lightbulb", sub: d.stopped.decorsCount ? t("{n} decors not bought since {m}: worth an offer", { n: num(d.stopped.decorsCount), m: F.monYear(d.l12From) }) : t("Everything bought before was bought again in the last 12 months.") },
      d.stopped.groups.length ? h("p", { className: "by-stopgroups" }, t("Whole product groups:"), " ", d.stopped.groups.map((g) => h("span", { key: g.g, className: "by-pill" }, h(Dot, { color: gColor(g.g) }), gName(g.g), " · ", money(g.eur), " · ", t("last {m}", { m: F.monYear(g.last) })))) : null,
      d.stopped.decors.length ? h("ul", { className: "by-stopped" }, stopRows.map((c) => h("li", { key: c.dec },
        h(Swatch, { name: c.name, size: 28 }),
        h("div", null, h("b", null, c.name || c.dec), h("small", null, gName(c.g), " · ", c.dec, c.board ? " · " + c.board : "")),
        h("div", { className: "by-stopped-n" }, h("b", null, money(c.eur)), h("small", null, t("last {m}", { m: F.monYear(c.last) })))))) : h(Empty, { icon: "check-circle", title: t("Nothing dropped") }),
      d.stopped.decors.length > 6 ? h("button", { type: "button", className: "by-link by-more", "aria-expanded": allStop, onClick: () => setAllStop((x) => !x) }, h(Icon, { n: allStop ? "keyboard-arrow-up" : "keyboard-arrow-down", size: 18 }), allStop ? t("Show fewer") : t("Show all {n}", { n: d.stopped.decors.length })) : null,
      scope === "card" && cardId && d.stopped.decors.length ? h(Link, { className: "tc-btn tc-btn--secondary tc-btn--md by-cta", to: `/cards/${cardId}/thank-you?tab=offer` }, h(Icon, { n: "send", size: 18 }), t("Make an offer")) : null),

    // ---- returns
    h(Card, { title: t("Returns"), icon: "undo", sub: d.returns.eur > 0 ? t("{v} returned: {s} of what was bought", { v: money(d.returns.eur), s: shareTxt(d.returns.share) }) : t("Nothing was returned.") },
      d.returns.reasons.length ? h("ul", { className: "by-reasons" }, d.returns.reasons.slice(0, 6).map((r) => h("li", { key: r.r },
        h("div", { className: "by-reason-top" }, h("span", null, F.tr ? r.r : t(REASON[r.r] || r.r)), h("b", null, money(r.eur))),
        h("span", { className: "by-hbar by-hbar--warn" }, h("i", { style: { width: Math.max(2, (r.eur / (d.returns.reasons[0].eur || 1)) * 100) + "%" } })),
        h("small", { className: "by-muted" }, r.n === 1 ? t("1 line") : t("{n} lines", { n: r.n }))))) : h(Empty, { icon: "check-circle", title: t("No returns") }),
      h("div", { className: "by-mix" },
        h("h4", null, t("Thickness mix")),
        h("div", { className: "by-mixbar", role: "img", "aria-label": t("Thickness mix") }, (() => { const tot = d.thMix.reduce((s, x) => s + x.meters, 0) || 1; return d.thMix.filter((x) => x.meters / tot >= 0.01).map((x, i) => h("span", { key: x.th, style: { flex: x.meters / tot, opacity: 1 - i * 0.13 }, title: x.th + " mm · " + shareTxt(x.meters / tot) }, x.meters / tot >= 0.09 ? x.th + " mm" : "")); })()),
      )),


  );
}

// ------------------------------------------------------------------ loading (kept for a few minutes, so going back to the tab is instant)
const kept = new Map();
function usePurchases(path) {
  const hit = kept.get(path);
  const [state, setState] = useState(hit && Date.now() - hit.at < 300000 ? { data: hit.data } : { loading: true });
  useEffect(() => {
    let alive = true;
    const k = kept.get(path);
    if (k && Date.now() - k.at < 300000) { setState({ data: k.data }); return undefined; }
    setState({ loading: true });
    api.get(path).then((data) => { kept.set(path, { at: Date.now(), data }); if (alive) setState({ data }); }).catch((e) => alive && setState({ error: errText(e, "Could not load") }));
    return () => { alive = false; };
  }, [path]);
  return state;
}
const Loading = () => h("div", { className: "by-grid", "aria-busy": "true" }, h("div", { className: "by-kpis" }, [0, 1, 2, 3, 4, 5].map((i) => h(Skel, { key: i, height: 96 }))), h("div", { className: "by-span2" }, h(Skel, { height: 280 })), h(Skel, { height: 260 }), h(Skel, { height: 260 }));

// the "Purchases" tab of a customer
export function BuysTab({ card, goDetails }) {
  const t = useT(), F = useFmt();
  const s = usePurchases(`/purchases/card/${card.id}`);
  if (s.loading) return h("div", { className: "by" }, h(Loading));
  if (s.error) return h("div", { className: "by" }, h("div", { className: "by-card" }, h(Empty, { icon: "lock", title: t("Purchases are not available") }, t(s.error))));
  const d = s.data;
  const head = h("div", { className: "by-head" },
    h("div", null,
      h("h2", null, t("Purchases")),
      h("p", null, d.sap && d.sap.length ? t("SAP {code}", { code: d.sap.join(", ") }) : t("No SAP number"), !d.empty ? " · " + t("data through {d}", { d: F.day(d.cut) }) : "")),
    d.country ? h(Link, { className: "tc-btn tc-btn--secondary tc-btn--md", to: `/map?view=countries&c=${encodeURIComponent(d.country)}&t=buys` }, h(Icon, { n: "public", size: 18 }), t("All of {c}", { c: d.country })) : null);
  if (d.noSap) return h("div", { className: "by" }, head, h("div", { className: "by-card" }, h(Empty, { icon: "receipt-long", title: t("No SAP number on this customer") }, t("Add it under Details to see what they bought."), " ", goDetails ? h("button", { type: "button", className: "tc-btn tc-btn--secondary tc-btn--md", onClick: goDetails }, t("Open Details")) : null)));
  if (d.empty) return h("div", { className: "by" }, head, h("div", { className: "by-card" }, h(Empty, { icon: "receipt-long", title: t("No purchases recorded under SAP {code}", { code: d.sap.join(", ") }) }, t("Purchases come from Sales intelligence (the SAP sales list). New months show here after the next upload."))));
  return h("div", { className: "by" }, head, h(Analysis, { d, scope: "card", cardId: card.id }));
}

// the "Purchases" tab of a country in the Country explorer
export function BuysCountry({ country }) {
  const t = useT(), F = useFmt();
  const s = usePurchases(`/purchases/country/${encodeURIComponent(country)}`);
  if (s.loading) return h("div", { className: "by by--country" }, h(Loading));
  if (s.error) return h("div", { className: "by by--country" }, h("div", { className: "by-card" }, h(Empty, { icon: "lock", title: t("Purchases are not available") }, t(s.error))));
  const d = s.data;
  if (d.empty) return h("div", { className: "by by--country" }, h("div", { className: "by-card" }, h(Empty, { icon: "receipt-long", title: t("No purchases recorded for {c}", { c: d.country }) }, t("Purchases come from Sales intelligence (the SAP sales list). A customer counts for a country through its CRM card or the SAP customer list."))));
  return h("div", { className: "by by--country" },
    h("div", { className: "by-head" }, h("div", null, h("h2", null, t("What {c} bought", { c: d.country })), h("p", null, t("{n} customers with an SAP account", { n: num(d.customers) }), " · ", t("data through {d}", { d: F.day(d.cut) })))),
    h(Analysis, { d, scope: "country" }));
}
