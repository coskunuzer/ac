-- Round 2 of the complaints: the change requests of the quality department (Nuray) and of sales.
ALTER TABLE complaints ADD COLUMN credit_note TEXT;          -- "Yansıyan maliyet": the credit note that came with the cost
ALTER TABLE complaints ADD COLUMN rep_user_id INTEGER;       -- the sales representative the complaint is about (quality can change it)
ALTER TABLE complaints ADD COLUMN result_text TEXT;          -- "Sonuç" (the root cause and the action taken have their own columns)
ALTER TABLE complaints ADD COLUMN share_result INTEGER NOT NULL DEFAULT 0;  -- 1 = quality lets the sales representative read root cause / result / action / reports

-- reports of the review and the result (PDF, Excel, photos) added by hand by quality; who uploaded them and when is kept (K11)
CREATE TABLE IF NOT EXISTS complaint_files (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  complaint_id INTEGER NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
  kind TEXT NOT NULL DEFAULT 'report',
  stored_name TEXT NOT NULL,
  original_name TEXT,
  uploaded_by INTEGER,
  uploaded_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_complaint_files ON complaint_files(complaint_id);

-- the panel now has 8 statuses: the ones that were dropped go to the nearest one that is left
UPDATE complaints SET internal_status = 'Ön inceleme' WHERE internal_status = 'Değerlendirmede';
UPDATE complaints SET internal_status = 'Birim yanıtı bekleniyor' WHERE internal_status = 'Ek inceleme';
UPDATE complaints SET internal_status = 'KYS değerlendirmesi bekleniyor' WHERE internal_status IN ('Aksiyon planlanıyor', 'Aksiyon devam ediyor', 'Kapanış değerlendirmesi');
UPDATE complaints SET priority = 'high' WHERE priority = 'urgent';
