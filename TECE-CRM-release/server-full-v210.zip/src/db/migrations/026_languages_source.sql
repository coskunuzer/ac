-- Languages and where a customer came from.

-- The language of the screens a person sees ('en' or 'tr'); empty = the company's default (an admin sets it).
ALTER TABLE users ADD COLUMN ui_language TEXT;

-- The language the offer and the e-mail to this customer are written in: en (default), ru, tr, es or fr.
-- Chosen by the AI when the customer is added; anybody can change it.
ALTER TABLE cards ADD COLUMN language TEXT;

-- How we got to know the customer: fair, visit, email, call, website, referral, other.
ALTER TABLE cards ADD COLUMN source TEXT;

-- Translations of offer texts (so a text is translated by the AI only once per language).
CREATE TABLE IF NOT EXISTS translations (
  lang TEXT NOT NULL,
  source TEXT NOT NULL,
  result TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (lang, source)
);
