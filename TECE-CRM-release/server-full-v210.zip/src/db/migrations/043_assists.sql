-- An assistant with a login (Sena for Abdullah, Ziya for Sunay): signs in with their own password and works as the person they assist, without admin rights.
ALTER TABLE users ADD COLUMN assists_id INTEGER REFERENCES users(id);
