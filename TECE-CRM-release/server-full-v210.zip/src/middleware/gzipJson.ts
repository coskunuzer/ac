import type { NextFunction, Request, Response } from 'express';
import { gzip } from 'node:zlib';

// Compresses big JSON answers with Node's built-in zlib (no extra npm package, so the
// cPanel deploy stays unchanged). Small answers and clients without gzip are untouched.
const MIN_BYTES = 1400;

export function gzipJson(req: Request, res: Response, next: NextFunction) {
  if (!String(req.headers['accept-encoding'] || '').includes('gzip')) return next();
  const original = res.json.bind(res);
  res.json = ((body?: unknown) => {
    const text = JSON.stringify(body);
    if (text === undefined || text.length < MIN_BYTES) return original(body);
    gzip(Buffer.from(text, 'utf8'), { level: 5 }, (err, buf) => {
      if (err || res.headersSent) return original(body);
      res.setHeader('Content-Type', 'application/json; charset=utf-8');
      res.setHeader('Content-Encoding', 'gzip');
      res.setHeader('Vary', 'Accept-Encoding');
      res.setHeader('Content-Length', String(buf.length));
      res.end(buf);
    });
    return res;
  }) as typeof res.json;
  next();
}
