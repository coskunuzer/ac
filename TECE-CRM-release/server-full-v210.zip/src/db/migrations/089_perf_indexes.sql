-- Speed: indexes for the questions the pages ask most (found by timing every page against a copy with 23,000 customers).
-- Nothing is changed in the data; every index can be dropped again without any effect other than speed.

-- "was an offer sent to this customer?" is asked for every customer of a list, a report, the follow-ups and the radar:
-- without an index every one of those questions read the whole table of sent offers.
CREATE INDEX IF NOT EXISTS idx_offers_card ON offers_sent (card_id, kind, sent_at);
CREATE INDEX IF NOT EXISTS idx_offers_sent_at ON offers_sent (sent_at);

-- the to-dos of one customer (the customer page), and deleting a customer no longer reads every to-do
CREATE INDEX IF NOT EXISTS idx_todos_card ON todos (card_id);

-- the customer list in its usual order (newest first), one page at a time, without sorting all customers first
CREATE INDEX IF NOT EXISTS idx_cards_created ON cards (created_at DESC, id DESC);

-- "what happened lately" (points, team report, last contact) without reading every activity
CREATE INDEX IF NOT EXISTS idx_activities_created ON activities (created_at);
CREATE INDEX IF NOT EXISTS idx_activities_type_card ON activities (type, card_id, created_at);

-- the ledger by date (sales of the last 12 months, "data as of")
CREATE INDEX IF NOT EXISTS idx_ledger_date ON ledger_transactions (tx_date);

-- the e-mails that went out lately (reports, the mail check)
CREATE INDEX IF NOT EXISTS idx_sent_emails_sent_at ON sent_emails (sent_at);


-- the points of a day (the daily goal, the ranking, the team report): "what did each person do on these days" straight from an index
-- instead of working out the day of every activity ever written
CREATE INDEX IF NOT EXISTS idx_activities_local_day ON activities (date(datetime(created_at, '+3 hours')), user_id, type) WHERE imported = 0;

-- fresh statistics, so the database picks the right index
ANALYZE;
