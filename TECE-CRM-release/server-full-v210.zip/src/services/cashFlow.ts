// Cash flow for the admin: pick two dates and see the money that comes in between them.
//  - "falling due": open invoices whose due date is inside the range (what the customers should pay in those days)
//  - "already overdue": the part of that which is past its due date today (it should have come already)
//  - "before the range": unpaid money that was due before the first day (still to come, outside the range)
//  - "received": payments that really came into the ledger between the two dates
// Money on its way (a SWIFT copy) is already taken off by the account figures. Euro and dollar are shown on their own and
// added together only in euro, at the rate set in Performance settings.
import { db } from '../db/connection';
import type { Viewer } from './visibility';
import { allAccounts, openItemsOf, usdPerEur } from './perfAnalytics';
import { todayIstanbul } from './todos';

const DAY = 86_400_000;
const addDays = (iso: string, n: number) => new Date(Date.parse(`${iso}T12:00:00Z`) + n * DAY).toISOString().slice(0, 10);
const daysBetween = (a: string, b: string) => Math.round((Date.parse(b) - Date.parse(a)) / DAY);
const r0 = (n: number) => Math.round(n);

export interface CashCustomer { sap: string; name: string; cardId: number | null; country: string; cur: string; amount: number; eur: number; earliestDue: string; overdue: number }
export interface CashSource { sap: string | null; name: string; cardId: number | null; country: string; cur: string; amount: number; eur: number; payments: number; last: string; list: { date: string; amount: number }[] }
export interface CashBucket { label: string; start: string; end: string; EUR: number; USD: number; eur: number }
export interface CashFlow {
  from: string; to: string; asOf: string; rate: number;
  falling: { cur: string; amount: number; overdue: number; before: number }[];
  eur: { falling: number; overdue: number; before: number; received: number };
  received: { cur: string; amount: number; payments: number }[];
  receivedFrom: CashSource[]; // where the money came from, customer by customer
  receivedFromTotal: number;
  receivedByCountry: { country: string; eur: number; customers: number }[];
  buckets: CashBucket[];
  customers: CashCustomer[];
  invoices: number;
  customersTotal: number;
}

export function cashFlow(viewer: Viewer, from: string, to: string): CashFlow {
  const today = todayIstanbul();
  const rate = usdPerEur();
  const toEur = (v: number, cur: string) => (cur === 'USD' ? v / rate : v);
  const span = Math.max(1, daysBetween(from, to) + 1);
  const monthly = span > 120;
  // the buckets: weeks for a short range, calendar months for a long one
  const buckets: CashBucket[] = [];
  if (monthly) {
    let c = `${from.slice(0, 7)}-01`;
    while (c <= to && buckets.length < 36) {
      const d = new Date(`${c}T12:00:00Z`);
      d.setUTCMonth(d.getUTCMonth() + 1);
      const next = d.toISOString().slice(0, 10);
      buckets.push({ label: c.slice(0, 7), start: c < from ? from : c, end: addDays(next, -1) > to ? to : addDays(next, -1), EUR: 0, USD: 0, eur: 0 });
      c = next;
    }
  } else {
    for (let s = from; s <= to && buckets.length < 60; s = addDays(s, 7)) {
      const e = addDays(s, 6) > to ? to : addDays(s, 6);
      buckets.push({ label: s.slice(5), start: s, end: e, EUR: 0, USD: 0, eur: 0 });
    }
  }

  const tot = new Map<string, { amount: number; overdue: number; before: number }>();
  const customers: CashCustomer[] = [];
  let invoices = 0;
  for (const a of allAccounts(viewer.id)) {
    let amount = 0;
    let overdue = 0;
    let earliest = '';
    for (const it of openItemsOf(a.sap, viewer.id)) {
      if (it.amount <= 0.5) continue;
      const due = addDays(today, -it.daysOver);
      const t = tot.get(a.currency) ?? tot.set(a.currency, { amount: 0, overdue: 0, before: 0 }).get(a.currency)!;
      if (due < from) { t.before += it.amount; continue; }
      if (due > to) continue;
      invoices += 1;
      amount += it.amount;
      t.amount += it.amount;
      if (due < today) { overdue += it.amount; t.overdue += it.amount; }
      if (!earliest || due < earliest) earliest = due;
      const b = buckets.find((x) => due >= x.start && due <= x.end);
      if (b) { if (a.currency === 'USD') b.USD += it.amount; else b.EUR += it.amount; b.eur += toEur(it.amount, a.currency); }
    }
    if (amount > 0) customers.push({ sap: a.sap, name: a.name, cardId: a.cardId, country: a.country, cur: a.currency, amount: r0(amount), eur: r0(toEur(amount, a.currency)), earliestDue: earliest, overdue: r0(overdue) });
  }
  customers.sort((x, y) => y.eur - x.eur);

  // money that really came in: the credit lines of the ledger (adjustments and resets are not money)
  // ... and where it came from: every payment, by the customer whose ledger sheet it is on
  const lines = db
    .prepare("SELECT sheet_name AS sheet, tx_date AS date, credit AS amount, currency AS cur FROM ledger_transactions WHERE credit > 0 AND tx_date >= ? AND tx_date <= ? AND lower(COALESCE(description, '')) NOT LIKE '%s_f_rla%' ORDER BY tx_date DESC, id DESC")
    .all(from, to > today ? today : to) as { sheet: string; date: string; amount: number; cur: string }[];
  const owner = new Map<string, { sap: string; name: string; cardId: number | null; country: string }>();
  for (const a of allAccounts(viewer.id)) for (const s of a.sheets) owner.set(s, { sap: a.sap, name: a.name, cardId: a.cardId, country: a.country });
  const src = new Map<string, CashSource>();
  const recTot = new Map<string, { amount: number; n: number }>();
  for (const l of lines) {
    const o = owner.get(l.sheet);
    const key = `${o?.sap ?? `sheet:${l.sheet}`}|${l.cur}`;
    const s = src.get(key) ?? src.set(key, { sap: o?.sap ?? null, name: o?.name ?? l.sheet, cardId: o?.cardId ?? null, country: o?.country ?? '', cur: l.cur, amount: 0, eur: 0, payments: 0, last: l.date, list: [] }).get(key)!;
    s.amount += l.amount;
    s.eur += toEur(l.amount, l.cur);
    s.payments += 1;
    if (s.list.length < 12) s.list.push({ date: l.date, amount: r0(l.amount) });
    const t = recTot.get(l.cur) ?? recTot.set(l.cur, { amount: 0, n: 0 }).get(l.cur)!;
    t.amount += l.amount;
    t.n += 1;
  }
  const received = [...recTot].map(([cur, v]) => ({ cur, amount: r0(v.amount), payments: v.n }));
  const receivedFrom = [...src.values()].map((s) => ({ ...s, amount: r0(s.amount), eur: r0(s.eur) })).sort((a, b) => b.eur - a.eur);
  const byCountry = new Map<string, { country: string; eur: number; customers: number }>();
  for (const s of receivedFrom) {
    const k = s.country || '—';
    const c = byCountry.get(k) ?? byCountry.set(k, { country: k, eur: 0, customers: 0 }).get(k)!;
    c.eur += s.eur;
    c.customers += 1;
  }

  const falling = [...tot].map(([cur, v]) => ({ cur, amount: r0(v.amount), overdue: r0(v.overdue), before: r0(v.before) })).sort((a, b) => b.amount - a.amount);
  return {
    from, to, asOf: today, rate,
    falling,
    eur: {
      falling: r0(falling.reduce((a, x) => a + toEur(x.amount, x.cur), 0)),
      overdue: r0(falling.reduce((a, x) => a + toEur(x.overdue, x.cur), 0)),
      before: r0(falling.reduce((a, x) => a + toEur(x.before, x.cur), 0)),
      received: r0(received.reduce((a, x) => a + toEur(x.amount, x.cur), 0)),
    },
    received,
    receivedFrom: receivedFrom.slice(0, 150),
    receivedFromTotal: receivedFrom.length,
    receivedByCountry: [...byCountry.values()].sort((a, b) => b.eur - a.eur),
    buckets: buckets.map((b) => ({ ...b, EUR: r0(b.EUR), USD: r0(b.USD), eur: r0(b.eur) })),
    customers: customers.slice(0, 150),
    invoices,
    customersTotal: customers.length,
  };
}
