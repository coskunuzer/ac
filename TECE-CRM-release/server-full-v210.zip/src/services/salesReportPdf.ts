import PDFDocument from 'pdfkit';
import { drawLogo, registerDesignFonts } from './priceBook/designed';
import type { ReportRow, SalesReport } from './salesReport';

// The sales report as a PDF in the TECE design: a navy band with the white logo, Montserrat, square tables, red only for the title rule.
const NAVY = '#17243E';
const CHART1 = '#36589D';
const RED = '#8B1931';
const INK = '#17243E';
const STEEL = '#5E6676';
const MIST = '#F3F4F7';
const LINE = '#E3E6EC';
const W = 842;
const H = 595;
const M = 30;

type Lang = 'tr' | 'en';
const L: Record<Lang, Record<string, string>> = {
  en: { title: 'Sales report', month: 'Monthly', quarter: 'Quarterly', year: 'Yearly', team: 'Whole team', invoiced: 'Invoiced', vs: 'against the same months last year', customers: 'Customers invoiced', countries: 'Countries',
    byCountry: 'Sales by country', byRep: 'Sales by employee', did: 'What we did in each country', country: 'Country', employee: 'Employee', total: 'Total', share: 'Share', yoy: 'Last year', newC: 'New cust.', offers: 'Offers', samples: 'Samples',
    visits: 'Visits', calls: 'Calls', notes: 'Notes', emails: 'E-mails', waiting: 'Waiting', ready: 'Ready', prod: 'Production', overdue: 'Overdue', crm: 'From the CRM, for the year', amounts: 'Amounts in', page: 'Page', of: 'of', made: 'Prepared', none: 'No sales in this period.', open: 'Open orders and receivables' },
  tr: { title: 'Satış raporu', month: 'Aylık', quarter: 'Çeyreklik', year: 'Yıllık', team: 'Tüm ekip', invoiced: 'Faturalanan', vs: 'geçen yılın aynı aylarına göre', customers: 'Fatura kesilen müşteri', countries: 'Ülke',
    byCountry: 'Ülkelere göre satış', byRep: 'Çalışanlara göre satış', did: 'Her ülkede ne yaptık', country: 'Ülke', employee: 'Çalışan', total: 'Toplam', share: 'Pay', yoy: 'Geçen yıl', newC: 'Yeni müşt.', offers: 'Teklif', samples: 'Numune',
    visits: 'Ziyaret', calls: 'Arama', notes: 'Not', emails: 'E-posta', waiting: 'Bekleyen', ready: 'Sevke hazır', prod: 'Üretimde', overdue: 'Vadesi geçmiş', crm: 'CRM kayıtlarından, yıl boyunca', amounts: 'Tutarlar', page: 'Sayfa', of: '/', made: 'Hazırlanma', none: 'Bu dönemde satış yok.', open: 'Açık siparişler ve alacaklar' },
};
const MONTHS_TR = ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara'];

export async function renderSalesReportPdf(r: SalesReport, lang: Lang, whoFor: string): Promise<Buffer> {
  const t = L[lang];
  const num = (n: number) => Math.round(n).toLocaleString(lang === 'tr' ? 'de-DE' : 'en-US');
  const sym = r.currency === 'USD' ? '$' : '€';
  const pct = (n: number | null) => (n === null ? '—' : `${n >= 0 ? '+' : '−'}${Math.abs(n).toLocaleString(lang === 'tr' ? 'de-DE' : 'en-US', { maximumFractionDigits: 0 })} %`);
  const cols = r.period === 'month' && lang === 'tr' ? MONTHS_TR : r.columns;
  const doc = new PDFDocument({ size: [W, H], margin: 0, bufferPages: true, info: { Title: `${t.title} ${r.year}`, Author: 'TECE' } });
  registerDesignFonts(doc);
  const chunks: Buffer[] = [];
  doc.on('data', (c: Buffer) => chunks.push(c));
  const done = new Promise<Buffer>((res) => doc.on('end', () => res(Buffer.concat(chunks))));

  const band = () => {
    doc.rect(0, 0, W, 54).fill(NAVY);
    drawLogo(doc, 'TECE_SloganliLogo_Beyaz_RGB.svg', M, 14, 170);
    doc.fillColor('#FFFFFF').font('TD-600').fontSize(15).text(`${t.title} ${r.year}`, M, 12, { width: W - 2 * M, align: 'right' });
    doc.fillColor('#FFFFFF').font('TD-400').fontSize(8.5).text(`${t[r.period]} · ${whoFor} · ${t.amounts} ${sym}`, M, 33, { width: W - 2 * M, align: 'right' });
  };
  const heading = (text: string, y: number): number => {
    doc.fillColor(INK).font('TD-600').fontSize(12).text(text, M, y, { lineBreak: false });
    const w = doc.widthOfString(text);
    doc.rect(M, y + 17, w, 1.6).fill(RED);
    return y + 28;
  };

  // a table: header row, zebra, repeated header on a new page; the first column is the name
  type Cell = { t: string; bold?: boolean };
  const table = (y: number, head: string[], widths: number[], rows: Cell[][], first: string): number => {
    const RH = 17;
    const drawHead = (yy: number) => {
      let x = M;
      head.forEach((h, i) => { doc.fillColor(STEEL).font('TD-600').fontSize(7).text(h.toUpperCase(), x + 4, yy + 5.5, { width: widths[i] - 8, align: i === 0 ? 'left' : 'right', lineBreak: false }); x += widths[i]; });
      doc.moveTo(M, yy + RH).lineTo(M + widths.reduce((a, b) => a + b, 0), yy + RH).lineWidth(1).strokeColor(INK).stroke();
      return yy + RH;
    };
    let yy = drawHead(y);
    rows.forEach((row, ri) => {
      if (yy + RH > H - 34) { doc.addPage(); band(); yy = drawHead(70); }
      if (row[0]?.bold) doc.moveTo(M, yy).lineTo(M + widths.reduce((a, b) => a + b, 0), yy).lineWidth(1).strokeColor(INK).stroke();
      let x = M;
      row.forEach((c, i) => { doc.fillColor(INK).font(c.bold ? 'TD-700' : 'TD-400').fontSize(7.5).text(c.t, x + 4, yy + 5, { width: widths[i] - 8, align: i === 0 ? 'left' : 'right', lineBreak: false, ellipsis: true }); x += widths[i]; });
      doc.moveTo(M, yy + RH).lineTo(M + widths.reduce((a, b) => a + b, 0), yy + RH).lineWidth(0.4).strokeColor(LINE).stroke();
      yy += RH;
    });
    void first;
    return yy;
  };
  const salesRows = (rows: ReportRow[]): Cell[][] => {
    const out: Cell[][] = rows.map((x) => [{ t: x.name }, ...x.values.map((v) => ({ t: v ? num(v) : '–' })), { t: num(x.total), bold: true }, { t: `${x.share.toLocaleString(lang === 'tr' ? 'de-DE' : 'en-US', { maximumFractionDigits: 1 })} %` }, { t: pct(x.yoy) }]);
    out.push([{ t: t.total, bold: true }, ...r.team.values.map((v) => ({ t: v ? num(v) : '–', bold: true })), { t: num(r.team.total), bold: true }, { t: '100 %', bold: true }, { t: pct(r.team.yoy), bold: true }]);
    return out;
  };
  const salesWidths = (): number[] => {
    const nameW = 110; const tail = [58, 38, 54];
    const free = W - 2 * M - nameW - tail.reduce((a, b) => a + b, 0);
    const each = Math.floor(free / cols.length);
    return [nameW, ...cols.map(() => each), ...tail];
  };

  // ---- page 1 ----
  band();
  let y = 70;
  // the key figures
  const tiles: [string, string, string][] = [
    [t.invoiced, `${sym}${num(r.team.total)}`, r.team.yoy === null ? '' : `${pct(r.team.yoy)} ${t.vs}`],
    [t.customers, String(r.team.customers), `${r.team.accounts} ${lang === 'tr' ? 'müşteri içinden' : 'customers in all'}`],
    [t.countries, String(r.byCountry.filter((c) => c.total > 0).length), r.byCountry[0] ? `${lang === 'tr' ? 'en büyük' : 'largest'}: ${r.byCountry[0].name} (${r.byCountry[0].share.toLocaleString(lang === 'tr' ? 'de-DE' : 'en-US', { maximumFractionDigits: 0 })} %)` : ''],
    [t.open, `${sym}${num(r.team.waiting + r.team.ready + r.team.production)}`, `${t.overdue}: ${sym}${num(r.team.overdue)}`],
  ];
  const tw = (W - 2 * M - 3 * 12) / 4;
  tiles.forEach(([label, value, sub], i) => {
    const x = M + i * (tw + 12);
    doc.rect(x, y, tw, 58).lineWidth(0.8).strokeColor(LINE).stroke();
    doc.fillColor(STEEL).font('TD-600').fontSize(6.5).text(label.toUpperCase(), x + 8, y + 7, { width: tw - 16, lineBreak: false });
    doc.fillColor(INK).font('TD-700').fontSize(17).text(value, x + 8, y + 19, { width: tw - 16, lineBreak: false });
    doc.fillColor(STEEL).font('TD-400').fontSize(6.5).text(sub, x + 8, y + 43, { width: tw - 16, lineBreak: false, ellipsis: true });
  });
  y += 74;

  // a small bar chart of the countries (the top eight)
  const top = r.byCountry.filter((c) => c.total > 0).slice(0, 8);
  y = heading(t.byCountry, y);
  if (r.team.total <= 0) doc.fillColor(STEEL).font('TD-400').fontSize(9).text(t.none, M, y + 4);
  else {
    const max = Math.max(...top.map((c) => c.total), 1);
    const chartW = 300;
    top.forEach((c, i) => {
      const yy = y + i * 14;
      doc.fillColor(INK).font('TD-500').fontSize(7.5).text(c.name, M, yy + 2, { width: 96, lineBreak: false, ellipsis: true });
      doc.rect(M + 100, yy, Math.max(2, (c.total / max) * chartW), 9).fill(CHART1);
      doc.fillColor(STEEL).font('TD-500').fontSize(7).text(`${sym}${num(c.total)}`, M + 106 + Math.max(2, (c.total / max) * chartW), yy + 1.5, { lineBreak: false });
    });
    doc.moveTo(M + 100, y - 2).lineTo(M + 100, y + top.length * 14).lineWidth(2).strokeColor(INK).stroke();
    doc.fillColor(STEEL).font('TD-400').fontSize(7).text(lang === 'tr' ? `Kaynak: TECE satış verisi (SAP cari hesap), ${r.year}.` : `Source: TECE sales data (SAP ledger), ${r.year}.`, M, y + top.length * 14 + 4, { lineBreak: false });
    y += top.length * 14 + 24;
  }
  y = Math.max(y, 280);
  // the table by country continues on the first page when there is room
  if (y > H - 120) { doc.addPage(); band(); y = 70; }
  y = table(y, [t.country, ...cols, t.total, t.share, t.yoy], salesWidths(), salesRows(r.byCountry.filter((c) => c.total > 0)), 'country');

  // ---- by employee ----
  doc.addPage(); band();
  y = heading(t.byRep, 70);
  y = table(y, [t.employee, ...cols, t.total, t.share, t.yoy], salesWidths(), salesRows(r.byRep.filter((c) => c.total > 0)), 'rep');

  // ---- what was done in each country ----
  doc.addPage(); band();
  y = heading(`${t.did} (${r.year})`, 70);
  doc.fillColor(STEEL).font('TD-400').fontSize(7.5).text(t.crm, M, y - 6);
  const dw = [120, 52, 46, 52, 48, 46, 42, 50, 60, 56, 60, 60];
  const scale = (W - 2 * M) / dw.reduce((a, b) => a + b, 0);
  const widths = dw.map((x) => x * scale);
  const act = (x: ReportRow): Cell[] => [{ t: x.name }, { t: String(x.activity.newCustomers) }, { t: String(x.activity.offers) }, { t: String(x.activity.samples) }, { t: String(x.activity.visits) }, { t: String(x.activity.calls) }, { t: String(x.activity.notes) }, { t: String(x.activity.emails) }, { t: x.waiting ? num(x.waiting) : '–' }, { t: x.ready ? num(x.ready) : '–' }, { t: x.production ? num(x.production) : '–' }, { t: x.overdue ? num(x.overdue) : '–' }];
  const rows = r.byCountry.filter((x) => Object.values(x.activity).some((v) => v > 0) || x.waiting + x.ready + x.production + x.overdue > 0).sort((a, b) => (Object.values(b.activity).reduce((p, q) => p + q, 0) - Object.values(a.activity).reduce((p, q) => p + q, 0)) || b.total - a.total).map(act);
  const all: Cell[] = [{ t: t.total, bold: true }, ...[r.team.activity.newCustomers, r.team.activity.offers, r.team.activity.samples, r.team.activity.visits, r.team.activity.calls, r.team.activity.notes, r.team.activity.emails].map((v) => ({ t: String(v), bold: true })), { t: num(r.team.waiting), bold: true }, { t: num(r.team.ready), bold: true }, { t: num(r.team.production), bold: true }, { t: num(r.team.overdue), bold: true }];
  table(y + 4, [t.country, t.newC, t.offers, t.samples, t.visits, t.calls, t.notes, t.emails, t.waiting, t.ready, t.prod, t.overdue], widths, [...rows, all], 'did');

  // footer on every page
  const range = doc.bufferedPageRange();
  for (let i = 0; i < range.count; i += 1) {
    doc.switchToPage(i);
    doc.moveTo(M, H - 26).lineTo(W - M, H - 26).lineWidth(0.4).strokeColor(LINE).stroke();
    doc.fillColor(STEEL).font('TD-400').fontSize(7).text(`TECE · The Edgebanding Company · ${t.made} ${r.asOf.split('-').reverse().join('.')}`, M, H - 20, { lineBreak: false });
    doc.text(`${t.page} ${i + 1} ${t.of} ${range.count}`, W - M - 100, H - 20, { width: 100, align: 'right', lineBreak: false });
  }
  doc.end();
  return done;
}
