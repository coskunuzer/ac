import sharp from 'sharp';

// Photos are saved small so the server does not fill up: at most 1600 px on the long side, JPEG quality 75, turned upright (the phone's rotation flag is applied), no hidden
// location data. A phone photo of 4-6 MB becomes about 200-400 KB, still clear enough to see a damaged edge. Anything that is not a JPG or PNG is kept as it came,
// and so is an image that would not get smaller.
const MAX = 1600;

export async function shrinkUpload(file: { buffer: Buffer; mimetype: string }, ext: string): Promise<{ buffer: Buffer; ext: string }> {
  if (file.mimetype !== 'image/jpeg' && file.mimetype !== 'image/png') return { buffer: file.buffer, ext };
  try {
    const out = await sharp(file.buffer, { failOn: 'none' }).rotate().resize({ width: MAX, height: MAX, fit: 'inside', withoutEnlargement: true }).flatten({ background: '#ffffff' }).jpeg({ quality: 75, mozjpeg: true }).toBuffer();
    return out.length < file.buffer.length ? { buffer: out, ext: '.jpg' } : { buffer: file.buffer, ext };
  } catch {
    return { buffer: file.buffer, ext }; // not readable as an image: kept as it came
  }
}
