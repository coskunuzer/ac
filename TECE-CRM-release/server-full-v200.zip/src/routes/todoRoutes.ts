import { Router } from 'express';
import multer from 'multer';
import { readNotePhotos } from '../services/noteAssist';
import { parseNotes } from '../services/quickTodos';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { cardModel } from '../models/cardModel';
import { addBusinessDays, todayIstanbul, todoModel } from '../services/todos';
import { canSeeCard } from '../services/visibility';

const router = Router();
router.use(requireAuth);

const DAY = /^\d{4}-\d{2}-\d{2}$/;
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 8 * 1024 * 1024, files: 4 } });

// Simple notes (typed, or photos of handwriting) -> a proposed list, each line joined to the customer it names. Nothing is saved here.
router.post('/from-notes', upload.array('photos', 4), async (req: AuthedRequest, res) => {
  let text = typeof req.body?.text === 'string' ? req.body.text : '';
  const files = (req.files as Express.Multer.File[] | undefined) ?? [];
  if (files.length) {
    const read = await readNotePhotos(files.map((f) => ({ data: f.buffer, mime: f.mimetype || 'image/jpeg' })));
    if (!read) return res.status(502).json({ error: 'The photo could not be read. Type the notes instead.' });
    text = text + '\n' + read;
  }
  if (!text.trim()) return res.status(400).json({ error: 'Type your notes or add a photo.' });
  res.json({ text: text.trim(), items: await parseNotes(text, req.user!) });
});
// the confirmed list: every line a to-do (joined to its customer when it has one)
router.post('/bulk', (req: AuthedRequest, res) => {
  const items = (Array.isArray(req.body?.items) ? req.body.items : []).slice(0, 60) as { text?: unknown; cardId?: unknown; dueDate?: unknown }[];
  const out = [];
  for (const i of items) {
    const text = typeof i.text === 'string' ? i.text.trim() : '';
    if (!text) continue;
    const card = i.cardId ? cardModel.findById(parseInt(String(i.cardId), 10)) : undefined;
    if (card && !canSeeCard(req.user!, card)) continue;
    const due = typeof i.dueDate === 'string' && DAY.test(i.dueDate) ? i.dueDate : addBusinessDays(todayIstanbul(), 1);
    out.push(todoModel.add({ userId: req.user!.id, cardId: card?.id ?? null, text, dueDate: due }));
  }
  res.status(201).json({ added: out.length, todos: out });
});

// My to-dos (the open ones, and the ones done in the last week). ?from=&to= limits them to a period (the calendar).
router.get('/', (req: AuthedRequest, res) => {
  const from = typeof req.query.from === 'string' && DAY.test(req.query.from) ? req.query.from : undefined;
  const to = typeof req.query.to === 'string' && DAY.test(req.query.to) ? req.query.to : undefined;
  res.json(todoModel.forUser(req.user!.id, from, to));
});

router.post('/', (req: AuthedRequest, res) => {
  const b = (req.body ?? {}) as Record<string, unknown>;
  const text = typeof b.text === 'string' ? b.text.trim() : '';
  if (!text) return res.status(400).json({ error: 'Write what is to be done.' });
  const card = b.cardId ? cardModel.findById(parseInt(String(b.cardId), 10)) : undefined;
  if (b.cardId && (!card || !canSeeCard(req.user!, card))) return res.status(403).json({ error: 'You do not have access to that customer.' });
  const due = typeof b.dueDate === 'string' && DAY.test(b.dueDate) ? b.dueDate : addBusinessDays(todayIstanbul(), typeof b.inBusinessDays === 'number' ? b.inBusinessDays : 3);
  // never a second open to-do with the same customer and title
  const same = todoModel.findOpenDuplicate({ userId: req.user!.id, cardId: card?.id ?? null, text });
  if (same) return res.status(409).json({ error: 'This to-do is already on your list.', duplicate: true, todo: same });
  res.status(201).json(todoModel.add({ userId: req.user!.id, cardId: card?.id ?? null, text, dueDate: due }));
});

router.post('/:id/done', (req: AuthedRequest, res) => {
  const todo = todoModel.find(parseInt(String(req.params.id), 10));
  if (!todo || todo.userId !== req.user!.id) return res.status(404).json({ error: 'Not found' });
  todoModel.done(todo.id, req.body?.done !== false);
  res.json(todoModel.find(todo.id));
});

// move a to-do to another day (dragging it in the calendar) or change its text
router.patch('/:id', (req: AuthedRequest, res) => {
  const todo = todoModel.find(parseInt(String(req.params.id), 10));
  if (!todo || todo.userId !== req.user!.id) return res.status(404).json({ error: 'Not found' });
  const b = (req.body ?? {}) as Record<string, unknown>;
  const due = typeof b.dueDate === 'string' && DAY.test(b.dueDate) ? b.dueDate : null;
  const text = typeof b.text === 'string' && b.text.trim() ? b.text.trim().slice(0, 300) : null;
  if (!due && !text) return res.status(400).json({ error: 'Give the new day or the new text.' });
  todoModel.change(todo.id, { dueDate: due ?? undefined, text: text ?? undefined });
  res.json(todoModel.find(todo.id));
});

router.delete('/:id', (req: AuthedRequest, res) => {
  const todo = todoModel.find(parseInt(String(req.params.id), 10));
  if (!todo || todo.userId !== req.user!.id) return res.status(404).json({ error: 'Not found' });
  todoModel.delete(todo.id);
  res.json({ ok: true });
});

export default router;
