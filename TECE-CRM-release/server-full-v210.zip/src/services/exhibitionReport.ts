import fs from 'fs';
import path from 'path';
import PDFDocument from 'pdfkit';
import { paths } from '../config/env';
import { parseInsight } from './aiInsight';
import type { CardRow } from '../models/cardModel';
import type { Exhibition } from '../models/exhibitionModel';
import type { OfferEntry } from '../models/pricingModels';
import { HOT_RATE } from '../models/reportModel';
import { loadLetterhead } from './priceBook/sheetPrint';
import { followUpFor, groupByCard } from './followUp';
import { interestLabel, widthsLabel } from './interest';
import { buildPlan, type PlanItem, type PlanTask, type TaskKind } from './followUpPlan';

const FONT_DIR = path.resolve(__dirname, '../../assets/fonts');
const NAVY = '#17243E';
const MUTED = '#6B7280';
const LINE = '#D9DCE1';
const BAND = '#EEF0F4';
const RED = '#B4232A';

const PAGE = { w: 595.28, h: 841.89 };
const M = { left: 40, right: 40, top: 40, bottom: 62 };
const CONTENT_W = PAGE.w - M.left - M.right;

// Column layout of the visitor table (points, adds up to CONTENT_W).
const COLS = [
  { key: 'who', label: 'Company / contact', w: 138 },
  { key: 'reach', label: 'Email / phone', w: 124 },
  { key: 'interest', label: 'Interested in', w: 78 },
  { key: 'person', label: 'Met by', w: 52 },
  { key: 'rate', label: 'Rate', w: 26 },
  { key: 'offer', label: 'What we did', w: CONTENT_W - 138 - 124 - 78 - 52 - 26 },
] as const;

const pctText = (fraction: number | null) => {
  if (fraction === null) return 'documents';
  const n = Math.round(fraction * 1000) / 10;
  return n === 0 ? 'list price' : `${n > 0 ? '+' : ''}${n}%`;
};
const shortDate = (utc: string) => {
  const d = new Date(`${utc.replace(' ', 'T')}Z`);
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
};
const longDate = (s: string | null) =>
  s ? new Date(s.length <= 10 ? `${s}T00:00:00Z` : `${s.replace(' ', 'T')}Z`).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' }) : '';

interface Group {
  country: string;
  cards: CardRow[];
}

// Visitors grouped by country, countries A-Z (no country last), the most
// interesting visitors (highest rate) first within each country.
export function groupByCountry(cards: CardRow[]): Group[] {
  const map = new Map<string, CardRow[]>();
  for (const c of cards) {
    const key = c.country?.trim() || '';
    (map.get(key) ?? map.set(key, []).get(key)!).push(c);
  }
  return [...map.entries()]
    .sort(([a], [b]) => (a === '' ? 1 : b === '' ? -1 : a.localeCompare(b)))
    .map(([country, list]) => ({
      country: country || 'Country not recorded',
      cards: list.sort(
        (x, y) => (y.rate ?? -1) - (x.rate ?? -1) || (x.company ?? x.name ?? '').localeCompare(y.company ?? y.name ?? '')
      ),
    }));
}

// One A4 report for a fair: how many people came, and who they are, by country.
export function renderExhibitionReport(input: {
  exhibition: Exhibition;
  cards: CardRow[];
  offers: OfferEntry[]; // newest first
  generatedAt: Date;
  // a personal report: whose customers these are
  forPerson?: string | null;
}): Promise<Buffer> {
  const { exhibition, cards, offers } = input;
  const sentByCard = groupByCard(offers);
  const followUps = new Map(cards.map((c) => [c.id, followUpFor(c, sentByCard.get(c.id) ?? [])]));
  const planItems = buildPlan(cards, offers, new Date(), Infinity);
  const plan = new Map(planItems.map((p) => [p.id, p]));

  const doc = new PDFDocument({
    size: 'A4',
    autoFirstPage: false,
    margins: { top: M.top, bottom: 0, left: M.left, right: M.right },
    bufferPages: true,
    info: { Title: `${exhibition.name} - visitors`, Author: 'tece' },
  });
  doc.registerFont('r', path.join(FONT_DIR, 'Carlito-Regular.ttf'));
  doc.registerFont('b', path.join(FONT_DIR, 'Carlito-Bold.ttf'));
  doc.registerFont('i', path.join(FONT_DIR, 'Carlito-Italic.ttf'));

  const chunks: Buffer[] = [];
  doc.on('data', (c: Buffer) => chunks.push(c));
  const done = new Promise<Buffer>((resolve, reject) => {
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);
  });

  const { header, footer } = loadLetterhead();
  let y = M.top;
  const limit = PAGE.h - M.bottom;

  const drawFooter = () => {
    if (footer) doc.image(footer, M.left, PAGE.h - 44, { width: CONTENT_W });
  };
  const newPage = () => {
    doc.addPage();
    y = M.top;
    if (header) {
      doc.image(header, M.left, y, { width: CONTENT_W });
      y += (CONTENT_W * 151) / 1796 + 14;
    }
  };

  // ---- cover block ----------------------------------------------------
  newPage();
  const sum = (f: (c: CardRow) => boolean) => cards.filter(f).length;
  const countries = new Set(cards.map((c) => c.country?.trim()).filter(Boolean));
  const byStatus = (s: string) => cards.filter((c) => followUps.get(c.id)?.status === s).length;

  doc.font('b').fontSize(22).fillColor(NAVY).text(exhibition.name, M.left, y, { width: CONTENT_W });
  y = doc.y + 2;
  const meta = [
    exhibition.location,
    exhibition.start_date ? (exhibition.end_date && exhibition.end_date !== exhibition.start_date ? `${longDate(exhibition.start_date)} - ${longDate(exhibition.end_date)}` : longDate(exhibition.start_date)) : '',
  ].filter(Boolean).join('  ·  ');
  if (meta) {
    doc.font('r').fontSize(11).fillColor(MUTED).text(meta, M.left, y, { width: CONTENT_W });
    y = doc.y;
  }
  doc.font('r').fontSize(9).fillColor(MUTED).text(`${input.forPerson ? `Visitor report for ${input.forPerson}` : 'Visitor report'}, prepared ${longDate(input.generatedAt.toISOString().slice(0, 10))}`, M.left, y + 2, { width: CONTENT_W });
  y = doc.y + 14;

  // feedback about the fair, with a photo of it (written under Fairs by an admin)
  const photoFile = exhibition.photo_path ? path.join(paths.uploadsDir, exhibition.photo_path) : null;
  if (photoFile && fs.existsSync(photoFile)) {
    try {
      const img = (doc as unknown as { openImage(file: string): { width: number; height: number } }).openImage(photoFile);
      const scale = Math.min(CONTENT_W / img.width, 200 / img.height);
      const w = img.width * scale;
      const h = img.height * scale;
      doc.image(photoFile, M.left, y, { width: w, height: h });
      y += h + 10;
    } catch {
      /* an unreadable photo is left out */
    }
  }
  if (exhibition.feedback) {
    const text = exhibition.feedback;
    doc.font('b').fontSize(11).fillColor(NAVY).text('Feedback from the fair', M.left, y);
    y = doc.y + 3;
    doc.font('r').fontSize(9.5).fillColor('#222');
    const need = doc.heightOfString(text, { width: CONTENT_W });
    if (y + need > limit - 80) {
      newPage();
      doc.font('r').fontSize(9.5).fillColor('#222');
    }
    doc.text(text, M.left, y, { width: CONTENT_W, lineGap: 1.5 });
    y = doc.y + 14;
  }

  // headline figures
  const stats: [string, string][] = [
    [String(cards.length), 'visitors'],
    [String(countries.size), 'countries'],
    [String(sum((c) => (c.rate ?? 0) >= HOT_RATE)), `hot leads (rated ${HOT_RATE}+)`],
    [String(byStatus('offer')), 'got an offer'],
    [String(byStatus('documents')), 'documents only'],
    [String(byStatus('thank_you')), 'thank-you only'],
    [String(byStatus('nothing')), 'nothing yet'],
  ];
  const cellW = CONTENT_W / stats.length;
  doc.rect(M.left, y, CONTENT_W, 54).fill(BAND);
  stats.forEach(([value, label], i) => {
    const x = M.left + i * cellW;
    doc.font('b').fontSize(20).fillColor(NAVY).text(value, x + 8, y + 7, { width: cellW - 12 });
    doc.font('r').fontSize(8.5).fillColor(MUTED).text(label, x + 8, y + 33, { width: cellW - 12 });
  });
  y += 54 + 18;

  // ---- countries at a glance -------------------------------------------
  const groups = groupByCountry(cards);
  doc.font('b').fontSize(12).fillColor(NAVY).text('Visitors by country', M.left, y);
  y = doc.y + 6;
  const perCol = Math.ceil(groups.length / 3) || 1;
  const colW = CONTENT_W / 3;
  const glanceTop = y;
  let glanceBottom = y;
  groups.forEach((g, i) => {
    const col = Math.floor(i / perCol);
    const row = i % perCol;
    const gx = M.left + col * colW;
    const gy = glanceTop + row * 13;
    doc.font('r').fontSize(9).fillColor('#222').text(g.country, gx, gy, { width: colW - 36, lineBreak: false, ellipsis: true });
    doc.font('b').fontSize(9).fillColor(NAVY).text(String(g.cards.length), gx + colW - 34, gy, { width: 28, align: 'right', lineBreak: false });
    glanceBottom = Math.max(glanceBottom, gy + 13);
  });
  y = glanceBottom + 10;

  // ---- actions to take ------------------------------------------------
  const GROUPS: { kind: TaskKind; title: string }[] = [
    { kind: 'thank_you', title: 'Thank-yous to send' },
    { kind: 'offer', title: 'Offers to send' },
    { kind: 'chase', title: 'Offers to chase' },
    { kind: 'reminder', title: 'Reminders from the notes' },
    { kind: 'check', title: 'To check first' },
  ];
  const tasksOfKind = (kind: TaskKind): { item: PlanItem; task: PlanTask }[] =>
    planItems.flatMap((item) => item.tasks.filter((t) => t.kind === kind).map((task) => ({ item, task })));
  if (planItems.length > 0) {
    newPage();
    doc.font('b').fontSize(16).fillColor(NAVY).text('Actions to take', M.left, y);
    y = doc.y + 2;
    doc
      .font('r')
      .fontSize(9)
      .fillColor(MUTED)
      .text(
        `${planItems.length} of ${cards.length} visitors are waiting for something. Most urgent first - the notes on the forms were read for this.`,
        M.left,
        y,
        { width: CONTENT_W }
      );
    y = doc.y + 12;
    for (const group of GROUPS) {
      const rows = tasksOfKind(group.kind);
      if (!rows.length) continue;
      if (y + 40 > limit) newPage();
      doc.font('b').fontSize(11).fillColor(NAVY).text(`${group.title} (${rows.length})`, M.left, y);
      y = doc.y + 4;
      doc.moveTo(M.left, y).lineTo(M.left + CONTENT_W, y).strokeColor(LINE).lineWidth(0.6).stroke();
      y += 5;
      for (const { item, task } of rows) {
        const who = [item.company || item.name || 'Unnamed', item.company && item.name ? item.name : null, item.country].filter(Boolean).join(' · ');
        const what = task.label + (task.detail && group.kind !== 'thank_you' ? ` - ${task.detail}` : '');
        const metaText = item.person ? `${item.person}` : '';
        const h = Math.max(
          (doc.font('b').fontSize(8.5), doc.heightOfString(who, { width: 190 })),
          (doc.font('r').fontSize(8.5), doc.heightOfString(what, { width: CONTENT_W - 206 - 80 }))
        ) + 5;
        if (y + h > limit) newPage();
        doc.rect(M.left + 2, y + 2, 7, 7).strokeColor('#8A93A3').lineWidth(0.7).stroke(); // a box to tick
        doc.font('b').fontSize(8.5).fillColor('#111').text(who, M.left + 16, y + 1, { width: 190 });
        doc.font('r').fontSize(8.5).fillColor('#222').text(what, M.left + 206, y + 1, { width: CONTENT_W - 206 - 80 });
        doc.font('r').fontSize(8).fillColor(MUTED).text(metaText, M.left + CONTENT_W - 78, y + 1, { width: 78, align: 'right' });
        y += h;
      }
      y += 10;
    }
  }

  // ---- who they are, country by country -------------------------------
  const rowHeight = (cells: Record<string, string>) =>
    Math.max(
      ...COLS.map((c) => {
        doc.font('r').fontSize(8.5);
        return doc.heightOfString(cells[c.key] || ' ', { width: c.w - 8 });
      })
    ) + 8;

  const drawColumnHeads = () => {
    doc.font('b').fontSize(7.5).fillColor(MUTED);
    let x = M.left;
    for (const c of COLS) {
      doc.text(c.label.toUpperCase(), x + 4, y, { width: c.w - 8, lineBreak: false });
      x += c.w;
    }
    y += 12;
    doc.moveTo(M.left, y - 2).lineTo(M.left + CONTENT_W, y - 2).strokeColor(LINE).lineWidth(0.6).stroke();
  };

  const drawCountryBand = (g: Group, cont: boolean) => {
    doc.rect(M.left, y, CONTENT_W, 20).fill(NAVY);
    doc.font('b').fontSize(11).fillColor('#FFFFFF').text(`${g.country}${cont ? ' (continued)' : ''}`, M.left + 8, y + 5, { width: CONTENT_W - 90, lineBreak: false });
    doc.font('r').fontSize(9).fillColor('#FFFFFF').text(`${g.cards.length} ${g.cards.length === 1 ? 'visitor' : 'visitors'}`, M.left + CONTENT_W - 82, y + 6, { width: 74, align: 'right', lineBreak: false });
    y += 26;
  };

  const needNewSection = () => {
    // start the country list on its own page when the cover is already half full
    if (y > PAGE.h * 0.6) newPage();
    else y += 6;
  };
  needNewSection();
  doc.font('b').fontSize(12).fillColor(NAVY).text('Who came', M.left, y);
  y = doc.y + 8;

  for (const g of groups) {
    const firstRow = g.cards[0];
    const firstH = firstRow ? 60 : 0;
    if (y + 26 + 14 + firstH > limit) newPage();
    drawCountryBand(g, false);
    drawColumnHeads();

    for (const c of g.cards) {
      const follow = followUps.get(c.id)!;
      const cells: Record<string, string> = {
        who: [c.company, c.name, c.position].filter(Boolean).join('\n') || 'Unnamed',
        reach: [c.email, c.tel].filter(Boolean).join('\n'),
        interest: [interestLabel(c), widthsLabel(c)].filter(Boolean).join('\n'),
        person: c.person ?? '',
        rate: c.rate === null || c.rate === undefined ? '' : String(c.rate),
        offer:
          follow.status === 'offer'
            ? `Offer ${pctText(follow.percent)}\n${shortDate(follow.at!)}`
            : follow.status === 'documents'
              ? `Documents\n${shortDate(follow.at!)}`
              : follow.status === 'thank_you'
                ? `Thank-you only\n${shortDate(follow.at!)}`
                : 'Nothing yet',
      };
      // and what is still to do for this customer
      const next = plan.get(c.id)?.tasks[0];
      if (next) cells.offer += `\n> ${next.label}`;
      const base = rowHeight(cells);
      // what the AI found out about the company, in a line of its own under the customer
      const ins = parseInsight(c.ai_insight);
      const aboutRaw = ins ? [ins.companyType, ins.companyProfile || ins.websiteSummary].filter(Boolean).join(' - ') : '';
      const about = aboutRaw.length > 260 ? `${aboutRaw.slice(0, 260).replace(/\s+\S*$/, '')}...` : aboutRaw;
      const aboutH = about ? (doc.font('i').fontSize(7.5), doc.heightOfString(about, { width: CONTENT_W - 8 }) + 4) : 0;
      const h = base;
      if (y + h + aboutH > limit) {
        newPage();
        drawCountryBand(g, true);
        drawColumnHeads();
      }
      let x = M.left;
      const hot = (c.rate ?? 0) >= HOT_RATE;
      for (const col of COLS) {
        const text = cells[col.key];
        if (col.key === 'who') {
          const [first, ...rest] = text.split('\n');
          doc.font('b').fontSize(8.5).fillColor('#111').text(first, x + 4, y + 3, { width: col.w - 8, height: h - 4 });
          if (rest.length) doc.font('r').fontSize(8.5).fillColor(MUTED).text(rest.join('\n'), x + 4, doc.y, { width: col.w - 8 });
        } else {
          doc
            .font(col.key === 'rate' && hot ? 'b' : 'r')
            .fontSize(8.5)
            .fillColor(col.key === 'rate' && hot ? RED : '#222')
            .text(text, x + 4, y + 3, { width: col.w - 8, height: h - 4, align: col.key === 'rate' ? 'center' : 'left' });
        }
        x += col.w;
      }
      if (about) doc.font('i').fontSize(7.5).fillColor(MUTED).text(about, M.left + 4, y + h - 3, { width: CONTENT_W - 8 });
      y += h + aboutH;
      doc.moveTo(M.left, y).lineTo(M.left + CONTENT_W, y).strokeColor(LINE).lineWidth(0.4).stroke();
    }
    y += 12;
  }

  if (cards.length === 0) {
    doc.font('i').fontSize(11).fillColor(MUTED).text('No visitors have been recorded for this exhibition yet.', M.left, y);
  }

  // footers and page numbers, once all pages exist
  const range = doc.bufferedPageRange();
  for (let i = 0; i < range.count; i++) {
    doc.switchToPage(range.start + i);
    drawFooter();
    doc.font('r').fontSize(8).fillColor(MUTED).text(`${exhibition.name}  ·  page ${i + 1} of ${range.count}`, M.left, PAGE.h - 56, { width: CONTENT_W, align: 'right', lineBreak: false });
  }
  doc.end();
  return done;
}
