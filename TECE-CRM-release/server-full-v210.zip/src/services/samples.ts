import type { CardRow } from '../models/cardModel';
import type { Lang } from './translate';

// The e-mail to the customer once the samples have left: what we sent (the description written with the request) and the tracking number.
// Written in the customer's language; the salesperson reads it and may change it before it goes.

export const TRACKING_URL: Record<string, (n: string) => string> = {
  DHL: (n) => `https://www.dhl.com/global-en/home/tracking.html?tracking-id=${encodeURIComponent(n)}`,
  FedEx: (n) => `https://www.fedex.com/fedextrack/?trknbr=${encodeURIComponent(n)}`,
  UPS: (n) => `https://www.ups.com/track?tracknum=${encodeURIComponent(n)}`,
  TNT: (n) => `https://www.tnt.com/express/en_gc/site/shipping-tools/tracking.html?searchType=con&cons=${encodeURIComponent(n)}`,
  'Aras Kargo': (n) => `https://www.araskargo.com.tr/tr/cargo_tracking_detail.aspx?query=${encodeURIComponent(n)}`,
  'MNG Kargo': (n) => `https://www.mngkargo.com.tr/gonderi-takip/?q=${encodeURIComponent(n)}`,
  'Yurtiçi Kargo': (n) => `https://www.yurticikargo.com/tr/online-servisler/gonderi-sorgula?code=${encodeURIComponent(n)}`,
  PTT: () => 'https://gonderitakip.ptt.gov.tr/',
};

const T: Record<Lang, { subject: string; hello: (n: string) => string; intro: string; list: string; carrier: string; tracking: string; follow: string; ask: string; bye: (s: string) => string }> = {
  en: { subject: 'Your TECE samples are on the way', hello: (n) => `Dear ${n},`, intro: 'We are pleased to let you know that your samples have been shipped.', list: 'What we sent:', carrier: 'Courier', tracking: 'Tracking number', follow: 'You can follow the shipment here:', ask: 'Please tell us when they arrive and what you think - we are glad to help with the next step.', bye: (s) => `Best regards,\n${s}` },
  tr: { subject: 'TECE numuneleriniz yola çıktı', hello: (n) => `Sayın ${n},`, intro: 'Numunelerinizin gönderildiğini bildirmekten memnuniyet duyarız.', list: 'Gönderdiklerimiz:', carrier: 'Kurye', tracking: 'Takip numarası', follow: 'Gönderiyi buradan takip edebilirsiniz:', ask: 'Ulaştığında ve görüşlerinizi bizimle paylaşmanızı rica ederiz; bir sonraki adımda yardımcı olmaktan memnuniyet duyarız.', bye: (s) => `Saygılarımla,\n${s}` },
  ru: { subject: 'Ваши образцы TECE отправлены', hello: (n) => `Уважаемый(ая) ${n},`, intro: 'Рады сообщить, что ваши образцы отправлены.', list: 'Что мы отправили:', carrier: 'Курьер', tracking: 'Номер отслеживания', follow: 'Отследить отправление можно здесь:', ask: 'Пожалуйста, сообщите нам, когда образцы придут, и что вы о них думаете.', bye: (s) => `С уважением,\n${s}` },
  es: { subject: 'Sus muestras de TECE están en camino', hello: (n) => `Estimado/a ${n}:`, intro: 'Nos complace informarle de que sus muestras han sido enviadas.', list: 'Lo que hemos enviado:', carrier: 'Mensajería', tracking: 'Número de seguimiento', follow: 'Puede seguir el envío aquí:', ask: 'Por favor, díganos cuándo lleguen y qué opina; estaremos encantados de ayudarle con el siguiente paso.', bye: (s) => `Saludos cordiales,\n${s}` },
  fr: { subject: 'Vos échantillons TECE sont en route', hello: (n) => `Cher/Chère ${n},`, intro: 'Nous avons le plaisir de vous informer que vos échantillons ont été expédiés.', list: 'Ce que nous avons envoyé :', carrier: 'Transporteur', tracking: 'Numéro de suivi', follow: "Vous pouvez suivre l'envoi ici :", ask: 'Dites-nous quand ils arrivent et ce que vous en pensez ; nous serons ravis de vous aider pour la suite.', bye: (s) => `Cordialement,\n${s}` },
};

export function trackingMail(card: Pick<CardRow, 'company' | 'name'>, lang: Lang, items: string, carrier: string, trackingNo: string, sender: string): { subject: string; body: string } {
  const t = T[lang] ?? T.en;
  const first = card.name?.split(/\s+/)[0] || card.company || '';
  const url = TRACKING_URL[carrier]?.(trackingNo);
  const lines = items.split('\n').map((l) => l.trim()).filter(Boolean).map((l) => `- ${l.replace(/^[-•*]\s*/, '')}`);
  return {
    subject: t.subject,
    body: [t.hello(first), '', t.intro, '', t.list, ...lines, '', carrier ? `${t.carrier}: ${carrier}` : '', `${t.tracking}: ${trackingNo}`, url ? `${t.follow} ${url}` : '', '', t.ask, '', t.bye(sender)].filter((l, i, a) => !(l === '' && a[i - 1] === '')).join('\n'),
  };
}
