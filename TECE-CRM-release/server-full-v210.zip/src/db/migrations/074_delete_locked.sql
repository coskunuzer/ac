-- An admin can mark an uploaded list "only an admin may delete these": sales staff then cannot delete (or junk) them.
ALTER TABLE cards ADD COLUMN delete_locked INTEGER NOT NULL DEFAULT 0;
