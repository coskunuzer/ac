import { db } from '../db/connection';
import { canonicalCountry, countryKey } from '../models/countryModel';
import { allAccountSets, setsFor, type Account } from './perfAnalytics';
import { toEur } from './perfIngest';
import { matchPlace } from './shipPlaces';
import { askJson } from './perfActions';
import { visibilitySql, canSeeCard, accessOf, type Viewer } from './visibility';
import { viewMode } from './viewMode';
import { userModel } from '../models/userModel';
import type { CardRow } from '../models/cardModel';

// Country explorer: one country at a time - what is known about it (World Bank figures, an AI estimate of its furniture market), what we sold there for the
// last ten years (from the ledgers), how our customers there grade, and the brainstorm of the sales people.
// Sales people see the TOTAL turnover of a country; the customers' names and figures are only those they may see.

const r0 = (n: number) => Math.round(n);

export interface CountryRow { country: string; iso: string | null; customers: number; withSap: number; lastYear: number; ytd: number }

const nameOf = (a: string | null | undefined): string => String(canonicalCountry(a ?? '') || '').trim();
export const isoOf = (country: string): string | null => { const p = matchPlace(country); return p && p.type === 'country' ? p.iso : null; };

function accountsOf(country: string): Account[] {
  const sets = allAccountSets(0);
  const k = countryKey(country);
  return [...sets.live, ...sets.dead].filter((a) => countryKey(nameOf(a.country)) === k);
}

// Which countries this person may open: an admin sees all of them. Everybody else sees their own countries - and, only while the
// Manager switch is on, the countries of the people who report to them. null = all.
export function countryScope(viewer: Viewer): Set<string> | null {
  if (viewer.role === 'admin') return null;
  const me = userModel.findPublicById(viewer.id);
  if (!me) return new Set();
  const team = viewMode.team(me.id).ids;
  const keys = new Set<string>();
  const people = [me, ...team.map((id) => userModel.findPublicById(id)).filter((u): u is NonNullable<typeof u> => !!u)];
  for (const u of people) for (const k of accessOf({ id: u.id, role: u.role, display_name: u.display_name, market: u.market }).countries) keys.add(k);
  return keys;
}

// every country that has customers or sales, with the figures of the whole company (the totals are for everybody)
export function listCountries(): CountryRow[] {
  const year = new Date().getFullYear();
  const rows = new Map<string, CountryRow>();
  const get = (c: string): CountryRow => { const k = countryKey(c); let r = rows.get(k); if (!r) { r = { country: c, iso: isoOf(c), customers: 0, withSap: 0, lastYear: 0, ytd: 0 }; rows.set(k, r); } return r; };
  for (const c of db.prepare("SELECT country, COUNT(*) AS n, SUM(CASE WHEN TRIM(COALESCE(sap, '')) != '' THEN 1 ELSE 0 END) AS s FROM cards WHERE COALESCE(market, 'export') != 'domestic' AND TRIM(COALESCE(country, '')) != '' GROUP BY country").all() as { country: string; n: number; s: number }[]) {
    const r = get(nameOf(c.country)); r.customers += c.n; r.withSap += c.s;
  }
  const sets = allAccountSets(0);
  for (const a of [...sets.live, ...sets.dead]) {
    const c = nameOf(a.country); if (!c) continue;
    const r = get(c);
    r.lastYear += toEur(a.years[year - 1] ?? 0, a.currency); r.ytd += toEur(a.ytd, a.currency);
  }
  return [...rows.values()].map((r) => ({ ...r, lastYear: r0(r.lastYear), ytd: r0(r.ytd) })).sort((a, b) => (b.lastYear + b.ytd) - (a.lastYear + a.ytd) || b.customers - a.customers);
}

// ---- public figures (World Bank) --------------------------------------------------------------------------------------------------------------
export interface Facts { iso: string; name: string; region: string | null; incomeLevel: string | null; capital: string | null; population: number | null; populationYear: string | null; gniPerCapita: number | null; gniYear: string | null; gdp: number | null; gdpYear: string | null; fetchedAt: string | null; market: unknown; marketAt: string | null; analysis: unknown; analysisAt: string | null }
interface FactRow { iso: string; name: string; region: string | null; income_level: string | null; capital: string | null; population: number | null; population_year: string | null; gni_per_capita: number | null; gni_year: string | null; gdp: number | null; gdp_year: string | null; wb_at: string | null; market_json: string | null; market_at: string | null; analysis_json: string | null; analysis_at: string | null }
const parse = (s: string | null): unknown => { if (!s) return null; try { return JSON.parse(s); } catch { return null; } };
const toFacts = (r: FactRow): Facts => ({ iso: r.iso, name: r.name, region: r.region, incomeLevel: r.income_level, capital: r.capital, population: r.population, populationYear: r.population_year, gniPerCapita: r.gni_per_capita, gniYear: r.gni_year, gdp: r.gdp, gdpYear: r.gdp_year, fetchedAt: r.wb_at, market: parse(r.market_json), marketAt: r.market_at, analysis: parse(r.analysis_json), analysisAt: r.analysis_at });
export const factsOf = (iso: string): Facts | null => { const r = db.prepare('SELECT * FROM country_facts WHERE iso = ?').get(iso) as FactRow | undefined; return r ? toFacts(r) : null; };

async function wb<T>(path: string): Promise<T | null> {
  try {
    const res = await fetch(`https://api.worldbank.org/v2/${path}${path.includes('?') ? '&' : '?'}format=json`, { signal: AbortSignal.timeout(6000) });
    if (!res.ok) return null;
    return (await res.json()) as T;
  } catch { return null; }
}
// the newest year that has a value: the last years are asked for and the first one with a number is taken (the newest year is often still empty)
const latest = async (iso: string, indicator: string): Promise<{ value: number; year: string } | null> => {
  for (const q of ['mrv=8', 'date=2012:2026&per_page=30', 'mrnev=1']) {
    const j = await wb<[unknown, { value: number | null; date: string }[] | null]>(`country/${iso}/indicator/${indicator}?${q}`);
    const rows = (j?.[1] ?? []).filter((r) => typeof r.value === 'number' && r.value > 0).sort((a, b) => b.date.localeCompare(a.date));
    if (rows[0]) return { value: rows[0].value as number, year: rows[0].date };
  }
  return null;
};
// a second source for the population, when the World Bank does not give it
async function restPopulation(iso: string): Promise<number | null> {
  for (const url of [`https://restcountries.com/v3.1/alpha/${iso}?fields=population`, `https://restcountries.com/v3.1/alpha?codes=${iso}&fields=population`]) {
    try {
      const res = await fetch(url, { signal: AbortSignal.timeout(8000), redirect: 'follow' });
      if (!res.ok) continue;
      const j = (await res.json()) as { population?: number } | { population?: number }[];
      const p = Array.isArray(j) ? j[0]?.population : j.population;
      if (typeof p === 'number' && p > 0) return p;
    } catch { /* the next one */ }
  }
  return null;
}

// asks the World Bank (free, public) and keeps the answer for 30 days; a country the World Bank does not know keeps what is there
export async function refreshFacts(iso: string, name: string, force = false): Promise<Facts> {
  const have = factsOf(iso);
  // complete figures are kept for 30 days; incomplete ones (the World Bank was down) are asked again after a day
  const ttl = have && have.gniPerCapita !== null && have.population !== null ? 30 * 86_400_000 : 3_600_000;
  if (have && have.fetchedAt && !force && Date.now() - Date.parse(have.fetchedAt.replace(' ', 'T') + 'Z') < ttl) return have;
  const meta = await wb<[unknown, { name: string; region?: { value: string }; incomeLevel?: { value: string }; capitalCity?: string }[] | null]>(`country/${iso}`);
  const m = meta?.[1]?.[0];
  let [pop, gni, gdp] = await Promise.all([latest(iso, 'SP.POP.TOTL'), latest(iso, 'NY.GNP.PCAP.CD'), latest(iso, 'NY.GDP.MKTP.CD')]);
  // the World Bank's indicator service is sometimes down: the population then comes from REST Countries
  if (!pop) { const p = await restPopulation(iso); if (p) pop = { value: p, year: 'est.' }; }
  // what an earlier answer had is not thrown away when this one is incomplete
  if (!pop && have?.population) pop = { value: have.population, year: have.populationYear ?? '' };
  if (!gni && have?.gniPerCapita) gni = { value: have.gniPerCapita, year: have.gniYear ?? '' };
  if (!gdp && have?.gdp) gdp = { value: have.gdp, year: have.gdpYear ?? '' };
  if (!m && !pop && !gni && !gdp) return have ?? { iso, name, region: null, incomeLevel: null, capital: null, population: null, populationYear: null, gniPerCapita: null, gniYear: null, gdp: null, gdpYear: null, fetchedAt: null, market: null, marketAt: null, analysis: null, analysisAt: null };
  db.prepare(`INSERT INTO country_facts (iso, name, region, income_level, capital, population, population_year, gni_per_capita, gni_year, gdp, gdp_year, wb_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
    ON CONFLICT(iso) DO UPDATE SET name = excluded.name, region = excluded.region, income_level = excluded.income_level, capital = excluded.capital, population = excluded.population, population_year = excluded.population_year,
      gni_per_capita = excluded.gni_per_capita, gni_year = excluded.gni_year, gdp = excluded.gdp, gdp_year = excluded.gdp_year, wb_at = excluded.wb_at`)
    .run(iso, name, m?.region?.value ?? null, m?.incomeLevel?.value ?? null, m?.capitalCity ?? null, pop?.value ?? null, pop?.year ?? null, gni?.value ?? null, gni?.year ?? null, gdp?.value ?? null, gdp?.year ?? null);
  return factsOf(iso)!;
}

// ---- our own turnover, ten years ---------------------------------------------------------------------------------------------------------------
export interface Insight { tone: 'good' | 'warn' | 'bad' | 'info'; text: string }
export interface Turnover {
  years: { year: number; eur: number; customers: number; partial: boolean }[];
  ytd: number; prevYtd: number; throughLabel: string;
  top: { name: string; cardId: number | null; value: number; visible: boolean }[];
  lost: { name: string; cardId: number | null; prevYear: number; lastInvoice: string | null; visible: boolean }[];
  insights: Insight[];
  accounts: number;
  oldestYear: number | null;
}
export function turnoverOf(viewer: Viewer, country: string): Turnover {
  const accounts = accountsOf(country);
  const now = new Date();
  const year = now.getFullYear();
  const from = year - 9;
  const mine = new Set<string>();
  // the accounts this person may see: the strict rule of setsFor()
  const seen = setsFor(viewer, null);
  for (const a of [...seen.live, ...seen.dead]) mine.add(a.sap);
  const years = [] as Turnover['years'];
  let oldest: number | null = null;
  for (let y = from; y <= year; y++) {
    let eur = 0, n = 0;
    for (const a of accounts) { const v = a.years[y] ?? 0; if (v > 0) { eur += toEur(v, a.currency); n++; if (oldest === null || y < oldest) oldest = y; } }
    years.push({ year: y, eur: r0(eur), customers: n, partial: y === year });
  }
  const ytd = r0(accounts.reduce((s, a) => s + toEur(a.ytd, a.currency), 0));
  const prevYtd = r0(accounts.reduce((s, a) => s + toEur(a.prevYtd, a.currency), 0));
  const label = (n: string, a: Account) => (mine.has(a.sap) ? n : 'Another customer');
  const top = accounts.map((a) => ({ a, v: toEur((a.years[year - 1] ?? 0) + a.ytd, a.currency) })).filter((x) => x.v > 0).sort((x, y) => y.v - x.v).slice(0, 8)
    .map(({ a, v }) => ({ name: label(a.name, a), cardId: mine.has(a.sap) ? a.cardId : null, value: r0(v), visible: mine.has(a.sap) }));
  const lost = accounts.filter((a) => (a.years[year - 1] ?? 0) > 0 && a.ytd <= 0 && (a.lastInvoice ?? '') < new Date(Date.now() - 180 * 86_400_000).toISOString().slice(0, 10))
    .sort((x, y) => toEur(y.years[year - 1] ?? 0, y.currency) - toEur(x.years[year - 1] ?? 0, x.currency)).slice(0, 6)
    .map((a) => ({ name: label(a.name, a), cardId: mine.has(a.sap) ? a.cardId : null, prevYear: r0(toEur(a.years[year - 1] ?? 0, a.currency)), lastInvoice: a.lastInvoice, visible: mine.has(a.sap) }));

  // the plain rules first: what the figures say, before any AI is asked
  const insights: Insight[] = [];
  const full = years.filter((y) => !y.partial);
  const pct = (a: number, b: number) => (b > 0 ? Math.round(((a - b) / b) * 100) : null);
  if (oldest === null) insights.push({ tone: 'info', text: 'No sales are booked in this country in the last ten years.' });
  else {
    const last3 = full.slice(-3).reduce((s, y) => s + y.eur, 0), prev3 = full.slice(-6, -3).reduce((s, y) => s + y.eur, 0);
    const trend = pct(last3, prev3);
    if (trend !== null) insights.push({ tone: trend >= 10 ? 'good' : trend <= -10 ? 'bad' : 'info', text: `The last 3 full years brought ${trend >= 0 ? '+' : ''}${trend}% against the 3 years before.` });
    const cur = pct(ytd, prevYtd);
    if (cur !== null) insights.push({ tone: cur >= 0 ? 'good' : cur <= -15 ? 'bad' : 'warn', text: `This year so far is ${cur >= 0 ? '+' : ''}${cur}% against the same days of last year.` });
    const peak = full.reduce((m, y) => (y.eur > m.eur ? y : m), full[0]);
    const lastFull = full[full.length - 1];
    if (peak && lastFull && peak.year !== lastFull.year && peak.eur > 0) { const gap = pct(lastFull.eur, peak.eur); if (gap !== null && gap <= -30) insights.push({ tone: 'warn', text: `The best year was ${peak.year}; last year is ${Math.abs(gap)}% below it.` }); }
    const base = lastFull?.eur ?? 0;
    if (base > 0) {
      const best = accounts.map((x) => toEur(x.years[year - 1] ?? 0, x.currency)).sort((p, q) => q - p)[0] ?? 0;
      const share = Math.round((best / base) * 100);
      if (share >= 50) insights.push({ tone: 'warn', text: `One customer is ${share}% of last year's sales here: the country depends on it.` });
    }
    const act = years.map((y) => y.customers);
    if (act.length >= 4 && act[act.length - 2] < act[act.length - 5]) insights.push({ tone: 'warn', text: `Fewer customers buy than ${4} years ago (${act[act.length - 2]} against ${act[act.length - 5]}).` });
    if (lost.length) insights.push({ tone: 'bad', text: `${lost.length} customer${lost.length === 1 ? '' : 's'} that bought last year have not bought this year.` });
  }
  return { years, ytd, prevYtd, throughLabel: now.toISOString().slice(0, 10), top, lost, insights, accounts: accounts.length, oldestYear: oldest };
}

// ---- our customers in the country, graded ------------------------------------------------------------------------------------------------------
export interface Graded { id: number; company: string; person: string | null; position: string | null; city: string | null; tel: string | null; mobile: string | null; email: string | null; stage: string | null; grade: 'A' | 'B' | 'C' | 'New'; why: string; sap: string | null; turnover: number | null; lastContact: string | null; next: string; owner: string | null; website: string | null; address: string | null; country: string | null; lat: number | null; lon: number | null; geoSource: string | null }
const gradeOf = (c: CardRow & { company_score?: string | null }, turnover: number | null): { grade: Graded['grade']; why: string } => {
  let tier: string | null = null; let fit: string | null = null;
  try { const s = c.company_score ? (JSON.parse(c.company_score) as { purchase?: { tier?: string; score?: number }; fit?: { priority?: string } }) : null; tier = s?.purchase?.tier ?? null; fit = s?.fit?.priority ?? null; } catch { /* no score */ }
  const mine = typeof c.rate === 'number' ? c.rate : null, ai = typeof c.ai_rate === 'number' ? c.ai_rate : null;
  const v = mine ?? ai;
  if (turnover !== null && turnover > 50_000) return { grade: 'A', why: 'Big customer' };
  if (tier === 'A' || (v !== null && v >= 8) || fit === 'A') return { grade: 'A', why: tier === 'A' ? 'Tier A by the company score' : v !== null && v >= 8 ? `${mine !== null ? 'Your' : 'AI'} rating ${v}/10` : 'Best fit' };
  if (tier === 'B' || (v !== null && v >= 5) || (turnover !== null && turnover > 5_000)) return { grade: 'B', why: tier === 'B' ? 'Tier B by the company score' : v !== null ? `${mine !== null ? 'Your' : 'AI'} rating ${v}/10` : 'Buys from us' };
  if (v !== null || tier) return { grade: 'C', why: v !== null ? `${mine !== null ? 'Your' : 'AI'} rating ${v}/10` : `Tier ${tier}` };
  return { grade: 'New', why: 'Not rated yet' };
};
export function customersOf(viewer: Viewer, country: string): Graded[] {
  const k = countryKey(country);
  const variants = (db.prepare("SELECT DISTINCT country FROM cards WHERE COALESCE(market, 'export') != 'domestic' AND TRIM(COALESCE(country, '')) != ''").all() as { country: string }[]).map((x) => x.country).filter((c) => countryKey(nameOf(c)) === k);
  if (!variants.length) return [];
  const params: Record<string, string | number> = {};
  const vis = visibilitySql(viewer, params);
  variants.forEach((v, i) => { params[`c${i}`] = v; });
  const rows = db.prepare(`SELECT *, (SELECT MAX(created_at) FROM activities a WHERE a.card_id = cards.id AND a.type IN ('note', 'call', 'visit', 'meeting', 'sample', 'offer', 'thank_you', 'documents', 'email')) AS last_contact FROM cards WHERE country IN (${variants.map((_, i) => `@c${i}`).join(',')})${vis ? ` AND ${vis}` : ''} ORDER BY id DESC LIMIT 700`).all(params) as unknown as (CardRow & { last_contact: string | null; company_score: string | null })[];
  const accBySap = new Map(accountsOf(country).map((a) => [a.sap, a]));
  const year = new Date().getFullYear();
  const out = rows.map((c) => {
    const acc = c.sap ? accBySap.get(c.sap.trim()) : undefined;
    const turnover = acc ? r0(toEur((acc.years[year - 1] ?? 0) + acc.ytd, acc.currency)) : null;
    const g = gradeOf(c, turnover);
    const days = c.last_contact ? Math.floor((Date.now() - Date.parse(c.last_contact.replace(' ', 'T') + 'Z')) / 86_400_000) : null;
    const next = (g.grade === 'A' || g.grade === 'B') && (days === null || days > 90) ? (days === null ? 'Make the first contact' : 'Call: nobody was in touch for 90 days')
      : c.stage === 'interested' || c.stage === 'quoted' ? 'Follow up the offer' : g.grade === 'New' ? 'Rate it' : days !== null && days > 180 ? 'Reactivate' : '';
    return { id: c.id, company: c.company || c.name || `#${c.id}`, person: c.name && c.company ? c.name : null, position: c.position ?? null, city: c.city ?? null, tel: c.tel ?? null, mobile: (c as unknown as { mobile?: string | null }).mobile ?? null, email: c.email ?? null, stage: c.stage ?? null, grade: g.grade, why: g.why, sap: c.sap ?? null, turnover, lastContact: c.last_contact, next, owner: c.person ?? null, website: (c as unknown as { website?: string | null }).website ?? null, address: (c as unknown as { address?: string | null }).address ?? null, country: c.country ?? null, lat: (c as unknown as { lat?: number | null }).lat ?? null, lon: (c as unknown as { lon?: number | null }).lon ?? null, geoSource: (c as unknown as { geo_source?: string | null }).geo_source ?? null } as Graded;
  });
  const order: Record<string, number> = { A: 0, B: 1, C: 2, New: 3 };
  return out.sort((a, b) => order[a.grade] - order[b.grade] || (b.turnover ?? 0) - (a.turnover ?? 0));
}

// ---- the AI parts (asked on request, saved, marked as estimates) -------------------------------------------------------------------------------
const MARKET_SCHEMA = { type: 'OBJECT', properties: { furnitureMarket: { type: 'STRING' }, furnitureTrend: { type: 'STRING' }, edgebandingDemand: { type: 'STRING' }, buyers: { type: 'ARRAY', items: { type: 'STRING' } }, competitors: { type: 'ARRAY', items: { type: 'STRING' } }, importNotes: { type: 'STRING' }, opportunities: { type: 'ARRAY', items: { type: 'STRING' } }, risks: { type: 'ARRAY', items: { type: 'STRING' } } }, required: ['furnitureMarket', 'edgebandingDemand', 'opportunities'] };
export async function marketAi(viewer: Viewer, f: Facts, lang: string): Promise<{ ok: boolean; error?: string }> {
  const j = await askJson(`You advise TECE, a Turkish maker of edgebanding (PVC, ABS, melamine and veneer edge tapes for furniture). Give a short, honest overview of the furniture industry of ${f.name} for a sales team that wants to sell edgebanding there. Known facts: population ${f.population ?? 'unknown'}, income level ${f.incomeLevel ?? 'unknown'}, GNI per capita ${f.gniPerCapita ?? 'unknown'} USD. Where you are not sure, say it is an estimate; never invent exact numbers or company names you are not sure of. Write in ${lang === 'tr' ? 'Turkish' : 'English'}. Fields: furnitureMarket = size and character of the furniture industry; furnitureTrend = where it is going; edgebandingDemand = what edge tape buyers there want (materials, colours, price level); buyers = the kinds of buyers (kitchen makers, panel producers, distributors ...); competitors = the usual suppliers or origins competing; importNotes = how imports work (duties, local production), only if you know; opportunities = 3 to 5 concrete ideas; risks = 2 to 4.`, MARKET_SCHEMA);
  if (!j) return { ok: false, error: 'The AI could not be reached or the AI budget is used up.' };
  db.prepare('INSERT OR IGNORE INTO country_facts (iso, name) VALUES (?, ?)').run(f.iso, f.name);
  db.prepare("UPDATE country_facts SET market_json = ?, market_at = datetime('now'), market_by = ? WHERE iso = ?").run(JSON.stringify(j), viewer.id, f.iso);
  return { ok: true };
}
const ANALYSIS_SCHEMA = { type: 'OBJECT', properties: { verdict: { type: 'STRING' }, headline: { type: 'STRING' }, working: { type: 'ARRAY', items: { type: 'STRING' } }, notWorking: { type: 'ARRAY', items: { type: 'STRING' } }, actions: { type: 'ARRAY', items: { type: 'STRING' } } }, required: ['verdict', 'headline', 'actions'] };
export async function analysisAi(viewer: Viewer, f: Facts, t: Turnover, custs: Graded[], lang: string): Promise<{ ok: boolean; error?: string }> {
  const gradeCount = { A: 0, B: 0, C: 0, New: 0 } as Record<string, number>; for (const c of custs) gradeCount[c.grade]++;
  const data = { country: f.name, facts: { population: f.population, income: f.incomeLevel, gniPerCapita: f.gniPerCapita }, ourTurnoverEurByYear: t.years.map((y) => `${y.year}${y.partial ? '(so far)' : ''}: ${y.eur} EUR, ${y.customers} buying customers`), thisYearSoFar: t.ytd, sameDaysLastYear: t.prevYtd, rulesSay: t.insights.map((i) => i.text), lostCustomers: t.lost.length, customersByGrade: gradeCount, marketEstimate: f.market ?? null };
  const j = await askJson(`You review how TECE (Turkish edgebanding maker) is doing in one country, for the sales team. Use ONLY this data, do not invent numbers: ${JSON.stringify(data)}. verdict = one of "right" (we are doing well), "mixed" or "wrong" (we are doing badly) - judge against the country's size and income, not only against our own past. headline = one clear sentence. working = what goes right; notWorking = what goes wrong; actions = 3 to 5 concrete next steps for the sales person. Write in ${lang === 'tr' ? 'Turkish' : 'English'}.`, ANALYSIS_SCHEMA);
  if (!j) return { ok: false, error: 'The AI could not be reached or the AI budget is used up.' };
  db.prepare('INSERT OR IGNORE INTO country_facts (iso, name) VALUES (?, ?)').run(f.iso, f.name);
  db.prepare("UPDATE country_facts SET analysis_json = ?, analysis_at = datetime('now'), analysis_by = ? WHERE iso = ?").run(JSON.stringify(j), viewer.id, f.iso);
  return { ok: true };
}

// ---- notes (only added) ------------------------------------------------------------------------------------------------------------------------
export interface Note { id: number; kind: string; text: string; user: string | null; at: string }
export const notesOf = (iso: string): Note[] => (db.prepare('SELECT id, kind, text, user_name, created_at FROM country_notes WHERE iso = ? ORDER BY id DESC LIMIT 200').all(iso) as { id: number; kind: string; text: string; user_name: string | null; created_at: string }[]).map((n) => ({ id: n.id, kind: n.kind, text: n.text, user: n.user_name, at: n.created_at }));
export function addNote(iso: string, country: string, viewer: Viewer, kind: string, text: string): void {
  const k = ['note', 'idea', 'risk', 'plan'].includes(kind) ? kind : 'note';
  db.prepare('INSERT INTO country_notes (iso, country, user_id, user_name, kind, text) VALUES (?, ?, ?, ?, ?, ?)').run(iso, country, viewer.id, viewer.display_name, k, text.slice(0, 2000));
}
export { canSeeCard };
