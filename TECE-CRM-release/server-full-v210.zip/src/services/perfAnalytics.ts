import { createHash } from 'node:crypto';
import { memoByData, memoTables } from '../db/dataVersion';
import { niceName } from './niceName';
import { db } from '../db/connection';
import { settingsModel } from '../models/settingsModel';
import { countryModel, canonicalCountry } from '../models/countryModel';
import type { Viewer } from './visibility';
import { viewMode } from './viewMode';
import { userModel } from '../models/userModel';
import { DEFAULT_RISK, riskProfile, type PaidInvoice, type RiskInput, type RiskLevel, type RiskProfile, type RiskSettings } from './paymentRisk';

// Everything the Performance page shows, worked out from the tables the SAP files fill (see perfIngest.ts).
// Money stays in the currency of the customer's ledger tab (euro accounts in euro, dollar accounts in dollars): nothing is converted.
// "Çıkış" in the ledger is an invoice; a payment that is a little short of its invoice is a bank charge that is ours (see simulate()).

export const HOLD_LIMIT = 10_000; // no invoice for 12 months and a debt of this size or more: on hold
export const SMALL_BALANCE = 1_500; // below this a silent big customer is a question for the AI
export const BIG_YEAR = 30_000; // a year of this size makes a customer "big"
export const DEAD_BALANCE = 10_000; // under this and no movement for 24 months: not a customer any more, dropped from everything
const DAY = 86_400_000;

const intSetting = (key: string, def: number, min: number, max: number) => {
  const n = parseFloat(settingsModel.get(key) ?? '');
  return Number.isFinite(n) && n >= min && n <= max ? n : def;
};
export const termsDays = (): number => intSetting('perf_terms_days', 30, 0, 365);
export const usdPerEur = (): number => intSetting('perf_usd_per_eur', 1.1, 0.5, 2);

// the payment time of each customer (days from the invoice): what an admin set, else the general one
function termsMaps(): { bySap: Map<string, number>; bySheet: Map<string, number>; sig: string } {
  const L = linkMap();
  const bySap = new Map((db.prepare('SELECT sap_no, days FROM perf_terms').all() as { sap_no: string; days: number }[]).map((r) => [r.sap_no, r.days]));
  const bySheet = new Map<string, number>();
  for (const a of db.prepare('SELECT sheet_name, sap_no FROM customer_aliases WHERE sap_no IS NOT NULL').all() as { sheet_name: string; sap_no: string }[]) {
    const d = bySap.get(L.get(a.sap_no) ?? a.sap_no) ?? bySap.get(a.sap_no);
    if (d !== undefined) bySheet.set(a.sheet_name, d);
  }
  return { bySap, bySheet, sig: [...bySap].map(([k, v]) => k + ':' + v).join(',') + '|' + [...L].join(',') };
}
export const riskSettings = (): RiskSettings => ({ graceDays: intSetting('risk_grace_days', DEFAULT_RISK.graceDays, 0, 60), blackDays: intSetting('risk_black_days', DEFAULT_RISK.blackDays, 30, 365), blackAmount: intSetting('risk_black_amount', DEFAULT_RISK.blackAmount, 0, 10_000_000) });
// what the scoring looked at, per customer (for the detail window); filled by allAccountSets
export const riskInputs = new Map<string, RiskInput>();
export const bankTolerancePct = (): number => intSetting('perf_bank_tol_pct', 1, 0, 20);
export const bankYearPct = (): number => intSetting('perf_bank_year_pct', 1, 0, 5); // a balance up to this % of a year's invoicing is bank fees

const iso = (d: Date) => d.toISOString().slice(0, 10);
const todayIso = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });
const daysBetween = (from: string, to: string) => Math.round((Date.parse(to) - Date.parse(from)) / DAY);
const monthsAgo = (n: number, from: string) => {
  const d = new Date(`${from}T00:00:00Z`);
  d.setUTCMonth(d.getUTCMonth() - n);
  return iso(d);
};
const round = (n: number) => Math.round(n * 100) / 100;
const fold = (s: string) => s.replace(/İ/g, 'i').normalize('NFD').replace(/\p{Diacritic}/gu, '').replace(/ı/g, 'i').toLowerCase();

// "çıkış TEZ2020000000082", "556741 nolu fatura" are invoices; "SIFIRLAMA" (reset), "KDV", "geri ödeme" are adjustments
export const isInvoiceText = (d: string | null): boolean => {
  const f = fold(d ?? '');
  return /^\s*cik/.test(f) || (/fatura|cikis/.test(f) && !/hata|iade|sifirla/.test(f));
};
const isReset = (d: string | null) => /sifirla/.test(fold(d ?? ''));

// ---- the ledger, sheet by sheet --------------------------------------------------------------------------------------------------
import { applySwift, waitingBySap, type SwiftRow } from './perfSwift';
import { NOT_SILENCED } from './shipDispatch';

// the open invoices of every account as the ledger shows them (before the money on its way is taken off): for the SWIFT window
const OPEN_BY_SAP = new Map<string, OpenItem[]>();
export function openItemsOf(sap: string, viewerId: number): OpenItem[] {
  allAccountSets(viewerId);
  return OPEN_BY_SAP.get(sap) ?? [];
}

export interface OpenItem { date: string; description: string; amount: number; daysOver: number; carried?: boolean }
interface SheetMetrics {
  sheet: string;
  currency: string;
  balance: number; // what the ledger itself shows on its last line
  owed: number; // what is really owed: the ledger's balance without the bank charges that are ours
  cuts: number; // payments a little short of their invoice (bank charges): ours, not asked from the customer
  lastInvoice: string | null;
  lastPayment: string | null;
  lastMove: string | null;
  byYear: Record<number, number>; // invoiced
  monthly: Record<number, number[]>;
  ytd: number;
  prevYtd: number;
  sameDays: Record<number, number>; // invoiced from 1 January to today's day, for this year and the four before
  open: OpenItem[];
  settled: PaidInvoice[]; // invoices that are paid, with the day the last money came in (how the customer pays)
  terms: number;
}

let cache: { key: string; sheets: Map<string, SheetMetrics> } | null = null;

type Line = { tx_date: string; description: string | null; debit: number | null; credit: number | null };

// Payments are applied to the oldest invoice first, and money paid in advance waits for the next invoice. When an invoice is paid down to a
// small rest (a few percent: the bank took its charge from the transfer) the rest is a cut that is ours, and the invoice is closed.
function simulate(lines: Line[], tolPct: number): { open: { date: string; description: string; rem: number; amount: number }[]; cuts: number; settled: PaidInvoice[] } {
  const queue: { date: string; description: string; amount: number; rem: number; paid: boolean }[] = [];
  const settled: PaidInvoice[] = [];
  let pool = 0;
  let cuts = 0;
  let today = '';
  const settle = () => {
    for (let i = queue.length - 1; i >= 0; i -= 1) if (queue[i].rem <= 0.005) { settled.unshift({ date: queue[i].date, amount: queue[i].amount, paidOn: today }); queue.splice(i, 1); }
  };
  for (const l of lines) {
    today = l.tx_date;
    const d = l.debit ?? 0;
    const c = l.credit ?? 0;
    if (d > 0 && isInvoiceText(l.description)) {
      const t = Math.min(pool, d);
      pool -= t;
      queue.push({ date: l.tx_date, description: l.description ?? '', amount: d, rem: d - t, paid: t > 0 });
    }
    if (c > 0) {
      if (isReset(l.description)) { queue.length = 0; pool = 0; continue; }
      let left = c;
      for (const inv of queue) {
        if (left <= 0) break;
        const t = Math.min(left, inv.rem);
        // one payment that is just a little short of its invoice: the bank took its charge, and that is ours
        const single = !inv.paid && t >= inv.amount * (1 - tolPct / 100);
        inv.rem -= t;
        left -= t;
        if (t > 0) inv.paid = true;
        if (single && inv.rem > 0.005 && inv.rem <= (inv.amount * tolPct) / 100) { cuts += inv.rem; inv.rem = 0; }
      }
      pool += left;
    }
    settle();
  }
  return { open: queue.map((q) => ({ date: q.date, description: q.description, rem: q.rem, amount: q.amount })), cuts, settled: settled.sort((a, b) => a.date.localeCompare(b.date)) };
}

// "has the ledger changed?" was a count of every ledger line, asked for each account sum; the answer is kept until the ledger is written to
const ledgerMark = memoTables(['ledger_transactions'], () => db.prepare('SELECT COUNT(*) AS n, COALESCE(MAX(id), 0) AS m FROM ledger_transactions').get() as { n: number; m: number });
const summaryMark = memoTables(['customer_financial_summary'], () => db.prepare("SELECT COUNT(*) AS n, COALESCE(MAX(updated_at), '') AS u FROM customer_financial_summary").get() as { n: number; u: string });

function sheetMetrics(): Map<string, SheetMetrics> {
  const today = todayIso();
  const v = ledgerMark();
  const s = summaryMark();
  const tm = termsMaps();
  const key = `${today}|${v.n}|${v.m}|${s.n}|${s.u}|${termsDays()}|${bankTolerancePct()}|${bankYearPct()}|${tm.sig}`;
  if (cache?.key === key) return cache.sheets;

  const year = Number(today.slice(0, 4));
  const cutPrev = `${year - 1}${today.slice(4)}`;
  const tol = bankTolerancePct();
  const yearFeePct = bankYearPct();
  const out = new Map<string, SheetMetrics>();
  const summary = db.prepare('SELECT sheet_name, currency, balance, last_invoice_date, last_payment_date, last_transaction_date FROM customer_financial_summary').all() as { sheet_name: string; currency: string; balance: number; last_invoice_date: string | null; last_payment_date: string | null; last_transaction_date: string | null }[];
  const rows = db.prepare('SELECT sheet_name, tx_date, description, debit, credit FROM ledger_transactions ORDER BY sheet_name, tx_date, seq, id').all() as (Line & { sheet_name: string })[];
  const grouped = new Map<string, Line[]>();
  for (const r of rows) {
    const g = grouped.get(r.sheet_name);
    if (g) g.push(r); else grouped.set(r.sheet_name, [r]);
  }
  for (const sm of summary) {
    const terms = tm.bySheet.get(sm.sheet_name) ?? termsDays();
    const list = grouped.get(sm.sheet_name) ?? [];
    const m: SheetMetrics = { sheet: sm.sheet_name, currency: sm.currency, balance: sm.balance, owed: sm.balance, cuts: 0, lastInvoice: null, lastPayment: sm.last_payment_date, lastMove: sm.last_transaction_date, byYear: {}, monthly: {}, ytd: 0, prevYtd: 0, sameDays: {}, open: [], settled: [], terms };
    for (const r of list) {
      const d = r.debit ?? 0;
      if (d <= 0 || !isInvoiceText(r.description)) continue;
      const y = Number(r.tx_date.slice(0, 4));
      m.byYear[y] = (m.byYear[y] ?? 0) + d;
      (m.monthly[y] ??= Array(12).fill(0))[Number(r.tx_date.slice(5, 7)) - 1] += d;
      if (y >= year - 4 && y <= year && r.tx_date.slice(5) <= today.slice(5)) m.sameDays[y] = (m.sameDays[y] ?? 0) + d;
      if (y === year && r.tx_date <= today) m.ytd += d;
      if (y === year - 1 && r.tx_date <= cutPrev) m.prevYtd += d;
      if (!m.lastInvoice || r.tx_date > m.lastInvoice) m.lastInvoice = r.tx_date;
    }
    const sim = simulate(list, tol);
    m.settled = sim.settled;
    // the ledger's own balance is what is owed; only bank charges are taken out, and never more than a small part of the year's sales
    const annual = Math.max(m.byYear[year - 1] ?? 0, m.byYear[year] ?? 0);
    const feeCap = (annual * yearFeePct) / 100;
    m.cuts = round(Math.min(sim.cuts, feeCap));
    m.owed = round(sm.balance <= 0 ? sm.balance : Math.max(0, sm.balance - m.cuts));
    // a balance that is only a few bank charges of the year's sales is nothing: 500 on 100,000 a year is bank fees
    if (m.owed > 0.005 && m.owed <= feeCap) { m.cuts = round(m.cuts + m.owed); m.owed = 0; }
    // what they owe: the newest invoices in full, and what is left of the balance as the first line ("balance brought forward")
    let left = Math.max(m.owed, 0);
    let i = sim.open.length - 1;
    const full: OpenItem[] = [];
    for (; i >= 0 && left >= sim.open[i].amount - 0.005; i -= 1) {
      left -= sim.open[i].amount;
      full.unshift({ date: sim.open[i].date, description: sim.open[i].description, amount: round(sim.open[i].amount), daysOver: daysBetween(sim.open[i].date, today) - terms });
    }
    if (left > 0.5) {
      const d = i >= 0 ? sim.open[i].date : (full[0]?.date ?? today);
      m.open.push({ date: d, description: '', amount: round(left), daysOver: daysBetween(d, today) - terms, carried: true });
    }
    m.open.push(...full);
    out.set(sm.sheet_name, m);
  }
  cache = { key, sheets: out };
  return out;
}

// what waits in production, by kind of product: PVC, ABS and PP in kilos; melamine and veneer in square metres; the rest in kilos (or its own unit)
export const MIX_ORDER = ['PVC', 'ABS', 'PP', 'Melamine', 'Veneer', 'Other'];
function productMix(r: { product_group: string; pending_m2: number | null; pending_kg: number | null; pending_qty: number | null; unit: string | null; width: number | null }): MixLine {
  const g = (r.product_group ?? '').toLowerCase();
  const m2 = r.pending_m2 && r.pending_m2 > 0 ? r.pending_m2 : r.unit === 'M' && r.width ? ((r.pending_qty ?? 0) * r.width) / 1000 : 0; // veneer comes in metres: metres x width
  if (/pvc/.test(g)) return { k: 'PVC', unit: 'kg', amount: r.pending_kg ?? 0 };
  if (/\babs/.test(g)) return { k: 'ABS', unit: 'kg', amount: r.pending_kg ?? 0 };
  if (/^pp\b|\bpp$/.test(g)) return { k: 'PP', unit: 'kg', amount: r.pending_kg ?? 0 };
  if (/melamin/.test(g)) return { k: 'Melamine', unit: 'm²', amount: m2 };
  if (/ahşap|ahsap|kaplama|veneer/.test(g)) return { k: 'Veneer', unit: 'm²', amount: m2 };
  return r.pending_kg && r.pending_kg > 0 ? { k: 'Other', unit: 'kg', amount: r.pending_kg } : { k: 'Other', unit: r.unit || 'pcs', amount: r.pending_qty ?? 0 };
}

// ---- accounts (one per SAP customer) ---------------------------------------------------------------------------------------------
export interface Aging { current: number; d30: number; d60: number; over60: number; total: number }
export interface Account {
  sap: string;
  name: string;
  country: string;
  rep: string;
  cardId: number | null;
  status: string; // SAP: active | passive | dormant
  hasLedger: boolean;
  sheets: string[];
  currency: string;
  balance: number; // what is owed (in the currency of the account)
  bankCuts: number; // bank charges that are ours, left out of the balance
  lastInvoice: string | null;
  lastPayment: string | null;
  ytd: number;
  prevYtd: number;
  prevYear: number;
  prevRest: number;
  bestYear: number;
  years: Record<number, number>;
  monthly: Record<number, number[]>; // invoiced each month (the sales report)
  target: number | null; // what an admin typed, or else the automatic one
  targetAuto: boolean;
  suggestedTarget: number;
  pace: number | null;
  yoy: number | null;
  health: 'ahead' | 'on_track' | 'behind' | 'no_target';
  inactive: boolean; // no invoice for 12 months
  rule: 'none' | 'hide' | 'hold' | 'diagnostic';
  hold: boolean;
  overridden: boolean;
  hidden: boolean;
  aging: Aging;
  overdue: number;
  swift: { amount: number; count: number; date: string; days: number; stale: boolean } | null; // money on its way (a SWIFT copy), already taken off the overdue amount
  oldestOver: number; // days of the oldest unpaid invoice past its due date
  urgency: number;
  backlogM2: number;
  backlogValue: number;
  blockers: number;
  readyToShip: number;
  diagnostic: string | null;
  hasSuggestion: boolean;
  terms: number; // payment time in days
  waitingValue: number; // orders waiting for the confirmation or the advance
  readyValue: number; // ready to dispatch
  readyKg: number;
  risk: RiskProfile; // how the customer pays
  black: boolean; // the black account: pays so late that a new order or a dispatch needs care
}

const emptyAging = (): Aging => ({ current: 0, d30: 0, d60: 0, over60: 0, total: 0 });
function addAging(a: Aging, item: { amount: number; daysOver: number }): void {
  const v = item.amount;
  if (item.daysOver <= 0) a.current += v;
  else if (item.daysOver <= 30) a.d30 += v;
  else if (item.daysOver <= 60) a.d60 += v;
  else a.over60 += v;
  a.total += v;
}
const roundAging = (a: Aging): Aging => ({ current: round(a.current), d30: round(a.d30), d60: round(a.d60), over60: round(a.over60), total: round(a.total) });

const foldName = (s: string) => fold(s).replace(/[^a-z0-9 ]+/g, ' ').trim().replace(/\s+/g, ' ');

// SAP writes "ABDULLAH COŞKUNUZER", the CRM "Abdullah Coskunuzer", a colleague may be only "Insaf": all become the name of the user
export function canonicalReps(): (name: string) => string {
  const users = userModel.listAll().filter((u) => !u.is_assistant && !u.assists_id && u.is_active).map((u) => u.display_name || u.username);
  const full = new Map(users.map((n) => [foldName(n), n]));
  const first = new Map<string, string[]>();
  for (const n of users) { const t = foldName(n).split(' ')[0]; (first.get(t) ?? first.set(t, []).get(t)!).push(n); }
  return (name) => {
    const k = foldName(name);
    if (!k) return '';
    const exact = full.get(k);
    if (exact) return exact;
    const hit = first.get(k.split(' ')[0]);
    return hit?.length === 1 ? hit[0] : name;
  };
}

// who looks after a customer: what an admin set > the person on the CRM card > the person of the country > the sales person of the shipment
export function repOf(country: string, cardPerson: string | null, dispatchRep: string | null): string {
  if (cardPerson) return cardPerson;
  const c = country ? countryModel.findByCountry(country)?.responsible : null;
  if (c) return c;
  return dispatchRep || '';
}

// a customer that counts as another one (sales of "TECE DEKOR Ltd" are sales of Canplast): child -> final parent
export function linkMap(): Map<string, string> {
  const raw = new Map((db.prepare('SELECT sap_no, parent_sap FROM perf_links').all() as { sap_no: string; parent_sap: string }[]).map((r) => [r.sap_no, r.parent_sap]));
  const out = new Map<string, string>();
  for (const child of raw.keys()) {
    let p = raw.get(child)!;
    for (let i = 0; i < 6 && raw.has(p) && p !== child; i += 1) p = raw.get(p)!;
    if (p !== child) out.set(child, p);
  }
  return out;
}
export const familyOf = (sap: string): string[] => [sap, ...[...linkMap()].filter(([, p]) => p === sap).map(([c]) => c)];

export interface AccountSet { live: Account[]; dead: Account[] }

// What people log all day (notes, to-dos, meetings, e-mails, offers ...) is not read by the account sums below (they are made from the SAP tables, the ledger,
// the customers and the settings), so those writes do not make them be added up again. Anything else that is written does.
export const NOT_IN_ACCOUNTS = ['activities', 'todos', 'meetings', 'daywork', 'plan_done', 'queue_state', 'sent_emails', 'offers_sent', 'opportunities', 'card_samples', 'radar_silenced', 'watch_items', 'trips', 'trip_stops', 'daily_explore', 'card_contacts', 'budget_expenses', 'complaints'] as const;
// Of the customers, the account sums read only the ones with a SAP number, and of those the number, the responsible person, the country, the market
// and the name. Customers are written all day (a note, a rating, a stage, a web site that was looked up): the sums are kept until one of THOSE
// fields changes. The fingerprint is taken again only after a customer was written (one quick read), not for every question.
const sapCustomersMark = memoTables(['cards'], () => {
  const h = createHash('sha1');
  for (const r of db.prepare('SELECT id, sap, person, country, market, company, name FROM cards WHERE sap IS NOT NULL ORDER BY id').all() as Record<string, unknown>[]) h.update(`${r.id}\u0001${r.sap}\u0001${r.person}\u0001${r.country}\u0001${r.market}\u0001${r.company}\u0001${r.name}\u0002`);
  return h.digest('hex');
});
const setsKept = new Map<number | string, { v: number; at: number; day?: string; mark?: string; data: AccountSet }>();
export const allAccountSets = (viewerId: number): AccountSet => memoByData(setsKept, viewerId, () => allAccountSetsRaw(viewerId), 300_000, [...NOT_IN_ACCOUNTS, 'cards'], sapCustomersMark);
function allAccountSetsRaw(viewerId: number): AccountSet {
  const today = todayIso();
  const year = Number(today.slice(0, 4));
  const sheets = sheetMetrics();
  const sapRows = db.prepare('SELECT * FROM sap_customers').all() as { sap_no: string; name: string; country: string; status_key: string; last_order: string | null }[];
  const aliasRows = db.prepare('SELECT sheet_name, sap_no FROM customer_aliases WHERE sap_no IS NOT NULL').all() as { sheet_name: string; sap_no: string }[];
  const sheetsOf = new Map<string, string[]>();
  const L = linkMap();
  const P = (sap: string) => L.get(sap) ?? sap;
  for (const a of aliasRows) (sheetsOf.get(P(a.sap_no)) ?? sheetsOf.set(P(a.sap_no), []).get(P(a.sap_no))!).push(a.sheet_name);

  const cards = new Map<string, { id: number; person: string | null; country: string | null; market: string | null }>();
  for (const c of db.prepare("SELECT id, sap, person, country, market FROM cards WHERE sap IS NOT NULL AND sap != ''").all() as { id: number; sap: string; person: string | null; country: string | null; market: string | null }[]) { const k = c.sap.trim(); if (!L.has(k) || !cards.has(P(k))) cards.set(P(k), { id: c.id, person: c.person, country: c.country, market: c.market }); if (!L.has(k)) cards.set(k, { id: c.id, person: c.person, country: c.country, market: c.market }); }
  const excluded = new Set((db.prepare('SELECT sap_no FROM perf_excluded').all() as { sap_no: string }[]).map((r) => r.sap_no));
  const swiftBy = waitingBySap();
  const nameOv = new Map((db.prepare('SELECT sap_no, name FROM perf_name_override').all() as { sap_no: string; name: string }[]).map((r) => [r.sap_no, r.name]));
  const repSet = new Map((db.prepare('SELECT sap_no, rep FROM perf_rep_override').all() as { sap_no: string; rep: string }[]).map((r) => [r.sap_no, r.rep]));

  const targets = new Map((db.prepare('SELECT sap_no, target_eur FROM export_targets WHERE year = ?').all(year) as { sap_no: string; target_eur: number }[]).map((r) => [r.sap_no, r.target_eur]));
  const hiddenBy = new Set((db.prepare('SELECT sap_no FROM perf_hidden WHERE user_id = ?').all(viewerId) as { sap_no: string }[]).map((r) => r.sap_no));
  const overrides = new Set((db.prepare('SELECT sap_no FROM perf_hold_override').all() as { sap_no: string }[]).map((r) => r.sap_no));
  const diag = new Map((db.prepare('SELECT sap_no, body FROM perf_diagnostics').all() as { sap_no: string; body: string }[]).map((r) => [r.sap_no, r.body]));
  const suggested = new Set((db.prepare('SELECT sap_no FROM perf_suggestions').all() as { sap_no: string }[]).map((r) => r.sap_no));

  const backlog = new Map<string, { m2: number; v: number }>();
  for (const r of db.prepare('SELECT sap_no, SUM(pending_m2) AS m2, SUM(value_eur) AS v FROM export_production_backlog GROUP BY sap_no').all() as { sap_no: string; m2: number | null; v: number | null }[]) {
    const o = backlog.get(P(r.sap_no)) ?? { m2: 0, v: 0 }; o.m2 += r.m2 ?? 0; o.v += r.v ?? 0; backlog.set(P(r.sap_no), o);
  }
  const blockers = new Map<string, number>();
  for (const r of db.prepare('SELECT sap_no, COUNT(DISTINCT sd_no) AS n FROM export_pipeline_blockers GROUP BY sap_no').all() as { sap_no: string; n: number }[]) blockers.set(P(r.sap_no), (blockers.get(P(r.sap_no)) ?? 0) + r.n);
  const ready = new Map<string, { n: number; rep: string | null; v: number; kg: number }>();
  for (const r of db.prepare('SELECT sap_no, COUNT(*) AS n, MAX(sales_rep) AS rep, SUM(net_value) AS v, SUM(weight) AS kg FROM export_dispatch_queue WHERE ' + NOT_SILENCED + ' GROUP BY sap_no').all() as { sap_no: string; n: number; rep: string | null; v: number | null; kg: number | null }[]) {
    const o = ready.get(P(r.sap_no)) ?? { n: 0, rep: r.rep, v: 0, kg: 0 }; o.n += r.n; o.v += r.v ?? 0; o.kg += r.kg ?? 0; ready.set(P(r.sap_no), o);
  }
  const waiting = new Map<string, number>();
  for (const r of db.prepare('SELECT sap_no, SUM(net_value) AS v FROM export_pipeline_blockers GROUP BY sap_no').all() as { sap_no: string; v: number | null }[]) waiting.set(P(r.sap_no), (waiting.get(P(r.sap_no)) ?? 0) + (r.v ?? 0));
  const termsBySap = termsMaps().bySap;
  const riskManual = new Map((db.prepare('SELECT sap_no, mode, reason FROM perf_risk').all() as { sap_no: string; mode: 'black' | 'clear'; reason: string | null }[]).map((r) => [r.sap_no, r]));
  const riskCfg = riskSettings();

  const known = new Set(sapRows.map((r) => r.sap_no));
  const extra = new Map<string, { name: string; country: string }>();
  for (const r of db.prepare('SELECT DISTINCT sap_no, customer FROM export_production_backlog UNION SELECT DISTINCT sap_no, customer FROM export_pipeline_blockers UNION SELECT DISTINCT sap_no, customer FROM export_dispatch_queue').all() as { sap_no: string; customer: string }[]) {
    if (r.sap_no && !known.has(r.sap_no) && !L.has(r.sap_no)) extra.set(r.sap_no, { name: r.customer, country: '' });
  }
  // a SAP number an admin gave to a ledger tab, but which is not in the SAP list yet (a new customer): named after its CRM record or the tab
  for (const a of aliasRows) {
    const sapNo = P(a.sap_no);
    if (known.has(sapNo) || extra.has(sapNo) || L.has(sapNo)) continue;
    extra.set(sapNo, { name: (db.prepare("SELECT COALESCE(NULLIF(company, ''), name) AS n FROM cards WHERE TRIM(sap) = ? LIMIT 1").get(sapNo) as { n: string | null } | undefined)?.n || a.sheet_name.replace(/\s*[-–—]\s*[^-–—]{2,30}$/, ''), country: '' });
  }
  const base = [...sapRows.map((r) => ({ sap: r.sap_no, name: niceName(r.name), country: r.country ?? '', status: r.status_key ?? 'dormant', lastOrder: r.last_order })), ...[...extra].map(([sap, e]) => ({ sap, name: niceName(e.name), country: e.country, status: 'active', lastOrder: null as string | null }))];
  const cutoff12 = monthsAgo(12, today);
  const cutoff24 = monthsAgo(24, today);
  const canon = canonicalReps();
  const live: Account[] = [];
  const dead: Account[] = [];

  for (const b of base) {
    if (excluded.has(b.sap) || L.has(b.sap)) continue;
    const mine = (sheetsOf.get(b.sap) ?? []).map((s) => sheets.get(s)).filter((x): x is SheetMetrics => !!x);
    const currency = mine[0]?.currency ?? 'EUR';
    let balance = 0, ytd = 0, prevYtd = 0, cuts = 0;
    let lastInvoice: string | null = null, lastPayment: string | null = null, lastMove: string | null = null;
    const years: Record<number, number> = {};
    const monthly: Record<number, number[]> = {};
    const aging = emptyAging();
    let oldest = 0;
    const settled: PaidInvoice[] = [];
    const openInv: { date: string; amount: number; daysOver: number }[] = [];
    const agingItems: OpenItem[] = [];
    for (const m of mine) {
      if (m.currency !== currency) continue; // one account, one currency
      settled.push(...m.settled);
      for (const it of m.open) openInv.push({ date: it.date, amount: it.amount, daysOver: it.daysOver });
      balance += m.owed; ytd += m.ytd; prevYtd += m.prevYtd; cuts += m.cuts;
      if (m.lastInvoice && (!lastInvoice || m.lastInvoice > lastInvoice)) lastInvoice = m.lastInvoice;
      if (m.lastPayment && (!lastPayment || m.lastPayment > lastPayment)) lastPayment = m.lastPayment;
      if (m.lastMove && (!lastMove || m.lastMove > lastMove)) lastMove = m.lastMove;
      for (const [y, v] of Object.entries(m.byYear)) years[Number(y)] = round((years[Number(y)] ?? 0) + v);
      for (const [y, arr] of Object.entries(m.monthly)) { const t = (monthly[Number(y)] ??= Array(12).fill(0)); arr.forEach((v, i) => { t[i] += v; }); }
      for (const it of m.open) agingItems.push(it);
    }
    OPEN_BY_SAP.set(b.sap, agingItems.map((i) => ({ ...i })));
    const swiftRows: SwiftRow[] = (swiftBy.get(b.sap) ?? []).filter((r) => r.currency === currency);
    for (const it of swiftRows.length ? applySwift(agingItems, swiftRows) : agingItems) { addAging(aging, it); if (it.daysOver > oldest) oldest = it.daysOver; }
    const lastActive = lastInvoice ?? b.lastOrder;
    const inactive = !lastActive || lastActive < cutoff12;
    const bestYear = Math.max(0, ...Object.values(years));
    const firstYear = Math.min(9999, ...Object.entries(years).filter(([, v]) => v > 0).map(([y]) => Number(y)));
    const span = [year - 3, year - 2, year - 1].filter((y) => y >= firstYear);
    const autoTarget = !inactive && span.length ? Math.round((span.reduce((a2, y) => a2 + (years[y] ?? 0), 0) / span.length) * 1.2) : 0;
    const manual = targets.get(b.sap) ?? null;
    const target = manual ?? (autoTarget > 0 ? autoTarget : null);
    const elapsed = Math.max(0.02, (Date.parse(today) - Date.parse(`${year}-01-01`)) / DAY / 365);
    const pace = target ? (ytd / target) * 100 : null;
    const health: Account['health'] = !target ? 'no_target' : ytd / target / elapsed >= 1 ? 'ahead' : ytd / target / elapsed >= 0.8 ? 'on_track' : 'behind';
    const card = cards.get(b.sap);
    const dispatchRep = ready.get(b.sap)?.rep ?? null;
    const isHold = inactive && balance >= HOLD_LIMIT;
    const isDiag = inactive && balance < SMALL_BALANCE && bestYear > BIG_YEAR;
    const rule: Account['rule'] = isHold ? 'hold' : isDiag ? 'diagnostic' : inactive && balance < HOLD_LIMIT ? 'hide' : 'none';
    const bl = backlog.get(b.sap);
    const ag = roundAging(aging);
    const overdue = round(ag.d30 + ag.d60 + ag.over60);
    const acc: Account = {
      sap: b.sap, name: nameOv.get(b.sap) ?? b.name, country: (card?.market !== 'domestic' && card?.country?.trim() ? canonicalCountry(card.country) : canonicalCountry(b.country)) as string, rep: canon(repSet.get(b.sap) ?? repOf(b.country, card?.person ?? null, dispatchRep)), cardId: card?.id ?? null, status: b.status,
      hasLedger: mine.length > 0, sheets: sheetsOf.get(b.sap) ?? [], currency, balance: round(balance), bankCuts: round(cuts), lastInvoice, lastPayment,
      ytd: round(ytd), prevYtd: round(prevYtd), prevYear: round(years[year - 1] ?? 0), prevRest: round(Math.max(0, (years[year - 1] ?? 0) - prevYtd)), bestYear: round(bestYear), years, monthly,
      target, targetAuto: manual === null && autoTarget > 0, suggestedTarget: autoTarget,
      pace: pace === null ? null : round(pace), yoy: prevYtd > 0 ? round(((ytd - prevYtd) / prevYtd) * 100) : null, health, inactive, rule,
      hold: isHold && !overrides.has(b.sap), overridden: isHold && overrides.has(b.sap), hidden: hiddenBy.has(b.sap),
      aging: ag, overdue, swift: swiftRows.length ? { amount: round(swiftRows.reduce((a2, r) => a2 + r.amount, 0)), count: swiftRows.length, date: swiftRows[0].date, days: daysBetween(swiftRows[0].date, today), stale: daysBetween(swiftRows[0].date, today) > 7 } : null, oldestOver: oldest, urgency: round(ag.d30 + ag.d60 * 2 + ag.over60 * 3),
      backlogM2: round(bl?.m2 ?? 0), backlogValue: round(bl?.v ?? 0), blockers: blockers.get(b.sap) ?? 0, readyToShip: ready.get(b.sap)?.n ?? 0,
      diagnostic: diag.get(b.sap) ?? null, hasSuggestion: suggested.has(b.sap),
      terms: termsBySap.get(b.sap) ?? termsDays(), waitingValue: round(waiting.get(b.sap) ?? 0), readyValue: round(ready.get(b.sap)?.v ?? 0), readyKg: round(ready.get(b.sap)?.kg ?? 0),
      risk: null as unknown as RiskProfile, black: false,
    };
    const rin: RiskInput = { settled, open: openInv, terms: acc.terms, today, annual: Math.max(years[year - 1] ?? 0, years[year] ?? 0), overdue: acc.overdue, oldestOver: acc.oldestOver, hold: acc.hold };
    acc.risk = riskProfile(rin, riskManual.get(b.sap) ?? null, riskCfg);
    acc.black = acc.risk.level === 'black';
    riskInputs.set(b.sap, rin);
    // a dead account: under €5,000 owed and nothing at all moved on the ledger for 24 months (an order on its way keeps it alive)
    const quiet = !lastMove || lastMove < cutoff24;
    const orderOn = acc.backlogValue > 0 || acc.blockers > 0 || acc.readyToShip > 0;
    if (quiet && balance < DEAD_BALANCE && !orderOn && (!b.lastOrder || b.lastOrder < cutoff24)) dead.push(acc); else live.push(acc);
  }
  return { live, dead };
}

export const allAccounts = (viewerId: number): Account[] => allAccountSets(viewerId).live;

// ---- who sees what ---------------------------------------------------------------------------------------------------------------
// Strict: a person sees the customers that have their name (and, for a manager, the names of the people who report to them) - nothing else.
export function scopeOf(viewer: Viewer): (a: Pick<Account, 'rep'>) => boolean {
  if (viewer.role === 'admin') return () => true;
  // strict: only the person's own customers; the people below them join only while the request is in Manager mode
  const names = new Set<string>(viewMode.team(viewer.id).names);
  if (viewer.display_name) names.add(viewer.display_name);
  return (a) => !!a.rep && names.has(a.rep);
}

export function setsFor(viewer: Viewer, repFilter: string | null = null): AccountSet {
  const ok = scopeOf(viewer);
  const set = allAccountSets(viewer.id);
  const pick = (list: Account[]) => list.filter((a) => ok(a) && (!repFilter || a.rep === repFilter));
  return { live: pick(set.live), dead: pick(set.dead) };
}

export const accountsFor = (viewer: Viewer): Account[] => setsFor(viewer).live;
// any account (alive or dead, whoever looks after it): only for the health bar of a customer page, which shows days and never money
export function accountOfSapAny(sap: string): Account | null {
  const real = linkMap().get(sap) ?? sap;
  const s = allAccountSets(0);
  return [...s.live, ...s.dead].find((a) => a.sap === real) ?? null;
}

export const accountOfSap = (viewer: Viewer, sap: string): Account | null => { const s = setsFor(viewer); return [...s.live, ...s.dead].find((a) => a.sap === sap) ?? null; };

// the people whose customers this person may look at (an admin: all sales people)
export function teamNames(viewer: Viewer): string[] {
  if (viewer.role === 'admin') return [...new Set(allAccounts(viewer.id).map((a) => a.rep).filter(Boolean))].sort();
  const below = viewMode.team(viewer.id).names; // the team shows only in Manager mode
  if (!below.length) return [];
  return [...new Set([...below, ...(viewer.display_name ? [viewer.display_name] : [])])].sort();
}

// Is this customer (a card of the CRM) on hold? Used when an offer or a proforma is sent.
export function holdOfCard(cardId: number): { hold: boolean; sap: string; balance: number } | null {
  const c = db.prepare('SELECT sap FROM cards WHERE id = ?').get(cardId) as { sap: string | null } | undefined;
  const raw = c?.sap?.trim();
  if (!raw) return null;
  const sap = linkMap().get(raw) ?? raw;
  const a = allAccounts(0).find((x) => x.sap === sap);
  return a?.hold ? { hold: true, sap, balance: a.balance } : null;
}

// Is this customer a black account? Used when an offer or a proforma is sent, and for the dispatch request.
export function blackOfCard(cardId: number): { sap: string; overdue: number; oldestOver: number; currency: string; reasons: string[] } | null {
  const c = db.prepare('SELECT sap FROM cards WHERE id = ?').get(cardId) as { sap: string | null } | undefined;
  const raw = c?.sap?.trim();
  if (!raw) return null;
  const sap = linkMap().get(raw) ?? raw;
  const a = accountOfSapAny(sap);
  return a?.black ? { sap, overdue: a.overdue, oldestOver: a.oldestOver, currency: a.currency, reasons: a.risk.reasons } : null;
}

// ---- the page --------------------------------------------------------------------------------------------------------------------
export interface WaitingOrder { sd: string; date: string | null; days: number; value: number; items: { name: string; qty: number; unit: string }[] }
export interface BlockerSum { sap: string; customer: string; orders: number; lines: number; value: number; currency: string; days: number; level: 'ok' | 'warn' | 'critical'; detail: WaitingOrder[] }
export interface MixLine { k: string; unit: string; amount: number }
export interface ProductionSum { sap: string; customer: string; orders: number; m2: number; value: number; firstDelivery: string | null; daysLeft: number | null; groups: string; mix: MixLine[]; detail: { order: string; delivery: string | null; daysLeft: number | null; m2: number; value: number; mix: MixLine[] }[] }
export interface DispatchLot { sd: string; date: string | null; days: number | null; value: number; weight: number }
// one box per customer: what is ready (VF04), what is still to be made (ZSD0013), what waits for the confirmation (ZSD0010) and how the account stands
export interface DispatchProduction { value: number; m2: number; orders: number; firstDelivery: string | null; daysLeft: number | null; mix: MixLine[]; detail: ProductionSum['detail'] }
export interface DispatchAccount { balance: number; overdue: number; oldestOver: number; currency: string; weOwe: boolean }
export interface DispatchSum { sap: string; customer: string; country: string; lots: number; sds: string[]; detail: DispatchLot[]; value: number; currency: string; weight: number; firstDate: string | null; salesRep: string; opsRep: string; production: DispatchProduction | null; waiting: { value: number; orders: number } | null; total: number; account: DispatchAccount | null; risk: RiskLevel | null; riskReasons: string[] }
export interface DataFile { kind: string; label: string; short: string; fileName: string; rows: number; at: string }
export interface YearRow { year: number; total: number; live: number; dead: number; unmatched: number; yoy: number | null }
export interface Overview {
  year: number;
  asOf: string;
  elapsedPct: number;
  currency: string;
  currencies: string[];
  combined: boolean;
  usdPerEur: number;
  kpi: { ytd: number; prevYtd: number; target: number | null; pace: number | null; backlogM2: number; backlogValue: number; blockerOrders: number; blockerValue: number; blockerLate: number; arTotal: number; arOverdue: number; aging: Aging; holds: number; bankCuts: number; unmatchedYtd: number; dispatchValue: number; dispatchKg: number; dispatchLots: number; blockerCustomers: number; black: number; blackOverdue: number };
  files: DataFile[];
  ledgerThrough: string | null;
  trajectory: { months: string[]; prev: number[]; current: (number | null)[]; targetLine: number[] | null };
  history: YearRow[];
  accounts: Account[];
  deadCount: number;
  blockers: BlockerSum[];
  production: ProductionSum[];
  dispatch: DispatchSum[];
  reps: string[];
}

// the same account with the dollars changed to euro (the "combined" view)
export function inEuro(a: Account, rate: number): Account {
  if (a.currency !== 'USD') return a;
  const f = 1 / rate;
  const r = (n: number) => round(n * f);
  const years: Record<number, number> = {};
  for (const [y, v] of Object.entries(a.years)) years[Number(y)] = r(v);
  const monthly: Record<number, number[]> = {};
  for (const [y, arr] of Object.entries(a.monthly)) monthly[Number(y)] = arr.map(r);
  return { ...a, monthly, currency: 'EUR', balance: r(a.balance), bankCuts: r(a.bankCuts), ytd: r(a.ytd), prevYtd: r(a.prevYtd), prevYear: r(a.prevYear), prevRest: r(a.prevRest), bestYear: r(a.bestYear), years,
    target: a.target === null ? null : r(a.target), suggestedTarget: r(a.suggestedTarget), aging: { current: r(a.aging.current), d30: r(a.aging.d30), d60: r(a.aging.d60), over60: r(a.aging.over60), total: r(a.aging.total) },
    overdue: r(a.overdue), urgency: r(a.urgency), waitingValue: r(a.waitingValue), readyValue: r(a.readyValue) };
}

// when each SAP file was uploaded the last time (everybody sees it: the numbers are only as new as the files)
const FILE_NAMES: Record<string, { label: string; short: string }> = {
  ledger: { label: 'Export ledger (customer accounts)', short: 'Ledger' },
  sap: { label: 'SAP customer list', short: 'SAP customers' },
  backlog: { label: 'ZSD0013 · production backlog', short: 'ZSD0013' },
  blockers: { label: 'ZSD0010 · waiting for confirmation / advance', short: 'ZSD0010' },
  dispatch: { label: 'VF04 · ready to ship', short: 'VF04' },
};
export function dataFiles(): DataFile[] {
  const rows = db.prepare('SELECT kind, file_name, rows, at FROM perf_uploads WHERE id IN (SELECT MAX(id) FROM perf_uploads GROUP BY kind)').all() as { kind: string; file_name: string | null; rows: number | null; at: string }[];
  const by = new Map(rows.map((r) => [r.kind, r]));
  return ['backlog', 'blockers', 'dispatch', 'ledger', 'sap'].map((k) => {
    const r = by.get(k);
    return { kind: k, label: FILE_NAMES[k].label, short: FILE_NAMES[k].short, fileName: r?.file_name ?? '', rows: r?.rows ?? 0, at: r ? `${r.at.replace(' ', 'T')}Z` : '' };
  });
}

export function overview(viewer: Viewer, repFilter: string | null, cur: string | null): Overview {
  const today = todayIso();
  const year = Number(today.slice(0, 4));
  const combined = cur === 'ALL';
  const rate = usdPerEur();
  const fx = (c: string) => (combined && c === 'USD' ? 1 / rate : 1);
  const sets0 = setsFor(viewer, repFilter);
  const sets: AccountSet = combined ? { live: sets0.live.map((a) => inEuro(a, rate)), dead: sets0.dead.map((a) => inEuro(a, rate)) } : sets0;
  const adminAll = viewer.role === 'admin' && !repFilter;
  const inScope = new Set([...sets.live, ...sets.dead].map((a) => a.sap));
  const sees = (sap: string) => adminAll || inScope.has(sap);
  const LM = linkMap();
  const P = (sap: string) => LM.get(sap) ?? sap;
  const excludedSaps = new Set((db.prepare('SELECT sap_no FROM perf_excluded').all() as { sap_no: string }[]).map((r) => r.sap_no));
  const nameOf = new Map([...sets.live, ...sets.dead].map((a2) => [a2.sap, a2.name]));
  const sheets = sheetMetrics();

  const base = [...new Set(sets0.live.map((a) => a.currency))].sort((a, b) => (a === 'EUR' ? -1 : b === 'EUR' ? 1 : a.localeCompare(b)));
  const currencies = base.length > 1 ? [...base, 'ALL'] : base;
  const currency = combined ? 'EUR' : cur && base.includes(cur) ? cur : base[0] ?? 'EUR';
  const accounts = sets.live;
  const mine = accounts.filter((a) => a.currency === currency);

  // the sheets that belong to the people in scope (an admin without a filter also gets the sheets not matched yet)
  const deadSaps = new Set(sets.dead.map((a) => a.sap));
  const liveSaps = new Set(sets.live.map((a) => a.sap));
  const sheetSap = new Map((db.prepare('SELECT sheet_name, sap_no FROM customer_aliases WHERE sap_no IS NOT NULL').all() as { sheet_name: string; sap_no: string }[]).map((r) => [r.sheet_name, P(r.sap_no)]));
  const prev = Array(12).fill(0);
  const curM = Array(12).fill(0);
  const hist = new Map<number, { live: number; dead: number; unmatched: number }>();
  let unmatchedYtd = 0;
  for (const [name, m] of sheets) {
    if (!combined && m.currency !== currency) continue;
    const k = fx(m.currency);
    const sap = sheetSap.get(name);
    const isLive = sap ? liveSaps.has(sap) : false;
    const isDead = sap ? deadSaps.has(sap) : false;
    if (!isLive && !isDead && !adminAll) continue;
    for (const [y, v] of Object.entries(m.byYear)) {
      if (Number(y) > year) continue;
      const h = hist.get(Number(y)) ?? { live: 0, dead: 0, unmatched: 0 };
      if (isLive) h.live += v * k; else if (isDead) h.dead += v * k; else h.unmatched += v * k;
      hist.set(Number(y), h);
    }
    if (!isLive && !isDead) unmatchedYtd += m.ytd * k;
    if (!isLive) continue;
    (m.monthly[year - 1] ?? []).forEach((v, i) => { prev[i] += v * k; });
    (m.monthly[year] ?? []).forEach((v, i) => { curM[i] += v * k; });
  }
  const years = [...hist.keys()].sort((a, b) => a - b);
  const history: YearRow[] = years.map((y, i) => {
    const h = hist.get(y)!;
    const total = h.live + h.dead + h.unmatched;
    const before = i > 0 && years[i - 1] === y - 1 ? hist.get(y - 1)! : null;
    const bt = before ? before.live + before.dead + before.unmatched : 0;
    return { year: y, total: round(total), live: round(h.live), dead: round(h.dead), unmatched: round(h.unmatched), yoy: bt > 0 ? round(((total - bt) / bt) * 100) : null };
  });

  const month = Number(today.slice(5, 7));
  const cumulative = (a: number[], upto: number) => { let s = 0; return a.map((v, i) => (i < upto ? (s += v, round(s)) : null)); };
  const targetTotal = mine.reduce((s, a) => s + (a.target ?? 0), 0);
  const ytd = mine.reduce((s, a) => s + a.ytd, 0);
  const prevYtd = mine.reduce((s, a) => s + a.prevYtd, 0);
  const aging = emptyAging();
  for (const a of mine) { aging.current += a.aging.current; aging.d30 += a.aging.d30; aging.d60 += a.aging.d60; aging.over60 += a.aging.over60; aging.total += a.aging.total; }

  // ZSD0010: orders that wait for the confirmation or the advance - one line per customer
  const bl = db.prepare('SELECT sd_no, doc_date, sap_no, customer, material_name, qty, unit, net_value, currency FROM export_pipeline_blockers').all() as { sd_no: string; doc_date: string | null; sap_no: string; customer: string; material_name: string | null; qty: number | null; unit: string | null; net_value: number | null; currency: string }[];
  const bmap = new Map<string, BlockerSum & { sds: Set<string>; od: Map<string, WaitingOrder> }>();
  for (const r of bl) {
    if (!sees(P(r.sap_no)) || excludedSaps.has(P(r.sap_no))) continue;
    const days = r.doc_date ? daysBetween(r.doc_date, today) : 0;
    const cc = combined ? 'EUR' : r.currency;
    const val = (r.net_value ?? 0) * fx(r.currency);
    const k = `${P(r.sap_no)}|${cc}`;
    const o = bmap.get(k) ?? { sap: P(r.sap_no), customer: nameOf.get(P(r.sap_no)) ?? r.customer, orders: 0, lines: 0, value: 0, currency: cc, days: 0, level: 'ok' as const, detail: [], sds: new Set<string>(), od: new Map<string, WaitingOrder>() };
    o.lines += 1; o.value += val; o.sds.add(r.sd_no); o.orders = o.sds.size; o.days = Math.max(o.days, days);
    const w = o.od.get(r.sd_no) ?? { sd: r.sd_no, date: r.doc_date, days, value: 0, items: [] };
    w.value += val;
    if (w.items.length < 6) w.items.push({ name: r.material_name ?? '', qty: r.qty ?? 0, unit: r.unit ?? '' });
    o.od.set(r.sd_no, w);
    bmap.set(k, o);
  }
  const blockers: BlockerSum[] = [...bmap.values()].map(({ sds: _s, od, ...o }) => ({ ...o, detail: [...od.values()].map((w) => ({ ...w, value: round(w.value) })).sort((x, y) => y.days - x.days), value: round(o.value), level: (o.days > 14 ? 'critical' : o.days > 7 ? 'warn' : 'ok') as BlockerSum['level'] })).sort((x, y) => y.value - x.value);

  // ZSD0013: what is still to be made and delivered - money first, one line per customer
  const pr = db.prepare('SELECT order_no, sap_no, customer, product_group, delivery_date, pending_m2, pending_kg, pending_qty, unit, width, value_eur FROM export_production_backlog').all() as { order_no: string; sap_no: string; customer: string; product_group: string; delivery_date: string | null; pending_m2: number | null; pending_kg: number | null; pending_qty: number | null; unit: string | null; width: number | null; value_eur: number | null }[];
  const pmap = new Map<string, ProductionSum & { os: Set<string>; gs: Map<string, number>; mx: Map<string, MixLine>; od: Map<string, { order: string; delivery: string | null; daysLeft: number | null; m2: number; value: number; mx: Map<string, MixLine> }> }>();
  for (const r of pr) {
    if (!sees(P(r.sap_no)) || excludedSaps.has(P(r.sap_no))) continue;
    const o = pmap.get(P(r.sap_no)) ?? { sap: P(r.sap_no), customer: nameOf.get(P(r.sap_no)) ?? r.customer, orders: 0, m2: 0, value: 0, firstDelivery: null, daysLeft: null, groups: '', mix: [], detail: [], os: new Set<string>(), gs: new Map<string, number>(), mx: new Map<string, MixLine>(), od: new Map() };
    const mixLine = productMix(r);
    const ml = o.mx.get(mixLine.k) ?? { k: mixLine.k, unit: mixLine.unit, amount: 0 };
    ml.amount += mixLine.amount;
    o.mx.set(mixLine.k, ml);
    const od = o.od.get(r.order_no) ?? { order: r.order_no, delivery: r.delivery_date, daysLeft: r.delivery_date ? daysBetween(today, r.delivery_date) : null, m2: 0, value: 0, mx: new Map<string, MixLine>() };
    od.m2 += r.pending_m2 ?? 0; od.value += r.value_eur ?? 0;
    if (r.delivery_date && (!od.delivery || r.delivery_date < od.delivery)) { od.delivery = r.delivery_date; od.daysLeft = daysBetween(today, r.delivery_date); }
    const oml = od.mx.get(mixLine.k) ?? { k: mixLine.k, unit: mixLine.unit, amount: 0 };
    oml.amount += mixLine.amount;
    od.mx.set(mixLine.k, oml);
    o.od.set(r.order_no, od);
    o.os.add(r.order_no); o.orders = o.os.size; o.m2 += r.pending_m2 ?? 0; o.value += r.value_eur ?? 0;
    if (r.delivery_date && (!o.firstDelivery || r.delivery_date < o.firstDelivery)) { o.firstDelivery = r.delivery_date; o.daysLeft = daysBetween(today, r.delivery_date); }
    o.gs.set(r.product_group || '—', (o.gs.get(r.product_group || '—') ?? 0) + (r.value_eur ?? 0));
    pmap.set(P(r.sap_no), o);
  }
  const production: ProductionSum[] = [...pmap.values()].map(({ os: _o, gs, mx, od, ...o }) => ({ ...o, detail: [...od.values()].map((x) => ({ order: x.order, delivery: x.delivery, daysLeft: x.daysLeft, m2: round(x.m2), value: round(x.value), mix: [...x.mx.values()].filter((m) => m.amount > 0.5).map((m) => ({ ...m, amount: Math.round(m.amount) })).sort((p, q) => MIX_ORDER.indexOf(p.k) - MIX_ORDER.indexOf(q.k)) })).sort((x, y) => (x.delivery ?? '9').localeCompare(y.delivery ?? '9')), mix: [...mx.values()].filter((m) => m.amount > 0.5).map((m) => ({ ...m, amount: Math.round(m.amount) })).sort((x, y) => MIX_ORDER.indexOf(x.k) - MIX_ORDER.indexOf(y.k)), m2: round(o.m2), value: round(o.value), groups: [...gs].sort((x, y) => y[1] - x[1]).slice(0, 3).map(([g]) => g).join(', ') })).sort((x, y) => y.value - x.value);

  // VF04: ready in Bursa - money and kilos, one line per customer
  const dr = db.prepare('SELECT sd_no, billing_date, sap_no, customer, country, net_value, currency, weight, sales_rep, ops_rep FROM export_dispatch_queue WHERE ' + NOT_SILENCED + ' ORDER BY billing_date').all() as { sd_no: string; billing_date: string | null; sap_no: string; customer: string; country: string; net_value: number | null; currency: string; weight: number | null; sales_rep: string; ops_rep: string }[];
  const dmap = new Map<string, Omit<DispatchSum, 'production' | 'waiting' | 'total' | 'account' | 'risk' | 'riskReasons'>>();
  for (const r of dr) {
    if (!sees(P(r.sap_no)) || excludedSaps.has(P(r.sap_no))) continue;
    const cc = combined ? 'EUR' : r.currency;
    const k = `${P(r.sap_no)}|${cc}`;
    const o = dmap.get(k) ?? { sap: P(r.sap_no), customer: nameOf.get(P(r.sap_no)) ?? r.customer, country: r.country, lots: 0, sds: [], detail: [], value: 0, currency: cc, weight: 0, firstDate: r.billing_date, salesRep: r.sales_rep, opsRep: r.ops_rep };
    o.lots += 1; o.sds.push(r.sd_no); o.value += (r.net_value ?? 0) * fx(r.currency); o.weight += r.weight ?? 0;
    o.detail.push({ sd: r.sd_no, date: r.billing_date, days: r.billing_date ? daysBetween(r.billing_date, today) : null, value: round((r.net_value ?? 0) * fx(r.currency)), weight: round(r.weight ?? 0) });
    dmap.set(k, o);
  }
  const accOf = new Map([...sets.live, ...sets.dead].map((a2) => [a2.sap, a2]));
  const prodBy = new Map(production.map((p) => [p.sap, p]));
  const waitBy = new Map(blockers.map((b) => [`${b.sap}|${b.currency}`, b]));
  const dispatch: DispatchSum[] = [...dmap.values()].map((o) => {
    const p = prodBy.get(o.sap);
    const w = waitBy.get(`${o.sap}|${o.currency}`);
    const acc2 = accOf.get(o.sap);
    const k = o.currency === 'USD' ? rate : 1; // the backlog is in euro: in a dollar view it is shown in dollars
    const production2: DispatchProduction | null = p ? { value: round(p.value * k), m2: p.m2, orders: p.orders, firstDelivery: p.firstDelivery, daysLeft: p.daysLeft, mix: p.mix, detail: p.detail.map((x) => ({ ...x, value: round(x.value * k) })) } : null;
    return {
      ...o, value: round(o.value), weight: round(o.weight), production: production2, waiting: w ? { value: w.value, orders: w.orders } : null, total: round(o.value + (production2?.value ?? 0)),
      account: acc2 ? { balance: acc2.balance, overdue: acc2.overdue, oldestOver: acc2.oldestOver, currency: acc2.currency, weOwe: acc2.balance < -0.5 } : null,
      risk: acc2?.risk.level ?? null, riskReasons: acc2 && acc2.risk.level !== 'good' ? acc2.risk.reasons.slice(0, 3) : [],
    };
  }).sort((x, y) => y.value - x.value);

  const reps = teamNames(viewer);
  const bCur = blockers.filter((r) => r.currency === currency);
  const dCur = dispatch.filter((r) => r.currency === currency);
  const elapsed = (Date.parse(today) - Date.parse(`${year}-01-01`)) / DAY / 365;
  return {
    year, asOf: today, elapsedPct: round(elapsed * 100), currency, currencies, combined, usdPerEur: rate,
    kpi: {
      ytd: round(ytd), prevYtd: round(prevYtd), target: targetTotal || null, pace: targetTotal ? round((ytd / targetTotal) * 100) : null,
      backlogM2: round(production.reduce((s, g) => s + g.m2, 0)), backlogValue: currency === 'EUR' ? round(production.reduce((s, g) => s + g.value, 0)) : 0,
      blockerOrders: bCur.reduce((s, b2) => s + b2.orders, 0), blockerCustomers: bCur.length, black: mine.filter((a) => a.black).length, blackOverdue: round(mine.filter((a) => a.black).reduce((s2, a) => s2 + a.overdue, 0)), dispatchValue: round(dCur.reduce((s, d2) => s + d2.value, 0)), dispatchKg: round(dCur.reduce((s, d2) => s + d2.weight, 0)), dispatchLots: dCur.reduce((s, d2) => s + d2.lots, 0), blockerValue: round(bCur.reduce((s, b) => s + b.value, 0)), blockerLate: bCur.filter((b) => b.level !== 'ok').length,
      arTotal: round(aging.total), arOverdue: round(aging.d30 + aging.d60 + aging.over60), aging: roundAging(aging), holds: mine.filter((a) => a.hold).length, bankCuts: round(mine.reduce((s, a) => s + a.bankCuts, 0)), unmatchedYtd: adminAll ? round(unmatchedYtd) : 0,
    },
    trajectory: {
      months: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
      prev: cumulative(prev, 12) as number[], current: cumulative(curM, month),
      targetLine: targetTotal ? Array.from({ length: 12 }, (_, i) => round((targetTotal * (i + 1)) / 12)) : null,
    },
    history, accounts, deadCount: sets.dead.length, blockers, production, dispatch, reps, files: dataFiles(), ledgerThrough: (db.prepare('SELECT MAX(tx_date) AS d FROM ledger_transactions').get() as { d: string | null }).d,
  };
}

// the four things to ask a customer for (the Mission board): payment, dispatch, order, confirmation - only the customers of the person
export interface Ask { sap: string; customer: string; cardId: number | null; line: string; value: number; currency: string; days: number | null; sd?: string }
export interface SamePeriod { currency: string; years: { year: number; amount: number; change: number | null }[] }
export interface SameCompany { sap: string; name: string; cardId: number | null; currency: string; years: Record<number, number> }
export interface Asks { hold: Ask[]; payment: Ask[]; dispatch: Ask[]; order: Ask[]; confirmation: Ask[]; totals: { payment: number; dispatch: number; order: number; confirmation: number }; samePeriod: SamePeriod[]; companies: SameCompany[]; through: string }

export function asksFor(viewer: Viewer, full = false): Asks {
  const today = todayIso();
  const sets = setsFor(viewer);
  const cardOf = new Map(sets.live.map((a) => [a.sap, a.cardId]));
  const payment = sets.live.filter((a) => a.overdue > 0.5).sort((a, b) => b.urgency - a.urgency)
    .map((a): Ask => ({ sap: a.sap, customer: a.name, cardId: a.cardId, line: `${a.oldestOver} days past due`, value: a.overdue, currency: a.currency, days: a.oldestOver }));
  const ov = overview(viewer, null, null);
  const dispatch = ov.dispatch.map((d): Ask => ({ sap: d.sap, customer: d.customer, cardId: cardOf.get(d.sap) ?? null, line: `${d.lots} lots, ${Math.round(d.weight).toLocaleString('en-US')} kg`, value: d.value, currency: d.currency, days: d.firstDate ? daysBetween(d.firstDate, today) : null, sd: d.sap }));
  const confirmation = ov.blockers.map((b): Ask => ({ sap: b.sap, customer: b.customer, cardId: cardOf.get(b.sap) ?? null, line: `${b.orders} orders`, value: b.value, currency: b.currency, days: b.days }));
  const order = sets.live.filter((a) => !a.hold && !a.inactive && a.prevYear > 0 && (a.health === 'behind' || (a.lastInvoice && daysBetween(a.lastInvoice, today) > 90)))
    .sort((a, b) => b.prevYear - a.prevYear)
    .map((a): Ask => ({ sap: a.sap, customer: a.name, cardId: a.cardId, line: a.lastInvoice ? `last invoice ${daysBetween(a.lastInvoice, today)} days ago` : 'behind the target', value: a.prevYear, currency: a.currency, days: a.lastInvoice ? daysBetween(a.lastInvoice, today) : null }));
  // the same days of the year (1 January to today) for five years, in euro and in dollars, for the customers of this person
  const sheetsAll = sheetMetrics();
  const scoped = new Set([...sets.live, ...sets.dead].flatMap((a) => a.sheets));
  const adminAll = viewer.role === 'admin';
  const year = Number(today.slice(0, 4));
  const samePeriod: SamePeriod[] = ['EUR', 'USD'].map((currency) => {
    const sums: Record<number, number> = {};
    for (const [name, m] of sheetsAll) {
      if (m.currency !== currency || (!adminAll && !scoped.has(name))) continue;
      for (const [y, v] of Object.entries(m.sameDays)) sums[Number(y)] = (sums[Number(y)] ?? 0) + v;
    }
    return { currency, years: [year - 4, year - 3, year - 2, year - 1, year].map((y, i, arr) => ({ year: y, amount: round(sums[y] ?? 0), change: i > 0 && (sums[arr[i - 1]] ?? 0) > 0 ? round((((sums[y] ?? 0) - (sums[arr[i - 1]] ?? 0)) / (sums[arr[i - 1]] ?? 0)) * 100) : null })) };
  }).filter((p) => p.years.some((y) => y.amount > 0));
  // and company by company: the same days of the year, five years, for the customers this person looks after
  const companies: SameCompany[] = sets.live.map((a) => {
    const years: Record<number, number> = {};
    for (const n of a.sheets) {
      const m = sheetsAll.get(n);
      if (!m || m.currency !== a.currency) continue;
      for (const [y, v] of Object.entries(m.sameDays)) years[Number(y)] = round((years[Number(y)] ?? 0) + v);
    }
    return { sap: a.sap, name: a.name, cardId: a.cardId, currency: a.currency, years };
  }).filter((c) => Object.values(c.years).some((v) => v > 0)).sort((x, y) => ((y.years[year] ?? 0) + (y.years[year - 1] ?? 0)) - ((x.years[year] ?? 0) + (x.years[year - 1] ?? 0)));
  const cut = (l: Ask[]) => (full ? l : l.slice(0, 8));
  // the accounts on a credit hold (the Money page)
  const hold = sets.live.filter((a) => a.hold).sort((a, b) => b.balance - a.balance).map((a): Ask => ({ sap: a.sap, customer: a.name, cardId: a.cardId, line: `${a.oldestOver} days past due`, value: a.balance, currency: a.currency, days: a.oldestOver }));
  return { hold: full ? hold : [], payment: cut(payment), dispatch: cut(dispatch), order: cut(order), confirmation: cut(confirmation), totals: { payment: payment.length, dispatch: dispatch.length, order: order.length, confirmation: confirmation.length }, samePeriod, companies, through: today };
}

// the sheets of the ledger that are not matched to a SAP customer yet
export function unresolvedSheets(): { sheet: string; balance: number; currency: string; last: string | null; active: boolean }[] {
  const cutoff = monthsAgo(12, todayIso());
  return (db.prepare('SELECT f.sheet_name, f.balance, f.currency, f.last_transaction_date FROM customer_financial_summary f LEFT JOIN customer_aliases a ON a.sheet_name = f.sheet_name WHERE a.sap_no IS NULL ORDER BY ABS(f.balance) DESC, f.last_transaction_date DESC').all() as { sheet_name: string; balance: number; currency: string; last_transaction_date: string | null }[])
    .map((r) => ({ sheet: r.sheet_name, balance: round(r.balance), currency: r.currency, last: r.last_transaction_date, active: !!r.last_transaction_date && r.last_transaction_date >= cutoff }));
}

export function statementItems(sap: string): { currency: string; items: OpenItem[]; balance: number } {
  const sheets = sheetMetrics();
  const names = familyOf(sap).flatMap((sp) => (db.prepare('SELECT sheet_name FROM customer_aliases WHERE sap_no = ?').all(sp) as { sheet_name: string }[]).map((r) => r.sheet_name));
  const ms = names.map((n) => sheets.get(n)).filter((x): x is SheetMetrics => !!x);
  const currency = ms[0]?.currency ?? 'EUR';
  const same = ms.filter((m) => m.currency === currency);
  return { currency, items: same.flatMap((m) => m.open).sort((a, b) => a.date.localeCompare(b.date)), balance: round(same.reduce((s, m) => s + m.owed, 0)) };
}

// the money invoiced to a customer, per year
export function yearsOf(sap: string): Record<number, number> {
  const sheets = sheetMetrics();
  const out: Record<number, number> = {};
  for (const r of familyOf(sap).flatMap((sp) => db.prepare('SELECT sheet_name FROM customer_aliases WHERE sap_no = ?').all(sp) as { sheet_name: string }[])) {
    for (const [y, v] of Object.entries(sheets.get(r.sheet_name)?.byYear ?? {})) out[Number(y)] = round((out[Number(y)] ?? 0) + v);
  }
  return out;
}

// one line per sales person: what a manager (or an admin) sees at the top, and clicks to see what that person sees
export interface PersonRow { name: string; customers: number; cur: { currency: string; ytd: number; prevYtd: number; target: number | null; overdue: number; waiting: number; ready: number }[]; combinedYtd: number; combinedPrev: number; combinedPace: number | null; behind: number }
export function teamSummary(viewer: Viewer): PersonRow[] {
  const names = teamNames(viewer);
  if (!names.length) return [];
  const rate = usdPerEur();
  const all = setsFor(viewer).live;
  const rows: PersonRow[] = names.map((name) => {
    const mine = all.filter((a) => a.rep === name);
    const byCur = new Map<string, PersonRow['cur'][number]>();
    let cy = 0, cp = 0, ct = 0, behind = 0;
    for (const a of mine) {
      const c = byCur.get(a.currency) ?? { currency: a.currency, ytd: 0, prevYtd: 0, target: null as number | null, overdue: 0, waiting: 0, ready: 0 };
      c.ytd += a.ytd; c.prevYtd += a.prevYtd; c.overdue += a.overdue; c.waiting += a.waitingValue; c.ready += a.readyValue;
      if (a.target) c.target = (c.target ?? 0) + a.target;
      byCur.set(a.currency, c);
      const f = a.currency === 'USD' ? 1 / rate : 1;
      cy += a.ytd * f; cp += a.prevYtd * f; ct += (a.target ?? 0) * f;
      if (a.health === 'behind') behind += 1;
    }
    return { name, customers: mine.length, cur: [...byCur.values()].map((c) => ({ ...c, ytd: round(c.ytd), prevYtd: round(c.prevYtd), overdue: round(c.overdue), waiting: round(c.waiting), ready: round(c.ready), target: c.target === null ? null : round(c.target) })), combinedYtd: round(cy), combinedPrev: round(cp), combinedPace: ct ? round((cy / ct) * 100) : null, behind };
  });
  return rows.filter((r) => r.customers > 0).sort((a, b) => b.combinedYtd - a.combinedYtd);
}

// the customers that matter (by what they bought) and have no e-mail or no phone in the CRM, per sales person. When the details are filled in, the customer is gone from the list.
export interface MissingRow { sap: string; name: string; cardId: number | null; country: string; volume: number; currency: string; noEmail: boolean; noPhone: boolean; noRecord: boolean }
export interface MissingGroup { rep: string; total: number; rows: MissingRow[] }
export function missingContacts(viewer: Viewer): MissingGroup[] {
  const live = setsFor(viewer).live.filter((a) => a.bestYear > 0 || a.ytd > 0);
  const ids = live.map((a) => a.cardId).filter((x): x is number => !!x);
  const info = new Map<number, { email: boolean; phone: boolean }>();
  if (ids.length) {
    const marks = ids.map(() => '?').join(',');
    const valid = (e: string | null) => !!e && /@/.test(e);
    for (const c of db.prepare(`SELECT id, email, tel, mobile FROM cards WHERE id IN (${marks})`).all(...ids) as { id: number; email: string | null; tel: string | null; mobile: string | null }[]) info.set(c.id, { email: valid(c.email), phone: !!(c.tel?.trim() || c.mobile?.trim()) });
    for (const c of db.prepare(`SELECT card_id AS id, email, tel, mobile FROM card_contacts WHERE card_id IN (${marks})`).all(...ids) as { id: number; email: string | null; tel: string | null; mobile: string | null }[]) {
      const cur = info.get(c.id) ?? { email: false, phone: false };
      info.set(c.id, { email: cur.email || valid(c.email), phone: cur.phone || !!(c.tel?.trim() || c.mobile?.trim()) });
    }
  }
  const groups = new Map<string, MissingRow[]>();
  for (const a of live) {
    const i = a.cardId ? info.get(a.cardId) ?? { email: false, phone: false } : { email: false, phone: false };
    if (i.email && i.phone) continue;
    const rows = groups.get(a.rep || '—') ?? [];
    rows.push({ sap: a.sap, name: a.name, cardId: a.cardId, country: a.country, volume: Math.max(a.ytd, a.prevYear), currency: a.currency, noEmail: !i.email, noPhone: !i.phone, noRecord: !a.cardId });
    groups.set(a.rep || '—', rows);
  }
  return [...groups].map(([rep, rows]) => ({ rep, total: rows.length, rows: rows.sort((x, y) => y.volume - x.volume).slice(0, 12) })).sort((x, y) => x.rep.localeCompare(y.rep));
}
