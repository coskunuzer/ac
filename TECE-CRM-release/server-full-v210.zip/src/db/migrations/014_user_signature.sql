-- The signature under each person's emails: job title, mobile and office phone
-- (the name comes from the display name, the company lines are fixed).
ALTER TABLE users ADD COLUMN job_title TEXT;
ALTER TABLE users ADD COLUMN mobile TEXT;
ALTER TABLE users ADD COLUMN office_phone TEXT;
