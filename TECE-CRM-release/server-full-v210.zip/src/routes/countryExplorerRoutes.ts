import { Router } from 'express';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { addNote, analysisAi, countryScope, customersOf, factsOf, isoOf, listCountries, marketAi, notesOf, refreshFacts, turnoverOf } from '../services/countryExplorer';
import { canonicalCountry, countryKey } from '../models/countryModel';
import { db } from '../db/connection';
import { cardModel } from '../models/cardModel';
import { canSeeCard } from '../services/visibility';
import { lookupPlace } from '../services/geocode';

// Country explorer (under Map). Everybody sees the TOTAL turnover of a country; customers and their figures only as far as the person may see them.
const router = Router();
router.use(requireAuth);
const viewerOf = (req: AuthedRequest) => ({ id: req.user!.id, role: req.user!.role, display_name: req.user!.display_name });
const countryOf = (req: AuthedRequest): string => String(canonicalCountry(String(req.params.country ?? '').trim()) || '');
const langOf = (req: AuthedRequest): string => (String(req.body?.lang ?? req.query.lang ?? '').startsWith('tr') ? 'tr' : 'en');

// where a customer's address is on the map (for the popup): the written address first, then the city. A person looks at the map and says if it is right.
router.post('/geo/lookup', async (req: AuthedRequest, res) => {
  const city = String(req.body?.city ?? '').trim(); const address = String(req.body?.address ?? '').trim(); const country = String(req.body?.country ?? '').trim();
  if (!city && !address) return res.status(400).json({ error: 'Write a city or an address.' });
  const iso = country ? isoOf(String(canonicalCountry(country))) : null;
  const q = [address, city, country].filter(Boolean).join(', ');
  // a written address is looked up as it is; a city alone is looked up among towns and cities only (so a misspelt name does not match a street)
  const found = address ? ((await lookupPlace(q, iso)) ?? (city ? await lookupPlace([city, country].filter(Boolean).join(', '), iso, true) : null)) : await lookupPlace(q, iso, true);
  res.json({ found, query: q });
});

// a person confirms the place (or the address changed and the old point must go): the trip planner uses this point
router.post('/geo/set', (req: AuthedRequest, res) => {
  const card = cardModel.findById(parseInt(String(req.body?.cardId), 10));
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canSeeCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  const lat = Number(req.body?.lat), lon = Number(req.body?.lon);
  if (req.body?.reset || !Number.isFinite(lat) || !Number.isFinite(lon)) db.prepare('UPDATE cards SET lat = NULL, lon = NULL, geo_source = NULL, geo_place = NULL WHERE id = ?').run(card.id);
  else db.prepare("UPDATE cards SET lat = ?, lon = ?, geo_source = 'manual', geo_place = ? WHERE id = ?").run(lat, lon, String(req.body?.place ?? '').slice(0, 200) || null, card.id);
  res.json({ ok: true });
});

router.get('/', (req: AuthedRequest, res) => {
  const scope = countryScope(viewerOf(req));
  res.json({ countries: scope ? listCountries().filter((c) => scope.has(countryKey(c.country))) : listCountries() });
});

router.get('/:country', async (req: AuthedRequest, res) => {
  const country = countryOf(req);
  if (!country) return res.status(400).json({ error: 'Choose a country.' });
  const iso = isoOf(country);
  const viewer = viewerOf(req);
  const scope = countryScope(viewer);
  if (scope && !scope.has(countryKey(country))) return res.status(403).json({ error: 'This country is not in your team.' });
  const facts = iso ? factsOf(iso) : null; // what is kept; the public figures are fetched in the background by /facts, so the page opens at once
  res.json({
    country, iso, facts,
    turnover: turnoverOf(viewer, country),
    customers: customersOf(viewer, country),
    notes: iso ? notesOf(iso) : [],
  });
});

router.get('/:country/facts', async (req: AuthedRequest, res) => {
  const country = countryOf(req); const iso = isoOf(country);
  if (!iso) return res.json({ facts: null });
  res.json({ facts: await refreshFacts(iso, country) });
});

router.post('/:country/refresh', async (req: AuthedRequest, res) => {
  const country = countryOf(req); const iso = isoOf(country);
  if (!iso) return res.status(400).json({ error: 'This country has no ISO code.' });
  res.json({ facts: await refreshFacts(iso, country, true) });
});

// the AI parts: asked on request, saved, shown as estimates
router.post('/:country/market', async (req: AuthedRequest, res) => {
  const country = countryOf(req); const iso = isoOf(country);
  if (!iso) return res.status(400).json({ error: 'This country has no ISO code.' });
  const facts = await refreshFacts(iso, country);
  const r = await marketAi(viewerOf(req), facts, langOf(req));
  if (!r.ok) return res.status(503).json({ error: r.error });
  res.json({ facts: factsOf(iso) });
});

router.post('/:country/analyse', async (req: AuthedRequest, res) => {
  const country = countryOf(req); const iso = isoOf(country);
  if (!iso) return res.status(400).json({ error: 'This country has no ISO code.' });
  const viewer = viewerOf(req);
  const facts = await refreshFacts(iso, country);
  const r = await analysisAi(viewer, facts, turnoverOf(viewer, country), customersOf(viewer, country), langOf(req));
  if (!r.ok) return res.status(503).json({ error: r.error });
  res.json({ facts: factsOf(iso) });
});

router.post('/:country/notes', (req: AuthedRequest, res) => {
  const country = countryOf(req); const iso = isoOf(country);
  const text = String(req.body?.text ?? '').trim();
  if (!iso || !text) return res.status(400).json({ error: 'Write something.' });
  addNote(iso, country, viewerOf(req), String(req.body?.kind ?? 'note'), text);
  res.json({ notes: notesOf(iso) });
});

export default router;
