import { Router, type Response } from 'express';
import { db } from '../db/connection';
import { requireAuth, requireAdmin, type AuthedRequest } from '../middleware/auth';
import { overview, proposeShares, setTarget, saveForecast, canEditForecast, dataCut, type Channel } from '../services/salesTargets';
import { targetsWorkbook } from '../services/salesReports';

// Revenue targets and forecasts. Everybody signed in sees their own line; an admin and the people who may oversee the team see everybody.
const router = Router();
router.use(requireAuth);
const fail = (res: Response, err: unknown, code = 400) => res.status(code).json({ error: err instanceof Error ? err.message : String(err) });
const chOf = (v: unknown): Channel => (v === 'export' || v === 'domestic' ? v : 'all');
const viewer = (req: AuthedRequest) => {
  const u = req.user!; const admin = u.role === 'admin';
  const seeAll = admin || !!u.can_oversee || !!req.actor?.can_oversee || req.actor?.role === 'admin';
  return { id: u.id, admin, seeAll, name: u.display_name || u.username };
};

router.get('/overview', (req: AuthedRequest, res) => {
  try { res.json(overview({ ym: String(req.query.ym ?? ''), channel: chOf(req.query.channel), viewer: viewer(req) })); } catch (e) { console.error('Targets overview failed:', e); fail(res, e); }
});

router.get('/export.xlsx', async (req: AuthedRequest, res) => {
  try {
    const o = overview({ ym: String(req.query.ym ?? ''), channel: chOf(req.query.channel), viewer: viewer(req) });
    const buf = await targetsWorkbook(o);
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="Hedef-Tahmin-${o.ym || 'rapor'}.xlsx"`);
    res.send(buf);
  } catch (e) { fail(res, e); }
});

// the people a target can be divided between, with their share of the last 12 months (a proposal, nothing is saved)
router.get('/suggest', requireAdmin, (req, res) => { res.json(proposeShares(chOf(req.query.channel))); });

// set one target: period = YYYY or YYYY-MM; userId 0 = the company; no amount removes it
router.put('/target', requireAdmin, (req: AuthedRequest, res) => {
  try {
    const period = String(req.body?.period ?? ''); const userId = Number(req.body?.userId ?? 0) || 0;
    const raw = req.body?.amount; const amount = raw === null || raw === '' || raw === undefined ? null : Number(String(raw).replace(/[^\d.]/g, ''));
    if (userId && !db.prepare('SELECT id FROM users WHERE id = ?').get(userId)) throw new Error('That person does not exist.');
    setTarget(period, userId, amount, req.user!.id);
    res.json({ ok: true });
  } catch (e) { fail(res, e); }
});

// several targets in one go: [{ period, userId, amount }]
router.post('/targets', requireAdmin, (req: AuthedRequest, res) => {
  try {
    const list = Array.isArray(req.body?.items) ? req.body.items as { period: string; userId?: number; amount: number | string | null }[] : [];
    if (!list.length || list.length > 400) throw new Error('Nothing to save.');
    db.exec('BEGIN');
    try {
      for (const it of list) {
        const amount = it.amount === null || it.amount === '' || it.amount === undefined ? null : Number(String(it.amount).replace(/[^\d.]/g, ''));
        setTarget(String(it.period), Number(it.userId ?? 0) || 0, amount, req.user!.id);
      }
      db.exec('COMMIT');
    } catch (e) { db.exec('ROLLBACK'); throw e; }
    res.json({ ok: true, saved: list.length });
  } catch (e) { fail(res, e); }
});

// the forecast of a sales person for a month. A person types their own; an admin can type anybody's.
router.put('/forecast', (req: AuthedRequest, res) => {
  try {
    const me = viewer(req); const ym = String(req.body?.ym ?? '');
    const userId = me.admin && req.body?.userId ? Number(req.body.userId) : me.id;
    if (!me.admin && userId !== me.id) throw new Error('You can only type your own forecast.');
    const cut = dataCut() ?? new Date().toISOString().slice(0, 10);
    if (!canEditForecast(ym, cut, me.admin)) throw new Error(`The forecast of ${ym} is closed: it can be typed until day 10 of the month. Ask an admin to change it.`);
    const raw = req.body?.amount; const amount = raw === null || raw === '' || raw === undefined ? null : Number(String(raw).replace(/[^\d.]/g, ''));
    saveForecast(userId, ym, amount, String(req.body?.note ?? '').slice(0, 300), req.user!.id);
    res.json({ ok: true });
  } catch (e) { fail(res, e); }
});

// every change of a target or a forecast (append-only)
router.get('/log', requireAdmin, (_req, res) => {
  res.json({
    targets: db.prepare('SELECT l.period, l.user_id, COALESCE(u.display_name, \'Company\') AS who, l.before_eur, l.after_eur, b.display_name AS by_name, l.at FROM sales_targets_log l LEFT JOIN users u ON u.id = l.user_id AND l.user_id > 0 LEFT JOIN users b ON b.id = l.by_user ORDER BY l.id DESC LIMIT 100').all(),
    forecasts: db.prepare('SELECT l.ym, u.display_name AS who, l.amount_eur, l.note, b.display_name AS by_name, l.at FROM sales_forecasts_log l LEFT JOIN users u ON u.id = l.user_id LEFT JOIN users b ON b.id = l.by_user ORDER BY l.id DESC LIMIT 100').all(),
  });
});

export default router;
