import type { NextFunction, Request, Response } from 'express';
import { db } from '../db/connection';
import { env } from '../config/env';
import { settingsModel } from '../models/settingsModel';
import { blockedReason } from './aiGate';

// The AI costs money for every question. So it is never run by itself on every customer: a person asks for it on one customer at a
// time, up to a daily limit; the big jobs (many customers at once) are for admins only.
export const DEFAULT_AI_LIMIT = 15;

export const aiDailyLimit = (): number => {
  const n = parseInt(settingsModel.get('ai_daily_limit') ?? '', 10);
  return Number.isFinite(n) && n >= 0 ? Math.min(n, 500) : DEFAULT_AI_LIMIT;
};
export const setAiDailyLimit = (n: number): number => {
  const v = Math.max(0, Math.min(500, Math.round(n)));
  settingsModel.set('ai_daily_limit', String(v));
  return v;
};

// A guard for the big jobs: refuses with the reason when the AI is switched off or a limit is reached (instead of starting a job that cannot run).
export function needAi(_req: Request, res: Response, next: NextFunction): void {
  const blocked = env.geminiApiKey ? blockedReason() : null;
  if (blocked) {
    res.status(503).json({ error: blocked, ai: true });
    return;
  }
  next();
}

const today = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });

export function aiAllowance(user: { id: number; role: string }): { admin: boolean; limit: number; used: number; left: number; hasKey: boolean } {
  const used = (db.prepare('SELECT n FROM ai_usage WHERE user_id = ? AND day = ?').get(user.id, today()) as { n: number } | undefined)?.n ?? 0;
  const limit = aiDailyLimit();
  return { admin: user.role === 'admin', limit, used, left: user.role === 'admin' ? 999 : Math.max(0, limit - used), hasKey: !!env.geminiApiKey };
}

// Asks for one use of the AI. True when it may go ahead (it is counted); false after answering 429 when today's limit is used up.
// Without a Gemini key nothing is spent: the answer is a plain-rules one anyway.
export function useAi(user: { id: number; role: string }, res: Response): boolean {
  if (!env.geminiApiKey) return true;
  // switched off by an admin, or a token limit is reached: nobody (the admin neither) can ask now, and the answer says why
  const blocked = blockedReason();
  if (blocked) {
    res.status(503).json({ error: blocked, ai: true });
    return false;
  }
  if (user.role === 'admin') return true;
  const a = aiAllowance(user);
  if (a.left <= 0) {
    res.status(429).json({ ai: true, error: `You have used your ${a.limit} AI questions for today. They come back tomorrow, or an admin can run the AI for many customers at once.` });
    return false;
  }
  db.prepare('INSERT INTO ai_usage (user_id, day, n) VALUES (?, ?, 1) ON CONFLICT(user_id, day) DO UPDATE SET n = n + 1').run(user.id, today());
  return true;
}
