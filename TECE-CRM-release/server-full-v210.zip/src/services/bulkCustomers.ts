import fs from 'fs';
import path from 'path';
import { db } from '../db/connection';
import { env, paths } from '../config/env';
import { cardModel, isJustLead, type CardRow } from '../models/cardModel';
import { cityKey } from '../models/cityModel';
import { countryKey } from '../models/countryModel';
import type { PublicUser } from '../models/userModel';
import { removeCustomerFolder } from './customerFiles';
import { myCityKeys, myCountryKeys } from './visibility';
import { logAi, runForCard } from './aiLog';

// Who may delete a customer: an admin, anybody. Everybody else only a "just lead" (no web site and no e-mail, or not rated yet -
// never a customer or a hot deal), and only when they look after its country (or city).
// An existing or important customer is never deleted, by anybody (an admin can still send it to the junk folder or merge it into another record: both keep everything).
// Existing = a customer stage, an SAP number, a sent offer, an open or won deal, a proforma or other archived document.
export function isProtected(card: CardRow): boolean {
  if (card.stage === 'customer' || (card.sap ?? '').trim()) return true;
  const has = (sql: string) => !!db.prepare(sql).get(card.id);
  return has('SELECT 1 FROM offers_sent WHERE card_id = ? LIMIT 1') || has("SELECT 1 FROM opportunities WHERE card_id = ? AND status IN ('open', 'won') LIMIT 1") || has('SELECT 1 FROM document_archive WHERE card_id = ? LIMIT 1');
}

export function canDeleteCard(user: Pick<PublicUser, 'role' | 'display_name'>, card: CardRow, mine?: { countries: Set<string>; cities: Set<string> }): boolean {
  if (user.role === 'admin') return true;
  const pm = (user as { perms?: { actions: string[] } | null }).perms; // a person with a permissions row deletes only when "Delete" is switched on
  if (pm && !pm.actions.includes('del')) return false;
  if (card.delete_locked) return false; // the admin who uploaded this list said: only an admin deletes these
  if (!isJustLead(card)) return false;
  const keys = mine ?? { countries: myCountryKeys(user.display_name), cities: myCityKeys(user.display_name) };
  if (card.market === 'domestic') return !!card.city && keys.cities.has(cityKey(card.city));
  return !!card.country && keys.countries.has(countryKey(card.country));
}

// Sending ONE record to the junk folder (it can always be brought back; only an admin deletes for good). A sales person may do it for a record of a
// country/city they look after (or that carries their name) when it is not a customer, not an active deal and not rated 5 or more - even when it has an
// e-mail or a web site and has been rated low (a disqualified inquiry is exactly what the junk folder is for).
export function canJunkCard(user: Pick<PublicUser, 'role' | 'display_name'>, card: CardRow, mine?: { countries: Set<string>; cities: Set<string> }): boolean {
  if (user.role === 'admin') return true;
  const pm = (user as { perms?: { actions: string[] } | null }).perms;
  if (pm && !pm.actions.includes('del')) return false;
  if (card.delete_locked) return false;
  if (card.stage && !['lead', 'contacted', 'lost'].includes(card.stage)) return false;
  const rating = card.rate ?? (card.ai_rate_source === 'ai' ? card.ai_rate : null);
  if (rating !== null && rating !== undefined && rating >= 5) return false;
  if (isProtected(card)) return false;
  if (card.person && user.display_name && card.person === user.display_name) return true;
  const keys = mine ?? { countries: myCountryKeys(user.display_name), cities: myCityKeys(user.display_name) };
  if (card.market === 'domestic') return !!card.city && keys.cities.has(cityKey(card.city));
  return !!card.country && keys.countries.has(countryKey(card.country));
}

export function removeCard(card: CardRow): void {
  if (card.image_path) {
    const file = path.join(paths.uploadsDir, card.image_path);
    fs.unlink(file, () => undefined);
  }
  db.prepare('DELETE FROM activities WHERE card_id = ?').run(card.id);
  db.prepare('DELETE FROM price_changes WHERE card_id = ?').run(card.id);
  cardModel.delete(card.id);
  removeCustomerFolder(card);
}

// ---- finding the web site of a company --------------------------------------------------------------------------

const GEMINI_URL = 'https://generativelanguage.googleapis.com/v1beta/models';
const MODEL = 'gemini-3.6-flash';

export interface WebsiteJob {
  running: boolean;
  total: number;
  done: number;
  found: number;
  none: number;
  startedAt: string | null;
  finishedAt: string | null;
  hasKey: boolean;
}
let job: WebsiteJob = { running: false, total: 0, done: 0, found: 0, none: 0, startedAt: null, finishedAt: null, hasKey: !!env.geminiApiKey };
export const websiteStatus = (): WebsiteJob => ({ ...job, hasKey: !!env.geminiApiKey });

const words = (s: string) =>
  s.normalize('NFD').replace(/\p{Diacritic}/gu, '').toLowerCase().replace(/[^a-z0-9 ]+/g, ' ').split(' ').filter((w) => w.length > 2 && !['ltd', 'llc', 'inc', 'the', 'and', 'sas', 'srl', 'gmbh', 'corp', 'company', 'sanayi', 'ticaret', 'anonim', 'sirketi'].includes(w));

// The address is real when the page opens and mentions the company (a word of its name, in the page or in the address).
async function verify(url: string, company: string): Promise<string | null> {
  const clean = /^https?:\/\//i.test(url) ? url : `https://${url}`;
  try {
    const res = await fetch(clean, { redirect: 'follow', signal: AbortSignal.timeout(9000), headers: { 'user-agent': 'Mozilla/5.0 (compatible; TECE-CRM website check)', accept: 'text/html' } });
    if (!res.ok) return null;
    const html = (await res.text()).slice(0, 200000).normalize('NFD').replace(/\p{Diacritic}/gu, '').toLowerCase();
    const host = new URL(res.url).hostname.toLowerCase();
    const mine = words(company).slice(0, 3);
    if (!mine.length) return null;
    const hit = mine.some((w) => html.includes(w) || host.includes(w));
    return hit ? new URL(res.url).origin : null;
  } catch {
    return null;
  }
}

// The address; null when the AI says there is none; undefined when the AI could not be asked (stopped, out of budget, no answer):
// that is not an answer, so the customer must not be marked "no web site".
async function askForWebsite(company: string, country: string | null): Promise<string | null | undefined> {
  const prompt = `Find the official web site of this company: "${company}"${country ? `, in ${country}` : ''}. It buys or makes furniture, kitchens, doors, panels or edgebanding. Use a web search. Answer with one line only: either WEBSITE: <the address of its own web site> or WEBSITE: NONE. Never answer with a directory, a social-media page, a marketplace or a trade register - only the company's own site. If you are not sure it is the right company, answer NONE.`;
  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      const res = await fetch(`${GEMINI_URL}/${MODEL}:generateContent`, {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-goog-api-key': env.geminiApiKey },
        body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: prompt }] }], tools: [{ google_search: {} }], generationConfig: { temperature: 0 } }),
        signal: AbortSignal.timeout(45000),
      });
      if (!res.ok) {
        if (res.status === 429 || res.status >= 500) {
          await new Promise((r) => setTimeout(r, 2500 * (attempt + 1)));
          continue;
        }
        return undefined;
      }
      const data = (await res.json()) as { candidates?: { content?: { parts?: { text?: string; thought?: boolean }[] } }[] };
      const text = (data.candidates?.[0]?.content?.parts ?? []).filter((p) => !p.thought && p.text).map((p) => p.text).join(' ');
      const m = /WEBSITE:\s*(\S+)/i.exec(text);
      if (!m || /^none/i.test(m[1])) return null;
      const url = m[1].replace(/[)\].,;>"']+$/, '');
      return /^(https?:\/\/)?[a-z0-9.-]+\.[a-z]{2,}/i.test(url) ? url : null;
    } catch {
      await new Promise((r) => setTimeout(r, 1500));
    }
  }
  return undefined;
}

// Looks the companies up one by one (a few at a time): a company with a web site gets it written on the customer and moves up
// to "e-mail or web"; one without is marked "no web site", so it can be removed.
export function startWebsiteSearch(ids: number[]): WebsiteJob {
  if (job.running) return websiteStatus();
  const queue = [...ids];
  job = { running: !!env.geminiApiKey && queue.length > 0, total: queue.length, done: 0, found: 0, none: 0, startedAt: new Date().toISOString(), finishedAt: env.geminiApiKey && queue.length ? null : new Date().toISOString(), hasKey: !!env.geminiApiKey };
  if (!job.running) return websiteStatus();
  const worker = async () => {
    while (queue.length) {
      const id = queue.shift()!;
      try {
        const card = cardModel.findById(id);
        if (card && card.company && card.website_check !== 'found') {
          const guess = await runForCard(id, () => askForWebsite(card.company!, card.country));
          const site = guess ? await verify(guess, card.company) : null;
          if (site) {
            db.prepare("UPDATE cards SET website = ?, website_check = 'found', contact_group = CASE WHEN contact_group = 'no_contact' THEN 'reachable' ELSE contact_group END WHERE id = ?").run(site, id);
            logAi(id, `AI found the web site ${site}`);
            job.found += 1;
          } else if (guess !== undefined) {
            db.prepare("UPDATE cards SET website_check = 'none' WHERE id = ?").run(id);
            logAi(id, 'AI looked for the web site of this company and found none');
            job.none += 1;
          }
          // (no answer from the AI at all: the customer is left as it was)
        }
      } catch (err) {
        console.error('Web site search failed for', id, err);
      }
      job.done += 1;
    }
  };
  void Promise.all([worker(), worker(), worker(), worker()]).finally(() => {
    job.running = false;
    job.finishedAt = new Date().toISOString();
  });
  return websiteStatus();
}
