import { db } from '../db/connection';
import { env } from '../config/env';
import { cardModel, type CardRow } from '../models/cardModel';
import { distributorModel } from '../models/distributorModel';
import { fetchHtml } from './websiteLookup';
import { canonicalCountry } from '../models/countryModel';
import { COUNTRY_NAMES } from '../data/countries';
import { resolveCity } from '../data/turkeyPlaces';
import { analysePhone, splitNumbers } from './phone';
import { settingsModel } from '../models/settingsModel';
import { addSiteSuppliers } from './competitors';
import { FACT_KEYS, checkFacts, computeScore, rateOf, verdictOf, type Fact, type ScoreResult } from './companyScoring';
import { logAi, runForCard } from './aiLog';
import { DEFAULT_RATING_PROMPT } from './leadPrompt';
import { normText } from './companyScoring';

// "Check with the AI" = the company scoring (v12, see companyScoring.ts):
//  1. The web site of the company: the one we have, or - when there is none - found with a web search (Google, LinkedIn, Facebook).
//     A company nobody can find on the web gets 0: it probably does not exist.
//  2. The AI reads the text of the web site and writes down facts, each with a quote. It does not give a score.
//  3. Code checks the quotes and works out the Purchase Score (Tier) and the Fit Score (Priority).
// A web site or e-mail that was missing and was found is written on the customer.

const GEMINI_URL = process.env.GEMINI_BASE_URL || 'https://generativelanguage.googleapis.com/v1beta/models';
const MODEL = 'gemini-3.6-flash';

// what the clean-up page and the lists read (the shape of the earlier AI check, kept)
export type Verdict = 'fit' | 'none' | 'unrelated' | 'unsuitable';
export interface CompanyCheck {
  found: boolean;
  verdict: Verdict;
  website: string | null;
  email: string | null;
  linkedin: string | null;
  facebook: string | null;
  business: string;
  size: string;
  fit: number;
  why: string;
  wasNoContact: boolean;
  checkedAt: string;
}

export function parseCheck(json: string | null | undefined): CompanyCheck | null {
  try { return json ? (JSON.parse(json) as CompanyCheck) : null; } catch { return null; }
}
export function parseScore(json: string | null | undefined): ScoreResult | null {
  try { return json ? (JSON.parse(json) as ScoreResult) : null; } catch { return null; }
}

export const aiAvailable = () => !!env.geminiApiKey;

async function gemini(prompt: string, opts: { search?: boolean; schema?: unknown }): Promise<string | null> {
  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      const res = await fetch(`${GEMINI_URL}/${MODEL}:generateContent`, {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-goog-api-key': env.geminiApiKey },
        body: JSON.stringify({
          contents: [{ role: 'user', parts: [{ text: prompt }] }],
          ...(opts.search ? { tools: [{ google_search: {} }] } : {}),
          generationConfig: { temperature: 0, ...(opts.schema ? { responseMimeType: 'application/json', responseSchema: opts.schema } : {}) },
        }),
        signal: AbortSignal.timeout(90000),
      });
      if (!res.ok) {
        if (res.status === 429 || res.status >= 500) { await new Promise((r) => setTimeout(r, 2500 * (attempt + 1))); continue; }
        return null;
      }
      const data = (await res.json()) as { candidates?: { content?: { parts?: { text?: string; thought?: boolean }[] } }[] };
      return (data.candidates?.[0]?.content?.parts ?? []).filter((p) => !p.thought && p.text).map((p) => p.text).join('\n');
    } catch {
      await new Promise((r) => setTimeout(r, 1500));
    }
  }
  return null;
}

// ---- 1. finding the company on the web ----------------------------------------------------------------------------------
const none = (v: string): string | null => {
  const s = v.replace(/^<|>$/g, '').trim().split(/\s+/)[0] ?? '';
  return s && !/^(none|n\/a|unknown|-)$/i.test(s) ? s.replace(/[)\].,;>"']+$/, '') : null;
};

interface WebTrace { found: boolean; website: string | null; email: string | null; linkedin: string | null; facebook: string | null }

async function searchWeb(card: CardRow): Promise<WebTrace | null> {
  const known = [
    `Company: ${card.company || card.name}`,
    card.market === 'domestic' ? `Country: Turkey${card.city ? `, ${card.city}` : ''}` : card.country ? `Country: ${card.country}` : '',
    card.email ? `E-mail: ${card.email}` : '',
    card.work_area ? `Work area (our note): ${card.work_area}` : '',
  ].filter(Boolean).join('\n');
  const text = await gemini(
    `Search the web (at most 2 searches) to find this company:\n\n${known}\n\nAnswer with exactly these lines and nothing else:\nFOUND: <YES if you found a real trace of this exact company on the web (its own web site, a LinkedIn or Facebook page, a trade register entry), NO if you found nothing>\nWEBSITE: <the company's own web site, or NONE>\nEMAIL: <a contact e-mail address of the company that you read on its web site or pages, or NONE. Never guess one>\nLINKEDIN: <the company's LinkedIn page, or NONE>\nFACEBOOK: <the company's Facebook page, or NONE>\nIf you are not sure it is the same company, answer FOUND: NO.`,
    { search: true }
  );
  if (!text) return null;
  const line = (key: string) => new RegExp(String.raw`^\s*${key}:\s*(.+)$`, 'im').exec(text)?.[1].trim() ?? '';
  const site = none(line('WEBSITE'));
  const email = none(line('EMAIL'));
  return {
    found: /^yes/i.test(line('FOUND')),
    website: site && /\.[a-z]{2,}/i.test(site) ? site : null,
    email: email && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ? email.toLowerCase() : null,
    linkedin: none(line('LINKEDIN')),
    facebook: none(line('FACEBOOK')),
  };
}

// ---- 2. the text of the web site -----------------------------------------------------------------------------------------
const decode = (s: string) => s.replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#0?39;|&apos;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&#(\d+);/g, (_m, n) => String.fromCharCode(Number(n)));
export const htmlToText = (html: string): string =>
  decode(html.replace(/<(script|style|noscript|svg)[\s\S]*?<\/\1>/gi, ' ').replace(/<!--[\s\S]*?-->/g, ' ').replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim();

const PAGES = /about|hakkimizda|hakkımızda|kurumsal|company|urun|ürün|product|production|uretim|üretim|service|hizmet|catalog|katalog|brand|marka|reference|referans|machine|makine|kariyer|career|jobs/i;

export async function siteText(url: string): Promise<{ text: string; finalUrl: string } | null> {
  const start = /^https?:\/\//i.test(url) ? url : `https://${url}`;
  try {
    const first = await fetchHtml(start);
    const parts = [htmlToText(first.html)];
    // a few inner pages that say what the company does
    const base = new URL(first.finalUrl);
    const links = new Set<string>();
    for (const m of first.html.matchAll(/<a\s[^>]*href=["']([^"'#]+)["']/gi)) {
      try {
        const u = new URL(m[1], base);
        if (u.host === base.host && u.pathname !== '/' && u.pathname !== base.pathname && PAGES.test(u.pathname + u.search) && !/\.(pdf|jpe?g|png|zip)$/i.test(u.pathname)) links.add(u.toString());
      } catch { /* not a link */ }
      if (links.size >= 2) break;
    }
    for (const l of links) {
      try { parts.push(htmlToText((await fetchHtml(l)).html)); } catch { /* that page did not open */ }
    }
    return { text: parts.join('\n\n').slice(0, 9000), finalUrl: first.finalUrl };
  } catch {
    return null;
  }
}

// ---- 3. the facts ----------------------------------------------------------------------------------------------------------
const FACT_SCHEMA = {
  type: 'ARRAY',
  items: { type: 'OBJECT', properties: { key: { type: 'STRING', enum: Object.keys(FACT_KEYS) }, value: { type: 'STRING' }, quote: { type: 'STRING' } }, required: ['key', 'value', 'quote'] },
};

async function extractFacts(card: CardRow, text: string): Promise<Fact[] | null> {
  const prompt = `You read the text of a company's web site and write down facts about it for TECE, a Turkish maker of edgebanding for furniture panels. You do NOT give scores or opinions.
Company: ${card.company || card.name}${card.country ? ` (${card.country})` : ''}

Rules:
- Every fact needs a "quote": a short piece (at most 200 characters) copied EXACTLY, word for word, from the text below. Never translate, shorten the words or invent a quote. A fact without an exact quote must not be written at all.
- Write only what the text states. Do not guess from the company name. If the text does not say it, leave the fact out.
- Contact data rules: take an e-mail only if it is written on the page, never guess one from the name or the domain (a role address such as info@ or sales@ is fine). Take a person (name and title) only if the page names them. A number is a mobile or WhatsApp number only when the page says so. If the page is blocked, needs a log-in or shows a CAPTCHA, write nothing from it.
- Buying signals count when quoted: edgebanding machine or CNC, edgebanding operator job, growth, fair attendance, dealer of a competitor brand. A company that is closed (site gone, 'permanently closed') is out of business.
- "value" is "true" for a yes-fact, a number for a number-fact, a comma separated list for a list-fact, or the word asked for.
The facts you may write (key: meaning):
${Object.entries(FACT_KEYS).map(([k, m]) => `- ${k}: ${m}`).join('\n')}

Answer with a JSON array of {key, value, quote}. An empty array if the text says nothing useful.

TEXT:
${text}`;
  const out = await gemini(prompt, { schema: FACT_SCHEMA });
  if (out === null) return null;
  try {
    const list = JSON.parse(out);
    return Array.isArray(list) ? (list as Fact[]) : [];
  } catch {
    return null;
  }
}

// ---- the rating by the written prompt (Admin > AI usage; the starting text is leadPrompt.ts) -------------------------------------
export const ratingPrompt = (): string => settingsModel.get('ai_rating_prompt')?.trim() || DEFAULT_RATING_PROMPT;
export const setRatingPrompt = (text: string): void => settingsModel.set('ai_rating_prompt', text.trim() === DEFAULT_RATING_PROMPT.trim() ? '' : text.trim().slice(0, 20000));

const RATING_SCHEMA = {
  type: 'OBJECT',
  properties: {
    not_scored_reason: { type: 'STRING' }, company: { type: 'STRING' }, country: { type: 'STRING' }, city: { type: 'STRING' }, activity: { type: 'STRING' },
    segment: { type: 'STRING' }, score: { type: 'INTEGER' }, reasons_for: { type: 'ARRAY', items: { type: 'STRING' } }, reasons_against: { type: 'ARRAY', items: { type: 'STRING' } },
    story: { type: 'STRING' }, confidence: { type: 'STRING' }, manufacturing_status: { type: 'STRING' }, manufacturing_reason: { type: 'STRING' },
    findings: { type: 'ARRAY', items: { type: 'OBJECT', properties: { topic: { type: 'STRING' }, value: { type: 'STRING' }, quote: { type: 'STRING' } }, required: ['topic', 'value', 'quote'] } },
    phone: { type: 'STRING' }, fax: { type: 'STRING' }, email: { type: 'STRING' }, address: { type: 'STRING' }, decision_maker: { type: 'STRING' }, decision_title: { type: 'STRING' }, whatsapp: { type: 'STRING' }, founded_year: { type: 'STRING' }, registry_no: { type: 'STRING' },
  },
  required: ['score', 'segment', 'confidence', 'findings'],
};

// The AI follows the prompt and gives the score (0-10) itself. The code still checks the quotes: a finding whose quote is not in the text is dropped.
async function scoreByPrompt(card: CardRow, website: string, text: string): Promise<ScoreResult | null> {
  const prompt = [
    ratingPrompt(),
    'Answer as JSON: not_scored_reason (empty unless not readable), company, country, city, activity (1 sentence), segment, score (0-10), reasons_for[] and reasons_against[] (max 3 short items each), confidence (High/Medium/Low), manufacturing_status, manufacturing_reason, findings[{topic, value, quote}] (max 6), phone, fax, email, address, decision_maker, decision_title, whatsapp, founded_year, registry_no, story. "Not stated" where the text does not say it. story: three short sentences, like the opening of a little tale about this company: who they are, what they make or sell, and the part TECE edgebanding could play for them. Light and a little witty, but ONLY from facts in the text: no invented names, numbers or events. English.',
    `Website: ${website}`,
    `TEXT OF THE WEBSITE (up to 5 pages):\n${text}`,
  ].join('\n\n');
  const out = await gemini(prompt, { schema: RATING_SCHEMA });
  if (out === null) return null;
  let j: Record<string, unknown>;
  try { j = JSON.parse(out) as Record<string, unknown>; } catch { return null; }
  const str = (v: unknown) => String(v ?? '').trim();
  const stated = (v: unknown) => { const s = str(v); return s && !/^not stated\.?$/i.test(s) ? s : ''; };
  const reason = str(j.not_scored_reason);
  if (reason || /^NOT SCORED/i.test(str(j.activity))) {
    const r = scoreFromText(card, null, '', []);
    r.website = website;
    r.notes.push(`NOT SCORED: ${reason || str(j.activity).replace(/^NOT SCORED:?\s*/i, '')}`);
    return r;
  }
  const hay = normText(text);
  const digits = text.replace(/\D/g, '');
  const findings = (Array.isArray(j.findings) ? j.findings : []) as { topic?: string; value?: string; quote?: string }[];
  // the quote is the sentence in its own language, then the English translation in brackets: the first part must be in the text
  const checked = findings
    .map((f) => ({ key: str(f.topic), value: str(f.value), quote: str(f.quote) }))
    .filter((f) => f.key && f.quote && hay.includes(normText(f.quote.replace(/\s*[\[(][^\])]*[\])]\s*$/, '')) || '\u0000'))
    .map((f) => ({ ...f, verified: true }));
  const facts: ScoreResult['facts'] = [...checked];
  for (const [key, v] of [['c_country', stated(j.country)], ['c_city', stated(j.city)]] as const) if (v) facts.push({ key, value: v, quote: v, verified: true });
  const email = stated(j.email);
  if (email && text.toLowerCase().includes(email.toLowerCase())) facts.push({ key: 'c_email', value: email, quote: email, verified: true });
  // the address and the fax number are taken only when they are written on the site
  const address = stated(j.address);
  if (address && hay.includes(normText(address).slice(0, 18))) facts.push({ key: 'c_address', value: address, quote: address, verified: true });
  const fax = stated(j.fax);
  if (fax && fax.replace(/\D/g, '').length >= 7 && digits.includes(fax.replace(/\D/g, ''))) facts.push({ key: 'c_fax', value: fax, quote: fax, verified: true });
  const phone = stated(j.phone);
  if (phone && phone.replace(/\D/g, '').length >= 7 && digits.includes(phone.replace(/\D/g, ''))) facts.push({ key: 'c_phone', value: phone, quote: phone, verified: true });

  // the person, the WhatsApp number, the year and the registry number: kept only when they are really written on the site
  const dm = stated(j.decision_maker);
  if (dm && hay.includes(normText(dm))) { facts.push({ key: 'c_decision_maker', value: dm, quote: dm, verified: true }); const dt = stated(j.decision_title); if (dt && hay.includes(normText(dt))) facts.push({ key: 'c_decision_title', value: dt, quote: dt, verified: true }); }
  const wa = stated(j.whatsapp);
  if (wa && wa.replace(/D/g, '').length >= 7 && digits.includes(wa.replace(/D/g, ''))) facts.push({ key: 'c_whatsapp', value: wa, quote: wa, verified: true });
  const fy = stated(j.founded_year);
  if (/^(19|20)dd$/.test(fy) && text.includes(fy)) facts.push({ key: 'c_founded', value: fy, quote: fy, verified: true });
  const rn = stated(j.registry_no);
  if (rn && rn.length >= 5 && hay.includes(normText(rn))) facts.push({ key: 'c_registry_no', value: rn, quote: rn, verified: true });

  const score = Math.max(0, Math.min(10, Math.round(Number(j.score) || 0)));
  const manu = str(j.manufacturing_status);
  const tier = score === 0 ? 'Disqualified' : score >= 8 ? 'Hot' : score >= 5 ? 'Warm' : 'Cold';
  const r = scoreFromText(card, website, text, []);
  r.method = 'prompt';
  r.status = 'scored';
  r.story = stated(j.story).slice(0, 700) || undefined;
  r.purchase = { score: score * 10, tier, parts: { segment: 0, flow: 0, size: 0, special: 0 }, floor: null, caps: [] };
  r.fit = null;
  r.track = score === 0 ? 'disqualified' : 'sales';
  r.tags = [str(j.segment)].filter(Boolean);
  r.facts = facts;
  r.notes = [
    str(j.activity),
    ...((Array.isArray(j.reasons_for) ? j.reasons_for : []) as unknown[]).map((x) => `+ ${str(x)}`),
    ...((Array.isArray(j.reasons_against) ? j.reasons_against : []) as unknown[]).map((x) => `- ${str(x)}`),
    `Confidence: ${str(j.confidence) || '?'}`,
    `Manufacturing: ${manu || '?'}${str(j.manufacturing_reason) ? ` (${str(j.manufacturing_reason)})` : ''}`,
    stated(j.decision_maker) ? `Decision maker: ${stated(j.decision_maker)}` : '',
  ].filter(Boolean);
  return r;
}

// ---- the whole check ---------------------------------------------------------------------------------------------------------
function leadInfoOf(card: CardRow): { tradeSources: string[]; tradeValue: number | null; businessType: string | null } {
  try {
    const l = JSON.parse(card.lead_info ?? '{}') as { sources?: string[]; tradeValue?: number | null; businessType?: string | null };
    return { tradeSources: l.sources ?? [], tradeValue: l.tradeValue ?? null, businessType: l.businessType ?? null };
  } catch {
    return { tradeSources: [], tradeValue: null, businessType: null };
  }
}

// Scores a company from the text of its web site (used by the check, and by the tests).
export function scoreFromText(card: CardRow, website: string | null, text: string, facts: Fact[]): ScoreResult {
  const { checked, inferred } = checkFacts(facts, text);
  const info = leadInfoOf(card);
  return computeScore({
    checked, inferred, words: text.split(/\s+/).filter(Boolean).length, website, country: card.country, stage: card.stage, ...info,
    dealerInCountry: card.market !== 'domestic' && !!distributorModel.forCard(card),
  });
}

// Rated already = the web site was read before (a score, or an older check from before the scoring system). A candidate without a web site and a
// quick check ("does it exist") do not count: they are still waiting for the real reading.
export const isScored = (card: Pick<CardRow, 'company_score' | 'company_check'>): boolean => {
  const s = parseScore(card.company_score);
  if (s && s.status !== 'no_website') return true;
  const c = parseCheck(card.company_check) as (CompanyCheck & { quick?: boolean }) | null;
  return !!c && !c.quick;
};

// the leads the full reading may take: not read before (SQL form of the above)
export const SQL_UNREAD = "(COALESCE(json_extract(company_score, '$.status'), '') IN ('', 'no_website') AND (company_check IS NULL OR (json_extract(company_check, '$.quick') = 1 AND json_extract(company_check, '$.verdict') = 'fit')))";

// Checks one customer. A company that is rated already is NOT read again (that costs tokens): its earlier check is returned, unless `force`.
// Returns what was found, or null when the AI could not be reached.
// (the tokens it uses are booked on this customer, and what it found is written in the customer's history)
export function checkCompany(cardId: number, force = false): Promise<CompanyCheck | null> {
  return runForCard(cardId, () => checkCompanyOf(cardId, force));
}

async function checkCompanyOf(cardId: number, force: boolean): Promise<CompanyCheck | null> {
  const card = cardModel.findById(cardId);
  if (!card || !env.geminiApiKey || !(card.company || card.name)) return null;
  if (!force && isScored(card)) return parseCheck(card.company_check);

  let website = (card.website ?? '').trim() || null;
  let trace: WebTrace | null = null;
  // a web site we already have is read; otherwise the company is searched for
  if (!website) {
    trace = await searchWeb(card);
    if (!trace) return null;
    website = trace.website;
  }

  let score: ScoreResult;
  const nothingFound = !website && !(trace?.found);
  if (website) {
    const page = await siteText(website);
    if (page) {
      // one scoring method: the written prompt (Admin > AI usage)
      const byPrompt = await scoreByPrompt(card, website, page.text);
      if (!byPrompt) return null;
      score = byPrompt;
    } else {
      // the web site did not open: there is nothing to quote
      score = scoreFromText(card, null, '', []);
      score.website = website;
      score.notes.push('The web site could not be opened.');
    }
  } else {
    score = scoreFromText(card, null, '', []);
    if (nothingFound) score.notes.push('Nothing about this company was found on the web.');
  }

  const rate = nothingFound ? 0 : rateOf(score);
  const verdict = nothingFound ? 'none' : verdictOf(score);
  const tag = score.purchase ? `${score.purchase.tier}${score.fit?.priority ? ` · ${score.fit.priority}` : ''} · ${score.purchase.score}/100` : nothingFound ? 'Nothing found on the web' : 'Candidate to verify by phone';
  const wasNoContact = !(card.website ?? '').trim() && !(card.email ?? '').trim();
  const emp = score.facts.find((f) => f.key === 'employees' && f.verified);
  const check: CompanyCheck = {
    found: !nothingFound, verdict, website, email: trace?.email ?? null, linkedin: trace?.linkedin ?? null, facebook: trace?.facebook ?? null,
    business: score.facts.find((f) => f.key === 'segment' && f.verified)?.value?.toString().replace('_', ' ') ?? '', size: emp ? `${emp.value} employees` : '', fit: rate, why: tag, wasNoContact, checkedAt: new Date().toISOString(),
  };
  db.prepare('UPDATE cards SET company_score = ?, company_check = ? WHERE id = ?').run(JSON.stringify(score), JSON.stringify(check), cardId);
  cardModel.setAiRate(cardId, rate, tag, 'ai', { log: false });
  logAi(
    cardId,
    `AI company check: ${tag}${website ? ` · web site ${website}` : nothingFound ? '' : ' · no web site found'}${check.email && !(card.email ?? '').trim() ? ` · e-mail ${check.email} added` : ''} · rating ${rate}/10`
  );
  // what was missing is filled in; what was there stays as it is
  if (website && !(card.website ?? '').trim()) db.prepare("UPDATE cards SET website = ?, website_check = 'found' WHERE id = ?").run(website, cardId);
  if (check.email && !(card.email ?? '').trim()) db.prepare('UPDATE cards SET email = ? WHERE id = ?').run(check.email, cardId);
  if (verdict === 'fit' && (website || check.email)) db.prepare("UPDATE cards SET contact_group = 'reachable' WHERE id = ? AND contact_group = 'no_contact'").run(cardId);
  fillMissing(card, score);
  const brandFacts = score.facts.filter((f) => /competitor_brands|edgeband brands/i.test(f.key) && f.verified).map((f) => String(f.value));
  if (brandFacts.length) addSiteSuppliers(cardId, brandFacts.join(',').split(/[,;|]/).map((x) => x.trim()).filter(Boolean));
  return check;
}

// What the web site says about the company fills in what is missing on the customer (country, city, address, e-mail, phone) - never over what is there.
function fillMissing(card: CardRow, score: ScoreResult): void {
  const v = (k: string) => String(score.facts.find((f) => f.key === k && f.verified)?.value ?? '').trim();
  const sets: string[] = [];
  const args: (string | null)[] = [];
  const empty = (x: string | null) => !(x ?? '').trim();
  const country = v('c_country');
  if (country && empty(card.country)) {
    const c = canonicalCountry(country) as string;
    if (COUNTRY_NAMES.includes(c)) { sets.push('country = ?'); args.push(c); }
  }
  const city = v('c_city');
  if (city && empty(card.city) && card.market === 'domestic') { const r = resolveCity(city); if (r.city) { sets.push('city = ?'); args.push(r.city); } }
  const address = v('c_address');
  if (address && empty(card.address)) { sets.push('address = ?'); args.push(address.slice(0, 300)); }
  const email = v('c_email').toLowerCase();
  if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && empty(card.email)) { sets.push('email = ?'); args.push(email); }
  const phone = v('c_phone');
  if (phone) {
    const place = (sets.includes('country = ?') ? (canonicalCountry(country) as string) : card.country) ?? null;
    for (const n of splitNumbers(phone)) {
      const a = analysePhone(n, place);
      if (!a.e164) continue;
      if (a.kind === 'mobile' && empty(card.mobile) && !sets.includes('mobile = ?')) { sets.push('mobile = ?'); args.push(a.e164); }
      else if (a.kind !== 'mobile' && empty(card.tel) && !sets.includes('tel = ?')) { sets.push('tel = ?'); args.push(a.e164); }
    }
  }
  const dmName = v('c_decision_maker');
  if (dmName && empty(card.name)) { sets.push('name = ?'); args.push(dmName.slice(0, 120)); const dt = v('c_decision_title'); if (dt && empty(card.position)) { sets.push('position = ?'); args.push(dt.slice(0, 120)); } }
  const wa = v('c_whatsapp');
  if (wa && empty(card.mobile) && !sets.includes('mobile = ?')) { const a = analysePhone(splitNumbers(wa)[0] ?? wa, (sets.includes('country = ?') ? (canonicalCountry(country) as string) : card.country) ?? null); if (a.e164) { sets.push('mobile = ?'); args.push(a.e164); } }
  const fax = v('c_fax');
  if (fax && empty(card.fax)) { sets.push('fax = ?'); args.push(fax.slice(0, 60)); }
  if (sets.length) db.prepare(`UPDATE cards SET ${sets.join(', ')} WHERE id = ?`).run(...args, card.id);
}

// ---- the quick check: many companies per AI question, no web sites read ---------------------------------------------------------
// Much cheaper than the full scoring (25 companies in one question): only "does it exist" and "could it be a customer". For clean-up.
async function quickBatch(cards: CardRow[]): Promise<number> {
  const list = cards.map((c) => `${c.id} | ${c.company} | ${c.market === 'domestic' ? 'Turkey' : c.country ?? ''}`).join('\n');
  const text = await gemini(
    `TECE makes edgebanding for furniture panels. Use web searches to check each of these companies (id | name | country). For every one answer with one line only, in this form:\nid | FOUND=YES or NO | RELEVANT=YES, NO or UNSURE\nFOUND=YES only when you find a real trace of that exact company on the web. RELEVANT=YES when it could buy edgebanding (a furniture, kitchen, door or panel maker, a workshop, a board or edgebanding distributor); NO for a supplier, a competitor, a private person or an unrelated trade. If you are not sure, FOUND=NO.\n\n${list}`,
    { search: true }
  );
  if (!text) return 0;
  let done = 0;
  const upd = db.prepare('UPDATE cards SET company_check = ? WHERE id = ?');
  for (const c of cards) {
    const m = new RegExp(String.raw`(?:^|\n)\s*${c.id}\s*\|\s*FOUND\s*=\s*(YES|NO)\s*\|\s*RELEVANT\s*=\s*(YES|NO|UNSURE)`, 'i').exec(text);
    if (!m) continue;
    const found = /yes/i.test(m[1]);
    const rel = m[2].toUpperCase();
    const verdict: Verdict = !found ? 'none' : rel === 'NO' ? 'unrelated' : 'fit';
    const check: CompanyCheck = {
      found, verdict, website: null, email: null, linkedin: null, facebook: null, business: '', size: '', fit: found ? 3 : 0,
      why: !found ? 'Quick check: nothing found on the web' : rel === 'NO' ? 'Quick check: not a customer for us' : 'Quick check: looks real', wasNoContact: !(c.website ?? '').trim() && !(c.email ?? '').trim(), checkedAt: new Date().toISOString(),
    };
    upd.run(JSON.stringify({ ...check, quick: true }), c.id);
    if (!found || rel === 'NO') cardModel.setAiRate(c.id, 0, check.why, 'ai');
    else logAi(c.id, 'AI quick check: looks real - the company exists and could buy edgebanding');
    done += 1;
  }
  return done;
}

export function startQuickChecks(ids: number[]): CheckJob {
  if (job.running) return checkStatus();
  const batches: number[][] = [];
  for (let i = 0; i < ids.length; i += 25) batches.push(ids.slice(i, i + 25));
  job = { running: !!env.geminiApiKey && ids.length > 0, total: ids.length, done: 0, ok: 0, hasKey: !!env.geminiApiKey };
  if (!job.running) return checkStatus();
  const worker = async () => {
    while (batches.length) {
      const b = batches.shift()!;
      try {
        job.ok += await quickBatch(b.map((id) => cardModel.findById(id)).filter((c): c is CardRow => !!c && !!(c.company ?? '').trim()));
      } catch (err) {
        console.error('Quick check failed', err);
      }
      job.done += b.length;
    }
  };
  void Promise.all([worker(), worker(), worker()]).finally(() => { job.running = false; });
  return checkStatus();
}

// ---- the daily limit of the big runs (admin) ------------------------------------------------------------------------------------
export const bulkLimit = (): number => { const n = parseInt(settingsModel.get('bulk_ai_limit') ?? '', 10); return Number.isFinite(n) && n >= 0 ? Math.min(n, 5000) : 300; };
export const setBulkLimit = (n: number): number => { const v = Math.max(0, Math.min(5000, Math.round(n))); settingsModel.set('bulk_ai_limit', String(v)); return v; };
const dayKey = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });
export function bulkLeftToday(): number {
  const used = settingsModel.get('bulk_ai_day') === dayKey() ? parseInt(settingsModel.get('bulk_ai_n') ?? '0', 10) || 0 : 0;
  return Math.max(0, bulkLimit() - used);
}
export function spendBulk(n: number): void {
  const day = dayKey();
  const used = settingsModel.get('bulk_ai_day') === day ? parseInt(settingsModel.get('bulk_ai_n') ?? '0', 10) || 0 : 0;
  settingsModel.set('bulk_ai_day', day);
  settingsModel.set('bulk_ai_n', String(used + n));
}

// Companies without a web site cannot be scored (nothing to quote): they become "candidates to verify" at once, at no cost.
export function markCandidates(): number {
  const rows = db.prepare("SELECT * FROM cards WHERE company_score IS NULL AND TRIM(COALESCE(website, '')) = ''").all() as unknown as CardRow[];
  const upd = db.prepare('UPDATE cards SET company_score = ? WHERE id = ?');
  db.exec('BEGIN');
  try {
    for (const c of rows) {
      const s = scoreFromText(c, null, '', []);
      if (c.stage === 'customer') s.track = 'existing';
      upd.run(JSON.stringify(s), c.id);
    }
    db.exec('COMMIT');
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
  return rows.length;
}

// ---- many at once, in the background ---------------------------------------------------------------------------

export interface CheckJob { running: boolean; total: number; done: number; ok: number; hasKey: boolean }
let job: CheckJob = { running: false, total: 0, done: 0, ok: 0, hasKey: !!env.geminiApiKey };
export const checkStatus = (): CheckJob => ({ ...job, hasKey: !!env.geminiApiKey });

export function startChecks(ids: number[]): CheckJob {
  if (job.running) return checkStatus();
  // what is rated already is not read again
  const queue = ids.filter((id) => { const c = cardModel.findById(id); return !!c && !isScored(c); });
  job = { running: !!env.geminiApiKey && queue.length > 0, total: queue.length, done: 0, ok: 0, hasKey: !!env.geminiApiKey };
  if (!job.running) return checkStatus();
  const worker = async () => {
    while (queue.length) {
      const id = queue.shift()!;
      try {
        if (await checkCompany(id)) job.ok += 1;
      } catch (err) {
        console.error('Company check failed for', id, err);
      }
      job.done += 1;
    }
  };
  void Promise.all([worker(), worker(), worker()]).finally(() => { job.running = false; });
  return checkStatus();
}
