-- Verification of the transport firms' e-mail addresses: one e-mail to every address (with the short video that shows how to answer a request), and a record of who
-- confirmed (a click on the link, a reply to the e-mail, or a person marking it after a phone call). Nothing here is ever deleted.
CREATE TABLE IF NOT EXISTS ship_verifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  batch TEXT NOT NULL,
  forwarder_id INTEGER NOT NULL,
  email TEXT NOT NULL,
  token TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL DEFAULT 'pending',      -- pending | sent | failed | confirmed
  error TEXT,
  message_id INTEGER,
  sent_at TEXT,
  confirmed_at TEXT,
  confirmed_via TEXT,                           -- link | reply | manual
  reply_from TEXT,                              -- the address the reply came from, when it is not the one we wrote to
  user_id INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_ship_verif_fw ON ship_verifications (forwarder_id, email);
