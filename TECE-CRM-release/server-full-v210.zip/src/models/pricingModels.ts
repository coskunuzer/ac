import { db } from '../db/connection';

export interface PriceListRow {
  id: number;
  original_name: string;
  stored_name: string;
  uploaded_by: number | null;
  uploaded_at: string;
  is_active: number;
  summary: string;
  // 'export' or 'domestic': each market has its own live list
  market: string;
}

export const priceListModel = {
  create(input: { originalName: string; storedName: string; uploadedBy: number; summary: unknown; market?: string }): PriceListRow {
    const market = input.market === 'domestic' ? 'domestic' : 'export';
    // Only one list per market is live at a time; older ones are kept for the offer log.
    db.prepare('UPDATE price_lists SET is_active = 0 WHERE is_active = 1 AND market = ?').run(market);
    const result = db
      .prepare(
        'INSERT INTO price_lists (original_name, stored_name, uploaded_by, is_active, summary, market) VALUES (?, ?, ?, 1, ?, ?)'
      )
      .run(input.originalName, input.storedName, input.uploadedBy, JSON.stringify(input.summary), market);
    return this.findById(result.lastInsertRowid as number)!;
  },

  findById(id: number): PriceListRow | undefined {
    return db.prepare('SELECT * FROM price_lists WHERE id = ?').get(id) as PriceListRow | undefined;
  },

  findActive(market = 'export'): PriceListRow | undefined {
    return db.prepare('SELECT * FROM price_lists WHERE is_active = 1 AND market = ? ORDER BY id DESC LIMIT 1').get(market === 'domestic' ? 'domestic' : 'export') as
      | PriceListRow
      | undefined;
  },

  listRecent(limit = 8, market = 'export'): PriceListRow[] {
    return db.prepare('SELECT * FROM price_lists WHERE market = ? ORDER BY id DESC LIMIT ?').all(market === 'domestic' ? 'domestic' : 'export', limit) as unknown as PriceListRow[];
  },
};

export type DocumentKind = 'catalog' | 'moq' | 'colors' | 'other';
export const DOCUMENT_KINDS: DocumentKind[] = ['catalog', 'moq', 'colors', 'other'];

export interface LibraryDocument {
  id: number;
  title: string;
  kind: DocumentKind;
  original_name: string;
  stored_name: string;
  mime_type: string;
  size_bytes: number;
  uploaded_by: number | null;
  created_at: string;
}

export const libraryModel = {
  create(input: {
    title: string;
    kind: DocumentKind;
    originalName: string;
    storedName: string;
    mimeType: string;
    sizeBytes: number;
    uploadedBy: number;
  }): LibraryDocument {
    const result = db
      .prepare(
        `INSERT INTO library_documents (title, kind, original_name, stored_name, mime_type, size_bytes, uploaded_by)
         VALUES (?, ?, ?, ?, ?, ?, ?)`
      )
      .run(input.title, input.kind, input.originalName, input.storedName, input.mimeType, input.sizeBytes, input.uploadedBy);
    return this.findById(result.lastInsertRowid as number)!;
  },

  findById(id: number): LibraryDocument | undefined {
    return db.prepare('SELECT * FROM library_documents WHERE id = ?').get(id) as LibraryDocument | undefined;
  },

  findMany(ids: number[]): LibraryDocument[] {
    if (!ids.length) return [];
    const marks = ids.map(() => '?').join(',');
    return db
      .prepare(`SELECT * FROM library_documents WHERE id IN (${marks}) ORDER BY id`)
      .all(...ids) as unknown as LibraryDocument[];
  },

  list(): LibraryDocument[] {
    return db
      .prepare("SELECT * FROM library_documents ORDER BY CASE kind WHEN 'catalog' THEN 0 WHEN 'moq' THEN 1 WHEN 'colors' THEN 2 ELSE 3 END, title")
      .all() as unknown as LibraryDocument[];
  },

  delete(id: number): void {
    db.prepare('DELETE FROM library_documents WHERE id = ?').run(id);
  },
};

// A readable snapshot of what was sent, written at send time so it still reads
// correctly after the price list or library change.
export interface OfferSummary {
  subject: string | null;
  sentTo: string | null;
  percent: number | null; // price increase / decrease as a fraction, -0.1 = -10 %
  currency: 'EUR' | 'USD' | null;
  usdRate: number | null;
  // percent: the price increase / decrease of this page (it can differ from the whole offer's)
  pages: { title: string; surcharge: number | null; products: string; percent?: number | null }[];
  widths?: number[];
  includeMoq: boolean;
  attachments: string[];
}

// What an email to the customer contained: a price offer, documents only, or
// just the thank-you note.
export type SendKind = 'offer' | 'documents' | 'thank_you' | 'personal';

export interface OfferEntry extends OfferSummary {
  id: number;
  cardId: number;
  kind: SendKind;
  sentAt: string; // UTC "YYYY-MM-DD HH:MM:SS"
  sentBy: string | null;
  priceList: string | null;
}

interface OfferLogRow {
  id: number;
  card_id: number;
  params: string;
  selections: string;
  summary: string | null;
  kind: SendKind;
  sent_at: string;
  sent_by: string | null;
  price_list: string | null;
}

function toEntry(row: OfferLogRow): OfferEntry {
  let summary: Partial<OfferSummary> = {};
  try {
    summary = row.summary ? JSON.parse(row.summary) : {};
  } catch {
    summary = {};
  }
  // Rows written before summaries existed: rebuild what we can from the raw log. The raw log (every page and price of the offer) is only read
  // when the summary lacks something - reading it for every offer of every customer was a large part of the time of the lists.
  const needRaw = summary.percent == null || summary.currency == null || summary.usdRate == null || summary.pages == null || summary.widths == null || summary.includeMoq == null;
  let params: Record<string, unknown> = {};
  let selections: { sheet: string }[] = [];
  if (needRaw) {
    try { params = JSON.parse(row.params) ?? {}; } catch { params = {}; }
    try { selections = JSON.parse(row.selections) ?? []; } catch { selections = []; }
  }
  const adjust = (params.adjust && typeof params.adjust === 'object' ? params.adjust : {}) as Record<string, number>;
  return {
    id: row.id,
    cardId: row.card_id,
    kind: row.kind,
    sentAt: row.sent_at,
    sentBy: row.sent_by,
    priceList: row.price_list,
    subject: summary.subject ?? null,
    sentTo: summary.sentTo ?? null,
    percent: summary.percent ?? (typeof params.transportPct === 'number' ? params.transportPct : null),
    currency: summary.currency ?? (params.currency === 'USD' ? 'USD' : params.currency === 'EUR' ? 'EUR' : null),
    usdRate: summary.usdRate ?? (typeof params.usdRate === 'number' ? params.usdRate : null),
    pages: summary.pages ?? selections.map((s) => ({ title: s.sheet, surcharge: typeof adjust[s.sheet] === 'number' ? adjust[s.sheet] : null, products: '' })),
    widths: summary.widths ?? (Array.isArray(params.widths) ? (params.widths as number[]) : undefined),
    includeMoq: summary.includeMoq ?? params.includeMoq === true,
    attachments: summary.attachments ?? [],
  };
}

const OFFER_SELECT = `SELECT o.id, o.card_id, o.params, o.selections, o.summary, o.kind, o.sent_at,
         u.display_name AS sent_by, p.original_name AS price_list
       FROM offers_sent o
       LEFT JOIN users u ON u.id = o.created_by
       LEFT JOIN price_lists p ON p.id = o.price_list_id`;

export const offerLogModel = {
  record(input: {
    cardId: number;
    priceListId: number | null;
    createdBy: number;
    params: unknown;
    selections: unknown;
    attachmentIds: number[];
    summary: OfferSummary;
    kind: SendKind;
  }): void {
    db.prepare(
      'INSERT INTO offers_sent (card_id, price_list_id, created_by, params, selections, attachment_ids, summary, kind) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    ).run(
      input.cardId,
      input.priceListId,
      input.createdBy,
      JSON.stringify(input.params),
      JSON.stringify(input.selections),
      JSON.stringify(input.attachmentIds),
      JSON.stringify(input.summary),
      input.kind
    );
  },

  // Newest first.
  listForCard(cardId: number): OfferEntry[] {
    return (db.prepare(`${OFFER_SELECT} WHERE o.card_id = ? ORDER BY o.id DESC`).all(cardId) as unknown as OfferLogRow[]).map(toEntry);
  },

  listAll(): OfferEntry[] {
    return (db.prepare(`${OFFER_SELECT} ORDER BY o.id DESC`).all() as unknown as OfferLogRow[]).map(toEntry);
  },

  // for one page of customers: the sends of just these
  listForCards(cardIds: number[]): OfferEntry[] {
    if (!cardIds.length) return [];
    const ids = cardIds.map((n) => Math.trunc(Number(n))).join(',');
    return (db.prepare(`${OFFER_SELECT} WHERE o.card_id IN (${ids}) ORDER BY o.id DESC`).all() as unknown as OfferLogRow[]).map(toEntry);
  },

  // the sends of a set of customers (newest first), without reading the sends of everybody else
  listForIdSet(cardIds: Set<number>): OfferEntry[] {
    if (!cardIds.size) return [];
    if (cardIds.size > 4000) return this.listAll().filter((o) => cardIds.has(o.cardId));
    return this.listForCards([...cardIds]);
  },

  // was an offer (not a thank-you, not documents) sent to this customer?
  offerSentTo(cardId: number): boolean {
    return !!db.prepare("SELECT 1 AS x FROM offers_sent WHERE card_id = ? AND kind = 'offer' LIMIT 1").get(cardId);
  },

  countForCard(cardId: number): number {
    const row = db.prepare('SELECT COUNT(*) AS n FROM offers_sent WHERE card_id = ?').get(cardId) as { n: number };
    return row.n;
  },
};
