import { db } from '../db/connection';
import { gameFor, gameSettings } from './gamify';
import { accountsFor } from './perfAnalytics';
import { visibilitySql, type Viewer } from './visibility';

// "Suggested focus today" for the mission board: every signal the CRM has (orders waiting for the advance, goods ready, payments late,
// customers slipping away, offers and samples nobody followed up, hot leads nobody touched, questions from quality, to-dos) is turned
// into one action with a reason, a number of points toward today's goal, and a link that opens the right place. The list is ordered by
// urgency, and the shortest way to the daily goal is marked.

const TOUCH = "('note', 'call', 'visit', 'meeting', 'sample', 'offer', 'thank_you', 'documents', 'email')";
const today = (): string => new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });
const daysSince = (iso: string | null | undefined, from = today()): number | null => {
  if (!iso) return null;
  const d = Date.parse(`${iso.slice(0, 10)}T00:00:00Z`);
  return Number.isFinite(d) ? Math.round((Date.parse(`${from}T00:00:00Z`) - d) / 86_400_000) : null;
};
const money = (n: number, cur: string) => `${Math.round(n).toLocaleString('en-GB')} ${cur}`;

export type FocusKind = 'complaint' | 'waiting' | 'ready' | 'overdue' | 'followup' | 'offer' | 'sample' | 'hot' | 'slipping' | 'todo';
export interface FocusItem {
  key: string;
  kind: FocusKind;
  /** the customer */
  title: string;
  /** why it is on the list, in one line (English: the page translates the pieces it knows) */
  reason: string;
  /** what to do */
  action: string;
  /** points the action earns (call + note, an offer, a visit ...) */
  points: number;
  score: number;
  cardId: number | null;
  to: string;
  /** the part of the reason that changes (an amount, a number of days) */
  vars?: Record<string, string | number>;
}

export interface FocusReport {
  goal: number;
  points: number;
  remaining: number;
  items: FocusItem[];
  /** how many of the first items together reach the goal (0 = the goal is reached already) */
  needed: number;
  /** every kind that has something waiting, with how many */
  counts: Record<string, number>;
}

export function focusFor(viewer: Viewer): FocusReport {
  const s = gameSettings();
  const w = (k: string, d: number) => s.weights[k] ?? d;
  const game = gameFor(viewer.id).today;
  const items: FocusItem[] = [];
  const t0 = today();

  // when each customer was last touched by anybody (a note, a call, a visit ...)
  const last = new Map<number, string>();
  for (const r of db.prepare(`SELECT card_id, MAX(created_at) AS at FROM activities WHERE card_id IS NOT NULL AND type IN ${TOUCH} GROUP BY card_id`).all() as { card_id: number; at: string }[]) last.set(r.card_id, r.at);
  const idle = (cardId: number | null): number | null => (cardId ? daysSince(last.get(cardId) ?? null) : null);

  // ---- customers that buy (SAP): orders, payments, silence -------------------------------------------------------------------------------
  const callPts = w('call', 2) + w('note', 1);
  for (const a of accountsFor(viewer)) {
    if (a.hidden) continue;
    const link = a.cardId ? `/cards/${a.cardId}/review` : '/performance';
    const open = a.backlogValue + a.waitingValue + a.readyValue > 0;
    const sinceInvoice = daysSince(a.lastInvoice);
    if (a.waitingValue > 0) {
      items.push({ key: `w${a.sap}`, kind: 'waiting', title: a.name, reason: 'An order is waiting for the advance or the confirmation: {amount}.', vars: { amount: money(a.waitingValue, a.currency) }, action: 'Call to get the advance or the confirmation', points: callPts, score: 78 + Math.min(14, Math.log10(1 + a.waitingValue) * 2.6), cardId: a.cardId, to: link });
    }
    if (a.readyValue > 0) {
      items.push({ key: `r${a.sap}`, kind: 'ready', title: a.name, reason: 'Goods are ready to dispatch: {amount}.', vars: { amount: money(a.readyValue, a.currency) }, action: 'Tell the customer and arrange the pick-up', points: callPts, score: 76 + Math.min(14, Math.log10(1 + a.readyValue) * 2.4), cardId: a.cardId, to: link });
    }
    if (a.overdue > 0.5 && a.oldestOver >= 15) {
      items.push({ key: `o${a.sap}`, kind: 'overdue', title: a.name, reason: 'Payment is late: {amount}, the oldest invoice {days} days over.', vars: { amount: money(a.overdue, a.currency), days: Math.round(a.oldestOver) }, action: 'Remind the customer of the payment', points: callPts, score: 62 + Math.min(14, a.oldestOver / 8) + Math.min(10, Math.log10(1 + a.overdue) * 2) + (a.hold ? 6 : 0) - (a.oldestOver > 365 ? 24 : 0), cardId: a.cardId, to: link });
    }
    // slipping: it bought before, nothing open, no invoice for 90+ days, and nobody has been in touch for 30 days
    const quiet = a.cardId ? idle(a.cardId) : null;
    if (!open && !a.inactive && sinceInvoice !== null && sinceInvoice > 90 && (quiet === null || quiet > 30) && a.bestYear > 0) {
      items.push({ key: `s${a.sap}`, kind: 'slipping', title: a.name, reason: 'No order for {days} days and nobody has been in touch for a month (best year {amount}).', vars: { days: sinceInvoice, amount: money(a.bestYear, a.currency) }, action: 'Call: find out why they stopped', points: callPts, score: 48 + Math.min(16, Math.log10(1 + a.bestYear) * 3) + Math.min(6, (sinceInvoice - 90) / 30), cardId: a.cardId, to: link });
    }
  }

  // ---- prospects: follow-up days, offers, samples, hot leads -------------------------------------------------------------------------------------
  const params: Record<string, string | number> = {};
  const vis = visibilitySql(viewer, params);
  const rows = db.prepare(`SELECT id, company, name, pipeline_stage, rate, ai_rate, ai_rate_source, follow_up_date FROM cards
      WHERE TRIM(COALESCE(sap, '')) = '' AND exit_status IS NULL AND status != 'needs_review'${vis ? ` AND ${vis}` : ''} AND (pipeline_stage IN (1, 2, 4, 5) OR pipeline_stage IS NULL OR follow_up_date IS NOT NULL) LIMIT 6000`).all(params) as {
    id: number; company: string | null; name: string | null; pipeline_stage: number | null; rate: number | null; ai_rate: number | null; ai_rate_source: string | null; follow_up_date: string | null }[];
  for (const c of rows) {
    const title = c.company || c.name || `#${c.id}`;
    const to = `/cards/${c.id}/review`;
    const rating = c.rate ?? (c.ai_rate_source === 'ai' ? c.ai_rate : null);
    const idleDays = idle(c.id);
    const stage = c.pipeline_stage ?? 1;
    if (c.follow_up_date && c.follow_up_date <= t0) {
      items.push({ key: `f${c.id}`, kind: 'followup', title, reason: 'The follow-up day you set ({date}) has come.', vars: { date: c.follow_up_date.split('-').reverse().join('.') }, action: 'Do the follow-up you planned', points: callPts, score: 84 + Math.min(8, daysSince(c.follow_up_date) ?? 0), cardId: c.id, to });
      continue;
    }
    if (stage === 5 && (idleDays === null || idleDays > 7)) {
      items.push({ key: `of${c.id}`, kind: 'offer', title, reason: 'The offer is out and nobody has followed it up for {days} days.', vars: { days: idleDays ?? 30 }, action: 'Ask what the customer thinks about the offer', points: callPts + 1, score: 74 + Math.min(10, (idleDays ?? 30) / 3), cardId: c.id, to });
    } else if (stage === 4 && (idleDays === null || idleDays > 5)) {
      items.push({ key: `sa${c.id}`, kind: 'sample', title, reason: 'Samples went out and there is no news for {days} days.', vars: { days: idleDays ?? 20 }, action: 'Ask if the colour matches and what comes next', points: callPts, score: 68 + Math.min(10, (idleDays ?? 20) / 3), cardId: c.id, to });
    } else if (stage === 1 && rating !== null && rating >= 7 && (idleDays === null || idleDays > 5)) {
      items.push({ key: `h${c.id}`, kind: 'hot', title, reason: idleDays === null ? 'A promising lead (rated {rating}/10) that nobody has contacted yet.' : 'A promising lead (rated {rating}/10) that nobody has contacted for {days} days.', vars: { rating, days: idleDays ?? 0 }, action: 'Make the first contact', points: callPts + 1, score: 60 + rating * 1.5, cardId: c.id, to });
    }
  }

  // ---- a question of quality waits for the salesperson ----------------------------------------------------------------------------------------
  for (const r of db.prepare("SELECT id, customer_name, complaint_no, info_request FROM complaints WHERE created_by = ? AND internal_status = 'Bilgi bekleniyor'").all(viewer.id) as { id: number; customer_name: string | null; complaint_no: string | null; info_request: string | null }[]) {
    items.push({ key: `c${r.id}`, kind: 'complaint', title: r.customer_name ?? 'Complaint', reason: 'Quality is waiting for your answer: {ask}', vars: { ask: (r.info_request ?? '').slice(0, 90) }, action: 'Answer quality', points: w('note', 1), score: 96, cardId: null, to: `/complaints/${r.id}` });
  }

  // ---- to-dos that are late or due today --------------------------------------------------------------------------------------------------------
  for (const r of db.prepare('SELECT t.id, t.card_id, t.text, t.due_date, c.company, c.name FROM todos t LEFT JOIN cards c ON c.id = t.card_id WHERE t.user_id = ? AND t.done_at IS NULL AND t.due_date <= ? ORDER BY t.due_date LIMIT 40').all(viewer.id, t0) as { id: number; card_id: number | null; text: string; due_date: string; company: string | null; name: string | null }[]) {
    const late = daysSince(r.due_date) ?? 0;
    items.push({ key: `t${r.id}`, kind: 'todo', title: r.company || r.name || r.text, reason: late > 0 ? 'Your to-do is {days} days late: {text}' : 'Your to-do is due today: {text}', vars: { days: late, text: r.text.slice(0, 80) }, action: 'Do it and tick it off', points: w('todo', 2), score: 78 + Math.min(14, late * 2), cardId: r.card_id, to: r.card_id ? `/cards/${r.card_id}/review` : '/calendar' });
  }

  // one line for each customer: the most urgent reason wins (the others are in the customer's page)
  items.sort((a, b) => b.score - a.score);
  const seen = new Set<string>();
  const unique = items.filter((i) => {
    const k = i.cardId ? `c${i.cardId}` : i.key;
    if (seen.has(k)) return false;
    seen.add(k);
    return true;
  });

  // variety first: the best of each kind, most urgent kind first, then the rest - so the top five is not five orders of the same sort
  const firsts: FocusItem[] = [];
  const seenKind = new Set<string>();
  for (const i of unique) if (!seenKind.has(i.kind)) { seenKind.add(i.kind); firsts.push(i); }
  const ordered = [...firsts, ...unique.filter((i) => !firsts.includes(i))];

  const remaining = Math.max(0, game.goal - game.points);
  let sum = 0;
  let needed = 0;
  if (remaining > 0) {
    for (const [i, it] of ordered.slice(0, 12).entries()) { sum += it.points; if (sum >= remaining) { needed = i + 1; break; } }
    if (!needed) needed = Math.min(ordered.length, 12);
  }
  const counts: Record<string, number> = {};
  for (const i of unique) counts[i.kind] = (counts[i.kind] ?? 0) + 1;
  return { goal: game.goal, points: game.points, remaining, items: ordered.slice(0, 12), needed, counts };
}
