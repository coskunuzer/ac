import { db } from '../db/connection';
import { settingsModel } from '../models/settingsModel';
import { familyOf } from './perfAnalytics';

// The account ledger of a customer, with every invoice paired to the payment(s) that settled it.
// The ledger has the invoice number in its text but a payment only says "incoming payment bank" with an amount, so the pairs are found by amount and order:
//   1. a payment of exactly an invoice            2. a payment a little short of an invoice (up to the bank-charge limit: the bank kept it)
//   3. one payment for several invoices, or several payments for one invoice   4. what is left: the oldest open invoice (assumed)
// A person can fix a pair by hand (a pin). Invoices nobody paid, and invoices paid short by more than the limit, are the exceptions (shown in red).
export interface Tx { id: number; date: string; description: string; debit: number | null; credit: number | null; balance: number | null; currency: string; sheet: string }
export type HowMatched = 'exact' | 'bank' | 'combined' | 'split' | 'assumed' | 'hand';
export type Status = 'paid' | 'bank' | 'short' | 'open' | 'payment' | 'advance';
export interface LedgerRow {
  id: number; date: string; description: string; kind: 'invoice' | 'payment'; amount: number;
  pair: number | null;            // the number shared by an invoice and its payment(s)
  how: HowMatched | null;
  status: Status;                 // invoice: paid | bank (paid, the bank kept a little) | short | open ; payment: payment (matched) | advance (not matched to an invoice)
  short: number;                  // invoice: what is still missing
  bankCharge: number;             // invoice: the little the bank kept
  withIds: number[];              // the other side of the pair
}
export interface LedgerResult {
  sap: string; currency: string; tolerance: number; from: string | null; openingBalance: number; balance: number;
  rows: LedgerRow[];
  summary: { invoices: number; paid: number; bank: number; short: number; open: number; shortTotal: number; openTotal: number; bankTotal: number; unmatchedPayments: number; unmatchedPaymentsTotal: number; pairs: number };
}

export const bankTolerance = (): number => { const n = parseFloat(settingsModel.get('ledger_bank_tolerance') ?? ''); return Number.isFinite(n) && n >= 0 ? Math.min(n, 5000) : 150; };
export const setBankTolerance = (n: number): number => { const v = Math.max(0, Math.min(5000, Math.round(n * 100) / 100)); settingsModel.set('ledger_bank_tolerance', String(v)); return v; };

const cents = (n: number | null) => Math.round((n ?? 0) * 100);
const DAY = 86_400_000;
const days = (a: string, b: string) => Math.round((Date.parse(b) - Date.parse(a)) / DAY);

interface Inv { tx: Tx; rem: number; amt: number }
interface Pay { tx: Tx; rem: number; amt: number }
interface Link { inv: Inv; pay: Pay; amt: number; how: HowMatched }

// the pure part: transactions in, pairs out (testable without the database)
export function matchTransactions(txs: Tx[], tolerance: number, pins: { invoice: number; payment: number }[] = []): { links: Link[]; inv: Inv[]; pay: Pay[] } {
  const tol = Math.round(tolerance * 100);
  const inv: Inv[] = txs.filter((t) => cents(t.debit) > 0).map((t) => ({ tx: t, rem: cents(t.debit), amt: cents(t.debit) }));
  const pay: Pay[] = txs.filter((t) => cents(t.credit) > 0).map((t) => ({ tx: t, rem: cents(t.credit), amt: cents(t.credit) }));
  const links: Link[] = [];
  const link = (i: Inv, p: Pay, amt: number, how: HowMatched) => { amt = Math.min(amt, i.rem, p.rem); if (amt <= 0) return; i.rem -= amt; p.rem -= amt; links.push({ inv: i, pay: p, amt, how }); };
  const byId = new Map<number, Inv>(inv.map((i) => [i.tx.id, i]));
  const byPay = new Map<number, Pay>(pay.map((p) => [p.tx.id, p]));
  // by hand first
  for (const pin of pins) { const i = byId.get(pin.invoice); const p = byPay.get(pin.payment); if (i && p) link(i, p, Math.min(i.rem, p.rem), 'hand'); }
  // an invoice settled with a little kept by the bank is closed: nothing else is put on it
  const closed = new Set<Inv>();
  const close = (i: Inv) => { if (i.rem <= tol) closed.add(i); };
  const open = () => inv.filter((i) => i.rem > 0 && !closed.has(i));
  // closest invoice in time (an invoice before the payment first, then one after it: an advance payment)
  const near = (p: Pay, list: Inv[]) => [...list].sort((a, b) => {
    const da = days(a.tx.date, p.tx.date); const db2 = days(b.tx.date, p.tx.date);
    const ra = da >= 0 ? da : 10_000 - da; const rb = db2 >= 0 ? db2 : 10_000 - db2;
    return ra - rb;
  });
  // 1. exact
  for (const p of pay) { if (p.rem <= 0) continue; const c = near(p, open().filter((i) => i.rem === p.rem))[0]; if (c) link(c, p, p.rem, 'exact'); }
  // 2. a little short: the bank kept it
  for (const p of pay) { if (p.rem <= 0) continue; const c = near(p, open().filter((i) => i.rem > p.rem && i.rem - p.rem <= tol))[0]; if (c) { link(c, p, p.rem, 'bank'); close(c); } }
  // 3. one payment for several invoices (up to 4), then several payments for one invoice (up to 3)
  for (const p of pay) {
    if (p.rem <= 0) continue;
    const cands = open().filter((i) => days(i.tx.date, p.tx.date) > -120).sort((a, b) => a.tx.date.localeCompare(b.tx.date));
    // the invoices together may be a little MORE than the payment (the bank kept a little)
    const set = ((): Inv[] | null => {
      const pool = cands.slice(0, 14); let hit: Inv[] | null = null;
      const go = (start: number, chosen: Inv[], sum: number) => {
        if (hit) return;
        if (chosen.length >= 2 && sum >= p.rem && sum - p.rem <= tol) { hit = [...chosen]; return; }
        if (chosen.length >= 4) return;
        for (let k = start; k < pool.length; k += 1) { if (sum + pool[k].rem > p.rem + tol) continue; go(k + 1, [...chosen, pool[k]], sum + pool[k].rem); }
      };
      go(0, [], 0);
      return hit;
    })();
    if (set) for (const i of set) { link(i, p, Math.min(i.rem, p.rem), 'combined'); close(i); }
  }
  for (const i of open()) {
    const ps = pay.filter((p) => p.rem > 0 && Math.abs(days(i.tx.date, p.tx.date)) < 400).sort((a, b) => a.tx.date.localeCompare(b.tx.date));
    const pool = ps.slice(0, 10); let hit: Pay[] | null = null;
    const go = (start: number, chosen: Pay[], sum: number) => {
      if (hit) return;
      if (chosen.length >= 2 && sum <= i.rem && i.rem - sum <= tol && sum > 0) { hit = [...chosen]; return; }
      if (chosen.length >= 3) return;
      for (let k = start; k < pool.length; k += 1) { if (sum + pool[k].rem > i.rem) continue; go(k + 1, [...chosen, pool[k]], sum + pool[k].rem); }
    };
    go(0, [], 0);
    if (hit) { for (const p of hit as Pay[]) link(i, p, p.rem, 'split'); close(i); }
  }
  // 4. what is left: a payment goes to the oldest open invoice that is not newer than it; an advance payment waits for the next invoice
  for (const p of pay) {
    if (p.rem <= 0) continue;
    for (const i of open().filter((x) => days(x.tx.date, p.tx.date) >= 0).sort((a, b) => a.tx.date.localeCompare(b.tx.date))) { if (p.rem <= 0) break; link(i, p, Math.min(i.rem, p.rem), 'assumed'); }
  }
  for (const p of pay) {
    if (p.rem <= 0) continue;
    for (const i of open().sort((a, b) => a.tx.date.localeCompare(b.tx.date))) { if (p.rem <= 0) break; link(i, p, Math.min(i.rem, p.rem), 'assumed'); }
  }
  return { links, inv, pay };
}

// the database part
export function sheetsOfSap(sap: string): string[] {
  const names = new Set<string>();
  for (const sp of familyOf(sap)) for (const r of db.prepare('SELECT sheet_name FROM customer_aliases WHERE sap_no = ?').all(sp) as { sheet_name: string }[]) names.add(r.sheet_name);
  return [...names];
}

export function ledgerFor(sap: string, from: string | null = null): LedgerResult | null {
  const sheets = sheetsOfSap(sap);
  if (!sheets.length) return null;
  const all = db.prepare(`SELECT id, sheet_name AS sheet, tx_date AS date, description, debit, credit, balance, currency FROM ledger_transactions WHERE sheet_name IN (${sheets.map(() => '?').join(',')}) ORDER BY tx_date, seq, id`).all(...sheets) as unknown as Tx[];
  if (!all.length) return null;
  const currency = all[0].currency;
  const txs = all.filter((t) => t.currency === currency);
  const tol = bankTolerance();
  const tolC = Math.round(tol * 100);
  const pins = db.prepare('SELECT invoice_tx AS invoice, payment_tx AS payment FROM ledger_pins WHERE sap = ?').all(sap) as { invoice: number; payment: number }[];
  const { links, inv, pay } = matchTransactions(txs, tol, pins);

  // the pair numbers: invoices and payments that belong together share one number (in the order of the oldest invoice)
  const parent = new Map<string, string>();
  const find = (k: string): string => { let r = k; while ((parent.get(r) ?? r) !== r) r = parent.get(r)!; parent.set(k, r); return r; };
  const union = (a: string, b: string) => { const x = find(a); const y = find(b); if (x !== y) parent.set(x, y); };
  for (const l of links) union(`i${l.inv.tx.id}`, `p${l.pay.tx.id}`);
  const groups = new Map<string, number>();
  const sorted = [...inv].filter((i) => links.some((l) => l.inv === i)).sort((a, b) => a.tx.date.localeCompare(b.tx.date) || a.tx.id - b.tx.id);
  let n = 0;
  for (const i of sorted) { const g = find(`i${i.tx.id}`); if (!groups.has(g)) groups.set(g, ++n); }
  for (const p of pay) { if (links.some((l) => l.pay === p)) { const g = find(`p${p.tx.id}`); if (!groups.has(g)) groups.set(g, ++n); } }

  const rows: LedgerRow[] = [];
  const invBy = new Map(inv.map((i) => [i.tx.id, i]));
  const payBy = new Map(pay.map((p) => [p.tx.id, p]));
  for (const t of txs) {
    const i = invBy.get(t.id); const p = payBy.get(t.id);
    if (i) {
      const mine = links.filter((l) => l.inv === i);
      const rem = i.rem;
      const status: Status = rem <= 0 ? (mine.length && mine.reduce((a, l) => a + l.amt, 0) < i.amt ? 'bank' : 'paid') : mine.length ? (rem <= tolC ? 'bank' : 'short') : 'open';
      const paid = mine.reduce((a, l) => a + l.amt, 0);
      rows.push({ id: t.id, date: t.date, description: t.description ?? '', kind: 'invoice', amount: i.amt / 100, pair: mine.length ? groups.get(find(`i${t.id}`)) ?? null : null, how: mine[0]?.how ?? null, status, short: status === 'short' || status === 'open' ? rem / 100 : 0, bankCharge: status === 'bank' ? (i.amt - paid) / 100 : 0, withIds: [...new Set(mine.map((l) => l.pay.tx.id))] });
    } else if (p) {
      const mine = links.filter((l) => l.pay === p);
      rows.push({ id: t.id, date: t.date, description: t.description ?? '', kind: 'payment', amount: p.amt / 100, pair: mine.length ? groups.get(find(`p${t.id}`)) ?? null : null, how: mine[0]?.how ?? null, status: p.rem > 1 ? 'advance' : 'payment', short: p.rem > 1 ? p.rem / 100 : 0, bankCharge: 0, withIds: [...new Set(mine.map((l) => l.inv.tx.id))] });
    }
  }
  // the period shown (the pairs were found on the whole history)
  const shown = from ? rows.filter((r) => r.date >= from) : rows;
  const before = from ? txs.filter((t) => t.date < from) : [];
  const openingBalance = Math.round(before.reduce((a, t) => a + cents(t.debit) - cents(t.credit), 0)) / 100;
  const inv2 = shown.filter((r) => r.kind === 'invoice');
  const sum = (f: (r: LedgerRow) => boolean, g: (r: LedgerRow) => number) => Math.round(inv2.filter(f).reduce((a, r) => a + g(r), 0) * 100) / 100;
  const unp = shown.filter((r) => r.kind === 'payment' && r.status === 'advance');
  return {
    sap, currency, tolerance: tol, from, openingBalance, balance: Math.round(txs.reduce((a, t) => a + cents(t.debit) - cents(t.credit), 0)) / 100, rows: shown,
    summary: {
      invoices: inv2.length, paid: inv2.filter((r) => r.status === 'paid').length, bank: inv2.filter((r) => r.status === 'bank').length, short: inv2.filter((r) => r.status === 'short').length, open: inv2.filter((r) => r.status === 'open').length,
      shortTotal: sum((r) => r.status === 'short', (r) => r.short), openTotal: sum((r) => r.status === 'open', (r) => r.short), bankTotal: sum((r) => r.status === 'bank', (r) => r.bankCharge),
      unmatchedPayments: unp.length, unmatchedPaymentsTotal: Math.round(unp.reduce((a, r) => a + r.short, 0) * 100) / 100, pairs: new Set(shown.map((r) => r.pair).filter((x) => x !== null)).size,
    },
  };
}
