import { db } from '../db/connection';

// The e-mails Nakliye sends. Every text has a built-in default (below); an admin can change the wording on the Nakliye page.
// Words in {curly brackets} are filled in when the e-mail is sent.
export type Lang = 'tr' | 'en';
interface Def { subject?: string; body: string }
export interface TemplateInfo { key: string; title: string; when: string; hasSubject: boolean; subjectNote?: string; vars: [string, string][]; sample: Record<string, string>; def: Record<Lang, Def> }

const SIGN: Record<Lang, string> = { tr: 'Saygılarımızla,\nTECE Dekor - Operasyon', en: 'Best regards,\nTECE Dekor - Operations' };
const HELLO_SAMPLE: Record<Lang, string> = { tr: 'Sayın Ahmet Bey,', en: 'Dear Mr Ahmet,' };
const COMMON: [string, string][] = [['hello', 'The greeting with the person\'s name ("Sayın Ahmet Bey," / "Dear Ahmet,")'], ['sign', 'The signature (Saygılarımızla, TECE Dekor - Operasyon)']];
const BY_REQ: [string, string][] = [['id', 'The request number'], ...COMMON];

export const TEMPLATES: TemplateInfo[] = [
  {
    key: 'rfq', title: 'Freight request (the first e-mail to the firms)', when: 'When you send a freight request (Navlun talebi) to the firms.', hasSubject: false,
    subjectNote: 'The subject line stays as it is ("TECE - Navlun Talebi #123 - …"): the replies are matched to the request by it.',
    vars: [['hello', 'The greeting with the contact name'], ['details', 'The cargo and route lines (built from what you confirmed on the screen)'], ['charges', 'The ticked costs that must be inside the price (empty when none)'], ['sign', 'The signature']],
    sample: { hello: HELLO_SAMPLE.tr, details: 'Çıkış: Bursa, Türkiye\nVarış: Hamburg, Germany\nYük: 6 palet, 3.200 kg\nHazır olma tarihi: 20.11.2026\n\nTalep notu:\n"Hamburg’a 6 palet"', charges: '', sign: SIGN.tr },
    def: {
      tr: { body: '{hello}\n\nAşağıdaki yük için en uygun navlun teklifinizi rica ederiz.\n\n{details}\n\n{charges}Lütfen yanıtınızda toplam fiyatı (all-in) ve fiyata dahil olmayan kalemleri açıkça belirtiniz. Yanıtınızı konu satırını değiştirmeden iletiniz.\n\n{sign}' },
      en: { body: '{hello}\n\nPlease send us your best freight offer for the shipment below.\n\n{details}\n\n{charges}Please state the total price all-in and list any costs that are not included. Reply without changing the subject line.\n\n{sign}' },
    },
  },
  {
    key: 'verify', title: 'E-mail address verification', when: 'When you press "E-posta adreslerini doğrula" in the firm list.', hasSubject: true,
    subjectNote: 'A code like [V-1a2b3c4d] is added to the subject by itself (the replies are recognised by it).',
    vars: [['firm', 'The firm name'], ['email', 'The address the e-mail is sent to'], ['link', 'The confirmation link (one click)'], ['videoWord', '"Ekteki" / "Aşağıdaki" (attached or below)'], ['video', 'The video link line (empty when the video is attached)']],
    sample: { firm: 'Örnek Lojistik', email: 'info@ornek-lojistik.example', link: 'https://cards.example.com/api/ship-verify/abc123', videoWord: 'Ekteki', video: '' },
    def: {
      tr: { subject: 'TECE Nakliye - e-posta adresi doğrulama', body: 'Merhaba {firm} ekibi,\n\nTECE Dekor olarak nakliye tekliflerini bundan sonra bu e-posta adresi ({email}) üzerinden isteyeceğiz. E-postalarımızın doğru kişiye ulaştığından emin olmak istiyoruz.\n\nLütfen şunlardan BİRİNİ yapın:\n1) Şu bağlantıya tıklayın: {link}\n2) Veya bu e-postayı "ONAY" yazarak yanıtlayın.\n\nBu adres nakliye teklifleri için doğru kişiye ait değilse, lütfen yanıtınıza doğru kişinin adını ve e-posta adresini yazın.\n\n{videoWord} kısa video, taleplerimize nasıl cevap vereceğinizi anlatıyor: "TECE - Navlun Talebi" konulu bir e-posta aldığınızda, aynı e-postayı yanıtlayıp e-postada yazan şartlara göre fiyatınızı yazmanız yeterli.{video}\n\nTeşekkürler,\nTECE Nakliye' },
      en: { subject: 'TECE Nakliye - e-mail verification', body: 'Hello {firm} team,\n\nFrom now on TECE Dekor will ask for freight offers at this e-mail address ({email}). We want to be sure that our e-mails reach the right person.\n\nPlease do ONE of these:\n1) Click this link: {link}\n2) Or reply to this e-mail with the word "CONFIRMED".\n\nIf this is not the right person for freight offers, please write the name and e-mail address of the right person in your reply.\n\nThe short video {videoWord} shows how to answer our requests: when you get an e-mail called "TECE - Navlun Talebi", simply reply to that same e-mail with your price and the conditions written in it.{video}\n\nThank you,\nTECE Nakliye' },
    },
  },
  {
    key: 'acceptance', title: 'Offer accepted', when: 'The firm whose offer you accept.', hasSubject: false, vars: [...BY_REQ, ['total', 'The accepted price with currency']],
    sample: { id: '123', total: '2.450 EUR', hello: HELLO_SAMPLE.tr, sign: SIGN.tr },
    def: { tr: { body: '{hello}\n\n#{id} numaralı talebimiz için {total} tutarındaki teklifinizi kabul ediyoruz. Yükleme detayları için ekibimiz sizinle iletişime geçecektir.\n\n{sign}' }, en: { body: '{hello}\n\nWe accept your offer of {total} for request #{id}. Our team will contact you about the loading details.\n\n{sign}' } },
  },
  {
    key: 'rejection', title: 'Offer not chosen', when: 'The other firms, when you accept one offer.', hasSubject: false, vars: BY_REQ,
    sample: { id: '123', hello: HELLO_SAMPLE.tr, sign: SIGN.tr },
    def: { tr: { body: '{hello}\n\n#{id} numaralı talebimiz için verdiğiniz teklif için teşekkür ederiz. Bu sefer başka bir firmayla ilerlemeye karar verdik. Bir sonraki sevkiyatta çalışmayı umuyoruz.\n\n{sign}' }, en: { body: '{hello}\n\nThank you for your offer for request #{id}. We have decided to proceed with another company this time. We hope to work with you on the next shipment.\n\n{sign}' } },
  },
  {
    key: 'cancel', title: 'Request closed', when: 'The silent firms, when a request is closed.', hasSubject: false, vars: BY_REQ,
    sample: { id: '123', hello: HELLO_SAMPLE.tr, sign: SIGN.tr },
    def: { tr: { body: '{hello}\n\n#{id} numaralı talep kapanmıştır; artık teklif gerekmemektedir. İlginiz için teşekkür ederiz.\n\n{sign}' }, en: { body: '{hello}\n\nRequest #{id} has been closed, so no offer is needed any more. Thank you for your interest.\n\n{sign}' } },
  },
  {
    key: 'counter', title: 'Ask for a better price', when: 'When you counter a firm\'s offer with a price.', hasSubject: false, vars: [...BY_REQ, ['price', 'The price you ask for, with currency']],
    sample: { id: '123', price: '2.200 EUR', hello: HELLO_SAMPLE.tr, sign: SIGN.tr },
    def: { tr: { body: '{hello}\n\n#{id} numaralı talebimiz için teklifiniz için teşekkür ederiz. Fiyatı tüm masraflar dahil {price} seviyesine çekebilir misiniz?\n\n{sign}' }, en: { body: '{hello}\n\nThank you for your offer for request #{id}. Could you improve it to {price} all-in?\n\n{sign}' } },
  },
  {
    key: 'allIn', title: 'Ask for the all-in price', when: 'When a price is unclear and you ask for the all-in total.', hasSubject: false, vars: BY_REQ,
    sample: { id: '123', hello: HELLO_SAMPLE.tr, sign: SIGN.tr },
    def: { tr: { body: '{hello}\n\n#{id} numaralı talebimiz için teklifiniz için teşekkür ederiz. Lütfen fiyatın tüm masraflar dahil (all-in) toplamını ve fiyata dahil olmayan kalemleri bildiriniz.\n\n{sign}' }, en: { body: '{hello}\n\nThank you for your offer for request #{id}. Please confirm the total price all-in and list any costs that are not included.\n\n{sign}' } },
  },
  {
    key: 'reminder', title: 'Reminder to silent firms', when: 'When you remind the firms that have not answered.', hasSubject: false, vars: [...BY_REQ, ['place', 'City and country of the shipment']],
    sample: { id: '123', place: 'Hamburg, Germany', hello: HELLO_SAMPLE.tr, sign: SIGN.tr },
    def: { tr: { body: '{hello}\n\n#{id} numaralı talebimiz ({place}) için teklifinizi bekliyoruz. Bu e-postayı yanıtlayabilir misiniz?\n\n{sign}' }, en: { body: '{hello}\n\nWe would be glad to receive your offer for request #{id} ({place}). Could you reply to this e-mail?\n\n{sign}' } },
  },
];

const find = (key: string) => TEMPLATES.find((t) => t.key === key);
export const langOf = (l: string | null | undefined): Lang => (l === 'en' ? 'en' : 'tr');

export function getTemplate(key: string, lang: string): Def & { custom: boolean } {
  const t = find(key); const l = langOf(lang);
  if (!t) throw new Error(`Unknown template ${key}`);
  const r = db.prepare('SELECT subject, body FROM ship_templates WHERE key = ? AND lang = ?').get(key, l) as { subject: string | null; body: string } | undefined;
  if (r && r.body.trim()) return { subject: r.subject?.trim() || t.def[l].subject, body: r.body, custom: true };
  return { ...t.def[l], custom: false };
}

export const fill = (tpl: string, vars: Record<string, string>): string => tpl.replace(/\{(\w+)\}/g, (m, k: string) => (k in vars ? vars[k] : m));
export const renderTemplate = (key: string, lang: string, vars: Record<string, string>): string => fill(getTemplate(key, lang).body, vars);

export function saveTemplate(key: string, lang: string, subject: string | null, body: string, userId: number): void {
  const t = find(key); if (!t) throw new Error('Unknown template');
  if (!body.trim()) throw new Error('The text cannot be empty.');
  const l = langOf(lang);
  const known = new Set(t.vars.map((v) => v[0]));
  const bad = [...body.matchAll(/\{(\w+)\}/g)].map((m) => m[1]).filter((k) => !known.has(k));
  if (bad.length) throw new Error(`Unknown word in {brackets}: ${[...new Set(bad)].map((b) => `{${b}}`).join(', ')}`);
  db.prepare(`INSERT INTO ship_templates (key, lang, subject, body, updated_by, updated_at) VALUES (?, ?, ?, ?, ?, datetime('now'))
    ON CONFLICT(key, lang) DO UPDATE SET subject = excluded.subject, body = excluded.body, updated_by = excluded.updated_by, updated_at = excluded.updated_at`).run(key, l, t.hasSubject ? (subject ?? '').trim().slice(0, 200) || null : null, body, userId);
}
export const resetTemplate = (key: string, lang: string): void => { db.prepare('DELETE FROM ship_templates WHERE key = ? AND lang = ?').run(key, langOf(lang)); };

export function listTemplates() {
  return TEMPLATES.map((t) => ({
    key: t.key, title: t.title, when: t.when, hasSubject: t.hasSubject, subjectNote: t.subjectNote ?? null, vars: t.vars,
    langs: (['tr', 'en'] as Lang[]).map((l) => { const cur = getTemplate(t.key, l); return { lang: l, subject: cur.subject ?? null, body: cur.body, custom: cur.custom, defSubject: t.def[l].subject ?? null, defBody: t.def[l].body }; }),
  }));
}
export function previewTemplate(key: string, lang: string, subject: string | null, body: string): { subject: string | null; body: string } {
  const t = find(key); if (!t) throw new Error('Unknown template');
  const l = langOf(lang);
  const sample = { ...t.sample };
  if (l === 'en') { sample.hello = HELLO_SAMPLE.en; sample.sign = SIGN.en; if (key === 'verify') sample.videoWord = 'attached to this e-mail'; }
  return { subject: t.hasSubject ? `${fill(subject || t.def[l].subject || '', sample)} [V-1a2b3c4d]` : null, body: fill(body, sample) };
}
