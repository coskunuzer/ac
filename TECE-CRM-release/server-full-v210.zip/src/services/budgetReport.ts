import fs from 'fs';
import path from 'path';
import PDFDocument from 'pdfkit';
import { PDFDocument as PdfLib, StandardFonts, degrees, rgb } from 'pdf-lib';
import sharp from 'sharp';
import ExcelJS from 'exceljs';
import { db } from '../db/connection';
import { paths } from '../config/env';
import { drawLogo, registerDesignFonts } from './priceBook/designed';
import { COMPANY_ADDRESS_LINE } from './signature';
import { DOC_LABEL, EVENT_CATEGORIES, eventBudget, type DocType, type EventKind } from './eventBudget';
import { visibilityFor, type Viewer } from './visibility';
import { descendants } from './team';

// The Turquality file of one trip or one fair: to claim the costs back, the company hands in - per trip / fair - the invoices, the payment proofs,
// the boarding passes, the hotel bills and a visit report, with the amounts in TL and EUR. This builds all of it as ONE PDF:
//   1. a summary (who, when, where, planned and spent per kind of cost),  2. the list of the costs,  3. the visit report (the days and the customers
//   of the trip with the notes written in those days / the people met at the fair),  4. the list of the documents, and then a copy of every
//   uploaded document in the same order: PDFs page by page, pictures one per page. Other files (Excel, Word) are named as "not embeddable".
// The pages we write are drawn with pdfkit (Montserrat, so Turkish letters are right); pdf-lib puts them together with the documents.
export const BUDGET_FILES = path.join(path.dirname(paths.dbFile), 'budget-files');

type Lang = 'en' | 'tr';
const NAVY = '#17243E', RED = '#8B1931', STEEL = '#5E6676', SMOKE = '#E3E6EC', ZEBRA = '#F4F6FA', INK = '#1F2430';
const F = { r: 'TD-400', m: 'TD-500', b: 'TD-600', h: 'TD-700' };
const PW = 595.28, PH = 841.89, L0 = 36, CW = PW - 2 * L0, TOP = 74, BOTTOM = PH - 46;

// the few words of the report, in the language of the person who takes it
const WORDS: Record<string, string> = {
  'Turquality report': 'Turquality raporu', 'Business trip': 'İş seyahati', 'Trade fair': 'Fuar', Dates: 'Tarihler', 'Person': 'Kişi', People: 'Kişiler', Countries: 'Ülkeler', Place: 'Yer',
  Planned: 'Planlanan', 'Spent (EUR)': 'Harcanan (EUR)', 'Spent (TL)': 'Harcanan (TL)', Costs: 'Harcamalar', Documents: 'Belgeler', 'Customers visited': 'Ziyaret edilen müşteri', 'People met': 'Görüşülen kişi',
  'Per kind of cost': 'Harcama türüne göre', 'Kind of cost': 'Harcama türü', 'Planned €': 'Planlanan €', 'Spent €': 'Harcanan €', 'Spent TL': 'Harcanan TL', Total: 'Toplam',
  Date: 'Tarih', Document: 'Belge', 'Supplier · what for': 'Tedarikçi · açıklama', 'Invoice no.': 'Fatura no', Amount: 'Tutar', Pages: 'Sayfa', 'Entered by': 'Giren',
  'Visit report': 'Ziyaret raporu', Day: 'Gün', Time: 'Saat', Customer: 'Müşteri', 'City, country': 'Şehir, ülke', Contact: 'İlgili kişi', Note: 'Not',
  'Not on a day': 'Güne konmamış', 'Notes and activities in the trip dates': 'Seyahat tarihlerinde yazılan notlar ve faaliyetler', Type: 'Tür', Text: 'Metin', By: 'Yazan',
  'Note of the trip': 'Seyahat notu', 'List of documents': 'Belge listesi', Appendix: 'Ek', 'Cost': 'Harcama', File: 'Dosya',
  'not embeddable, kept in the CRM': 'eklenemedi, CRM’de saklı', 'password-protected: print it to PDF and upload again': 'şifreli: PDF olarak yazdırıp yeniden yükleyin', 'file missing': 'dosya bulunamadı', 'could not be read': 'okunamadı',
  'No costs yet.': 'Henüz harcama yok.', 'No customers on the trip.': 'Seyahatte müşteri yok.', 'No notes written in these days.': 'Bu günlerde yazılmış not yok.', 'No documents uploaded.': 'Yüklenmiş belge yok.',
  'By country': 'Ülkeye göre', 'By person': 'Kişiye göre', Country: 'Ülke', 'People met at the fair': 'Fuarda görüşülen kişiler', 'Offers sent': 'Gönderilen teklif', 'Customers won': 'Kazanılan müşteri', 'Thank-you e-mails sent': 'Gönderilen teşekkür e-postası',
  'Prepared by {by} on {date}.': '{by} tarafından {date} tarihinde hazırlandı.',
  'Only the costs marked for Turquality: {n} of {m}.': 'Yalnızca Turquality için işaretlenen harcamalar: {m} harcamadan {n}.',
  'All the costs of the {what}, also those not marked for Turquality.': 'Turquality için işaretlenmeyenler dahil tüm harcamalar.',
  'Amounts in TL as booked; EUR at the rate of the month (TL for 1 €). The planned TL is at {rate} TL/€.': 'TL tutarlar muhasebe kaydındaki gibidir; EUR, ayın kuruyla (1 € için TL). Planlanan TL {rate} TL/€ kuruyla hesaplanmıştır.',
  'Amounts in TL as booked; EUR at the rate of the month (TL for 1 €).': 'TL tutarlar muhasebe kaydındaki gibidir; EUR, ayın kuruyla (1 € için TL).',
  'Rate': 'Kur', 'Kind': 'Tür', 'Page {n} of {t}': 'Sayfa {n} / {t}', 'trip': 'seyahatin', 'fair': 'fuarın', 'No.': 'No',
  Invoice: 'Fatura', 'Payment proof': 'Ödeme dekontu', 'Boarding pass / ticket': 'Biniş kartı / bilet', 'Hotel bill': 'Otel faturası', 'Other document': 'Diğer belge',
  Flights: 'Uçak', Hotel: 'Otel', 'Car, taxi, train': 'Araç, taksi, tren', Meals: 'Yemek', 'Customer dinners and gifts': 'Müşteri yemekleri ve hediyeler', 'Visa and insurance': 'Vize ve sigorta', Other: 'Diğer',
  'Stand rent and sponsorship': 'Stant kirası ve sponsorluk', 'Stand design and build': 'Stant tasarım ve yapım', Logistics: 'Lojistik', 'Flights and hotel of the team': 'Ekibin uçak ve oteli', 'Meals of the team': 'Ekibin yemekleri',
  'Samples, catalogues, gifts': 'Numune, katalog, hediye', 'Customs and official fees': 'Gümrük ve resmi harçlar',
  Note_: 'Not', Call: 'Arama', Visit: 'Ziyaret', Meeting: 'Toplantı', 'Sample sent': 'Numune gönderildi', 'Offer sent': 'Teklif gönderildi', 'Documents sent': 'Belge gönderildi', 'Thank-you sent': 'Teşekkür gönderildi', 'Personal e-mail sent': 'E-posta gönderildi',
  'not on a day': 'güne konmamış', Expenses: 'Harcamalar', '{n} costs · {d} documents': '{n} harcama · {d} belge', Count: 'Adet',
};
const tr = (lang: Lang) => (en: string, vars?: Record<string, string | number>) => {
  let s = lang === 'tr' ? (WORDS[en] ?? en) : en;
  if (vars) for (const [k, v] of Object.entries(vars)) s = s.replace(`{${k}}`, String(v));
  return s;
};
const ACT_LABEL: Record<string, string> = { note: 'Note_', call: 'Call', visit: 'Visit', meeting: 'Meeting', sample: 'Sample sent', offer: 'Offer sent', documents: 'Documents sent', thank_you: 'Thank-you sent', email: 'Personal e-mail sent' };
const ACT_TYPES = Object.keys(ACT_LABEL);

const r2 = (v: number) => Math.round(v * 100) / 100;
const money = (lang: Lang) => (v: number) => (Number.isFinite(v) ? v : 0).toLocaleString(lang === 'tr' ? 'tr-TR' : 'en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const day = (lang: Lang, iso: string | null, weekday = false) => (iso ? new Date(`${iso.slice(0, 10)}T12:00:00Z`).toLocaleDateString(lang === 'tr' ? 'tr-TR' : 'en-GB', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC', ...(weekday ? { weekday: 'short' } : {}) }) : '');
const addDays = (iso: string, n: number) => new Date(Date.parse(`${iso}T12:00:00Z`) + n * 864e5).toISOString().slice(0, 10);
const extOf = (name: string) => path.extname(name).toLowerCase();
const IMAGE = ['.jpg', '.jpeg', '.png', '.webp'];
// pdf-lib's own font knows no Turkish letters: the small labels stamped on the copied documents are written without them
const ascii = (s: string) => s.replace(/[ğĞ]/g, (c) => (c === 'ğ' ? 'g' : 'G')).replace(/[şŞ]/g, (c) => (c === 'ş' ? 's' : 'S')).replace(/ı/g, 'i').replace(/İ/g, 'I').replace(/[çÇ]/g, (c) => (c === 'ç' ? 'c' : 'C'))
  .replace(/[öÖ]/g, (c) => (c === 'ö' ? 'o' : 'O')).replace(/[üÜ]/g, (c) => (c === 'ü' ? 'u' : 'U')).replace(/€/g, 'EUR').replace(/[^\x20-\x7E·—]/g, '?');

interface Doc { no: number; costNo: number; docType: DocType; name: string; rel: string; kind: 'pdf' | 'image' | 'other' | 'missing' | 'broken' | 'locked'; pages: number; pdf?: PdfLib; img?: { buf: Buffer; w: number; h: number }; start?: number }
interface Cost { no: number; id: number; date: string; category: string; docType: DocType; supplier: string | null; description: string | null; invoiceNo: string | null; currency: string; amount: number; rate: number | null; try: number; eur: number; by: string | null; turquality: boolean; docs: Doc[] }

interface Data {
  kind: EventKind; id: number; title: string; from: string | null; to: string | null; people: string[]; countries: string[]; place: string | null;
  costs: Cost[]; allCount: number; all: boolean; docs: Doc[];
  cats: { key: string; label: string; planned: number; eur: number; try: number; n: number }[];
  planned: number; plannedRate: number | null; eur: number; try: number;
  trip?: { days: { n: number | null; date: string | null; stops: { time: string | null; company: string; city: string; contact: string; note: string }[] }[]; notes: { date: string; company: string; type: string; text: string; by: string }[]; note: string | null; customers: number };
  fair?: { met: number; offers: number; won: number; thanked: number; byCountry: { country: string; n: number }[]; byPerson: { name: string; n: number }[] };
}

// `viewer`: who asks for the file. Stops and notes on customers they may not see (the budget people looking at somebody else's trip) come out
// without the company, contact, stop note or note text: only the country.
// `team`: may this person see their team's customers at all (the same rule as the Manager switch: not an assistant working for somebody)
function collect(kind: EventKind, id: number, all: boolean, viewer?: Viewer, lang: Lang = 'en', team = false): Data {
  const b = eventBudget(kind, id);
  if (!b) throw new Error(kind === 'trip' ? 'Trip not found' : 'Fair not found');
  const ids = b.rows.map((r) => r.id);
  const marks = ids.map(() => '?').join(',');
  const extra = ids.length ? (db.prepare(`SELECT id, rate, file_path FROM budget_expenses WHERE id IN (${marks})`).all(...ids) as unknown as { id: number; rate: number | null; file_path: string | null }[]) : [];
  const more = ids.length ? (db.prepare(`SELECT id, expense_id, doc_type, file_path, file_name FROM budget_expense_files WHERE expense_id IN (${marks}) ORDER BY id`).all(...ids) as unknown as { id: number; expense_id: number; doc_type: string; file_path: string; file_name: string | null }[]) : [];
  const rows = all ? b.rows : b.rows.filter((r) => r.turquality);
  const docs: Doc[] = [];
  const costs: Cost[] = rows.map((r, i) => {
    const x = extra.find((e) => e.id === r.id);
    const mine: Doc[] = [];
    const add = (docType: DocType, rel: string | null | undefined, name: string | null) => { if (!rel) return; const d: Doc = { no: docs.length + 1, costNo: i + 1, docType, name: name || path.basename(rel), rel, kind: 'other', pages: 0 }; docs.push(d); mine.push(d); };
    add(r.docType, x?.file_path, r.fileName);
    for (const f of more.filter((m) => m.expense_id === r.id)) add((DOC_LABEL as Record<string, string>)[f.doc_type] ? (f.doc_type as DocType) : 'other', f.file_path, f.file_name);
    return { no: i + 1, id: r.id, date: r.date, category: r.category, docType: r.docType, supplier: r.supplier, description: r.description, invoiceNo: r.invoiceNo, currency: r.currency, amount: r.amount, rate: x?.rate ?? null, try: r.try, eur: r.eur, by: r.by, turquality: r.turquality, docs: mine };
  });
  const cats = EVENT_CATEGORIES[kind].map((c) => {
    const mine = costs.filter((x) => x.category === c.key);
    return { key: c.key, label: c.label, planned: b.categories.find((p) => p.key === c.key)?.planned ?? 0, eur: r2(mine.reduce((s, x) => s + x.eur, 0)), try: r2(mine.reduce((s, x) => s + x.try, 0)), n: mine.length };
  });
  const eur = r2(costs.reduce((s, x) => s + x.eur, 0)), tl = r2(costs.reduce((s, x) => s + x.try, 0));
  // the planned TL: at the rate of the first month of the trip / fair, else the rate of what was spent
  const ym = (b.from ?? '').slice(0, 7);
  const stored = ym ? (db.prepare('SELECT try_per_eur AS t FROM budget_rates WHERE ym <= ? ORDER BY ym DESC LIMIT 1').get(ym) as { t: number } | undefined)?.t ?? null : null;
  const plannedRate = stored ?? (eur > 0 ? r2(tl / eur) : null);
  const d: Data = { kind, id, title: b.title, from: b.from, to: b.to, people: [], countries: [], place: null, costs, allCount: b.rows.length, all, docs, cats, planned: b.planned, plannedRate, eur, try: tl };

  if (kind === 'trip') {
    const t = db.prepare('SELECT t.user_id, t.note, t.start_date, t.end_date, u.display_name, u.username FROM trips t LEFT JOIN users u ON u.id = t.user_id WHERE t.id = ?').get(id) as { user_id: number; note: string | null; start_date: string | null; end_date: string | null; display_name: string | null; username: string | null };
    d.people = [t.display_name || t.username || ''].filter(Boolean);
    // what this person may read: an admin everything; anybody else the customers they see, plus their team's when the trip is theirs or of somebody below them
    const seen = viewer && viewer.role !== 'admin' ? visibilityFor(viewer) : null;
    const below = seen && team ? descendants(viewer!.id) : [];
    const mineOrTeam = !seen || t.user_id === viewer!.id || below.some((x) => x.user.id === t.user_id);
    const names = new Set(mineOrTeam ? below.map((x) => x.user.display_name).filter((n): n is string => !!n) : []);
    const open = (c: { uploaded_by: number | null; person: string | null; country: string | null; status: string | null; market: string | null; city: string | null; owner_override: number | null }) => !seen || seen(c as never) || (!!c.person && names.has(c.person));
    const hiddenName = lang === 'tr' ? 'Bir müşteri (size görünmüyor)' : 'A customer (not visible to you)';
    const stops = db.prepare(`SELECT s.day_no, s.sort, s.visit_time, s.note, s.card_id, c.company, c.name, c.last_name, c.city, c.country, c.uploaded_by, c.person, c.status, c.market, c.owner_override FROM trip_stops s JOIN cards c ON c.id = s.card_id WHERE s.trip_id = ?
      ORDER BY CASE WHEN s.day_no IS NULL THEN 1 ELSE 0 END, s.day_no, CASE WHEN COALESCE(s.visit_time, '') = '' THEN 1 ELSE 0 END, CAST(substr(s.visit_time, 1, instr(s.visit_time || ':', ':') - 1) AS INTEGER), s.visit_time, s.sort`).all(id) as unknown as { day_no: number | null; visit_time: string | null; note: string | null; card_id: number; company: string | null; name: string | null; last_name: string | null; city: string | null; country: string | null; uploaded_by: number | null; person: string | null; status: string | null; market: string | null; owner_override: number | null }[];
    d.countries = [...new Set(stops.map((s) => (s.country ?? '').trim()).filter(Boolean))];
    const days: NonNullable<Data['trip']>['days'] = [];
    for (const s of stops) {
      let g = days.find((x) => x.n === s.day_no);
      if (!g) { g = { n: s.day_no, date: s.day_no && t.start_date ? addDays(t.start_date, s.day_no - 1) : null, stops: [] }; days.push(g); }
      if (!open(s)) { g.stops.push({ time: s.visit_time, company: hiddenName, city: s.country ?? '', contact: '', note: '' }); continue; }
      g.stops.push({ time: s.visit_time, company: s.company || '—', city: [s.city, s.country].filter(Boolean).join(', '), contact: [s.name, s.last_name].filter(Boolean).join(' '), note: s.note ?? '' });
    }
    // what was written on the customers of the trip in the days of the trip (and anything written "for this trip", where notes carry it)
    const notes: NonNullable<Data['trip']>['notes'] = [];
    const cardIds = [...new Set(stops.map((s) => s.card_id))];
    if (t.start_date) {
      const until = addDays(t.end_date || t.start_date, 1);
      const hasTrip = (db.prepare("SELECT COUNT(*) AS n FROM pragma_table_info('activities') WHERE name = 'trip_id'").get() as { n: number }).n > 0;
      const p: (string | number)[] = [];
      const parts: string[] = [];
      // only what the person who travelled wrote: other people's notes on these customers are not part of this visit
      if (cardIds.length) { parts.push(`(a.card_id IN (${cardIds.map(() => '?').join(',')}) AND a.user_id = ? AND a.created_at >= ? AND a.created_at < ?)`); p.push(...cardIds, t.user_id, `${t.start_date} 00:00:00`, `${until} 00:00:00`); }
      if (hasTrip) { parts.push('a.trip_id = ?'); p.push(id); }
      if (parts.length) {
        const acts = db.prepare(`SELECT a.created_at, a.type, a.text, a.card_id, c.company, c.uploaded_by, c.person, c.country, c.status, c.market, c.city, c.owner_override, u.display_name, u.username FROM activities a LEFT JOIN cards c ON c.id = a.card_id LEFT JOIN users u ON u.id = a.user_id
          WHERE (${parts.join(' OR ')}) AND a.imported = 0 AND a.type IN (${ACT_TYPES.map(() => '?').join(',')}) ORDER BY a.created_at LIMIT 400`).all(...p, ...ACT_TYPES) as unknown as { created_at: string; type: string; text: string | null; card_id: number | null; company: string | null; uploaded_by: number | null; person: string | null; country: string | null; status: string | null; market: string | null; city: string | null; owner_override: number | null; display_name: string | null; username: string | null }[];
        for (const a of acts) if (a.card_id == null ? mineOrTeam : open(a)) notes.push({ date: a.created_at, company: a.company || '—', type: a.type, text: (a.text ?? '').replace(/\s+/g, ' ').trim().slice(0, 600), by: a.display_name || a.username || '' });
      }
    }
    d.trip = { days, notes, note: t.note, customers: stops.length };
  } else {
    const e = db.prepare('SELECT location FROM exhibitions WHERE id = ?').get(id) as { location: string | null };
    d.place = e.location;
    d.countries = e.location ? [e.location.split(',').pop()!.trim()] : [];
    d.people = (db.prepare('SELECT COALESCE(u.display_name, u.username) AS n FROM exhibition_attendees a JOIN users u ON u.id = a.user_id WHERE a.exhibition_id = ? ORDER BY 1').all(id) as unknown as { n: string }[]).map((x) => x.n);
    const n = (sql: string) => (db.prepare(sql).get(id) as { n: number }).n;
    const unit = (label: string) => b.units.find((u) => u.label === label)?.n ?? 0;
    d.fair = {
      // the same figures as the fair board and the fair's budget panel (won = not buying before the fair started; offers = real offers)
      met: unit('people met'),
      offers: unit('offers sent'),
      won: unit('customers won'),
      thanked: n('SELECT COUNT(*) AS n FROM cards WHERE exhibition_id = ? AND thank_you_sent_at IS NOT NULL'),
      byCountry: db.prepare("SELECT COALESCE(NULLIF(TRIM(country), ''), '—') AS country, COUNT(*) AS n FROM cards WHERE exhibition_id = ? GROUP BY 1 ORDER BY n DESC, 1 LIMIT 40").all(id) as unknown as { country: string; n: number }[],
      byPerson: db.prepare("SELECT COALESCE(u.display_name, u.username, NULLIF(TRIM(c.person), ''), '—') AS name, COUNT(*) AS n FROM cards c LEFT JOIN users u ON u.id = c.uploaded_by WHERE c.exhibition_id = ? GROUP BY 1 ORDER BY n DESC LIMIT 30").all(id) as unknown as { name: string; n: number }[],
    };
  }
  return d;
}

// read every document once: how many pages it brings, and the pictures as JPEG (webp and PNG too: pdfkit draws JPEG and PNG, a phone photo can be huge)
async function load(docs: Doc[]): Promise<void> {
  for (const d of docs) {
    const full = path.resolve(BUDGET_FILES, d.rel);
    if (!full.startsWith(path.resolve(BUDGET_FILES) + path.sep) || !fs.existsSync(full)) { d.kind = 'missing'; continue; }
    const ext = extOf(d.rel);
    try {
      if (ext === '.pdf') {
        d.pdf = await PdfLib.load(fs.readFileSync(full), { ignoreEncryption: true, updateMetadata: false });
        d.pages = d.pdf.getPageCount();
        d.kind = d.pages > 0 ? 'pdf' : 'broken';
        // a password-protected PDF (bank payment proofs often are) cannot be copied: its pages would come out blank
        if (d.pdf.isEncrypted) { d.kind = 'locked'; d.pages = 0; d.pdf = undefined; }
      } else if (IMAGE.includes(ext)) {
        const out = await sharp(fs.readFileSync(full), { failOn: 'none' }).rotate().resize(2200, 2200, { fit: 'inside', withoutEnlargement: true }).flatten({ background: '#ffffff' }).jpeg({ quality: 82 }).toBuffer({ resolveWithObject: true });
        d.img = { buf: out.data, w: out.info.width, h: out.info.height };
        d.pages = 1; d.kind = 'image';
      } else d.kind = 'other';
    } catch (e) {
      console.warn('Turquality report: could not read', d.rel, e instanceof Error ? e.message : e);
      d.kind = 'broken'; d.pages = 0;
    }
  }
}

type Pdf = InstanceType<typeof PDFDocument>;
interface Col { label: string; w: number; right?: boolean }

// the pages we write ourselves; pageOf(doc) is where each document starts in the finished file (unknown in the first pass)
function renderSummary(d: Data, lang: Lang, by: string, total: number | null): Promise<{ buf: Buffer; pages: number }> {
  const t = tr(lang); const m = money(lang);
  const up = (v: string) => v.toLocaleUpperCase(lang === 'tr' ? 'tr-TR' : 'en-GB').replace(/TURQUALİTY/g, 'TURQUALITY');
  const doc = new PDFDocument({ size: 'A4', margin: 0, autoFirstPage: false, bufferPages: true, info: { Title: `${t('Turquality report')} - ${d.title}`, Author: 'TECE' } });
  const chunks: Buffer[] = [];
  doc.on('data', (b: Buffer) => chunks.push(b));
  const done = new Promise<Buffer>((resolve, reject) => { doc.on('end', () => resolve(Buffer.concat(chunks))); doc.on('error', reject); });
  registerDesignFonts(doc);
  let y = TOP;
  const page = () => {
    doc.addPage();
    doc.rect(0, 0, PW, 50).fill(NAVY);
    drawLogo(doc, 'TECE_SloganliLogo_Beyaz_RGB.svg', L0, (50 - 160 * (522 / 5990)) / 2, 160);
    doc.rect(0, 50, PW, 3).fill(RED);
    doc.font(F.h).fontSize(11).fillColor('#FFFFFF').text(up(t('Turquality report')), L0, 15, { width: CW, align: 'right', lineBreak: false });
    doc.font(F.r).fontSize(7.5).fillColor('#C9CFDA').text(d.title, L0, 30, { width: CW, align: 'right', lineBreak: false, ellipsis: true });
    y = TOP;
  };
  const need = (h: number) => { if (y + h > BOTTOM) page(); };
  const heading = (text: string, sub?: string) => {
    need(sub ? 60 : 44);
    y += 6;
    doc.font(F.h).fontSize(13).fillColor(NAVY).text(text, L0, y, { width: CW });
    y = doc.y + 2;
    doc.rect(L0, y, 34, 2).fill(RED);
    y += 7;
    if (sub) { doc.font(F.r).fontSize(8).fillColor(STEEL).text(sub, L0, y, { width: CW }); y = doc.y + 6; }
  };
  // a table whose rows grow with their text; the header comes back on every new page
  const table = (cols: Col[], rows: string[][], opt: { size?: number; boldFirst?: boolean; totals?: string[]; empty?: string } = {}) => {
    const size = opt.size ?? 7.6;
    const sum = cols.reduce((n, c) => n + c.w, 0);
    let x = L0;
    const cs = cols.map((c) => { const w = (c.w / sum) * CW; const r = { ...c, x, w }; x += w; return r; });
    const head = () => {
      doc.font(F.b).fontSize(6.6).fillColor(STEEL);
      let hh = 0;
      for (const c of cs) hh = Math.max(hh, doc.heightOfString(up(c.label), { width: c.w - 6 }));
      for (const c of cs) doc.text(up(c.label), c.x + 3, y, { width: c.w - 6, align: c.right ? 'right' : 'left' });
      y += hh + 3;
      doc.rect(L0, y, CW, 1).fill(NAVY);
      y += 4;
    };
    need(40);
    head();
    if (!rows.length) { doc.font(F.r).fontSize(8.5).fillColor(STEEL).text(opt.empty ?? '—', L0 + 3, y + 2, { width: CW }); y = doc.y + 12; return; }
    const draw = (row: string[], i: number, bold: boolean) => {
      let rh = 0;
      row.forEach((cell, k) => { const c = cs[k]; if (!c) return; doc.font(bold || (k === 0 && opt.boldFirst) ? F.b : F.r).fontSize(size); rh = Math.max(rh, doc.heightOfString(cell || ' ', { width: c.w - 6 })); });
      rh += 6;
      if (y + rh > BOTTOM) { page(); head(); }
      if (bold) doc.rect(L0, y - 1, CW, rh).fill('#E9ECF2'); else if (i % 2 === 1) doc.rect(L0, y - 1, CW, rh).fill(ZEBRA);
      row.forEach((cell, k) => { const c = cs[k]; if (!c) return; doc.font(bold || (k === 0 && opt.boldFirst) ? F.b : F.r).fontSize(size).fillColor(INK).text(cell || '', c.x + 3, y + 2, { width: c.w - 6, align: c.right ? 'right' : 'left' }); });
      y += rh;
      doc.rect(L0, y - 1, CW, 0.4).fill(SMOKE);
    };
    rows.forEach((r, i) => draw(r, i, false));
    if (opt.totals) draw(opt.totals, 0, true);
    y += 12;
  };
  const docLabel = (k: DocType) => t(DOC_LABEL[k]);
  const catLabel = (k: string) => t(EVENT_CATEGORIES[d.kind].find((c) => c.key === k)?.label ?? k);
  const pagesOf = (x: Doc) => (x.kind === 'pdf' || x.kind === 'image' ? (x.start ? (x.pages > 1 ? `${x.start}–${x.start + x.pages - 1}` : String(x.start)) : '…') : x.kind === 'missing' ? t('file missing') : x.kind === 'broken' ? t('could not be read') : x.kind === 'locked' ? t('password-protected: print it to PDF and upload again') : t('not embeddable, kept in the CRM'));

  // ---- 1. the summary
  page();
  doc.font(F.m).fontSize(8.5).fillColor(RED).text(up(d.kind === 'trip' ? t('Business trip') : t('Trade fair')), L0, y, { width: CW, characterSpacing: 0.6 });
  y = doc.y + 2;
  doc.font(F.h).fontSize(22).fillColor(NAVY).text(d.title, L0, y, { width: CW });
  y = doc.y + 10;
  const facts: [string, string][] = [
    [t('Dates'), d.from ? (d.to && d.to !== d.from ? `${day(lang, d.from)} – ${day(lang, d.to)}` : day(lang, d.from)) : '—'],
    [d.people.length > 1 ? t('People') : t('Person'), d.people.join(', ') || '—'],
    ...(d.place ? [[t('Place'), d.place] as [string, string]] : []),
    [t('Countries'), d.countries.join(', ') || '—'],
  ];
  for (const [k, v] of facts) {
    doc.font(F.b).fontSize(8).fillColor(STEEL).text(up(k), L0, y, { width: 90 });
    doc.font(F.m).fontSize(10).fillColor(INK).text(v, L0 + 95, y - 1, { width: CW - 95 });
    y = Math.max(doc.y, y + 12) + 5;
  }
  y += 6;
  // the big numbers
  const tiles: [string, string, string?][] = [
    [t('Planned'), `€ ${m(d.planned)}`, d.plannedRate && d.planned > 0 ? `≈ ${m(d.planned * d.plannedRate)} TL` : undefined],
    [t('Spent (EUR)'), `€ ${m(d.eur)}`, d.planned > 0 ? `${Math.round((d.eur / d.planned) * 100)}%` : undefined],
    [t('Spent (TL)'), `${m(d.try)} TL`],
    [d.kind === 'trip' ? t('Customers visited') : t('People met'), String(d.kind === 'trip' ? d.trip!.customers : d.fair!.met), t('{n} costs · {d} documents', { n: d.costs.length, d: d.docs.length })],
  ];
  const tw = (CW - 3 * 8) / 4;
  tiles.forEach(([k, v, s], i) => {
    const x = L0 + i * (tw + 8);
    doc.roundedRect(x, y, tw, 62, 6).fill(i === 1 && d.planned > 0 && d.eur > d.planned ? '#FBEAEA' : ZEBRA);
    doc.font(F.b).fontSize(6.8).fillColor(STEEL).text(up(k), x + 9, y + 9, { width: tw - 18, lineBreak: false, ellipsis: true });
    doc.font(F.h).fontSize(13).fillColor(NAVY).text(v, x + 9, y + 23, { width: tw - 18, lineBreak: false, ellipsis: true });
    if (s) doc.font(F.r).fontSize(7).fillColor(STEEL).text(s, x + 9, y + 44, { width: tw - 18, lineBreak: false, ellipsis: true });
  });
  y += 76;
  heading(t('Per kind of cost'));
  const used = d.cats.filter((c) => c.planned > 0 || c.n > 0);
  table([{ label: t('Kind of cost'), w: 34 }, { label: t('Planned €'), w: 16, right: true }, { label: t('Spent €'), w: 16, right: true }, { label: t('Spent TL'), w: 18, right: true }, { label: t('Count'), w: 9, right: true }],
    used.map((c) => [catLabel(c.key), c.planned ? m(c.planned) : '—', m(c.eur), m(c.try), String(c.n)]),
    { boldFirst: true, size: 8.4, empty: t('No costs yet.'), totals: used.length ? [t('Total'), m(d.planned), m(d.eur), m(d.try), String(d.costs.length)] : undefined });
  const notes = [
    d.all ? t('All the costs of the {what}, also those not marked for Turquality.', { what: d.kind === 'trip' ? t('trip') : t('fair') }) : t('Only the costs marked for Turquality: {n} of {m}.', { n: d.costs.length, m: d.allCount }),
    d.plannedRate && d.planned > 0 ? t('Amounts in TL as booked; EUR at the rate of the month (TL for 1 €). The planned TL is at {rate} TL/€.', { rate: m(d.plannedRate) }) : t('Amounts in TL as booked; EUR at the rate of the month (TL for 1 €).'),
    t('Prepared by {by} on {date}.', { by, date: day(lang, new Date().toISOString().slice(0, 10)) }),
  ];
  need(40);
  doc.font(F.r).fontSize(7.6).fillColor(STEEL).text(notes.join('\n'), L0, y, { width: CW, lineGap: 2 });
  y = doc.y + 10;

  // ---- 2. the costs
  page();
  heading(t('Costs'));
  table([
    { label: t('No.'), w: 4 }, { label: t('Date'), w: 9 }, { label: t('Kind of cost'), w: 12 }, { label: t('Document'), w: 11 }, { label: t('Supplier · what for'), w: 21 }, { label: t('Invoice no.'), w: 10 },
    { label: t('Amount'), w: 11, right: true }, { label: t('Rate'), w: 6, right: true }, { label: 'TL', w: 11, right: true }, { label: 'EUR', w: 10, right: true }, { label: t('Pages'), w: 8, right: true },
  ], d.costs.map((c) => [
    String(c.no), day(lang, c.date), catLabel(c.category), docLabel(c.docType), [c.supplier, c.description].filter(Boolean).join(' · ') + (c.by ? `\n${t('Entered by')}: ${c.by}` : ''), c.invoiceNo ?? '',
    `${m(c.amount)} ${c.currency}`, c.rate ? m(c.rate) : '', m(c.try), m(c.eur), c.docs.length ? c.docs.map((x) => (x.kind === 'pdf' || x.kind === 'image' ? pagesOf(x) : '—')).join(', ') : '—',
  ]), { size: 7.2, empty: t('No costs yet.'), totals: d.costs.length ? ['', '', '', '', t('Total'), '', '', '', m(d.try), m(d.eur), ''] : undefined });

  // ---- 3. the visit report
  page();
  heading(t('Visit report'));
  if (d.trip) {
    if (d.trip.note) { need(30); doc.font(F.b).fontSize(8).fillColor(STEEL).text(up(t('Note of the trip')), L0, y); y = doc.y + 2; doc.font(F.r).fontSize(9).fillColor(INK).text(d.trip.note, L0, y, { width: CW }); y = doc.y + 10; }
    if (!d.trip.days.length) { doc.font(F.r).fontSize(9).fillColor(STEEL).text(t('No customers on the trip.'), L0, y); y = doc.y + 12; }
    for (const g of d.trip.days) {
      need(60);
      doc.font(F.h).fontSize(10).fillColor(NAVY).text(g.n ? `${t('Day')} ${g.n}${g.date ? '  ·  ' + day(lang, g.date, true) : ''}` : t('Not on a day'), L0, y, { width: CW });
      y = doc.y + 4;
      table([{ label: t('Time'), w: 8 }, { label: t('Customer'), w: 30 }, { label: t('City, country'), w: 20 }, { label: t('Contact'), w: 16 }, { label: t('Note'), w: 26 }],
        g.stops.map((s) => [s.time ?? '', s.company, s.city, s.contact, s.note]), { boldFirst: false, size: 7.8 });
    }
    heading(t('Notes and activities in the trip dates'));
    table([{ label: t('Date'), w: 12 }, { label: t('Customer'), w: 22 }, { label: t('Type'), w: 11 }, { label: t('Text'), w: 42 }, { label: t('By'), w: 13 }],
      d.trip.notes.map((n) => [day(lang, n.date), n.company, t(ACT_LABEL[n.type] ?? n.type), n.text, n.by]), { size: 7.4, empty: t('No notes written in these days.') });
  } else if (d.fair) {
    const f = d.fair;
    table([{ label: t('People met at the fair'), w: 50 }, { label: '', w: 20, right: true }],
      [[t('People met'), String(f.met)], [t('Thank-you e-mails sent'), String(f.thanked)], [t('Offers sent'), String(f.offers)], [t('Customers won'), String(f.won)]], { boldFirst: true, size: 8.6 });
    heading(t('By country'));
    table([{ label: t('Country'), w: 60 }, { label: t('People met'), w: 20, right: true }], f.byCountry.map((r) => [r.country, String(r.n)]), { size: 7.8 });
    heading(t('By person'));
    table([{ label: t('Person'), w: 60 }, { label: t('People met'), w: 20, right: true }], f.byPerson.map((r) => [r.name, String(r.n)]), { size: 7.8 });
  }

  // ---- 4. the list of the documents that follow
  heading(t('List of documents'));
  table([{ label: t('Appendix'), w: 11 }, { label: t('Cost'), w: 7 }, { label: t('Document'), w: 18 }, { label: t('File'), w: 44 }, { label: t('Pages'), w: 20, right: true }],
    d.docs.map((x) => [String(x.no), String(x.costNo), docLabel(x.docType), x.name, pagesOf(x)]), { empty: t('No documents uploaded.') });

  // the footer of every page we wrote: the page number of the finished file
  const range = doc.bufferedPageRange();
  for (let i = 0; i < range.count; i++) {
    doc.switchToPage(range.start + i);
    doc.font(F.r).fontSize(7).fillColor(STEEL).text(`${COMPANY_ADDRESS_LINE}   ·   ${t('Page {n} of {t}', { n: i + 1, t: total ?? '…' })}`, L0, PH - 26, { width: CW, align: 'center', lineBreak: false });
  }
  const pages = range.count;
  doc.end();
  return done.then((buf) => ({ buf, pages }));
}

// the pictures, one per page, scaled to fit, with what they are on top
function renderImages(d: Data, lang: Lang, total: number): Promise<Buffer | null> {
  const imgs = d.docs.filter((x) => x.kind === 'image');
  if (!imgs.length) return Promise.resolve(null);
  const t = tr(lang);
  const doc = new PDFDocument({ size: 'A4', margin: 0, autoFirstPage: false });
  const chunks: Buffer[] = [];
  doc.on('data', (b: Buffer) => chunks.push(b));
  const done = new Promise<Buffer>((resolve, reject) => { doc.on('end', () => resolve(Buffer.concat(chunks))); doc.on('error', reject); });
  registerDesignFonts(doc);
  for (const x of imgs) {
    const land = x.img!.w > x.img!.h * 1.15;
    const W = land ? PH : PW, H = land ? PW : PH;
    doc.addPage({ size: 'A4', layout: land ? 'landscape' : 'portrait', margin: 0 });
    doc.font(F.b).fontSize(8).fillColor(NAVY).text(`${t('Appendix')} ${x.no}  ·  ${t('Cost')} ${x.costNo}  ·  ${t(DOC_LABEL[x.docType])}`, 24, 16, { width: W - 48, lineBreak: false, ellipsis: true });
    doc.font(F.r).fontSize(7).fillColor(STEEL).text(`${x.name}   ·   ${t('Page {n} of {t}', { n: x.start ?? 0, t: total })}`, 24, 28, { width: W - 48, lineBreak: false, ellipsis: true });
    doc.rect(24, 40, W - 48, 0.6).fill(SMOKE);
    doc.image(x.img!.buf, 24, 48, { fit: [W - 48, H - 48 - 24], align: 'center', valign: 'center' });
  }
  doc.end();
  return done;
}

export async function turqualityPdf(kind: EventKind, id: number, opt: { all: boolean; by: string; lang?: Lang; viewer?: Viewer; team?: boolean }): Promise<{ pdf: Buffer; name: string; pages: number }> {
  const lang: Lang = opt.lang === 'tr' ? 'tr' : 'en';
  const d = collect(kind, id, opt.all, opt.viewer, lang, !!opt.team);
  await load(d.docs);
  const place = (first: number) => { let at = first + 1; for (const x of d.docs) { x.start = undefined; if (x.kind === 'pdf' || x.kind === 'image') { x.start = at; at += x.pages; } } return at - 1; };
  // the pages we write say where each document starts, which depends on how many pages we wrote: measure, then write again
  let sum = await renderSummary(d, lang, opt.by, null);
  let total = place(sum.pages);
  for (let i = 0; i < 3; i++) {
    const again = await renderSummary(d, lang, opt.by, total);
    const same = again.pages === sum.pages;
    sum = again;
    total = place(sum.pages);
    if (same) break;
  }
  const out = await PdfLib.create();
  out.setTitle(`${tr(lang)('Turquality report')} - ${d.title}`); out.setAuthor('TECE'); out.setCreator('TECE CRM'); out.setProducer('TECE CRM');
  const head = await PdfLib.load(sum.buf);
  for (const p of await out.copyPages(head, head.getPageIndices())) out.addPage(p);
  const imgBuf = await renderImages(d, lang, total);
  const imgs = imgBuf ? await PdfLib.load(imgBuf) : null;
  const font = await out.embedFont(StandardFonts.Helvetica);
  const t = tr(lang);
  let imgAt = 0;
  for (const x of d.docs) {
    if (x.kind === 'image' && imgs) { const [p] = await out.copyPages(imgs, [imgAt++]); out.addPage(p); continue; }
    if (x.kind !== 'pdf' || !x.pdf) continue;
    let pages;
    try { pages = await out.copyPages(x.pdf, x.pdf.getPageIndices()); } catch (e) { console.warn('Turquality report: could not copy', x.rel, e); continue; }
    pages.forEach((p, k) => {
      out.addPage(p);
      // a small label at the foot of each copied page: which appendix, which page of the whole file (on a white strip, so it reads on any page)
      const label = ascii(`${t('Appendix')} ${x.no} · ${t('Cost')} ${x.costNo} · ${t(DOC_LABEL[x.docType])} · ${x.name} · ${k + 1}/${x.pages}  —  ${t('Page {n} of {t}', { n: (x.start ?? 0) + k, t: total })}`).slice(0, 150);
      // on a page shown turned (/Rotate), the label goes to the corner that is bottom-left as the page is seen, written the right way up
      const box = p.getCropBox();
      const rot = (((p.getRotation().angle || 0) % 360) + 360) % 360;
      const turned = rot === 90 || rot === 270;
      const vw = turned ? box.height : box.width;
      const at = (lx: number, ly: number) => rot === 90 ? { x: box.x + box.width - ly, y: box.y + lx } : rot === 180 ? { x: box.x + box.width - lx, y: box.y + box.height - ly } : rot === 270 ? { x: box.x + ly, y: box.y + box.height - lx } : { x: box.x + lx, y: box.y + ly };
      const size = 6.5;
      const w = Math.min(font.widthOfTextAtSize(label, size) + 8, vw - 8);
      p.drawRectangle({ ...at(4, 3), width: w, height: size + 5, color: rgb(1, 1, 1), opacity: 0.85, rotate: degrees(rot) });
      p.drawText(label, { ...at(8, 6), size, font, color: rgb(0.09, 0.14, 0.24), maxWidth: vw - 16, rotate: degrees(rot) });
    });
  }
  const pdf = Buffer.from(await out.save());
  const safe = d.title.replace(/[\\/:*?"<>|\r\n]+/g, ' ').trim().slice(0, 80) || (kind === 'trip' ? 'Trip' : 'Fair');
  return { pdf, name: `Turquality - ${safe}.pdf`, pages: out.getPageCount() };
}

// the list of the costs of one trip / fair as Excel (for accounting or the consultant)
export async function eventExpensesXlsx(kind: EventKind, id: number): Promise<{ xlsx: Buffer; name: string }> {
  const d = collect(kind, id, true);
  const wb = new ExcelJS.Workbook(); wb.creator = 'TECE CRM';
  const ws = wb.addWorksheet('Harcamalar');
  const border = { top: { style: 'thin' as const, color: { argb: 'FFD0D0D0' } }, left: { style: 'thin' as const, color: { argb: 'FFD0D0D0' } }, bottom: { style: 'thin' as const, color: { argb: 'FFD0D0D0' } }, right: { style: 'thin' as const, color: { argb: 'FFD0D0D0' } } };
  ws.getCell('A1').value = `${d.title}${d.from ? `  (${d.from}${d.to && d.to !== d.from ? ' – ' + d.to : ''})` : ''}`; ws.getCell('A1').font = { bold: true, size: 13, name: 'Arial' };
  ws.getCell('A2').value = [d.people.join(', '), d.countries.join(', ')].filter(Boolean).join('  ·  '); ws.getCell('A2').font = { size: 10, name: 'Arial', color: { argb: 'FF5E6676' } };
  const cols = ['No', 'Tarih', 'Harcama türü', 'Belge türü', 'Tedarikçi', 'Açıklama', 'Fatura No', 'Para Birimi', 'Tutar', 'Kur (₺/€)', 'Tutar (₺)', 'Tutar (€)', 'Turquality', 'Belgeler', 'Giren'];
  const hr = ws.getRow(4); hr.values = cols;
  hr.eachCell((c) => { c.font = { bold: true, size: 10, name: 'Arial' }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFFF00' } }; c.border = border; c.alignment = { wrapText: true, vertical: 'middle' }; });
  [5, 12, 26, 20, 24, 36, 14, 8, 14, 9, 14, 14, 10, 40, 18].forEach((w, i) => { ws.getColumn(i + 1).width = w; });
  const trWords = tr('tr');
  d.costs.forEach((c, i) => {
    const row = ws.getRow(5 + i);
    row.values = [c.no, new Date(`${c.date}T00:00:00Z`), trWords(EVENT_CATEGORIES[kind].find((x) => x.key === c.category)?.label ?? c.category), trWords(DOC_LABEL[c.docType]), c.supplier, c.description, c.invoiceNo, c.currency, c.amount, c.rate, c.try, c.eur, c.turquality ? 'Evet' : 'Hayır', c.docs.map((x) => x.name).join(', '), c.by] as ExcelJS.CellValue[];
    row.eachCell({ includeEmpty: true }, (cell) => { cell.border = border; cell.font = { size: 10, name: 'Arial' }; });
    row.getCell(2).numFmt = 'dd.mm.yyyy'; [9, 11, 12].forEach((k) => { row.getCell(k).numFmt = '#,##0.00;(#,##0.00);-'; });
  });
  const tot = ws.getRow(5 + d.costs.length);
  tot.getCell(1).value = 'TOPLAM'; tot.getCell(11).value = d.try; tot.getCell(12).value = d.eur;
  tot.eachCell({ includeEmpty: true }, (cell) => { cell.font = { bold: true, size: 10, name: 'Arial' }; cell.border = border; });
  [11, 12].forEach((k) => { tot.getCell(k).numFmt = '#,##0.00'; });
  ws.views = [{ state: 'frozen', ySplit: 4 }];
  const safe = d.title.replace(/[\\/:*?"<>|\r\n]+/g, ' ').trim().slice(0, 80) || 'Harcamalar';
  return { xlsx: Buffer.from(await wb.xlsx.writeBuffer()), name: `Harcamalar - ${safe}.xlsx` };
}
