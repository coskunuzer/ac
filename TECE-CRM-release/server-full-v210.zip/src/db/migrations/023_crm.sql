-- The app as a simple CRM.

-- Who reports to whom: a manager sees what their team did each day.
ALTER TABLE users ADD COLUMN manager_id INTEGER;
-- The offer design this person prefers ('' = the company's choice): 'tece' (new) or 'classic' (as in Excel).
ALTER TABLE users ADD COLUMN offer_style TEXT;

-- Per customer: the offer design to use for them, where the customer is in the pipeline, their web site,
-- and what the lead database knew about them (tier, score, business type, suppliers ...).
ALTER TABLE cards ADD COLUMN offer_style TEXT;
-- NULL = met at a fair (as before); otherwise lead / contacted / interested / quoted / customer / lost.
ALTER TABLE cards ADD COLUMN stage TEXT;
ALTER TABLE cards ADD COLUMN website TEXT;
ALTER TABLE cards ADD COLUMN lead_info TEXT;
CREATE INDEX IF NOT EXISTS idx_cards_stage ON cards(stage);
CREATE INDEX IF NOT EXISTS idx_cards_company ON cards(company);
CREATE INDEX IF NOT EXISTS idx_cards_country ON cards(country);
CREATE INDEX IF NOT EXISTS idx_cards_person ON cards(person);

-- Everything people do: notes (with photos), calls, visits, e-mails and offers sent, new customers.
-- It is the source of the daily team report.
CREATE TABLE IF NOT EXISTS activities (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  card_id INTEGER,
  type TEXT NOT NULL,
  text TEXT,
  photos TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_activities_user_day ON activities(user_id, created_at);
CREATE INDEX IF NOT EXISTS idx_activities_card ON activities(card_id, created_at);
