import { Router } from 'express';
import { db } from '../db/connection';
import { requireAdmin, requireAuth, type AuthedRequest } from '../middleware/auth';
import { userModel } from '../models/userModel';

// The staff's clicks and pages, kept so the admin can download them (for a better design). The page of a record is stored without its number; no typed text is ever stored.
const router = Router();
router.use(requireAuth);

const KINDS = new Set(['click', 'view', 'dead', 'rage', 'error', 'api_error', 'slow', 'key']);
const clip = (v: unknown, n: number) => String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, n);
let lastPrune = 0;

router.post('/events', (req: AuthedRequest, res) => {
  const list = Array.isArray(req.body?.events) ? (req.body.events as Record<string, unknown>[]).slice(0, 120) : [];
  const ins = db.prepare('INSERT INTO ux_events (user_id, session, at, kind, route, target, extra) VALUES (?, ?, ?, ?, ?, ?, ?)');
  let n = 0;
  db.exec('BEGIN');
  try {
    for (const e of list) {
      const kind = clip(e.kind, 12);
      if (!KINDS.has(kind)) continue;
      const at = /^\d{4}-\d{2}-\d{2}T/.test(String(e.at)) ? String(e.at).slice(0, 24) : new Date().toISOString();
      const extra = e.extra && typeof e.extra === 'object' ? JSON.stringify(e.extra).slice(0, 400) : null;
      ins.run(req.user!.id, clip(req.body?.session, 24), at, kind, clip(e.route, 120), clip(e.target, 90), extra);
      n += 1;
    }
    db.exec('COMMIT');
  } catch (err) { db.exec('ROLLBACK'); console.error('UX log failed:', err); return res.status(500).json({ error: 'Could not save' }); }
  // the log keeps 120 days
  if (Date.now() - lastPrune > 6 * 3600 * 1000) { lastPrune = Date.now(); db.prepare("DELETE FROM ux_events WHERE at < datetime('now', '-120 day')").run(); }
  res.json({ ok: true, saved: n });
});

const since = (days: number) => new Date(Date.now() - days * 86_400_000).toISOString();
const daysOf = (v: unknown) => Math.min(120, Math.max(1, parseInt(String(v ?? '14'), 10) || 14));

// the picture: where people click most, where they click in vain, where it breaks or is slow
router.get('/summary', requireAdmin, (req, res) => {
  const s = since(daysOf(req.query.days));
  const q = (sql: string, ...p: string[]) => db.prepare(sql).all(...p) as Record<string, unknown>[];
  res.json({
    days: daysOf(req.query.days),
    totals: q('SELECT kind, COUNT(*) AS n FROM ux_events WHERE at >= ? GROUP BY kind ORDER BY n DESC', s),
    people: q('SELECT user_id, COUNT(*) AS n, COUNT(DISTINCT substr(at, 1, 10)) AS days, MAX(at) AS last FROM ux_events WHERE at >= ? GROUP BY user_id ORDER BY n DESC', s).map((r) => ({ ...r, name: r.user_id ? userModel.findById(Number(r.user_id))?.display_name ?? `#${r.user_id}` : '—' })),
    pages: q("SELECT route, COUNT(*) AS n FROM ux_events WHERE at >= ? AND kind = 'view' GROUP BY route ORDER BY n DESC LIMIT 25", s),
    topClicks: q("SELECT route, target, COUNT(*) AS n FROM ux_events WHERE at >= ? AND kind = 'click' AND target != '' GROUP BY route, target ORDER BY n DESC LIMIT 30", s),
    dead: q("SELECT route, target, COUNT(*) AS n FROM ux_events WHERE at >= ? AND kind = 'dead' GROUP BY route, target ORDER BY n DESC LIMIT 20", s),
    rage: q("SELECT route, target, COUNT(*) AS n FROM ux_events WHERE at >= ? AND kind = 'rage' GROUP BY route, target ORDER BY n DESC LIMIT 20", s),
    errors: q("SELECT route, target, COUNT(*) AS n FROM ux_events WHERE at >= ? AND kind IN ('error','api_error') GROUP BY route, target ORDER BY n DESC LIMIT 20", s),
    slow: q("SELECT route, target, COUNT(*) AS n, ROUND(AVG(json_extract(extra, '$.ms'))) AS avg_ms FROM ux_events WHERE at >= ? AND kind = 'slow' GROUP BY route, target ORDER BY n DESC LIMIT 20", s),
  });
});

// the download: a summary and the events, as JSON (to give to the one who improves the app) or CSV
// the pictures: activity per day, the busy hours, what kind of events, where it hurts, and where people click on a page (a heat map)
router.get('/charts', requireAdmin, (req, res) => {
  const s = since(daysOf(req.query.days));
  const route = clip(req.query.route, 120);
  const daily = db.prepare("SELECT substr(datetime(at, '+3 hours'), 1, 10) AS d, COUNT(*) AS n, SUM(CASE WHEN kind IN ('dead','rage','error','api_error','slow') THEN 1 ELSE 0 END) AS bad FROM ux_events WHERE at >= ? GROUP BY d ORDER BY d").all(s) as { d: string; n: number; bad: number }[];
  const hours = db.prepare("SELECT CAST(strftime('%w', datetime(at, '+3 hours')) AS INTEGER) AS wd, CAST(strftime('%H', datetime(at, '+3 hours')) AS INTEGER) AS h, COUNT(*) AS n FROM ux_events WHERE at >= ? AND kind IN ('click','view') GROUP BY wd, h").all(s) as { wd: number; h: number; n: number }[];
  const kinds = db.prepare('SELECT kind, COUNT(*) AS n FROM ux_events WHERE at >= ? GROUP BY kind ORDER BY n DESC').all(s) as { kind: string; n: number }[];
  const friction = db.prepare("SELECT route, SUM(CASE WHEN kind = 'dead' THEN 1 ELSE 0 END) AS dead, SUM(CASE WHEN kind = 'rage' THEN 1 ELSE 0 END) AS rage, SUM(CASE WHEN kind IN ('error','api_error') THEN 1 ELSE 0 END) AS errors, SUM(CASE WHEN kind = 'slow' THEN 1 ELSE 0 END) AS slow, SUM(CASE WHEN kind = 'view' THEN 1 ELSE 0 END) AS views FROM ux_events WHERE at >= ? AND route != '' GROUP BY route HAVING dead + rage + errors + slow > 0 ORDER BY dead + rage * 2 + errors * 2 + slow DESC LIMIT 10").all(s) as { route: string; dead: number; rage: number; errors: number; slow: number; views: number }[];
  const people = db.prepare("SELECT COALESCE(u.display_name, u.username, '?') AS name, COUNT(*) AS n FROM ux_events e LEFT JOIN users u ON u.id = e.user_id WHERE e.at >= ? GROUP BY e.user_id ORDER BY n DESC LIMIT 10").all(s) as { name: string; n: number }[];
  const routes = db.prepare("SELECT route, COUNT(*) AS n FROM ux_events WHERE at >= ? AND kind IN ('click','dead','rage') AND route != '' GROUP BY route ORDER BY n DESC LIMIT 25").all(s) as { route: string; n: number }[];
  const pick = route || routes[0]?.route || '';
  const clicks: { x: number; y: number; bad: number }[] = [];
  if (pick) {
    const rows = db.prepare("SELECT kind, extra FROM ux_events WHERE at >= ? AND route = ? AND kind IN ('click','dead','rage') AND extra IS NOT NULL LIMIT 4000").all(s, pick) as { kind: string; extra: string }[];
    for (const r of rows) { try { const e = JSON.parse(r.extra) as { x?: number; y?: number }; if (Number.isFinite(e.x) && Number.isFinite(e.y)) clicks.push({ x: Math.round(e.x as number), y: Math.round(e.y as number), bad: r.kind === 'click' ? 0 : 1 }); } catch { /* not a click with a place */ } }
  }
  res.json({ daily, hours, kinds, friction, people, routes, route: pick, clicks });
});

router.get('/export', requireAdmin, (req, res) => {
  const days = daysOf(req.query.days);
  const rows = db.prepare('SELECT id, user_id, session, at, kind, route, target, extra FROM ux_events WHERE at >= ? ORDER BY id DESC LIMIT 30000').all(since(days)) as { id: number; user_id: number | null; session: string | null; at: string; kind: string; route: string | null; target: string | null; extra: string | null }[];
  const names = new Map<number, string>();
  const who = (id: number | null) => (id ? names.get(id) ?? (names.set(id, userModel.findById(id)?.display_name ?? `#${id}`), names.get(id)!) : '');
  const stamp = new Date().toISOString().slice(0, 10);
  if (req.query.format === 'csv') {
    const q = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`;
    const csv = ['at,user,session,kind,route,target,extra', ...rows.map((r) => [r.at, who(r.user_id), r.session, r.kind, r.route, r.target, r.extra].map(q).join(','))].join('\r\n');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="tece-ux-log-${stamp}.csv"`);
    return res.send('﻿' + csv);
  }
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="tece-ux-log-${stamp}.json"`);
  res.send(JSON.stringify({
    about: 'TECE CRM usage log: what staff clicked and where it broke. No typed text is stored. route = the page (record numbers replaced), target = the label of what was clicked, kinds: view, click, dead (a click on something that is not a button), rage (3+ quick clicks on one spot), error / api_error (a failure), slow (an answer over 3 seconds).',
    days, count: rows.length,
    events: rows.map((r) => ({ at: r.at, user: who(r.user_id), session: r.session, kind: r.kind, route: r.route, target: r.target, ...(r.extra ? { extra: JSON.parse(r.extra) } : {}) })),
  }, null, 1));
});

router.delete('/events', requireAdmin, (req, res) => {
  const days = Math.max(0, parseInt(String(req.query.olderThanDays ?? '0'), 10) || 0);
  const r = db.prepare('DELETE FROM ux_events WHERE at < ?').run(since(days));
  res.json({ deleted: Number(r.changes) });
});

export default router;
