import countries from 'i18n-iso-countries';
import trNames from 'i18n-iso-countries/langs/tr.json';
import enNames from 'i18n-iso-countries/langs/en.json';
import { db } from '../db/connection';
import { cardModel } from '../models/cardModel';
import { exhibitionModel } from '../models/exhibitionModel';
import { countryModel } from '../models/countryModel';
import { filterVisible, type Viewer } from './visibility';
import { statementItems } from './perfAnalytics';

countries.registerLocale(trNames);
countries.registerLocale(enNames);

// Accounts that are in the ledger (a tab of the current-account workbook) but have no customer card in the CRM: the search could not find them.
const norm = (s: string) => s.toLocaleLowerCase('tr').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/ı/g, 'i').replace(/[^a-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim();

let trToEn: Map<string, string> | null = null;
function countryFromTurkish(name: string): string | null {
  if (!trToEn) {
    trToEn = new Map();
    for (const iso of Object.keys(countries.getAlpha2Codes())) { const tr = countries.getName(iso, 'tr'), en = countries.getName(iso, 'en'); if (tr && en) trToEn.set(norm(tr), en); }
    for (const [a, b] of [['abd', 'United States'], ['amerika', 'United States'], ['ingiltere', 'United Kingdom'], ['bosna', 'Bosnia and Herzegovina'], ['kibris', 'Cyprus'], ['kktc', 'Cyprus'], ['bae', 'United Arab Emirates'], ['irak', 'Iraq'], ['urdun', 'Jordan']]) trToEn.set(a, b);
  }
  return trToEn.get(norm(name)) ?? null;
}

// "SCHWARTZ VRENA - BOLİVYA" is the company and the country (in Turkish) after the dash
export function splitSheet(sheet: string): { company: string; country: string | null } {
  const m = sheet.match(/^(.*?)\s*[-–—]\s*([^-–—]+)$/);
  if (m) { const c = countryFromTurkish(m[2]); if (c) return { company: m[1].trim(), country: c }; }
  return { company: sheet.replace(/^\(SHT\)\s*/i, '').trim(), country: null };
}

export interface LedgerOnly { sheet: string; company: string; country: string | null; balance: number; currency: string; last: string | null; sap: string | null }

export function ledgerOnly(q: string, limit = 6): LedgerOnly[] {
  const words = norm(q).split(' ').filter((w) => w.length >= 3);
  if (!words.length) return [];
  const rows = db.prepare(`SELECT f.sheet_name, f.balance, f.currency, f.last_transaction_date last, a.sap_no, a.card_id FROM customer_financial_summary f LEFT JOIN customer_aliases a ON a.sheet_name = f.sheet_name`).all() as { sheet_name: string; balance: number; currency: string; last: string | null; sap_no: string | null; card_id: number | null }[];
  const hasCard = db.prepare('SELECT 1 FROM cards WHERE id = ?'), bySap = db.prepare('SELECT 1 FROM cards WHERE TRIM(sap) = ? LIMIT 1');
  const out: LedgerOnly[] = [];
  for (const r of rows) {
    const n = norm(r.sheet_name);
    if (!words.every((w) => n.includes(w))) continue;
    if ((r.card_id && hasCard.get(r.card_id)) || (r.sap_no && bySap.get(String(r.sap_no).trim()))) continue; // it has a card: the normal search finds that
    const sp = splitSheet(r.sheet_name);
    out.push({ sheet: r.sheet_name, company: sp.company, country: sp.country, balance: Math.round(r.balance * 100) / 100, currency: r.currency, last: r.last, sap: r.sap_no });
  }
  return out.sort((a, b) => Math.abs(b.balance) - Math.abs(a.balance)).slice(0, limit);
}

// a customer card for a ledger account (admin): the company and country come from the name of the tab; a SAP number can be given to match the ledger to it
export function createCardFromLedger(sheet: string, sap: string, userId: number): { cardId: number; company: string } {
  const f = db.prepare('SELECT sheet_name FROM customer_financial_summary WHERE sheet_name = ?').get(sheet);
  if (!f) throw new Error('This ledger tab does not exist.');
  const sapNo = sap.replace(/\D/g, '');
  if (sap && !/^\d{6,}$/.test(sapNo)) throw new Error('A SAP number has at least 6 digits.');
  if (sapNo && db.prepare('SELECT id FROM cards WHERE TRIM(sap) = ?').get(sapNo)) throw new Error('A customer card with this SAP number already exists.');
  const sp = splitSheet(sheet);
  const domestic = sapNo.startsWith('1201');
  const listName = 'Customer database';
  const ex = exhibitionModel.listAll().find((e) => e.name.trim().toLowerCase() === listName.toLowerCase()) ?? exhibitionModel.create({ name: listName, location: 'All customers and leads', createdBy: userId });
  const owner = sp.country ? countryModel.findByCountry(sp.country)?.responsible ?? null : null;
  const card = cardModel.createFromExtraction({
    exhibitionId: ex.id, uploadedBy: userId, imagePath: '',
    fields: { name: null, company: sp.company, address: null, country: sp.country ?? (domestic ? 'Turkey' : null), tel: null, email: null, position: null, interestedIn: null, workArea: null, date: null, person: owner, rate: null, notes: `Created from the ledger tab "${sheet}".` },
    fieldStatus: {} as never, extractionModel: 'ledger-tab', status: 'confirmed', badgeId: `ledger:${sheet}`.slice(0, 80), stage: 'customer', market: domestic ? 'domestic' : 'export', source: 'database', sap: sapNo || null,
  } as never);
  if (sapNo) db.prepare("INSERT INTO customer_aliases (sheet_name, sap_no, card_id, is_manually_verified, how) VALUES (?, ?, ?, 1, 'chosen by an admin') ON CONFLICT(sheet_name) DO UPDATE SET sap_no = excluded.sap_no, card_id = excluded.card_id, is_manually_verified = 1, how = excluded.how").run(sheet, sapNo, card.id);
  return { cardId: card.id, company: sp.company };
}

// ---- invoice numbers: "TTE2026000000157" is written in the description of a ledger entry ("Çıkış TTE2026000000157")
export interface InvoiceHit { invoice: string; date: string; amount: number; currency: string; kind: 'invoice' | 'payment'; sheet: string; cardId: number | null; company: string; country: string | null; sap: string | null; open: boolean | null; daysOver: number | null }

const canSeeLedger = (u: { role: string; perms?: { money: string[] } | null }) => u.role === 'admin' || !u.perms || u.perms.money.includes('ledger');

export function invoiceFind(viewer: Viewer & { role: string; perms?: { money: string[] } | null }, q: string, limit = 6): InvoiceHit[] {
  const tok = q.replace(/\s+/g, '').toUpperCase();
  if (tok.length < 5 || (tok.match(/\d/g) ?? []).length < 4 || /[^A-Z0-9./-]/.test(tok) || !canSeeLedger(viewer)) return [];
  const esc = tok; // only letters, digits and . / - are allowed above, so there is nothing to escape
  const rows = db.prepare(`SELECT sheet_name, tx_date, description, debit, credit, currency FROM ledger_transactions WHERE UPPER(REPLACE(description, ' ', '')) LIKE ? ORDER BY tx_date DESC LIMIT 40`).all(`%${esc}%`) as { sheet_name: string; tx_date: string; description: string; debit: number | null; credit: number | null; currency: string }[];
  const alias = db.prepare('SELECT sap_no, card_id FROM customer_aliases WHERE sheet_name = ?');
  const byId = db.prepare('SELECT id, company, name, country, sap, stage, market, person, uploaded_by FROM cards WHERE id = ?');
  const bySap = db.prepare('SELECT id, company, name, country, sap, stage, market, person, uploaded_by FROM cards WHERE TRIM(sap) = ? LIMIT 1');
  const open = new Map<string, { items: { date: string; description: string; daysOver: number }[] }>();
  const out: InvoiceHit[] = [];
  for (const r of rows) {
    const a = alias.get(r.sheet_name) as { sap_no: string | null; card_id: number | null } | undefined;
    const sap = a?.sap_no ? String(a.sap_no).trim() : null;
    const card = (a?.card_id ? byId.get(a.card_id) : null) ?? (sap ? bySap.get(sap) : null) ?? null;
    const c = card as { id: number; company: string | null; name: string | null; country: string | null } | null;
    if (viewer.role !== 'admin') { if (!c || !filterVisible(viewer, [card as never]).length) continue; } // somebody else's customer is not shown
    let isOpen: boolean | null = null, daysOver: number | null = null;
    if (sap && r.debit) {
      if (!open.has(sap)) { try { open.set(sap, statementItems(sap)); } catch { open.set(sap, { items: [] }); } }
      const it = open.get(sap)!.items.find((i) => i.description === r.description && i.date === r.tx_date);
      isOpen = !!it; daysOver = it ? it.daysOver : null;
    }
    const sp = splitSheet(r.sheet_name);
    out.push({ invoice: r.description.match(/[A-Za-z]{2,4}\d{7,}/)?.[0] ?? r.description, date: r.tx_date, amount: Math.round(((r.debit ?? r.credit) || 0) * 100) / 100, currency: r.currency, kind: r.debit ? 'invoice' : 'payment', sheet: r.sheet_name, cardId: c?.id ?? null, company: c?.company || c?.name || sp.company, country: c?.country ?? sp.country, sap, open: isOpen, daysOver });
    if (out.length >= limit) break;
  }
  return out;
}
