import { db } from '../db/connection';

export interface Todo {
  id: number;
  userId: number;
  cardId: number | null;
  text: string;
  dueDate: string; // YYYY-MM-DD
  doneAt: string | null;
  company: string | null;
  contact: string | null;
}

interface Row { id: number; user_id: number; card_id: number | null; text: string; due_date: string; done_at: string | null; company: string | null; contact: string | null }

const SELECT = `SELECT t.id, t.user_id, t.card_id, t.text, t.due_date, t.done_at, c.company AS company, c.name AS contact
                FROM todos t LEFT JOIN cards c ON c.id = t.card_id`;
const toTodo = (r: Row): Todo => ({ id: r.id, userId: r.user_id, cardId: r.card_id, text: r.text, dueDate: r.due_date, doneAt: r.done_at, company: r.company, contact: r.contact });

// The day that is N business days from a day (weekends skipped): "follow up in 3 business days".
export function addBusinessDays(from: string, n: number): string {
  const d = new Date(`${from}T12:00:00Z`);
  let left = Math.max(0, Math.min(60, Math.round(n)));
  while (left > 0) {
    d.setUTCDate(d.getUTCDate() + 1);
    const dow = d.getUTCDay();
    if (dow !== 0 && dow !== 6) left -= 1;
  }
  return d.toISOString().slice(0, 10);
}

export const todayIstanbul = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });

export const todoModel = {
  // an open to-do of the same person, for the same customer, with the same title (case and spaces ignored)
  findOpenDuplicate(input: { userId: number; cardId: number | null; text: string }): Todo | undefined {
    const norm = input.text.replace(/\s+/g, ' ').trim().toLowerCase();
    const rows = db.prepare(`${SELECT} WHERE t.user_id = ? AND t.done_at IS NULL AND COALESCE(t.card_id, 0) = ?`).all(input.userId, input.cardId ?? 0) as unknown as Row[];
    const hit = rows.find((r) => r.text.replace(/\s+/g, ' ').trim().toLowerCase() === norm.slice(0, 300));
    return hit && toTodo(hit);
  },
  // never a second open to-do with the same customer and title: the one that is there is returned
  add(input: { userId: number; cardId: number | null; text: string; dueDate: string }): Todo {
    const same = todoModel.findOpenDuplicate(input);
    if (same) return same;
    const r = db.prepare('INSERT INTO todos (user_id, card_id, text, due_date) VALUES (?, ?, ?, ?)').run(input.userId, input.cardId, input.text.slice(0, 300), input.dueDate);
    return todoModel.find(Number(r.lastInsertRowid))!;
  },
  find(id: number): Todo | undefined {
    const r = db.prepare(`${SELECT} WHERE t.id = ?`).get(id) as Row | undefined;
    return r && toTodo(r);
  },
  // the open to-dos of one person, and the ones done in the last week (for the calendar)
  forUser(userId: number, from?: string, to?: string): Todo[] {
    const rows = db
      .prepare(`${SELECT} WHERE t.user_id = @userId AND (t.done_at IS NULL OR t.done_at >= date('now', '-7 day'))${from ? ' AND t.due_date >= @from' : ''}${to ? ' AND t.due_date <= @to' : ''} ORDER BY t.due_date, t.id`)
      .all({ userId, ...(from ? { from } : {}), ...(to ? { to } : {}) }) as unknown as Row[];
    return rows.map(toTodo);
  },
  done(id: number, done: boolean): void {
    db.prepare(`UPDATE todos SET done_at = ${done ? "datetime('now')" : 'NULL'} WHERE id = ?`).run(id);
  },
  change(id: number, input: { dueDate?: string; text?: string }): void {
    if (input.dueDate) db.prepare('UPDATE todos SET due_date = ? WHERE id = ?').run(input.dueDate, id);
    if (input.text) db.prepare('UPDATE todos SET text = ? WHERE id = ?').run(input.text, id);
  },
  delete(id: number): void {
    db.prepare('DELETE FROM todos WHERE id = ?').run(id);
  },
};
