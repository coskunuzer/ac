import { db } from '../db/connection';
import type { CardRow } from '../models/cardModel';

// What a person at a company is for. A statement goes to the finance person, an offer to purchasing, a dispatch notice to logistics. A company with one person
// asks for nothing: that person gets everything. Nobody with the role = the main contact, and the send screen says so.
export const ROLES = ['purchasing', 'finance', 'management', 'technical', 'logistics', 'other'] as const;
export type Role = (typeof ROLES)[number];

export const cleanRoles = (v: unknown): string | null => {
  const list = (Array.isArray(v) ? v : typeof v === 'string' ? v.split(',') : []).map((x) => String(x).trim().toLowerCase()).filter((x): x is Role => (ROLES as readonly string[]).includes(x));
  return list.length ? [...new Set(list)].join(',') : null;
};
export const rolesOf = (s: string | null | undefined): Role[] => (s ?? '').split(',').map((x) => x.trim()).filter((x): x is Role => (ROLES as readonly string[]).includes(x));

const emails = (s: string | null | undefined): string[] => (s ?? '').split(/[,;\s]+/).map((x) => x.trim()).filter((x) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(x));

export interface Recipient { emails: string[]; names: string[]; // who
  basis: 'only-person' | 'role' | 'main-contact'; // why them
  people: number }

// who gets a message of this kind: the people marked with the role (and an e-mail), else the main contact; with one person, that person
export function recipientsFor(card: CardRow, role: Role): Recipient {
  const main = { name: [card.name, card.last_name].filter(Boolean).join(' '), emails: emails(card.email), roles: rolesOf((card as unknown as { contact_roles?: string | null }).contact_roles) };
  const others = (db.prepare('SELECT name, last_name, email, roles FROM card_contacts WHERE card_id = ? ORDER BY id').all(card.id) as { name: string | null; last_name: string | null; email: string | null; roles: string | null }[])
    .map((c) => ({ name: [c.name, c.last_name].filter(Boolean).join(' '), emails: emails(c.email), roles: rolesOf(c.roles) }));
  const all = [main, ...others].filter((p) => p.name || p.emails.length);
  if (all.length <= 1) return { emails: main.emails.length ? main.emails : (all[0]?.emails ?? []), names: all[0]?.name ? [all[0].name] : [], basis: 'only-person', people: all.length };
  const hit = all.filter((p) => p.roles.includes(role) && p.emails.length);
  if (hit.length) return { emails: [...new Set(hit.flatMap((p) => p.emails))], names: hit.map((p) => p.name).filter(Boolean), basis: 'role', people: all.length };
  return { emails: main.emails, names: main.name ? [main.name] : [], basis: 'main-contact', people: all.length };
}
