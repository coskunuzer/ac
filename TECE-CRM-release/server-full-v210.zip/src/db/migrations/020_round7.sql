-- A signature the person wrote or edited themselves (empty = the layout they chose)
ALTER TABLE users ADD COLUMN signature_text TEXT;

-- Feedback and a photo of the fair, printed at the top of every PDF report
ALTER TABLE exhibitions ADD COLUMN feedback TEXT;
ALTER TABLE exhibitions ADD COLUMN photo_path TEXT;

-- Why no offer is sent to this customer (already sent before, too small ...)
ALTER TABLE cards ADD COLUMN offer_skip_reason TEXT;
-- Pass this contact to the Bulgaria office (TECE Dekor Ltd): NULL = not decided (the AI's suggestion shows), 1 = yes, 0 = no
ALTER TABLE cards ADD COLUMN bulgaria INTEGER;

-- The standard thank-you text now says "{{follow_up_line}}" where it promised a follow-up, so the
-- wording can be seen and changed ("We will send you our offer ..." when one is wanted).
UPDATE email_templates
   SET body = replace(body, 'We will follow up shortly with any further information you asked for.', '{{follow_up_line}}')
 WHERE kind = 'thank_you' AND body LIKE '%We will follow up shortly with any further information you asked for.%';
