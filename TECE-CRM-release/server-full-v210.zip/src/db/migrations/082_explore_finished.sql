-- the places a person already finished today (so "next country" never offers them again)
ALTER TABLE daily_explore ADD COLUMN finished TEXT NOT NULL DEFAULT '';
