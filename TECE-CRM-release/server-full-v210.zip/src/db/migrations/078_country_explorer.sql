-- Country explorer: what is known about a country (public figures from the World Bank, an AI estimate of the furniture market, the AI's reading of our own
-- turnover) and the brainstorm notes of the sales people. The notes are only ever added, never changed or removed.
CREATE TABLE IF NOT EXISTS country_facts (
  iso TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  region TEXT,
  income_level TEXT,
  capital TEXT,
  population REAL,
  population_year TEXT,
  gni_per_capita REAL,
  gni_year TEXT,
  gdp REAL,
  gdp_year TEXT,
  wb_at TEXT,
  market_json TEXT,           -- the AI's estimate of the furniture / edgebanding market (marked as an estimate on the screen)
  market_at TEXT,
  market_by INTEGER,
  analysis_json TEXT,         -- the AI's reading of our own figures there
  analysis_at TEXT,
  analysis_by INTEGER
);

CREATE TABLE IF NOT EXISTS country_notes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  iso TEXT NOT NULL,
  country TEXT NOT NULL,
  user_id INTEGER,
  user_name TEXT,
  kind TEXT NOT NULL DEFAULT 'note',   -- note | idea | risk | plan
  text TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_country_notes_iso ON country_notes (iso, id);
