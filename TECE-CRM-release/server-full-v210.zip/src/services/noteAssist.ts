import { env } from '../config/env';
import { settingsModel } from '../models/settingsModel';
import type { CardRow } from '../models/cardModel';
import { blockedReason } from './aiGate';
import { LANGS, type Lang } from './translate';

// What the AI does with a note: reads handwriting from the photos of a note, and writes the e-mail "meeting notes as below" to the customer
// in the customer's language. Also the sample request that goes to production (the preparation list) and to shipping.

import { EDGEBAND_CONTEXT } from './edgebandingKnowledge';

const GEMINI_URL = process.env.GEMINI_BASE_URL || 'https://generativelanguage.googleapis.com/v1beta/models'; // (the gate sends it to DeepSeek)
const MODEL = 'gemini-3.6-flash';

export async function askJsonParts(parts: unknown[], schema: Record<string, unknown>, temperature = 0.3): Promise<Record<string, unknown> | null> {
  if (!env.geminiApiKey || blockedReason()) return null;
  try {
    const res = await fetch(`${GEMINI_URL}/${MODEL}:generateContent`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-goog-api-key': env.geminiApiKey },
      body: JSON.stringify({ contents: [{ role: 'user', parts }], generationConfig: { temperature, responseMimeType: 'application/json', responseSchema: schema } }),
      signal: AbortSignal.timeout(90000),
    });
    if (!res.ok) return null;
    const data = (await res.json()) as { candidates?: { content?: { parts?: { text?: string }[] } }[] };
    return JSON.parse((data.candidates?.[0]?.content?.parts ?? []).map((p) => p.text ?? '').join('')) as Record<string, unknown>;
  } catch {
    return null;
  }
}

// ---- a note written on paper: the photo is read ----------------------------------------------------------------------------------------
export async function readNotePhotos(images: { data: Buffer; mime: string }[]): Promise<string | null> {
  const parts: unknown[] = [
    { text: EDGEBAND_CONTEXT + '\n\nThese are photos of a handwritten or printed note taken by a salesperson of TECE (edgebanding for furniture panels) at a meeting or a fair. Write down exactly what is written, line by line, in the language it is written in. Keep names, numbers, sizes (mm), product names and dates exactly. Do not add anything and do not explain. Mark a word you cannot read as [?]. Answer as JSON {"text": "..."}.' },
    ...images.map((i) => ({ inlineData: { mimeType: i.mime, data: i.data.toString('base64') } })),
  ];
  const j = await askJsonParts(parts, { type: 'OBJECT', properties: { text: { type: 'STRING' } }, required: ['text'] }, 0.1);
  const t = j?.text ? String(j.text).trim() : '';
  return t || null;
}

// ---- the e-mail with the meeting notes -------------------------------------------------------------------------------------------------
const FALLBACK: Record<Lang, { subject: string; hello: (n: string) => string; intro: string; next: string; bye: (s: string) => string }> = {
  en: { subject: 'Notes of our meeting', hello: (n) => `Dear ${n},`, intro: 'Thank you for your time. The meeting notes are as below:', next: 'Please tell me if anything should be corrected or added.', bye: () => 'Best regards,' },
  ru: { subject: 'Итоги нашей встречи', hello: (n) => `Уважаемый(ая) ${n},`, intro: 'Благодарим за уделённое время. Ниже приведены заметки о встрече:', next: 'Пожалуйста, сообщите, если что-то нужно исправить или добавить.', bye: () => 'С уважением,' },
  tr: { subject: 'Görüşme notlarımız', hello: (n) => `Sayın ${n},`, intro: 'Ayırdığınız zaman için teşekkür ederiz. Görüşme notları aşağıdadır:', next: 'Düzeltilmesi veya eklenmesi gereken bir şey varsa lütfen bildirin.', bye: () => 'Saygılarımla,' },
  es: { subject: 'Notas de nuestra reunión', hello: (n) => `Estimado/a ${n}:`, intro: 'Gracias por su tiempo. Las notas de la reunión son las siguientes:', next: 'Por favor, dígame si hay algo que corregir o añadir.', bye: () => 'Saludos cordiales,' },
  fr: { subject: 'Notes de notre réunion', hello: (n) => `Cher/Chère ${n},`, intro: 'Merci pour votre temps. Les notes de la réunion sont les suivantes :', next: "Dites-moi s'il faut corriger ou ajouter quelque chose.", bye: () => 'Cordialement,' },
};

export interface MeetingMail { subject: string; body: string; ai: boolean }

export async function meetingNotesMail(card: Pick<CardRow, 'company' | 'name'>, note: string, lang: Lang, sender: string): Promise<MeetingMail> {
  const contact = card.name?.split(/\s+/)[0] || card.company || '';
  const j = await askJsonParts(
    [{ text: [
      EDGEBAND_CONTEXT,
      `You write an e-mail for ${sender}, a salesperson of TECE (a Turkish manufacturer of edgebanding for furniture panels: PVC, ABS, PP, melamine, veneer), to ${contact || 'the customer'}${card.company ? ` at ${card.company}` : ''}.`,
      `Write it in ${LANGS[lang]}. The salesperson's notes below may be shorthand and in Turkish or English. Turn them into a clear, polite e-mail that starts with the greeting, says the meeting notes are as below (in natural wording), then lists what was discussed and agreed as short bullet lines starting with "- ", and what happens next. Expand shorthand into full sentences (for example "send price, ABS PVC 22mm 44mm" becomes: we will send you our prices for ABS and PVC edgebanding in 22 mm and 44 mm). Use only what is in the notes: invent no prices, dates, promises or product codes. End with ONLY a short closing phrase such as "Best regards," in that language: do NOT write the sender's name, title or company after it, because the sender's own signature is added automatically. At most 160 words.`,
      'Notes:', note,
    ].join('\n') }],
    { type: 'OBJECT', properties: { subject: { type: 'STRING' }, body: { type: 'STRING' } }, required: ['subject', 'body'] },
  );
  if (j?.subject && j?.body) return { subject: String(j.subject).trim(), body: String(j.body).trim(), ai: true };
  const f = FALLBACK[lang];
  const lines = note.split(/\n+/).map((l) => l.trim()).filter(Boolean).map((l) => `- ${l.replace(/^[-•*]\s*/, '')}`);
  return { subject: f.subject, body: [f.hello(contact || card.company || ''), '', f.intro, '', ...lines, '', f.next, '', f.bye(sender)].join('\n'), ai: false };
}

// ---- the sample request ------------------------------------------------------------------------------------------------------------------
export const SAMPLE_CHOICES: Record<string, string> = {
  full: 'Full edgebanding collection',
  kronospan: 'Kronospan collection',
  egger: 'Egger collection',
  pvc: 'PVC collection',
  custom: 'Edgebanding sample (written below)',
};
export const CARRIERS = ['DHL', 'FedEx', 'UPS', 'TNT', 'Aras Kargo', 'MNG Kargo', 'Yurtiçi Kargo', 'PTT', 'Other'];
export const sampleRecipients = () => ({
  prep: settingsModel.get('sample_prep_email') || 'isimsek@tece.com.tr',
  ship: settingsModel.get('sample_ship_email') || 'gizem.keremer@tece.com.tr',
});

export function sampleMails(card: CardRow, items: string[], custom: string, carrier: string, note: string, sender: string): { prep: { subject: string; body: string }; ship: { subject: string; body: string } } {
  const who = card.company || card.name || `#${card.id}`;
  const list = items.map((k) => `- ${SAMPLE_CHOICES[k] ?? k}${k === 'custom' && custom ? `: ${custom}` : ''}`);
  const address = [card.address, card.country].filter(Boolean).join(', ') || '(adres kayıtta yok)';
  const contact = [[card.name, card.last_name].filter(Boolean).join(' '), card.position].filter(Boolean).join(', ');
  const phone = card.mobile || card.tel || '';
  const head = [`Müşteri: ${who}`, contact ? `İlgili kişi: ${contact}` : '', `Ülke: ${card.country ?? ''}`, phone ? `Telefon: ${phone}` : '', card.email ? `E-posta: ${card.email}` : '', `Talep eden: ${sender}`].filter(Boolean);
  return {
    prep: {
      subject: `Numune hazırlama talebi - ${who}`,
      body: ['Merhaba,', '', `${who} için aşağıdaki numunelerin hazırlanmasını rica ederim:`, '', ...list, note ? `\nNot: ${note}` : '', '', ...head, '', 'Hazır olduğunda lütfen Gizem Hanım\'a (sevkiyat) haber verin.', '', 'Teşekkürler.'].filter((l) => l !== null).join('\n'),
    },
    ship: {
      subject: `Numune gönderimi - ${who}${carrier ? ` (${carrier})` : ''}`,
      body: ['Merhaba,', '', `${who} için hazırlanacak numuneler ${carrier ? `${carrier} ile` : 'uygun bir kurye ile'} gönderilecek.`, carrier ? `Tercih edilen kurye: ${carrier}` : 'Kurye tercihi belirtilmedi.', '', 'Gönderilecek numuneler:', ...list, note ? `\nNot: ${note}` : '', '', `Teslimat adresi: ${address}`, ...head, '', 'Numuneler hazır olunca (hazırlayan: isimsek@tece.com.tr) gönderimi planlamanızı rica ederim.', '', 'Teşekkürler.'].join('\n'),
    },
  };
}
