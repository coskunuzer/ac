-- "My day": the work sessions a person sets in their account (for example 10:00-11:00 and 14:00-15:00), and a log of what was opened and ticked off each day (kept, never deleted).
ALTER TABLE users ADD COLUMN work_windows TEXT;
CREATE TABLE IF NOT EXISTS daywork (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  day TEXT NOT NULL,
  task_key TEXT NOT NULL,
  label TEXT,
  link TEXT,
  opened_at TEXT,
  done_at TEXT,
  UNIQUE (user_id, day, task_key)
);
CREATE INDEX IF NOT EXISTS idx_daywork_user_day ON daywork (user_id, day);
