-- Performance, round 3: SAP customers an admin has removed from the page (they stay away after a new SAP upload), and names an admin corrected
-- (for example "TECE DEKOR Ltd" is Canplast).
CREATE TABLE IF NOT EXISTS perf_excluded (
  sap_no TEXT PRIMARY KEY,
  by_user INTEGER,
  at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS perf_name_override (
  sap_no TEXT PRIMARY KEY,
  name TEXT NOT NULL
);
