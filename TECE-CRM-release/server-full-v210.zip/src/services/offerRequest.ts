import type { OfferParams, PriceBook, SectionSelection } from './priceBook';
import { offerCatalog } from './offerTabs';

export interface OfferRequest {
  params: OfferParams;
  selections: SectionSelection[];
  includeMoq: boolean;
}

const MAX_WIDTHS = 8;
const MAX_PCT = 5; // +500 %
const MIN_PCT = -0.9; // 90 % discount

function pct(value: unknown, fallback: number): number {
  const n = typeof value === 'number' ? value : typeof value === 'string' ? parseFloat(value) : NaN;
  if (!Number.isFinite(n)) return fallback;
  return Math.min(MAX_PCT, Math.max(MIN_PCT, n));
}

function text(value: unknown, fallback: string): string {
  return typeof value === 'string' ? value.trim().slice(0, 300) : fallback;
}

// Everything the client sends is treated as untrusted: unknown tabs, rows and
// columns are dropped and numbers are clamped, then the server prints from the
// workbook itself - a price typed into the browser is never used.
export function sanitiseOffer(raw: unknown, book: PriceBook): OfferRequest {
  const body = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>;
  const p = (body.params && typeof body.params === 'object' ? body.params : {}) as Record<string, unknown>;
  const d = book.defaults;

  const currency: OfferParams['currency'] = p.currency === 'USD' ? 'USD' : 'EUR';
  const rate = typeof p.usdRate === 'number' && Number.isFinite(p.usdRate) && p.usdRate > 0 && p.usdRate < 1000 ? p.usdRate : d.usdRate;
  // The per-tab surcharge / discount cells are set in the uploaded price
  // workbook by an admin; whatever the browser sends for them is ignored.
  const adjust: Record<string, number> = { ...d.adjust };

  const widths = Array.isArray(p.widths)
    ? [...new Set(p.widths.filter((w): w is number => typeof w === 'number' && Number.isInteger(w) && w >= 5 && w <= 1000))].slice(0, MAX_WIDTHS)
    : [];

  // a different price increase / decrease for one page (veneer, say), keyed by the page's tab
  const pagePct: Record<string, number> = {};
  const rawPct = p.pagePct && typeof p.pagePct === 'object' ? (p.pagePct as Record<string, unknown>) : {};
  const catalog = offerCatalog(book.catalog);
  for (const section of catalog) {
    const v = rawPct[section.sheet];
    if (v === undefined || v === null || v === '') continue;
    const n = pct(v, NaN);
    if (Number.isFinite(n)) pagePct[section.sheet] = n;
  }

  // the customer's own prices: a few cells of the product pages, by address
  const cellOverrides: Record<string, number> = {};
  const rawCells = p.cellOverrides && typeof p.cellOverrides === 'object' ? (p.cellOverrides as Record<string, unknown>) : {};
  const tabs = new Set(catalog.map((c) => c.sheet));
  for (const [addr, v] of Object.entries(rawCells).slice(0, 400)) {
    const m = /^(.{1,40})!([A-Z]{1,2}[0-9]{1,4})$/.exec(addr);
    const n = typeof v === 'number' ? v : Number(v);
    if (m && tabs.has(m[1]) && Number.isFinite(n) && n > 0 && n < 100000) cellOverrides[addr] = n;
  }

  const params: OfferParams = {
    currency,
    usdRate: currency === 'USD' ? rate : 1,
    transportPct: pct(p.transportPct, d.transportPct),
    adjust,
    // one to eight widths; the first three are the template's own columns, the rest print on an extra copy of the page
    widths: widths.length ? widths : d.widths,
    ...(Object.keys(pagePct).length ? { pagePct } : {}),
    ...(Object.keys(cellOverrides).length ? { cellOverrides } : {}),
    numberStyle: p.numberStyle === 'en' ? 'en' : 'eu',
    deliveryTerm: text(p.deliveryTerm, d.deliveryTerm),
    paymentTerm: text(p.paymentTerm, d.paymentTerm),
    dispatchTime: text(p.dispatchTime, d.dispatchTime),
  };

  const selections: SectionSelection[] = [];
  const seen = new Set<string>();
  for (const item of Array.isArray(body.selections) ? body.selections : []) {
    if (!item || typeof item !== 'object') continue;
    const s = item as Record<string, unknown>;
    const section = catalog.find((c) => c.sheet === s.sheet);
    if (!section || seen.has(section.sheet)) continue;
    const rowIds = new Set(section.rows.map((r) => r.id));
    const colIds = new Set(section.columns.map((c) => c.id));
    const rows = (Array.isArray(s.rows) ? s.rows : []).filter((r): r is number => typeof r === 'number' && rowIds.has(r));
    // The columns the sheet shows are always printed (hiding one would break the page); a column the Excel
    // hides (another thickness, the base paper) is printed only when it is asked for.
    const asked = new Set((Array.isArray(s.columns) ? s.columns : []).filter((c): c is string => typeof c === 'string'));
    const columns = section.columns.filter((c) => !c.hidden || asked.has(c.id)).map((c) => c.id);
    if (!rows.length) continue;
    seen.add(section.sheet);
    selections.push({ sheet: section.sheet, rows, columns });
  }
  return { params, selections, includeMoq: book.hasMoq && body.includeMoq === true };
}
