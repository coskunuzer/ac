import { db } from '../db/connection';
import { env } from '../config/env';

// The offer (and the e-mail with it) can be written in Russian, Turkish, Spanish or French; English is the default.
// The fixed words of the layout are translated by hand (offerI18n.ts); everything that comes from the price workbook
// (product names, notes, terms) and the e-mail text is translated by Gemini, once, and remembered.

export const LANGS = { en: 'English', ru: 'Russian', tr: 'Turkish', es: 'Spanish', fr: 'French' } as const;
export type Lang = keyof typeof LANGS;
export const isLang = (v: unknown): v is Lang => typeof v === 'string' && v in LANGS;

const GEMINI_URL = process.env.GEMINI_BASE_URL || 'https://generativelanguage.googleapis.com/v1beta/models';
const MODEL = 'gemini-3.6-flash';

// Numbers, prices and codes are never translated.
export const worthTranslating = (s: string) => /[A-Za-z]{3,}/.test(s) && !/^https?:\/\//i.test(s.trim());

const SCHEMA = {
  type: 'ARRAY',
  items: { type: 'OBJECT', properties: { i: { type: 'INTEGER' }, t: { type: 'STRING' } }, required: ['i', 't'] },
};

async function askGemini(texts: string[], lang: Lang, kind: 'offer' | 'email'): Promise<(string | null)[]> {
  const out: (string | null)[] = texts.map(() => null);
  if (!env.geminiApiKey || !texts.length) return out;
  const prompt = [
    `Translate these texts from English to ${LANGS[lang]}. They are ${kind === 'offer' ? 'parts of a price offer of TECE, a manufacturer of edgebanding (edge tape for furniture panels: PVC, ABS, PP, melamine, veneer)' : 'an e-mail from a TECE salesperson to a customer'}.`,
    'Keep unchanged: numbers, units (mm, m, m²), currency signs, web addresses, e-mail addresses, product codes (for example "PVC SC", "PVC HG"), and brand and company names (TECE, Kronospan, Egger, Incoterms such as EXW).',
    'Keep line breaks, bullet characters ("- ", "* ") and the order of the lines. Use the natural words of the furniture and edgebanding trade, polite business style. Do not add or remove anything.',
    'Answer with a JSON array of {"i": number, "t": translated text}, one item for each text.',
    `Texts: ${JSON.stringify(texts.map((t, i) => ({ i, text: t })))}`,
  ].join('\n');
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      const res = await fetch(`${GEMINI_URL}/${MODEL}:generateContent`, {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-goog-api-key': env.geminiApiKey },
        body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { responseMimeType: 'application/json', responseSchema: SCHEMA, temperature: 0.1 } }),
        signal: AbortSignal.timeout(60000),
      });
      if (!res.ok) {
        if (res.status === 429 || res.status >= 500) {
          await new Promise((r) => setTimeout(r, 2000 * (attempt + 1)));
          continue;
        }
        return out;
      }
      const data = (await res.json()) as { candidates?: { content?: { parts?: { text?: string; thought?: boolean }[] } }[] };
      const parts = data.candidates?.[0]?.content?.parts?.filter((p) => !p.thought && p.text) ?? [];
      const text = parts[parts.length - 1]?.text;
      if (!text) return out;
      for (const r of JSON.parse(text) as { i?: number; t?: string }[]) {
        if (typeof r.i === 'number' && r.i >= 0 && r.i < texts.length && typeof r.t === 'string' && r.t.trim()) out[r.i] = r.t;
      }
      return out;
    } catch {
      await new Promise((r) => setTimeout(r, 1500));
    }
  }
  return out;
}

// Texts -> their translations (what could not be translated is simply missing, and stays English).
export async function translateStrings(texts: string[], lang: Lang): Promise<Map<string, string>> {
  const result = new Map<string, string>();
  if (lang === 'en') return result;
  const wanted = [...new Set(texts.filter(worthTranslating))];
  const get = db.prepare('SELECT result FROM translations WHERE lang = ? AND source = ?');
  const missing: string[] = [];
  for (const s of wanted) {
    const row = get.get(lang, s) as { result: string } | undefined;
    if (row) result.set(s, row.result);
    else missing.push(s);
  }
  const put = db.prepare('INSERT OR REPLACE INTO translations (lang, source, result) VALUES (?, ?, ?)');
  for (let i = 0; i < missing.length; i += 40) {
    const chunk = missing.slice(i, i + 40);
    const answers = await askGemini(chunk, lang, 'offer');
    chunk.forEach((s, k) => {
      const t = answers[k];
      if (t) {
        result.set(s, t);
        put.run(lang, s, t);
      }
    });
  }
  return result;
}

// The subject and message of an e-mail (kept in the cache too, so the same text is never paid for twice).
export async function translateEmail(subject: string, body: string, lang: Lang): Promise<{ subject: string; body: string } | null> {
  if (lang === 'en' || !env.geminiApiKey) return null;
  // an empty subject (a personal e-mail not yet given one) stays empty; only what is written is translated
  const withSubject = subject.trim().length > 0;
  if (!body.trim() && !withSubject) return null;
  const answers = await askGemini(withSubject ? [subject, body] : [body], lang, 'email');
  if (withSubject) return answers[0] && answers[1] ? { subject: answers[0], body: answers[1] } : null;
  return answers[0] ? { subject: '', body: answers[0] } : null;
}
