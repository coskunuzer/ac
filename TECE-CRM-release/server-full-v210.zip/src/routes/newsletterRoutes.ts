import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import multer from 'multer';
import { Router } from 'express';
import { sanitizeHtml } from '../services/sanitizeHtml';
import { db } from '../db/connection';
import { requireAuth, requireAdminOr, type AuthedRequest } from '../middleware/auth';
import { settingsModel } from '../models/settingsModel';
import { isLang, type Lang } from '../services/translate';
import {
  audience, campaignOf, contentFor, dailyCap, emptyContent, filesDir, filesOf, headerDataUri, maxRecipients, prepareTranslations, renderHtml, runBatch, sendOne, smtpReady, unsubscribe,
  type Campaign, type NlContent,
} from '../services/newsletter';

// Admin > Newsletter: write the campaign, see who gets it, send it in batches, watch it go. And the public "unsubscribe" link.
const router = Router();
router.use(requireAuth, requireAdminOr('camp'));

const str = (v: unknown, max = 4000) => String(v ?? '').trim().slice(0, max);
const lines = (v: unknown): string[] => (Array.isArray(v) ? v : String(v ?? '').split('\n')).map((x) => String(x).trim()).filter(Boolean).slice(0, 80);
const cleanContent = (b: Record<string, unknown>): NlContent => ({ intro: str(b.intro), body: sanitizeHtml(String(b.body ?? '')), added: lines(b.added), removed: lines(b.removed), decorNote: str(b.decorNote, 1500), decorUrl: /^https?:\/\//i.test(str(b.decorUrl, 500)) ? str(b.decorUrl, 500) : '', closing: str(b.closing, 1500) });

function counts(id: number) {
  const r = db.prepare("SELECT status, COUNT(*) AS n FROM newsletter_recipients WHERE newsletter_id = ? GROUP BY status").all(id) as { status: string; n: number }[];
  const o = { queued: 0, sent: 0, failed: 0 };
  for (const x of r) if (x.status in o) o[x.status as keyof typeof o] = x.n;
  return { ...o, total: o.queued + o.sent + o.failed };
}
const view = (c: Campaign) => {
  const en = { ...emptyContent(), ...JSON.parse(c.content_json || '{}') } as NlContent;
  const tr = c.content_tr_json ? (JSON.parse(c.content_tr_json) as Partial<NlContent> & { subject?: string }) : null;
  return {
    id: c.id, title: c.title, subject: c.subject, content: en, contentTr: tr ? { subject: tr.subject ?? '', ...emptyContent(), ...tr } : null, status: c.status, batchSize: c.batch_size, intervalMin: c.interval_min,
    lastBatchAt: c.last_batch_at, note: c.note, createdAt: c.created_at, startedAt: c.started_at, finishedAt: c.finished_at, counts: counts(c.id),
    files: filesOf(c.id).map((f) => ({ id: f.id, name: f.original_name, size: f.size })),
  };
};

router.get('/settings', (_req, res) => res.json({ max: maxRecipients(), dailyCap: dailyCap(), smtp: smtpReady(), testMode: settingsModel.get('test_mode') === '1' }));
router.put('/settings', (req, res) => {
  const n = (v: unknown, lo: number, hi: number, d: number) => { const x = parseInt(String(v), 10); return Number.isFinite(x) ? Math.max(lo, Math.min(hi, x)) : d; };
  settingsModel.set('newsletter_max', String(n(req.body?.max, 1, 1000, 250)));
  settingsModel.set('newsletter_daily_cap', String(n(req.body?.dailyCap, 1, 2000, 250)));
  res.json({ ok: true });
});

router.get('/campaigns', (_req, res) => {
  const rows = db.prepare('SELECT * FROM newsletters ORDER BY id DESC LIMIT 100').all() as unknown as Campaign[];
  res.json({ campaigns: rows.map(view) });
});
router.post('/campaigns', (req: AuthedRequest, res) => {
  const title = str(req.body?.title, 120) || 'New newsletter';
  const r = db.prepare("INSERT INTO newsletters (title, subject, content_json, created_by) VALUES (?, ?, ?, ?)").run(title, title, JSON.stringify(emptyContent()), req.user!.id);
  res.status(201).json(view(campaignOf(Number(r.lastInsertRowid))!));
});
router.get('/campaigns/:id', (req, res) => {
  const c = campaignOf(parseInt(String(req.params.id), 10));
  if (!c) return res.status(404).json({ error: 'Not found' });
  res.json(view(c));
});
router.put('/campaigns/:id', (req, res) => {
  const c = campaignOf(parseInt(String(req.params.id), 10));
  if (!c) return res.status(404).json({ error: 'Not found' });
  if (c.status !== 'draft' && c.status !== 'paused') return res.status(400).json({ error: 'A campaign that is sending or finished cannot be changed.' });
  const b = (req.body ?? {}) as Record<string, unknown>;
  const batch = Math.max(5, Math.min(250, parseInt(String(b.batchSize), 10) || c.batch_size));
  const every = Math.max(1, Math.min(240, parseInt(String(b.intervalMin), 10) || c.interval_min));
  const tr = b.contentTr && typeof b.contentTr === 'object' ? { subject: str((b.contentTr as Record<string, unknown>).subject, 200), ...cleanContent(b.contentTr as Record<string, unknown>) } : null;
  const hasTr = tr && (tr.subject || tr.intro || tr.body || tr.closing || tr.decorNote);
  // a changed text makes the old translations wrong
  db.prepare('UPDATE newsletters SET title = ?, subject = ?, content_json = ?, content_tr_json = ?, translations_json = NULL, batch_size = ?, interval_min = ? WHERE id = ?')
    .run(str(b.title, 120) || c.title, str(b.subject, 200), JSON.stringify(cleanContent((b.content ?? {}) as Record<string, unknown>)), hasTr ? JSON.stringify(tr) : null, batch, every, c.id);
  res.json(view(campaignOf(c.id)!));
});
router.delete('/campaigns/:id', (req, res) => {
  const c = campaignOf(parseInt(String(req.params.id), 10));
  if (!c) return res.status(404).json({ error: 'Not found' });
  if (c.status === 'sending') return res.status(400).json({ error: 'Pause it first.' });
  db.prepare('DELETE FROM newsletters WHERE id = ?').run(c.id);
  res.json({ ok: true });
});

// ---- attached files (PDF and the like): kept on the server, sent with every e-mail of the campaign
const OK_EXT = new Set(['.pdf', '.png', '.jpg', '.jpeg', '.xlsx', '.xls', '.docx', '.doc', '.pptx']);
const fileUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 8 * 1024 * 1024, files: 5 } });
router.post('/campaigns/:id/files', fileUpload.array('files', 5), (req, res) => {
  const c = campaignOf(parseInt(String(req.params.id), 10));
  if (!c) return res.status(404).json({ error: 'Not found' });
  if (c.status !== 'draft' && c.status !== 'paused') return res.status(400).json({ error: 'A campaign that is sending or finished cannot be changed.' });
  const files = (req.files as Express.Multer.File[] | undefined) ?? [];
  if (!files.length) return res.status(400).json({ error: 'Choose a file.' });
  let total = filesOf(c.id).reduce((n, f) => n + f.size, 0);
  const dir = path.join(filesDir, String(c.id));
  fs.mkdirSync(dir, { recursive: true });
  for (const f of files) {
    const ext = path.extname(f.originalname).toLowerCase();
    if (!OK_EXT.has(ext)) return res.status(400).json({ error: 'PDF, picture, Word, Excel or PowerPoint files only.' });
    if (total + f.size > 10 * 1024 * 1024) return res.status(400).json({ error: 'The files of one newsletter can be 10 MB at most (it goes to every customer: keep it small).' });
    const stored = crypto.randomBytes(8).toString('hex') + ext;
    fs.writeFileSync(path.join(dir, stored), f.buffer);
    db.prepare('INSERT INTO newsletter_files (newsletter_id, original_name, stored_name, size, mime) VALUES (?, ?, ?, ?, ?)').run(c.id, path.basename(f.originalname).slice(0, 160), stored, f.size, f.mimetype || null);
    total += f.size;
  }
  res.json(view(campaignOf(c.id)!));
});
router.delete('/campaigns/:id/files/:fid', (req, res) => {
  const c = campaignOf(parseInt(String(req.params.id), 10));
  if (!c) return res.status(404).json({ error: 'Not found' });
  if (c.status !== 'draft' && c.status !== 'paused') return res.status(400).json({ error: 'A campaign that is sending or finished cannot be changed.' });
  const f = filesOf(c.id).find((x) => x.id === parseInt(String(req.params.fid), 10));
  if (f) { try { fs.unlinkSync(path.join(filesDir, String(c.id), path.basename(f.stored_name))); } catch { /* already gone */ } db.prepare('DELETE FROM newsletter_files WHERE id = ?').run(f.id); }
  res.json(view(campaignOf(c.id)!));
});

// what the customer sees (in a language)
router.get('/campaigns/:id/preview', (req, res) => {
  const c = campaignOf(parseInt(String(req.params.id), 10));
  if (!c) return res.status(404).send('Not found');
  const lang: Lang = isLang(req.query.lang) ? req.query.lang : 'en';
  const { content } = contentFor(c, lang);
  res.type('html').send(renderHtml(content, lang, { name: '', unsubUrl: '#', headerSrc: headerDataUri(), preview: true }));
});
// a test to the admin's own address
router.post('/campaigns/:id/test', async (req: AuthedRequest, res) => {
  const c = campaignOf(parseInt(String(req.params.id), 10));
  if (!c) return res.status(404).json({ error: 'Not found' });
  const to = str(req.body?.to, 200) || req.user!.email || '';
  if (!/@/.test(to)) return res.status(400).json({ error: 'Add your e-mail address under My account, or type one.' });
  if (!smtpReady()) return res.status(400).json({ error: 'The mail server (SMTP) is not set up on this server.' });
  const lang: Lang = isLang(req.body?.lang) ? req.body.lang : 'en';
  try { await sendOne(c, { email: to, name: '', lang }, { testTag: true }); res.json({ ok: true, to }); } catch (err) { res.status(502).json({ error: 'Failed to send email', message: (err as Error).message }); }
});

// ---- who gets it ----
router.get('/audience', (_req, res) => {
  const rows = audience();
  res.json({ max: maxRecipients(), rows: rows.map((r) => ({ cardId: r.cardId, company: r.company, country: r.country, email: r.email, lang: r.lang, lastInvoice: r.lastInvoice, ytd: Math.round(r.ytd), currency: r.currency, overdue: Math.round(r.overdue), risk: r.risk, eligible: r.eligible, reasons: r.reasons, override: r.override, overLimit: r.overLimit })) });
});
router.put('/overrides', (req, res) => {
  const cardId = parseInt(String(req.body?.cardId), 10);
  const mode = req.body?.mode;
  if (!Number.isInteger(cardId)) return res.status(400).json({ error: 'Choose the customer.' });
  if (mode === 'include' || mode === 'exclude') db.prepare('INSERT OR REPLACE INTO newsletter_overrides (card_id, mode, note) VALUES (?, ?, ?)').run(cardId, mode, str(req.body?.note, 200) || null);
  else db.prepare('DELETE FROM newsletter_overrides WHERE card_id = ?').run(cardId);
  res.json({ ok: true });
});
router.get('/optouts', (_req, res) => res.json({ rows: db.prepare('SELECT o.email, o.at, o.via, c.company FROM newsletter_optout o LEFT JOIN cards c ON c.id = o.card_id ORDER BY o.at DESC LIMIT 500').all() }));
router.delete('/optouts/:email', (req, res) => { db.prepare('DELETE FROM newsletter_optout WHERE email = ?').run(String(req.params.email).toLowerCase()); res.json({ ok: true }); });

// ---- sending ----
router.post('/campaigns/:id/start', async (req, res) => {
  const c = campaignOf(parseInt(String(req.params.id), 10));
  if (!c) return res.status(404).json({ error: 'Not found' });
  if (c.status !== 'draft') return res.status(400).json({ error: 'It was started already.' });
  if (!smtpReady()) return res.status(400).json({ error: 'The mail server (SMTP) is not set up on this server.' });
  if (settingsModel.get('test_mode') === '1') return res.status(400).json({ error: 'Test mode is on (Admin > Email texts). Switch it off to send to customers.' });
  const content = JSON.parse(c.content_json || '{}') as NlContent;
  if (!c.subject.trim() || !(content.intro || content.body || content.added?.length || content.removed?.length || content.decorUrl)) return res.status(400).json({ error: 'Write a subject and some content first.' });
  const aud = audience().filter((r) => r.eligible && r.cardId !== null);
  if (!aud.length) return res.status(400).json({ error: 'Nobody is on the list.' });
  const ins = db.prepare('INSERT INTO newsletter_recipients (newsletter_id, card_id, sap, company, country, email, lang) VALUES (?, ?, ?, ?, ?, ?, ?)');
  const seen = new Set<string>();
  for (const r of aud) { const k = r.email.toLowerCase(); if (seen.has(k)) continue; seen.add(k); ins.run(c.id, r.cardId, r.sap, r.company, r.country, r.email, r.lang); }
  // the texts in the languages of the customers who get it
  await prepareTranslations(c, [...new Set(aud.map((r) => r.lang))]);
  db.prepare("UPDATE newsletters SET status = 'sending', started_at = datetime('now'), last_batch_at = NULL, note = NULL WHERE id = ?").run(c.id);
  // the first batch goes at once (in the background); the next ones follow every `interval` minutes
  void runBatch(c.id).catch((e) => console.error('Newsletter batch failed:', e));
  res.json(view(campaignOf(c.id)!));
});
router.post('/campaigns/:id/pause', (req, res) => { db.prepare("UPDATE newsletters SET status = 'paused', note = 'Paused by an admin.' WHERE id = ? AND status = 'sending'").run(parseInt(String(req.params.id), 10)); res.json(view(campaignOf(parseInt(String(req.params.id), 10))!)); });
router.post('/campaigns/:id/resume', (req, res) => { db.prepare("UPDATE newsletters SET status = 'sending', note = NULL WHERE id = ? AND status = 'paused' AND started_at IS NOT NULL").run(parseInt(String(req.params.id), 10)); res.json(view(campaignOf(parseInt(String(req.params.id), 10))!)); });
router.post('/campaigns/:id/cancel', (req, res) => { db.prepare("UPDATE newsletters SET status = 'cancelled', finished_at = datetime('now'), note = 'Cancelled by an admin.' WHERE id = ? AND status IN ('sending', 'paused')").run(parseInt(String(req.params.id), 10)); res.json(view(campaignOf(parseInt(String(req.params.id), 10))!)); });
router.post('/campaigns/:id/next-batch', async (req, res) => {
  const id = parseInt(String(req.params.id), 10);
  const r = await runBatch(id);
  res.json({ ...r, campaign: view(campaignOf(id)!) });
});
router.get('/campaigns/:id/recipients', (req, res) => {
  const rows = db.prepare('SELECT id, card_id AS cardId, company, country, email, lang, status, error, sent_at AS sentAt FROM newsletter_recipients WHERE newsletter_id = ? ORDER BY id').all(parseInt(String(req.params.id), 10));
  res.json({ rows });
});

export default router;

// the link in the e-mail: no login
export const publicRouter = Router();
const page = (title: string, text: string) => `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TECE</title></head><body style="margin:0;background:#F3F4F7;font-family:Montserrat,Arial,sans-serif;color:#17243E"><div style="max-width:520px;margin:60px auto;background:#fff;padding:36px 32px"><h1 style="font-weight:400;font-size:26px;margin:0 0 6px">${title}</h1><div style="height:3px;width:50px;background:#8B1931;margin:0 0 18px"></div><p style="line-height:1.6;margin:0">${text}</p></div></body></html>`;
publicRouter.get('/unsubscribe', (req, res) => {
  const ok = unsubscribe(String(req.query.e ?? ''), String(req.query.t ?? ''));
  res.status(ok ? 200 : 400).type('html').send(ok ? page('You are unsubscribed', 'You will not get the TECE newsletter any more. Thank you. / Artık TECE bültenini almayacaksınız.') : page('This link does not work', 'Please write to info@tece.com.tr and we will remove you.'));
});
publicRouter.post('/unsubscribe', (req, res) => { const ok = unsubscribe(String(req.query.e ?? ''), String(req.query.t ?? '')); res.status(ok ? 200 : 400).json({ ok }); });
