import { db } from '../db/connection';
import { SQL_CLEANABLE, SQL_IMPORTANT, SQL_RATING, SQL_VERDICT } from '../models/cardModel';
import { countryKey } from '../models/countryModel';
import { visibilityFor, visibilitySql, type Viewer } from './visibility';
import { quickPlace } from './geocode';
import { placeOf } from './geo';
import { dayRange } from './team';
import { viewMode } from './viewMode';
import { userModel } from '../models/userModel';

// A trip: days, and on each day the customers to visit. Everything a person may see is decided by the same visibility rule as everywhere else.

export interface Trip { id: number; userId: number; title: string; startDate: string | null; endDate: string | null; note: string | null; createdAt: string; updatedAt: string; stopCount?: number; countries?: string[] }
interface TripRow { id: number; user_id: number; title: string; start_date: string | null; end_date: string | null; note: string | null; created_at: string; updated_at: string }
const toTrip = (r: TripRow): Trip => ({ id: r.id, userId: r.user_id, title: r.title, startDate: r.start_date, endDate: r.end_date, note: r.note, createdAt: r.created_at, updatedAt: r.updated_at });

export interface Stop {
  stopId: number; cardId: number; dayNo: number | null; sort: number; visitTime: string | null; note: string | null; messagedAt: string | null;
  company: string | null; name: string | null; position: string | null; email: string | null; mobile: string | null; tel: string | null;
  country: string | null; city: string | null; address: string | null; lat: number | null; lon: number | null; geoSource: string | null;
  stage: string | null; rating: number | null; tier: string | null; language: string | null; person: string | null; website: string | null;
}

const DATE = /^\d{4}-\d{2}-\d{2}$/;
const day = (v: unknown): string | null => (typeof v === 'string' && DATE.test(v) ? v : null);
const text = (v: unknown, max: number): string | null => (typeof v === 'string' && v.trim() ? v.trim().slice(0, max) : null);

export const tripModel = {
  list(viewer: Viewer, all: boolean): Trip[] {
    const names = all ? new Map(userModel.listAll().map((u) => [u.id, u.display_name || u.username])) : null;
    const ownerName = (id: number) => names?.get(id) ?? '';
    const rows = (viewer.role === 'admin' && all
      ? db.prepare('SELECT * FROM trips ORDER BY COALESCE(start_date, created_at) DESC').all()
      : db.prepare('SELECT * FROM trips WHERE user_id = ? ORDER BY COALESCE(start_date, created_at) DESC').all(viewer.id)) as unknown as TripRow[];
    return rows.map((r) => {
      const t = toTrip(r);
      const c = db.prepare('SELECT COUNT(*) AS n FROM trip_stops WHERE trip_id = ?').get(r.id) as { n: number };
      const cs = db.prepare('SELECT DISTINCT cards.country FROM trip_stops ts JOIN cards ON cards.id = ts.card_id WHERE ts.trip_id = ? AND cards.country IS NOT NULL').all(r.id) as { country: string }[];
      return { ...t, stopCount: c.n, countries: cs.map((x) => x.country), ...(all && r.user_id !== viewer.id ? { ownerName: ownerName(r.user_id) } : {}) };
    });
  },
  find(id: number): Trip | null {
    const r = db.prepare('SELECT * FROM trips WHERE id = ?').get(id) as TripRow | undefined;
    return r ? toTrip(r) : null;
  },
  create(userId: number, input: { title?: unknown; startDate?: unknown; endDate?: unknown; note?: unknown }): Trip {
    const title = text(input.title, 120) ?? 'New trip';
    const r = db.prepare('INSERT INTO trips (user_id, title, start_date, end_date, note) VALUES (?, ?, ?, ?, ?)').run(userId, title, day(input.startDate), day(input.endDate), text(input.note, 2000));
    return this.find(Number(r.lastInsertRowid))!;
  },
  update(id: number, input: { title?: unknown; startDate?: unknown; endDate?: unknown; note?: unknown }): Trip | null {
    const t = this.find(id);
    if (!t) return null;
    db.prepare("UPDATE trips SET title = ?, start_date = ?, end_date = ?, note = ?, updated_at = datetime('now') WHERE id = ?").run(
      input.title !== undefined ? text(input.title, 120) ?? t.title : t.title,
      input.startDate !== undefined ? day(input.startDate) : t.startDate,
      input.endDate !== undefined ? day(input.endDate) : t.endDate,
      input.note !== undefined ? text(input.note, 2000) : t.note, id);
    return this.find(id);
  },
  remove(id: number): void {
    db.prepare('DELETE FROM trip_stops WHERE trip_id = ?').run(id);
    db.prepare('DELETE FROM trips WHERE id = ?').run(id);
  },
  // `alsoNames`: a manager looking at the trip of somebody below them also sees the customers that carry a name of their team
  stops(tripId: number, viewer: Viewer, alsoNames?: Set<string>): Stop[] {
    const rows = db.prepare(
      `SELECT ts.id AS stop_id, ts.card_id, ts.day_no, ts.sort, ts.visit_time, ts.note AS stop_note, ts.messaged_at,
              c.company, c.name, c.last_name, c.position, c.email, c.mobile, c.tel, c.country, c.city, c.address, c.lat, c.lon, c.geo_source,
              c.stage, c.language, c.person, c.website, c.uploaded_by, c.status, c.market, c.owner_override,
              ${SQL_RATING} AS rating, COALESCE(json_extract(c.company_score, '$.purchase.tier'), json_extract(c.lead_info, '$.tier')) AS tier
         FROM trip_stops ts JOIN cards c ON c.id = ts.card_id
        WHERE ts.trip_id = ? ORDER BY COALESCE(ts.day_no, 9999), ts.sort, ts.id`
    ).all(tripId) as unknown as Record<string, any>[];
    const seen = visibilityFor(viewer);
    const ok = alsoNames?.size ? (c: Parameters<typeof seen>[0]) => seen(c) || (!!c.person && alsoNames.has(c.person)) : seen;
    return rows.filter((r) => ok({ uploaded_by: r.uploaded_by, person: r.person, country: r.country, status: r.status, market: r.market, city: r.city, owner_override: r.owner_override })).map((r) => ({
      stopId: r.stop_id, cardId: r.card_id, dayNo: r.day_no, sort: r.sort, visitTime: r.visit_time, note: r.stop_note, messagedAt: r.messaged_at,
      company: r.company, name: [r.name, r.last_name].filter(Boolean).join(' ') || null, position: r.position, email: r.email, mobile: r.mobile, tel: r.tel,
      country: r.country, city: r.city, address: r.address, lat: r.lat, lon: r.lon, geoSource: r.geo_source,
      stage: r.stage, rating: r.rating, tier: r.tier, language: r.language, person: r.person, website: r.website,
    }));
  },
  // how many stops of the trip this person cannot see (so the planner can say so instead of looking empty)
  hiddenCount(tripId: number, visible: number): number {
    const c = db.prepare('SELECT COUNT(*) AS n FROM trip_stops ts JOIN cards c ON c.id = ts.card_id WHERE ts.trip_id = ?').get(tripId) as { n: number };
    return Math.max(0, c.n - visible);
  },
  // The whole plan in one go (what the planner sends after every drag): the customers, their day and their order. Nothing else is touched.
  setStops(tripId: number, items: { cardId: number; dayNo: number | null; visitTime?: string | null; note?: string | null }[], viewer: Viewer): void {
    const ok = visibilityFor(viewer);
    const oldRows = db.prepare('SELECT ts.card_id, ts.messaged_at, ts.day_no, ts.sort, c.id AS cid, c.uploaded_by, c.person, c.country, c.status, c.market, c.city, c.owner_override FROM trip_stops ts LEFT JOIN cards c ON c.id = ts.card_id WHERE ts.trip_id = ?').all(tripId) as Record<string, any>[];
    const old = new Map(oldRows.map((r) => [r.card_id as number, r.messaged_at as string | null]));
    // stops whose customer this person cannot see now (looked after by somebody else, or another view mode) stay on the trip untouched
    const kept = new Set(oldRows.filter((r) => r.cid != null && !ok(r as never)).map((r) => r.card_id as number));
    const seen = new Set<number>(kept);
    const counters = new Map<number | null, number>();
    // the kept stops hold their place in the day: new numbers skip theirs so two stops never share a place
    const keptSlots = new Set(oldRows.filter((r) => kept.has(r.card_id)).map((r) => `${r.day_no ?? ''}:${r.sort}`));
    db.exec('BEGIN');
    try {
      const del = db.prepare('DELETE FROM trip_stops WHERE trip_id = ? AND card_id = ?');
      for (const r of oldRows) if (!kept.has(r.card_id)) del.run(tripId, r.card_id);
      const ins = db.prepare('INSERT INTO trip_stops (trip_id, card_id, day_no, sort, visit_time, note, messaged_at) VALUES (?, ?, ?, ?, ?, ?, ?)');
      for (const it of items.slice(0, 400)) {
        if (seen.has(it.cardId)) continue;
        const c = db.prepare('SELECT id, uploaded_by, person, country, status, market, city, owner_override FROM cards WHERE id = ?').get(it.cardId) as Record<string, any> | undefined;
        if (!c || !ok(c as never)) continue;
        seen.add(it.cardId);
        const d = Number.isInteger(it.dayNo) && (it.dayNo as number) >= 1 && (it.dayNo as number) <= 60 ? (it.dayNo as number) : null;
        let n = counters.get(d) ?? 0;
        while (keptSlots.has(`${d ?? ''}:${n}`)) n++;
        counters.set(d, n + 1);
        const t = typeof it.visitTime === 'string' && /^\d{2}:\d{2}$/.test(it.visitTime) ? it.visitTime : null;
        ins.run(tripId, it.cardId, d, n, t, text(it.note, 500), old.get(it.cardId) ?? null);
      }
      db.prepare("UPDATE trips SET updated_at = datetime('now') WHERE id = ?").run(tripId);
      db.exec('COMMIT');
      for (const id of seen) if (!kept.has(id)) quickPlace(id);
    } catch (err) {
      db.exec('ROLLBACK');
      throw err;
    }
  },
};

// ---- who can be put on a trip ---------------------------------------------------------------------------------------------------------
// Customers the person may see, in the chosen countries. Never the ones the clean-up marked for removal (and no lead that nothing is known about).
export type Kind = 'existing' | 'important' | 'tiers';
const NOT_CLEANUP = `NOT EXISTS (SELECT 1 FROM cleanup_suggestions s WHERE s.card_id = cards.id AND s.verdict = 'remove') AND NOT (${SQL_CLEANABLE} AND COALESCE(${SQL_VERDICT}, '') IN ('none', 'unrelated'))`;
const TIER = "COALESCE(json_extract(company_score, '$.purchase.tier'), json_extract(lead_info, '$.tier'))";

export interface Candidate { id: number; company: string | null; name: string | null; country: string | null; city: string | null; stage: string | null; rating: number | null; tier: string | null; lat: number | null; lon: number | null; hasPlace: boolean; hasCity: boolean }

export function candidates(viewer: Viewer, q: { countries: string[]; kinds: Kind[]; text: string; limit?: number }): { items: Candidate[]; total: number; hiddenByCleanup: number } {
  const params: Record<string, string | number> = {};
  const vis = visibilitySql(viewer, params);
  const where: string[] = ["market != 'domestic'", "status != 'needs_review'", "COALESCE(country, '') != ''"];
  if (vis) where.push(vis);
  const cs = q.countries.filter(Boolean);
  if (cs.length) {
    // the country as it is spelled on the customers
    const spelled = (db.prepare("SELECT DISTINCT country FROM cards WHERE market != 'domestic' AND country IS NOT NULL AND country != ''").all() as { country: string }[]).map((r) => r.country).filter((c) => cs.some((x) => countryKey(x) === countryKey(c)));
    if (!spelled.length) return { items: [], total: 0, hiddenByCleanup: 0 };
    spelled.forEach((c, i) => { params[`tc${i}`] = c; });
    where.push(`country IN (${spelled.map((_, i) => `@tc${i}`).join(',')})`);
  }
  const kinds: string[] = [];
  if (q.kinds.includes('existing')) kinds.push("stage = 'customer'");
  if (q.kinds.includes('important')) kinds.push(`(COALESCE(stage, '') != 'customer' AND ${SQL_IMPORTANT})`);
  if (q.kinds.includes('tiers')) kinds.push(`(${TIER} LIKE 'Hot%' OR ${TIER} LIKE 'Warm%')`);
  if (kinds.length) where.push(`(${kinds.join(' OR ')})`);
  if (q.text.trim()) { params.tq = `%${q.text.trim().toLowerCase()}%`; where.push("(LOWER(COALESCE(company, '')) LIKE @tq OR LOWER(COALESCE(name, '')) LIKE @tq OR LOWER(COALESCE(city, '')) LIKE @tq)"); }
  const base = where.join(' AND ');
  const total = (db.prepare(`SELECT COUNT(*) AS n FROM cards WHERE ${base} AND ${NOT_CLEANUP}`).get(params) as { n: number }).n;
  const all = (db.prepare(`SELECT COUNT(*) AS n FROM cards WHERE ${base}`).get(params) as { n: number }).n;
  const rows = db.prepare(
    `SELECT id, company, name, country, city, stage, lat, lon, ${SQL_RATING} AS rating, ${TIER} AS tier FROM cards WHERE ${base} AND ${NOT_CLEANUP}
      ORDER BY (stage = 'customer') DESC, COALESCE(${SQL_RATING}, 0) DESC, company LIMIT ${Math.min(500, q.limit ?? 300)}`
  ).all(params) as unknown as Omit<Candidate, 'hasPlace' | 'hasCity'>[];
  return { items: rows.map((r) => ({ ...r, hasPlace: (r.lat != null && r.lon != null) || !!placeOf(r.city, r.country), hasCity: !!(r.city ?? '').trim() })), total, hiddenByCleanup: Math.max(0, all - total) };
}

// ---- the route ------------------------------------------------------------------------------------------------------------------------------
export interface Pt { lat: number; lon: number }
export function km(a: Pt, b: Pt): number {
  const rad = Math.PI / 180;
  const dLat = (b.lat - a.lat) * rad; const dLon = (b.lon - a.lon) * rad;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * rad) * Math.cos(b.lat * rad) * Math.sin(dLon / 2) ** 2;
  return 6371 * 2 * Math.asin(Math.min(1, Math.sqrt(h)));
}

// The shortest way through all the points that starts at the first one: nearest neighbour, then 2-opt until nothing gets shorter.
export function shortestOrder(points: Pt[], start = 0): number[] {
  const n = points.length;
  if (n <= 2) return points.map((_, i) => i);
  const used = new Array(n).fill(false);
  const order = [start]; used[start] = true;
  while (order.length < n) {
    const cur = points[order[order.length - 1]];
    let best = -1; let bd = Infinity;
    for (let i = 0; i < n; i += 1) if (!used[i]) { const d = km(cur, points[i]); if (d < bd) { bd = d; best = i; } }
    used[best] = true; order.push(best);
  }
  let improved = true; let guard = 0;
  while (improved && guard++ < 60) {
    improved = false;
    for (let i = 1; i < n - 1; i += 1) {
      for (let j = i + 1; j < n; j += 1) {
        const a = points[order[i - 1]]; const b = points[order[i]]; const c = points[order[j]]; const d = j + 1 < n ? points[order[j + 1]] : null;
        const before = km(a, b) + (d ? km(c, d) : 0);
        const after = km(a, c) + (d ? km(b, d) : 0);
        if (after + 1e-6 < before) { order.splice(i, j - i + 1, ...order.slice(i, j + 1).reverse()); improved = true; }
      }
    }
  }
  return order;
}

// The days: a new day starts when the day is full, the country changes, or the next customer is too far to drive on the same day.
export function splitDays(order: { country: string | null; pt: Pt }[], perDay: number, maxLegKm = 350): number[] {
  const out: number[] = [];
  let d = 1; let inDay = 0;
  order.forEach((s, i) => {
    if (i > 0) {
      const prev = order[i - 1];
      if (inDay >= perDay || countryKey(prev.country ?? '') !== countryKey(s.country ?? '') || km(prev.pt, s.pt) > maxLegKm) { d += 1; inDay = 0; }
    }
    out.push(d); inDay += 1;
  });
  return out;
}

export const addDays = (date: string, n: number): string => { const d = new Date(`${date}T12:00:00Z`); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };

export interface Leg { fromStopId: number; toStopId: number; km: number; minutes: number | null; mode: 'road' | 'flight'; approx: boolean }
export interface DayRoute { dayNo: number; date: string | null; stopIds: number[]; legs: Leg[]; totalKm: number; totalMinutes: number | null; geometry: [number, number][] | null }
export interface Transfer { fromDay: number; toDay: number; km: number; mode: 'road' | 'flight'; minutes: number | null; from: string; to: string }
const OSRM = process.env.OSRM_URL || 'https://router.project-osrm.org';

const FLIGHT_KM = 700;
async function drive(points: Pt[]): Promise<{ km: number[]; minutes: number[]; geometry: [number, number][] } | null> {
  try {
    const coords = points.map((p) => `${p.lon.toFixed(5)},${p.lat.toFixed(5)}`).join(';');
    const res = await fetch(`${OSRM}/route/v1/driving/${coords}?overview=full&geometries=geojson&steps=false`, { headers: { 'user-agent': 'TECE-CRM trip planner' }, signal: AbortSignal.timeout(12000) });
    if (!res.ok) return null;
    const j = (await res.json()) as { code?: string; routes?: { geometry?: { coordinates?: [number, number][] }; legs?: { distance: number; duration: number }[] }[] };
    const r = j.routes?.[0];
    if (j.code !== 'Ok' || !r?.legs) return null;
    return { km: r.legs.map((l) => l.distance / 1000), minutes: r.legs.map((l) => l.duration / 60), geometry: (r.geometry?.coordinates ?? []).map(([lon, lat]) => [lat, lon] as [number, number]) };
  } catch {
    return null;
  }
}

// Distances and times per day: real roads when the road service answers (a straight-line estimate, marked as such, when it does not).
export async function routeOf(trip: Trip, stops: Stop[]): Promise<{ days: DayRoute[]; transfers: Transfer[]; unplaced: number[]; totalKm: number; roadService: boolean }> {
  const placed = stops.filter((s) => s.dayNo !== null);
  const dayNos = [...new Set(placed.map((s) => s.dayNo!))].sort((a, b) => a - b);
  const days: DayRoute[] = [];
  let roadOk = false;
  for (const dn of dayNos) {
    const ds = placed.filter((s) => s.dayNo === dn).sort((a, b) => a.sort - b.sort);
    const withPt = ds.filter((s) => s.lat != null && s.lon != null);
    const legs: Leg[] = [];
    let geometry: [number, number][] | null = null;
    const pts = withPt.map((s) => ({ lat: s.lat!, lon: s.lon! }));
    const straight = pts.slice(1).map((p, i) => km(pts[i], p));
    const allRoad = pts.length >= 2 && straight.every((d) => d < FLIGHT_KM) && withPt.every((s) => countryKey(s.country ?? '') === countryKey(withPt[0].country ?? ''));
    const road = allRoad && pts.length <= 25 ? await drive(pts) : null;
    if (road) roadOk = true;
    withPt.slice(1).forEach((s, i) => {
      const from = withPt[i];
      const flight = straight[i] >= FLIGHT_KM || countryKey(from.country ?? '') !== countryKey(s.country ?? '');
      legs.push(flight
        ? { fromStopId: from.stopId, toStopId: s.stopId, km: Math.round(straight[i]), minutes: null, mode: 'flight', approx: true }
        : road
          ? { fromStopId: from.stopId, toStopId: s.stopId, km: Math.round(road.km[i]), minutes: Math.round(road.minutes[i]), mode: 'road', approx: false }
          : { fromStopId: from.stopId, toStopId: s.stopId, km: Math.round(straight[i] * 1.3), minutes: Math.round((straight[i] * 1.3) / 55 * 60), mode: 'road', approx: true });
    });
    days.push({
      dayNo: dn, date: trip.startDate ? addDays(trip.startDate, dn - 1) : null, stopIds: ds.map((s) => s.stopId), legs,
      totalKm: legs.reduce((a, l) => a + l.km, 0), totalMinutes: legs.every((l) => l.minutes !== null) ? legs.reduce((a, l) => a + (l.minutes ?? 0), 0) : null,
      geometry: road?.geometry ?? null,
    });
  }
  // the move from the last customer of a day to the first of the next
  const transfers: Transfer[] = [];
  for (let i = 1; i < days.length; i += 1) {
    const last = stops.find((s) => s.stopId === days[i - 1].stopIds[days[i - 1].stopIds.length - 1]);
    const first = stops.find((s) => s.stopId === days[i].stopIds[0]);
    if (!last || !first || last.lat == null || first.lat == null) continue;
    const d = km({ lat: last.lat!, lon: last.lon! }, { lat: first.lat!, lon: first.lon! });
    const flight = d >= FLIGHT_KM || countryKey(last.country ?? '') !== countryKey(first.country ?? '');
    transfers.push({ fromDay: days[i - 1].dayNo, toDay: days[i].dayNo, km: Math.round(flight ? d : d * 1.3), mode: flight ? 'flight' : 'road', minutes: flight ? null : Math.round((d * 1.3) / 55 * 60), from: last.city || last.country || '', to: first.city || first.country || '' });
  }
  return { days, transfers, unplaced: stops.filter((s) => s.dayNo === null || s.lat == null).map((s) => s.stopId), totalKm: days.reduce((a, d) => a + d.totalKm, 0) + transfers.reduce((a, t) => a + t.km, 0), roadService: roadOk };
}

// "Plan the route": the order that is shortest, cut into days. Customers without a place on the map are left on the last day, not lost.
export function optimise(tripId: number, viewer: Viewer, opts: { perDay: number; startCardId?: number | null }): { moved: number; days: number; withoutPlace: number } {
  const stops = tripModel.stops(tripId, viewer);
  const located = stops.filter((s) => s.lat != null && s.lon != null);
  const without = stops.filter((s) => s.lat == null || s.lon == null);
  if (!located.length) return { moved: 0, days: 0, withoutPlace: without.length };
  const pts = located.map((s) => ({ lat: s.lat!, lon: s.lon! }));
  const startIdx = Math.max(0, located.findIndex((s) => s.cardId === opts.startCardId));
  const order = shortestOrder(pts, startIdx);
  const sorted = order.map((i) => located[i]);
  const dayOf = splitDays(sorted.map((s) => ({ country: s.country, pt: { lat: s.lat!, lon: s.lon! } })), Math.max(1, Math.min(12, opts.perDay)));
  const lastDay = Math.max(...dayOf);
  const items = [
    ...sorted.map((s, i) => ({ cardId: s.cardId, dayNo: dayOf[i], visitTime: null as string | null, note: s.note })),
    ...without.map((s) => ({ cardId: s.cardId, dayNo: lastDay, visitTime: null as string | null, note: s.note })),
  ];
  tripModel.setStops(tripId, items, viewer);
  return { moved: items.length, days: lastDay, withoutPlace: without.length };
}

// ---- where the person has really been ---------------------------------------------------------------------------------------------
// A customer of the trip counts as visited when the owner of the trip wrote a visit, a meeting or a note on it during the trip's dates,
// or when anybody wrote a note on it from the trip itself (activities.trip_id). The notes written from the trip are listed per customer.
export interface TripNote { id: number; cardId: number; type: string; text: string | null; at: string; userId: number; userName: string | null }
export interface VisitInfo { visited: boolean; at: string | null; how: string | null; notes: TripNote[] }
export interface TripVisits { cards: Record<number, VisitInfo>; summary: { planned: number; visited: number; countries: string[]; countriesVisited: string[]; days: number; daysVisited: number; notes: number } }

export function visitsOf(trip: Trip, stops: Pick<Stop, 'cardId' | 'country'>[]): TripVisits {
  const ids = [...new Set(stops.map((s) => Math.trunc(s.cardId)))];
  const cards: Record<number, VisitInfo> = {};
  for (const id of ids) cards[id] = { visited: false, at: null, how: null, notes: [] };
  const days = trip.startDate ? Math.max(1, Math.round((Date.parse(`${trip.endDate || trip.startDate}T12:00:00Z`) - Date.parse(`${trip.startDate}T12:00:00Z`)) / 864e5) + 1) : 0;
  const daysSeen = new Set<string>();
  let notes = 0;
  if (ids.length) {
    const range = trip.startDate ? { from: dayRange(trip.startDate).from, to: dayRange(trip.endDate || trip.startDate).to } : null;
    const rows = db.prepare(
      `SELECT a.id, a.card_id, a.type, a.text, a.created_at, a.user_id, a.trip_id, COALESCE(u.display_name, u.username) AS user_name
         FROM activities a LEFT JOIN users u ON u.id = a.user_id
        WHERE a.card_id IN (${ids.join(',')})
          AND (a.trip_id = @trip ${range ? "OR (a.user_id = @owner AND a.type IN ('visit', 'meeting', 'note') AND a.created_at >= @from AND a.created_at < @to)" : ''})
        ORDER BY a.created_at ASC, a.id ASC`
    ).all({ trip: trip.id, ...(range ? { owner: trip.userId, from: range.from, to: range.to } : {}) }) as { id: number; card_id: number; type: string; text: string | null; created_at: string; user_id: number; trip_id: number | null; user_name: string | null }[];
    for (const r of rows) {
      const c = cards[r.card_id];
      if (!c) continue;
      if (!c.visited || r.type === 'visit' || r.type === 'meeting') { c.visited = true; c.at = r.created_at; c.how = r.type; }
      daysSeen.add(new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Istanbul' }).format(new Date(`${r.created_at.replace(' ', 'T')}Z`)));
      if (r.trip_id === trip.id) { c.notes.push({ id: r.id, cardId: r.card_id, type: r.type, text: r.text, at: r.created_at, userId: r.user_id, userName: r.user_name }); notes += 1; }
    }
  }
  const countries = [...new Set(stops.map((s) => s.country).filter((c): c is string => !!c))];
  const countriesVisited = [...new Set(stops.filter((s) => cards[s.cardId]?.visited).map((s) => s.country).filter((c): c is string => !!c))];
  return { cards, summary: { planned: ids.length, visited: ids.filter((id) => cards[id].visited).length, countries, countriesVisited, days, daysVisited: daysSeen.size, notes } };
}

// The trips of the people below a person (an admin: everybody else's), with the owner's name and how many customers were visited.
export function teamTrips(viewer: Viewer): { people: { id: number; name: string; trips: number }[]; trips: (Trip & { ownerName: string; visited: number })[] } {
  const users = userModel.listAll();
  const nameOf = new Map(users.map((u) => [u.id, u.display_name || u.username]));
  const ids = viewer.role === 'admin' ? users.filter((u) => u.id !== viewer.id).map((u) => u.id) : viewMode.team(viewer.id).ids;
  if (!ids.length) return { people: [], trips: [] };
  const rows = db.prepare(`SELECT * FROM trips WHERE user_id IN (${ids.map((n) => Math.trunc(n)).join(',')}) ORDER BY COALESCE(start_date, created_at) DESC LIMIT 300`).all() as unknown as TripRow[];
  const trips = rows.map((r) => {
    const t = toTrip(r);
    const stops = db.prepare('SELECT ts.card_id AS cardId, cards.country FROM trip_stops ts JOIN cards ON cards.id = ts.card_id WHERE ts.trip_id = ?').all(r.id) as { cardId: number; country: string | null }[];
    const v = visitsOf(t, stops);
    return { ...t, ownerName: nameOf.get(t.userId) ?? '', stopCount: stops.length, countries: v.summary.countries, visited: v.summary.visited };
  });
  const people = [...new Set(trips.map((t) => t.userId))].map((id) => ({ id, name: nameOf.get(id) ?? '', trips: trips.filter((t) => t.userId === id).length })).sort((a, b) => a.name.localeCompare(b.name));
  return { people, trips };
}

// May this person look at this trip? Its owner and an admin may change it; the manager of the owner (anybody above them) may only look.
export function tripAccess(trip: Trip, viewer: Viewer): 'edit' | 'view' | null {
  if (trip.userId === viewer.id || viewer.role === 'admin') return 'edit';
  return viewMode.team(viewer.id).ids.includes(trip.userId) ? 'view' : null;
}
// the names of the manager's team (to show the customers of the trip they look at)
export function teamNamesOf(viewer: Viewer): Set<string> {
  return new Set(viewMode.team(viewer.id).names);
}
