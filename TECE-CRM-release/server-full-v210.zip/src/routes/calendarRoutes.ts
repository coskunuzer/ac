import { Router } from 'express';
import { db } from '../db/connection';
import { env } from '../config/env';
import { requireAdmin, requireAuth, type AuthedRequest } from '../middleware/auth';
import { activityModel } from '../models/activityModel';
import { cardModel } from '../models/cardModel';
import { authUrl, configured, connectedCount, createEvent, testConnection, disconnect, getConfig, handleCallback, listEvents, setConfig, status, moveEvent } from '../services/googleCalendar';
import { canSeeCard } from '../services/visibility';
import { clockIn, isZone, TURKEY_ZONE, zoneCity, zoneOf } from '../services/timezones';
import { emailsIn, peopleOf } from '../services/meetingPeople';
import { LOCALE, langOf, meetingMessage } from '../services/outreachText';

const router = Router();

// Google sends the person back here (the proof of who they are is the signed "state", so no session is needed).
router.get('/callback', async (req, res) => {
  const back = (what: string, reason?: string) => res.redirect(`${env.isProduction ? '' : env.corsOrigin[0]}/calendar?calendar=${what}${reason ? `&reason=${encodeURIComponent(reason.slice(0, 200))}` : ''}`);
  if (typeof req.query.error === 'string') return back('refused', String(req.query.error));
  try {
    await handleCallback(String(req.query.code ?? ''), String(req.query.state ?? ''));
    back('connected');
  } catch (err) {
    console.error('Google Calendar connection failed:', err);
    back('failed', (err as Error).message);
  }
});

router.use(requireAuth);

// Admin: the Google client that lets every person connect their own calendar.
router.get('/config', requireAdmin, (_req, res) => {
  res.json({ ...getConfig(), connected: connectedCount() });
});
router.put('/config', requireAdmin, (req, res) => {
  const b = (req.body ?? {}) as Record<string, unknown>;
  const clientId = typeof b.clientId === 'string' ? b.clientId.trim() : '';
  const publicUrl = typeof b.publicUrl === 'string' ? b.publicUrl.trim() : '';
  if (!clientId || !/^https?:\/\/[^\s]+$/i.test(publicUrl)) return res.status(400).json({ error: 'The Google client ID and the address of this app (starting with https://) are needed.' });
  if (!getConfig().hasSecret && !(typeof b.clientSecret === 'string' && b.clientSecret.trim())) return res.status(400).json({ error: 'The client secret is needed the first time.' });
  setConfig({ clientId, clientSecret: typeof b.clientSecret === 'string' ? b.clientSecret : undefined, publicUrl });
  res.json(getConfig());
});

// "Test my calendar": each step with Google's own answer, to find out what is wrong.
router.post('/test', async (req: AuthedRequest, res) => {
  res.json(await testConnection(req.user!.id));
});

router.get('/status', (req: AuthedRequest, res) => {
  res.json(status(req.user!.id));
});

router.get('/connect', (req: AuthedRequest, res) => {
  if (!configured()) return res.status(503).json({ error: 'Google Calendar is not set up on the server yet (an admin has to add the Google client). See the setup note.' });
  res.json({ url: authUrl(req.user!.id) });
});

router.delete('/connection', (req: AuthedRequest, res) => {
  disconnect(req.user!.id);
  res.json({ ok: true });
});

// The meetings of this person between two moments.
router.get('/events', async (req: AuthedRequest, res) => {
  const from = new Date(String(req.query.from ?? ''));
  const to = new Date(String(req.query.to ?? ''));
  if (Number.isNaN(from.getTime()) || Number.isNaN(to.getTime())) return res.status(400).json({ error: 'from and to are needed' });
  try {
    res.json(await listEvents(req.user!.id, from.toISOString(), to.toISOString()));
  } catch (err) {
    res.status(502).json({ error: (err as Error).message });
  }
});

// The people of a customer (who can be invited or written to), and the time zone of its country.
router.get('/people', (req: AuthedRequest, res) => {
  const card = cardModel.findById(parseInt(String(req.query.cardId ?? ''), 10));
  if (!card || !canSeeCard(req.user!, card)) return res.status(404).json({ error: 'Not found' });
  const zone = zoneOf(card.country, card.city);
  res.json({ people: peopleOf(card), zone, country: card.country, language: card.language ?? 'en' });
});

const EMAIL_OK = /^[^\s@,;<>]+@[^\s@,;<>]+\.[^\s@,;<>]+$/;

// Make a meeting: it goes into the person's Google Calendar and is written down on the customer (as a meeting).
// The team types TURKISH time; the customer is always told THEIR OWN country's time. Guests: the ticked people of the customer and any
// other e-mail addresses typed in. A Google Meet link can be made, and a ready WhatsApp message (with the time of the customer) can be
// opened for each mobile number.
router.post('/events', async (req: AuthedRequest, res) => {
  const b = (req.body ?? {}) as Record<string, unknown>;
  const title = String(b.title ?? '').trim().slice(0, 200);
  const start = new Date(String(b.start ?? ''));
  const end = new Date(String(b.end ?? ''));
  if (!title || Number.isNaN(start.getTime()) || Number.isNaN(end.getTime()) || end <= start) return res.status(400).json({ error: 'A title, a start and an end after the start are needed.' });
  const card = b.cardId ? cardModel.findById(parseInt(String(b.cardId), 10)) : undefined;
  if (card && !canSeeCard(req.user!, card)) return res.status(403).json({ error: 'You do not have access to that customer.' });

  // the guests: ticked addresses and typed ones, each checked
  const typed = String(b.extraEmails ?? '').split(/[\s,;]+/).map((e) => e.trim().toLowerCase()).filter(Boolean);
  const ticked = Array.isArray(b.attendees) ? (b.attendees as unknown[]).map((e) => String(e).trim().toLowerCase()).filter(Boolean) : [];
  const legacy = b.invite === true && card?.email ? emailsIn(card.email).slice(0, 1) : [];
  const guests = [...new Set([...ticked, ...typed, ...legacy])];
  const bad = guests.filter((e) => !EMAIL_OK.test(e));
  if (bad.length) return res.status(400).json({ error: `This is not an e-mail address: ${bad.slice(0, 3).join(', ')}` });
  if (guests.length > 30) return res.status(400).json({ error: 'At most 30 guests.' });

  // the time of the customer
  const zone = isZone(b.zone) ? b.zone : card ? zoneOf(card.country, card.city) : null;
  const tr = clockIn(start, TURKEY_ZONE);
  const local = zone ? clockIn(start, zone) : null;
  const timeLine = local && zone && zone !== TURKEY_ZONE ? `Time of the customer: ${local.time} on ${local.long} (${zoneCity(zone)}) · Turkish time: ${tr.time}` : `Time: ${tr.time} (Turkish time)`;
  const user = req.user!.display_name || req.user!.username;
  const wantMeet = b.meet === true;
  try {
    const event = await createEvent(req.user!.id, {
      title,
      startIso: start.toISOString(),
      endIso: end.toISOString(),
      description: [String(b.description ?? '').slice(0, 2000) || (card ? `TECE CRM: ${card.company ?? card.name ?? ''}` : ''), timeLine].filter(Boolean).join('\n\n'),
      location: String(b.location ?? '').slice(0, 200) || undefined,
      attendees: guests,
      meet: wantMeet,
      cardId: card?.id,
    });

    // a ready WhatsApp message for each chosen mobile number (nothing is sent by the CRM: the person presses send in WhatsApp)
    const whatsapp: { name: string; to: string; url: string }[] = [];
    if (b.whatsapp === true && card) {
      const chosen = Array.isArray(b.whatsappTo) ? new Set((b.whatsappTo as unknown[]).map((x) => String(x))) : null;
      for (const p of peopleOf(card)) {
        if (!p.whatsapp || (chosen && !chosen.has(p.whatsapp))) continue;
        const loc = LOCALE[langOf(card.language)];
        const shown = local && zone ? clockIn(start, zone, loc) : clockIn(start, TURKEY_ZONE, loc);
        const text = meetingMessage(card.language, { name: p.name.split(/\s+/)[0] || card.company || '', user, title, date: shown.long, time: shown.time, zone: zone ? zoneCity(zone) : 'Istanbul', link: event.meetLink });
        whatsapp.push({ name: p.name || card.company || p.whatsapp, to: p.whatsapp, url: `https://wa.me/${p.whatsapp.slice(1)}?text=${encodeURIComponent(text)}` });
      }
    }
    if (card) {
      const when = local && zone && zone !== TURKEY_ZONE ? `${local.date} ${local.time} (${zoneCity(zone)}) = ${tr.time} Turkish time` : `${tr.date} ${tr.time} Turkish time`;
      const extras = [guests.length ? `guests: ${guests.join(', ')}` : '', event.meetLink ? `Meet: ${event.meetLink}` : '', whatsapp.length ? `WhatsApp message ready for ${whatsapp.length}` : ''].filter(Boolean).join(' · ');
      activityModel.add({ userId: req.user!.id, cardId: card.id, type: 'meeting', text: `Meeting planned: ${title} - ${when}${extras ? ` (${extras})` : ''}` });
    }
    // a meeting is a record (date, guests, link), not only a line of note text: Today and the calendar read it
    try {
      const utc = (d: Date) => d.toISOString().slice(0, 16).replace('T', ' ');
      db.prepare('INSERT INTO meetings (card_id, user_id, title, starts_at, ends_at, tz, guests, link, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
        .run(card?.id ?? null, req.user!.id, title, utc(start), utc(end), zone ?? null, JSON.stringify(guests.map((email) => ({ email }))), event.meetLink ?? null, String(b.description ?? '').slice(0, 500) || null);
    } catch (e) { console.error('The meeting was made but could not be kept as a record:', e); }
    res.status(201).json({ ...event, whatsapp, customerTime: local && zone ? { zone, time: local.time, date: local.long } : null });
  } catch (err) {
    res.status(502).json({ error: (err as Error).message });
  }
});

// Move a meeting to another day (drag and drop in the calendar). The time of day stays. The record of the meeting in the CRM follows.
router.post('/events/:id/move', async (req: AuthedRequest, res) => {
  const date = String(req.body?.date ?? '');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return res.status(400).json({ error: 'Give the new day.' });
  try {
    const moved = await moveEvent(req.user!.id, String(req.params.id), date);
    if (!moved.allDay) {
      const utc = (iso: string) => new Date(iso).toISOString().slice(0, 16).replace('T', ' ');
      try {
        const old = db.prepare('SELECT id FROM meetings WHERE user_id = ? AND starts_at = ? AND title = ? ORDER BY id DESC LIMIT 1').get(req.user!.id, utc(moved.oldStart), moved.title) as { id: number } | undefined;
        if (old) db.prepare('UPDATE meetings SET starts_at = ?, ends_at = ? WHERE id = ?').run(utc(moved.start), utc(moved.end), old.id);
      } catch (e) { console.error('The meeting was moved in Google but its record could not be updated:', e); }
      if (moved.cardId) {
        const when = clockIn(new Date(moved.start), TURKEY_ZONE);
        try { activityModel.add({ userId: req.user!.id, cardId: moved.cardId, type: 'meeting', text: `Meeting moved: ${moved.title} - now ${when.date} ${when.time} Turkish time` }); } catch { /* the move itself worked */ }
      }
    }
    res.json(moved);
  } catch (err) {
    res.status(502).json({ error: (err as Error).message });
  }
});

// a meeting that only lives in the CRM (no Google Calendar): move its record to another day, same time
router.post('/meetings/:id/move', (req: AuthedRequest, res) => {
  const date = String(req.body?.date ?? '');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return res.status(400).json({ error: 'Give the new day.' });
  const m = db.prepare('SELECT id, starts_at, ends_at FROM meetings WHERE id = ? AND user_id = ?').get(parseInt(String(req.params.id), 10), req.user!.id) as { id: number; starts_at: string; ends_at: string | null } | undefined;
  if (!m) return res.status(404).json({ error: 'Not found' });
  const s = new Date(`${m.starts_at.replace(' ', 'T')}:00Z`);
  const istDay = (d: Date) => d.toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });
  const delta = Math.round((Date.parse(`${date}T12:00:00Z`) - Date.parse(`${istDay(s)}T12:00:00Z`)) / 86400000) * 86400000;
  const utc = (d: Date) => d.toISOString().slice(0, 16).replace('T', ' ');
  db.prepare('UPDATE meetings SET starts_at = ?, ends_at = ? WHERE id = ?').run(utc(new Date(s.getTime() + delta)), m.ends_at ? utc(new Date(new Date(`${m.ends_at.replace(' ', 'T')}:00Z`).getTime() + delta)) : null, m.id);
  res.json({ ok: true });
});

// my meetings in a period (the records), with the customer and the guests
router.get('/meetings', (req: AuthedRequest, res) => {
  const day = /^\d{4}-\d{2}-\d{2}$/;
  const from = typeof req.query.from === 'string' && day.test(req.query.from) ? req.query.from : new Date().toISOString().slice(0, 10);
  const to = typeof req.query.to === 'string' && day.test(req.query.to) ? req.query.to : new Date(Date.now() + 60 * 86_400_000).toISOString().slice(0, 10);
  const rows = db.prepare(`SELECT m.id, m.card_id AS cardId, m.title, m.starts_at AS startsAt, m.ends_at AS endsAt, m.tz, m.guests, m.link, m.notes, m.done_at AS doneAt, COALESCE(c.company, c.name) AS customer
      FROM meetings m LEFT JOIN cards c ON c.id = m.card_id WHERE m.user_id = ? AND date(m.starts_at) >= ? AND date(m.starts_at) <= ? ORDER BY m.starts_at`).all(req.user!.id, from, to) as { guests: string | null }[];
  res.json(rows.map((r) => ({ ...r, guests: r.guests ? JSON.parse(r.guests) : [] })));
});

router.post('/meetings/:id/done', (req: AuthedRequest, res) => {
  const r = db.prepare('UPDATE meetings SET done_at = CASE WHEN done_at IS NULL THEN datetime(\'now\') ELSE NULL END WHERE id = ? AND user_id = ?').run(parseInt(String(req.params.id), 10), req.user!.id);
  if (!r.changes) return res.status(404).json({ error: 'Not found' });
  res.json({ ok: true });
});

export default router;
