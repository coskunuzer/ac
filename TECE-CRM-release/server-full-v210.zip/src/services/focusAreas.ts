import { db } from '../db/connection';
import { memoByData } from '../db/dataVersion';
import { countryKey } from '../models/countryModel';
import { pricePerfBase, priceIndex, LIMITS, type CustRow } from './pricePerf';
import { context, detailsFor, rowFor, type Person } from './teamPerf';
import { purchasesForCountry, mayOpenCountry } from './purchases';
import { visibilityFor, type Viewer } from './visibility';
import { viewMode } from './viewMode';

// "Your focus" (owner, 21 Nov: "CRM should tell us hey man, you need to focus there, the sprint is just a way for us to manage this").
// For one salesperson, every day, the 1-3 places where effort pays most right now - from facts the CRM already has, by rules (no AI):
//   - a COUNTRY he is responsible for: leads and customers nobody contacted for a year, fair visitors from there still waiting, customers there
//     who slow down, his price index there (the owner's index: 100 = company average, same products, same 12 months) and the country's trend
//   - one CUSTOMER: the biggest drop (slowing), or a customer lost lately
//   - a FAIR: his visitors still waiting (hot = score 7+)
//   - a RUN through a list: overdue follow-ups, offers nobody followed up, meetings to prepare, a price review of customers under index 90
//
// Expected value (EUR, one year) - the same formulas are shown to the user in the "why" line:
//   A   = what a new customer buys in his first year (the average of the company's "new" customers in the last 12 months; €12,000 when unknown)
//   country   EV = 2% x untouched x A  +  5% x fair visitors waiting x A  +  35% x (sales lost by slowing customers there)  +  50% x price gap there
//   customer  EV = 40% x (what he bought the 12 months before - the last 12 months)          (a lost one: 20% x the 12 months before he stopped)
//   fair      EV = 8% x hot visitors waiting x A  +  2% x other visitors waiting x A
//   follow-ups EV = 5% x last-12-month sales of the customers + 2% x A per lead          offers EV = 15% x A per offer nobody followed up
//   meetings  EV = 10% x last-12-month sales of the customer (10% x A for a lead)        price review EV = 50% x sum(sales x (100 - index) / 100) over the first 15 (the biggest gap first)
//   price gap = sales x (100 - index) / 100 (only below index 95 with enough volume: the owner's minimum volume)
// Score = EV x (1 + urgency) / sqrt(effort hours). Urgency 0..1 (days overdue, a fair that ended lately, a meeting within two days, a falling
// market); effort = the hours the start action usually takes. The top 3 of different kinds are taken; a second one of the same kind only when
// it scores more than twice the best of every other kind ("overwhelming").
//
// Money: a viewer without the money switch "ledger" gets the same focus areas with counts only (ev null, no euros in the reason).
// Kept per viewer, subject and data version for the day (db/dataVersion.memoByData); "Not now" (queue_state, key f:<focus key>) is read live.

export type FocusKind = 'country' | 'customer' | 'fair' | 'followups' | 'offers' | 'meetings' | 'price' | 'explore';
export interface Part { t: string; v?: Record<string, string | number> }
export interface RunItem { id: number; name: string; note?: Part | null }
export interface Focus {
  key: string; kind: FocusKind; title: string; titleT?: Part | null;
  why: Part[]; formula: Part; ev: number | null; urgency: number; effort: number; score: number;
  start: { to: string; label: string }; alt?: { to: string; label: string } | null;
  run?: RunItem[]; runCount?: number; country?: string | null; cardId?: number | null;
}

const NEW_A_FALLBACK = 12000;
const r0 = Math.round;
const today = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });
const daysBetween = (a: string, b: string) => r0((Date.parse(`${b.slice(0, 10)}T12:00:00Z`) - Date.parse(`${a.slice(0, 10)}T12:00:00Z`)) / 864e5);
// "€180k", "€12,400", "€1.2M" (the page shows it as it is: the same in Turkish and English)
export const eurShort = (v: number): string => { const a = Math.abs(v); return (v < 0 ? '-' : '') + '€' + (a >= 1e6 ? `${(a / 1e6).toFixed(1)}M` : a >= 10000 ? `${r0(a / 1000)}k` : r0(a).toLocaleString('en-US')); };
const TOUCH = "('note', 'call', 'visit', 'meeting', 'sample', 'thank_you', 'offer', 'documents', 'email', 'whatsapp')";

// what a new customer buys in the first year: the company's "new" customers (status new) in the last 12 months
function newCustomerValue(): number {
  const base = pricePerfBase();
  let s = 0, n = 0;
  for (const c of base.custs.values()) if (c.status === 'new') { const v = c.win.get('12m')?.net ?? 0; if (v > 0) { s += v; n += 1; } }
  return n >= 3 ? r0(s / n) : NEW_A_FALLBACK;
}

type CardV = { id: number; company: string; person: string | null; country: string | null; status: string; market: string; city: string | null; uploaded_by: number; owner_override: number; sap: string | null; stage: string | null };
const liteOf = (c: CardV) => ({ uploaded_by: c.uploaded_by, person: c.person, country: c.country, status: c.status as never, market: c.market, city: c.city, owner_override: c.owner_override });

function compute(viewer: Viewer, subject: Person, money: boolean): { focus: Focus[]; asOf: string | null; today: string; a: number; applies: boolean } {
  const day = today();
  const ctx = context(money);
  const row = rowFor(ctx, [subject]);
  const rows: CustRow[] = row._rows;
  const base = pricePerfBase();
  const d = detailsFor(viewer, subject, rows, money);
  const see = visibilityFor(viewer);
  const A = newCustomerValue();
  const out: Focus[] = [];
  const ev = (v: number) => (money ? r0(v) : null);
  const byCard = new Map<number, CustRow>(); for (const r of rows) if (r.cardId) byCard.set(r.cardId, r);
  const rev12Of = (cardId: number | null) => (cardId ? byCard.get(cardId)?.rev12 ?? 0 : 0);
  const applies = rows.length > 0 || d.countries.length > 0 || d.overdueCount > 0 || d.fairWaitingCount > 0;

  // ---- fair visitors of this person still waiting (nobody wrote, called or visited), per fair and per country -----------------------
  const fairRows = db.prepare(`SELECT c.id, c.exhibition_id ex, e.name fair, COALESCE(e.end_date, e.start_date) last, c.country, COALESCE(c.rate, c.ai_rate, 0) score,
      COALESCE(NULLIF(c.company, ''), c.name, '') company, c.person, c.status, c.market, c.city, c.uploaded_by, c.owner_override, c.sap, c.stage
    FROM cards c JOIN exhibitions e ON e.id = c.exhibition_id
    WHERE c.person = ? AND COALESCE(e.is_default, 0) = 0 AND e.start_date <= ? AND COALESCE(e.end_date, e.start_date) >= ? AND (c.exit_status IS NULL OR c.exit_status = '')
      AND NOT EXISTS (SELECT 1 FROM activities a WHERE a.card_id = c.id AND a.imported = 0 AND a.type IN ${TOUCH})`).all(subject.name, day, shiftDay(day, -180)) as unknown as (CardV & { ex: number; fair: string; last: string; score: number })[];
  const fairs = new Map<number, { name: string; last: string; hot: number; all: number; top: string | null }>();
  const waitingByCountry = new Map<string, number>();
  for (const r of fairRows) {
    const f = fairs.get(r.ex) ?? fairs.set(r.ex, { name: r.fair, last: r.last, hot: 0, all: 0, top: null }).get(r.ex)!;
    f.all += 1; if (r.score >= 7) { f.hot += 1; if (!f.top && see(liteOf(r))) f.top = r.company; }
    if (r.country) { const k = countryKey(r.country); waitingByCountry.set(k, (waitingByCountry.get(k) ?? 0) + 1); }
  }
  for (const [id, f] of fairs) {
    if (!f.all) continue;
    const ago = Math.max(0, daysBetween(f.last, day));
    const v = 0.08 * f.hot * A + 0.02 * (f.all - f.hot) * A;
    const urgency = Math.max(0, 1 - ago / 60);
    const why: Part[] = [plural(f.all, '1 visitor still waiting', '{n} visitors still waiting')];
    if (f.hot) why.push({ t: '{n} of them hot (score 7+)', v: { n: f.hot } });
    why.push({ t: 'the fair ended {d} days ago', v: { d: ago } });
    out.push({ key: `fair:${id}`, kind: 'fair', title: f.name, why, formula: { t: '8% × hot visitors × {a} + 2% × the others × {a} ({a} = what a new customer buys in a year)', v: { a: eurShort(A) } },
      ev: ev(v), urgency, effort: session(f.all, 0.1), score: 0, start: { to: `/fairs/${id}/focus`, label: 'Start the fair focus' } });
  }

  // ---- countries he is responsible for -----------------------------------------------------------------------------------------------
  const rowsByCountry = new Map<string, CustRow[]>();
  for (const r of rows) if (r.country) { const k = countryKey(r.country); (rowsByCountry.get(k) ?? rowsByCountry.set(k, []).get(k)!).push(r); }
  const countryCands = d.countries.map((c) => {
    const k = countryKey(c.country);
    const cr = rowsByCountry.get(k) ?? [];
    const slowing = cr.filter((r) => r.status === 'slowing');
    const gap = slowing.reduce((s, r) => s + Math.max(0, r.revPrev - r.rev), 0);
    const slowWorth = slowing.reduce((s, r) => s + r.revPrev, 0);
    const slowNow = slowing.reduce((s, r) => s + r.rev, 0);
    // the owner's index of his customers there taken together (their group sums pooled, as for a person): the same number as the country page
    const pool = new Map<string, { eur: number; kg: number; m2: number }>();
    for (const r of cr) for (const [g, x] of base.custs.get(r.sap)?.win.get('12m')?.grp ?? []) { const o = pool.get(g) ?? pool.set(g, { eur: 0, kg: 0, m2: 0 }).get(g)!; o.eur += x.eur; o.kg += x.kg; o.m2 += x.m2; }
    const pi = priceIndex(pool, base.bench.get('12m'));
    const pRev = pi.sure ? pi.groups.filter((g) => g.ok).reduce((s, g) => s + g.eur, 0) : 0;
    const idx = pi.sure && pi.index != null ? pi.index : null;
    const priceGap = idx != null && idx < 95 && pRev >= LIMITS.minEur * 10 ? pRev * (100 - idx) / 100 : 0;
    const waiting = waitingByCountry.get(k) ?? 0;
    const v = 0.02 * c.untouched * A + 0.05 * waiting * A + 0.35 * gap + 0.5 * priceGap;
    return { c, slowing, slowWorth, slowNow, gap, idx: idx == null ? null : r0(idx), priceGap, waiting, v, sales: cr.reduce((s, r) => s + r.rev12, 0) };
  }).filter((x) => x.v > 0).sort((a, b) => b.v - a.v).slice(0, 4);
  for (const x of countryCands) {
    // the market of the country (all customers there, the Sales intelligence trend): only for the few that may make the top, only with money
    let trend: number | null = null;
    if (money && mayOpenCountry(viewer as never, x.c.country)) {
      try { const p = purchasesForCountry(x.c.country, viewer as never) as { empty?: boolean; l12?: { eur: number }; p12?: { eur: number } }; if (p && !p.empty && p.p12 && p.p12.eur > 0 && p.l12) trend = r0(((p.l12.eur - p.p12.eur) / p.p12.eur) * 100); } catch { trend = null; }
    }
    const why: Part[] = [];
    if (x.waiting) why.push(plural(x.waiting, '1 fair visitor waiting', '{n} fair visitors waiting'));
    if (x.c.untouched) why.push(plural(x.c.untouched, '1 company nobody contacted for a year', '{n} companies nobody contacted for a year'));
    if (x.slowing.length) why.push(money ? plural(x.slowing.length, '1 slowing customer: {a} the year before, {b} now', '{n} slowing customers: {a} the year before, {b} now', { a: eurShort(x.slowWorth), b: eurShort(x.slowNow) }) : plural(x.slowing.length, '1 slowing customer', '{n} slowing customers'));
    if (money && x.idx != null && x.idx < 95) why.push({ t: 'your price index there {i}', v: { i: x.idx } });
    if (trend != null && Math.abs(trend) >= 5) why.push({ t: trend > 0 ? 'the country buys {p}% more than a year ago' : 'the country buys {p}% less than a year ago', v: { p: Math.abs(trend) } });
    if (x.c.viewOnly) why.push(plural(x.c.viewOnly, '1 looked after by a colleague', '{n} looked after by colleagues'));
    const urgency = Math.min(1, (x.waiting ? 0.3 : 0) + (x.slowing.length ? 0.3 : 0) + (trend != null && trend < -10 ? 0.2 : 0));
    // the run behind the card: the slowing customers there (the biggest drop first), then the fair visitors from there who still wait
    const sIds = x.slowing.filter((r) => r.cardId).map((r) => r.cardId as number);
    const sCards = new Map<number, CardV>();
    if (sIds.length) for (const c of db.prepare(`SELECT id, COALESCE(NULLIF(company, ''), name, '') company, person, country, status, market, city, uploaded_by, owner_override, sap, stage FROM cards WHERE id IN (${sIds.map(() => '?').join(',')})`).all(...sIds) as unknown as CardV[]) sCards.set(c.id, c);
    const ck = countryKey(x.c.country);
    const cRun: RunItem[] = dedupe([
      ...x.slowing.filter((r) => r.cardId && sCards.has(r.cardId) && see(liteOf(sCards.get(r.cardId)!))).sort((p, q) => (q.revPrev - q.rev) - (p.revPrev - p.rev))
        .map((r): RunItem => ({ id: r.cardId as number, name: r.name, note: money ? { t: 'down {p}% ({a} → {b})', v: { p: Math.abs(r0(r.growth ?? 0)), a: eurShort(r.revPrev), b: eurShort(r.rev) } } : { t: 'down {p}%', v: { p: Math.abs(r0(r.growth ?? 0)) } } })),
      ...fairRows.filter((r) => r.country && countryKey(r.country) === ck && see(liteOf(r))).sort((p, q) => q.score - p.score)
        .map((r): RunItem => ({ id: r.id, name: r.company, note: { t: 'waiting since {fair}', v: { fair: r.fair } } })),
    ]).slice(0, RUN);
    // the slowing customers make most of the value: the card starts their run; otherwise the lead sprint of the country
    const runFirst = cRun.length > 0 && 0.35 * x.gap + 0.05 * x.waiting * A >= 0.5 * x.v;
    const sprint = { to: `/sprint?country=${encodeURIComponent(x.c.country)}`, label: 'Start a country sprint' };
    out.push({ key: `country:${ck}`, kind: 'country', title: x.c.country, country: x.c.country, why, run: cRun,
      formula: { t: '2% × untouched × {a} + 5% × visitors waiting × {a} + 35% × sales lost by slowing customers + 50% × price gap', v: { a: eurShort(A) } },
      ev: ev(x.v), urgency, effort: 2, score: 0, start: runFirst ? { to: `/focus/run?key=${encodeURIComponent(`country:${ck}`)}`, label: 'Start the run' } : sprint,
      alt: runFirst ? { to: sprint.to, label: 'The country sprint (leads)' } : money ? { to: `/map?view=countries&c=${encodeURIComponent(x.c.country)}&t=buys`, label: 'What the country buys' } : null });
  }

  // ---- one customer: the biggest drop, or one lost lately -------------------------------------------------------------------------------
  const openable = (id: number | null) => !!id && d.slowing.concat(d.lost).some((n) => n.id === id);
  const slowTop = rows.filter((r) => r.status === 'slowing' && openable(r.cardId)).map((r) => ({ r, drop: r.revPrev - r.rev })).sort((a, b) => b.drop - a.drop).slice(0, 3);
  const lostTop = rows.filter((r) => r.status === 'lost' && openable(r.cardId) && r.revPrev > 0).sort((a, b) => b.revPrev - a.revPrev).slice(0, 2);
  const ids = [...slowTop.map((x) => x.r.cardId!), ...lostTop.map((r) => r.cardId!)];
  const lastTouch = new Map<number, string>();
  if (ids.length) for (const t of db.prepare(`SELECT card_id id, MAX(created_at) at FROM activities WHERE imported = 0 AND type IN ${TOUCH} AND card_id IN (${ids.map(() => '?').join(',')}) GROUP BY 1`).all(...ids) as { id: number; at: string }[]) lastTouch.set(t.id, t.at);
  const lastPart = (id: number): Part => { const l = lastTouch.get(id); return l ? { t: 'last contact {d} days ago', v: { d: daysBetween(l, day) } } : { t: 'no contact recorded' }; };
  for (const { r, drop } of slowTop) {
    if (drop <= 0) continue;
    const l = lastTouch.get(r.cardId!); const since = l ? daysBetween(l, day) : 999;
    const why: Part[] = [money ? { t: 'down {p}% ({a} → {b})', v: { p: Math.abs(r0(r.growth ?? 0)), a: eurShort(r.revPrev), b: eurShort(r.rev) } } : { t: 'down {p}%', v: { p: Math.abs(r0(r.growth ?? 0)) } }, lastPart(r.cardId!)];
    out.push({ key: `customer:${r.cardId}`, kind: 'customer', title: r.name, cardId: r.cardId, country: r.country, why, formula: { t: '40% × what was lost against the 12 months before' },
      ev: ev(0.4 * drop), urgency: Math.min(1, since / 90), effort: 0.5, score: 0, start: { to: `/cards/${r.cardId}/review?tab=buys`, label: 'Open the customer' } });
  }
  for (const r of lostTop) {
    const why: Part[] = [money ? { t: 'bought {v} in the 12 months before, nothing since {d}', v: { v: eurShort(r.revPrev), d: r.last ?? '–' } } : { t: 'nothing bought since {d}', v: { d: r.last ?? '–' } }, lastPart(r.cardId!)];
    out.push({ key: `customer:${r.cardId}`, kind: 'customer', title: r.name, cardId: r.cardId, country: r.country, why, formula: { t: '20% × what he bought in the 12 months before he stopped' },
      ev: ev(0.2 * r.revPrev), urgency: 0.4, effort: 0.5, score: 0, start: { to: `/cards/${r.cardId}/review?tab=buys`, label: 'Open the customer' } });
  }

  // ---- runs through a list ---------------------------------------------------------------------------------------------------------
  // A run is one session: its EV counts the first RUN items (the most valuable first), its effort is that session (at most 2 hours).
  // overdue follow-ups: all of his late to-dos; the run holds the ones on customers he may open, the biggest customers and the oldest first
  if (d.overdueCount) {
    const late = db.prepare(`SELECT t.card_id id, MIN(t.due_date) due, MAX(substr(t.text, 1, 120)) text, COALESCE(NULLIF(c.company, ''), c.name, '') company, c.person, c.country, c.status, c.market, c.city, c.uploaded_by, c.owner_override, c.sap, c.stage
        FROM todos t JOIN cards c ON c.id = t.card_id WHERE t.user_id = ? AND t.done_at IS NULL AND t.due_date < ? GROUP BY t.card_id`).all(subject.id, day) as unknown as (CardV & { due: string; text: string | null })[];
    const items = late.filter((x) => see(liteOf(x))).map((x) => ({ x, v: rev12Of(x.id) > 0 ? 0.05 * rev12Of(x.id) : 0.02 * A, days: daysBetween(x.due, day) }))
      .sort((p, q) => q.v - p.v || q.days - p.days);
    const first = items.slice(0, RUN);
    const v = first.reduce((s2, i) => s2 + i.v, 0);
    const maxDays = items.reduce((m, i) => Math.max(m, i.days), 0);
    const run = first.map(({ x, days }): RunItem => ({ id: x.id, name: x.company, note: x.text ? { t: '{d} days late: {txt}', v: { d: days, txt: x.text } } : { t: '{d} days late', v: { d: days } } }));
    out.push({ key: 'followups', kind: 'followups', title: 'Overdue follow-ups', why: [plural(d.overdueCount, '1 follow-up is late', '{n} follow-ups are late'), { t: 'the oldest {d} days', v: { d: maxDays } }],
      formula: { t: '5% × last-12-month sales of the customer, 2% × {a} per lead (the first {r} = one session)', v: { a: eurShort(A), r: RUN } }, ev: ev(v), urgency: Math.min(1, maxDays / 30), effort: session(first.length, 0.1), score: 0,
      start: run.length ? { to: '/focus/run?key=followups', label: 'Start the run' } : { to: '/follow-ups', label: 'Open the follow-ups' }, alt: { to: '/follow-ups', label: 'All follow-ups' }, run });
  }
  // offers sent 5-90 days ago that nobody followed up (no call, mail, visit or note after the offer)
  const offers = db.prepare(`SELECT x.id, x.sent, COALESCE(NULLIF(c.company, ''), c.name, '') company, c.person, c.country, c.status, c.market, c.city, c.uploaded_by, c.owner_override, c.sap, c.stage
      FROM (SELECT card_id id, MAX(sent_at) sent FROM offers_sent WHERE created_by = ? AND kind = 'offer' AND sent_at >= ? AND sent_at <= ? GROUP BY card_id) x JOIN cards c ON c.id = x.id
      WHERE NOT EXISTS (SELECT 1 FROM activities a WHERE a.card_id = x.id AND a.imported = 0 AND a.type IN ('call', 'visit', 'meeting', 'note', 'email', 'whatsapp') AND a.created_at > x.sent)
        -- the same idea as Today's follow-ups (the opportunities): an offer already marked won or lost, or snoozed, on the customer page is not waiting
        AND (NOT EXISTS (SELECT 1 FROM opportunities op WHERE op.card_id = x.id)
          OR EXISTS (SELECT 1 FROM opportunities op WHERE op.card_id = x.id AND op.status = 'open' AND COALESCE(op.snoozed_until, '') <= ?))
      ORDER BY sent DESC`).all(subject.id, `${shiftDay(day, -90)} 00:00`, `${shiftDay(day, -5)} 23:59`, day) as unknown as (CardV & { sent: string })[];
  if (offers.length) {
    const items = offers.filter((o) => see(liteOf(o))).map((o) => ({ o, v: rev12Of(o.id) > 0 ? 0.05 * rev12Of(o.id) : 0.15 * A })).sort((p, q) => q.v - p.v || q.o.sent.localeCompare(p.o.sent));
    const first = items.slice(0, RUN);
    const run = first.map(({ o }) => ({ id: o.id, name: o.company, note: { t: 'offer sent {d} days ago', v: { d: daysBetween(o.sent, day) } } }));
    out.push({ key: 'offers', kind: 'offers', title: 'Offers nobody followed up', why: [plural(offers.length, '1 offer without a call or mail after it', '{n} offers without a call or mail after them'), { t: 'sent 5 to 90 days ago' }],
      formula: { t: '15% × {a} per offer to a new company, 5% of the last 12 months for a customer (the first {r} = one session)', v: { a: eurShort(A), r: RUN } }, ev: ev(first.reduce((s2, i) => s2 + i.v, 0)), urgency: 0.5, effort: session(first.length, 0.12), score: 0,
      start: run.length ? { to: '/focus/run?key=offers', label: 'Start the run' } : { to: '/follow-ups', label: 'Open the follow-ups' }, run });
  }
  // meetings of the next 7 days with a customer: prepare them
  const meet = db.prepare(`SELECT m.card_id id, MIN(m.starts_at) at, m.title, COALESCE(NULLIF(c.company, ''), c.name, '') company, c.person, c.country, c.status, c.market, c.city, c.uploaded_by, c.owner_override, c.sap, c.stage
      FROM meetings m JOIN cards c ON c.id = m.card_id WHERE m.user_id = ? AND m.done_at IS NULL AND m.starts_at >= ? AND m.starts_at <= ? GROUP BY m.card_id ORDER BY at LIMIT 20`)
    .all(subject.id, `${day} 00:00`, `${shiftDay(day, 7)} 23:59`) as unknown as (CardV & { at: string; title: string })[];
  const meetOk = meet.filter((m) => see(liteOf(m)));
  if (meetOk.length) {
    const v = meetOk.reduce((s, m) => s + (rev12Of(m.id) > 0 ? 0.1 * rev12Of(m.id) : 0.1 * A), 0);
    const soon = Math.min(...meetOk.map((m) => daysBetween(day, m.at)));
    const run = meetOk.map((m) => ({ id: m.id, name: m.company, note: { t: '{when}: {title}', v: { when: m.at.slice(0, 16), title: m.title.slice(0, 80) } } }));
    out.push({ key: 'meetings', kind: 'meetings', title: 'Meetings to prepare', why: [plural(meetOk.length, '1 meeting in the next 7 days', '{n} meetings in the next 7 days'), { t: soon <= 0 ? 'the first one today' : 'the first one in {d} days', v: { d: soon } }],
      formula: { t: '10% × last-12-month sales of the customer (10% × {a} for a lead)', v: { a: eurShort(A) } }, ev: ev(v), urgency: soon <= 2 ? 1 : 0.5, effort: session(meetOk.length, 0.25), score: 0,
      start: meetOk.length === 1 ? { to: `/cards/${meetOk[0].id}/review?tab=details`, label: 'Prepare it' } : { to: '/focus/run?key=meetings', label: 'Start the run' }, alt: { to: '/calendar', label: 'Calendar' }, run });
  }
  // price review: customers well below the company average (owner's index, enough volume), only with money
  if (money && d.discounted.length) {
    const disc = rows.filter((r) => r.flags.includes('leak') && r.index != null);
    const gap = disc.reduce((s, r) => s + r.rev * (100 - (r.index as number)) / 100, 0);
    // the run: every customer under the index that this viewer may open, the biggest gap first (the first RUN = one session)
    const dIds = disc.filter((r) => r.cardId).map((r) => r.cardId as number);
    const dCards = new Map<number, CardV>();
    if (dIds.length) for (const c of db.prepare(`SELECT id, COALESCE(NULLIF(company, ''), name, '') company, person, country, status, market, city, uploaded_by, owner_override, sap, stage FROM cards WHERE id IN (${dIds.map(() => '?').join(',')})`).all(...dIds) as unknown as CardV[]) dCards.set(c.id, c);
    const runG = disc.filter((r) => r.cardId && dCards.has(r.cardId) && see(liteOf(dCards.get(r.cardId)!)))
      .map((r) => ({ r, g: r.rev * (100 - (r.index as number)) / 100 })).sort((a, b) => b.g - a.g).slice(0, RUN)
      .map(({ r, g }) => ({ id: r.cardId as number, name: r.name, g, note: { t: 'price index {i} · gap {v} a year', v: { i: r0(r.index as number), v: eurShort(g) } } }));
    const runGap = runG.reduce((s2, x) => s2 + x.g, 0);
    const run: RunItem[] = runG.map(({ id, name, note }) => ({ id, name, note }));
    const low = disc.reduce((m, r) => Math.min(m, r.index as number), 100);
    out.push({ key: 'price', kind: 'price', title: 'Price review', why: [plural(d.counts.discounted, '1 customer under price index {l}', '{n} customers under price index {l}', { l: LIMITS.leakIndex }), { t: 'the lowest at {i}', v: { i: r0(low) } }, { t: 'gap {v} a year', v: { v: eurShort(gap) } }],
      formula: { t: '50% × sales × (100 − index) / 100 of the first {r} customers, the biggest gap first (100 = company average, same products, same 12 months)', v: { r: RUN } }, ev: ev(0.5 * (run.length ? runGap : gap)), urgency: 0.3, effort: session(run.length || d.counts.discounted, 0.2), score: 0,
      start: run.length ? { to: '/focus/run?key=price', label: 'Start the price review' } : { to: '/performance?tab=pprice', label: 'Open Price performance' }, alt: { to: '/performance?tab=pprice', label: 'Price performance' }, run });
  }

  // score: EV x (1 + urgency) / sqrt(effort); without money the same EV orders them (it is not shown)
  // (without money the EV is null here: focusFor orders them by the scores worked out with money, see computeRanked)
  for (const f of out) f.score = Math.round((f.ev ?? 1) * (1 + f.urgency) / Math.sqrt(Math.max(0.25, f.effort)) * 10) / 10;
  return { focus: out, asOf: ctx.base.cut, today: day, a: A, applies };
}

const RUN = 15; // items in one session of a run
const session = (n: number, hoursEach: number) => Math.max(0.5, Math.min(2, n * hoursEach));
// "1 visitor" / "{n} visitors" (the Turkish dictionary has both)
const plural = (n: number, one: string, many: string, v: Record<string, string | number> = {}): Part => ({ t: n === 1 ? one : many, v: { n, ...v } });
function shiftDay(d: string, n: number): string { return new Date(Date.parse(`${d}T12:00:00Z`) + n * 864e5).toISOString().slice(0, 10); }
function dedupe(l: RunItem[]): RunItem[] { const s = new Set<number>(); return l.filter((x) => (s.has(x.id) ? false : (s.add(x.id), true))); }

// the top 3 of different kinds (a second of the same kind only when it is more than twice as good as everything else)
export function pickTop(all: Focus[], n = 3): Focus[] {
  const sorted = [...all].sort((a, b) => b.score - a.score);
  const out: Focus[] = []; const kinds = new Set<string>();
  for (const f of sorted) {
    if (out.length >= n) break;
    if (kinds.has(f.kind)) {
      if (out.filter((g) => g.kind === f.kind).length >= 2) continue; // never three of one kind
      const bestOther = sorted.find((g) => !kinds.has(g.kind) && !out.includes(g));
      if (bestOther && f.score <= 2 * bestOther.score) continue;
    }
    out.push(f); kinds.add(f.kind);
  }
  return out;
}

const kept = new Map<number | string, { v: number; at: number; day?: string; mark?: string; data: ReturnType<typeof compute> }>();
// ranking without money: the scores are made with the euro values (so the order is the same as with money), the euros are then removed
function computeRanked(viewer: Viewer, subject: Person, money: boolean): ReturnType<typeof compute> {
  if (money) return compute(viewer, subject, true);
  const withMoney = compute(viewer, subject, true);
  const plain = compute(viewer, subject, false);
  const score = new Map(withMoney.focus.map((f) => [f.key, f.score]));
  // keep only the focus areas that also exist without money (the price review needs money), with the order of the euro scores
  for (const f of plain.focus) f.score = score.get(f.key) ?? f.score;
  return plain;
}

export interface FocusAnswer { applies: boolean; money: boolean; today: string; asOf: string | null; newCustomerValue: number | null; person: { id: number; name: string; self: boolean }; focus: Focus[]; more: Focus[]; snoozed: number; snoozedKeys: string[]; empty: Focus | null }
export function focusFor(viewer: Viewer, subject: Person, money: boolean, opts: { snoozeOf?: number | null; all?: boolean } = {}): FocusAnswer {
  const key = [viewer.id, viewer.role, viewer.display_name ?? '', viewMode.team(viewer.id).names.join('\u0001'), subject.id, money ? 1 : 0].join('|');
  // the busy tables (to-dos, notes, meetings, offers) of everybody do not drop it; the subject's own part of them is the fingerprint `mark`
  const busy = ['queue_state', 'queue_log', 'ux_events', 'todos', 'activities', 'meetings', 'offers_sent', 'fair_focus_state', 'card_contacts', 'watch_items'];
  // (a to-do or meeting moved to another day changes no count, so the late to-dos and the open meetings' days are in it as well)
  const mark = () => JSON.stringify(db.prepare(`SELECT (SELECT COUNT(*) || ':' || COALESCE(SUM(done_at IS NULL), 0) || ':' || COALESCE(MAX(id), 0) || ':' || COALESCE(SUM(done_at IS NULL AND due_date < @d), 0) || ':' || COALESCE(MIN(CASE WHEN done_at IS NULL THEN due_date END), '') FROM todos WHERE user_id = @u) t,
      (SELECT MAX(created_at) FROM activities WHERE user_id = @u) a,
      (SELECT COUNT(*) || ':' || COALESCE(SUM(done_at IS NULL), 0) FROM meetings WHERE user_id = @u) m,
      (SELECT group_concat(starts_at) FROM (SELECT starts_at FROM meetings WHERE user_id = @u AND done_at IS NULL AND starts_at >= @d ORDER BY starts_at LIMIT 40)) md,
      (SELECT MAX(id) FROM offers_sent) o`).get({ u: subject.id, d: today() }));
  const r = memoByData(kept, key, () => computeRanked(viewer, subject, money), 600_000, busy, mark);
  // "Not now" of the person who looks at his own focus (a manager looking at somebody's focus sees all of it)
  const snoozed = new Set<string>();
  if (opts.snoozeOf) for (const s of db.prepare("SELECT key FROM queue_state WHERE user_id = ? AND kind = 'snooze' AND key LIKE 'f:%' AND until > ?").all(opts.snoozeOf, today()) as { key: string }[]) snoozed.add(s.key.slice(2));
  const live = r.focus.filter((f) => !snoozed.has(f.key));
  const top = pickTop(live);
  // nothing stands out: explore a new country (the one with the most untouched companies, or the sprint page)
  let empty: Focus | null = null;
  if (!top.length && r.applies) {
    empty = { key: 'explore', kind: 'explore', title: 'Nothing urgent', why: [{ t: 'explore a new country' }], formula: { t: '' }, ev: null, urgency: 0, effort: 1, score: 0, start: { to: '/sprint', label: 'Start a sprint' } };
  }
  // without money nothing that carries euros leaves the server: the score (made from the euro values) becomes the rank, and the
  // "what a new customer buys" amount in the formula becomes the letter A
  const noEur = (f: Focus, i: number): Focus => (money ? f : { ...f, score: i + 1, formula: f.formula.v && 'a' in f.formula.v ? { ...f.formula, v: { ...f.formula.v, a: 'A' } } : f.formula });
  const strip = (f: Focus): Focus => (opts.all ? f : { ...f, run: f.run ? f.run.slice(0, 0) : undefined });
  const runLen = (f: Focus) => (f.run ? f.run.length : 0);
  return {
    applies: r.applies, money, today: r.today, asOf: r.asOf, newCustomerValue: money ? r.a : null, person: { id: subject.id, name: subject.name, self: subject.self },
    focus: top.map((f, i) => noEur({ ...strip(f), runCount: runLen(f) }, i)), more: opts.all ? live.filter((f) => !top.includes(f)).sort((a, b) => b.score - a.score).map((f, i) => noEur(f, top.length + i)) : [], snoozed: snoozed.size, snoozedKeys: [...snoozed], empty,
  };
}

// "Not now": the focus comes back tomorrow (or in `days`)
export function snoozeFocus(userId: number, key: string, days = 1): void {
  const until = shiftDay(today(), Math.max(1, Math.min(14, Math.round(days))));
  db.prepare("INSERT INTO queue_state (user_id, key, kind, until, label) VALUES (?, ?, 'snooze', ?, ?) ON CONFLICT(user_id, key) DO UPDATE SET kind = excluded.kind, until = excluded.until, label = excluded.label, created_at = datetime('now')")
    .run(userId, `f:${key.slice(0, 120)}`, until, 'focus');
}
export function unsnoozeFocus(userId: number, key: string): void { db.prepare('DELETE FROM queue_state WHERE user_id = ? AND key = ?').run(userId, `f:${key.slice(0, 120)}`); }
