-- Performance, round 4: a SAP customer that counts as another one (the sales of TECE DEKOR Ltd are the sales of Canplast).
CREATE TABLE IF NOT EXISTS perf_links (
  sap_no TEXT PRIMARY KEY,
  parent_sap TEXT NOT NULL,
  by_user INTEGER,
  at TEXT NOT NULL DEFAULT (datetime('now'))
);
