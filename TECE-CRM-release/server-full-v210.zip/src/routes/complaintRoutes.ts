import { Router, type Response } from 'express';
import { shrinkUpload } from '../services/shrinkImage';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { db } from '../db/connection';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { cardModel } from '../models/cardModel';
import { userModel } from '../models/userModel';
import { countryModel } from '../models/countryModel';
import { settingsModel } from '../models/settingsModel';
import { activityModel } from '../models/activityModel';
import { canSeeCard } from '../services/visibility';
import { useAi } from '../services/aiBudget';
import { readLabel } from '../services/labelReader';
import { aiFailureMessage } from '../services/aiGate';
import { buildSignature, styleFor } from '../services/signature';
import { sendThankYouEmail } from '../services/thankYouEmail';
import { splitEmails } from '../services/emailAddresses';
import { descendants } from '../services/team';
import { REASONS } from '../data/complaintPanel';
import { ensurePanel, externalView, logEvent, moveStatus, noticeToQuality, statusBeforeInfo, suggestReason, type CRow } from '../services/quality';
import {
  KINDS, cleanItems, complaintsDir, ensureDir, imagePath, polishComplaint, renderComplaintPdf, workOut, type ComplaintItem, type ComplaintKind, type Polished,
} from '../services/complaints';

const router = Router();
router.use(requireAuth);
router.use((_req, _res, next) => { ensurePanel(); next(); });

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 12 * 1024 * 1024, files: 8 } });
const IMAGE_TYPES: Record<string, string> = { 'image/jpeg': '.jpg', 'image/png': '.png' };

// where complaints always go (besides the person and the assistant of the customer's country)
const DEFAULT_TO = 'tarik@tece.com.tr';
const fixedRecipients = () => splitEmails(settingsModel.get('complaint_to') ?? DEFAULT_TO);

type Row = CRow;
interface ImageRow { id: number; complaint_id: number; stored_name: string; original_name: string | null; caption: string | null }

const str = (v: unknown, max = 200) => String(v ?? '').trim().slice(0, max);
const amountOf = (v: unknown): number | null => {
  if (v === null || v === undefined || String(v).trim() === '') return null;
  const n = Number(String(v).replace(',', '.'));
  return Number.isFinite(n) ? Math.round(n * 100) / 100 : null;
};
const parse = <T,>(s: string | null, fallback: T): T => { try { return s ? (JSON.parse(s) as T) : fallback; } catch { return fallback; } };

// a person sees the complaints they wrote and those of the people who report to them (an admin sees all)
function mayOpen(req: AuthedRequest, row: Row): boolean {
  const u = req.user!;
  if (u.role === 'admin' || row.created_by === u.id) return true;
  return descendants(u.id).some((d) => d.user.id === row.created_by);
}
function openRow(req: AuthedRequest, res: Response): Row | null {
  const row = db.prepare('SELECT * FROM complaints WHERE id = ?').get(parseInt(String(req.params.id), 10)) as Row | undefined;
  if (!row) { res.status(404).json({ error: 'Complaint not found' }); return null; }
  if (!mayOpen(req, row)) { res.status(403).json({ error: 'You do not have access to this complaint' }); return null; }
  return row;
}
const imagesOf = (id: number) => db.prepare('SELECT * FROM complaint_images WHERE complaint_id = ? ORDER BY id').all(id) as unknown as ImageRow[];

function shape(row: Row) {
  return {
    id: row.id, cardId: row.card_id, customerName: row.customer_name, customerContact: row.customer_contact, customerEmail: row.customer_email, customerCountry: row.customer_country,
    orderNo: row.order_no, kind: row.kind, text: row.raw_text ?? '', items: parse<ComplaintItem[]>(row.items_json, []), amount: row.amount_wasted, currency: row.currency,
    polished: parse<Polished | null>(row.polished_json, null), status: row.status, sentAt: row.sent_at, sentTo: row.sent_to, createdAt: row.created_at,
    createdBy: userModel.findById(row.created_by)?.display_name ?? null,
    reportedDate: row.reported_date ?? row.created_at.slice(0, 10), productCode: row.product_code, orderQty: row.order_qty, complainedQty: row.complained_qty, reasonCode: row.reason_code, channel: row.channel, customerRequest: row.customer_request,
    creditNote: row.credit_note, priority: row.priority ?? 'normal', repUserId: row.rep_user_id, repName: row.rep_user_id ? userModel.findById(row.rep_user_id)?.display_name ?? null : null,
    // what quality lets the sales representative read (K04): root cause, result, action taken and the reports
    result: row.share_result ? {
      rootCause: row.root_cause, resultText: row.result_text, actionTaken: row.result_action,
      files: (db.prepare('SELECT id, original_name, uploaded_at FROM complaint_files WHERE complaint_id = ? ORDER BY id').all(row.id) as { id: number; original_name: string | null; uploaded_at: string }[]).map((f) => ({ id: f.id, name: f.original_name, at: f.uploaded_at })),
    } : null,
    external: externalView(row), locked: !!row.internal_status && !['Yeni kayıt', 'Bilgi bekleniyor'].includes(row.internal_status),
    images: imagesOf(row.id).map((i) => ({ id: i.id, name: i.original_name, caption: i.caption ?? '' })),
  };
}

// the people the complaint goes to: the fixed address(es), the person writing, and the assistant of the customer's country
function recipientsFor(req: AuthedRequest, row: Row): { to: string[]; cc: string[] } {
  const to = fixedRecipients();
  const cc: string[] = [];
  const mine = req.user!.email;
  if (mine) cc.push(mine);
  const country = row.customer_country ?? cardModel.findById(row.card_id ?? 0)?.country ?? null;
  const assistant = country ? countryModel.findByCountry(country)?.assistant ?? null : null;
  const person = assistant ? userModel.findByDisplayName(assistant) : null;
  if (person?.email) cc.push(person.email);
  const seen = new Set(to.map((a) => a.toLowerCase()));
  return { to, cc: cc.filter((a) => !seen.has(a.toLowerCase()) && (seen.add(a.toLowerCase()), true)) };
}

router.get('/', (req: AuthedRequest, res) => {
  const u = req.user!;
  const ids = u.role === 'admin' ? null : [u.id, ...descendants(u.id).map((d) => d.user.id)];
  const rows = (ids
    ? db.prepare(`SELECT * FROM complaints WHERE created_by IN (${ids.map(() => '?').join(',')}) ORDER BY id DESC LIMIT 300`).all(...ids)
    : db.prepare('SELECT * FROM complaints ORDER BY id DESC LIMIT 300').all()) as unknown as Row[];
  res.json({ complaints: rows.map(shape).map((c) => ({ ...c, images: c.images.length })), fixedTo: fixedRecipients() });
});

// how many complaints are still open (the red number on the top bar): the same complaints the list shows this person
router.get('/open-count', (req: AuthedRequest, res) => {
  const u = req.user!;
  if ((u as { perms?: { menu: string[] } | null }).perms && !(u as { perms?: { menu: string[] } | null }).perms!.menu.includes('comp')) return res.json({ count: 0 });
  const ids = u.role === 'admin' ? null : [u.id, ...descendants(u.id).map((d) => d.user.id)];
  const where = "status != 'draft' AND (internal_status IS NULL OR internal_status != 'Kapatıldı')" + (ids ? ` AND created_by IN (${ids.map(() => '?').join(',')})` : '');
  const r = db.prepare(`SELECT COUNT(*) AS n FROM complaints WHERE ${where}`).get(...(ids ?? [])) as { n: number };
  res.json({ count: r.n });
});

// the standard reasons (the list of the quality panel) for the form
router.get('/reasons', (_req, res) => res.json({ reasons: REASONS }));

// an open complaint of a customer: the red alert on the customer page (only the complaints this person may open)
router.get('/open-for-card/:cardId', (req: AuthedRequest, res) => {
  const rows = db.prepare("SELECT * FROM complaints WHERE card_id = ? AND (internal_status IS NULL OR internal_status != 'Kapatıldı') AND status != 'draft' ORDER BY id DESC").all(parseInt(String(req.params.cardId), 10)) as unknown as Row[];
  const mine = rows.filter((r) => mayOpen(req, r));
  res.json({ complaints: mine.map((r) => ({ id: r.id, no: r.complaint_no, label: externalView(r).label })) });
});

router.get('/:id', (req: AuthedRequest, res) => {
  const row = openRow(req, res);
  if (!row) return;
  // sales sees the status labels and its own conversation - never the internal notes, the departments or the root cause (K04)
  const timeline = (db.prepare("SELECT at, to_status FROM complaint_events WHERE complaint_id = ? AND kind = 'status' AND internal = 0 ORDER BY id DESC").all(row.id) as { at: string; to_status: string }[]).map((e) => ({ at: e.at, label: externalView({ ...row, internal_status: e.to_status }).label }));
  const comms = (db.prepare('SELECT id, user_id, at, kind, channel, text, feedback FROM complaint_comms WHERE complaint_id = ? ORDER BY id DESC').all(row.id) as { id: number; user_id: number | null; at: string; kind: string; channel: string | null; text: string | null; feedback: string | null }[]).map((m) => ({ ...m, who: userModel.findById(m.user_id ?? 0)?.display_name ?? null }));
  res.json({ ...shape(row), recipients: recipientsFor(req, row), timeline, comms });
});

// create or change: the facts (the polished text stays until the facts change and the AI is asked again)
function save(req: AuthedRequest, id: number | null): number | { error: string } {
  const b = (req.body ?? {}) as Record<string, unknown>;
  const kind = (KINDS as readonly string[]).includes(String(b.kind)) ? String(b.kind) : 'quality';
  let name = str(b.customerName, 160);
  let contact = str(b.customerContact, 120);
  let email = str(b.customerEmail, 200);
  let country = str(b.customerCountry, 80);
  const cardId = Number.isInteger(Number(b.cardId)) && Number(b.cardId) > 0 ? Number(b.cardId) : null;
  if (cardId) {
    const card = cardModel.findById(cardId);
    if (!card || !canSeeCard(req.user, card)) return { error: 'You do not have access to this customer' };
    name = name || card.company || card.name || '';
    contact = contact || (card.company ? card.name ?? '' : '');
    email = email || card.email || '';
    country = country || card.country || '';
  }
  if (!name) return { error: 'Choose the customer (or type the name).' };
  const items = cleanItems(b.items);
  const cur = ['EUR', 'USD', 'TRY'].includes(String(b.currency)) ? String(b.currency) : 'EUR';
  const reason = str(b.reasonCode, 6);
  if (reason && !REASONS.some((x) => x.code === reason)) return { error: 'Choose the reason from the list.' };
  const reported = /^\d{4}-\d{2}-\d{2}$/.test(str(b.reportedDate, 10)) ? str(b.reportedDate, 10) : new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });
  const channel = ['email', 'phone', 'visit'].includes(str(b.channel, 10)) ? str(b.channel, 10) : null;
  const values = [cardId, name, contact || null, email || null, country || null, str(b.orderNo, 80) || null, kind, str(b.text, 6000) || null, JSON.stringify(items), amountOf(b.amount), cur, reported, str(b.productCode, 80) || null, str(b.orderQty, 60) || null, str(b.complainedQty, 60) || null, reason || null, channel, str(b.customerRequest, 1500) || null, str(b.creditNote, 300) || null, ['low', 'normal', 'high'].includes(str(b.priority, 10)) ? str(b.priority, 10) : 'normal'];
  if (id) {
    db.prepare(`UPDATE complaints SET card_id = ?, customer_name = ?, customer_contact = ?, customer_email = ?, customer_country = ?, order_no = ?, kind = ?, raw_text = ?, items_json = ?, amount_wasted = ?, currency = ?, reported_date = ?, product_code = ?, order_qty = ?, complained_qty = ?, reason_code = ?, channel = ?, customer_request = ?, credit_note = ?, priority = ?, updated_at = datetime('now') WHERE id = ?`).run(...values, id);
    return id;
  }
  const r = db.prepare(`INSERT INTO complaints (card_id, customer_name, customer_contact, customer_email, customer_country, order_no, kind, raw_text, items_json, amount_wasted, currency, reported_date, product_code, order_qty, complained_qty, reason_code, channel, customer_request, credit_note, priority, created_by, rep_user_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(...values, req.user!.id, req.user!.id);
  return Number(r.lastInsertRowid);
}

router.post('/', (req: AuthedRequest, res) => {
  const r = save(req, null);
  if (typeof r !== 'number') return res.status(400).json(r);
  res.json({ id: r });
});

router.put('/:id', (req: AuthedRequest, res) => {
  const row = openRow(req, res);
  if (!row) return;
  if (row.internal_status && !['Yeni kayıt', 'Bilgi bekleniyor'].includes(row.internal_status)) return res.status(400).json({ error: 'Quality is already working on this complaint: it cannot be changed any more. Add information under "Answer to quality" instead.' });
  const r = save(req, row.id);
  if (typeof r !== 'number') return res.status(400).json(r);
  res.json({ id: r });
});

router.delete('/:id', (req: AuthedRequest, res) => {
  const row = openRow(req, res);
  if (!row) return;
  if (row.created_by !== req.user!.id && req.user!.role !== 'admin') return res.status(403).json({ error: 'Only the person who wrote it can delete it.' });
  if (row.internal_status) return res.status(400).json({ error: 'A complaint that was sent to quality is kept in the register: it cannot be deleted.' });
  for (const i of imagesOf(row.id)) fs.rmSync(imagePath(i.stored_name), { force: true });
  db.prepare('DELETE FROM complaints WHERE id = ?').run(row.id);
  res.json({ ok: true });
});

// photos
router.post('/:id/images', upload.array('photos', 8), async (req: AuthedRequest, res) => {
  const row = openRow(req, res);
  if (!row) return;
  ensureDir();
  const have = imagesOf(row.id).length;
  const files = ((req.files as Express.Multer.File[]) ?? []).slice(0, Math.max(0, 12 - have));
  for (const f of files) {
    const ext = IMAGE_TYPES[f.mimetype];
    if (!ext) return res.status(400).json({ error: 'Photos must be JPG or PNG.' });
    const small = await shrinkUpload(f, ext);
    const stored = `${row.id}-${crypto.randomBytes(6).toString('hex')}${small.ext}`;
    fs.writeFileSync(path.join(complaintsDir, stored), small.buffer);
    db.prepare('INSERT INTO complaint_images (complaint_id, stored_name, original_name) VALUES (?, ?, ?)').run(row.id, stored, f.originalname.slice(0, 120));
  }
  res.json({ images: shape(row).images.length === 0 ? [] : imagesOf(row.id).map((i) => ({ id: i.id, name: i.original_name, caption: i.caption ?? '' })) });
});

router.patch('/:id/images/:imageId', (req: AuthedRequest, res) => {
  const row = openRow(req, res);
  if (!row) return;
  db.prepare('UPDATE complaint_images SET caption = ? WHERE id = ? AND complaint_id = ?').run(str(req.body?.caption, 140) || null, parseInt(String(req.params.imageId), 10), row.id);
  res.json({ ok: true });
});

// Read the label in a photo (brand, decor, code, size, origin, barcode): one small AI vision call, only when the person asks. A photo of a complaint that is not saved yet is sent
// with the request; a saved photo is read from its file.
const labelAnswer = async (buf: Buffer, req: AuthedRequest, res: Response) => {
  if (!useAi(req.user!, res)) return;
  const info = await readLabel(buf);
  if (!info) return res.status(503).json({ ai: true, error: aiFailureMessage('The AI could not read the photo just now. Try again in a minute, or type the label by hand.') });
  res.json(info);
};
router.post('/read-label', upload.single('photo'), async (req: AuthedRequest, res) => {
  if (!req.file) return res.status(400).json({ error: 'Choose a photo first.' });
  await labelAnswer(req.file.buffer, req, res);
});
router.post('/:id/images/:imageId/read-label', async (req: AuthedRequest, res) => {
  const row = openRow(req, res);
  if (!row) return;
  const img = imagesOf(row.id).find((i) => i.id === parseInt(String(req.params.imageId), 10));
  if (!img) return res.status(404).json({ error: 'Photo not found' });
  let buf: Buffer;
  try { buf = fs.readFileSync(imagePath(img.stored_name)); } catch { return res.status(404).json({ error: 'Photo not found' }); }
  await labelAnswer(buf, req, res);
});

router.delete('/:id/images/:imageId', (req: AuthedRequest, res) => {
  const row = openRow(req, res);
  if (!row) return;
  const img = imagesOf(row.id).find((i) => i.id === parseInt(String(req.params.imageId), 10));
  if (img) { fs.rmSync(imagePath(img.stored_name), { force: true }); db.prepare('DELETE FROM complaint_images WHERE id = ?').run(img.id); }
  res.json({ ok: true });
});

// the reports quality has chosen to share
router.get('/:id/files/:fid', (req: AuthedRequest, res) => {
  const row = openRow(req, res);
  if (!row) return;
  const f = db.prepare('SELECT stored_name, original_name FROM complaint_files WHERE id = ? AND complaint_id = ?').get(parseInt(String(req.params.fid), 10), row.id) as { stored_name: string; original_name: string | null } | undefined;
  if (!row.share_result || !f || !fs.existsSync(imagePath(f.stored_name))) return res.status(404).json({ error: 'Not found' });
  res.download(imagePath(f.stored_name), f.original_name ?? f.stored_name);
});

router.get('/:id/images/:imageId', (req: AuthedRequest, res) => {
  const row = openRow(req, res);
  if (!row) return;
  const img = imagesOf(row.id).find((i) => i.id === parseInt(String(req.params.imageId), 10));
  if (!img || !fs.existsSync(imagePath(img.stored_name))) return res.status(404).json({ error: 'Not found' });
  res.sendFile(imagePath(img.stored_name));
});

// the AI picks the standard reason from what was written (step 3)
router.post('/:id/suggest-reason', async (req: AuthedRequest, res) => {
  const row = openRow(req, res);
  if (!row) return;
  const text = `${str(req.body?.text, 3000) || row.raw_text || ''}`.trim();
  if (!text) return res.status(400).json({ error: 'Write what happened first.' });
  if (!useAi(req.user!, res)) return;
  const hit = await suggestReason(text);
  if (!hit) return res.status(503).json({ ai: true, error: aiFailureMessage('The AI could not choose a reason just now. Choose it from the list.') });
  res.json(hit);
});

// sales answers a request of quality (more information, a document) or writes down what was told to the customer and what came back (K06, K10)
router.post('/:id/respond', async (req: AuthedRequest, res) => {
  const row = openRow(req, res);
  if (!row) return;
  if (!row.internal_status) return res.status(400).json({ error: 'Send the complaint to quality first.' });
  const kind = str(req.body?.kind, 10) === 'customer' ? 'customer' : 'info';
  const text = str(req.body?.text, 2000);
  const feedback = str(req.body?.feedback, 1000);
  if (!text && !feedback) return res.status(400).json({ error: 'Write something.' });
  const channel = ['email', 'phone', 'visit'].includes(str(req.body?.channel, 10)) ? str(req.body?.channel, 10) : null;
  db.prepare('INSERT INTO complaint_comms (complaint_id, user_id, kind, channel, text, feedback) VALUES (?, ?, ?, ?, ?, ?)').run(row.id, req.user!.id, kind, channel, text || null, feedback || null);
  if (kind === 'info' && row.internal_status === 'Bilgi bekleniyor') {
    db.prepare('UPDATE complaints SET info_request = NULL, info_due = NULL WHERE id = ?').run(row.id);
    const back = moveStatus({ ...row, info_request: 'x' }, statusBeforeInfo(row.id), req.user!.id, 'Sales answered the request for information');
    if (back) console.error('Complaint', row.id, 'could not go back after the answer:', back);
    void noticeToQuality({ ...row, customer_name: `${row.customer_name} - satıştan ek bilgi geldi` }, req.user!.display_name || req.user!.username);
  }
  if (kind === 'customer') {
    db.prepare("UPDATE complaints SET customer_replied = 1, customer_reply_date = COALESCE(customer_reply_date, date('now', 'localtime')) WHERE id = ?").run(row.id);
    const fresh = db.prepare('SELECT * FROM complaints WHERE id = ?').get(row.id) as unknown as Row;
    logEvent(row.id, req.user!.id, 'reply', null, null, `Customer informed (${channel ?? '-'})`, false);
  }
  res.json({ ok: true });
});

// the AI writes the clean Turkish text from the facts
router.post('/:id/polish', async (req: AuthedRequest, res) => {
  const row = openRow(req, res);
  if (!row) return;
  if (!(row.raw_text ?? '').trim() && !parse<ComplaintItem[]>(row.items_json, []).length) return res.status(400).json({ error: 'Write what happened first (or add the order lines).' });
  if (!useAi(req.user!, res)) return;
  const items = workOut(parse<ComplaintItem[]>(row.items_json, [])).rows;
  const polished = await polishComplaint({
    kind: row.kind, customer: row.customer_name ?? '', country: row.customer_country ?? '', orderNo: row.order_no ?? '', text: row.raw_text ?? '', items,
    amount: row.amount_wasted, currency: row.currency, photos: imagesOf(row.id).length,
  });
  if (!polished) return res.status(503).json({ ai: true, error: aiFailureMessage('The AI could not write the text just now. Try again in a moment, or write the text yourself.') });
  db.prepare("UPDATE complaints SET polished_json = ?, updated_at = datetime('now') WHERE id = ?").run(JSON.stringify(polished), row.id);
  res.json({ polished });
});

// the person may correct the AI text before it is sent
router.put('/:id/polished', (req: AuthedRequest, res) => {
  const row = openRow(req, res);
  if (!row) return;
  const b = (req.body ?? {}) as Record<string, unknown>;
  const polished: Polished = {
    title: str(b.title, 160), summary: str(b.summary, 1500), details: (Array.isArray(b.details) ? b.details : []).map((d) => str(d, 400)).filter(Boolean).slice(0, 10),
    impact: str(b.impact, 800), requested: str(b.requested, 800),
  };
  if (!polished.title) return res.status(400).json({ error: 'The complaint needs a title.' });
  db.prepare("UPDATE complaints SET polished_json = ?, updated_at = datetime('now') WHERE id = ?").run(JSON.stringify(polished), row.id);
  res.json({ ok: true });
});

async function pdfOf(req: AuthedRequest, row: Row): Promise<Buffer> {
  const p = parse<Polished | null>(row.polished_json, null) ?? {
    title: `${row.customer_name ?? 'Müşteri'} şikâyeti`, summary: row.raw_text ?? '', details: [], impact: '', requested: '',
  };
  return renderComplaintPdf({
    id: row.id, kind: row.kind, date: row.created_at.slice(0, 10).split('-').reverse().join('.'),
    customer: { name: row.customer_name ?? '', contact: row.customer_contact ?? '', email: row.customer_email ?? '', country: row.customer_country ?? '' },
    orderNo: row.order_no ?? '', by: userModel.findById(row.created_by)?.display_name ?? req.user!.display_name ?? '', polished: p,
    items: parse<ComplaintItem[]>(row.items_json, []), amount: row.amount_wasted, currency: row.currency,
    images: imagesOf(row.id).filter((i) => fs.existsSync(imagePath(i.stored_name))).map((i) => ({ file: imagePath(i.stored_name), caption: i.caption ?? '' })),
  });
}

router.get('/:id/pdf', async (req: AuthedRequest, res) => {
  const row = openRow(req, res);
  if (!row) return;
  const pdf = await pdfOf(req, row);
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `inline; filename="TECE-Complaint-${row.id}.pdf"`);
  res.send(pdf);
});

// send it: the PDF goes with a short e-mail to Tarik, the person and the assistant of the country
router.post('/:id/send', async (req: AuthedRequest, res) => {
  const row = openRow(req, res);
  if (!row) return;
  if (row.internal_status) return res.status(400).json({ error: 'This complaint is already with quality.' });
  if (!row.reason_code) return res.status(400).json({ error: 'Choose the complaint reason (step 3) before sending.' });
  if (!parse<Polished | null>(row.polished_json, null)) return res.status(400).json({ error: 'Let the AI write the text first (or write it), then send.' });
  const base = recipientsFor(req, row);
  const extra = splitEmails(str(req.body?.extra, 400));
  const test = req.body?.test === true;
  const to = [...base.to, ...extra.filter((a) => !base.to.includes(a))];
  const polished = parse<Polished>(row.polished_json, { title: '', summary: '', details: [], impact: '', requested: '' });
  try {
    const pdf = await pdfOf(req, row);
    const subject = `Müşteri şikâyeti: ${row.customer_name}${row.order_no ? ` - ${row.order_no}` : ''}`;
    const body = [
      'Merhaba,',
      `${row.customer_name}${row.customer_country ? ` (${row.customer_country})` : ''} için bir müşteri şikâyeti kaydedildi. Ayrıntılar ekteki PDF formundadır.`,
      `${polished.title}${row.amount_wasted !== null ? `\nKayıp tutar: ${row.amount_wasted.toLocaleString('tr-TR', { minimumFractionDigits: 2 })} ${row.currency}` : ''}`,
      'İlgilenmenizi rica ederim.',
      'Saygılarımla',
    ].join('\n\n');
    await sendThankYouEmail({
      to: to.join(', '), cc: base.cc.join(', ') || null, subject, body, replyTo: req.user!.email,
      attachments: [{ filename: `TECE-Sikayet-${row.id}.pdf`, content: pdf, contentType: 'application/pdf' }],
      signature: buildSignature(req.user, styleFor(req.user)), testTo: test ? req.user!.email : null,
    });
    if (test) return res.json({ test: true, sentTo: req.user!.email });
  } catch (err) {
    console.error('Send complaint failed:', err);
    return res.status(502).json({ error: 'Failed to send email', message: (err as Error).message });
  }
  db.prepare("UPDATE complaints SET status = 'sent', sent_at = datetime('now'), sent_to = ?, internal_status = 'Yeni kayıt', submitted_at = datetime('now') WHERE id = ?").run([...to, ...base.cc].join(', '), row.id);
  logEvent(row.id, req.user!.id, 'status', null, 'Yeni kayıt', 'Sent to quality by sales', false);
  void noticeToQuality(row, req.user!.display_name || req.user!.username);
  if (row.card_id) activityModel.add({ userId: req.user!.id, cardId: row.card_id, type: 'note', text: `Complaint sent: ${polished.title}` });
  res.json({ ok: true, sentTo: [...to, ...base.cc] });
});

export default router;
