const EMAIL_RE = /^[^\s@,;]+@[^\s@,;]+\.[^\s@,;]+$/;

// A visitor may have more than one address (two business cards on one form):
// "a@x.com, b@y.com" or "a@x.com; b@y.com". Returns the valid ones, de-duplicated.
export function splitEmails(value: string | null | undefined): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const part of (value ?? '').split(/[,;\s]+/)) {
    const address = part.trim().replace(/^<|>$/g, '');
    if (!EMAIL_RE.test(address) || seen.has(address.toLowerCase())) continue;
    seen.add(address.toLowerCase());
    out.push(address);
  }
  return out;
}

// True when every address in the text is valid (for the AI "uncertain" flag).
export function allEmailsValid(value: string): boolean {
  const parts = value.split(/[,;\s]+/).filter(Boolean);
  return parts.length > 0 && parts.every((p) => EMAIL_RE.test(p.replace(/^<|>$/g, '')));
}
