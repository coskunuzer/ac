import fs from 'fs';
import { Router } from 'express';
import { db } from '../db/connection';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { cardModel } from '../models/cardModel';
import { userModel } from '../models/userModel';
import { canSeeCard } from '../services/visibility';
import { archiveFile, type ArchiveRow } from '../services/archive';
import { activityModel } from '../models/activityModel';
import { clearRadarCache } from '../services/radar';

const router = Router();
router.use(requireAuth);

const shape = (r: ArchiveRow) => ({ droppedAt: r.dropped_at ?? null, supersededBy: r.superseded_by ?? null, confirmedAt: r.confirmed_at ?? null, confirmedBy: r.confirmed_by ? userModel.findById(r.confirmed_by)?.display_name ?? null : null, id: r.id, kind: r.kind, cardId: r.card_id, title: r.title, fileName: r.file_name, createdAt: r.created_at, by: r.created_by ? userModel.findById(r.created_by)?.display_name ?? null : null });

// the earlier PDFs: of one customer (proformas), or the price lists (everybody who may make offers may look at them)
router.get('/', (req: AuthedRequest, res) => {
  const kind = req.query.kind === 'price_list' ? 'price_list' : 'proforma';
  if (kind === 'proforma') {
    const card = cardModel.findById(parseInt(String(req.query.cardId ?? ''), 10));
    if (!card) return res.status(404).json({ error: 'Not found' });
    if (!canSeeCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
    return res.json((db.prepare("SELECT * FROM document_archive WHERE kind = 'proforma' AND card_id = ? ORDER BY id DESC LIMIT 100").all(card.id) as unknown as ArchiveRow[]).map(shape));
  }
  res.json((db.prepare("SELECT * FROM document_archive WHERE kind = 'price_list' ORDER BY id DESC LIMIT 200").all() as unknown as ArchiveRow[]).map(shape));
});

// "The customer does not want it any more": one click closes the waiting proforma. The open proforma opportunity is closed as lost; it can be taken back.
router.post('/:id/drop', (req: AuthedRequest, res) => {
  const row = db.prepare('SELECT * FROM document_archive WHERE id = ?').get(parseInt(String(req.params.id), 10)) as ArchiveRow | undefined;
  if (!row || row.kind !== 'proforma' || !row.card_id) return res.status(404).json({ error: 'Not found' });
  const card = cardModel.findById(row.card_id);
  if (!card || !canSeeCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  if (req.body?.dropped === false) {
    db.prepare('UPDATE document_archive SET dropped_at = NULL, dropped_by = NULL WHERE id = ?').run(row.id);
    activityModel.add({ userId: req.user!.id, cardId: card.id, type: 'stage', text: `Proforma open again: ${row.title ?? 'proforma'}` });
  } else {
    db.prepare("UPDATE document_archive SET dropped_at = datetime('now'), dropped_by = ? WHERE id = ?").run(req.user!.id, row.id);
    db.prepare("UPDATE opportunities SET status = 'lost', closed_at = datetime('now') WHERE id = (SELECT id FROM opportunities WHERE card_id = ? AND status = 'open' AND kind = 'proforma' ORDER BY id DESC LIMIT 1)").run(card.id);
    activityModel.add({ userId: req.user!.id, cardId: card.id, type: 'stage', text: `Proforma closed, the customer does not want it any more: ${row.title ?? 'proforma'}` });
  }
  clearRadarCache();
  res.json(shape(db.prepare('SELECT * FROM document_archive WHERE id = ?').get(row.id) as unknown as ArchiveRow));
});

// "The order is confirmed": the customer said yes to this proforma. The customer becomes a customer, the open proforma opportunity is won, and the waiting list loses it.
router.post('/:id/confirm', (req: AuthedRequest, res) => {
  const row = db.prepare('SELECT * FROM document_archive WHERE id = ?').get(parseInt(String(req.params.id), 10)) as ArchiveRow | undefined;
  if (!row || row.kind !== 'proforma' || !row.card_id) return res.status(404).json({ error: 'Not found' });
  const card = cardModel.findById(row.card_id);
  if (!card || !canSeeCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  const undo = req.body?.confirmed === false;
  if (undo) {
    db.prepare('UPDATE document_archive SET confirmed_at = NULL, confirmed_by = NULL WHERE id = ?').run(row.id);
    db.prepare('UPDATE document_archive SET superseded_by = NULL WHERE superseded_by = ?').run(row.id);
    activityModel.add({ userId: req.user!.id, cardId: card.id, type: 'stage', text: `Order confirmation taken back: ${row.title ?? 'proforma'}` });
  } else {
    db.prepare("UPDATE document_archive SET confirmed_at = datetime('now'), confirmed_by = ?, superseded_by = NULL WHERE id = ?").run(req.user!.id, row.id);
    // the earlier proformas of this customer that were still waiting were drafts of this order: they are replaced by it
    db.prepare("UPDATE document_archive SET superseded_by = ? WHERE kind = 'proforma' AND card_id = ? AND id < ? AND confirmed_at IS NULL AND superseded_by IS NULL").run(row.id, row.card_id, row.id);
    // the proforma opportunity of this customer is won
    db.prepare("UPDATE opportunities SET status = 'won', closed_at = datetime('now') WHERE id = (SELECT id FROM opportunities WHERE card_id = ? AND status = 'open' AND kind = 'proforma' ORDER BY id DESC LIMIT 1)").run(card.id);
    // a prospect that orders is a customer now
    if (card.stage !== 'customer') db.prepare("UPDATE cards SET stage = 'customer', pipeline_stage = CASE WHEN COALESCE(pipeline_stage, 0) < 6 THEN 6 ELSE pipeline_stage END, exit_status = NULL, updated_at = datetime('now') WHERE id = ?").run(card.id);
    activityModel.add({ userId: req.user!.id, cardId: card.id, type: 'stage', text: `Order confirmed: ${row.title ?? 'proforma'}` });
  }
  clearRadarCache();
  const after = db.prepare('SELECT * FROM document_archive WHERE id = ?').get(row.id) as unknown as ArchiveRow;
  res.json(shape(after));
});

router.get('/:id/file', (req: AuthedRequest, res) => {
  const row = db.prepare('SELECT * FROM document_archive WHERE id = ?').get(parseInt(String(req.params.id), 10)) as ArchiveRow | undefined;
  if (!row || !fs.existsSync(archiveFile(row))) return res.status(404).json({ error: 'Not found' });
  if (row.kind === 'proforma') {
    const card = row.card_id ? cardModel.findById(row.card_id) : undefined;
    if (!card || !canSeeCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  }
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `inline; filename="${row.file_name.replace(/[^\w.\- ]+/g, '_')}"`);
  res.sendFile(archiveFile(row));
});

export default router;
