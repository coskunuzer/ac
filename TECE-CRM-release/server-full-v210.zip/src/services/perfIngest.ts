import crypto from 'crypto';
import * as XLSX from 'xlsx';
import { db } from '../db/connection';
import { settingsModel } from '../models/settingsModel';
import { companyKey } from './companyKey';

// The five SAP / Excel exports behind the Performance page. Two of them are kept and grow (the ledger of every customer), the other four are
// snapshots: each upload replaces the table.

export const KINDS = ['ledger', 'backlog', 'blockers', 'dispatch', 'sap'] as const;
export type UploadKind = (typeof KINDS)[number];
export interface IngestReport { kind: UploadKind; rows: number; added: number; note: string; unresolved?: number }

// ---- reading cells -------------------------------------------------------------------------------------------------------------
// "12,164.75 €", "-€ 0.00", "$33.15", "6,520.800", 92407.27
export function num(v: unknown): number | null {
  if (v === null || v === undefined) return null;
  if (typeof v === 'number') return Number.isFinite(v) ? v : null;
  const s = String(v).trim();
  if (!s) return null;
  const neg = /^-|-\s*[€$]|[€$]\s*-|\(.*\)/.test(s) && /\d/.test(s);
  const digits = s.replace(/[^\d.,]/g, '');
  if (!/\d/.test(digits)) return null;
  // 1.234,56 (decimal comma) or 1,234.56
  let t = digits;
  if (/,\d{1,2}$/.test(t) && !/\.\d{3}/.test(t.replace(/,\d{1,2}$/, '')) && t.includes(',') && (t.match(/,/g) ?? []).length === 1 && !t.includes('.')) t = t.replace(',', '.');
  else if (/\.\d{3},\d{1,2}$/.test(t)) t = t.replace(/\./g, '').replace(',', '.');
  else t = t.replace(/,/g, '');
  const n = parseFloat(t);
  return Number.isFinite(n) ? (neg ? -Math.abs(n) : n) : null;
}

const pad = (n: number) => String(n).padStart(2, '0');
// "10/30/26", "12/6/11", "05/2/2007", "2026-10-30", "30.10.2026" -> YYYY-MM-DD
export function isoDate(v: unknown): string | null {
  if (v === null || v === undefined) return null;
  if (v instanceof Date) return `${v.getFullYear()}-${pad(v.getMonth() + 1)}-${pad(v.getDate())}`;
  const s = String(v).trim();
  let m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s);
  if (m) return `${m[1]}-${m[2]}-${m[3]}`;
  m = /^(\d{1,2})\.(\d{1,2})\.(\d{4})$/.exec(s);
  if (m) return `${m[3]}-${pad(+m[2])}-${pad(+m[1])}`;
  m = /^(\d{1,2})\/(\d{1,2})\/(\d{2,4})/.exec(s);
  if (m) {
    let y = +m[3];
    if (y < 100) y += y < 70 ? 2000 : 1900;
    const mo = +m[1];
    const d = +m[2];
    if (mo < 1 || mo > 12 || d < 1 || d > 31) return null;
    return `${y}-${pad(mo)}-${pad(d)}`;
  }
  return null;
}

const text = (v: unknown) => String(v ?? '').trim();
const key = (v: unknown) => text(v).normalize('NFC');
const pick = (row: Record<string, unknown>, ...names: string[]) => {
  for (const n of names) if (row[n] !== undefined && row[n] !== '') return row[n];
  return '';
};
function table(buffer: Buffer, sheet?: string): Record<string, unknown>[] {
  const wb = XLSX.read(buffer, { type: 'buffer' });
  const name = sheet && wb.SheetNames.includes(sheet) ? sheet : wb.SheetNames[0];
  return XLSX.utils.sheet_to_json<Record<string, unknown>>(wb.Sheets[name], { defval: '', raw: false });
}

export const usdPerEur = (): number => {
  const n = parseFloat(settingsModel.get('perf_usd_per_eur') ?? '');
  return Number.isFinite(n) && n > 0.5 && n < 2 ? n : 1.1;
};
export const toEur = (amount: number, currency: string): number => (currency === 'USD' ? amount / usdPerEur() : amount);

const log = (kind: UploadKind, fileName: string, rows: number, added: number, note: string, by: number | null) =>
  db.prepare('INSERT INTO perf_uploads (kind, file_name, rows, added, note, by_user) VALUES (?, ?, ?, ?, ?, ?)').run(kind, fileName.slice(0, 160), rows, added, note.slice(0, 300), by);

// ---- A. the ledger ---------------------------------------------------------------------------------------------------------------
const SKIP_SHEETS = /^(usd|euro|eur)$/i;

export function ingestLedger(buffer: Buffer, fileName: string, by: number | null): IngestReport {
  const wb = XLSX.read(buffer, { type: 'buffer' });
  const has = db.prepare('SELECT 1 FROM ledger_transactions WHERE hash = ?');
  const ins = db.prepare('INSERT OR IGNORE INTO ledger_transactions (hash, sheet_name, seq, tx_date, description, debit, credit, balance, currency) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
  let rows = 0;
  let added = 0;
  let removed = 0;
  const touched = new Set<string>();
  const inFile = new Set<string>();
  const finalBalance = new Map<string, number>(); // the balance at the bottom of the sheet: what the sheet says is owed today
  const todayIso = new Date().toISOString().slice(0, 10);
  db.exec('BEGIN');
  try {
    for (const sheetName of wb.SheetNames) {
      if (SKIP_SHEETS.test(sheetName.trim())) continue;
      const grid = XLSX.utils.sheet_to_json<unknown[]>(wb.Sheets[sheetName], { header: 1, defval: '', raw: false });
      // the money of this sheet is in euro unless a dollar sign is the first currency seen
      let currency = 'EUR';
      for (const r of grid) {
        const m = [r[2], r[3], r[4]].map((c) => String(c ?? '')).join(' ');
        if (/€/.test(m)) { currency = 'EUR'; break; }
        if (/\$/.test(m)) { currency = 'USD'; break; }
      }
      const seen = new Map<string, number>();
      const keep = new Set<string>();
      for (const r of grid) { const b = String(r[4] ?? '').trim() ? num(r[4]) : null; if (b !== null) finalBalance.set(sheetName, b); }
      inFile.add(sheetName);
      grid.forEach((r, i) => {
        let date = isoDate(r[0]);
        let desc = text(r[1]);
        // some old sheets have the date inside the text ("05/2/2007 TARİH VE 556295 NOLU FATURA")
        if (!date) {
          const m = /^(\d{1,2}\/\d{1,2}\/\d{4})\s*(.*)$/.exec(desc);
          if (m) { date = isoDate(m[1]); desc = m[2] || desc; }
        }
        if (!date) return;
        // a year typed wrongly (10/31/27 on an invoice TEZ2024...): the year of the invoice number is used
        if (date > todayIso) {
          const y = /(?:TEZ|TTE|COS)(20\d\d)/i.exec(desc)?.[1];
          if (y && `${y}${date.slice(4)}` <= todayIso) date = `${y}${date.slice(4)}`;
        }
        const debit = num(r[2]);
        const credit = num(r[3]);
        if (debit === null && credit === null) return;
        const balance = num(r[4]);
        rows += 1;
        const base = `${sheetName}|${date}|${desc}|${debit ?? ''}|${credit ?? ''}`;
        const occ = (seen.get(base) ?? 0) + 1;
        seen.set(base, occ);
        const hash = crypto.createHash('sha256').update(`${base}|#${occ}`).digest('hex');
        keep.add(hash);
        if (has.get(hash)) return;
        ins.run(hash, sheetName, i, date, desc.slice(0, 300), debit, credit, balance, currency);
        added += 1;
        touched.add(sheetName);
      });
      // a line that was corrected or taken out of the sheet must go from the database too (otherwise old and new lines add up)
      const old = db.prepare('SELECT id, hash FROM ledger_transactions WHERE sheet_name = ?').all(sheetName) as { id: number; hash: string }[];
      for (const o of old) {
        if (keep.has(o.hash)) continue;
        db.prepare('DELETE FROM ledger_transactions WHERE id = ?').run(o.id);
        removed += 1;
        touched.add(sheetName);
      }
    }
    // the summary of every sheet that got new lines (and of every sheet that has none yet)
    const all = (db.prepare('SELECT DISTINCT sheet_name FROM ledger_transactions').all() as { sheet_name: string }[]).map((r) => r.sheet_name);
    for (const sheet of all) if (touched.has(sheet) || !db.prepare('SELECT 1 FROM customer_financial_summary WHERE sheet_name = ?').get(sheet)) summarise(sheet);
    // what the sheet says at the bottom is the balance (the last line by date can be a wrong year)
    for (const [sheet, bal] of finalBalance) {
      db.prepare("UPDATE customer_financial_summary SET balance = ?, updated_at = datetime('now') WHERE sheet_name = ? AND ABS(balance - ?) > 0.004").run(bal, sheet, bal);
    }
    db.exec('COMMIT');
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
  const resolved = resolveAliases();
  const gone = (db.prepare('SELECT DISTINCT sheet_name FROM ledger_transactions').all() as { sheet_name: string }[]).filter((r) => !inFile.has(r.sheet_name)).length;
  const note = `${rows} lines read, ${added} new, ${removed} old lines removed (corrected in the file); ${touched.size} customer sheets changed; ${resolved.unresolved} sheets not matched to a SAP customer yet${gone ? `; ${gone} sheets in the database are not in this file (kept)` : ''}`;
  log('ledger', fileName, rows, added, note, by);
  return { kind: 'ledger', rows, added, note, unresolved: resolved.unresolved };
}

function summarise(sheet: string): void {
  const rows = db.prepare('SELECT tx_date, debit, credit, balance, currency FROM ledger_transactions WHERE sheet_name = ? ORDER BY tx_date, seq, id').all(sheet) as { tx_date: string; debit: number | null; credit: number | null; balance: number | null; currency: string }[];
  if (!rows.length) { db.prepare('DELETE FROM customer_financial_summary WHERE sheet_name = ?').run(sheet); return; }
  const last = rows[rows.length - 1];
  // the balance the ledger itself shows on its last line; when a sheet has none, debits minus credits
  const withBalance = [...rows].reverse().find((r) => r.balance !== null);
  const sum = rows.reduce((a, r) => a + (r.debit ?? 0) - (r.credit ?? 0), 0);
  const invoices = rows.filter((r) => (r.debit ?? 0) > 0);
  const payments = rows.filter((r) => (r.credit ?? 0) > 0);
  db.prepare(
    `INSERT OR REPLACE INTO customer_financial_summary (sheet_name, currency, balance, tx_count, first_date, last_invoice_date, last_payment_date, last_transaction_date, total_invoiced, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))`
  ).run(sheet, last.currency, withBalance?.balance ?? sum, rows.length, rows[0].tx_date, invoices.at(-1)?.tx_date ?? null, payments.at(-1)?.tx_date ?? null, last.tx_date, invoices.reduce((a, r) => a + (r.debit ?? 0), 0));
}

// ---- B. C. D. the snapshots -----------------------------------------------------------------------------------------------------
export function ingestBacklog(buffer: Buffer, fileName: string, by: number | null): IngestReport {
  const rows = table(buffer);
  db.exec('BEGIN');
  try {
    db.exec('DELETE FROM export_production_backlog');
    const ins = db.prepare('INSERT INTO export_production_backlog (order_no, item_no, doc_date, delivery_date, sap_no, customer, product_group, material, material_name, thickness, width, roll_length, pending_qty, unit, pending_kg, pending_m2, value_eur, customer_ref) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    for (const r of rows) {
      if (!text(r['Sipariş No'])) continue;
      ins.run(text(r['Sipariş No']), text(r['Kalem No']), isoDate(r['Belge tarihi']), isoDate(r['Teslimat tarihi']), text(r['Cari Kod']), text(r['Cari Ünvan']), text(r['Ürün Grubu Tanımı']), text(r['Malzeme Kod']), text(r['Malzeme Adı']),
        num(r['Kalınlık']), num(r['Genişlik']), num(r['Rulo/Bobin Boyu']), num(r['Bekleyen Miktar']), text(r['Sat ÖB']), num(r['Bekleyen KG']), num(r['Bekleyen M2']), num(r['Satış Bekleyen Fiyat(EUR)']), text(r['Müşteri malzeme numarası']));
    }
    db.exec('COMMIT');
  } catch (err) { db.exec('ROLLBACK'); throw err; }
  const n = (db.prepare('SELECT COUNT(*) AS n FROM export_production_backlog').get() as { n: number }).n;
  const note = `${n} order lines still to be delivered`;
  log('backlog', fileName, rows.length, n, note, by);
  return { kind: 'backlog', rows: rows.length, added: n, note };
}

export function ingestBlockers(buffer: Buffer, fileName: string, by: number | null): IngestReport {
  const rows = table(buffer);
  db.exec('BEGIN');
  try {
    db.exec('DELETE FROM export_pipeline_blockers');
    const ins = db.prepare('INSERT INTO export_pipeline_blockers (sd_no, item_no, doc_date, sap_no, customer, material, material_name, thickness, width, qty, unit, net_value, currency, confirmed, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    for (const r of rows) {
      const sd = text(r['SD belgesi']);
      if (!sd) continue;
      // the first column (no heading) says whether the order is confirmed ("Hayır" = not yet); "Durum" is mostly empty
      ins.run(sd, text(r['Kalem (SD)']), isoDate(r['Belge tarihi']), text(r['Müşteri Kodu']), text(r['Müşteri adı']), text(r['Malzeme']), text(r['Malzeme kısa metni']), num(r['Kalınlık Bilgisi(mm)']), num(r['Genişlik Bilgisi(mm)']),
        num(r['Sipariş miktarı']), text(r['Satış ölçü birimi']), num(r['Net değer']), text(r['Belge para birimi']) || 'EUR', text(pick(r, '', '__EMPTY')), text(r['Durum']));
    }
    db.exec('COMMIT');
  } catch (err) { db.exec('ROLLBACK'); throw err; }
  const n = (db.prepare('SELECT COUNT(*) AS n FROM export_pipeline_blockers').get() as { n: number }).n;
  const orders = (db.prepare('SELECT COUNT(DISTINCT sd_no) AS n FROM export_pipeline_blockers').get() as { n: number }).n;
  const note = `${orders} orders (${n} lines) waiting for confirmation or the advance payment`;
  log('blockers', fileName, rows.length, n, note, by);
  return { kind: 'blockers', rows: rows.length, added: n, note };
}

export function ingestDispatch(buffer: Buffer, fileName: string, by: number | null): IngestReport {
  const rows = table(buffer);
  db.exec('BEGIN');
  try {
    db.exec('DELETE FROM export_dispatch_queue');
    const ins = db.prepare('INSERT INTO export_dispatch_queue (sd_no, billing_date, sap_no, customer, country, city, net_value, currency, weight, sales_rep, ops_rep) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    for (const r of rows) {
      const sd = text(r['SD belgesi']);
      if (!sd) continue;
      ins.run(sd, isoDate(r['Faturalama tarihi']), text(r['Sipariş veren']), text(r['Siparişi verenin adı']), text(r['Alıcı ülke']), text(r['Sipariş verenin yeri']), num(r['Net değer']), text(r['Belge para birimi']) || 'EUR', num(r['Ağırlık']),
        text(r['Satış Sorumlusu']), text(r['Operasyon Sorumlusu']));
    }
    db.exec('COMMIT');
  } catch (err) { db.exec('ROLLBACK'); throw err; }
  const n = (db.prepare('SELECT COUNT(*) AS n FROM export_dispatch_queue').get() as { n: number }).n;
  const note = `${n} shipments ready for dispatch`;
  log('dispatch', fileName, rows.length, n, note, by);
  return { kind: 'dispatch', rows: rows.length, added: n, note };
}

// ---- E. the SAP customer master -------------------------------------------------------------------------------------------------
const statusKey = (s: string): string => (/aktif|active/i.test(s) ? 'active' : /pasif|passive/i.test(s) ? 'passive' : 'dormant');

export function ingestSap(buffer: Buffer, fileName: string, by: number | null): IngestReport {
  const rows = table(buffer, 'Müşteri Listesi');
  if (!rows.length || rows[0]['SAP Müşteri No'] === undefined) throw new Error('This does not look like the SAP customer list: there is no "SAP Müşteri No" column.');
  db.exec('BEGIN');
  try {
    db.exec('DELETE FROM sap_customers');
    const ins = db.prepare('INSERT OR REPLACE INTO sap_customers (sap_no, name, country, contact, email, phone, website, first_order, last_order, status, status_key, orders, m2, net_eur, net_usd, note) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    for (const r of rows) {
      const no = text(r['SAP Müşteri No']);
      if (!no) continue;
      ins.run(no, text(r['Müşteri Adı (SAP)']), text(r['Ülke']), text(r['İletişim Kişisi']), text(r['E-posta']).toLowerCase(), text(r['Telefon']), text(r['Web Sitesi']), isoDate(r['İlk Sipariş']), isoDate(r['Son Sipariş']), text(r['Durum']), statusKey(text(r['Durum'])),
        num(r['Sipariş Adedi']), num(r['Toplam m²']), num(r['Net Satış (EUR)']), num(r['Net Satış (USD)']), text(r['Not']));
    }
    db.exec('COMMIT');
  } catch (err) { db.exec('ROLLBACK'); throw err; }
  const n = (db.prepare('SELECT COUNT(*) AS n FROM sap_customers').get() as { n: number }).n;
  const resolved = resolveAliases();
  const note = `${n} SAP customers; ${resolved.unresolved} ledger sheets not matched yet`;
  log('sap', fileName, rows.length, n, note, by);
  return { kind: 'sap', rows: rows.length, added: n, note, unresolved: resolved.unresolved };
}

// ---- the tab alias resolver ------------------------------------------------------------------------------------------------------
// "ACEM SPA-ITALYA" (a ledger tab) is "ACEM S.P.A." in SAP: the country after the last dash is dropped, then the names are compared without legal endings.
const COUNTRY_TAIL = /\s*(?:[-–—]\s*[^-–—]{2,30}|\([^)]{2,25}\))\s*$/;
const LEGAL = new Set(['ltd', 'llc', 'srl', 'spa', 'gmbh', 'inc', 'sas', 'sarl', 'doo', 'ooo', 'pvt', 'private', 'limited', 'company', 'co', 'sa', 'ag', 'bv', 'nv', 'trading', 'traders', 'group', 'the', 'and', 'tece', 'dekor', 'sanayi', 'ticaret', 'international', 'industries', 'industry', 'import', 'imports', 'export', 'wood', 'panels', 'materials', 'building']);
const fold = (s: string) => s.replace(/İ/g, 'i').normalize('NFD').replace(/\p{Diacritic}/gu, '').replace(/ı/g, 'i').toLowerCase();
export function sheetKey(sheet: string): string | null {
  const base = sheet.replace(COUNTRY_TAIL, '');
  return companyKey(base) ?? companyKey(sheet);
}
const firstWord = (s: string): string | null => fold(s.replace(COUNTRY_TAIL, '')).replace(/[^a-z0-9]+/g, ' ').split(' ').filter((w) => w.length >= 4 && !LEGAL.has(w)).at(0) ?? null;
const words = (s: string) => new Set(fold(s.replace(COUNTRY_TAIL, '')).replace(/[^a-z0-9]+/g, ' ').split(' ').filter((w) => w.length >= 3));

export interface AliasResult { resolved: number; unresolved: number }

export function resolveAliases(): AliasResult {
  const sheets = (db.prepare('SELECT sheet_name FROM customer_financial_summary').all() as { sheet_name: string }[]).map((r) => r.sheet_name);
  const customers = db.prepare('SELECT sap_no, name FROM sap_customers').all() as { sap_no: string; name: string }[];
  if (!customers.length) return { resolved: 0, unresolved: sheets.length };
  const lastOrder = new Map((db.prepare('SELECT sap_no, last_order FROM sap_customers').all() as { sap_no: string; last_order: string | null }[]).map((r) => [r.sap_no, r.last_order ?? '']));
  const byKey = new Map<string, string[]>();
  for (const c of customers) {
    const k = companyKey(c.name);
    if (k) (byKey.get(k) ?? byKey.set(k, []).get(k)!).push(c.sap_no);
  }
  const cards = db.prepare("SELECT id, sap, company_key FROM cards WHERE sap IS NOT NULL AND sap != ''").all() as { id: number; sap: string; company_key: string | null }[];
  const cardOf = new Map(cards.map((c) => [c.sap.trim(), c.id]));
  const has = db.prepare('SELECT is_manually_verified AS v FROM customer_aliases WHERE sheet_name = ?');
  const put = db.prepare("INSERT INTO customer_aliases (sheet_name, sap_no, card_id, is_manually_verified, how) VALUES (?, ?, ?, 0, ?) ON CONFLICT(sheet_name) DO UPDATE SET sap_no = excluded.sap_no, card_id = excluded.card_id, how = excluded.how WHERE customer_aliases.is_manually_verified = 0");
  let resolved = 0;
  for (const sheet of sheets) {
    const done = has.get(sheet) as { v: number } | undefined;
    if (done?.v) { resolved += 1; continue; }
    let sap: string | null = null;
    let how = '';
    // 1. a SAP number written in the tab name
    const code = /(1202\d{6})/.exec(sheet)?.[1];
    if (code && customers.some((c) => c.sap_no === code)) { sap = code; how = 'SAP number in the name'; }
    // 2. the same name without legal endings and without the country
    if (!sap) {
      const k = sheetKey(sheet);
      const hits = k ? byKey.get(k) : undefined;
      if (hits?.length === 1) { sap = hits[0]; how = 'same name'; }
    }
    // 3. the words of the tab are all in one SAP name (or the other way round), when only one SAP customer fits
    if (!sap) {
      const a = words(sheet);
      if (a.size) {
        const fits = customers.filter((c) => {
          const b = words(c.name);
          if (!b.size) return false;
          const common = [...a].filter((w) => b.has(w)).length;
          return common >= Math.min(a.size, b.size) && common >= (Math.min(a.size, b.size) >= 2 ? 2 : 1) && common / Math.max(a.size, b.size) >= 0.5;
        });
        if (fits.length === 1) { sap = fits[0].sap_no; how = 'words of the name'; }
      }
    }
    // 4. the first distinctive word is the same and only one SAP customer starts with it (a name that appears twice: the one that ordered last)
    if (!sap) {
      const w = firstWord(sheet);
      if (w) {
        const fits = customers.filter((c) => firstWord(c.name) === w);
        const names = new Set(fits.map((c) => fold(c.name).replace(/[^a-z0-9]+/g, ' ').trim()));
        if (fits.length === 1 || (fits.length > 1 && names.size === 1)) {
          sap = [...fits].sort((x, y) => (lastOrder.get(y.sap_no) ?? '').localeCompare(lastOrder.get(x.sap_no) ?? ''))[0].sap_no;
          how = 'first word of the name';
        }
      }
    }
    if (sap) { put.run(sheet, sap, cardOf.get(sap) ?? null, how); resolved += 1; }
    else db.prepare('DELETE FROM customer_aliases WHERE sheet_name = ? AND is_manually_verified = 0').run(sheet);
  }
  // the CRM customer of every SAP number that has none yet
  return { resolved, unresolved: sheets.length - resolved };
}

export function ingest(kind: UploadKind, buffer: Buffer, fileName: string, by: number | null): IngestReport {
  switch (kind) {
    case 'ledger': return ingestLedger(buffer, fileName, by);
    case 'backlog': return ingestBacklog(buffer, fileName, by);
    case 'blockers': return ingestBlockers(buffer, fileName, by);
    case 'dispatch': return ingestDispatch(buffer, fileName, by);
    case 'sap': return ingestSap(buffer, fileName, by);
  }
}
void key;
