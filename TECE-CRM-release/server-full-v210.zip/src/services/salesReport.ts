import { db } from '../db/connection';
import { canonicalCountry } from '../models/countryModel';
import { inEuro, setsFor, usdPerEur, type Account } from './perfAnalytics';
import { visibilitySql, type Viewer } from './visibility';

// The sales report: what was invoiced, month by month, quarter by quarter or year by year - for the whole team, for each country and for each
// employee - and what the team did in each country (offers, samples, visits ...) from the CRM. Everything is limited to the customers the viewer may see.

export type Period = 'month' | 'quarter' | 'year';
export interface Activity { newCustomers: number; offers: number; samples: number; visits: number; calls: number; notes: number; emails: number }
export interface ReportRow {
  name: string;
  values: number[];
  total: number;
  /** the same stretch of the year before (the same months), for the comparison */
  prevTotal: number;
  yoy: number | null;
  share: number;
  customers: number; // customers invoiced in the period
  accounts: number; // customers of the country / employee
  waiting: number; ready: number; production: number; overdue: number;
  activity: Activity;
}
export interface SalesReport {
  year: number; period: Period; currency: string; columns: string[]; elapsed: number; rep: string | null; asOf: string;
  team: ReportRow;
  byCountry: ReportRow[];
  byRep: ReportRow[];
  reps: string[];
}

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const todayIso = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });
const round = (n: number) => Math.round(n * 100) / 100;
const noActivity = (): Activity => ({ newCustomers: 0, offers: 0, samples: 0, visits: 0, calls: 0, notes: 0, emails: 0 });

// the invoiced amount of an account in each column, and the same stretch of the year before
function series(a: Account, year: number, period: Period, elapsed: number): { values: number[]; prev: number } {
  const m = a.monthly[year] ?? Array(12).fill(0);
  const pm = a.monthly[year - 1] ?? Array(12).fill(0);
  if (period === 'month') return { values: m.slice(), prev: pm.slice(0, elapsed).reduce((x, y) => x + y, 0) };
  if (period === 'quarter') return { values: [0, 1, 2, 3].map((q) => m.slice(q * 3, q * 3 + 3).reduce((x, y) => x + y, 0)), prev: pm.slice(0, elapsed).reduce((x, y) => x + y, 0) };
  return { values: [year - 4, year - 3, year - 2, year - 1, year].map((y) => a.years[y] ?? 0), prev: pm.slice(0, elapsed).reduce((x, y) => x + y, 0) };
}

export function salesReport(viewer: Viewer, opts: { year?: number; period?: Period; rep?: string | null; cur?: string | null }): SalesReport {
  const today = todayIso();
  const thisYear = Number(today.slice(0, 4));
  const year = opts.year && opts.year >= 2015 && opts.year <= thisYear + 1 ? opts.year : thisYear;
  const period: Period = opts.period === 'quarter' || opts.period === 'year' ? opts.period : 'month';
  const rep = opts.rep || null;
  const cur = opts.cur === 'USD' || opts.cur === 'EUR' ? opts.cur : 'ALL';
  const rate = usdPerEur();
  // the months that have happened this year (the comparison with last year uses the same months)
  const elapsed = year < thisYear ? 12 : year > thisYear ? 0 : Number(today.slice(5, 7));
  const columns = period === 'month' ? MONTHS : period === 'quarter' ? ['Q1', 'Q2', 'Q3', 'Q4'] : [year - 4, year - 3, year - 2, year - 1, year].map(String);

  const sets = setsFor(viewer, rep);
  let accounts = sets.live.concat(sets.dead);
  accounts = cur === 'ALL' ? accounts.map((a) => inEuro(a, rate)) : accounts.filter((a) => a.currency === cur);
  const currency = cur === 'USD' ? 'USD' : 'EUR';

  const blank = (name: string): ReportRow => ({ name, values: Array(columns.length).fill(0), total: 0, prevTotal: 0, yoy: null, share: 0, customers: 0, accounts: 0, waiting: 0, ready: 0, production: 0, overdue: 0, activity: noActivity() });
  const add = (row: ReportRow, a: Account) => {
    const s = series(a, year, period, elapsed);
    s.values.forEach((v, i) => { row.values[i] += v; });
    row.prevTotal += s.prev;
    row.accounts += 1;
    if (s.values.some((v) => v > 0)) row.customers += 1;
    row.waiting += a.waitingValue; row.ready += a.readyValue; row.production += a.backlogValue; row.overdue += a.overdue;
  };
  const team = blank('Team');
  const countries = new Map<string, ReportRow>();
  const reps = new Map<string, ReportRow>();
  for (const a of accounts) {
    add(team, a);
    const c = (canonicalCountry(a.country || '') as string).trim() || '—';
    add(countries.get(c) ?? countries.set(c, blank(c)).get(c)!, a);
    const r = (a.rep || '—').trim() || '—';
    add(reps.get(r) ?? reps.set(r, blank(r)).get(r)!, a);
  }

  // what was done, from the CRM: counted over the year of the report, on the customers this person may see
  const params: Record<string, string | number> = { from: `${year}-01-01`, to: `${year}-12-31 23:59:59` };
  const vis = visibilitySql(viewer, params);
  const rows = db.prepare(`SELECT CASE WHEN cards.market = 'domestic' THEN 'Türkiye' ELSE COALESCE(NULLIF(TRIM(cards.country), ''), '—') END AS country, COALESCE((SELECT display_name FROM users WHERE users.id = a.user_id), '—') AS rep, a.type AS type, COUNT(*) AS n
      FROM activities a JOIN cards ON cards.id = a.card_id
      WHERE a.created_at >= @from AND a.created_at <= @to AND COALESCE(a.imported, 0) = 0${vis ? ` AND ${vis}` : ''} GROUP BY country, rep, type`).all(params) as { country: string; rep: string; type: string; n: number }[];
  const bump = (act: Activity, type: string, n: number) => {
    if (type === 'created' || type === 'scan') act.newCustomers += n;
    else if (type === 'offer') act.offers += n;
    else if (type === 'sample') act.samples += n;
    else if (type === 'visit' || type === 'meeting') act.visits += n;
    else if (type === 'call') act.calls += n;
    else if (type === 'note') act.notes += n;
    else if (type === 'email' || type === 'thank_you' || type === 'documents') act.emails += n;
  };
  for (const r0 of rows) {
    const r = { ...r0, country: r0.country === 'Türkiye' ? r0.country : (canonicalCountry(r0.country) as string) };
    if (rep && r.rep !== rep) continue;
    bump(team.activity, r.type, r.n);
    bump((countries.get(r.country) ?? countries.set(r.country, blank(r.country)).get(r.country)!).activity, r.type, r.n);
    bump((reps.get(r.rep) ?? reps.set(r.rep, blank(r.rep)).get(r.rep)!).activity, r.type, r.n);
  }
  const finish = (row: ReportRow): ReportRow => {
    row.values = row.values.map(round);
    row.total = round(period === 'year' ? row.values[row.values.length - 1] : row.values.reduce((x, y) => x + y, 0));
    row.prevTotal = round(row.prevTotal);
    row.yoy = row.prevTotal > 0 ? round(((period === 'year' ? row.total : row.values.slice(0, period === 'month' ? elapsed : Math.ceil(elapsed / 3)).reduce((x, y) => x + y, 0)) / row.prevTotal - 1) * 100) : null;
    row.share = team.total > 0 ? round((row.total / team.total) * 100) : 0;
    row.waiting = round(row.waiting); row.ready = round(row.ready); row.production = round(row.production); row.overdue = round(row.overdue);
    return row;
  };
  // the totals first (the shares need the team total)
  team.values = team.values.map(round);
  team.total = round(period === 'year' ? team.values[team.values.length - 1] : team.values.reduce((x, y) => x + y, 0));
  const list = (m: Map<string, ReportRow>) => [...m.values()].map(finish).filter((r) => r.total > 0 || r.accounts > 0 || Object.values(r.activity).some((v) => v > 0)).sort((a, b) => b.total - a.total || a.name.localeCompare(b.name));
  finish(team);

  return { year, period, currency, columns, elapsed, rep, asOf: today, team, byCountry: list(countries), byRep: list(reps), reps: [...new Set(setsFor(viewer, null).live.map((a) => a.rep).filter(Boolean))].sort() };
}
