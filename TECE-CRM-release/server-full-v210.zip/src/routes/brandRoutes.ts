import { Router } from 'express';
import { db } from '../db/connection';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { SQL_RATING } from '../models/cardModel';

// The brand manager's dashboard: how the leads, the introduction e-mails, the campaigns and the catalogues are doing.
// A brand manager sees their own work (the leads they brought in, the e-mails they sent); an admin sees everybody's.
const router = Router();
router.use(requireAuth);

const weeks = (n: number): { from: string; label: string }[] => {
  const out: { from: string; label: string }[] = [];
  const now = new Date();
  const monday = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() - ((now.getUTCDay() + 6) % 7)));
  for (let i = n - 1; i >= 0; i -= 1) {
    const d = new Date(monday.getTime() - i * 7 * 86400000);
    out.push({ from: d.toISOString().slice(0, 10), label: d.toISOString().slice(5, 10) });
  }
  return out;
};

router.get('/summary', (req: AuthedRequest, res) => {
  const me = req.user!;
  const all = me.role === 'admin';
  const own = all ? '' : ' AND uploaded_by = @me';
  const ownMail = all ? '' : ' AND user_id = @me';
  const p: Record<string, number> = all ? {} : { me: me.id }; // an admin's queries have no @me, and node:sqlite refuses a parameter that nothing uses
  const ws = weeks(8);
  const since = ws[0].from;

  const leadWeeks = db.prepare(`SELECT date(created_at, '-' || ((CAST(strftime('%w', created_at) AS INTEGER) + 6) % 7) || ' days') AS wk, COUNT(*) AS n FROM cards WHERE date(created_at) >= @since${own} GROUP BY wk`).all({ ...p, since }) as { wk: string; n: number }[];
  const mailWeeks = db.prepare(`SELECT date(sent_at, '-' || ((CAST(strftime('%w', sent_at) AS INTEGER) + 6) % 7) || ' days') AS wk, COUNT(*) AS n FROM sent_emails WHERE kind IN ('personal', 'documents') AND date(sent_at) >= @since${ownMail} GROUP BY wk`).all({ ...p, since }) as { wk: string; n: number }[];
  const fill = (rows: { wk: string; n: number }[]) => ws.map((w) => ({ label: w.label, n: rows.find((r) => r.wk === w.from)?.n ?? 0 }));

  const count = (sql: string) => (db.prepare(sql).get(p) as { n: number }).n;
  const leads = count(`SELECT COUNT(*) AS n FROM cards WHERE 1=1${own}`);
  const leads30 = count(`SELECT COUNT(*) AS n FROM cards WHERE created_at >= datetime('now', '-30 days')${own}`);
  const withEmail = count(`SELECT COUNT(*) AS n FROM cards WHERE COALESCE(email, '') != ''${own}`);
  const contacted = count(`SELECT COUNT(DISTINCT card_id) AS n FROM sent_emails WHERE card_id IS NOT NULL AND kind IN ('personal', 'documents')${ownMail}`);
  const countries = db.prepare(`SELECT country, COUNT(*) AS n FROM cards WHERE COALESCE(country, '') != ''${own} GROUP BY country ORDER BY n DESC LIMIT 8`).all(p) as { country: string; n: number }[];

  const campaigns = (db.prepare("SELECT id, title, status, created_at AS createdAt FROM newsletters ORDER BY id DESC LIMIT 6").all() as { id: number; title: string; status: string; createdAt: string }[]).map((c) => {
    const r = db.prepare('SELECT status, COUNT(*) AS n FROM newsletter_recipients WHERE newsletter_id = ? GROUP BY status').all(c.id) as { status: string; n: number }[];
    const g = (s: string) => r.find((x) => x.status === s)?.n ?? 0;
    return { ...c, sent: g('sent'), failed: g('failed'), queued: g('queued') };
  });
  const sentTotal = (db.prepare("SELECT COUNT(*) AS n FROM newsletter_recipients WHERE status = 'sent'").get() as { n: number }).n;
  const docs = db.prepare('SELECT id, title, kind, size_bytes AS size, created_at AS createdAt FROM library_documents ORDER BY id DESC LIMIT 8').all() as { id: number; title: string; kind: string; size: number; createdAt: string }[];
  const docCount = (db.prepare('SELECT COUNT(*) AS n FROM library_documents').get() as { n: number }).n;

  // how the leads rate (the rating is the person's own, or the AI's estimate until then)
  const rated = db.prepare(`SELECT CASE WHEN r IS NULL THEN 'none' WHEN r >= 7 THEN 'high' WHEN r >= 4 THEN 'mid' ELSE 'low' END AS band, COUNT(*) AS n FROM (SELECT ${SQL_RATING} AS r FROM cards WHERE 1=1${own}) GROUP BY band`).all(p) as { band: string; n: number }[];
  const band = (b: string) => rated.find((x) => x.band === b)?.n ?? 0;
  // leads with an e-mail address that nobody has written to yet: the next things to do
  const ownC = own.replace('uploaded_by', 'c.uploaded_by');
  const notWritten = "NOT EXISTS (SELECT 1 FROM sent_emails s WHERE s.card_id = c.id AND s.kind IN ('personal', 'documents'))";
  const waiting = db.prepare(`SELECT c.id, COALESCE(NULLIF(c.company, ''), NULLIF(c.name, ''), 'Lead') AS name, c.country FROM cards c WHERE COALESCE(c.email, '') != ''${ownC} AND ${notWritten} ORDER BY c.created_at DESC LIMIT 6`).all(p) as { id: number; name: string; country: string | null }[];
  const waitingN = count(`SELECT COUNT(*) AS n FROM cards c WHERE COALESCE(c.email, '') != ''${ownC} AND ${notWritten}`);
  // by country: how many, and how many are rated high
  const byCountry = db.prepare(`SELECT country, COUNT(*) AS n, SUM(CASE WHEN r >= 7 THEN 1 ELSE 0 END) AS high FROM (SELECT country, ${SQL_RATING} AS r FROM cards WHERE COALESCE(country, '') != ''${own}) GROUP BY country ORDER BY n DESC LIMIT 8`).all(p) as { country: string; n: number; high: number | null }[];

  res.json({
    ratings: { high: band('high'), mid: band('mid'), low: band('low'), none: band('none') }, waiting, waitingN, countriesRated: byCountry.map((c) => ({ ...c, high: c.high ?? 0 })),
    scope: all ? 'everybody' : 'me',
    kpis: { leads, leads30, withEmail, contacted, campaignMails: sentTotal, documents: docCount },
    leadWeeks: fill(leadWeeks), mailWeeks: fill(mailWeeks), countries, campaigns, docs,
    funnel: [{ label: 'Leads found', n: leads }, { label: 'With an e-mail', n: withEmail }, { label: 'Introduced', n: contacted }],
  });
});

export default router;
