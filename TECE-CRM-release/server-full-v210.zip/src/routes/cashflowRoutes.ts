import { Router } from 'express';
import { requireAuth, requireAdmin, type AuthedRequest } from '../middleware/auth';
import { cashFlow } from '../services/cashFlow';
import { todayIstanbul } from '../services/todos';

// Cash flow: admin only. Pick two dates; see the money that comes in between them. Reads only.
const router = Router();
router.use(requireAuth, requireAdmin);

const DAY = /^\d{4}-\d{2}-\d{2}$/;
const addDays = (iso: string, n: number) => new Date(Date.parse(`${iso}T12:00:00Z`) + n * 86_400_000).toISOString().slice(0, 10);

router.get('/', (req: AuthedRequest, res) => {
  const today = todayIstanbul();
  const from = typeof req.query.from === 'string' && DAY.test(req.query.from) ? req.query.from : today;
  let to = typeof req.query.to === 'string' && DAY.test(req.query.to) ? req.query.to : addDays(from, 29);
  if (to < from) return res.status(400).json({ error: 'The last day is before the first day.' });
  // a window of up to three years
  if (Date.parse(to) - Date.parse(from) > 1100 * 86_400_000) to = addDays(from, 1100);
  res.json(cashFlow(req.user!, from, to));
});

export default router;
