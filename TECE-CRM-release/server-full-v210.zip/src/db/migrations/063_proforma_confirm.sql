-- A proforma that was sent is "waiting" until the customer confirms the order: one button on the Proforma tab marks it.
ALTER TABLE document_archive ADD COLUMN confirmed_at TEXT;
ALTER TABLE document_archive ADD COLUMN confirmed_by INTEGER;
CREATE INDEX IF NOT EXISTS idx_archive_waiting ON document_archive (kind, confirmed_at, card_id);
