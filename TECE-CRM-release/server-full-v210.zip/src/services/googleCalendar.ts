import jwt from 'jsonwebtoken';
import { db } from '../db/connection';
import { env } from '../config/env';
import { settingsModel } from '../models/settingsModel';

// Each person can connect their own Google Calendar: their meetings show in the CRM next to their notes, and a meeting made in
// the CRM (linked to a customer) is written to their calendar. It needs a Google "OAuth client" (see the setup note in README).

// (the addresses can be pointed at a stand-in for testing; in real use they are Google's)
const AUTH = process.env.GOOGLE_AUTH_URL || 'https://accounts.google.com/o/oauth2/v2/auth';
const TOKEN = process.env.GOOGLE_TOKEN_URL || 'https://oauth2.googleapis.com/token';
const API = process.env.GOOGLE_CALENDAR_API || 'https://www.googleapis.com/calendar/v3';
const SCOPES = 'https://www.googleapis.com/auth/calendar.events openid email';

// The Google "OAuth client" can be typed in by an admin (Admin > Calendar setup) - no server file to edit. The environment is the fallback.
function cfg() {
  return {
    id: settingsModel.get('google_client_id') || env.googleClientId,
    secret: settingsModel.get('google_client_secret') || env.googleClientSecret,
    base: (settingsModel.get('public_url') || env.publicUrl).replace(/\/+$/, ''),
  };
}
export const configured = () => !!cfg().id && !!cfg().secret;
const redirectUri = () => `${cfg().base}/api/calendar/callback`;

export function getConfig(): { clientId: string; hasSecret: boolean; publicUrl: string; redirectUri: string; source: 'admin' | 'server' | 'none' } {
  const c = cfg();
  const fromAdmin = !!settingsModel.get('google_client_id');
  return { clientId: c.id, hasSecret: !!c.secret, publicUrl: c.base, redirectUri: redirectUri(), source: !c.id ? 'none' : fromAdmin ? 'admin' : 'server' };
}

export const connectedCount = (): number => (db.prepare('SELECT COUNT(*) AS n FROM google_calendar').get() as { n: number }).n;

export function setConfig(input: { clientId: string; clientSecret?: string; publicUrl: string }): void {
  settingsModel.set('google_client_id', input.clientId.trim());
  if (input.clientSecret && input.clientSecret.trim()) settingsModel.set('google_client_secret', input.clientSecret.trim());
  settingsModel.set('public_url', input.publicUrl.trim().replace(/\/+$/, ''));
  cache.clear();
}

export function status(userId: number): { configured: boolean; connected: boolean; email: string | null } {
  const row = db.prepare('SELECT email FROM google_calendar WHERE user_id = ?').get(userId) as { email: string | null } | undefined;
  return { configured: configured(), connected: !!row, email: row?.email ?? null };
}

export function authUrl(userId: number): string {
  const state = jwt.sign({ userId, k: 'calendar' }, env.jwtSecret, { expiresIn: '15m' });
  const q = new URLSearchParams({ client_id: cfg().id, redirect_uri: redirectUri(), response_type: 'code', scope: SCOPES, access_type: 'offline', prompt: 'consent', include_granted_scopes: 'true', state });
  return `${AUTH}?${q.toString()}`;
}

// Google sends the person back with a code: it is exchanged for a permission we can keep (a refresh token).
export async function handleCallback(code: string, state: string): Promise<number> {
  const payload = jwt.verify(state, env.jwtSecret) as { userId: number; k: string };
  if (payload.k !== 'calendar') throw new Error('Wrong state');
  const res = await fetch(TOKEN, {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ code, client_id: cfg().id, client_secret: cfg().secret, redirect_uri: redirectUri(), grant_type: 'authorization_code' }),
  });
  const data = (await res.json()) as { refresh_token?: string; id_token?: string; error_description?: string; scope?: string };
  if (!res.ok || !data.refresh_token) throw new Error(data.error_description || 'Google did not give a permission to keep. Try again.');
  // Google lets a person untick single permissions on the consent screen: without the calendar one nothing can be read or written
  if (data.scope && !data.scope.includes('calendar.events')) throw new Error('The calendar permission was not ticked on the Google screen. Connect again and leave "See, edit, share and permanently delete calendars" ticked.');
  let email: string | null = null;
  try {
    email = (JSON.parse(Buffer.from(String(data.id_token).split('.')[1], 'base64url').toString('utf8')) as { email?: string }).email ?? null;
  } catch {
    email = null;
  }
  db.prepare('INSERT OR REPLACE INTO google_calendar (user_id, email, refresh_token) VALUES (?, ?, ?)').run(payload.userId, email, data.refresh_token);
  return payload.userId;
}

export function disconnect(userId: number): void {
  db.prepare('DELETE FROM google_calendar WHERE user_id = ?').run(userId);
  cache.delete(userId);
}

const cache = new Map<number, { token: string; until: number }>();
async function accessToken(userId: number): Promise<string> {
  const hit = cache.get(userId);
  if (hit && hit.until > Date.now()) return hit.token;
  const row = db.prepare('SELECT refresh_token FROM google_calendar WHERE user_id = ?').get(userId) as { refresh_token: string } | undefined;
  if (!row) throw new Error('Your Google Calendar is not connected.');
  const res = await fetch(TOKEN, {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ client_id: cfg().id, client_secret: cfg().secret, refresh_token: row.refresh_token, grant_type: 'refresh_token' }),
  });
  const data = (await res.json()) as { access_token?: string; expires_in?: number; error?: string };
  if (!res.ok || !data.access_token) {
    if (data.error === 'invalid_grant') disconnect(userId); // the person took the permission away in Google
    throw new Error('Google did not accept the connection any more. Connect your calendar again.');
  }
  cache.set(userId, { token: data.access_token, until: Date.now() + ((data.expires_in ?? 3600) - 120) * 1000 });
  return data.access_token;
}

export async function deleteEvent(userId: number, eventId: string): Promise<void> {
  const token = await accessToken(userId);
  const res = await fetch(`${API}/calendars/primary/events/${encodeURIComponent(eventId)}?sendUpdates=none`, { method: 'DELETE', headers: { authorization: `Bearer ${token}` }, signal: AbortSignal.timeout(15000) });
  if (!res.ok && res.status !== 410) {
    const e = (await res.json().catch(() => ({}))) as { error?: { message?: string } };
    throw new Error(e.error?.message || `Google answered ${res.status}`);
  }
}

// Tries each step of the connection and says what Google answered: the access, reading the calendar, writing an event, removing it again.
export async function testConnection(userId: number): Promise<{ step: string; ok: boolean; message: string }[]> {
  const out: { step: string; ok: boolean; message: string }[] = [];
  const step = async <T>(name: string, fn: () => Promise<T>, okText: (v: T) => string): Promise<T | null> => {
    try {
      const v = await fn();
      out.push({ step: name, ok: true, message: okText(v) });
      return v;
    } catch (err) {
      out.push({ step: name, ok: false, message: (err as Error).message });
      return null;
    }
  };
  if (!(await step('Access', () => accessToken(userId), () => 'Google accepted the connection.'))) return out;
  const now = new Date();
  await step('Read the calendar', () => listEvents(userId, now.toISOString(), new Date(now.getTime() + 7 * 86400000).toISOString()), (l) => `${l.length} events in the next 7 days.`);
  const start = new Date(now.getTime() + 3600000);
  const made = await step('Write an event', () => createEvent(userId, { title: 'TECE CRM test (you can ignore this)', startIso: start.toISOString(), endIso: new Date(start.getTime() + 600000).toISOString() }), (e) => `Created (${e.id}).`);
  if (made) await step('Remove the test event', () => deleteEvent(userId, made.id), () => 'Removed again.');
  return out;
}

export interface CalendarEvent {
  id: string;
  title: string;
  start: string; // ISO date-time, or a date for an all-day event
  end: string;
  allDay: boolean;
  location: string | null;
  link: string | null;
  meetLink?: string | null; // the Google Meet address, when the meeting has one
  cardId: number | null; // the customer, when the meeting was made in the CRM
}

export async function listEvents(userId: number, fromIso: string, toIso: string): Promise<CalendarEvent[]> {
  const token = await accessToken(userId);
  const q = new URLSearchParams({ timeMin: fromIso, timeMax: toIso, singleEvents: 'true', orderBy: 'startTime', maxResults: '250' });
  const res = await fetch(`${API}/calendars/primary/events?${q.toString()}`, { headers: { authorization: `Bearer ${token}` }, signal: AbortSignal.timeout(15000) });
  const data = (await res.json()) as { items?: Record<string, any>[]; error?: { message?: string } };
  if (!res.ok) throw new Error(data.error?.message || 'Could not read the calendar.');
  return (data.items ?? [])
    .filter((e) => e.status !== 'cancelled')
    .map((e) => ({
      id: String(e.id),
      title: String(e.summary ?? '(no title)'),
      start: String(e.start?.dateTime ?? e.start?.date),
      end: String(e.end?.dateTime ?? e.end?.date),
      allDay: !e.start?.dateTime,
      location: e.location ? String(e.location) : null,
      link: e.htmlLink ? String(e.htmlLink) : null,
      meetLink: e.hangoutLink ? String(e.hangoutLink) : null,
      cardId: e.extendedProperties?.private?.crmCard ? parseInt(String(e.extendedProperties.private.crmCard), 10) || null : null,
    }));
}

// Move a meeting to another day (dragging it in the calendar): the clock time and the length stay, only the day changes.
// Guests are told by Google when the meeting has guests. An all-day event keeps its number of days.
export async function moveEvent(userId: number, eventId: string, toDay: string): Promise<{ id: string; title: string; start: string; end: string; allDay: boolean; cardId: number | null; oldStart: string }> {
  const token = await accessToken(userId);
  const url = `${API}/calendars/primary/events/${encodeURIComponent(eventId)}`;
  const got = await fetch(url, { headers: { authorization: `Bearer ${token}` }, signal: AbortSignal.timeout(15000) });
  const cur = (await got.json().catch(() => ({}))) as Record<string, any> & { error?: { message?: string } };
  if (!got.ok) throw new Error(cur.error?.message || 'Could not read the meeting.');
  const dayIn = (d: Date) => d.toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });
  const days = (a: string, b: string) => Math.round((Date.parse(`${b}T12:00:00Z`) - Date.parse(`${a}T12:00:00Z`)) / 86400000);
  const plus = (d: string, n: number) => new Date(Date.parse(`${d}T12:00:00Z`) + n * 86400000).toISOString().slice(0, 10);
  let body: Record<string, unknown>;
  let oldStart: string;
  if (!cur.start?.dateTime) {
    oldStart = String(cur.start?.date ?? '');
    const len = Math.max(1, days(oldStart, String(cur.end?.date ?? oldStart)));
    body = { start: { date: toDay }, end: { date: plus(toDay, len) } };
  } else {
    const s = new Date(String(cur.start.dateTime)); const e = new Date(String(cur.end?.dateTime ?? cur.start.dateTime));
    oldStart = s.toISOString();
    const delta = days(dayIn(s), toDay) * 86400000;
    body = { start: { dateTime: new Date(s.getTime() + delta).toISOString(), timeZone: cur.start.timeZone }, end: { dateTime: new Date(e.getTime() + delta).toISOString(), timeZone: cur.end?.timeZone ?? cur.start.timeZone } };
  }
  const guests = Array.isArray(cur.attendees) && cur.attendees.length > 0;
  const res = await fetch(`${url}?sendUpdates=${guests ? 'all' : 'none'}`, { method: 'PATCH', headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json' }, body: JSON.stringify(body), signal: AbortSignal.timeout(15000) });
  const e = (await res.json().catch(() => ({}))) as Record<string, any> & { error?: { message?: string } };
  if (!res.ok) throw new Error(e.error?.message || 'Google did not move the meeting.');
  return { id: String(e.id), title: String(e.summary ?? ''), start: String(e.start?.dateTime ?? e.start?.date), end: String(e.end?.dateTime ?? e.end?.date), allDay: !e.start?.dateTime, cardId: e.extendedProperties?.private?.crmCard ? parseInt(String(e.extendedProperties.private.crmCard), 10) || null : null, oldStart };
}

export async function createEvent(
  userId: number,
  input: { title: string; startIso: string; endIso: string; description?: string; location?: string; attendeeEmail?: string; attendees?: string[]; meet?: boolean; cardId?: number }
): Promise<CalendarEvent> {
  const token = await accessToken(userId);
  const guests = [...new Set([...(input.attendees ?? []), ...(input.attendeeEmail ? [input.attendeeEmail] : [])].map((e) => e.trim().toLowerCase()).filter(Boolean))];
  const body = {
    summary: input.title,
    description: input.description || undefined,
    location: input.location || undefined,
    start: { dateTime: input.startIso },
    end: { dateTime: input.endIso },
    attendees: guests.length ? guests.map((email) => ({ email })) : undefined,
    conferenceData: input.meet ? { createRequest: { requestId: `tece-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, conferenceSolutionKey: { type: 'hangoutsMeet' } } } : undefined,
    extendedProperties: input.cardId ? { private: { crmCard: String(input.cardId) } } : undefined,
  };
  const res = await fetch(`${API}/calendars/primary/events?sendUpdates=${guests.length ? 'all' : 'none'}${input.meet ? '&conferenceDataVersion=1' : ''}`, {
    method: 'POST',
    headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json' },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(15000),
  });
  const e = (await res.json()) as Record<string, any> & { error?: { message?: string } };
  if (!res.ok) throw new Error(e.error?.message || 'Could not create the meeting.');
  return { id: String(e.id), title: String(e.summary), start: String(e.start?.dateTime), end: String(e.end?.dateTime), allDay: false, location: e.location ? String(e.location) : null, link: e.htmlLink ? String(e.htmlLink) : null, meetLink: e.hangoutLink ? String(e.hangoutLink) : null, cardId: input.cardId ?? null };
}
