import { Router } from 'express';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { visibilitySql } from '../services/visibility';
import { db } from '../db/connection';
import type { CardRow } from '../models/cardModel';
import { userModel } from '../models/userModel';
import { exhibitionModel } from '../models/exhibitionModel';
import { offerLogModel } from '../models/pricingModels';
import { resolveTemplate } from '../services/thankYouEmail';
import { adviseEmailKind } from '../services/emailKind';
import { mailProblems, realFairIds } from '../services/emailSafety';

// A read-only review of the thank-you e-mails that are waiting: what each one would say, and what is wrong with it.
// Nothing is sent and nothing is changed here.
const router = Router();
router.use(requireAuth);

router.get('/thank-yous', (req: AuthedRequest, res) => {
  const user = req.user!;
  const params: Record<string, string | number> = {};
  const vis = visibilitySql(user, params);
  const rows = db
    .prepare(`SELECT * FROM cards WHERE thank_you_sent_at IS NULL AND email IS NOT NULL AND TRIM(email) != ''${vis ? ` AND ${vis}` : ''} ORDER BY created_at DESC LIMIT 1500`)
    .all(params) as unknown as CardRow[];
  const fairs = realFairIds();
  const thanked = new Set(offerLogModel.listAll().filter((o) => o.kind === 'thank_you').map((o) => o.cardId));
  const out: { id: number; name: string | null; company: string | null; email: string | null; country: string | null; fair: string | null; subject: string; problems: string[]; advice: string; adviceReason: string }[] = [];
  let ok = 0;
  for (const card of rows) {
    if (thanked.has(card.id)) continue;
    const exhibition = exhibitionModel.findById(card.exhibition_id);
    const fairName = exhibition?.name ?? null;
    const responsible = card.person ? userModel.findByDisplayName(card.person) : undefined;
    const custom = responsible?.email_template_subject && responsible?.email_template_body ? { subject: responsible.email_template_subject, body: responsible.email_template_body } : null;
    const exTpl = exhibition?.email_template_subject && exhibition?.email_template_body ? { subject: exhibition.email_template_subject, body: exhibition.email_template_body } : null;
    const t = resolveTemplate(card, fairName, custom, exTpl);
    const problems = mailProblems({ subject: t.subject, body: t.body, kind: 'thank_you', fairName: fairs.has(card.exhibition_id) ? fairName : null }).map((p) => p.message);
    const advice = adviseEmailKind(card);
    if (!problems.length) { ok++; continue; }
    out.push({ id: card.id, name: card.name, company: card.company, email: card.email, country: card.country, fair: fairs.has(card.exhibition_id) ? fairName : null, subject: t.subject, problems, advice: advice.kind, adviceReason: advice.reason });
  }
  res.json({ waiting: out.length + ok, fine: ok, blocked: out.length, rows: out.slice(0, 300) });
});

export default router;
