import * as XLSX from 'xlsx';
import { colorByOtherCode, colorBySap, normaliseSap, type ColorCode } from './colorDb';
import type { OfferParams, PriceBook } from './priceBook';

// The proforma: a customer's order (in whatever form it comes) turned into lines with a SAP code, priced from the price list through the colour
// database. No AI: the order is read by rules and the person checks every line.

export type Field = 'code' | 'description' | 'sap' | 'meters' | 'rolls' | 'thickness' | 'width' | 'rollLength';
export type Mapping = Partial<Record<Field, number>>;

export interface OrderTable {
  sheetNames: string[];
  sheet: string | null;
  headers: string[];
  rows: string[][];
  mapping: Mapping;
  headerFound: boolean;
}

// ---- 1. reading the order --------------------------------------------------------------------------------------------------------------
const HEAD: [Field, RegExp][] = [
  ['sap', /\bsap\b|malzeme\s*kod|material\s*(code|no|number)|art[ií]?(kel|cle|culo)?\.?\s*(no|nr|code|cod)\b|item\s*(code|no)/i],
  ['rollLength', /roll\s*length|rulo\s*boy|длина\s*рулона|longitud\s*(del\s*)?rollo/i],
  ['rolls', /\brolls?\b|\brulo\b|\brollos?\b|рулон/i],
  ['thickness', /thick|kal[ıi]nl[ıi]k|espesor|grosor|толщин|\bth\b\.?|\bt\s*\(?mm/i],
  ['width', /width|geni[şs]lik|ancho|ширин|\bw\s*\(?mm/i],
  ['meters', /\bmeters?\b|\bmetres?\b|\bmetros?\b|\bmt\b|\bmtr\b|\blm\b|\blfm\b|miktar|order\s*in\s*m\b|quantity|\bqty\b|amount|cantidad|количество|\badet\b|\blength\b/i],
  ['description', /desc|name|colou?r|renk|decor|dekor|desen|product|[üu]r[üu]n|producto|наимен|описан|artikel/i],
  ['code', /^(customer\s*)?(code|kod|ref|reference|no|#|item)\b|colou?r\s*(code|no)|dekor\s*no|decor\s*(no|code)|\bcod\.?$/i],
];

const clean = (v: unknown): string => String(v ?? '').replace(/\s+/g, ' ').trim();

// A number as people write it: 6.300 or 6,300 (thousands), 0,8 or 0.8 (decimals), 1.234,5.
export function numOf(raw: string, thousands = true): number | null {
  let s = raw.replace(/[^\d.,-]/g, '');
  if (!/\d/.test(s)) return null;
  if (thousands && /^-?\d{1,3}([.,]\d{3})+$/.test(s)) s = s.replace(/[.,]/g, '');
  else if (s.includes(',') && s.includes('.')) s = s.lastIndexOf(',') > s.lastIndexOf('.') ? s.replace(/\./g, '').replace(',', '.') : s.replace(/,/g, '');
  else s = s.replace(',', '.');
  const n = parseFloat(s);
  return Number.isFinite(n) ? n : null;
}

function guessMapping(headers: string[], sample: string[][]): Mapping {
  const mapping: Mapping = {};
  const taken = new Set<number>();
  headers.forEach((h, i) => {
    if (!h) return;
    for (const [field, re] of HEAD) {
      if (mapping[field] === undefined && re.test(h)) {
        mapping[field] = i;
        taken.add(i);
        return;
      }
    }
  });
  // columns without a usable heading are read from what is in them
  const width = Math.max(headers.length, ...sample.map((r) => r.length), 0);
  for (let i = 0; i < width; i++) {
    if (taken.has(i)) continue;
    const vals = sample.map((r) => clean(r[i])).filter(Boolean);
    if (vals.length < 2) continue;
    const share = (test: (v: string) => boolean) => vals.filter(test).length / vals.length;
    if (mapping.sap === undefined && share((v) => /\b\d{5}[. ]\d{2,3}\b/.test(v)) >= 0.5) mapping.sap = i;
    else if (mapping.thickness === undefined && share((v) => { const n = numOf(v, false); return n !== null && n >= 0.25 && n <= 3 && /^[\d.,]+\s*(mm)?$/i.test(v); }) >= 0.8) mapping.thickness = i;
    else if (mapping.width === undefined && share((v) => { const n = numOf(v, false); return n !== null && n >= 10 && n <= 70 && /^[\d.,]+\s*(mm)?$/i.test(v); }) >= 0.8) mapping.width = i;
    else if (mapping.meters === undefined && share((v) => { const n = numOf(v); return n !== null && n >= 50 && /^[\d.,\s]+(m|mt|mtr)?$/i.test(v); }) >= 0.8) mapping.meters = i;
    else if (mapping.description === undefined && share((v) => /[a-zA-Zçğıöşü]{3}/.test(v)) >= 0.8) mapping.description = i;
    else continue;
    taken.add(i);
  }
  if (mapping.description === undefined && mapping.code !== undefined) mapping.description = mapping.code;
  return mapping;
}

function tableFromGrid(grid: string[][], sheetNames: string[], sheet: string | null): OrderTable {
  const rows = grid.map((r) => r.map(clean)).filter((r) => r.some(Boolean));
  // the heading row: the first rows that name at least two of the things we look for
  let headIndex = -1;
  let best = 1;
  rows.slice(0, 15).forEach((r, i) => {
    // a heading row names the columns: short words, no quantities. A line of the order itself ("22mm x 2mm 5000 meter") is not one.
    if (r.some((c) => /\d{3,}/.test(c) || c.length > 40)) return;
    const hits = new Set(r.flatMap((c) => HEAD.filter(([, re]) => c && re.test(c)).map(([f]) => f))).size;
    if (hits > best) { best = hits; headIndex = i; }
  });
  const headers = headIndex >= 0 ? rows[headIndex] : [];
  const body = rows.slice(headIndex + 1);
  const mapping = guessMapping(headers, body.slice(0, 30));
  return { sheetNames, sheet, headers: headers.length ? headers : (body[0] ?? []).map((_, i) => `Column ${i + 1}`), rows: body.slice(0, 1000), mapping, headerFound: headIndex >= 0 };
}

export function parseOrderFile(buffer: Buffer, sheet?: string): OrderTable {
  const wb = XLSX.read(buffer, { type: 'buffer' });
  const names = wb.SheetNames;
  // the sheet that has the most filled rows, unless one was asked for
  const pick = sheet && names.includes(sheet) ? sheet : [...names].sort((a, b) => count(wb.Sheets[b]) - count(wb.Sheets[a]))[0];
  const grid = XLSX.utils.sheet_to_json<unknown[]>(wb.Sheets[pick], { header: 1, defval: '', raw: false, blankrows: false }) as string[][];
  return tableFromGrid(grid, names, pick);
}
const count = (ws: XLSX.WorkSheet) => (ws['!ref'] ? XLSX.utils.decode_range(ws['!ref']).e.r : 0);

// Text copied from an e-mail, a PDF or Excel: columns are separated by tabs, semicolons, commas or two or more spaces.
export function parseOrderText(textIn: string): OrderTable {
  const lines = textIn.replace(/\r/g, '').split('\n').filter((l) => l.trim());
  const sep = lines.some((l) => l.includes('\t')) ? /\t/ : lines.some((l) => l.includes(';')) ? /;/ : lines.filter((l) => (l.match(/,/g) ?? []).length >= 2).length > lines.length / 2 ? /,(?=(?:[^"]*"[^"]*")*[^"]*$)/ : /\s{2,}|\s\|\s/;
  return tableFromGrid(lines.map((l) => l.split(sep).map((c) => c.replace(/^"|"$/g, ''))), [], null);
}

// ---- 2. the table as lines ------------------------------------------------------------------------------------------------------------
export interface LineInput {
  code: string;
  description: string;
  sap: string;
  meters: number | null;
  thickness: number | null;
  width: number | null;
  rollLength: number | null;
  // a price typed by hand (per m²); it replaces the one of the price list
  priceM2?: number | null;
  // how the SAP code was found: typed in the order, found in the row, or matched from the colour code of the order
  sapSource?: 'column' | 'row' | 'code' | 'typed' | null;
}

// The standard roll length (m) by thickness (the packaging page of the price list).
export function defaultRollLength(thickness: number | null): number | null {
  if (!thickness) return null;
  if (thickness <= 0.45) return 300;
  if (thickness <= 0.65) return 200;
  if (thickness <= 1.25) return 150;
  if (thickness <= 3) return 100;
  return 50;
}

// Rolls in one box, by width (the template's own rule).
export function rollsPerBox(width: number | null): number | null {
  if (!width) return null;
  if (width >= 13 && width <= 16) return 10;
  if (width >= 19 && width <= 24) return 7;
  if (width >= 25 && width <= 34) return 5;
  if (width >= 35 && width <= 45) return 4;
  if (width >= 46 && width <= 70) return 3;
  return null;
}

// "22x0.8", "0,8 x 22 mm", "22 mm", "0.8mm" in the text of a row.
function sizesIn(text: string): { thickness: number | null; width: number | null } {
  let thickness: number | null = null;
  let width: number | null = null;
  const pair = /(\d+(?:[.,]\d+)?)\s*(?:mm)?\s*[x×*]\s*(\d+(?:[.,]\d+)?)\s*(?:mm)?/i.exec(text);
  if (pair) {
    const a = numOf(pair[1], false)!;
    const b = numOf(pair[2], false)!;
    for (const n of [a, b]) {
      if (n >= 0.25 && n <= 3 && thickness === null) thickness = n;
      else if (n >= 10 && n <= 70 && width === null) width = n;
    }
  }
  if (thickness === null) {
    const m = /(\d+(?:[.,]\d+)?)\s*mm\b/gi;
    for (const x of text.matchAll(m)) {
      const n = numOf(x[1], false)!;
      if (n >= 0.25 && n <= 3) { thickness = n; break; }
    }
  }
  if (width === null) {
    for (const x of text.matchAll(/\b(\d{2})\s*(?:mm|x|×)\b/gi)) {
      const n = parseInt(x[1], 10);
      if (n >= 10 && n <= 70) { width = n; break; }
    }
  }
  return { thickness, width };
}

export function linesFromTable(rows: string[][], mapping: Mapping, defaults: { thickness?: number | null; width?: number | null } = {}): LineInput[] {
  const out: LineInput[] = [];
  for (const r of rows) {
    const get = (f: Field) => (mapping[f] !== undefined ? clean(r[mapping[f]!]) : '');
    const rowText = r.map(clean).filter(Boolean).join(' ');
    if (!rowText || /^(grand\s*)?total|^toplam|^subtotal/i.test(clean(r[0]) || rowText)) continue;
    const description = get('description');
    const code = get('code');
    // nothing that looks like an order line (no quantity, no description)
    if (!description && !code && !get('sap') && !get('meters') && !get('rolls')) continue;

    // the SAP code: its column; else anything in the row that looks like 40001.042; else the colour code of the order
    let sap = '';
    let sapSource: LineInput['sapSource'] = null;
    const typed = get('sap');
    if (typed) {
      const n = normaliseSap(typed);
      sap = n.full ?? typed;
      sapSource = 'column';
    }
    if (!sap) {
      const m = /\b(\d{5})[. ](\d{2,3})\b/.exec(rowText);
      if (m) { sap = `${m[1]}.${m[2].padStart(3, '0')}`; sapSource = 'row'; }
    }
    if (!sap) {
      const hit = [code, description, ...r.map(clean)].filter(Boolean).map((c) => colorByOtherCode(c)).find(Boolean);
      if (hit) { sap = hit.sap; sapSource = 'code'; }
    }

    const sizes = sizesIn(rowText);
    const thickness = numOf(get('thickness'), false) ?? sizes.thickness ?? defaults.thickness ?? null;
    const width = numOf(get('width'), false) ?? sizes.width ?? defaults.width ?? null;
    let rollLength = numOf(get('rollLength')) ?? null;
    let meters = numOf(get('meters'));
    const rolls = numOf(get('rolls'));
    if (meters === null && rolls !== null) meters = rolls * (rollLength ?? defaultRollLength(thickness) ?? 0) || null;
    if (rollLength === null) rollLength = defaultRollLength(thickness);
    out.push({ code, description, sap, meters, thickness, width, rollLength, sapSource });
  }
  return out;
}

// ---- 2b. an order written as plain lines ------------------------------------------------------------------------------------------------
// "12000 Black color, 22mm x 2mm 5000 meter"   or   "10000 Beyaz Renk, 0,4mm x 22mm, 15000"
// The first number is the colour code (the TECE decor number, which is the first part of the SAP code); the sizes are told apart by their value
// (up to 3 mm is the thickness, 10 to 70 mm the width), in whichever order they come; the quantity is the number with "meter", "mt" or "m", or the last number.
export function linesFromFreeText(textIn: string, opts: { product?: 'PVC' | 'ABS' | 'PP' | null } = {}): LineInput[] {
  const out: LineInput[] = [];
  for (const raw of textIn.replace(/\r/g, '').split('\n')) {
    let s = raw.replace(/\t/g, ' ').replace(/\s+/g, ' ').trim();
    if (s.length < 3 || !/\d/.test(s)) continue;
    let sap = '';
    let sapSource: LineInput['sapSource'] = null;
    const explicit = /\b(\d{5})[. ](\d{2,3})\b/.exec(s);
    if (explicit) { sap = `${explicit[1]}.${explicit[2].padStart(3, '0')}`; sapSource = 'row'; s = s.replace(explicit[0], ' '); }

    // sizes
    let thickness: number | null = null;
    let width: number | null = null;
    // (the lines are read below with let: sizes can be set from the leftover numbers too)
    const assign = (n: number) => {
      if (n >= 0.2 && n <= 3 && thickness === null) thickness = n;
      else if (n >= 9 && n <= 610 && width === null) width = n;
    };
    const pair = /(\d+(?:[.,]\d+)?)\s*(?:mm)?\s*[x×*]\s*(\d+(?:[.,]\d+)?)\s*(?:mm)?(?![\w])/i.exec(s);
    if (pair) {
      assign(numOf(pair[1], false)!);
      assign(numOf(pair[2], false)!);
      s = s.replace(pair[0], ' ');
    }
    for (const x of [...s.matchAll(/(\d+(?:[.,]\d+)?)\s*mm\b/gi)]) {
      const n = numOf(x[1], false)!;
      if ((n >= 0.2 && n <= 3 && thickness === null) || (n >= 9 && n <= 610 && width === null)) { assign(n); s = s.replace(x[0], ' '); }
    }

    // quantity
    let meters: number | null = null;
    let rolls: number | null = null;
    const m = /(\d[\d.,]*)\s*(?:meters?|metres?|metros?|mtrs?|mts?|lfm|lm|m)\b/i.exec(s);
    const rl = /(\d[\d.,]*)\s*(?:rolls?|rulo|rollos?)\b/i.exec(s);
    if (m) { meters = numOf(m[1]); s = s.replace(m[0], ' '); }
    else if (rl) { rolls = numOf(rl[1]); s = s.replace(rl[0], ' '); }
    // the code at the start of the line (a number, or something like A1000BT)
    const lead = /^\s*([A-Za-z]{0,3}\d{3,6}[A-Za-z]{0,3})\b[\s,.:;-]*/.exec(s);
    let code = lead ? lead[1] : '';
    if (lead) s = s.slice(lead[0].length);
    if (meters === null && rolls === null) {
      const nums = [...s.matchAll(/(?<![\w.,])(\d[\d.,]*)(?![\w.,])/g)];
      // the quantity: the last number above 610 (nothing else can be that long a width); else, with the size known, the last number of 50 or more
      const big = nums.filter((n) => (numOf(n[1]) ?? 0) > 610).pop() ?? (thickness !== null && width !== null ? nums.filter((n) => (numOf(n[1]) ?? 0) >= 50).pop() : undefined);
      if (big) { meters = numOf(big[1]); s = s.slice(0, big.index) + ' ' + s.slice((big.index ?? 0) + big[0].length); }
    }
    // numbers that are left: 0.4 to 3 is the thickness, 9 to 610 the width
    for (const n of [...s.matchAll(/(?<![\w.,])(\d+(?:[.,]\d+)?)(?![\w.,])/g)]) {
      const v = numOf(n[1], false);
      if (v === null) continue;
      if (thickness === null && v >= 0.2 && v <= 3) { thickness = v; s = s.replace(n[0], ' '); }
      else if (width === null && v >= 9 && v <= 610) { width = v; s = s.replace(n[0], ' '); }
      else if (meters === null && rolls === null && v > 3) { meters = v; s = s.replace(n[0], ' '); }
    }
    const description = s.replace(/[,;]+/g, ' ').replace(/\s+/g, ' ').replace(/^[\s.:-]+|[\s.:-]+$/g, '');
    const hint = (/\b(pvc|abs|pp)\b/i.exec(raw)?.[1].toUpperCase() as 'PVC' | 'ABS' | 'PP' | undefined) ?? opts.product ?? null;

    // a 5-digit number is a SAP code only when it is in the colour database; otherwise it is a length (meters)
    let codeIsLength = false;
    if (!sap && /^\d{5}$/.test(code)) {
      const r = colorBySap(code);
      if (!r.color && !r.candidates.length) codeIsLength = true;
    }
    if (!sap && code && !codeIsLength) {
      const r = colorBySap(code);
      if (r.color) { sap = r.color.sap; sapSource = 'code'; }
      else if (r.candidates.length) {
        // several products share this decor number (PVC, ABS ...): the wanted product decides, else the person chooses
        const pick = hint ? r.candidates.filter((c) => c.productType === hint) : [];
        if (pick.length === 1) { sap = pick[0].sap; sapSource = 'code'; } else { sap = code; sapSource = 'code'; }
      } else {
        const o = colorByOtherCode(code, hint);
        if (o) { sap = o.sap; sapSource = 'code'; }
      }
    }
    if (codeIsLength) { if (meters === null) meters = numOf(code); code = ''; }
    const rollLength = defaultRollLength(thickness);
    if (meters === null && rolls !== null) meters = rolls * (rollLength ?? 0) || null;
    if (!code && !description && meters === null) continue;
    out.push({ code, description, sap, meters, thickness, width, rollLength, sapSource });
  }
  return out;
}

// ---- 3. pricing --------------------------------------------------------------------------------------------------------------------------
export interface ProformaHeader {
  name: string;
  company: string;
  address: string;
  tel: string;
  email: string;
  // the customer's number in SAP (printed on the proforma and used in the SAP order file)
  sapNumber: string;
  preparedBy: string;
  date: string; // YYYY-MM-DD
  reference: string;
  deliveryTerm: string;
  paymentTerm: string;
  dispatchTime: string;
  notes: string;
}

// A discount or an addition at the bottom: a percentage of the goods total or a fixed amount; a minus is a discount ("Discount 5 %" = -5, "Transport" = +120).
export interface Adjustment {
  label: string;
  mode: 'percent' | 'amount';
  value: number;
}

export interface ProformaData {
  header: ProformaHeader;
  currency: 'EUR' | 'USD';
  usdRate: number;
  // the price change of the whole price list for this proforma, a fraction (0.05 = +5 %)
  transportPct: number;
  lines: LineInput[];
  adjustments?: Adjustment[];
  // the customer's own prices learned from their SAP proformas (SAP code -> price per m2, in the currency of this proforma); set by the server, only for old customers
  // levels = what the customer usually pays against the list per product (-0.1 = 10 % below), used for a product they have not bought before
  memory?: { prices: Record<string, number>; levels?: Record<string, number> };
  // false: ignore the customer's own prices and use the price list
  useMemory?: boolean;
  // true (ticked by the person, default off): a product the customer never bought is priced at their usual level against the list, not at the full list
  useLevel?: boolean;
}

export interface PricedLine extends LineInput {
  found: ColorCode | null;
  candidates: ColorCode[];
  product: 'PVC' | 'ABS' | 'PP' | null;
  // what the line is when it is not PVC / ABS / PP edgebanding from the price list: Veneer, Melamine, Metal, Acrylic ... (from the colour database,
  // or read from the description the person typed). Such a line is priced by hand and printed under its own heading.
  otherProduct: string | null;
  // the name printed on the proforma for a line that has no colour of the database
  ownName: string | null;
  m2: number | null;
  rolls: number | null;
  perBox: number | null;
  boxes: number | null;
  listPriceM2: number | null;
  priceM2: number | null;
  priceSource: 'list' | 'manual' | 'memory' | 'level' | null;
  // set when the price is the list price at the customer's usual level (priceSource 'level'): -0.1 = 10 % below the list
  levelPct: number | null;
  // the customer's own price for this product, when there is one (shown next to the list price)
  memoryPriceM2: number | null;
  priceMt: number | null;
  total: number | null;
  weight: number | null;
  warnings: string[];
}

export interface MoqNote { product: string; thickness: number; kg: number; need: number; text: string }

export interface PricedProforma {
  lines: PricedLine[];
  // amount = the goods; adjustments = each discount / addition in money; grand = what the customer pays
  totals: { meters: number; m2: number; rolls: number; boxes: number; weight: number; amount: number; priced: number; unpriced: number; adjustments: { label: string; amount: number }[]; grand: number };
  moq: MoqNote[];
  priceList: boolean;
}

export function paramsFor(book: PriceBook, data: Pick<ProformaData, 'currency' | 'usdRate' | 'transportPct'>): OfferParams {
  const p = book.defaults;
  return {
    ...p,
    currency: data.currency,
    usdRate: data.currency === 'USD' ? (data.usdRate > 0 ? data.usdRate : 1.1) : 1,
    transportPct: p.transportPct + (Number.isFinite(data.transportPct) ? data.transportPct : 0),
  };
}

const round = (n: number, d = 2) => Math.round(n * 10 ** d) / 10 ** d;

// the customer's own price of a SAP code: exact, or (when the order has the code without its suffix) the only one that starts like it
function memoryPrice(prices: Record<string, number>, sap: string): number | null {
  if (!sap) return null;
  if (prices[sap] > 0) return prices[sap];
  if (!sap.includes('.')) { const hits = Object.keys(prices).filter((k) => k.startsWith(sap + '.')); if (hits.length === 1) return prices[hits[0]]; }
  return null;
}

// ---- products outside the price list (veneer, melamine, metal ...) -----------------------------------------------------------------------
// A proforma is not only PVC and ABS: wood veneer, melamine, aluminium and acrylic edgings, glue, tools - anything the customer orders.
// Such a line needs no SAP colour code: the person types what it is and its price per m2, and it is printed like every other line.
// kg per m2 and mm of thickness (an estimate for the Weight column, as 1.1 is for PVC / ABS)
export const OTHER_PRODUCTS: { key: string; label: string; words: RegExp; density: number }[] = [
  { key: 'Veneer', label: 'Wood veneer', words: /\b(veneers?|wood\s*veneer|real\s*wood|kaplama|ahşap|ahsap|furnier|placage|chapa|шпон)\b/i, density: 0.65 },
  { key: 'Melamine', label: 'Melamine', words: /\b(melamin[e]?|melamina|mélamine)\b/i, density: 1.2 },
  { key: 'Metal', label: 'Aluminium / metal', words: /\b(alu|alumin(i)?um|alüminyum|aluminyum|metal|metall|inox|chrome|krom)\b/i, density: 2.7 },
  { key: 'Acrylic', label: 'Acrylic / 3D', words: /\b(acryl(ic)?|akrilik|pmma|3d)\b/i, density: 1.2 },
  { key: 'PP', label: 'PP', words: /\bpp\b/i, density: 0.95 },
];
const DB_TYPE: Record<string, string> = { Melamin: 'Melamine', Melamine: 'Melamine', Metal: 'Metal' };
export function otherProductOf(text: string): string | null {
  return OTHER_PRODUCTS.find((p) => p.words.test(text))?.key ?? null;
}

export function priceProforma(data: ProformaData, book: PriceBook | null): PricedProforma {
  const params = book ? paramsFor(book, data) : null;
  const cache = new Map<string, ReturnType<typeof colorBySap>>();
  const lines: PricedLine[] = data.lines.map((l) => {
    const warnings: string[] = [];
    const sap = l.sap.trim();
    let found: ColorCode | null = null;
    let candidates: ColorCode[] = [];
    if (sap) {
      const r = cache.get(sap) ?? colorBySap(sap);
      cache.set(sap, r);
      found = r.color;
      candidates = r.candidates;
      if (!found && candidates.length) warnings.push(`${sap}: several codes start like this - choose one.`);
    }
    // a line that is not a colour of the database: with a name of its own it is a product outside the price list (veneer, melamine ...), not a mistake
    const typedName = (l.description ?? '').trim() || (!found ? (l.code ?? '').trim() : '');
    const free = !found && !candidates.length && !!typedName;
    if (!found && !candidates.length && !free) warnings.push(sap ? `${sap} is not in the colour database. If it is another product (veneer, melamine ...), write what it is.` : 'SAP code missing: no price yet.');

    const product = found?.productType === 'PVC' || found?.productType === 'ABS' || found?.productType === 'PP' ? found.productType : null;
    const otherProduct = product ? null : found ? (DB_TYPE[found.productType ?? ''] ?? found.productType ?? 'Other') : free ? (otherProductOf(`${typedName} ${l.code ?? ''}`) ?? 'Other') : null;
    const hasManual = typeof l.priceM2 === 'number' && l.priceM2 > 0;
    if (otherProduct && !hasManual) warnings.push(`${OTHER_PRODUCTS.find((p) => p.key === otherProduct)?.label ?? (otherProduct === 'Other' ? 'This product' : otherProduct)} is not in the price list: type the price per m².`);
    if (found?.status === 'Not in Kartela') warnings.push('This code is not in the current kartela (colour card range).');

    const meters = l.meters && l.meters > 0 ? l.meters : null;
    const width = l.width && l.width > 0 ? l.width : null;
    const thickness = l.thickness && l.thickness > 0 ? l.thickness : null;
    if (!meters) warnings.push('No quantity (meters).');
    if (!width) warnings.push('No width.');
    if (!thickness) warnings.push('No thickness.');
    const rollLength = l.rollLength && l.rollLength > 0 ? l.rollLength : defaultRollLength(thickness);

    let listPriceM2: number | null = null;
    if (book && params && product && found?.categoryNo && thickness) {
      const r = book.m2Price(product, found.categoryNo, thickness, params);
      if (r) listPriceM2 = r.price;
      else warnings.push(`The price list has no ${product} price for "${found.category ?? `category ${found.categoryNo}`}" at ${thickness} mm: type the price per m².`);
    }
    const manual = typeof l.priceM2 === 'number' && l.priceM2 > 0 ? l.priceM2 : null;
    const memoryPriceM2 = data.useMemory === false || !data.memory ? null : memoryPrice(data.memory.prices, sap);
    const level = data.useMemory === false || data.useLevel !== true || !product ? null : data.memory?.levels?.[product] ?? null;
    const levelPriceM2 = manual === null && memoryPriceM2 === null && listPriceM2 !== null && level !== null && level !== 0 ? round(listPriceM2 * (1 + level)) : null;
    if (levelPriceM2 !== null && level !== null) warnings.push(`Not bought before: priced at this customer's usual level (${level > 0 ? '+' : ''}${round(level * 100, 1)} % against the price list).`);
    const priceM2 = manual ?? memoryPriceM2 ?? levelPriceM2 ?? listPriceM2;
    const m2 = meters && width ? (meters * width) / 1000 : null;
    const rolls = meters && rollLength ? Math.ceil(meters / rollLength - 1e-9) : null;
    const perBox = rollsPerBox(width);
    return {
      ...l,
      thickness,
      width,
      meters,
      rollLength,
      found,
      candidates,
      product,
      otherProduct,
      ownName: free ? typedName : null,
      m2: m2 === null ? null : round(m2, 3),
      rolls,
      perBox,
      boxes: rolls && perBox ? Math.ceil(rolls / perBox - 1e-9) : null,
      listPriceM2,
      priceM2,
      memoryPriceM2,
      priceSource: manual !== null ? 'manual' : memoryPriceM2 !== null ? 'memory' : levelPriceM2 !== null ? 'level' : listPriceM2 !== null ? 'list' : null,
      levelPct: levelPriceM2 !== null ? level : null,
      priceMt: priceM2 !== null && width ? round((priceM2 * width) / 1000, 4) : null,
      total: priceM2 !== null && m2 !== null ? round(priceM2 * m2) : null,
      weight: m2 !== null && thickness ? round(m2 * thickness * (OTHER_PRODUCTS.find((p) => p.key === otherProduct)?.density ?? 1.1), 1) : null,
      warnings,
    };
  });

  const sum = (f: (l: PricedLine) => number | null) => lines.reduce((s, l) => s + (f(l) ?? 0), 0);
  // Minimum quantities, by what the colour database says (kartela availability and range status):
  //  - ABS outside the express range: 200 kg per thickness
  //  - PVC outside the express range: 600 kg for one thickness; once one thickness has its 600 kg, the next thickness needs 300 kg
  //  - express range: Kronospan = one jumbo roll of 400 mm; Egger = 100 kg per thickness
  // Every width and every decor of the same thickness counts together. The weight is the same estimate as the Weight column.
  const moq: MoqNote[] = [];
  const kgOf = (ls: PricedLine[]) => ls.reduce((a, l) => a + (l.weight ?? 0), 0);
  const withT = lines.filter((l) => l.found && l.product && l.thickness && l.weight !== null);
  const byThickness = (ls: PricedLine[]) => {
    const m = new Map<number, PricedLine[]>();
    for (const l of ls) m.set(l.thickness!, [...(m.get(l.thickness!) ?? []), l]);
    return [...m.entries()].sort((a, b) => kgOf(b[1]) - kgOf(a[1]));
  };
  const short = (product: string, t: number, kg: number, need: number, why: string) => {
    if (kg + 0.5 < need) moq.push({ product, thickness: t, kg: round(kg, 0), need, text: product + ' ' + t + ' mm (' + why + '): about ' + round(kg, 0) + ' kg ordered, the minimum is ' + need + ' kg.' });
  };
  const nonExpress = (l: PricedLine) => /^MOQ/i.test(l.found?.status ?? '');
  for (const [t, ls] of byThickness(withT.filter((l) => l.product === 'ABS' && nonExpress(l)))) short('ABS', t, kgOf(ls), 200, 'outside the express range');
  const pvc = byThickness(withT.filter((l) => l.product === 'PVC' && nonExpress(l)));
  if (pvc.length) {
    const fulfilled = pvc.some(([, ls]) => kgOf(ls) >= 599.5);
    pvc.forEach(([t, ls], i) => short('PVC', t, kgOf(ls), i === 0 || !fulfilled ? (i === 0 ? 600 : 300) : 300, i === 0 ? 'outside the express range, the first thickness' : fulfilled ? 'a further thickness, one is already fulfilled' : 'a further thickness: it counts once one thickness has 600 kg'));
  }
  for (const [t, ls] of byThickness(withT.filter((l) => l.found!.status === 'Express' && /egger/i.test(l.found!.producer ?? '')))) short('Egger', t, kgOf(ls), 100, 'express range');
  for (const l of lines) if (l.found?.status === 'Express' && /kronospan/i.test(l.found.producer ?? '')) { moq.push({ product: 'Kronospan', thickness: l.thickness ?? 0, kg: 0, need: 0, text: 'Kronospan express range (' + (l.found.sap) + '): the minimum is one jumbo roll of 400 mm.' }); break; }
  const amount = round(sum((l) => l.total), 2);
  const adjustments = (data.adjustments ?? [])
    .filter((a) => a && Number.isFinite(Number(a.value)) && Number(a.value) !== 0)
    .map((a) => ({ label: String(a.label || (Number(a.value) < 0 ? 'Discount' : 'Addition')).slice(0, 80) + (a.mode === 'percent' ? ` (${Number(a.value) > 0 ? '+' : ''}${round(Number(a.value), 2)} %)` : ''), amount: round(a.mode === 'percent' ? (amount * Number(a.value)) / 100 : Number(a.value), 2) }));
  return {
    lines,
    totals: {
      meters: round(sum((l) => l.meters), 0), m2: round(sum((l) => l.m2), 2), rolls: sum((l) => l.rolls), boxes: sum((l) => l.boxes), weight: round(sum((l) => l.weight), 1), amount,
      priced: lines.filter((l) => l.total !== null).length, unpriced: lines.filter((l) => l.total === null).length,
      adjustments, grand: round(amount + adjustments.reduce((s, a) => s + a.amount, 0), 2),
    },
    moq,
    priceList: !!book,
  };
}
