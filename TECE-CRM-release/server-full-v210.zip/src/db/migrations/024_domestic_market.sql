-- TECE CRM: a second market. Export staff look after countries; the domestic (Turkey) team looks after cities.

-- Which team a person belongs to ('export' or 'domestic'), and whether they may watch what everybody does
-- (read-only: a manager's overview page).
ALTER TABLE users ADD COLUMN market TEXT NOT NULL DEFAULT 'export';
ALTER TABLE users ADD COLUMN can_oversee INTEGER NOT NULL DEFAULT 0;

-- Which market a customer belongs to, and (domestic) the city they are in.
ALTER TABLE cards ADD COLUMN market TEXT NOT NULL DEFAULT 'export';
ALTER TABLE cards ADD COLUMN city TEXT;
CREATE INDEX IF NOT EXISTS idx_cards_market ON cards(market);
CREATE INDEX IF NOT EXISTS idx_cards_city ON cards(city);

-- One live price list per market: the domestic team never sees the export prices.
ALTER TABLE price_lists ADD COLUMN market TEXT NOT NULL DEFAULT 'export';

-- Who looks after each city (like country_assignments). Names are staff display names.
CREATE TABLE IF NOT EXISTS city_assignments (
  key TEXT PRIMARY KEY,
  city TEXT NOT NULL,
  responsible TEXT,
  assistant TEXT,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Extra customers an admin lets a person see: a whole market, one country or one city.
CREATE TABLE IF NOT EXISTS user_access (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,
  value TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, kind, value)
);

-- An admin's private evaluation of a person (not visible to the person or to the managers).
CREATE TABLE IF NOT EXISTS evaluations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  author_id INTEGER REFERENCES users(id),
  rating INTEGER,
  period TEXT,
  text TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_evaluations_user ON evaluations(user_id, created_at);
