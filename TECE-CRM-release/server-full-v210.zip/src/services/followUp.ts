import type { OfferEntry } from '../models/pricingModels';

// Where we stand with a customer, from what has actually been sent to them.
export type FollowUpStatus = 'offer' | 'documents' | 'thank_you' | 'personal' | 'nothing';

export interface FollowUp {
  status: FollowUpStatus;
  label: string;
  at: string | null; // when the most relevant send happened (UTC "YYYY-MM-DD HH:MM:SS")
  percent: number | null; // price increase / decrease on the latest offer
  count: number; // emails sent to this customer
  // the facts behind the status, so a list can show both at once
  thankYouAt: string | null;
  offerAt: string | null;
  documentsAt: string | null;
}

export const FOLLOW_UP_LABEL: Record<FollowUpStatus, string> = {
  offer: 'Offer sent',
  documents: 'Documents sent',
  thank_you: 'Thank-you only',
  personal: 'Personal e-mail sent',
  nothing: 'Nothing yet',
};

// entries: everything logged for the card, newest first.
export function followUpFor(card: { thank_you_sent_at: string | null }, entries: OfferEntry[]): FollowUp {
  const latestOffer = entries.find((e) => e.kind === 'offer');
  const latestDocs = entries.find((e) => e.kind === 'documents');
  const count = entries.length || (card.thank_you_sent_at ? 1 : 0);
  const facts = {
    thankYouAt: entries.find((e) => e.kind === 'thank_you')?.sentAt ?? card.thank_you_sent_at ?? null,
    offerAt: latestOffer?.sentAt ?? null,
    documentsAt: latestDocs?.sentAt ?? null,
  };
  if (latestOffer) return { status: 'offer', label: FOLLOW_UP_LABEL.offer, at: latestOffer.sentAt, percent: latestOffer.percent, count, ...facts };
  if (latestDocs) return { status: 'documents', label: FOLLOW_UP_LABEL.documents, at: latestDocs.sentAt, percent: null, count, ...facts };
  const thanked = facts.thankYouAt;
  if (thanked) return { status: 'thank_you', label: FOLLOW_UP_LABEL.thank_you, at: thanked, percent: null, count, ...facts };
  const personal = entries.find((e) => e.kind === 'personal');
  if (personal) return { status: 'personal', label: FOLLOW_UP_LABEL.personal, at: personal.sentAt, percent: null, count, ...facts };
  return { status: 'nothing', label: FOLLOW_UP_LABEL.nothing, at: null, percent: null, count: 0, ...facts };
}

export function groupByCard(entries: OfferEntry[]): Map<number, OfferEntry[]> {
  const map = new Map<number, OfferEntry[]>();
  for (const e of entries) (map.get(e.cardId) ?? map.set(e.cardId, []).get(e.cardId)!).push(e);
  return map;
}
