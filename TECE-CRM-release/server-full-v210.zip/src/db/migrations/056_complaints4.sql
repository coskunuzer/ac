-- The planned closing date of a complaint (the real one is set when it is closed).
ALTER TABLE complaints ADD COLUMN close_target TEXT;
