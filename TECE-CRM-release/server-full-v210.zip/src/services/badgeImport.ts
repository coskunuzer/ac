import { COUNTRY_NAMES } from '../data/countries';
import { ISO3_TO_ISO2 } from '../data/iso3';
import { cardModel } from '../models/cardModel';
import { countryKey } from '../models/countryModel';
import type { ExtractedCardFields, FieldStatusMap } from '../schema/cardSchema';
import { applyCountryDefaults } from './countryAssignment';
import { syncCustomerFolder } from './customerFiles';
import { analyseCard, ruleInsight, type AiInsight } from './aiInsight';
import { detectInterest } from './interest';

// Visitors scanned with a badge reader at a fair come out as a CSV. This turns
// that file into customer records for one exhibition. It works from the column
// *names*, so exports from different fairs (or in Italian) are read the same way.

// ---- reading the file --------------------------------------------------

// Badge exports are usually Windows-1252, not UTF-8; try UTF-8 first.
export function decodeText(buffer: Buffer): string {
  let text: string;
  try {
    text = new TextDecoder('utf-8', { fatal: true }).decode(buffer);
  } catch {
    text = new TextDecoder('windows-1252').decode(buffer);
  }
  return text.replace(/^﻿/, '');
}

export function parseCsv(text: string): string[][] {
  const first = text.split(/\r?\n/, 1)[0] ?? '';
  const delimiter = (first.match(/;/g)?.length ?? 0) > (first.match(/,/g)?.length ?? 0) ? ';' : ',';
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = '';
  let quoted = false;
  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"') {
        if (text[i + 1] === '"') {
          cell += '"';
          i += 1;
        } else quoted = false;
      } else cell += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === delimiter) {
      row.push(cell);
      cell = '';
    } else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && text[i + 1] === '\n') i += 1;
      row.push(cell);
      cell = '';
      if (row.some((c) => c.trim())) rows.push(row);
      row = [];
    } else cell += ch;
  }
  row.push(cell);
  if (row.some((c) => c.trim())) rows.push(row);
  return rows;
}

// ---- columns -----------------------------------------------------------

type Column =
  | 'id' | 'name' | 'surname' | 'company' | 'role' | 'sector' | 'occupation' | 'address' | 'zip'
  | 'city' | 'province' | 'country' | 'phone' | 'email' | 'priority' | 'products' | 'notes' | 'date';

const ALIASES: Record<Column, string[]> = {
  id: ['id', 'badgeid', 'visitorid', 'codice', 'code', 'barcode'],
  name: ['name', 'firstname', 'givenname', 'nome', 'vorname', 'ad'],
  surname: ['surname', 'lastname', 'familyname', 'cognome', 'nachname', 'soyad'],
  company: ['company', 'companyname', 'organisation', 'organization', 'azienda', 'ragionesociale', 'firma', 'sirket'],
  role: ['role', 'jobtitle', 'title', 'position', 'ruolo', 'funzione', 'gorev'],
  sector: ['sector', 'settore', 'industry'],
  occupation: ['occupation', 'professione', 'activity', 'attivita'],
  address: ['address', 'street', 'indirizzo', 'adres'],
  zip: ['zipcode', 'zip', 'postalcode', 'postcode', 'cap'],
  city: ['city', 'town', 'citta', 'localita', 'sehir'],
  province: ['province', 'provincia', 'state', 'region'],
  country: ['country', 'nation', 'nazione', 'paese', 'ulke'],
  phone: ['phone', 'tel', 'telephone', 'telefono', 'mobile', 'cell', 'telefon'],
  email: ['email', 'mail', 'emailaddress', 'epost'],
  priority: ['priority', 'priorita', 'rating', 'interestlevel'],
  products: ['products', 'prodotti', 'productinterest', 'interest', 'interests'],
  notes: ['notes', 'note', 'comments', 'comment', 'remarks', 'notlar'],
  date: ['visitdate', 'scandate', 'date', 'data', 'datavisita', 'datetime', 'tarih'],
};

function norm(header: string): string {
  return header
    .normalize('NFD')
    .replace(/\p{Diacritic}/gu, '')
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '');
}

function mapColumns(header: string[]): Partial<Record<Column, number>> {
  const out: Partial<Record<Column, number>> = {};
  header.forEach((h, i) => {
    const key = norm(h);
    for (const col of Object.keys(ALIASES) as Column[]) {
      if (out[col] === undefined && ALIASES[col].includes(key)) out[col] = i;
    }
  });
  return out;
}

// ---- cleaning ----------------------------------------------------------

const clean = (v: string | undefined) => (v ?? '').replace(/\s+/g, ' ').trim();

// ALL CAPS / all lower-case names and addresses become "Title Case"; mixed case is left alone.
function nice(value: string): string {
  const v = clean(value);
  if (!v) return v;
  if (v !== v.toUpperCase() && v !== v.toLowerCase()) return v;
  return v
    .toLowerCase()
    .replace(/(^|[\s\-'/(.])(\p{L})/gu, (_m, a: string, b: string) => a + b.toUpperCase());
}

// Company names keep their legal-form capitals (S.R.L., DOO ...) - only fix lower-case ones.
function companyName(value: string): string {
  const v = clean(value);
  return v === v.toLowerCase() ? nice(v) : v;
}

const WORDS: Record<string, string> = {
  MOBILI: 'Furniture',
  CUCINE: 'Kitchens',
  IMBOTTITI: 'Upholstered furniture',
  'COMPONENTI PER MOBILI': 'Furniture components',
  COMPONENTI: 'Components',
  CONTRACT: 'Contract',
  COMMERCIO: 'Trade',
  INDUSTRIA: 'Industry',
  'AZIENDA ARTIGIANALE': 'Craft business',
  ARTIGIANO: 'Craftsman',
  DISTRIBUZIONE: 'Distribution',
  'FALEGNAMERIA': 'Joinery',
  'ARREDAMENTO': 'Interior furnishing',
  'TITOLARE': 'Owner',
  'TITOLARE / CEO': 'Owner / CEO',
  'IMPIEGATO COMMERCIALE': 'Sales employee',
  'IMPIEGATO ACQUISTI': 'Purchasing employee',
  'RESPONSABILE ACQUISTI': 'Purchasing manager',
  'RESPONSABILE PRODUZIONE': 'Production manager',
  'RESPONSABILE COMMERCIALE': 'Sales manager',
  'DIRETTORE COMMERCIALE': 'Sales director',
  'DIRETTORE GENERALE': 'General manager',
  'DIRETTORE ACQUISTI': 'Purchasing director',
  'DIRETTORE TECNICO': 'Technical director',
  'UFFICIO ACQUISTI': 'Purchasing office',
  'PROGETTISTA': 'Designer',
  'TECNICO': 'Technician',
  'AMMINISTRATORE': 'Director',
  'SOCIO': 'Partner',
  'IMPIEGATO TECNICO': 'Technical employee',
  'IMPIEGATO': 'Employee',
};

function translate(value: string): string {
  const v = clean(value);
  if (!v) return '';
  const hit = WORDS[v.toUpperCase()];
  if (hit) return hit;
  // "A / B": translate each part that is known
  const parts = v.split(/\s*\/\s*/);
  if (parts.length > 1 && parts.some((p) => WORDS[p.toUpperCase()])) {
    return parts.map((p) => WORDS[p.toUpperCase()] ?? nice(p)).join(' / ');
  }
  return nice(v);
}

const looksLikeEmail = (v: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim());

// ---- country -----------------------------------------------------------

const BY_KEY = new Map(COUNTRY_NAMES.map((n) => [countryKey(n), n]));
const OVERRIDES: Record<string, string> = {
  TUR: 'Turkey', COD: 'DR Congo', COG: 'Congo', CZE: 'Czechia', MKD: 'North Macedonia', PSE: 'Palestine',
  KOR: 'South Korea', PRK: 'North Korea', RUS: 'Russia', SYR: 'Syria', VNM: 'Vietnam', LAO: 'Laos',
  MDA: 'Moldova', IRN: 'Iran', BOL: 'Bolivia', TZA: 'Tanzania', CIV: "Cote d'Ivoire", SWZ: 'Eswatini',
  CPV: 'Cabo Verde', TLS: 'Timor-Leste', MMR: 'Myanmar', BRN: 'Brunei', XKX: 'Kosovo', USA: 'United States',
  GBR: 'United Kingdom', ARE: 'United Arab Emirates', HKG: 'Hong Kong', MAC: 'Macau', CUW: 'Curaçao', KNA: 'Saint Kitts and Nevis', LCA: 'Saint Lucia', VCT: 'Saint Vincent and the Grenadines',
};

let regionNames: Intl.DisplayNames | null = null;
function regionName(iso2: string): string | null {
  try {
    regionNames ??= new Intl.DisplayNames(['en'], { type: 'region' });
    return regionNames.of(iso2) ?? null;
  } catch {
    return null;
  }
}

// ISO3 ("ITA"), ISO2 ("IT") or a name -> the spelling this app uses (null if unknown).
export function resolveCountry(raw: string): string | null {
  // "TAIWAN(CN)", "Georgia (Country)": the bracket is a note, not part of the name
  const v = clean(raw.replace(/\s*\([^)]*\)\s*$/, ' '));
  if (!v) return null;
  const upper = v.toUpperCase();
  if (/^[A-Za-z]{3}$/.test(v)) {
    const byName = BY_KEY.get(countryKey(v)); // "UAE", "USA" are names too
    if (byName) return byName;
    if (OVERRIDES[upper] && BY_KEY.has(countryKey(OVERRIDES[upper]))) return BY_KEY.get(countryKey(OVERRIDES[upper]))!;
    const iso2 = ISO3_TO_ISO2[upper];
    const name = iso2 ? regionName(iso2) : null;
    if (name && BY_KEY.has(countryKey(name))) return BY_KEY.get(countryKey(name))!;
    if (name) {
      const loose = COUNTRY_NAMES.find((c) => countryKey(c).startsWith(countryKey(name)) || countryKey(name).startsWith(countryKey(c)));
      if (loose) return loose;
    }
    return null;
  }
  if (/^[A-Za-z]{2}$/.test(v)) {
    const name = regionName(upper);
    return name && BY_KEY.has(countryKey(name)) ? BY_KEY.get(countryKey(name))! : null;
  }
  return BY_KEY.get(countryKey(v)) ?? null;
}

// ---- one row -> one customer ------------------------------------------

const RATE: Record<string, number> = { HIGH: 8, ALTA: 8, MEDIUM: 5, MEDIA: 5, LOW: 3, BASSA: 3 };

export interface ImportedRow {
  line: number;
  badgeId: string;
  fields: ExtractedCardFields;
  status: 'new' | 'duplicate' | 'skipped';
  reason?: string;
  warnings: string[];
}

function isoDate(raw: string): string | null {
  const m = clean(raw).match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (m) return `${m[1]}-${m[2]}-${m[3]}`;
  const d = clean(raw).match(/^(\d{1,2})[./](\d{1,2})[./](\d{4})/);
  if (d) return `${d[3]}-${d[2].padStart(2, '0')}-${d[1].padStart(2, '0')}`;
  return null;
}

function buildFields(get: (c: Column) => string, warnings: string[]): ExtractedCardFields {
  const name = [nice(get('name')), nice(get('surname'))].filter(Boolean).join(' ') || null;
  const zipCity = [clean(get('zip')), nice(get('city'))].filter(Boolean).join(' ');
  const province = clean(get('province'));
  const address =
    [nice(get('address')), province ? `${zipCity} (${province.toUpperCase()})` : zipCity].filter(Boolean).join(', ') || null;

  const rawCountry = clean(get('country'));
  const country = resolveCountry(rawCountry);
  if (rawCountry && !country) warnings.push(`Country "${rawCountry}" is not in the app's country list`);

  // some exports put an e-mail address in the wrong column
  const sector = looksLikeEmail(get('sector')) ? '' : translate(get('sector'));
  const occupation = translate(get('occupation'));
  const workArea = [sector, occupation].filter(Boolean).join(', ') || null;

  const staffNote = clean(get('notes'));
  const role = translate(get('role'));
  const products = clean(get('products'));
  const notes = staffNote || null;

  let email = clean(get('email')).toLowerCase() || null;
  if (email && !looksLikeEmail(email)) {
    warnings.push(`E-mail "${email}" does not look valid`);
  }
  if (!email) warnings.push('No e-mail address');

  const priority = clean(get('priority')).toUpperCase();
  const rate = RATE[priority] ?? null;

  const joined = [name, get('company'), address].join(' ');
  if (joined.includes('?')) warnings.push('Some characters were lost in the export ("?") - check the name/company');

  return {
    name,
    company: companyName(get('company')) || null,
    address,
    country,
    tel: clean(get('phone')) || null,
    email,
    position: role || null,
    interestedIn: products || null,
    workArea,
    date: isoDate(get('date')),
    person: null,
    rate,
    notes,
  };
}

// ---- the whole file ----------------------------------------------------

export interface BadgeImportReport {
  rows: number;
  created: number;
  duplicates: number;
  skipped: number;
  columnsFound: string[];
  columnsMissing: string[];
  noEmail: number;
  unknownCountries: string[];
  charactersLost: number;
  sameEmailAsOther: string[];
  preview: ImportedRow[];
  cardIds: number[];
}

const FOUND_ALL = (): FieldStatusMap => ({
  name: 'found', company: 'found', address: 'found', country: 'found', tel: 'found', email: 'found', position: 'found',
  interestedIn: 'found', workArea: 'found', date: 'found', person: 'found', rate: 'found', notes: 'found',
});

export async function importBadgeVisitors(opts: {
  // true = the AI reads the notes of every visitor (uses tokens); false (the default) = the plain rules
  useAi?: boolean;
  buffer: Buffer;
  exhibitionId: number;
  userId: number;
  dryRun: boolean;
}): Promise<BadgeImportReport> {
  const table = parseCsv(decodeText(opts.buffer));
  if (table.length < 2) throw new Error('The file has no visitor rows.');
  const header = table[0];
  const cols = mapColumns(header);
  if (cols.name === undefined && cols.surname === undefined && cols.company === undefined && cols.email === undefined) {
    throw new Error('Could not recognise the columns. The first line must name them (for example Name, Surname, Company, E-mail, Country).');
  }

  const report: BadgeImportReport = {
    rows: 0, created: 0, duplicates: 0, skipped: 0,
    columnsFound: (Object.keys(cols) as Column[]).sort(),
    columnsMissing: (Object.keys(ALIASES) as Column[]).filter((c) => cols[c] === undefined),
    noEmail: 0, unknownCountries: [], charactersLost: 0, sameEmailAsOther: [], preview: [], cardIds: [],
  };

  const seenInFile = new Set<string>();
  const emailsSeen = new Map<string, string>();
  const unknown = new Set<string>();
  const pending: { fields: ExtractedCardFields; badgeId: string }[] = [];

  for (let r = 1; r < table.length; r += 1) {
    const cells = table[r];
    const get = (c: Column) => (cols[c] === undefined ? '' : cells[cols[c]!] ?? '');
    report.rows += 1;
    const warnings: string[] = [];
    const fields = buildFields(get, warnings);

    if (!fields.name && !fields.company && !fields.email) {
      report.skipped += 1;
      report.preview.push({ line: r + 1, badgeId: '', fields, status: 'skipped', reason: 'Empty row', warnings });
      continue;
    }

    // the badge ID keeps a second upload of the same file from creating the same visitor twice
    const rawId = clean(get('id'));
    const badgeId = rawId || `auto:${(fields.email ?? '').toLowerCase()}|${(fields.name ?? '').toLowerCase()}|${(fields.company ?? '').toLowerCase()}`;
    const duplicate = seenInFile.has(badgeId) || !!cardModel.findByBadge(opts.exhibitionId, badgeId);
    seenInFile.add(badgeId);

    if (warnings.some((w) => w === 'No e-mail address')) report.noEmail += 1;
    if (warnings.some((w) => w.startsWith('Some characters'))) report.charactersLost += 1;
    const bad = warnings.find((w) => w.startsWith('Country "'));
    if (bad) unknown.add(bad.match(/"([^"]+)"/)![1]);

    if (fields.email) {
      const label = fields.name || fields.company || `line ${r + 1}`;
      const other = emailsSeen.get(fields.email);
      if (other && other !== label) report.sameEmailAsOther.push(`${label} and ${other} share ${fields.email}`);
      else emailsSeen.set(fields.email, label);
    }

    if (duplicate) {
      report.duplicates += 1;
      if (report.preview.length < 200) report.preview.push({ line: r + 1, badgeId, fields, status: 'duplicate', reason: 'Already imported', warnings });
      continue;
    }

    const defaults = applyCountryDefaults(fields, FOUND_ALL());
    // the visit date comes from the file; keep today's date only if the file has none
    if (!opts.dryRun) pending.push({ fields: defaults.fields, badgeId });
    report.created += 1;
    if (report.preview.length < 200) report.preview.push({ line: r + 1, badgeId, fields: defaults.fields, status: 'new', warnings });
  }
  report.unknownCountries = [...unknown];

  // The AI reads each visitor's notes (Turkish, English ...) and says what has to happen next;
  // a few at a time. Without the AI the same answer comes from the plain words.
  const insights: AiInsight[] = new Array(pending.length);
  for (let i = 0; i < pending.length; i += 5) {
    await Promise.all(
      pending.slice(i, i + 5).map(async (p, k) => {
        const f = p.fields;
        const found = detectInterest({ interestedIn: f.interestedIn, workArea: f.workArea, notes: f.notes });
        insights[i + k] = opts.useAi
          ? await analyseCard(
              { name: f.name, company: f.company, country: f.country, email: f.email, work_area: f.workArea, interested_in: f.interestedIn, notes: f.notes, rate: f.rate },
              { products: found.products, widths: found.widths, other: found.other || null }
            )
          : ruleInsight({ notes: f.notes, interested_in: f.interestedIn, work_area: f.workArea, products: found.products, widths: found.widths, other: found.other || null });
      })
    );
  }
  pending.forEach((p, i) => {
    const card = cardModel.createFromExtraction({
      exhibitionId: opts.exhibitionId,
      uploadedBy: opts.userId,
      imagePath: '',
      fields: p.fields,
      fieldStatus: { ...FOUND_ALL(), person: p.fields.person ? 'found' : 'not_found' },
      extractionModel: 'badge-import',
      status: 'confirmed',
      badgeId: p.badgeId,
      insight: insights[i],
    });
    syncCustomerFolder(card.id);
    report.cardIds.push(card.id);
  });
  return report;
}
