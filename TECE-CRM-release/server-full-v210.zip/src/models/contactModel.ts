import { db } from '../db/connection';
import { cleanRoles, rolesOf, type Role } from '../services/contactRoles';

// More people at one company: the first person is on the customer itself, the others are listed under it.
export interface Contact {
  id: number;
  cardId: number;
  name: string | null;
  lastName: string | null;
  position: string | null;
  email: string | null;
  tel: string | null;
  mobile: string | null;
  scanPath: string | null;
  notes: string | null;
  city: string | null;
  roles: Role[];
}

interface Row {
  id: number;
  card_id: number;
  name: string | null;
  last_name: string | null;
  position: string | null;
  email: string | null;
  tel: string | null;
  mobile: string | null;
  scan_path: string | null;
  notes: string | null;
  city?: string | null;
  roles?: string | null;
}

const toContact = (r: Row): Contact => ({ id: r.id, cardId: r.card_id, name: r.name, lastName: r.last_name, position: r.position, email: r.email, tel: r.tel, mobile: r.mobile, scanPath: r.scan_path, notes: r.notes, city: r.city ?? null, roles: rolesOf(r.roles) });
const clean = (v: unknown, max: number) => (typeof v === 'string' && v.trim() ? v.trim().slice(0, max) : null);

export interface ContactInput {
  name?: unknown;
  lastName?: unknown;
  mobile?: unknown;
  scanPath?: unknown;
  position?: unknown;
  email?: unknown;
  tel?: unknown;
  notes?: unknown;
  city?: unknown;
  roles?: unknown;
}

export const contactModel = {
  list(cardId: number): Contact[] {
    return (db.prepare('SELECT * FROM card_contacts WHERE card_id = ? ORDER BY id').all(cardId) as unknown as Row[]).map(toContact);
  },

  find(id: number): Contact | undefined {
    const r = db.prepare('SELECT * FROM card_contacts WHERE id = ?').get(id) as Row | undefined;
    return r && toContact(r);
  },

  add(cardId: number, input: ContactInput): Contact | null {
    const c = { name: clean(input.name, 120), lastName: clean(input.lastName, 120), position: clean(input.position, 120), email: clean(input.email, 200), tel: clean(input.tel, 80), mobile: clean(input.mobile, 80), scanPath: clean(input.scanPath, 200), notes: clean(input.notes, 500), city: clean(input.city, 120) };
    if (!c.name && !c.lastName && !c.email) return null;
    const r = db.prepare('INSERT INTO card_contacts (card_id, name, last_name, position, email, tel, mobile, scan_path, notes, city, roles) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').run(cardId, c.name, c.lastName, c.position, c.email, c.tel, c.mobile, c.scanPath, c.notes, c.city, cleanRoles(input.roles));
    return this.find(r.lastInsertRowid as number) ?? null;
  },

  update(id: number, input: ContactInput): Contact | undefined {
    const cur = this.find(id);
    if (!cur) return undefined;
    const pick = (k: keyof ContactInput, max: number, old: string | null) => (input[k] === undefined ? old : clean(input[k], max));
    db.prepare('UPDATE card_contacts SET name = ?, last_name = ?, position = ?, email = ?, tel = ?, mobile = ?, scan_path = ?, notes = ?, city = ?, roles = ? WHERE id = ?').run(
      pick('name', 120, cur.name), pick('lastName', 120, cur.lastName), pick('position', 120, cur.position), pick('email', 200, cur.email), pick('tel', 80, cur.tel), pick('mobile', 80, cur.mobile), pick('scanPath', 200, cur.scanPath), pick('notes', 500, cur.notes), pick('city', 120, cur.city), input.roles === undefined ? (cur.roles.join(',') || null) : cleanRoles(input.roles), id
    );
    return this.find(id);
  },

  remove(id: number): void {
    db.prepare('DELETE FROM card_contacts WHERE id = ?').run(id);
  },
};
