import path from 'path';
import dotenv from 'dotenv';

dotenv.config({ path: path.resolve(__dirname, '../../.env') });

function required(name: string): string {
  const value = process.env[name];
  if (!value) {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value;
}

// which key the AI services see: set by services/aiGate.ts (the chosen provider decides)
export const aiHooks = { active: (): string => '' };

export const env = {
  port: parseInt(process.env.PORT || '4000', 10),
  nodeEnv: process.env.NODE_ENV || 'development',
  isProduction: process.env.NODE_ENV === 'production',
  jwtSecret: required('JWT_SECRET'),
  // non-empty when the AI can be used (whichever provider is chosen)
  get geminiApiKey(): string {
    return aiHooks.active();
  },
  // Google Calendar (optional): an OAuth client made in the Google Cloud console, and the public address of this server
  googleClientId: process.env.GOOGLE_CLIENT_ID || '',
  googleClientSecret: process.env.GOOGLE_CLIENT_SECRET || '',
  publicUrl: (process.env.PUBLIC_URL || 'http://localhost:4000').replace(/\/+$/, ''),
  corsOrigin: (process.env.CORS_ORIGIN || 'http://localhost:5173').split(','),
  smtp: {
    host: process.env.SMTP_HOST || '',
    port: parseInt(process.env.SMTP_PORT || '587', 10),
    user: process.env.SMTP_USER || '',
    password: process.env.SMTP_PASSWORD || '',
    from: process.env.SMTP_FROM || '',
  },
};

export const paths = {
  dbFile: path.resolve(__dirname, '../../data/app.db'),
  uploadsDir: path.resolve(__dirname, '../../uploads'),
  // Price workbooks and the catalog/MOQ/colour documents live under data/
  // (not uploads/) so they are never reachable through the photo route.
  priceListsDir: path.resolve(__dirname, '../../data/price-lists'),
  libraryDir: path.resolve(__dirname, '../../data/library'),
  // One folder per exhibition, one folder per customer in it: the scan, the
  // details and every offer that was sent.
  customerFilesDir: path.resolve(__dirname, '../../data/customer-files'),
};
