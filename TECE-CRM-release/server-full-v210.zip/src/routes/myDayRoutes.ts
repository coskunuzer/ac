import { Router } from 'express';
import { db } from '../db/connection';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { radar } from '../services/radar';
import { todayIstanbul, todoModel } from '../services/todos';
import { mineDocuments } from './myDocumentsRoutes';

// "My day": the work sessions a person sets (for example 10:00-11:00 and 14:00-15:00) and, for today, the work that fills them: payments to chase, proformas waiting,
// documents to send, offers without an answer, to-dos. Each task opens in its own page; opening and ticking are logged (daywork) and never deleted.
const router = Router();
router.use(requireAuth);

interface Win { start: string; end: string }
const TIME = /^([01]\d|2[0-3]):[0-5]\d$/;
const mins = (t: string) => parseInt(t.slice(0, 2), 10) * 60 + parseInt(t.slice(3), 10);
const windowsOf = (userId: number): Win[] => {
  try { const j = JSON.parse((db.prepare('SELECT work_windows FROM users WHERE id = ?').get(userId) as { work_windows: string | null } | undefined)?.work_windows ?? '[]'); return Array.isArray(j) ? j.filter((w: Win) => TIME.test(w?.start) && TIME.test(w?.end) && mins(w.end) > mins(w.start)) : []; } catch { return []; }
};

interface Item { key: string; kind: string; label: string; sub: string; link: string; minutes: number; rank: number }

function tasksFor(req: AuthedRequest): Item[] {
  const me = req.user!;
  const out: Item[] = [];
  const day = todayIstanbul();
  const money = (n: number, c: string) => `${c === 'USD' ? '$' : '€'}${Math.round(n).toLocaleString('en-US')}`;
  try {
    const r = radar(me);
    for (const p of r.payments) out.push({ key: `radar:${p.key}`, kind: 'payment', label: `Ask ${p.customer} for the payment`, sub: `${money(p.overdue, p.currency)} overdue · oldest ${p.oldestOver} days`, link: p.cardId ? `/cards/${p.cardId}/review` : '/performance', minutes: 10, rank: 1 });
    for (const p of r.proformas) out.push({ key: `radar:${p.key}`, kind: 'proforma', label: `Ask ${p.customer} about the proforma`, sub: `${p.title} · ${p.days === 0 ? 'today' : `${p.days} days ago`}`, link: `/cards/${p.cardId}/review`, minutes: 8, rank: 2 });
    for (const o of r.offers) if (o.days >= 3) out.push({ key: `radar:${o.key}`, kind: 'offer', label: `Follow up the offer to ${o.customer}`, sub: `${o.days} days without an answer`, link: `/cards/${o.cardId}/review`, minutes: 8, rank: 5 });
    for (const c of r.important) out.push({ key: `radar:${c.key}`, kind: 'important', label: `Contact ${c.customer}`, sub: `${c.why} · ${money(c.last12, c.currency)} in 12 months`, link: c.cardId ? `/cards/${c.cardId}/review` : '/dashboard', minutes: 10, rank: 6 });
  } catch (e) { console.error('My day: the radar part failed', e); }
  try { for (const d of mineDocuments(me)) out.push({ key: `doc:${d.key}`, kind: 'documents', label: `Send the documents to ${d.customer}`, sub: `invoice ${d.invoice} · ${d.days} days ago`, link: `/cards/${d.cardId}/review?tab=send`, minutes: 5, rank: 3 }); } catch (e) { console.error('My day: the documents part failed', e); }
  for (const t of todoModel.forUser(me.id)) if (!t.doneAt && t.dueDate <= day) out.push({ key: `todo:${t.id}`, kind: 'todo', label: t.text, sub: [t.company || t.contact, t.dueDate < day ? 'overdue' : 'today'].filter(Boolean).join(' · '), link: t.cardId ? `/cards/${t.cardId}/review` : '/calendar', minutes: 5, rank: t.dueDate < day ? 2 : 4 });
  return out.sort((a, b) => a.rank - b.rank);
}

router.get('/', (req: AuthedRequest, res) => {
  const me = req.user!;
  const day = todayIstanbul();
  const windows = windowsOf(me.id);
  const log = new Map((db.prepare('SELECT task_key, label, link, opened_at, done_at FROM daywork WHERE user_id = ? AND day = ?').all(me.id, day) as unknown as { task_key: string; label: string | null; link: string | null; opened_at: string | null; done_at: string | null }[]).map((r) => [r.task_key, r]));
  const todo = tasksFor(req);
  const keys = new Set(todo.map((t) => t.key));
  // a task ticked today stays on the page (even when its source has gone), in "done"
  const done = [...log.values()].filter((l) => l.done_at && !keys.has(l.task_key)).map((l) => ({ key: l.task_key, kind: 'done', label: l.label ?? l.task_key, sub: '', link: l.link ?? '', minutes: 0, rank: 9, openedAt: l.opened_at, doneAt: l.done_at, session: null as number | null }));
  // fill the sessions in order of importance: a task needs its minutes; what does not fit waits under "later"
  const room = windows.map((w) => mins(w.end) - mins(w.start));
  const items = todo.map((t) => {
    const l = log.get(t.key);
    let session: number | null = null;
    if (!l?.done_at) { const i = room.findIndex((r) => r >= t.minutes); if (i >= 0) { room[i] -= t.minutes; session = i; } }
    return { ...t, openedAt: l?.opened_at ?? null, doneAt: l?.done_at ?? null, session };
  });
  const all = [...items, ...done];
  res.json({ day, windows, items: all, total: all.length, finished: all.filter((i) => i.doneAt).length });
});

router.put('/windows', (req: AuthedRequest, res) => {
  const list = (Array.isArray(req.body?.windows) ? req.body.windows : []).slice(0, 4).filter((w: Win) => TIME.test(String(w?.start)) && TIME.test(String(w?.end)) && mins(w.end) > mins(w.start)).map((w: Win) => ({ start: w.start, end: w.end }));
  list.sort((a: Win, b: Win) => mins(a.start) - mins(b.start));
  db.prepare('UPDATE users SET work_windows = ? WHERE id = ?').run(JSON.stringify(list), req.user!.id);
  res.json({ windows: list });
});

const mark = (req: AuthedRequest, field: 'opened_at' | 'done_at', on: boolean) => {
  const key = String(req.body?.key ?? '').slice(0, 200);
  if (!key) return false;
  const day = todayIstanbul();
  db.prepare('INSERT OR IGNORE INTO daywork (user_id, day, task_key, label, link) VALUES (?, ?, ?, ?, ?)').run(req.user!.id, day, key, String(req.body?.label ?? '').slice(0, 300) || null, String(req.body?.link ?? '').slice(0, 300) || null);
  db.prepare(`UPDATE daywork SET ${field} = ${on ? "COALESCE(" + field + ", datetime('now'))" : 'NULL'}, label = COALESCE(label, ?), link = COALESCE(link, ?) WHERE user_id = ? AND day = ? AND task_key = ?`).run(String(req.body?.label ?? '').slice(0, 300) || null, String(req.body?.link ?? '').slice(0, 300) || null, req.user!.id, day, key);
  return true;
};
router.post('/open', (req: AuthedRequest, res) => res.json({ ok: mark(req, 'opened_at', true) }));
router.post('/done', (req: AuthedRequest, res) => {
  const on = req.body?.done !== false;
  const ok = mark(req, 'done_at', on);
  // a to-do ticked here is done in the to-do list as well
  const m = /^todo:(\d+)$/.exec(String(req.body?.key ?? ''));
  if (ok && m) { const t = todoModel.find(parseInt(m[1], 10)); if (t && t.userId === req.user!.id) todoModel.done(t.id, on); }
  res.json({ ok });
});

export default router;
