import { db } from '../db/connection';
import { lastSentMap, type SentInfo } from './lastSent';
import { cardModel } from '../models/cardModel';
import { buyingIntel } from './buyingIntel';
import { companyKey } from './companyKey';
import { setsFor } from './perfAnalytics';
import { viewMode } from './viewMode';
import { canSeeCard, type Viewer } from './visibility';

// The radar: everything that matters today in one list, for the person who must not forget anything: money that is due, orders that just came, important
// customers that went quiet, offers that went out lately, proformas that wait for a yes. A company is on a line once (the same company in two records is one line),
// and a line can be silenced for a day, a week or for good.
export interface RadarLine { key: string }
export interface Radar {
  asOf: string;
  payments: (RadarLine & { sap: string; cardId: number | null; customer: string; currency: string; overdue: number; oldestOver: number; statement: SentInfo | null })[];
  newOrders: (RadarLine & { orderNo: string; sap: string; cardId: number | null; customer: string; date: string; valueEur: number })[];
  important: (RadarLine & { sap: string; cardId: number | null; customer: string; why: string; last12: number; currency: string })[];
  offers: (RadarLine & { id: number; cardId: number; customer: string; sentAt: string; days: number; times: number })[];
  proformas: (RadarLine & { id: number; cardId: number; customer: string; title: string; createdAt: string; days: number })[];
  silenced: { key: string; label: string; until: string | null }[];
  hidden: number;
}

const dayDiff = (iso: string) => Math.max(0, Math.floor((Date.now() - Date.parse(iso.includes('T') ? iso : `${iso.replace(' ', 'T')}Z`)) / 86_400_000));
const nameOf = (c: { company?: string | null; name?: string | null; id: number }) => c.company || c.name || `#${c.id}`;
const ck = (name: string, id: number) => companyKey(name) || `id${id}`;

export function silenceKeys(userId: number): Map<string, { label: string; until: string | null }> {
  db.prepare("DELETE FROM radar_silenced WHERE user_id = ? AND until IS NOT NULL AND until < datetime('now')").run(userId);
  const rows = db.prepare('SELECT key, label, until FROM radar_silenced WHERE user_id = ?').all(userId) as { key: string; label: string | null; until: string | null }[];
  return new Map(rows.map((r) => [r.key, { label: r.label ?? r.key, until: r.until }]));
}

export function silence(userId: number, key: string, days: number | null, label: string): void {
  const until = days ? new Date(Date.now() + days * 86_400_000).toISOString().slice(0, 19).replace('T', ' ') : null;
  db.prepare('INSERT INTO radar_silenced (user_id, key, until, label) VALUES (?, ?, ?, ?) ON CONFLICT(user_id, key) DO UPDATE SET until = excluded.until, label = excluded.label').run(userId, key.slice(0, 120), until, label.slice(0, 120));
  kept.delete(userId);
}
export function unsilence(userId: number, key: string): void {
  db.prepare('DELETE FROM radar_silenced WHERE user_id = ? AND key = ?').run(userId, key);
  kept.delete(userId);
}

// The radar is asked on every page and again when its panel opens, and it adds up the accounts of every customer: it is kept for 5 minutes for each person
// (and dropped at once when something it shows changes: a line silenced, an order confirmed). The usage log showed it taking 9 s on average, 22 s at worst.
const kept = new Map<number, { at: number; mode: boolean; data: Radar }>();
export const clearRadarCache = (): void => kept.clear();
export function radar(viewer: Viewer): Radar {
  const mode = viewMode.team(viewer.id).ids.length > 0; // Manager mode shows the team's customers too, so the two modes are kept apart
  const hit = kept.get(viewer.id);
  if (hit && hit.mode === mode && Date.now() - hit.at < 300_000) return hit.data;
  const data = radarCompute(viewer);
  kept.set(viewer.id, { at: Date.now(), mode, data });
  return data;
}

function radarCompute(viewer: Viewer): Radar {
  const out: Radar = { asOf: new Date().toISOString(), payments: [], newOrders: [], important: [], offers: [], proformas: [], silenced: [], hidden: 0 };
  const muted = silenceKeys(viewer.id);
  const keep = (key: string) => { if (muted.has(key)) { out.hidden += 1; return false; } return true; };

  // money that is due: the customers with the most overdue
  try {
    const sent = lastSentMap('statement');
    const seen = new Set<string>();
    for (const a of setsFor(viewer, null).live.filter((x) => x.overdue > 0.5).sort((x, y) => y.urgency - x.urgency)) {
      const key = `payments:${ck(a.name, 0) || a.sap}`;
      if (seen.has(key)) continue;
      seen.add(key);
      if (!keep(key)) continue;
      out.payments.push({ key, sap: a.sap, cardId: a.cardId, customer: a.name, currency: a.currency, overdue: Math.round(a.overdue), oldestOver: a.oldestOver, statement: sent.get(`sap:${a.sap}`) ?? (a.cardId ? sent.get(`card:${a.cardId}`) : undefined) ?? null });
      if (out.payments.length >= 8) break;
    }
  } catch { /* no ledger yet */ }

  // new orders: the SAP orders opened in the last 14 days, of the customers this person may see
  try {
    const mine = new Map(setsFor(viewer, null).live.map((a) => [a.sap, a]));
    const rows = db.prepare("SELECT order_no, sap_no, customer, MIN(doc_date) AS d, SUM(COALESCE(value_eur, 0)) AS v FROM export_production_backlog WHERE doc_date >= date('now', '-14 day') GROUP BY order_no, sap_no ORDER BY d DESC LIMIT 80").all() as { order_no: string; sap_no: string; customer: string | null; d: string; v: number }[];
    for (const r of rows) {
      const a = mine.get((r.sap_no ?? '').trim());
      if (!a) continue;
      const key = `orders:${r.order_no}`;
      if (!keep(key)) continue;
      out.newOrders.push({ key, orderNo: r.order_no, sap: a.sap, cardId: a.cardId, customer: a.name || r.customer || a.sap, date: r.d, valueEur: Math.round(r.v) });
      if (out.newOrders.length >= 8) break;
    }
  } catch { /* the backlog may be empty */ }

  // important customers that need a message now: late on their rhythm, biggest first
  try {
    const seen = new Set<string>();
    for (const r of buyingIntel(viewer).rows.filter((x) => x.status === 'late' || x.status === 'due').sort((x, y) => y.last12 - x.last12)) {
      const key = `important:${ck(r.customer, 0) || r.sap}`;
      if (seen.has(key)) continue;
      seen.add(key);
      if (!keep(key)) continue;
      out.important.push({ key, sap: r.sap, cardId: r.cardId, customer: r.customer, why: r.status === 'late' ? `${r.daysLate ?? 0} days later than usual` : 'order due now', last12: Math.round(r.last12), currency: r.currency });
      if (out.important.length >= 6) break;
    }
  } catch { /* no ledger yet */ }

  // offers that went out in the last 14 days: one line for each company, with how many went out
  const offers = db.prepare("SELECT id, card_id, sent_at FROM offers_sent WHERE sent_at >= datetime('now', '-14 day') ORDER BY sent_at DESC LIMIT 120").all() as { id: number; card_id: number; sent_at: string }[];
  const byCompany = new Map<string, Radar['offers'][number]>();
  for (const o of offers) {
    const c = cardModel.findById(o.card_id);
    if (!c || !canSeeCard(viewer, c)) continue;
    const key = `offers:${ck(nameOf(c), c.id)}`;
    const have = byCompany.get(key);
    if (have) { have.times += 1; continue; }
    if (!keep(key)) { byCompany.set(key, { key, id: o.id, cardId: c.id, customer: nameOf(c), sentAt: o.sent_at, days: dayDiff(o.sent_at), times: 0 }); continue; }
    byCompany.set(key, { key, id: o.id, cardId: c.id, customer: nameOf(c), sentAt: o.sent_at, days: dayDiff(o.sent_at), times: 1 });
  }
  out.offers = [...byCompany.values()].filter((o) => o.times > 0).slice(0, 8);

  // proformas that wait for the customer's yes: the newest of each company (the older ones were drafts of it)
  const pros = db.prepare("SELECT id, card_id, title, created_at FROM document_archive WHERE kind = 'proforma' AND card_id IS NOT NULL AND confirmed_at IS NULL AND dropped_at IS NULL AND superseded_by IS NULL AND created_at >= datetime('now', '-60 day') ORDER BY created_at DESC, id DESC LIMIT 120").all() as { id: number; card_id: number; title: string | null; created_at: string }[];
  const seenCo = new Set<string>();
  for (const p of pros) {
    const c = cardModel.findById(p.card_id);
    if (!c || !canSeeCard(viewer, c)) continue;
    const key = `proformas:${ck(nameOf(c), c.id)}`;
    if (seenCo.has(key)) continue;
    seenCo.add(key);
    if (!keep(key)) continue;
    out.proformas.push({ key, id: p.id, cardId: c.id, customer: nameOf(c), title: p.title ?? 'Proforma', createdAt: p.created_at, days: dayDiff(p.created_at) });
    if (out.proformas.length >= 8) break;
  }

  out.silenced = [...muted].map(([key, v]) => ({ key, label: v.label, until: v.until }));
  return out;
}
