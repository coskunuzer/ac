-- A proforma the customer does not want any more: closed with one click. It leaves every waiting list; nothing is deleted and it can be taken back.
ALTER TABLE document_archive ADD COLUMN dropped_at TEXT;
ALTER TABLE document_archive ADD COLUMN dropped_by INTEGER;
