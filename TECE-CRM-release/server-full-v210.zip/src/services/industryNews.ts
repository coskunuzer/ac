import { settingsModel } from '../models/settingsModel';
import { askJson } from './perfActions';

// The one-page "Global industry news" at the end of the daily brief. The same page for everybody, made ONCE a day (not per person): the headlines of the last two days
// from 24 trade sites + a keyword search (Google News RSS), filtered by one short AI call. The AI only chooses and comments: every link comes from the feed itself
// (the AI gives the number of the headline, never a web address), so nothing can be invented. No news or no AI = the brief simply has no news page.
export const NEWS_DOMAINS: { group: string; domains: string[] }[] = [
  { group: 'Technical, panels & surfaces', domains: ['woodandpanel.com', 'wbpionline.com', 'surfaceandpanel.com', 'moebelfertigung.com', 'hk-magazin.com', 'xylon.it'] },
  { group: 'Global macro & pricing', domains: ['worldfurnitureonline.com', 'euwid-wood-products.com'] },
  { group: 'Europe, UK & CIS', domains: ['furniturenews.net', 'interiorsmonthly.co.uk', 'cabinet-maker.co.uk', 'biznesmeble.pl', 'md-magazine.info', 'revistamobila.ro', 'lesprom.com', 'mebbusiness.ru', 'moebelmarkt.de', 'moebelkultur.de'] },
  { group: 'Americas', domains: ['woodworkingnetwork.com', 'revistamobile.com.br', 'm-m.com.co', 'furnituretoday.com', 'furninfo.com'] },
  { group: 'MENA, APAC & Türkiye', domains: ['panelsfurnitureasia.com', 'furnitureandfurnishing.com', 'plyreporter.com', 'orsiad.com.tr', 'furniturk.com'] },
];
// the brand words alone bring people and obituaries (Egger), so a brand must come with a trade word
// (one long query with nested brackets returns nothing from Google, so three simple ones)
const KEYWORD_QUERIES = [
  '"edgebanding" OR "edge banding" OR "ABS edgeband"',
  '(Kronospan OR "Swiss Krono" OR Kastamonu OR EGGER) (panel OR MDF OR particleboard OR mill)',
  '(HOMAG OR Biesse) (woodworking OR machinery OR furniture)',
];

export interface NewsItem { id: number; group: string; source: string; title: string; link: string; at: string }
export interface NewsBlock {
  date: string;
  summary: string[];
  technical: { headline: string; source: string; fact: string; assessment: 'GOOD' | 'BAD'; link: string }[];
  regional: { region: string; headline: string; source: string; summary: string; action: string; link: string }[];
}

const decode = (s: string) => s.replace(/<!\[CDATA\[|\]\]>/g, '').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/\s+/g, ' ').trim();
const tag = (x: string, n: string) => { const m = new RegExp(`<${n}[^>]*>([\\s\\S]*?)</${n}>`).exec(x); return m ? decode(m[1]) : ''; };

async function feed(query: string, group: string, limit: number): Promise<Omit<NewsItem, 'id'>[]> {
  const url = `https://news.google.com/rss/search?q=${encodeURIComponent(`${query} when:2d`)}&hl=en&gl=US&ceid=US:en`;
  try {
    const r = await fetch(url, { signal: AbortSignal.timeout(9000), headers: { 'user-agent': 'Mozilla/5.0 (compatible; industry-news)' } });
    if (!r.ok) return [];
    const xml = await r.text();
    const out: Omit<NewsItem, 'id'>[] = [];
    for (const m of xml.matchAll(/<item>([\s\S]*?)<\/item>/g)) {
      const x = m[1];
      const raw = tag(x, 'title'); const link = tag(x, 'link'); const at = tag(x, 'pubDate'); const source = tag(x, 'source');
      if (!raw || !/^https?:\/\//.test(link)) continue;
      const t = at ? Date.parse(at) : NaN;
      if (Number.isFinite(t) && Date.now() - t > 50 * 3600 * 1000) continue;
      // Google adds " - Source" to the title
      const title = source && raw.endsWith(` - ${source}`) ? raw.slice(0, -(source.length + 3)) : raw;
      out.push({ group, source: source || query.replace('site:', ''), title: title.slice(0, 180), link, at });
      if (out.length >= limit) break;
    }
    return out;
  } catch { return []; }
}

export async function collectNews(): Promise<NewsItem[]> {
  const jobs: { q: string; group: string; n: number }[] = KEYWORD_QUERIES.map((q) => ({ q, group: 'Keywords', n: 6 }));
  for (const g of NEWS_DOMAINS) for (const d of g.domains) jobs.push({ q: `site:${d}`, group: g.group, n: 5 });
  const all: Omit<NewsItem, 'id'>[] = [];
  for (let i = 0; i < jobs.length; i += 6) {
    const res = await Promise.all(jobs.slice(i, i + 6).map((j) => feed(j.q, j.group, j.n)));
    for (const r of res) all.push(...r);
  }
  const seen = new Set<string>();
  const uniq = all.filter((x) => { const k = x.title.toLowerCase().replace(/[^a-z0-9]+/g, ' ').slice(0, 70); if (seen.has(k)) return false; seen.add(k); return true; });
  return uniq.slice(0, 150).map((x, i) => ({ ...x, id: i + 1 }));
}

const SYSTEM = [
  'You are a B2B Market Intelligence filter for TECE Dekor (global edgebanding and furniture component manufacturer).',
  'From the provided raw news feed, select ONLY the most critical B2B stories from the last 48 hours: up to 8, fewer when little is relevant. Never pad the list with weak stories.',
  '- INCLUDE: Edgebanding (ABS, PVC, melamine, PMMA, 3D), board/panel mills (MDF, particleboard, Kronospan, Egger, Swiss Krono, Kastamonu), resins/adhesives (Henkel, Jowat, Kleiberit), machinery (HOMAG, Biesse, SCM), factory expansions/closures, and trade tariffs.',
  '- EXCLUDE: B2C home decor, retail sofa sales, DIY woodworking, and anything that is not about the wood panel / furniture / edgebanding industry (people, obituaries, sport, cars, pulp and paper).',
  '- NO HALLUCINATIONS: Only use facts explicitly present in the input feed. Refer to a story ONLY by its number (id). If a region has no relevant news, omit it.',
  'Output: summary = 3 short bullet sentences on the biggest shifts today. technical = stories about production, raw materials, R&D (id, fact = 1 sentence, assessment GOOD or BAD for the edgebanding / panel supply chain). regional = stories about export markets (id, region = Europe/UK, CIS, Americas, MENA/APAC or Türkiye, summary = 1 sentence, action = 1 short CRM instruction for Export Area Managers). Total under 350 words.',
].join('\n');

export async function buildNews(): Promise<NewsBlock | null> {
  const items = await collectNews();
  if (items.length < 3) return null;
  const lines = items.map((i) => `${i.id}|${i.group}|${i.source}|${i.title}`).join('\n');
  const j = await askJson(`${SYSTEM}\n\nRAW FEED (id|group|source|headline):\n${lines}`, {
    type: 'OBJECT',
    properties: {
      summary: { type: 'ARRAY', items: { type: 'STRING' } },
      technical: { type: 'ARRAY', items: { type: 'OBJECT', properties: { id: { type: 'INTEGER' }, fact: { type: 'STRING' }, assessment: { type: 'STRING' } }, required: ['id', 'fact', 'assessment'] } },
      regional: { type: 'ARRAY', items: { type: 'OBJECT', properties: { id: { type: 'INTEGER' }, region: { type: 'STRING' }, summary: { type: 'STRING' }, action: { type: 'STRING' } }, required: ['id', 'region', 'summary', 'action'] } },
    },
    required: ['summary', 'technical', 'regional'],
  });
  if (!j) return null;
  const byId = new Map(items.map((i) => [i.id, i]));
  const s = (v: unknown, n: number) => String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, n);
  const technical = (Array.isArray(j.technical) ? j.technical : []).map((x: Record<string, unknown>) => {
    const it = byId.get(Number(x.id)); if (!it) return null;
    return { headline: it.title, source: it.source, fact: s(x.fact, 220), assessment: /bad/i.test(s(x.assessment, 10)) ? 'BAD' as const : 'GOOD' as const, link: it.link };
  }).filter((x): x is NonNullable<typeof x> => !!x).slice(0, 4);
  const regional = (Array.isArray(j.regional) ? j.regional : []).map((x: Record<string, unknown>) => {
    const it = byId.get(Number(x.id)); if (!it) return null;
    return { region: s(x.region, 30), headline: it.title, source: it.source, summary: s(x.summary, 220), action: s(x.action, 160), link: it.link };
  }).filter((x): x is NonNullable<typeof x> => !!x).slice(0, 5);
  const summary = (Array.isArray(j.summary) ? j.summary : []).map((x: unknown) => s(x, 200)).filter(Boolean).slice(0, 3);
  if (!technical.length && !regional.length) return null;
  return { date: new Date().toISOString().slice(0, 10), summary, technical, regional };
}

// once a day for everybody: the first brief of the day makes it, the others (and a failed try within 3 hours) reuse the answer
let running: Promise<NewsBlock | null> | null = null;
export async function newsForToday(): Promise<NewsBlock | null> {
  if (settingsModel.get('daily_brief_news') === '0') return null;
  const today = new Date().toISOString().slice(0, 10);
  try {
    const cached = JSON.parse(settingsModel.get('industry_news') ?? 'null') as { date: string; at: number; data: NewsBlock | null } | null;
    if (cached && cached.date === today && (cached.data || Date.now() - cached.at < 3 * 3600 * 1000)) return cached.data;
  } catch { /* a broken cache is simply made again */ }
  running ??= (async () => {
    try {
      const data = await buildNews();
      settingsModel.set('industry_news', JSON.stringify({ date: today, at: Date.now(), data }));
      return data;
    } catch (err) { console.error('Industry news failed:', err); return null; } finally { running = null; }
  })();
  return running;
}
