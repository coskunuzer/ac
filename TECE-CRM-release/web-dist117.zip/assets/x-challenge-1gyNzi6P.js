// The challenge: today's points as a game against yourself. Your goal, your best day, yesterday at this hour, the colleague just ahead of you -
// and a dare you can take for today (a higher goal that cannot be taken back).
import { h, Fragment, useState, useEffect, useRef, useCallback, api, Link, useT, Icon, cx, errText, shortDate, Ring, Bar, toast, burst, loc, useTx } from "./x-kit-1W3jRMzJ.js";

// one copy of the numbers for the pill in the top bar and the board on the Home page; asked again when something is logged
let cache = null;
let cacheAt = 0;
let pending = null;
const listeners = new Set();
function load(force) {
  if (!force && cache && Date.now() - cacheAt < 60000) return Promise.resolve(cache);
  if (pending) return pending;
  pending = api.get("/gamify/challenge").then((d) => {
    const before = cache;
    cache = d;
    cacheAt = Date.now();
    listeners.forEach((fn) => fn(d, before));
    return d;
  }).finally(() => { pending = null; });
  return pending;
}
function useChallenge() {
  const [c, setC] = useState(cache);
  useEffect(() => {
    const fn = (d) => setC(d);
    listeners.add(fn);
    load(false).catch(() => undefined);
    const again = () => load(true).catch(() => undefined);
    window.addEventListener("tece:logged", again);
    const tick = window.setInterval(() => { if (!document.hidden) again(); }, 180000);
    const seen = () => { if (!document.hidden && Date.now() - cacheAt > 60000) again(); };
    document.addEventListener("visibilitychange", seen);
    return () => { listeners.delete(fn); window.removeEventListener("tece:logged", again); window.clearInterval(tick); document.removeEventListener("visibilitychange", seen); };
  }, []);
  return c;
}

const ACT = { offer: ["offer", "offers"], visit: ["visit", "visits"], call: ["call", "calls"], note: ["note", "notes"] };
const recipeText = (list, t) => list.map((r) => r.n + " " + t(ACT[r.key][r.n === 1 ? 0 : 1])).join(" + ");
const first = (name) => String(name || "").split(" ")[0];

// what to say right now: the headline, the line under it, and how it should feel
function headline(c, t) {
  const todo = c.recipe.length ? recipeText(c.recipe, t) : "";
  if (!c.workday) return c.points > 0 ? { tone: "win", title: t("Working on a day off. Respect."), sub: t("{n} points that nobody asked for.", { n: c.points }) } : { tone: "calm", title: t("Day off."), sub: t("The board waits for you on Monday.") };
  if (c.beatBest) return { tone: "win", title: t("New personal record: {n} points.", { n: c.points }), sub: t("Your old best was {n}. Every point from here sets the bar higher for the next time.", { n: c.best.points }) };
  if (c.dare && c.dare.done) return { tone: "win", title: t("Dare done. {n} points.", { n: c.points }), sub: c.dare.level !== "record" && c.toBest ? t("Still hungry? Your record is {n} points away.", { n: c.toBest }) : t("That is how it is done.") };
  if (c.dare) return { tone: "push", title: t("{n} points to go. You said you would.", { n: c.gap }), sub: todo ? t("Dare taken: {target} points. {todo} and it is done.", { target: c.dare.target, todo }) : t("Dare taken: {target} points.", { target: c.dare.target }) };
  if (c.goalReached) return { tone: "win", title: t("Goal reached. Was that all?"), sub: c.usual > c.goal ? t("A usual day of yours is {n} points. Take a dare and make today count.", { n: c.usual }) : t("Take a dare and make today count.") };
  if (c.streak.atRisk) return { tone: "alert", title: t("Your {n}-day streak ends tonight.", { n: c.streak.days }), sub: t("One call or one note keeps it alive. {todo} reaches the goal.", { todo }) };
  if (c.points === 0) return { tone: "push", title: c.now < "11:00" ? t("The board is empty. Make the first move.") : t("It is {time} and the board is still empty.", { time: c.now }), sub: c.yesterday.byNow > 0 ? t("Yesterday at this hour you already had {n} points.", { n: c.yesterday.byNow }) : t("{todo} reaches today's goal.", { todo }) };
  if (c.pace < -4) return { tone: "push", title: t("You are {n} points behind yesterday's you.", { n: -c.pace }), sub: t("Yesterday at {time} you had {a}. Today you have {b}. {todo} closes the goal.", { time: c.now, a: c.yesterday.byNow, b: c.points, todo }) };
  if (c.pace > 4) return { tone: "good", title: t("{n} points ahead of yesterday. Keep the foot down.", { n: c.pace }), sub: t("{gap} points to the goal: {todo}.", { gap: c.gap, todo }) };
  return { tone: "push", title: t("{gap} points to today's goal.", { gap: c.gap }), sub: todo ? t("{todo} and it is done.", { todo }) : "" };
}

const DARES = [
  { key: "push", name: "Push", icon: "trending-up", hint: "Half as much again as the goal" },
  { key: "beast", name: "Beast", icon: "local-fire-department", hint: "Twice the goal" },
  { key: "record", name: "Record", icon: "trophy", hint: "Beat your best day" },
];

export function HomeChallenge() {
  const t = useTx("chal");
  const c = useChallenge();
  const [busy, setBusy] = useState(null);
  const [ask, setAsk] = useState(null);
  const ref = useRef(null);
  const was = useRef(null);
  // a burst when the goal, the dare or the record falls while the page is open
  useEffect(() => {
    if (!c) return;
    const now = { goal: c.goalReached, dare: !!(c.dare && c.dare.done), best: c.beatBest };
    const b = was.current;
    was.current = now;
    if (!b || !ref.current) return;
    if ((now.goal && !b.goal) || (now.dare && !b.dare) || (now.best && !b.best)) {
      const r = ref.current.getBoundingClientRect();
      burst(r.left + 90, r.top + 80, now.best ? 60 : 36);
      toast(now.best && !b.best ? t("New personal record!") : now.dare && !b.dare ? t("Dare done!") : t("Today's goal is reached!"), "good");
    }
  }, [c]);
  const take = useCallback(async (level) => {
    setBusy(level);
    try {
      cache = await api.post("/gamify/dare", { level });
      cacheAt = Date.now();
      listeners.forEach((fn) => fn(cache));
      setAsk(null);
      toast(t("Dare taken. No way back."), "good");
    } catch (e) {
      toast(errText(e, t("Could not take the dare")), "bad");
    } finally {
      setBusy(null);
    }
  }, [t]);
  if (!c) return h("section", { className: "xc xc--loading", "aria-hidden": "true" });
  const hl = headline(c, t);
  const lv = c.level;
  const maxDay = Math.max(c.goal, ...c.week.days.map((d) => d.points), 1);
  return h("section", { className: cx("xc", "xc--" + hl.tone), ref, "aria-label": t("Today's challenge") },
    h("div", { className: "xc-main" },
      h("div", { className: "xc-ring" },
        h(Ring, { value: c.points, max: c.target, size: 132, stroke: 11, tone: "onink" }, h(Fragment, null, h("strong", null, c.points), h("small", null, "/ " + c.target))),
        h("span", { className: "xc-level", title: t("{n} points to the next level", { n: lv.toNext }) }, h(Icon, { n: "military-tech", size: 16 }), t("Level {n}", { n: lv.n }), " · ", t(lv.name)),
        h(Bar, { value: lv.pct, max: 100, tone: "onink", label: t("To the next level") }),
      ),
      h("div", { className: "xc-say" },
        h("span", { className: "xc-kicker" }, c.dare ? h(Fragment, null, h(Icon, { n: "local-fire-department", size: 16 }), t("Dare: {name}", { name: t(DARES.find((d) => d.key === c.dare.level).name) })) : t("Today's challenge")),
        h("h2", null, hl.title),
        hl.sub ? h("p", null, hl.sub) : null,
        h("div", { className: "xc-chips" },
          c.streak.days > 0 ? h("span", { className: cx("xc-chip", c.streak.atRisk && "is-alert") }, h(Icon, { n: "local-fire-department", size: 16 }), h("b", null, c.streak.days), c.streak.days === 1 ? t("day in a row") : t("days in a row"), c.streak.best > c.streak.days ? h("small", null, t("best {n}", { n: c.streak.best })) : c.streak.days > 1 ? h("small", null, t("your longest")) : null) : h("span", { className: "xc-chip" }, h(Icon, { n: "local-fire-department", size: 16 }), t("Start a streak today")),
          c.week.of > 1 ? h("span", { className: "xc-chip" }, h(Icon, { n: "leaderboard", size: 16 }), h("b", null, "#" + c.week.rank), t("of {n} this week", { n: c.week.of })) : null,
          c.rival ? h("span", { className: "xc-chip is-rival" }, h(Icon, { n: "flag", size: 16 }), c.rival.gap === 0 ? t("Level with {name}", { name: first(c.rival.name) }) : h(Fragment, null, t("{name} is", { name: first(c.rival.name) }), " ", h("b", null, c.rival.gap), " ", t("ahead"))) : c.leader && c.chaser ? h("span", { className: "xc-chip" }, h(Icon, { n: "trophy", size: 16 }), t("You lead."), " ", t("{name} is", { name: first(c.chaser.name) }), " ", h("b", null, c.chaser.gap), " ", t("behind")) : null,
          c.workday && c.momentum.before > 0 && c.momentum.delta !== 0 ? h("span", { className: cx("xc-chip", c.momentum.delta < 0 && "is-alert") }, h(Icon, { n: c.momentum.delta > 0 ? "trending-up" : "trending-down", size: 16 }), h("b", null, (c.momentum.delta > 0 ? "+" : "") + c.momentum.delta), t("a day against last week")) : null,
          c.best.points > 0 ? h("span", { className: "xc-chip" }, h(Icon, { n: "star", size: 16 }), t("Best day"), " ", h("b", null, c.best.points), c.best.date ? h("small", null, shortDate(c.best.date)) : null) : null,
        ),
      ),
      h("div", { className: "xc-dares" },
        h("span", { className: "xc-dares-title" }, c.dare ? t("Raise the dare") : t("Take a dare"), c.dares.won > 0 ? h("small", null, t("{n} won", { n: c.dares.won })) : null),
        DARES.map((d) => {
          const target = c.dares[d.key];
          const taken = c.dare && c.dare.target >= target;
          const mine = c.dare && c.dare.level === d.key;
          return h("button", { key: d.key, type: "button", className: cx("xc-dare", mine && "is-mine", taken && !mine && "is-below"), disabled: !!busy || (taken && !mine) || mine, title: t(d.hint), onClick: () => setAsk(d.key) },
            h(Icon, { n: d.icon, size: 20 }), h("span", null, t(d.name)), h("b", null, target), mine ? h(Icon, { n: c.dare.done ? "check-circle" : "lock", size: 16 }) : null);
        }),
        ask ? h("div", { className: "xc-ask", role: "alertdialog", "aria-label": t("Take the dare") },
          h("p", null, t("{n} points today. Once taken it cannot be lowered or taken back.", { n: c.dares[ask] })),
          h("div", null, h("button", { type: "button", className: "xc-ask-yes", disabled: !!busy, onClick: () => take(ask) }, busy ? t("Saving ...") : t("I am in")), h("button", { type: "button", className: "xc-ask-no", onClick: () => setAsk(null) }, t("Not today"))),
        ) : null,
      ),
    ),
    h("div", { className: "xc-foot" },
      h("div", { className: "xc-quests" },
        h("span", { className: "xc-foot-title" }, c.workday ? t("Three for today") : t("Three for today, if you like"), h("small", null, t("+{n} points each", { n: c.weights.challenge }))),
        c.challenges.map((q) => h("div", { key: q.key, className: cx("xc-quest", q.done && "is-done") },
          h(Icon, { n: q.done ? "check-circle" : "radio-button-unchecked", size: 20 }),
          h("span", null, t(q.text)),
          h("b", null, q.n + "/" + q.target),
        )),
      ),
      h("div", { className: "xc-week" },
        h("span", { className: "xc-foot-title" }, t("This week"), h("small", null, c.week.points + " / " + c.week.target + (c.week.needPerDay > 0 ? " · " + t("{n} a day to make it", { n: c.week.needPerDay }) : c.week.points >= c.week.target ? " · " + t("week goal reached") : ""))),
        h("div", { className: "xc-days" }, c.week.days.map((d) => h("div", { key: d.date, className: cx("xc-day", d.date === c.date && "is-today", d.future && "is-future", d.points >= c.goal && "is-hit") },
          h("span", { className: "xc-day-bar" }, h("span", { style: { height: Math.max(d.points > 0 ? 6 : 0, (d.points / maxDay) * 100) + "%" } }), h("i", { style: { bottom: (c.goal / maxDay) * 100 + "%" } })),
          h("small", null, new Intl.DateTimeFormat(loc(), { weekday: "narrow", timeZone: "UTC" }).format(new Date(d.date + "T12:00:00Z"))),
        ))),
      ),
      c.badges.length ? h("div", { className: "xc-badges" },
        h("span", { className: "xc-foot-title" }, t("Next badges")),
        c.badges.map((b) => h("div", { key: b.key, className: "xc-badge" }, h(Icon, { n: "military-tech", size: 20 }), h("span", null, h("b", null, t(b.label)), h("small", null, t(b.hint))), h(Bar, { value: b.n, max: b.target, tone: "onink" }))),
      ) : null,
    ),
  );
}

// the small score in the top bar, on every page: the streak and today's points against the target
export function ChallengePill() {
  const t = useTx("chal");
  const c = useChallenge();
  const nudged = useRef(0);
  // after a long quiet spell during working hours: one quiet reminder (at most every 90 minutes, never when the goal is reached)
  useEffect(() => {
    if (!c || !c.inHours || c.reached) return;
    const quiet = c.idleMinutes == null ? (c.now > "10:30" ? 999 : 0) : c.idleMinutes;
    let muted = false;
    try { muted = localStorage.getItem("xc-quiet") === c.date; } catch { muted = false; }
    if (quiet >= 90 && !muted && Date.now() - nudged.current > 90 * 60000) {
      nudged.current = Date.now();
      toast(c.idleMinutes == null ? t("Nothing logged yet today. One call starts the day.") : t("{n} minutes without a logged action. One call?", { n: Math.min(quiet, 240) }));
    }
  }, [c]);
  if (!c || !c.workday) return null;
  const p = Math.min(100, Math.round((c.points / Math.max(1, c.target)) * 100));
  return h(Link, { to: "/today", className: cx("xc-pill", c.reached && "is-done", c.streak.atRisk && "is-alert"), title: c.reached ? t("Today's target is reached") : t("{gap} points to today's target", { gap: c.gap }) },
    c.streak.days > 0 ? h("span", { className: "xc-pill-streak" }, h(Icon, { n: "local-fire-department", size: 16 }), c.streak.days) : null,
    h("span", { className: "xc-pill-bar" }, h("span", { style: { width: p + "%" } })),
    h("b", null, c.points), h("small", null, "/ " + c.target),
    c.dare ? h(Icon, { n: c.dare.done ? "check-circle" : "lock", size: 16 }) : null,
  );
}
