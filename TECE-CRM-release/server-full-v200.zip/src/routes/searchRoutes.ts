import { Router } from 'express';
import { requireAuth, requireAdmin, type AuthedRequest } from '../middleware/auth';
import { smartSearch } from '../services/smartSearch';
import { ledgerOnly, createCardFromLedger, invoiceFind } from '../services/ledgerFind';

const router = Router();
router.use(requireAuth);

// the smart search: closest first, then look-alikes, then where the words are written down.
// An admin also sees the accounts of the ledger that have no customer card yet (so a customer that is in the ledger can always be found).
router.get('/', (req: AuthedRequest, res) => {
  const q = String(req.query.q ?? '').slice(0, 120);
  const limit = Math.min(30, Math.max(3, parseInt(String(req.query.limit ?? '10'), 10) || 10));
  try {
    const r = smartSearch(req.user!, q, limit);
    const invoices = invoiceFind(req.user as never, q);
    res.json(req.user!.role === 'admin' ? { ...r, ledger: ledgerOnly(q), invoices } : { ...r, invoices });
  } catch (err) { console.error('Search failed:', err); res.status(500).json({ error: 'The search failed.' }); }
});

// a customer card for an account that is only in the ledger
router.post('/ledger-card', requireAdmin, (req: AuthedRequest, res) => {
  try { res.json({ ok: true, ...createCardFromLedger(String(req.body?.sheet ?? ''), String(req.body?.sap ?? ''), req.user!.id) }); }
  catch (e) { res.status(400).json({ error: e instanceof Error ? e.message : String(e) }); }
});

export default router;
