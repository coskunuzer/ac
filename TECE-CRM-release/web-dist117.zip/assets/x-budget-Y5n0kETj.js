// The budget of one trip or one fair: the plan per kind of cost, what was spent, what is left, and what the money bought.
import { h, Fragment, useState, useEffect, useMemo, useRef, api, useT, Icon, cx, errText, eur, dayDiff, shortDate, Bar, Chip, Skel, toast, todayIso, loc, pctTxt } from "./x-kit-1W3jRMzJ.js";

const CAT_ICON = { flights: "flight", hotel: "hotel", transport: "directions-car", meals: "restaurant", hosting: "handshake", visa: "badge", other: "more-horiz", stand: "storefront", build: "construction", logistics: "local-shipping", travel: "luggage", promo: "local-mall", fees: "receipt-long" };
const toneOf = (spent, planned) => (planned <= 0 ? "" : spent > planned ? "bad" : spent > planned * 0.85 ? "warn" : "good");
const num = (v) => {
  const n = Number(String(v == null ? "" : v).replace(/\s/g, "").replace(",", "."));
  return Number.isFinite(n) ? n : 0;
};

// a first guess for a trip of N days, so nobody starts from an empty sheet (the person changes it before saving)
function typicalTrip(days) {
  const d = Math.max(1, days);
  return { flights: 550, hotel: 120 * Math.max(1, d - 1), transport: 60 * d, meals: 45 * d, hosting: 150, visa: 0, other: 100 };
}

// the kinds of document a cost is proven with (what Turquality asks for)
const DOC_TYPES = ["invoice", "payment", "ticket", "hotel", "other"];
const DOC_LABEL = { invoice: "Invoice", payment: "Payment proof", ticket: "Boarding pass / ticket", hotel: "Hotel bill", other: "Other document" };
const DOC_ICON = { invoice: "receipt-long", payment: "payments", ticket: "flight", hotel: "hotel", other: "description" };
const ACCEPT = ".pdf,.png,.jpg,.jpeg,.webp,.xlsx,.xls,.doc,.docx";

// a new cost, or a change to one (row): the same form for the person who travelled and for the budget people
function ExpenseForm({ kind, id, categories, currencies, row, onSaved, onClose }) {
  const t = useT();
  const [f, setF] = useState(() =>
    row
      ? { spent_on: row.date, category: row.category, amount: String(row.amount), currency: row.currency, rate: row.rate ? String(row.rate) : "", amount_try: row.currency !== "TRY" && row.currency !== "EUR" ? String(row.try) : "", supplier: row.supplier || "", description: row.description || "", invoice_no: row.invoiceNo || "", doc_type: row.docType || "invoice", turquality: row.turquality !== false }
      : { spent_on: todayIso(), category: categories[0].key, amount: "", currency: "EUR", rate: "", amount_try: "", supplier: "", description: "", invoice_no: "", doc_type: "invoice", turquality: true },
  );
  const [file, setFile] = useState(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState(null);
  const [rateHint, setRateHint] = useState(null);
  const autoRate = useRef(!row);
  const ref = useRef(null);
  useEffect(() => {
    if (row && ref.current && ref.current.scrollIntoView) ref.current.scrollIntoView({ block: "nearest", behavior: "smooth" });
  }, []);
  const set = (k) => (e) => setF((x) => ({ ...x, [k]: e.target.value }));
  const ym = f.spent_on.slice(0, 7);
  useEffect(() => {
    let alive = true;
    api.get(`/budget/event-rate?ym=${ym}`).then((r) => {
      if (!alive) return;
      // the rate of the month of the invoice, as long as the person did not type one: a new date brings its own month's rate
      const fill = (x) => !x.rate || autoRate.current;
      if (r.rate) { setRateHint(null); setF((x) => (fill(x) ? { ...x, rate: String(r.rate) } : x)); }
      else if (r.last && r.last.rate) { setF((x) => { if (!fill(x)) return x; setRateHint(r.last.ym); return { ...x, rate: String(r.last.rate) }; }); }
      else if (autoRate.current) { setRateHint(null); setF((x) => ({ ...x, rate: "" })); }
    }).catch(() => undefined);
    return () => {
      alive = false;
    };
  }, [ym]);
  async function save(e) {
    e.preventDefault();
    setErr(null);
    if (!num(f.amount)) return setErr(t("Type the amount on the invoice."));
    setBusy(true);
    try {
      const fd = new FormData();
      for (const [k, v] of Object.entries(f)) if (k !== "turquality" && v !== "") fd.append(k, v);
      fd.append("turquality", f.turquality ? "1" : "0");
      if (file) fd.append("file", file);
      const next = await api.post(row ? `/budget/event/${kind}/${id}/expense/${row.id}` : `/budget/event/${kind}/${id}/expense`, fd);
      toast(row ? t("Cost changed") : t("Cost saved"), "good");
      onSaved(next);
    } catch (e2) {
      setErr(errText(e2, t("Could not save")));
    } finally {
      setBusy(false);
    }
  }
  const foreign = f.currency !== "TRY" && f.currency !== "EUR";
  return h(
    "form",
    { className: "xb-form", onSubmit: save, ref },
    h("div", { className: "xb-form-title" }, h(Icon, { n: row ? "edit" : "receipt-long", size: 20 }), h("b", null, row ? t("Change the cost") : t("Add a cost")), h("small", null, t("Attach the receipt: it goes into the Turquality report by itself."))),
    h("div", { className: "xb-form-grid" },
      h("label", null, h("span", null, t("Date of the invoice")), h("input", { type: "date", value: f.spent_on, onChange: set("spent_on"), required: true })),
      h("label", null, h("span", null, t("Kind of cost")), h("select", { value: f.category, onChange: set("category") }, categories.map((c) => h("option", { key: c.key, value: c.key }, t(c.label))))),
      h("label", null, h("span", null, t("Amount")), h("input", { inputMode: "decimal", value: f.amount, onChange: set("amount"), placeholder: "0.00", autoFocus: !row })),
      h("label", null, h("span", null, t("Currency")), h("select", { value: f.currency, onChange: set("currency") }, (currencies || ["EUR", "TRY", "USD", "GBP"]).map((c) => h("option", { key: c, value: c }, c)))),
      h("label", null, h("span", null, t("Rate (TL for 1 €)")), h("input", { inputMode: "decimal", value: f.rate, onChange: (e) => { autoRate.current = false; setRateHint(null); set("rate")(e); }, placeholder: t("of the month") }), rateHint ? h("small", { className: "xb-hint" }, t("Rate of {ym}. Check it.", { ym: rateHint })) : null),
      foreign ? h("label", null, h("span", null, t("Amount in TL (as booked)")), h("input", { inputMode: "decimal", value: f.amount_try, onChange: set("amount_try") })) : null,
      h("label", null, h("span", null, t("Supplier")), h("input", { value: f.supplier, onChange: set("supplier"), placeholder: t("Airline, hotel, stand builder ...") })),
      h("label", null, h("span", null, t("Invoice no.")), h("input", { value: f.invoice_no, onChange: set("invoice_no") })),
      h("label", null, h("span", null, t("Kind of document")), h("select", { value: f.doc_type, onChange: set("doc_type") }, DOC_TYPES.map((k) => h("option", { key: k, value: k }, t(DOC_LABEL[k]))))),
      h("label", { className: "xb-file" }, h("span", null, row && row.hasFile ? t("Replace the document (optional)") : t("Receipt or invoice (PDF or picture)")), h("input", { type: "file", accept: ACCEPT, onChange: (e) => setFile(e.target.files && e.target.files[0] ? e.target.files[0] : null) })),
      h("label", { className: "xb-wide" }, h("span", null, t("What it was for")), h("input", { value: f.description, onChange: set("description") })),
      h("label", { className: "xb-check xb-wide" }, h("input", { type: "checkbox", checked: f.turquality, onChange: (e) => setF((x) => ({ ...x, turquality: e.target.checked })) }), h("span", null, h("b", null, t("For Turquality")), " ", kind === "trip" ? t("Goes into the Turquality report of this trip.") : t("Goes into the Turquality report of this fair."))),
    ),
    err ? h("p", { className: "tx-err", role: "alert" }, err) : null,
    h("div", { className: "xb-form-foot" },
      h("button", { type: "submit", className: "tc-btn tc-btn--md", disabled: busy }, busy ? t("Saving ...") : row ? t("Save the change") : t("Save the cost")),
      h("button", { type: "button", className: "tc-btn tc-btn--ghost tc-btn--md", onClick: onClose }, t("Cancel")),
      h("small", { className: "tx-muted" }, t("It is booked on the right line of the marketing budget by itself.")),
    ),
  );
}

// one cost in the list: what it was, its documents (open, add, remove) and - for the person who typed it in or the budget people - change / remove
function CostRow({ r, b, kind, id, catLabel, onEdit, take }) {
  const t = useT();
  const [mode, setMode] = useState(null);
  const [docType, setDocType] = useState(r.docType === "invoice" ? "payment" : "invoice");
  const [file, setFile] = useState(null);
  const [busy, setBusy] = useState(false);
  const mine = b.canManage || r.byId === b.me;
  const base = `/budget/event/${kind}/${id}`;
  const files = [
    r.hasFile ? { key: "m", url: `${base}/expense/${r.id}/file`, name: r.fileName || t("Document"), docType: r.docType } : null,
    ...(r.files || []).map((f) => ({ key: "f" + f.id, fid: f.id, url: `${base}/doc/${f.id}/file`, name: f.name || t("Document"), docType: f.docType })),
  ].filter(Boolean);
  async function addDoc(e) {
    e.preventDefault();
    if (!file) return toast(t("Choose the file."), "bad");
    setBusy(true);
    try {
      const fd = new FormData();
      fd.append("doc_type", docType);
      fd.append("file", file);
      take(await api.post(`${base}/expense/${r.id}/doc`, fd));
      toast(t("Document added"), "good");
      setMode(null);
      setFile(null);
    } catch (e2) {
      toast(errText(e2, t("Could not save")), "bad");
    } finally {
      setBusy(false);
    }
  }
  const [dropDoc, setDropDoc] = useState(null);
  async function removeDoc(f) {
    setBusy(true);
    try {
      take(await api.delete(`${base}/doc/${f.fid}`));
      toast(t("Document removed"), "good");
      setDropDoc(null);
    } catch (e2) {
      toast(errText(e2, t("Could not remove")), "bad");
    } finally {
      setBusy(false);
    }
  }
  async function remove() {
    setBusy(true);
    try {
      take(await api.delete(`${base}/expense/${r.id}`));
      toast(t("Cost removed"), "good");
    } catch (e2) {
      toast(errText(e2, t("Could not remove")), "bad");
      setBusy(false);
    }
  }
  const title = r.supplier || catLabel(r.category);
  return h("li", { className: cx("xb-row2", !r.turquality && "is-out") },
    h("div", { className: "xb-row2-top" },
      h("span", { className: "xb-row-date" }, shortDate(r.date)),
      h("span", { className: "xb-row-what" },
        h("b", null, title),
        h("small", null, [catLabel(r.category), r.description, r.invoiceNo, r.by && r.byId !== b.me ? t("by {name}", { name: r.by }) : null].filter(Boolean).join(" · ")),
      ),
      h("span", { className: "xb-row-amt" }, h("b", null, eur(r.eur)), r.currency !== "EUR" ? h("small", null, r.amount.toLocaleString(loc()) + " " + r.currency) : h("small", null, Math.round(r.try).toLocaleString("en-US") + " TL")),
      h("span", { className: "xb-row-acts" },
        mine ? h("button", { type: "button", className: "xb-icon", title: t("Add a document"), "aria-label": t("Add a document"), onClick: () => { setDropDoc(null); setMode(mode === "doc" ? null : "doc"); } }, h(Icon, { n: "upload-file", size: 18 })) : null,
        mine ? h("button", { type: "button", className: "xb-icon", title: t("Change"), "aria-label": t("Change"), onClick: () => onEdit(r) }, h(Icon, { n: "edit", size: 18 })) : null,
        mine ? h("button", { type: "button", className: "xb-icon xb-icon--bad", title: t("Remove this cost"), "aria-label": t("Remove this cost"), onClick: () => { setDropDoc(null); setMode(mode === "del" ? null : "del"); } }, h(Icon, { n: "delete", size: 18 })) : null,
      ),
    ),
    h("div", { className: "xb-docs" },
      r.turquality ? h("span", { className: "xb-tag xb-tag--tq" }, h(Icon, { n: "verified", size: 14 }), "Turquality") : h("span", { className: "xb-tag" }, t("Not for Turquality")),
      files.length === 0 ? h("span", { className: cx("xb-tag", r.turquality && "xb-tag--warn") }, h(Icon, { n: "warning", size: 14 }), t("No document yet")) : null,
      files.map((f) =>
        h("span", { key: f.key, className: "xb-doc" },
          h("a", { href: api.downloadUrl(f.url), target: "_blank", rel: "noreferrer", title: f.name }, h(Icon, { n: DOC_ICON[f.docType] || "attach-file", size: 14 }), h("span", null, t(DOC_LABEL[f.docType] || "Document"))),
          f.fid && mine ? h("button", { type: "button", "aria-label": t("Remove the document {name}", { name: f.name }), title: t("Remove the document"), onClick: () => { setMode(null); setDropDoc(f); } }, h(Icon, { n: "close", size: 14 })) : null,
        ),
      ),
    ),
    dropDoc
      ? h("div", { className: "xb-confirm", role: "alert" },
          h("span", null, t("Remove the document {name} ({type}) from this cost? It will not be in the Turquality report.", { name: dropDoc.name, type: t(DOC_LABEL[dropDoc.docType] || "Document") })),
          h("button", { type: "button", className: "tc-btn tc-btn--danger tc-btn--sm", disabled: busy, onClick: () => removeDoc(dropDoc) }, t("Remove")),
          h("button", { type: "button", className: "tc-btn tc-btn--ghost tc-btn--sm", onClick: () => setDropDoc(null) }, t("Keep it")),
        )
      : null,
    mode === "doc"
      ? h("form", { className: "xb-adddoc", onSubmit: addDoc },
          h("select", { value: docType, onChange: (e) => setDocType(e.target.value), "aria-label": t("Kind of document") }, DOC_TYPES.map((k) => h("option", { key: k, value: k }, t(DOC_LABEL[k])))),
          h("input", { type: "file", accept: ACCEPT, "aria-label": t("File"), onChange: (e) => setFile(e.target.files && e.target.files[0] ? e.target.files[0] : null) }),
          h("button", { type: "submit", className: "tc-btn tc-btn--sm", disabled: busy || !file }, busy ? t("Saving ...") : t("Add")),
          h("button", { type: "button", className: "tc-btn tc-btn--ghost tc-btn--sm", onClick: () => setMode(null) }, t("Cancel")),
          h("small", { className: "tx-muted" }, t("The payment proof, the boarding pass, the hotel bill of this cost.")),
        )
      : null,
    mode === "del"
      ? h("div", { className: "xb-confirm", role: "alert" },
          h("span", null, files.length > 1 ? t("Remove {what} ({amount}) and its {n} documents? This cannot be undone.", { what: title, amount: eur(r.eur), n: files.length }) : files.length ? t("Remove {what} ({amount}) and its document? This cannot be undone.", { what: title, amount: eur(r.eur) }) : t("Remove {what} ({amount})? This cannot be undone.", { what: title, amount: eur(r.eur) })),
          h("button", { type: "button", className: "tc-btn tc-btn--danger tc-btn--sm", disabled: busy, onClick: remove }, t("Remove")),
          h("button", { type: "button", className: "tc-btn tc-btn--ghost tc-btn--sm", onClick: () => setMode(null) }, t("Keep it")),
        )
      : null,
  );
}

// the Turquality file of this trip / fair: how ready it is, and the one PDF with everything in it
function TurqualityStrip({ b, kind, id }) {
  const t = useT();
  const tq = b.rows.filter((r) => r.turquality);
  const docs = tq.reduce((n, r) => n + (r.hasFile ? 1 : 0) + (r.files ? r.files.length : 0), 0);
  const missing = tq.filter((r) => !r.hasFile && !(r.files && r.files.length)).length;
  const ready = tq.length - missing;
  const out = b.rows.length - tq.length;
  const base = api.downloadUrl(`/budget/event/${kind}/${id}`);
  const lang = typeof document !== "undefined" && document.documentElement.lang === "tr" ? "tr" : "en";
  return h("div", { className: "xb-tq" },
    h("div", { className: "xb-tq-main" },
      h("span", { className: "xb-tq-ic" }, h(Icon, { n: missing || !tq.length ? "receipt-long" : "task-alt", size: 22 })),
      h("div", { className: "xb-tq-text" },
        h("b", null, t("Turquality report")),
        h("small", null, tq.length ? docs === 1 ? t("{n} costs · 1 document in one PDF, with the visit report", { n: tq.length }) : t("{n} costs · {d} documents in one PDF, with the visit report", { n: tq.length, d: docs }) : t("No cost is marked for Turquality yet.")),
        tq.length ? h("span", { className: "xb-tq-bar" }, h(Bar, { value: ready, max: tq.length, tone: missing ? "warn" : "good", label: t("Costs with a document") }), h("small", { className: missing ? "is-warn" : "is-good" }, missing ? t("{n} without a document", { n: missing }) : t("Every cost has its document"))) : null,
      ),
    ),
    h("div", { className: "xb-tq-acts" },
      h("a", { className: "tc-btn tc-btn--secondary tc-btn--sm", href: `${base}/turquality.pdf?lang=${lang}`, target: "_blank", rel: "noreferrer" }, h(Icon, { n: "download", size: 16 }), t("Turquality report")),
      h("a", { className: "tc-btn tc-btn--ghost tc-btn--sm", href: `${base}/expenses.xlsx` }, h(Icon, { n: "table-chart", size: 16 }), t("Excel")),
      out > 0 ? h("a", { className: "tc-link xb-tq-all", href: `${base}/turquality.pdf?all=1&lang=${lang}`, target: "_blank", rel: "noreferrer" }, t("All {n} costs (PDF)", { n: b.rows.length })) : null,
    ),
  );
}

// kind: "trip" | "exhibition". days: the length of the trip (for the first guess). onChange: told the new totals.
export function EventBudget({ kind, id, days, onChange, embedded, collapsible }) {
  const t = useT();
  const [b, setB] = useState(null);
  const [err, setErr] = useState(null);
  const [edit, setEdit] = useState(false);
  const [draft, setDraft] = useState({});
  const [adding, setAdding] = useState(false);
  const [editing, setEditing] = useState(null);
  const [busy, setBusy] = useState(false);
  const [open, setOpen] = useState(false);
  const [shown, setShown] = useState(!collapsible);
  const take = (d) => {
    setB(d);
    setErr(null);
    if (onChange) onChange({ planned: d.planned, spent: d.spent });
  };
  useEffect(() => {
    let alive = true;
    setB(null);
    api.get(`/budget/event/${kind}/${id}`).then((d) => alive && take(d)).catch((e) => alive && setErr(e && e.status === 403 ? "hidden" : errText(e, t("Could not load the budget"))));
    return () => {
      alive = false;
    };
  }, [kind, id]);
  const startEdit = (preset) => {
    const d = {};
    for (const c of b.categories) d[c.key] = preset ? String(preset[c.key] || "") : c.planned ? String(c.planned) : "";
    setDraft(d);
    setEdit(true);
    setShown(true);
  };
  async function savePlan() {
    setBusy(true);
    try {
      take(await api.put(`/budget/event/${kind}/${id}/plan`, { lines: b.categories.map((c) => ({ category: c.key, planned: num(draft[c.key]) })) }));
      setEdit(false);
      toast(t("Budget saved"), "good");
    } catch (e) {
      setErr(errText(e, t("Could not save")));
    } finally {
      setBusy(false);
    }
  }
  const draftTotal = useMemo(() => Object.values(draft).reduce((s, v) => s + num(v), 0), [draft]);
  if (err === "hidden") return null;
  if (err && !b) return h("p", { className: "tx-err" }, err);
  if (!b) return h(Skel, { height: 120 });
  const tone = toneOf(b.spent, b.planned);
  const empty = b.planned === 0 && b.spent === 0;
  const catLabel = (k) => { const c = b.categories.find((x) => x.key === k); return c ? t(c.label) : k; };
  if (!shown)
    return h("section", { className: "xb xb--closed", "aria-label": t("Budget") },
      h("button", { type: "button", className: "xb-closed", "aria-expanded": false, onClick: () => setShown(true) },
        h("span", { className: "xb-title" }, h(Icon, { n: "savings", size: 24 }), h("b", null, t("Budget"))),
        empty
          ? h("span", { className: "xb-closed-hint" }, b.canPlan ? t("Not planned yet. Set what this may cost.") : t("Nothing yet."))
          : h(Fragment, null,
              h("span", { className: "xb-closed-num" }, h("small", null, t("Spent")), h("b", { className: b.over ? "is-bad" : "" }, eur(b.spent))),
              h("span", { className: "xb-closed-num" }, h("small", null, t("Planned")), h("b", null, b.planned > 0 ? eur(b.planned) : "–")),
              b.planned > 0 ? h("span", { className: "xb-closed-bar" }, h(Bar, { value: b.spent, max: Math.max(b.planned, b.spent), mark: b.over ? b.planned : null, tone })) : h("span", { className: "xb-closed-bar" }),
              b.units[0] && b.units[0].each != null ? h("span", { className: "xb-closed-num" }, h("small", null, kind === "trip" ? t("Per customer on the trip") : t("Per person met")), h("b", null, eur(b.units[0].each))) : null,
            ),
        h("span", { className: "xb-closed-open" }, empty && b.canPlan ? t("Plan the budget") : t("Open"), h(Icon, { n: "keyboard-arrow-down", size: 20 })),
      ),
    );
  return h(
    "section",
    { className: cx("xb", embedded && "xb--embedded"), "aria-label": t("Budget") },
    h("header", { className: "xb-head" },
      h("div", { className: "xb-title" }, collapsible ? h("button", { type: "button", className: "xb-collapse", "aria-label": t("Close the budget"), onClick: () => { setShown(false); setEdit(false); setAdding(false); setEditing(null); } }, h(Icon, { n: "keyboard-arrow-up", size: 20 })) : null, h(Icon, { n: "savings", size: 24 }), h("h3", null, t("Budget")), b.over ? h(Chip, { tone: "bad", icon: "warning" }, t("Over budget")) : b.planned > 0 && tone === "warn" ? h(Chip, { tone: "warn" }, t("Nearly used up")) : null),
      h("div", { className: "xb-actions" },
        b.canPlan && !edit ? h("button", { type: "button", className: "tc-btn tc-btn--secondary tc-btn--sm", onClick: () => startEdit() }, h(Icon, { n: "edit", size: 16 }), b.planned > 0 ? t("Change the plan") : t("Plan the budget")) : null,
        b.canSpend && !adding ? h("button", { type: "button", className: "tc-btn tc-btn--sm", onClick: () => { setEditing(null); setAdding(true); } }, h(Icon, { n: "add", size: 16 }), b.canManage ? t("Add an expense") : t("Add my cost")) : null,
      ),
    ),
    empty && !edit
      ? h("div", { className: "xb-empty" },
          h("p", null, kind === "trip" ? t("No budget yet. Plan what this trip may cost, then see what it really cost next to it.") : t("No budget yet. Plan what this fair may cost, then see what it really cost next to it.")),
          b.canPlan && kind === "trip" && days ? h("button", { type: "button", className: "tc-link xb-linkbtn", onClick: () => startEdit(typicalTrip(days)) }, t("Start from typical costs for {n} days", { n: days })) : null,
        )
      : h(Fragment, null,
          h("div", { className: "xb-totals" },
            h("div", { className: "xb-total" }, h("span", null, t("Planned")), h("b", null, eur(edit ? draftTotal : b.planned))),
            h("div", { className: cx("xb-total", tone && "xb-total--" + tone) }, h("span", null, t("Spent")), h("b", null, eur(b.spent)), b.pct != null ? h("small", null, pctTxt(b.pct)) : null),
            h("div", { className: cx("xb-total", b.over && "xb-total--bad") }, h("span", null, b.over ? t("Over by") : t("Left")), h("b", null, b.planned > 0 ? eur(Math.abs(b.left)) : "–"), b.planned === 0 && b.spent > 0 ? h("small", null, t("nothing planned")) : null),
            b.units.filter((u) => u.each != null).slice(0, 2).map((u) => h("div", { key: u.label, className: "xb-total xb-total--unit" }, h("span", null, t("Per " + u.label.replace(/^customers on the trip$/, "customer on the trip").replace(/^people met$/, "person met").replace(/^offers sent$/, "offer").replace(/^customers won$/, "customer won"))), h("b", null, eur(u.each)), h("small", null, u.n + " " + t(u.label)))),
          ),
          b.planned > 0 ? h(Bar, { value: b.spent, max: Math.max(b.planned, b.spent), mark: b.spent > b.planned ? b.planned : null, tone, label: t("Spent of planned") }) : null,
          h("div", { className: "xb-cats", role: "table" },
            b.categories.filter((c) => edit || c.planned > 0 || c.spent > 0).map((c) => {
              const ct = toneOf(c.spent, c.planned);
              return h("div", { key: c.key, className: "xb-cat", role: "row" },
                h("span", { className: "xb-cat-name" }, h(Icon, { n: CAT_ICON[c.key] || "label", size: 20 }), t(c.label)),
                edit
                  ? h("span", { className: "xb-cat-input" }, "€", h("input", { inputMode: "decimal", value: draft[c.key] || "", placeholder: "0", "aria-label": t(c.label), onChange: (e) => setDraft((d) => ({ ...d, [c.key]: e.target.value })) }))
                  : h("span", { className: "xb-cat-bar" }, h(Bar, { value: c.spent, max: Math.max(c.planned, c.spent, 1), mark: c.spent > c.planned && c.planned > 0 ? c.planned : null, tone: ct })),
                h("span", { className: cx("xb-cat-num", ct === "bad" && "is-bad") }, h("b", null, eur(c.spent)), h("small", null, " / " + eur(edit ? num(draft[c.key]) : c.planned))),
              );
            }),
          ),
          edit
            ? h("div", { className: "xb-form-foot" },
                h("button", { type: "button", className: "tc-btn tc-btn--md", disabled: busy, onClick: savePlan }, busy ? t("Saving ...") : t("Save the plan")),
                h("button", { type: "button", className: "tc-btn tc-btn--ghost tc-btn--md", onClick: () => setEdit(false) }, t("Cancel")),
                h("small", { className: "tx-muted" }, t("Amounts in euro. Leave a line empty when nothing is planned for it.")),
              )
            : null,
        ),
    adding || editing ? h(ExpenseForm, { key: editing ? "e" + editing.id : "new", kind, id, row: editing, categories: b.categories, currencies: b.currencies, onClose: () => { setAdding(false); setEditing(null); }, onSaved: (d) => { take(d); setAdding(false); setEditing(null); setOpen(true); } }) : null,
    b.rows.length > 0 || b.canSpend ? h(TurqualityStrip, { b, kind, id }) : null,
    b.rows.length > 0
      ? h("div", { className: "xb-rows" },
          h("button", { type: "button", className: "xb-rows-toggle", "aria-expanded": open, onClick: () => setOpen((o) => !o) }, h(Icon, { n: open ? "keyboard-arrow-up" : "keyboard-arrow-down", size: 20 }), t("{n} expenses", { n: b.rows.length }), h("span", null, eur(b.spent))),
          open
            ? h("ul", null, b.rows.map((r) => h(CostRow, { key: r.id, r, b, kind, id, catLabel, take, onEdit: (row) => { setAdding(false); setEditing(row); } })))
            : null,
        )
      : null,
    err && b ? h("p", { className: "tx-err", role: "alert" }, err) : null,
  );
}

// a line for lists: "€1,740 of €2,400" with a bar
export function BudgetLine({ planned, spent }) {
  const t = useT();
  if (!planned && !spent) return null;
  const tone = toneOf(spent, planned);
  return h("div", { className: "xb-line" },
    h("div", { className: "xb-line-top" }, h("span", null, h(Icon, { n: "savings", size: 16 }), " ", t("Budget")), h("b", { className: tone === "bad" ? "is-bad" : "" }, eur(spent), planned > 0 ? h("small", null, " / " + eur(planned)) : null)),
    planned > 0 ? h(Bar, { value: spent, max: Math.max(planned, spent), mark: spent > planned ? planned : null, tone }) : null,
  );
}

export { toneOf, dayDiff };
