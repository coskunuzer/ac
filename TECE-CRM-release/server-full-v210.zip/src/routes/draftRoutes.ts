import { Router } from 'express';
import multer from 'multer';
import { screenshotText } from '../services/screenshotText';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { cardModel } from '../models/cardModel';
import { activityModel } from '../models/activityModel';
import { canSeeCard } from '../services/visibility';
import { useAi } from '../services/aiBudget';
import { aiFailureMessage } from '../services/aiGate';
import { fillModel, introModel, adviseReply, introContext, introTemplate, introWithAi, nudgeTemplate, polishDraft, replyFacts, type NudgeKind } from '../services/drafts';

const router = Router();
const shots = multer({ storage: multer.memoryStorage(), limits: { fileSize: 12 * 1024 * 1024, files: 4 } });
router.use(requireAuth);

const KINDS: NudgeKind[] = ['reorder', 'offer_followup', 'first_contact', 'quiet', 'proforma_followup', 'payment', 'appointment'];

function cardOf(req: AuthedRequest, res: import('express').Response) {
  const card = cardModel.findById(parseInt(String(req.params.id), 10));
  if (!card) { res.status(404).json({ error: 'Not found' }); return null; }
  if (!canSeeCard(req.user, card)) { res.status(403).json({ error: 'You do not have access to this record' }); return null; }
  return card;
}

// the reminder says "write to them": the e-mail is ready (plain and natural); with ai: true the AI rewrites it so it sounds like a person
router.post('/:id/nudge-draft', async (req: AuthedRequest, res) => {
  const card = cardOf(req, res);
  if (!card) return;
  const kind = KINDS.includes(req.body?.kind) ? (req.body.kind as NudgeKind) : 'quiet';
  const c = (req.body?.ctx && typeof req.body.ctx === 'object' ? req.body.ctx : {}) as Record<string, unknown>;
  const base = nudgeTemplate(card, kind, { days: Number(c.days) || null, lastOrder: typeof c.lastOrder === 'string' ? c.lastOrder : null, usualDays: Number(c.usualDays) || null, offerAt: typeof c.offerAt === 'string' ? c.offerAt : null, proforma: typeof c.proforma === 'string' ? c.proforma : null, amount: typeof c.amount === 'string' ? c.amount : null, place: typeof c.place === 'string' ? c.place.slice(0, 120) : null, dates: typeof c.dates === 'string' ? c.dates.slice(0, 60) : null, time: typeof c.time === 'string' ? c.time.slice(0, 10) : null });
  if (req.body?.ai !== true) return res.json({ ...base, ai: false });
  if (!useAi(req.user!, res)) return;
  const better = await polishDraft(card, base, req.user!.display_name || req.user!.username);
  if (!better) return res.status(503).json({ ai: true, error: aiFailureMessage('The AI could not rewrite it just now. The plain e-mail is still good.') });
  res.json({ ...better, ai: true });
});

// an introduction e-mail for a potential customer, from what we know about them (the plain version at once; with ai: true the AI writes it in their language)
router.post('/:id/intro-draft', async (req: AuthedRequest, res) => {
  const card = cardOf(req, res);
  if (!card) return;
  const sender = req.user!.display_name || req.user!.username;
  const ctx = introContext(card);
  const model = introModel();
  const base = ctx.relation === 'lead' && model ? fillModel(model, card, sender) : introTemplate(card, sender, ctx);
  if (req.body?.ai !== true) return res.json({ ...base, ai: false });
  if (!useAi(req.user!, res)) return;
  const better = await introWithAi(card, base, sender, ctx);
  // the plain introduction is still good: the person gets it with the reason
  if (!better) return res.json({ ...base, ai: false, note: aiFailureMessage('The AI could not write it just now, so this is the standard introduction.') });
  res.json({ ...better, ai: true });
});

// the customer's answer about a price or about quality is put on their record, and the AI says what we can do and writes the reply
router.post('/:id/reply-advice', shots.array('photos', 4), async (req: AuthedRequest, res) => {
  const card = cardOf(req, res);
  if (!card) return;
  let text = String(req.body?.text ?? '').trim();
  // a screenshot of the customer's e-mail (pasted) is read into text first
  const files = (req.files as Express.Multer.File[] | undefined) ?? [];
  if (files.length) {
    if (!useAi(req.user!, res)) return;
    const read = await screenshotText(files.map((f) => ({ data: f.buffer, mime: f.mimetype || 'image/png' })), 'It is an e-mail from a customer.');
    if (!read) return res.status(503).json({ ai: true, error: aiFailureMessage('The AI could not read the screenshot just now. Paste the text of the e-mail, or try again.') });
    text = `${text}\n${read}`.trim();
  }
  if (text.length < 15) return res.status(400).json({ error: 'Paste the customer’s message first.' });
  // the reply is kept in the history whatever the AI does
  if (req.body?.save !== false) activityModel.add({ userId: req.user!.id, cardId: card.id, type: 'note', text: `Customer reply (e-mail): ${text.replace(/\s+/g, ' ').slice(0, 1800)}` });
  if (!files.length && !useAi(req.user!, res)) return;
  const facts = replyFacts(card, req.user!, text);
  const advice = await adviseReply(card, text, req.user!.display_name || req.user!.username, facts);
  if (!advice) return res.status(503).json({ ai: true, saved: true, error: aiFailureMessage('The reply is saved on the customer, but the AI could not analyse it just now. Try again in a minute.') });
  res.json(advice);
});

export default router;
