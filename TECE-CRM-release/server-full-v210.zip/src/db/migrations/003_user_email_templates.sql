ALTER TABLE users ADD COLUMN email_template_subject TEXT;
ALTER TABLE users ADD COLUMN email_template_body TEXT;
