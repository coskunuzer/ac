import type { Lang } from './translate';

// The fixed words of the offer layout (what is not in the price workbook), in the five languages.
type Key = 'customer' | 'offer' | 'date' | 'preparedBy' | 'currency' | 'eur' | 'usd' | 'product' | 'terms' | 'delivery' | 'payment' | 'dispatch';

export const LABELS: Record<Lang, Record<Key, string>> = {
  en: { customer: 'CUSTOMER', offer: 'OFFER', date: 'DATE', preparedBy: 'PREPARED BY', currency: 'CURRENCY', eur: 'Euro (EUR)', usd: 'US dollar (USD)', product: 'PRODUCT', terms: 'Terms and conditions', delivery: 'Delivery term', payment: 'Payment term', dispatch: 'Dispatch time' },
  ru: { customer: 'КЛИЕНТ', offer: 'ПРЕДЛОЖЕНИЕ', date: 'ДАТА', preparedBy: 'ПОДГОТОВИЛ', currency: 'ВАЛЮТА', eur: 'Евро (EUR)', usd: 'Доллар США (USD)', product: 'ТОВАР', terms: 'Условия сделки', delivery: 'Условия поставки', payment: 'Условия оплаты', dispatch: 'Срок отгрузки' },
  tr: { customer: 'MÜŞTERİ', offer: 'TEKLİF', date: 'TARİH', preparedBy: 'HAZIRLAYAN', currency: 'PARA BİRİMİ', eur: 'Euro (EUR)', usd: 'ABD Doları (USD)', product: 'ÜRÜN', terms: 'Şartlar ve koşullar', delivery: 'Teslimat şekli', payment: 'Ödeme şekli', dispatch: 'Sevkiyat süresi' },
  es: { customer: 'CLIENTE', offer: 'OFERTA', date: 'FECHA', preparedBy: 'PREPARADO POR', currency: 'MONEDA', eur: 'Euro (EUR)', usd: 'Dólar estadounidense (USD)', product: 'PRODUCTO', terms: 'Términos y condiciones', delivery: 'Condiciones de entrega', payment: 'Condiciones de pago', dispatch: 'Plazo de despacho' },
  fr: { customer: 'CLIENT', offer: 'OFFRE', date: 'DATE', preparedBy: 'PRÉPARÉ PAR', currency: 'DEVISE', eur: 'Euro (EUR)', usd: 'Dollar américain (USD)', product: 'PRODUIT', terms: 'Conditions générales', delivery: 'Conditions de livraison', payment: 'Conditions de paiement', dispatch: "Délai d'expédition" },
};

export const LOCALE: Record<Lang, string> = { en: 'en-GB', ru: 'ru-RU', tr: 'tr-TR', es: 'es-ES', fr: 'fr-FR' };

export const label = (lang: string | undefined, key: Key): string => (LABELS[(lang as Lang) in LABELS ? (lang as Lang) : 'en'] ?? LABELS.en)[key];
