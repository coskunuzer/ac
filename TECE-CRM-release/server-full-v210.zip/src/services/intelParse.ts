import fs from 'fs';
import os from 'os';
import path from 'path';
import { spawn } from 'node:child_process';

// Reading the big SAP Excel files in a separate process (no database here).
export type IntelKind = 'sales' | 'stock' | 'kartela' | 'master';

// runs in the child process
const SCRIPT = `
const X = require(process.argv[1]); const fs = require('fs');
const kind = process.argv[2], input = process.argv[3], output = process.argv[4];
const wb = X.read(fs.readFileSync(input), { type: 'buffer', dense: true });
const sheetRows = (ws) => X.utils.sheet_to_json(ws, { header: 1, raw: true, defval: '' });
const ser = (n) => { if (n instanceof Date) return n.toISOString().slice(0, 10); const v = +n; if (!v) return ''; if (v > 20000 && v < 80000) return new Date(Math.round((v - 25569) * 864e5)).toISOString().slice(0, 10); const d = new Date(n); return isNaN(+d) ? '' : d.toISOString().slice(0, 10); };
const num = (v) => { const x = +v; return Number.isFinite(x) ? x : 0; };
const out = { kind, rows: [] };
if (kind === 'sales') {
  const r = sheetRows(wb.Sheets[wb.SheetNames[0]]); const H = (r[0] || []).map((x) => String(x).trim());
  const c = (n) => H.indexOf(n);
  const need = ['Fatura türü', 'Fatura no', 'Kalem', 'Faturalama tarihi', 'Malzeme', 'Müşteri kodu', 'Net total euro'];
  const miss = need.filter((n) => c(n) < 0); if (miss.length) { out.error = 'This is not the ZSD0005 sales list: columns missing: ' + miss.join(', '); }
  else {
    const I = { t: c('Fatura türü'), no: c('Fatura no'), it: c('Kalem'), d: c('Faturalama tarihi'), so: c('Satış belgesi'), rep: c('Plasiyer'), mat: c('Malzeme'), desc: c('Malzeme açıklaması'), cu: c('Müşteri kodu'), cn: c('Ünvan'), w: c('Genişlik Bilgisi(mm)'), m: c('Faturalanan miktar'), m2: c('Faturalanan Top.Sip.Mik M2'), kg: c('Toplam Sipariş KG'), eur: c('Net total euro'), th: c('Kalınlık Bilgisi(mm)'), ty: c('Tip tanım'), gr: c('Ürün Grubu Tanımı'), fi: c('Baskı Yüzey Tanımı'), rg: c('Bölge adı'), ci: c('Şehir'), rs: c('İade nedeni tanımı') };
    let skipped = 0;
    for (let i = 1; i < r.length; i++) { const a = r[i]; if (!a || a.length < 10) continue; const t = String(a[I.t]).trim();
      if (t === 'DHL.MAHSUP') { skipped++; continue; }
      if (t !== 'SATIŞ' && t !== 'İADE') continue;
      const d = ser(a[I.d]); if (!d) continue;
      out.rows.push([String(a[I.no]), String(a[I.it]), t === 'İADE' ? 'R' : 'S', d, String(a[I.so] || ''), String(a[I.cu]), String(a[I.cn] || ''), String(a[I.mat]), String(a[I.desc] || ''), String(a[I.gr] || ''), String(a[I.ty] || ''), String(a[I.fi] || ''), num(a[I.th]), num(a[I.w]), num(a[I.m]), num(a[I.m2]), num(a[I.kg]), num(a[I.eur]), String(a[I.rg] || ''), String(a[I.ci] || '').replace('Sehir_Verisi_Yok', ''), String(a[I.rep] || ''), String(a[I.rs] || '')]); }
    out.skipped = skipped;
  }
} else if (kind === 'stock') {
  const r = sheetRows(wb.Sheets[wb.SheetNames[0]]); const H = (r[0] || []).map((x) => String(x).trim()); const c = (n) => H.indexOf(n);
  const need = ['Mal grubu', 'Malzeme', 'Depo yeri', 'Müşteri', 'Tahditsiz klnb.']; const miss = need.filter((n) => c(n) < 0);
  if (miss.length) out.error = 'This is not the ZMM0006 stock list: columns missing: ' + miss.join(', ');
  else {
    const EB = new Set(['300001', '300002', '300003', '300004', '300005', '300006', '300007', '300008', '300009', '310001']);
    const I = { g: c('Mal grubu'), gn: c('Mal grubu tanımı 2'), mat: c('Malzeme'), desc: c('Malzeme kısa metni'), th: c('Kalınlık Bilgisi(mm)'), w: c('Genişlik Bilgisi(mm)'), rl: c('Rulo Boyu Bilgisi(m)'), dp: c('Depo yeri'), cu: c('Müşteri'), q: c('Tahditsiz klnb.'), so: c('Satış belgesi'), it: c('Kalem'), m2: c('Toplam M2'), rec: c('Son mal girişi'), fo: c('Form No') };
    for (let i = 1; i < r.length; i++) { const a = r[i]; if (!a || !EB.has(String(a[I.g]))) continue; const q = num(a[I.q]); if (q <= 0) continue;
      out.rows.push([String(a[I.g]), String(a[I.gn] || ''), String(a[I.mat]), String(a[I.desc] || ''), num(a[I.th]), num(a[I.w]), num(a[I.rl]), q, num(a[I.m2]), String(a[I.dp]), String(a[I.cu] || ''), String(a[I.cu + 1] || ''), String(a[I.so] || ''), String(a[I.it] || ''), ser(a[I.rec]), String(a[I.fo] || '')]); }
  }
} else if (kind === 'master') {
  const r = sheetRows(wb.Sheets[wb.SheetNames[0]]); const H = (r[0] || []).map((x) => String(x).trim());
  const c = (n) => H.indexOf(n);
  const need = ['Müşteri', 'Ülke', 'Incoterms', 'Ödeme koşulu'];
  const miss = need.filter((n) => c(n) < 0);
  if (miss.length) out.error = 'This is not the SAP customer master list: columns missing: ' + miss.join(', ');
  else {
    const I = { code: c('Müşteri'), ch: c('Dağıtım kanalı'), n1: H.lastIndexOf('Ad 1'), city: H.lastIndexOf('Kent'), iso: c('Ülke'), prov: c('İl'), ph: c('Telefon 1'), del: c('Merkezi silme işareti'), blk: c('Merkezi sipariş blokajı'), inc: c('Incoterms'), incp: c('Incoterms yer 1'), pay: c('Ödeme koşulu'), mail: c('E-posta adresi') };
    for (let i = 1; i < r.length; i++) { const a = r[i]; const code = String(a[I.code] || '').trim(); if (!code) continue;
      out.rows.push([code, String(a[I.n1] || '').trim(), String(a[I.iso] || '').trim().toUpperCase(), String(a[I.city] || '').trim(), String(a[I.prov] || '').trim(), String(a[I.inc] || '').trim(), String(a[I.incp] || '').trim(), String(a[I.pay] || '').trim(), String(a[I.mail] || '').trim().toLowerCase(), String(a[I.ph] || '').trim(), String(a[I.ch] || '').trim(), (String(a[I.del] || '').trim() || String(a[I.blk] || '').trim()) ? 1 : 0]); }
    if (!out.rows.length) out.error = 'The customer list is empty.';
  }
} else if (kind === 'kartela') {
  out.surf = [];
  for (const n of wb.SheetNames) { const r = sheetRows(wb.Sheets[n]);
    if (/^Y/.test(n) && /Surface/i.test(n)) { for (const x of r) if (typeof x[0] === 'number' && x[1]) out.surf.push([String(x[1]).trim(), String(x[3] || x[2] || '').trim()]); continue; }
    if (/How|Order/i.test(n)) continue;
    let sec = '';
    for (const x of r) { const a = String(x[0]).trim();
      if (a && isNaN(+a) && a !== 'NO' && !a.startsWith('TECE') && x[1] === '') { sec = a.replace(/\\s+/g, ' '); continue; }
      if (typeof x[0] === 'number' && x[1] !== '') out.rows.push([n, sec, x[0], String(x[1]).trim(), String(x[2]).trim(), String(x[3]).trim(), String(x[4]).trim(), String(x[5]).trim()]); } }
  if (!out.rows.length) out.error = 'No kartela rows found. Use the TECE kartela workbook (one tab per list).';
}
fs.writeFileSync(output, JSON.stringify(out));
`;

export function parseInChild(kind: IntelKind, buffer: Buffer): Promise<{ rows: unknown[][]; surf?: string[][]; skipped?: number; error?: string }> {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'intel-'));
  const input = path.join(dir, 'in.xlsx'), output = path.join(dir, 'out.json');
  fs.writeFileSync(input, buffer);
  return new Promise((resolve, reject) => {
    const done = () => { try { fs.rmSync(dir, { recursive: true, force: true }); } catch { /* temp */ } };
    const child = spawn(process.execPath, ['--max-old-space-size=3072', '-e', SCRIPT, require.resolve('xlsx'), kind, input, output], { stdio: ['ignore', 'ignore', 'pipe'] });
    let err = '';
    child.stderr.on('data', (d) => { err += String(d); });
    child.on('error', (e) => { done(); reject(e); });
    child.on('close', (code) => {
      try {
        if (code !== 0 || !fs.existsSync(output)) throw new Error(`The file could not be read${err ? `: ${err.split('\n').find((l) => l.trim()) ?? ''}` : ''}`.slice(0, 300));
        const out = JSON.parse(fs.readFileSync(output, 'utf8'));
        done(); resolve(out);
      } catch (e) { done(); reject(e); }
    });
  });
}

