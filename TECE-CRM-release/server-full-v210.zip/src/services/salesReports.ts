import path from 'path';
import ExcelJS from 'exceljs';
import { db } from '../db/connection';
import { countryMap, continentOf } from './intelCountry';
import { windows } from './intelEngine';
import { countryModel, canonicalCountry } from '../models/countryModel';
import { filterVisible, type Viewer } from './visibility';
import { accountOfSapAny } from './perfAnalytics';
import { normName, type Overview } from './salesTargets';

// The Excel reports of the CRM: the customer list in Sena's template, the Turquality workbook (market revenue, new customers, distributor coverage)
// and the targets / forecasts table. All sales figures are net EUR from the SAP sales list kept in Sales intelligence.

const GROUPCOS = /TECE\s*DE[CK]|TEZER/i;
const YELLOW = 'FFFFFF00';
const border = { top: { style: 'thin' as const, color: { argb: 'FFD0D0D0' } }, left: { style: 'thin' as const, color: { argb: 'FFD0D0D0' } }, bottom: { style: 'thin' as const, color: { argb: 'FFD0D0D0' } }, right: { style: 'thin' as const, color: { argb: 'FFD0D0D0' } } };
const EUR = '#,##0;(#,##0);-', PCT = '0.0%;-0.0%;-', DATE = 'dd.mm.yyyy';

function header(ws: ExcelJS.Worksheet, row: number, labels: string[], height = 36) {
  const r = ws.getRow(row); r.values = labels; r.height = height;
  r.eachCell((c) => { c.font = { bold: true, size: 10, name: 'Arial' }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: YELLOW } }; c.alignment = { vertical: 'middle', horizontal: 'center', wrapText: true }; c.border = border; });
}
function body(ws: ExcelJS.Worksheet, from: number, fmts: (string | undefined)[]) {
  for (let r = from; r <= ws.rowCount; r++) ws.getRow(r).eachCell({ includeEmpty: false }, (c, i) => { c.font = { size: 10, name: 'Arial' }; c.border = border; if (fmts[i - 1]) c.numFmt = fmts[i - 1]!; });
}
const toBuf = async (wb: ExcelJS.Workbook) => Buffer.from(await wb.xlsx.writeBuffer());
const dateOf = (s: string | null | undefined): Date | null => (s && /^\d{4}-\d{2}-\d{2}/.test(s) ? new Date(`${s.slice(0, 10)}T00:00:00Z`) : null);

// ---------- sales per customer (from the summary of the SAP sales list)
export interface CustSales { code: string; ytd: number; py: number; l12: number; p12: number; years: Record<number, number> }
export function salesByCustomer(): { map: Map<string, CustSales>; cut: string | null; year: number } {
  let W; try { W = windows(); } catch { return { map: new Map(), cut: null, year: new Date().getFullYear() }; }
  const year = +W.cut.slice(0, 4);
  const l1 = W.L12S.slice(0, 7), l2 = W.L12E.slice(0, 7), p1 = W.P12S.slice(0, 7), p2 = (() => { let y = +l1.slice(0, 4), m = +l1.slice(5, 7) - 1; if (m < 1) { m = 12; y--; } return `${y}-${String(m).padStart(2, '0')}`; })();
  const map = new Map<string, CustSales>();
  for (const r of db.prepare("SELECT customer, period, SUM(eur) eur FROM intel_fact WHERE customer NOT IN (SELECT code FROM intel_excluded) GROUP BY customer, period").all() as { customer: string; period: string; eur: number }[]) {
    let o = map.get(r.customer); if (!o) { o = { code: r.customer, ytd: 0, py: 0, l12: 0, p12: 0, years: {} }; map.set(r.customer, o); }
    const y = +r.period.slice(0, 4); o.years[y] = (o.years[y] ?? 0) + r.eur;
    if (y === year) o.ytd += r.eur; if (y === year - 1) o.py += r.eur;
    if (!r.period.endsWith('-00')) { if (r.period >= l1 && r.period <= l2) o.l12 += r.eur; else if (r.period >= p1 && r.period <= p2) o.p12 += r.eur; }
  }
  return { map, cut: W.cut, year };
}

// ================= 1. the customer list (Sena's template) =================
interface CardRow { id: number; company: string | null; name: string | null; country: string | null; city: string | null; market: string | null; work_area: string | null; person: string | null; rate: number | null; sap: string | null; lead_info: string | null; company_score: number | null; notes: string | null; uploaded_by: number; status: string; owner_override: number | null; stage: string | null }
const TIER = (v: string | undefined) => { const m = /^\s*([A-D])\b/i.exec(v ?? ''); return m ? `Tier ${m[1].toUpperCase()}` : ''; };

export interface ListOptions { includeSapOnly: boolean; money: boolean }
export async function customerListWorkbook(viewer: Viewer, opt: ListOptions): Promise<Buffer> {
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.readFile(path.join(__dirname, '..', '..', 'assets', 'templates', 'musteri-listesi-sablonu.xlsx'));
  const ws = wb.getWorksheet('Müşteriler')!, wd = wb.getWorksheet('Distribütörler')!;
  const styleRow = ws.getRow(2); const styles: Partial<ExcelJS.Style>[] = []; for (let i = 1; i <= 22; i++) styles.push({ ...styleRow.getCell(i).style });
  const dStyleRow = wd.getRow(2); const dStyles: Partial<ExcelJS.Style>[] = []; for (let i = 1; i <= 8; i++) dStyles.push({ ...dStyleRow.getCell(i).style });
  // empty the sample rows
  for (let r = 2; r <= Math.max(ws.rowCount, 502); r++) { const row = ws.getRow(r); for (let c = 1; c <= 22; c++) row.getCell(c).value = null; }
  for (let r = 2; r <= Math.max(wd.rowCount, 102); r++) { const row = wd.getRow(r); for (let c = 1; c <= 8; c++) row.getCell(c).value = null; }

  const { map: sales, cut, year } = salesByCustomer();
  const cm = countryMap();
  const intelC = new Map((db.prepare('SELECT code, name, city, rep, last_date FROM intel_cust').all() as { code: string; name: string; city: string; rep: string; last_date: string }[]).map((r) => [r.code, r]));
  const master = new Map((db.prepare('SELECT code, city, incoterm, pay_days FROM intel_master').all() as { code: string; city: string; incoterm: string; pay_days: number | null }[]).map((r) => [r.code, r]));
  const cutDate = cut ? new Date(`${cut}T00:00:00Z`) : new Date();
  const active = (last: string | null | undefined) => (last ? (cutDate.getTime() - new Date(`${last}T00:00:00Z`).getTime()) / 864e5 <= 365 ? 'Aktif' : 'Pasif' : '');

  const cards = db.prepare("SELECT id, company, name, country, city, market, work_area, person, rate, sap, lead_info, company_score, notes, uploaded_by, status, owner_override, stage FROM cards WHERE stage = 'customer' OR (sap IS NOT NULL AND TRIM(sap) <> '')").all() as unknown as CardRow[];
  const seen = filterVisible(viewer, cards as never) as unknown as CardRow[];
  const done = new Set<string>();
  const out: (string | number | Date | null)[][] = [];
  const line = (code: string, card: CardRow | null): (string | number | Date | null)[] => {
    const s = sales.get(code), ic = intelC.get(code), ms = master.get(code), c = cm.get(code);
    const market = card?.market === 'domestic' || code.startsWith('1201') ? 'domestic' : 'export';
    const country = card?.country?.trim() ? (canonicalCountry(card.country) as string) : c?.country || '';
    let info: { tier?: string } = {}; try { info = card?.lead_info ? JSON.parse(card.lead_info) : {}; } catch { /* no info */ }
    const rep = card?.person || (country ? countryModel.findByCountry(country)?.responsible : '') || ic?.rep || '';
    const acc = opt.money && code ? accountOfSapAny(code) : null;
    const l12 = s?.l12 ?? 0, p12 = s?.p12 ?? 0;
    return [
      code || null, card?.company || card?.name || ic?.name || '', market === 'domestic' ? 'Yurtiçi' : 'Yurtdışı', country, card?.city || ic?.city || ms?.city || '', card?.work_area || '', rep, active(ic?.last_date),
      s ? 'EUR' : '', opt.money && s ? Math.round(s.ytd) : null, opt.money && s ? Math.round(l12) : null, opt.money && s ? Math.round(s.py) : null, opt.money && p12 > 0 ? (l12 - p12) / p12 : null, opt.money && s ? Math.round(l12) : null,
      acc && acc.overdue > 0 ? Math.round(acc.overdue) : null, card?.company_score ?? null, TIER(info.tier), card?.rate ?? null, dateOf(ic?.last_date), ms?.pay_days ?? (acc?.terms || null), ms?.incoterm || '', '',
    ];
  };
  for (const c of seen) { const code = (c.sap ?? '').trim(); if (code) done.add(code); out.push(line(code, c)); }
  if (opt.includeSapOnly && viewer.role === 'admin') {
    for (const [code, s] of [...sales].sort((a, b) => b[1].l12 - a[1].l12)) {
      if (done.has(code) || !intelC.has(code) || GROUPCOS.test(intelC.get(code)!.name || '')) continue;
      if (s.l12 <= 0 && s.ytd <= 0 && s.py <= 0) continue;
      out.push(line(code, null));
    }
  }
  const blankLast = (x: unknown) => (x ? 0 : 1);
  out.sort((a, b) => String(a[2]).localeCompare(String(b[2]), 'tr') || blankLast(a[3]) - blankLast(b[3]) || String(a[3]).localeCompare(String(b[3]), 'tr') || String(a[1]).localeCompare(String(b[1]), 'tr'));
  out.forEach((vals, i) => { const row = ws.getRow(i + 2); vals.forEach((v, k) => { const cell = row.getCell(k + 1); cell.value = v as ExcelJS.CellValue; cell.style = { ...styles[k] }; }); row.commit(); });
  ws.autoFilter = { from: 'A1', to: `V${Math.max(2, out.length + 1)}` };

  // distributors
  const dist = db.prepare('SELECT * FROM distributors ORDER BY country, name').all() as unknown as DistRow[];
  dist.forEach((d, i) => {
    const row = wd.getRow(i + 2);
    const vals: (string | null)[] = [d.sap || '', d.name, d.country, d.region || '', d.status === 'passive' ? 'Pasif' : 'Aktif', d.status === 'passive' ? [d.status_reason, d.status_date].filter(Boolean).join(' / ') : '', d.owner || countryModel.findByCountry(d.country)?.responsible || '', null];
    vals.forEach((v, k) => { const cell = row.getCell(k + 1); cell.value = v; cell.style = { ...dStyles[k] }; }); row.commit();
  });
  wd.autoFilter = { from: 'A1', to: `G${Math.max(2, dist.length + 1)}` };
  void year;
  return toBuf(wb);
}

// ================= 2. Turquality =================
interface DistRow { id: number; country: string; name: string; phone: string | null; email: string | null; notes: string | null; sap?: string | null; status?: string | null; status_reason?: string | null; status_date?: string | null; region?: string | null; owner?: string | null }
export interface TurqMarket { country: string; continent: string; years: Record<number, number>; rev: number; prev: number; growth: number | null; share: number; active: number; newCustomers: number; distributor: string; hasDistributor: boolean; months: number[] | null }
export interface TurqData {
  ready: boolean; message?: string; year: number; scope: 'export' | 'all'; cut: string; yearsShown: number[]; reliableNew: boolean; monthlyAvailable: boolean;
  kpis: { revenue: number; prev: number; growth: number | null; growthBasis: string; markets: number; prevMarkets: number; active: number; newCustomers: number; distributorMarkets: number; coverage: number; withoutDistributor: number; ytdNote: boolean };
  markets: TurqMarket[]; newCustomers: { code: string; name: string; country: string; first: string; revenue: number }[];
  distributors: { id: number; name: string; country: string; sap: string; status: string; region: string; owner: string; revenue: number | null; revenuePrev: number | null; customers: number | null; matched: string }[];
  whiteSpace: { country: string; revenue: number; customers: number }[];
  notes: string[];
}

export function turqData(year: number | null, scope: 'export' | 'all'): TurqData {
  const empty: TurqData = { ready: false, year: year ?? 0, scope, cut: '', yearsShown: [], reliableNew: false, monthlyAvailable: false, kpis: { revenue: 0, prev: 0, growth: null, growthBasis: 'year', markets: 0, prevMarkets: 0, active: 0, newCustomers: 0, distributorMarkets: 0, coverage: 0, withoutDistributor: 0, ytdNote: false }, markets: [], newCustomers: [], distributors: [], whiteSpace: [], notes: [] };
  const cutRow = db.prepare('SELECT MAX(last_date) d, MIN(first_date) f FROM intel_cust').get() as { d: string | null; f: string | null };
  if (!cutRow.d) return { ...empty, message: 'There is no sales data yet. An admin opens Sales intelligence and loads the history.' };
  const cut = cutRow.d; const cy = +cut.slice(0, 4); const Y = year && year >= 2000 && year <= cy ? year : cy;
  const cm = countryMap();
  const cust = new Map((db.prepare('SELECT code, name, first_date, last_date FROM intel_cust').all() as { code: string; name: string; first_date: string; last_date: string }[]).map((r) => [r.code, r]));
  const inScope = (code: string) => { const n = cust.get(code)?.name ?? ''; if (GROUPCOS.test(n)) return false; return scope === 'all' || !code.startsWith('1201'); };
  const country = (code: string) => (code.startsWith('1201') && scope === 'all' ? 'Turkey' : cm.get(code)?.country || 'Not identified');
  const cmo = +cut.slice(5, 7); const ytdC = new Map<string, number>(), ytdP = new Map<string, number>(); // the closed months of this year and of the year before (a fair comparison while the year is running)
  const years = new Map<string, Record<number, number>>(); const monthly = new Map<string, number[]>(); const byCust = new Map<string, Record<number, number>>();
  const firstMonthly = (db.prepare("SELECT MIN(period) p FROM intel_fact WHERE period NOT LIKE '%-00'").get() as { p: string | null }).p ?? '9999-99';
  const monthlyAvailable = `${Y}-01` >= firstMonthly;
  for (const r of db.prepare('SELECT customer, period, SUM(eur) eur FROM intel_fact WHERE customer NOT IN (SELECT code FROM intel_excluded) GROUP BY customer, period').all() as { customer: string; period: string; eur: number }[]) {
    if (!inScope(r.customer)) continue;
    const y = +r.period.slice(0, 4), ctry = country(r.customer);
    const yo = years.get(ctry) ?? (years.set(ctry, {}).get(ctry)!); yo[y] = (yo[y] ?? 0) + r.eur;
    const co = byCust.get(r.customer) ?? (byCust.set(r.customer, {}).get(r.customer)!); co[y] = (co[y] ?? 0) + r.eur;
    if (Y === cy && !r.period.endsWith('-00') && +r.period.slice(5, 7) < cmo) { if (y === Y) ytdC.set(ctry, (ytdC.get(ctry) ?? 0) + r.eur); else if (y === Y - 1) ytdP.set(ctry, (ytdP.get(ctry) ?? 0) + r.eur); }
    if (y === Y && !r.period.endsWith('-00')) { const mo = monthly.get(ctry) ?? (monthly.set(ctry, Array(12).fill(0)).get(ctry)!); mo[+r.period.slice(5, 7) - 1] += r.eur; }
  }
  const dist = db.prepare('SELECT * FROM distributors ORDER BY country, name').all() as unknown as DistRow[];
  const dByCountry = new Map<string, DistRow[]>(); for (const d of dist) { const k = canonicalCountry(d.country) as string; (dByCountry.get(k) ?? dByCountry.set(k, []).get(k)!).push(d); }
  const activeD = (d: DistRow) => d.status !== 'passive';
  const yearsShown = [Y - 4, Y - 3, Y - 2, Y - 1, Y].filter((y) => y >= +(cutRow.f ?? '2019').slice(0, 4));
  const markets: TurqMarket[] = [];
  for (const [ctry, yo] of years) {
    const rev = yo[Y] ?? 0, prev = yo[Y - 1] ?? 0; if (rev <= 0 && prev <= 0) continue;
    let activeC = 0, newC = 0;
    for (const [code, co] of byCust) { if (country(code) !== ctry) continue; if ((co[Y] ?? 0) > 0) { activeC++; if ((cust.get(code)?.first_date ?? '').slice(0, 4) === String(Y)) newC++; } }
    const ds = (dByCountry.get(ctry) ?? []).filter(activeD);
    markets.push({ country: ctry, continent: continentOf(ctry), years: yo, rev, prev, growth: Y === cy ? ((ytdP.get(ctry) ?? 0) > 0 ? ((ytdC.get(ctry) ?? 0) - (ytdP.get(ctry) ?? 0)) / ytdP.get(ctry)! : null) : prev > 0 ? (rev - prev) / prev : null, share: 0, active: activeC, newCustomers: newC, distributor: ds.map((d) => d.name).join('; '), hasDistributor: ds.length > 0, months: monthlyAvailable ? monthly.get(ctry) ?? null : null });
  }
  markets.sort((a, b) => b.rev - a.rev);
  const total = markets.reduce((s, m) => s + m.rev, 0), prevTotal = markets.reduce((s, m) => s + m.prev, 0);
  for (const m of markets) m.share = total > 0 ? m.rev / total : 0;
  const nc: TurqData['newCustomers'] = [];
  for (const [code, co] of byCust) { const c = cust.get(code); if (!c || (co[Y] ?? 0) <= 0) continue; if (c.first_date.slice(0, 4) === String(Y)) nc.push({ code, name: c.name, country: country(code), first: c.first_date, revenue: Math.round(co[Y]) }); }
  nc.sort((a, b) => a.first.localeCompare(b.first));
  // distributors: their own sales (by SAP number, else by the same name)
  const nameIdx = new Map<string, string>(); for (const [code, c] of cust) nameIdx.set(normName(c.name), code);
  const dRows = dist.map((d) => {
    let code = (d.sap ?? '').trim(), matched = code ? 'SAP number' : '';
    if (!code) { const k = nameIdx.get(normName(d.name)); if (k) { code = k; matched = 'same name'; } }
    const co = code ? byCust.get(code) ?? null : null;
    return { id: d.id, name: d.name, country: d.country, sap: code, status: d.status === 'passive' ? 'Pasif' : 'Aktif', region: d.region ?? '', owner: d.owner || countryModel.findByCountry(d.country)?.responsible || '', revenue: co ? Math.round(co[Y] ?? 0) : null, revenuePrev: co ? Math.round(co[Y - 1] ?? 0) : null, customers: null as number | null, matched };
  });
  const withD = markets.filter((m) => m.hasDistributor && m.country !== 'Not identified');
  const noD = markets.filter((m) => !m.hasDistributor && m.rev > 0 && m.country !== 'Not identified' && m.country !== 'Turkey');
  const sumC = [...ytdC.values()].reduce((a, b) => a + b, 0), sumP = [...ytdP.values()].reduce((a, b) => a + b, 0);
  const exportTotal = markets.filter((m) => m.country !== 'Turkey').reduce((s, m) => s + m.rev, 0);
  const notes: string[] = [];
  if (Y === cy) notes.push(`${Y} is the year in progress: figures run until ${cut}. Growth compares the closed months of ${Y} with the same months of ${Y - 1}.`);
  if (+(cutRow.f ?? '2019').slice(0, 4) >= Y - 1) notes.push('The sales history starts in 2019: a customer first seen in the first year of the data cannot be told from an older one.');
  if (!monthlyAvailable) notes.push(`Monthly detail is kept for the last 38 months only; ${Y} is shown by year.`);
  if (markets.some((m) => m.country === 'Not identified' && m.rev > 0)) notes.push('Some accounts have no country yet: upload the SAP customer list in Sales intelligence or link them to a CRM card.');
  if (!dist.length) notes.push('No distributors are entered yet (Admin → Distributors).');
  return {
    ready: true, year: Y, scope, cut, yearsShown, reliableNew: Y > +(cutRow.f ?? '2019').slice(0, 4), monthlyAvailable,
    kpis: { revenue: Math.round(total), prev: Math.round(prevTotal), growth: Y === cy ? (sumP > 0 ? (sumC - sumP) / sumP : null) : prevTotal > 0 ? (total - prevTotal) / prevTotal : null, growthBasis: Y === cy ? `${cmo > 1 ? 'Jan–' + MONTHS_EN[cmo - 2] : ''}` : 'year', markets: markets.filter((m) => m.rev > 0 && m.country !== 'Not identified').length, prevMarkets: markets.filter((m) => m.prev > 0 && m.country !== 'Not identified').length, active: markets.reduce((s, m) => s + m.active, 0), newCustomers: nc.length, distributorMarkets: withD.filter((m) => m.rev > 0).length, coverage: exportTotal > 0 ? withD.filter((m) => m.country !== 'Turkey').reduce((s, m) => s + m.rev, 0) / exportTotal : 0, withoutDistributor: noD.length, ytdNote: Y === cy },
    markets, newCustomers: nc, distributors: dRows, whiteSpace: noD.map((m) => ({ country: m.country, revenue: Math.round(m.rev), customers: m.active })), notes,
  };
}

const MONTHS_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MONTHS_TR = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
export async function turqualityWorkbook(t: TurqData): Promise<Buffer> {
  const wb = new ExcelJS.Workbook(); wb.creator = 'TECE CRM';
  const scopeTr = t.scope === 'export' ? 'Yurtdışı' : 'Yurtiçi + Yurtdışı';
  // --- summary
  const s = wb.addWorksheet('Özet');
  s.columns = [{ width: 44 }, { width: 18 }, { width: 18 }, { width: 14 }];
  s.getCell('A1').value = `TECE – Turquality Raporu ${t.year}`; s.getCell('A1').font = { bold: true, size: 14, name: 'Arial' };
  s.getCell('A2').value = `Kapsam: ${scopeTr} · Net satış (EUR, SAP fatura) · Veri tarihi: ${t.cut}${t.kpis.ytdNote ? ' (yıl devam ediyor)' : ''}`; s.getCell('A2').font = { size: 10, name: 'Arial', italic: true };
  header(s, 4, ['Gösterge', String(t.year), String(t.year - 1), 'Değişim']);
  const rows: [string, number | string, number | string, number | null, string?][] = [
    ['Ciro (EUR)', t.kpis.revenue, t.kpis.prev, t.kpis.growth, EUR],
    ['Satış yapılan pazar (ülke) sayısı', t.kpis.markets, t.kpis.prevMarkets, t.kpis.prevMarkets ? (t.kpis.markets - t.kpis.prevMarkets) / t.kpis.prevMarkets : null, '0'],
    ['Alım yapan müşteri sayısı', t.kpis.active, '', null, '0'],
    ['Yeni müşteri sayısı', t.kpis.newCustomers, '', null, '0'],
    ['Distribütörü olan pazar sayısı', t.kpis.distributorMarkets, '', null, '0'],
    ['Distribütör kapsaması (yurtdışı cironun payı)', t.kpis.coverage, '', null, '0.0%'],
    ['Distribütörü olmayan pazar sayısı', t.kpis.withoutDistributor, '', null, '0'],
  ];
  rows.forEach((r, i) => { const row = s.getRow(5 + i); row.getCell(1).value = r[0]; row.getCell(2).value = r[1] as ExcelJS.CellValue; row.getCell(3).value = r[2] as ExcelJS.CellValue; row.getCell(4).value = r[3]; [1, 2, 3, 4].forEach((c) => { row.getCell(c).border = border; row.getCell(c).font = { size: 10, name: 'Arial' }; }); row.getCell(2).numFmt = r[4] ?? EUR; row.getCell(3).numFmt = r[4] ?? EUR; row.getCell(4).numFmt = PCT; });
  t.notes.forEach((n, i) => { const c = s.getCell(14 + i, 1); c.value = n; c.font = { size: 9, name: 'Arial', italic: true, color: { argb: 'FF666666' } }; });

  // --- market revenue
  const m = wb.addWorksheet('Pazar Cirosu');
  const ys = t.yearsShown;
  m.columns = [{ width: 24 }, { width: 14 }, ...ys.map(() => ({ width: 14 })), { width: 11 }, { width: 11 }, { width: 11 }, { width: 11 }, { width: 14 }, { width: 30 }];
  header(m, 1, ['Ülke', 'Kıta', ...ys.map(String), 'Pay %', 'Büyüme %', 'Müşteri', 'Yeni müşteri', 'Distribütör', 'Distribütör adı']);
  t.markets.forEach((x, i) => { const row = m.getRow(2 + i); row.values = [x.country, x.continent, ...ys.map((y) => Math.round(x.years[y] ?? 0)), x.share, x.growth, x.active, x.newCustomers, x.hasDistributor ? 'Var' : 'Yok', x.distributor]; });
  const tr = m.getRow(2 + t.markets.length); tr.values = ['TOPLAM', '', ...ys.map((y) => Math.round(t.markets.reduce((a, x) => a + (x.years[y] ?? 0), 0))), 1, t.kpis.growth, t.kpis.active, t.kpis.newCustomers, '', '']; tr.font = { bold: true, size: 10, name: 'Arial' };
  body(m, 2, ['@', '@', ...ys.map(() => EUR), PCT, PCT, '0', '0', '@', '@']); m.views = [{ state: 'frozen', xSplit: 1, ySplit: 1 }]; m.autoFilter = { from: 'A1', to: { row: 1 + t.markets.length, column: 8 + ys.length } };

  // --- monthly
  if (t.monthlyAvailable) {
    const mo = wb.addWorksheet('Aylık Pazar Cirosu');
    mo.columns = [{ width: 24 }, ...MONTHS_TR.map(() => ({ width: 12 })), { width: 14 }];
    header(mo, 1, ['Ülke', ...MONTHS_TR, 'Toplam']);
    t.markets.filter((x) => x.months).forEach((x, i) => { const row = mo.getRow(2 + i); const vals = x.months!.map((v) => Math.round(v)); row.values = [x.country, ...vals, vals.reduce((a, b) => a + b, 0)]; });
    body(mo, 2, ['@', ...MONTHS_TR.map(() => EUR), EUR]); mo.views = [{ state: 'frozen', xSplit: 1, ySplit: 1 }];
  }

  // --- new customers
  const n = wb.addWorksheet('Yeni Müşteriler');
  n.columns = [{ width: 14 }, { width: 44 }, { width: 22 }, { width: 14 }, { width: 14 }];
  header(n, 1, ['SAP Cari Kodu', 'Müşteri Adı', 'Ülke', 'İlk Fatura', `${t.year} Cirosu (EUR)`]);
  t.newCustomers.forEach((x, i) => { n.getRow(2 + i).values = [x.code, x.name, x.country, dateOf(x.first), x.revenue]; });
  body(n, 2, ['@', '@', '@', DATE, EUR]);
  if (!t.reliableNew) { const c = n.getCell(3 + t.newCustomers.length, 1); c.value = 'Not: Veri 2019 başlangıçlıdır; ilk yıldaki müşteriler eski müşterilerden ayırt edilemez.'; c.font = { italic: true, size: 9, name: 'Arial' }; }
  // new customers by country
  const byC = new Map<string, number>(); for (const x of t.newCustomers) byC.set(x.country, (byC.get(x.country) ?? 0) + 1);
  const nb = wb.addWorksheet('Yeni Müşteri - Ülke'); nb.columns = [{ width: 26 }, { width: 16 }];
  header(nb, 1, ['Ülke', 'Yeni müşteri sayısı']); [...byC].sort((a, b) => b[1] - a[1]).forEach(([k, v], i) => { nb.getRow(2 + i).values = [k, v]; }); body(nb, 2, ['@', '0']);

  // --- distributors
  const d = wb.addWorksheet('Distribütör Kapsaması');
  d.columns = [{ width: 34 }, { width: 22 }, { width: 14 }, { width: 10 }, { width: 18 }, { width: 22 }, { width: 16 }, { width: 16 }, { width: 14 }];
  header(d, 1, ['Distribütör', 'Ülke', 'SAP Cari Kodu', 'Durum', 'Sorumlu Bölge', 'TECE Sorumlusu', `${t.year} Alımı (EUR)`, `${t.year - 1} Alımı (EUR)`, 'Eşleşme']);
  t.distributors.forEach((x, i) => { d.getRow(2 + i).values = [x.name, x.country, x.sap, x.status, x.region, x.owner, x.revenue, x.revenuePrev, x.matched]; });
  body(d, 2, ['@', '@', '@', '@', '@', '@', EUR, EUR, '@']);
  const w0 = 4 + t.distributors.length;
  d.getCell(w0, 1).value = 'Distribütörü olmayan pazarlar (ciroya göre)'; d.getCell(w0, 1).font = { bold: true, size: 10, name: 'Arial' };
  header(d, w0 + 1, ['Ülke', 'Müşteri sayısı', `${t.year} Cirosu (EUR)`], 22);
  t.whiteSpace.forEach((x, i) => { const r = d.getRow(w0 + 2 + i); r.values = [x.country, x.customers, x.revenue]; [1, 2, 3].forEach((c) => { r.getCell(c).border = border; r.getCell(c).font = { size: 10, name: 'Arial' }; }); r.getCell(3).numFmt = EUR; });
  return toBuf(wb);
}

// ================= 3. targets and forecasts =================
export async function targetsWorkbook(o: Overview): Promise<Buffer> {
  const wb = new ExcelJS.Workbook(); wb.creator = 'TECE CRM';
  const ws = wb.addWorksheet('Hedef - Gerçekleşen');
  ws.columns = [{ width: 28 }, { width: 16 }, { width: 16 }, { width: 16 }, { width: 16 }, { width: 16 }, { width: 16 }];
  ws.getCell('A1').value = `Ciro hedefi ve tahmin – ${o.ym}`; ws.getCell('A1').font = { bold: true, size: 14, name: 'Arial' };
  ws.getCell('A2').value = `Veri tarihi: ${o.cut} · EUR (SAP fatura, net)`; ws.getCell('A2').font = { italic: true, size: 10, name: 'Arial' };
  header(ws, 4, ['Satış temsilcisi', 'Hedef', 'Gerçekleşen', 'Beklenen (ay sonu)', 'Fark (hedef - gerçekleşen)', 'Sistem tahmini', 'Satışçı tahmini']);
  let r = 5;
  if (o.company) { const c = o.company; ws.getRow(r).values = ['TOPLAM', c.target.amount, c.actual, c.expected.point, c.gap, c.sys, c.repForecasts || null]; ws.getRow(r).font = { bold: true, size: 10, name: 'Arial' }; r++; }
  for (const l of o.reps) { ws.getRow(r).values = [l.name, l.target, l.actual, l.expected.point, l.gap, l.sys, l.forecast?.amount ?? null]; r++; }
  body(ws, 5, ['@', EUR, EUR, EUR, EUR, EUR, EUR]);
  if (o.history.length) {
    const h = wb.addWorksheet('Tahmin Doğruluğu'); h.columns = [{ width: 12 }, { width: 16 }, { width: 16 }, { width: 18 }, { width: 16 }, { width: 14 }, { width: 14 }];
    header(h, 1, ['Ay', 'Hedef', 'Sistem tahmini', 'Satışçı tahminleri', 'Gerçekleşen', 'Sistem hata %', 'Satışçı hata %']);
    o.history.forEach((x, i) => { h.getRow(2 + i).values = [x.ym, x.target, x.sys, x.reps, x.actual, x.sys !== null && x.actual ? (x.sys - x.actual) / x.actual : null, x.reps !== null && x.actual ? (x.reps - x.actual) / x.actual : null]; });
    body(h, 2, ['@', EUR, EUR, EUR, EUR, PCT, PCT]);
  }
  return toBuf(wb);
}
