-- The smart clean-up: what was decided about a lead (remove, keep) and why, so nothing is asked twice and the AI is used only once for each company.
CREATE TABLE IF NOT EXISTS cleanup_suggestions (
  card_id INTEGER PRIMARY KEY,
  verdict TEXT NOT NULL,             -- remove | keep | unsure
  why TEXT,
  source TEXT NOT NULL,              -- rule | ai | person
  at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_cleanup_verdict ON cleanup_suggestions (verdict);
