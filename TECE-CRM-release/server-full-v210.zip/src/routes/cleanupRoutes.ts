import { Router } from 'express';
import { requireAdmin, requireAuth, type AuthedRequest } from '../middleware/auth';
import { needAi } from '../services/aiBudget';
import { dupInfo, markKeep, mergeSure, removeToJunk, scan, summary, suggestions } from '../services/smartCleanup';

// The admin's smart clean-up: duplicates and companies out of our league. Rules are free; the AI (optional) sees only the doubtful names, 60 per question.
const router = Router();
router.use(requireAuth, requireAdmin);

const ids = (v: unknown): number[] => (Array.isArray(v) ? v.map((n) => Math.trunc(Number(n))).filter((n) => Number.isFinite(n) && n > 0).slice(0, 2000) : []);

router.get('/summary', (_req, res) => res.json(summary()));

// a scan with the free rules only
router.post('/scan', async (_req, res) => {
  try { res.json({ ...(await scan({ ai: false, max: 0 })), ...summary() }); } catch (err) { console.error('Cleanup scan failed:', err); res.status(500).json({ error: 'The scan did not work.' }); }
});
// a scan where the AI also sees the doubtful ones (at most `max`, default 300 = 5 short questions)
router.post('/scan-ai', needAi, async (req, res) => {
  const max = Math.min(600, Math.max(60, Math.round(Number(req.body?.max) || 300)));
  try { res.json({ ...(await scan({ ai: true, max })), ...summary() }); } catch (err) { console.error('Cleanup AI scan failed:', err); res.status(500).json({ error: 'The scan did not work.' }); }
});

router.get('/suggestions', (req, res) => {
  const v = req.query.verdict === 'unsure' ? 'unsure' : req.query.verdict === 'keep' ? 'keep' : 'remove';
  res.json({ verdict: v, rows: suggestions(v) });
});
router.post('/remove', (req: AuthedRequest, res) => {
  const list = ids(req.body?.ids);
  if (!list.length) return res.status(400).json({ error: 'Nothing chosen.' });
  res.json({ ...removeToJunk(list, req.user!.id), ...summary() });
});
router.post('/keep', (req, res) => {
  const list = ids(req.body?.ids);
  if (!list.length) return res.status(400).json({ error: 'Nothing chosen.' });
  res.json({ kept: markKeep(list), ...summary() });
});

router.get('/duplicates', (req: AuthedRequest, res) => {
  try {
    const info = dupInfo(req.user!, 400);
    res.json({ sure: info.filter((i) => i.sure).length, groups: info });
  } catch (err) { console.error('Cleanup duplicates failed:', err); res.status(500).json({ error: 'Duplicates could not be listed.' }); }
});
router.post('/merge-sure', (req: AuthedRequest, res) => {
  try {
    const only = Array.isArray(req.body?.keys) ? req.body.keys.map(String) : undefined;
    res.json(mergeSure(req.user!, req.user!.id, only));
  } catch (err) { console.error('Cleanup merge failed:', err); res.status(500).json({ error: 'The merge did not work.' }); }
});

export default router;
