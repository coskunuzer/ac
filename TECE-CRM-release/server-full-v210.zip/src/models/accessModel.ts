import { db } from '../db/connection';
import { memoTablesBy } from '../db/dataVersion';

// Extra customers an admin lets somebody see, on top of their own country / city list.
export type AccessKind = 'market' | 'country' | 'city';
export const ACCESS_KINDS: AccessKind[] = ['market', 'country', 'city'];

export interface AccessGrant {
  kind: AccessKind;
  value: string;
}

const keptGrants = memoTablesBy(['user_access'], (userId: number) => db.prepare('SELECT kind, value FROM user_access WHERE user_id = ? ORDER BY kind, value').all(userId) as unknown as AccessGrant[]);

export const accessModel = {
  forUser(userId: number): AccessGrant[] {
    return keptGrants(userId).map((g) => ({ ...g }));
  },

  // Replaces everything granted to this person.
  replace(userId: number, grants: AccessGrant[]): AccessGrant[] {
    const clean = grants
      .filter((g) => ACCESS_KINDS.includes(g.kind) && typeof g.value === 'string' && g.value.trim())
      .map((g) => ({ kind: g.kind, value: g.value.trim().slice(0, 80) }))
      .filter((g) => g.kind !== 'market' || g.value === 'export' || g.value === 'domestic');
    db.exec('BEGIN');
    try {
      db.prepare('DELETE FROM user_access WHERE user_id = ?').run(userId);
      const ins = db.prepare('INSERT OR IGNORE INTO user_access (user_id, kind, value) VALUES (?, ?, ?)');
      for (const g of clean) ins.run(userId, g.kind, g.value);
      db.exec('COMMIT');
    } catch (err) {
      db.exec('ROLLBACK');
      throw err;
    }
    return this.forUser(userId);
  },

  addOne(userId: number, grant: AccessGrant): void {
    db.prepare('INSERT OR IGNORE INTO user_access (user_id, kind, value) VALUES (?, ?, ?)').run(userId, grant.kind, grant.value);
  },
};
