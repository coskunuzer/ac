import { db } from '../db/connection';
import { cardModel, type CardRow } from '../models/cardModel';
import { canSeeCard } from './visibility';
import { priceMarketFor } from './priceMarket';
import { activePriceBook } from './priceBook/store';
import { priceProforma, type ProformaData } from './proforma';
import { accountOfSapAny, usdPerEur } from './perfAnalytics';
import type { DocLine } from './customerPrices';
import { colorBySap } from './colorDb';

// Pricing and buying of the customers who keep their own prices (learned from their SAP proformas): what they pay against OUR STANDARD PRICE LIST, and what they buy.
// The standard price is today's price list at the same product, thickness and width. A proforma is an order placed, not a shipment: the SAP figures (sales this
// year, last year) come from the ledger.
export interface ProductRow { sap: string; description: string; thickness: number | null; m2: number; price: number; standard: number | null; diffPct: number | null }
// a simple view of what a customer buys: product (ABS, PVC ...) and plain or woodgrain, with what they pay against the standard
export interface GroupRow { product: string; style: 'Plain' | 'Woodgrain'; m2: number; price: number | null; standard: number | null; diffPct: number | null }
export interface PricingRow {
  cardId: number; customer: string; country: string; rep: string; currency: string; sap: string;
  docs: number; lines: number; m2: number; goods: number; standardGoods: number; coveredPct: number;
  indexPct: number | null;        // what they pay against the standard, in % (-12 = 12 % below the standard)
  effectivePct: number | null;    // the same with their usual general discount / increase added
  gap: number;                    // money: what they paid minus what the standard would have been (negative = below the standard)
  usualAdjPct: number; firstDoc: string | null; lastDoc: string | null;
  ytd: number | null; prevYear: number | null; yoy: number | null; lastInvoice: string | null; balance: number | null;
  monthly: { month: string; indexPct: number | null; m2: number }[];
  products: ProductRow[];
  groups: GroupRow[];
}
const r2 = (n: number) => Math.round(n * 100) / 100;
const styleCache = new Map<string, { product: string; style: 'Plain' | 'Woodgrain' }>();
// plain or woodgrain, from the colour database (categories 2 and 4 are wood); the product from the same row, or from the SAP ending
function styleOf(sap: string, description: string): { product: string; style: 'Plain' | 'Woodgrain' } {
  const hit = styleCache.get(sap);
  if (hit) return hit;
  let product = ''; let wood = false;
  try {
    const c = colorBySap(sap).color;
    if (c) { product = c.productType ?? ''; wood = c.categoryNo === 2 || c.categoryNo === 4 || /wood|ahşap|ahsap|oak|meşe|mese|ceviz|walnut|dekor/i.test(c.category ?? ''); }
  } catch { /* the colour database may be empty */ }
  if (!product) product = /^d{8}$/.test(sap) ? 'Veneer' : sap.endsWith('.012') ? 'PVC' : sap.endsWith('.042') ? 'ABS' : sap.endsWith('.023') ? 'Melamine' : 'Other';
  if (product === 'Melamin') product = 'Melamine';
  if (!wood && /wood|oak|walnut|ceviz|meşe/i.test(description)) wood = true;
  const r = { product, style: wood ? 'Woodgrain' as const : 'Plain' as const };
  styleCache.set(sap, r);
  return r;
}

export function pricingAnalysis(viewer: { id: number; role: string; display_name: string | null; market?: string }, onlyCard?: number): { rows: PricingRow[]; priceList: boolean; note: string } {
  const docs = db.prepare('SELECT d.*, c.id AS cid FROM customer_price_docs d JOIN cards c ON c.id = d.card_id ORDER BY d.card_id, COALESCE(d.doc_date, \'\'), d.proforma_no').all() as { card_id: number; proforma_no: string; doc_date: string | null; currency: string; adjust_pct: number; lines_json: string }[];
  const byCard = new Map<number, typeof docs>();
  for (const d of docs) (byCard.get(d.card_id) ?? byCard.set(d.card_id, []).get(d.card_id)!).push(d);
  const rows: PricingRow[] = [];
  let anyBook = false;
  for (const [cardId, list] of byCard) {
    if (onlyCard && cardId !== onlyCard) continue;
    const card = cardModel.findById(cardId) as CardRow | undefined;
    if (!card || !canSeeCard(viewer, card)) continue;
    const market = priceMarketFor(viewer, card.market);
    const book = market ? activePriceBook(market)?.book ?? null : null;
    if (book) anyBook = true;
    // one row per customer and currency (a customer rarely has both)
    const cur = new Map<string, typeof docs>();
    for (const d of list) (cur.get(d.currency) ?? cur.set(d.currency, []).get(d.currency)!).push(d);
    for (const [currency, cdocs] of cur) {
      let goods = 0; let covered = 0; let std = 0; let m2All = 0; let withAdj = 0; let linesN = 0;
      const prod = new Map<string, ProductRow & { w: number; wStd: number }>();
      const grp = new Map<string, { product: string; style: 'Plain' | 'Woodgrain'; m2: number; a: number; s: number; cm2: number }>();
      const months = new Map<string, { a: number; s: number; m2: number }>();
      for (const d of cdocs) {
        const lines = JSON.parse(d.lines_json) as DocLine[];
        const data: ProformaData = {
          header: { name: '', company: '', address: '', tel: '', email: '', sapNumber: '', preparedBy: '', date: d.doc_date ?? '', reference: '', deliveryTerm: '', paymentTerm: '', dispatchTime: '', notes: '' },
          currency: currency === 'USD' ? 'USD' : 'EUR', usdRate: usdPerEur(), transportPct: 0, useMemory: false,
          lines: lines.map((l) => ({ code: l.reference, description: l.description, sap: l.sap, meters: l.meters, thickness: l.thickness, width: l.width, rollLength: l.rollLength })),
        };
        const priced = priceProforma(data, book).lines;
        lines.forEach((l, i) => {
          const m2 = l.meters && l.width ? (l.meters * l.width) / 1000 : 0;
          if (m2 <= 0) return;
          linesN += 1; m2All += m2; goods += l.priceM2 * m2;
          const list = priced[i]?.listPriceM2 ?? null;
          const key = l.sap;
          const p = prod.get(key) ?? { sap: l.sap, description: l.description, thickness: l.thickness, m2: 0, price: l.priceM2, standard: list, diffPct: null, w: 0, wStd: 0 };
          const sg = styleOf(l.sap, l.description); const gk = `${sg.product}|${sg.style}`;
          const g = grp.get(gk) ?? { ...sg, m2: 0, a: 0, s: 0, cm2: 0 };
          g.m2 += m2; g.a += l.priceM2 * m2; if (list) { g.s += list * m2; g.cm2 += m2; } grp.set(gk, g);
          p.m2 += m2; p.price = l.priceM2; p.standard = list ?? p.standard; prod.set(key, p);
          if (list) {
            covered += l.priceM2 * m2; std += list * m2; withAdj += l.priceM2 * m2 * (1 + d.adjust_pct / 100);
            p.w += l.priceM2 * m2; p.wStd += list * m2;
            const mo = (d.doc_date ?? '').slice(0, 7);
            if (mo) { const x = months.get(mo) ?? { a: 0, s: 0, m2: 0 }; x.a += l.priceM2 * m2; x.s += list * m2; x.m2 += m2; months.set(mo, x); }
          }
        });
      }
      const acc = card.sap ? accountOfSapAny(card.sap.trim()) : null;
      const adjs = cdocs.map((d) => d.adjust_pct).filter((x) => x !== 0);
      rows.push({
        cardId, customer: card.company || card.name || `#${cardId}`, country: (card.market === 'domestic' ? card.city : card.country) ?? '', rep: card.person ?? '', currency, sap: card.sap ?? '',
        docs: cdocs.length, lines: linesN, m2: r2(m2All), goods: r2(goods), standardGoods: r2(std), coveredPct: goods > 0 ? Math.round((covered / goods) * 100) : 0,
        indexPct: std > 0 ? r2((covered / std - 1) * 100) : null, effectivePct: std > 0 ? r2((withAdj / std - 1) * 100) : null, gap: r2(covered - std),
        usualAdjPct: adjs.length ? adjs[adjs.length - 1] : 0, firstDoc: cdocs[0]?.doc_date ?? null, lastDoc: cdocs[cdocs.length - 1]?.doc_date ?? null,
        ytd: acc ? r2(acc.ytd) : null, prevYear: acc ? r2(acc.prevYear) : null, yoy: acc?.yoy ?? null, lastInvoice: acc?.lastInvoice ?? null, balance: acc ? r2(acc.balance) : null,
        monthly: [...months].sort(([a], [b]) => a.localeCompare(b)).map(([month, x]) => ({ month, indexPct: x.s > 0 ? r2((x.a / x.s - 1) * 100) : null, m2: r2(x.m2) })),
        groups: [...grp.values()].sort((a, b) => b.m2 - a.m2).map((g) => ({ product: g.product, style: g.style, m2: r2(g.m2), price: g.m2 > 0 ? r2(g.a / g.m2) : null, standard: g.cm2 > 0 ? r2(g.s / g.cm2) : null, diffPct: g.s > 0 ? r2(((g.a * (g.cm2 / g.m2)) / g.s - 1) * 100) : null })),
        products: [...prod.values()].map((p) => ({ sap: p.sap, description: p.description, thickness: p.thickness, m2: r2(p.m2), price: p.price, standard: p.standard === null ? null : r2(p.standard), diffPct: p.wStd > 0 ? r2((p.w / p.wStd - 1) * 100) : null })).sort((a, b) => b.m2 - a.m2).slice(0, 30),
      });
    }
  }
  rows.sort((a, b) => (a.indexPct ?? 999) - (b.indexPct ?? 999));
  return { rows, priceList: anyBook, note: 'The standard price is today’s price list for the same product, thickness and width.' };
}

// What this customer pays today against the standard price list, as the percentages the OFFER starts from: one for every product page (ABS, PVC ...) and one overall.
// The customer's usual general discount / increase is included. Only for a customer whose SAP proformas were uploaded; everybody else is priced as always.
const SHEETS_OF: Record<string, string[]> = { PVC: ['PVC M2+22'], ABS: ['ABS M2+22'], PP: ['PP M2+22', 'PP M2'], Melamine: ['Melamine'], Veneer: ['Veneer'] };
export interface OfferMemory { currency: string; overall: number | null; pagePct: Record<string, number>; parts: { product: string; pct: number }[] }
export function offerMemoryFor(viewer: { id: number; role: string; display_name: string | null; market?: string }, cardId: number, currency?: string | null): OfferMemory | null {
  const rows = pricingAnalysis(viewer, cardId).rows.filter((r) => r.cardId === cardId);
  const row = rows.find((r) => r.currency === currency) ?? rows[0];
  if (!row) return null;
  const adj = 1 + row.usualAdjPct / 100;
  const byProduct = new Map<string, { m2: number; w: number }>();
  for (const g of row.groups) { if (g.diffPct === null) continue; const x = byProduct.get(g.product) ?? { m2: 0, w: 0 }; x.m2 += g.m2; x.w += g.diffPct * g.m2; byProduct.set(g.product, x); }
  const pagePct: Record<string, number> = {}; const parts: { product: string; pct: number }[] = [];
  for (const [product, x] of byProduct) {
    if (x.m2 <= 0) continue;
    const pct = Math.round(((1 + x.w / x.m2 / 100) * adj - 1) * 1000) / 1000;
    parts.push({ product, pct });
    for (const sheet of SHEETS_OF[product] ?? []) pagePct[sheet] = pct;
  }
  const overall = row.indexPct === null ? null : Math.round(((1 + row.indexPct / 100) * adj - 1) * 1000) / 1000;
  return parts.length || overall !== null ? { currency: row.currency, overall, pagePct, parts } : null;
}
