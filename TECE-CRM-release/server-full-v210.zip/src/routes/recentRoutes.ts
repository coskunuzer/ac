import { Router } from 'express';
import { db } from '../db/connection';
import { requireAuth, type AuthedRequest } from '../middleware/auth';

const router = Router();
router.use(requireAuth);

// My latest 10 activities. "all" (Home): notes, calls, visits, meetings, samples, e-mails and everything sent. "sends" (Mission page): what went out -
// price lists / offers, proformas and other documents, e-mails - and the calls.
const TYPES = {
  all: ['note', 'call', 'visit', 'meeting', 'sample', 'offer', 'thank_you', 'documents', 'email'],
  sends: ['offer', 'documents', 'email', 'thank_you', 'call'],
} as const;

router.get('/', (req: AuthedRequest, res) => {
  const kind = req.query.kind === 'sends' ? 'sends' : 'all';
  const list = TYPES[kind];
  const rows = db
    .prepare(
      `SELECT a.id, a.type, a.text, a.created_at, a.card_id, c.company, c.name
       FROM activities a LEFT JOIN cards c ON c.id = a.card_id
       WHERE a.user_id = ? AND a.imported = 0 AND a.type IN (${list.map(() => '?').join(',')})
       ORDER BY a.id DESC LIMIT 10`
    )
    .all(req.user!.id, ...list) as { id: number; type: string; text: string | null; created_at: string; card_id: number | null; company: string | null; name: string | null }[];
  res.json(rows.map((r) => ({ id: r.id, type: r.type, text: r.text, at: r.created_at, cardId: r.card_id, customer: r.company || r.name || null })));
});

export default router;
