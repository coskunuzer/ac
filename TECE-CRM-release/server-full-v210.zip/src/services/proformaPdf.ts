import path from 'path';
import ExcelJS from 'exceljs';
import PDFDocument from 'pdfkit';
import type { PriceBook } from './priceBook';
import { drawLogo, registerDesignFonts } from './priceBook/designed';
import { registerSheetFonts } from './priceBook/sheetPrint';
import { OTHER_PRODUCTS, priceProforma, type PricedLine, type PricedProforma, type ProformaData } from './proforma';

export type ProformaStyle = 'tece' | 'standard';

const NAVY = '#17243E';
const RED = '#8B1931';
const STEEL = '#5E6676';
const MIST = '#F3F4F7';
const SMOKE = '#E3E6EC';

const FALLBACK_TERMS = ['Tolerance in total amount and total quantity + 10% / - 10%', 'All the goods are of Turkish origin.'];
const FALLBACK_BANK_EUR = ['Account : TECE DEKOR A.S.', 'Bank : ZIRAAT BANKASI A.S.', 'Branch : BEŞEVLER SANAYİ (BRANCH CODE: 1921)', 'IBAN NO : TR93 0001 0019 2155 1631 9650 11', 'Account Number : 55163196-5011', 'SWIFT : TCZBTR2A'];
const FALLBACK_BANK_USD = ['Account : TECE DEKOR A.S.', 'Bank : ZIRAAT BANKASI A.S.', 'Branch : BEŞEVLER SANAYİ (BRANCH CODE: 1921)', 'IBAN NO : TR66 0001 0019 2155 1631 9650 12', 'Account Number : 55163196-5012', 'SWIFT : TCZBTR2A'];

// The bank block, always in this order: Account, Account Number, IBAN, VAT No, Beneficiary address (2 lines), Bank, Branch, SWIFT.
// Whatever the price workbook says for a line is kept; the VAT number and the beneficiary address are added.
function withBankExtras(lines: string[]): string[] {
  const find = (re: RegExp) => lines.find((l) => re.test(l.trim()));
  const ordered = [
    find(/^Account\s*:/i) ?? 'Account : TECE DEKOR A.S.',
    find(/^Account\s*Number\s*:/i),
    find(/^IBAN/i),
    'VAT No : 8330424495',
    'Beneficiary address : BOSB 75. Yil Bulv. No:12,',
    '                                      Nilufer, Bursa, 16140 Türkiye',
    find(/^Bank\s*:/i),
    find(/^Branch\s*:/i),
    find(/^SWIFT/i),
  ].filter((x): x is string => !!x);
  // any other line the workbook has stays, at the end
  const used = new Set(ordered.map((x) => x.trim()));
  const rest = lines.filter((l) => !used.has(l.trim()) && !/^(VAT\s*No|Beneficiary address)/i.test(l.trim()) && !/^Nilufer/i.test(l.trim()));
  return [...ordered, ...rest];
}

// European number style (1.234,56), like the price offers.
const eu = (n: number | null, d = 2) => (n === null ? '' : n.toLocaleString('de-DE', { minimumFractionDigits: d, maximumFractionDigits: d }));
const GROUP_TITLE: Record<string, string> = { PVC: 'PVC EDGEBANDING', ABS: 'ABS EDGEBANDING', PP: 'PP EDGEBANDING', Veneer: 'WOOD VENEER EDGEBANDING', Melamine: 'MELAMINE EDGEBANDING', Metal: 'ALUMINIUM / METAL EDGEBANDING', Acrylic: 'ACRYLIC / 3D EDGEBANDING', other: 'OTHER PRODUCTS' };
// the name and the kind of a line that is not a colour of the database (veneer, melamine ...): what the person typed
const nameOf = (l: PricedLine) => l.found?.boardCode ?? l.ownName ?? l.description ?? '';
const kindOf = (l: PricedLine) => l.found?.swatch ?? (l.ownName && l.otherProduct && l.otherProduct !== 'Other' ? (OTHER_PRODUCTS.find((p) => p.key === l.otherProduct)?.label ?? l.otherProduct) : '');

interface Col { key: string; title: string; w: number; align: 'left' | 'right'; value: (l: PricedLine) => string }

const COLUMNS = (sym: string): Col[] => [
  // a line with its own name: the name is not printed twice when it was typed in the customer code field
  { key: 'code', title: 'Customer Code', w: 76, align: 'left', value: (l) => (l.ownName && l.ownName === (l.code ?? '').trim() ? '' : l.code || '') },
  { key: 'name', title: 'Color Name', w: 84, align: 'left', value: nameOf },
  { key: 'desc', title: 'Description', w: 62, align: 'left', value: kindOf },
  { key: 'surf', title: 'Surface', w: 40, align: 'left', value: (l) => l.found?.surface ?? '' },
  { key: 'sap', title: 'TECE SAP Code', w: 56, align: 'left', value: (l) => l.found?.sap ?? l.sap },
  { key: 'm', title: 'Order in Meters', w: 46, align: 'right', value: (l) => eu(l.meters, 0) },
  { key: 't', title: 'Thickness', w: 38, align: 'right', value: (l) => (l.thickness === null ? '' : `${eu(l.thickness, 2)} mm`) },
  { key: 'w', title: 'Width', w: 32, align: 'right', value: (l) => (l.width === null ? '' : `${eu(l.width, 0)} mm`) },
  { key: 'rl', title: 'Roll Length', w: 36, align: 'right', value: (l) => (l.rollLength === null ? '' : `${eu(l.rollLength, 0)} mt`) },
  { key: 'pb', title: '# of roll in box', w: 34, align: 'right', value: (l) => (l.perBox === null ? '' : String(l.perBox)) },
  { key: 'm2', title: 'Order in m²', w: 40, align: 'right', value: (l) => (l.m2 === null ? '' : `${eu(l.m2, 0)} m²`) },
  { key: 'rb', title: 'Order in Rolls & Box', w: 56, align: 'right', value: (l) => (l.rolls === null ? '' : `${l.rolls} rolls${l.boxes !== null ? ` | ${l.boxes} box` : ''}`) },
  { key: 'pm2', title: `Price for m² (${sym})`, w: 44, align: 'right', value: (l) => eu(l.priceM2, 2) },
  { key: 'pmt', title: `Price for Mt (${sym})`, w: 44, align: 'right', value: (l) => eu(l.priceMt, 3) },
  { key: 'tot', title: `Total Prices (${sym})`, w: 56, align: 'right', value: (l) => eu(l.total, 2) },
  { key: 'wt', title: 'Weight', w: 38, align: 'right', value: (l) => (l.weight === null ? '' : `${eu(l.weight, 0)} kg`) },
];

const groupOf = (l: PricedLine) => l.product ?? (l.otherProduct && GROUP_TITLE[l.otherProduct] ? l.otherProduct : 'other');

// The proforma as a PDF. 'tece' is the new design (the TECE navy band and Montserrat); 'standard' is the plain layout of the Excel Proforma tab.
export async function renderProformaPdf(data: ProformaData, book: PriceBook | null, style: ProformaStyle): Promise<Buffer> {
  const priced = priceProforma(data, book);
  const texts = book?.proformaTexts() ?? null;
  const sym = data.currency === 'USD' ? '$' : '€';
  const tece = style === 'tece';
  const doc = new PDFDocument({ size: 'A4', layout: 'landscape', margin: 0, autoFirstPage: false, info: { Title: 'TECE proforma invoice', Author: 'tece' } });
  const chunks: Buffer[] = [];
  doc.on('data', (c: Buffer) => chunks.push(c));
  const done = new Promise<Buffer>((resolve, reject) => { doc.on('end', () => resolve(Buffer.concat(chunks))); doc.on('error', reject); });
  if (tece) registerDesignFonts(doc);
  else registerSheetFonts(doc);
  const F = tece ? { r: 'TD-400', b: 'TD-600', h: 'TD-700' } : { r: 'Sheet-Regular', b: 'Sheet-Bold', h: 'Sheet-Bold' };

  const PW = 841.89;
  const PH = 595.28;
  const L = 28;
  const CW = PW - 2 * L;
  const cols = COLUMNS(sym);
  const scale = CW / cols.reduce((s, c) => s + c.w, 0);
  const xs: number[] = [];
  let acc = L;
  for (const c of cols) { xs.push(acc); acc += c.w * scale; }
  const BAND = tece ? 50 : 0;
  const BOTTOM = PH - 34;
  const RH = 15;
  const FS = tece ? 7 : 7.6;

  const page = () => {
    doc.addPage();
    if (tece) {
      doc.rect(0, 0, PW, BAND).fill(NAVY);
      drawLogo(doc, 'TECE_SloganliLogo_Beyaz_RGB.svg', L, (BAND - 220 * (522 / 5990)) / 2, 220);
      doc.rect(0, BAND, PW, 2.5).fill(RED);
      doc.font(F.h).fontSize(15).fillColor('#FFFFFF').text('PROFORMA INVOICE', L, 17, { width: CW, align: 'right', lineBreak: false });
    } else {
      doc.font(F.h).fontSize(20).fillColor('#000000').text('PROFORMA INVOICE', L, 22, { width: CW, lineBreak: false });
    }
    return BAND + (tece ? 16 : 52);
  };

  const cell = (text: string, x: number, y: number, w: number, align: 'left' | 'right', font: string, color: string) => {
    doc.font(font).fontSize(FS).fillColor(color).text(text, x + 2.5, y + 4, { width: w - 5, height: RH - 4, align, ellipsis: true, lineBreak: false });
  };

  const header = (y: number): number => {
    const h = RH * 2.1;
    cols.forEach((c, i) => {
      const w = c.w * scale;
      doc.rect(xs[i], y, w, h).fill(tece ? NAVY : '#1F4E79');
      doc.font(F.b).fontSize(6.6).fillColor('#FFFFFF').text(c.title, xs[i] + 2.5, y + 4, { width: w - 5, height: h - 6, align: c.align === 'right' ? 'center' : 'left', lineBreak: true });
    });
    return y + h;
  };

  // the customer and the offer details
  let y = page();
  const h = data.header;
  const left = [h.company || h.name, h.company && h.name ? h.name : '', ...h.address.split('\n'), h.tel ? `Tel: ${h.tel}` : '', h.email ? `Email: ${h.email}` : ''].filter((s) => s && s.trim());
  doc.font(F.b).fontSize(8).fillColor(tece ? RED : '#000000').text('>> Customer Details:', L, y, { lineBreak: false });
  doc.font(F.r).fontSize(8.5).fillColor('#222222');
  left.slice(0, 7).forEach((t, i) => doc.font(i === 0 ? F.b : F.r).text(t, L, y + 12 + i * 10.5, { width: 400, lineBreak: false, ellipsis: true }));
  const rx = PW - L - 260;
  doc.font(F.b).fontSize(8).fillColor(tece ? RED : '#000000').text('>> Offer Details:', rx, y, { lineBreak: false });
  const right: [string, string][] = [['Date', h.date], ['Prepared By', h.preparedBy], ['Currency', data.currency === 'USD' ? '$ - USD' : '€ - EUR'], ['SAP customer no.', h.sapNumber], ['Order reference no.', h.reference]];
  right.filter(([, v]) => v).forEach(([k, v], i) => {
    doc.font(F.r).fontSize(8.5).fillColor(STEEL).text(k, rx, y + 12 + i * 10.5, { width: 90, lineBreak: false });
    doc.font(F.b).fillColor('#222222').text(v, rx + 92, y + 12 + i * 10.5, { width: 168, lineBreak: false, ellipsis: true });
  });
  y += 12 + Math.max(left.slice(0, 7).length, right.filter(([, v]) => v).length) * 10.5 + 10;
  y = header(y);

  let band = false;
  let lastGroup = '';
  const newPage = () => { y = header(page()); };
  for (const l of priced.lines) {
    const g = groupOf(l);
    if (g !== lastGroup) {
      if (y + RH * 2 > BOTTOM) newPage();
      doc.rect(L, y, CW, RH).fill(tece ? SMOKE : '#D9D9D9');
      doc.font(F.h).fontSize(FS + 0.4).fillColor('#000000').text(GROUP_TITLE[g], L + 3, y + 4, { lineBreak: false });
      y += RH;
      lastGroup = g;
      band = false;
    }
    if (y + RH > BOTTOM) { newPage(); }
    if (band) doc.rect(L, y, CW, RH).fill(tece ? MIST : '#F2F2F2');
    band = !band;
    cols.forEach((c, i) => {
      const missing = (c.key === 'pm2' || c.key === 'tot') && l.priceM2 === null;
      cell(missing ? 'no price' : c.value(l), xs[i], y, c.w * scale, c.align, c.key === 'tot' ? F.b : F.r, missing ? RED : '#111111');
    });
    doc.moveTo(L, y + RH).lineTo(L + CW, y + RH).lineWidth(0.3).strokeColor(SMOKE).stroke();
    y += RH;
  }

  // totals
  if (y + 40 > BOTTOM) newPage();
  const t = priced.totals;
  doc.rect(L, y, CW, RH + 2).fill(tece ? NAVY : '#1F4E79');
  const put = (key: string, text: string) => { const i = cols.findIndex((c) => c.key === key); cell(text, xs[i], y + 1, cols[i].w * scale, 'right', F.b, '#FFFFFF'); };
  doc.font(F.b).fontSize(FS).fillColor('#FFFFFF').text('Totals:', L + 3, y + 5, { lineBreak: false });
  put('m', eu(t.meters, 0));
  put('m2', `${eu(t.m2, 0)} m²`);
  put('rb', `${t.rolls} rolls | ${t.boxes} box`);
  put('tot', `${sym} ${eu(t.amount, 2)}`);
  put('wt', `${eu(t.weight, 0)} kg`);
  y += RH + 4;
  // a discount or an addition at the bottom, then what the customer pays
  if (t.adjustments.length) {
    const labelW = cols.slice(0, 12).reduce((s, c) => s + c.w * scale, 0);
    const amountX = xs[12];
    const amountW = cols[12].w * scale + cols[13].w * scale;
    for (const a of t.adjustments) {
      if (y + RH * 3 > BOTTOM) newPage();
      doc.font(F.r).fontSize(FS + 0.4).fillColor(a.amount < 0 ? RED : '#222222').text(a.label, L, y + 4, { width: labelW - 6, align: 'right', lineBreak: false, ellipsis: true });
      doc.font(F.b).text(`${a.amount > 0 ? '+' : ''}${eu(a.amount, 2)} ${sym}`, amountX, y + 4, { width: amountW - 4, align: 'right', lineBreak: false });
      y += RH - 2;
    }
    doc.rect(L, y, CW, RH + 2).fill(tece ? RED : '#1F4E79');
    doc.font(F.h).fontSize(FS + 1).fillColor('#FFFFFF').text('Total to pay', L + 3, y + 5, { lineBreak: false });
    doc.text(`${sym} ${eu(t.grand, 2)}`, amountX, y + 5, { width: amountW - 4, align: 'right', lineBreak: false });
    y += RH + 2;
  }
  y += 8;

  // terms and bank details
  const terms = [
    ...(texts?.terms.filter((s) => !s.startsWith('>>') && !/^to confirm/i.test(s)) ?? FALLBACK_TERMS),
  ];
  const bank = withBankExtras(data.currency === 'USD' ? texts?.bankUsd.length ? texts.bankUsd : FALLBACK_BANK_USD : texts?.bankEur.length ? texts.bankEur : FALLBACK_BANK_EUR);
  const termLines: [string, string][] = [['Delivery Term:', data.header.deliveryTerm], ['Payment Term:', data.header.paymentTerm], ['Dispatch Time:', data.header.dispatchTime]];
  const need = 14 + Math.max(termLines.length + terms.length + (h.notes ? 2 : 0), bank.length + 1) * 10.5 + 40;
  if (y + need > BOTTOM + 20) y = page();
  doc.font(F.b).fontSize(8).fillColor(tece ? RED : '#000000').text('>> Terms and Conditions:', L, y, { lineBreak: false });
  let ty = y + 12;
  for (const [k, v] of termLines) {
    if (!v) continue;
    doc.font(F.b).fontSize(8).fillColor('#222222').text(k, L, ty, { width: 80, lineBreak: false });
    doc.font(F.r).text(v, L + 82, ty, { width: 380, lineBreak: false, ellipsis: true });
    ty += 10.5;
  }
  for (const s of terms) { doc.font(F.r).fontSize(8).fillColor('#222222').text(s, L, ty, { width: 460, lineBreak: false, ellipsis: true }); ty += 10.5; }
  if (h.notes) { doc.font(F.r).fontSize(8).fillColor('#222222').text(h.notes, L, ty + 3, { width: 460 }); }
  const bx = L + 500;
  doc.font(F.b).fontSize(8).fillColor(tece ? RED : '#000000').text(`>> Bank Details for ${data.currency === 'USD' ? 'USD' : 'Euro'}:`, bx, y, { lineBreak: false });
  bank.forEach((b, i) => doc.font(F.r).fontSize(8).fillColor('#222222').text(b, bx, y + 12 + i * 10.5, { width: PW - L - bx, lineBreak: false, ellipsis: true }));
  const sy = y + 12 + Math.max(ty - y - 12, bank.length * 10.5) + 18;
  if (sy + 30 < PH - 10) {
    doc.font(F.b).fontSize(8).fillColor(tece ? RED : '#000000').text('>> Customer Signature:', L, sy, { lineBreak: false });
    doc.font(F.r).fillColor('#222222').text('To confirm this order, please sign below and send PI back:', L, sy + 12, { lineBreak: false });
    doc.moveTo(L, sy + 38).lineTo(L + 220, sy + 38).lineWidth(0.5).strokeColor('#888888').stroke();
  }
  doc.end();
  return done;
}

// The proforma as Excel: the "Proforma" sheet as in the template, and a "SAP order" sheet in the layout of the SAP order upload.
export async function renderProformaXlsx(data: ProformaData, book: PriceBook | null): Promise<Buffer> {
  const priced: PricedProforma = priceProforma(data, book);
  const sym = data.currency === 'USD' ? '$' : '€';
  const wb = new ExcelJS.Workbook();
  wb.creator = 'TECE CRM';
  const ws = wb.addWorksheet('Proforma', { views: [{ state: 'frozen', ySplit: 11 }] });
  const h = data.header;
  ws.getCell('A1').value = 'PROFORMA INVOICE';
  ws.getCell('A1').font = { bold: true, size: 18 };
  ws.getCell('A3').value = '>> Customer Details:';
  ws.getCell('A3').font = { bold: true };
  [h.company || h.name, h.company && h.name ? h.name : '', ...h.address.split('\n'), h.tel ? `Tel: ${h.tel}` : '', h.email ? `Email: ${h.email}` : ''].filter(Boolean).slice(0, 6).forEach((t, i) => (ws.getCell(`A${4 + i}`).value = t));
  ws.getCell('J3').value = '>> Offer Details:';
  ws.getCell('J3').font = { bold: true };
  ([['Date', h.date], ['Prepared By', h.preparedBy], ['Currency', data.currency], ['SAP customer no.', h.sapNumber], ['Order reference no.', h.reference]] as [string, string][]).filter(([, v]) => v).forEach(([k, v], i) => { ws.getCell(`J${4 + i}`).value = k; ws.getCell(`K${4 + i}`).value = v; });
  const heads = ['Customer Code', 'Color Name', 'Description', 'Surface', 'TECE SAP Code', 'Order in Meters', 'Thickness (mm)', 'Width (mm)', 'Roll Length (mt)', '# of roll in box', 'Order in m²', 'Order in Rolls', 'Order in Boxes', `Price for m² (${sym})`, `Price for Mt (${sym})`, `Total Prices (${sym})`, 'Weight (kg)'];
  const hr = ws.getRow(11);
  heads.forEach((t, i) => {
    const c = hr.getCell(i + 1);
    c.value = t;
    c.font = { bold: true, color: { argb: 'FFFFFFFF' } };
    c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1F4E79' } };
    c.alignment = { wrapText: true, vertical: 'middle', horizontal: 'center' };
  });
  hr.height = 32;
  let r = 12;
  let group = '';
  const first = r + 1;
  for (const l of priced.lines) {
    const g = groupOf(l);
    if (g !== group) { ws.getCell(`A${r}`).value = GROUP_TITLE[g]; ws.getCell(`A${r}`).font = { bold: true }; r++; group = g; }
    const row = ws.getRow(r);
    row.values = [l.ownName && l.ownName === (l.code ?? '').trim() ? '' : l.code, nameOf(l), kindOf(l), l.found?.surface ?? '', l.found?.sap ?? l.sap, l.meters, l.thickness, l.width, l.rollLength, l.perBox, null, l.rolls, l.boxes, l.priceM2, null, null, null];
    // the same formulas as the template's Proforma tab
    row.getCell(11).value = { formula: `F${r}*(H${r}/1000)`, result: l.m2 ?? undefined };
    row.getCell(15).value = { formula: `IF(N${r}="","",N${r}*H${r}/1000)`, result: l.priceMt ?? undefined };
    row.getCell(16).value = { formula: `IF(N${r}="","",K${r}*N${r})`, result: l.total ?? undefined };
    row.getCell(17).value = { formula: `K${r}*G${r}*${OTHER_PRODUCTS.find((p) => p.key === l.otherProduct)?.density ?? 1.1}`, result: l.weight ?? undefined };
    r++;
  }
  const last = r - 1;
  ws.getCell(`B${r + 1}`).value = 'Totals:';
  ws.getCell(`B${r + 1}`).font = { bold: true };
  for (const [col, f] of [['F', 'SUM'], ['K', 'SUM'], ['L', 'SUM'], ['M', 'SUM'], ['P', 'SUM'], ['Q', 'SUM']] as [string, string][]) {
    ws.getCell(`${col}${r + 1}`).value = { formula: `${f}(${col}${first}:${col}${last})` };
    ws.getCell(`${col}${r + 1}`).font = { bold: true };
  }
  ws.getCell(`O${r + 1}`).value = 'Total Price:';
  ws.getCell(`O${r + 1}`).font = { bold: true };
  // a discount or an addition at the bottom (a percentage of the goods is calculated by the formula, so it follows when a price is changed in Excel)
  let sr = r + 2;
  const adjRows: number[] = [];
  for (const a of (data.adjustments ?? []).filter((x) => x && Number(x.value))) {
    const pct = a.mode === 'percent';
    ws.getCell(`O${sr}`).value = pct ? `${a.label || (a.value < 0 ? 'Discount' : 'Addition')} (${a.value > 0 ? '+' : ''}${a.value} %)` : a.label || (a.value < 0 ? 'Discount' : 'Addition');
    ws.getCell(`P${sr}`).value = pct ? { formula: `P${r + 1}*${a.value}/100` } : a.value;
    adjRows.push(sr);
    sr++;
  }
  if (adjRows.length) {
    ws.getCell(`O${sr}`).value = 'Total to pay:';
    ws.getCell(`O${sr}`).font = { bold: true };
    ws.getCell(`P${sr}`).value = { formula: `P${r + 1}+${adjRows.map((x) => `P${x}`).join('+')}`, result: priced.totals.grand };
    ws.getCell(`P${sr}`).font = { bold: true };
    r = sr; // the terms start below
  }
  [16, 30, 24, 14, 16, 12, 11, 10, 12, 10, 11, 11, 11, 13, 13, 15, 11].forEach((w, i) => (ws.getColumn(i + 1).width = w));
  for (const col of [6, 12, 13]) ws.getColumn(col).numFmt = '#,##0';
  for (const col of [11, 17]) ws.getColumn(col).numFmt = '#,##0.0';
  for (const col of [14, 15, 16]) ws.getColumn(col).numFmt = '#,##0.00';
  let tr = r + 4;
  ws.getCell(`A${tr}`).value = '>> Terms and Conditions:';
  ws.getCell(`A${tr}`).font = { bold: true };
  for (const [k, v] of [['Delivery Term:', h.deliveryTerm], ['Payment Term:', h.paymentTerm], ['Dispatch Time:', h.dispatchTime]]) { if (v) { tr++; ws.getCell(`A${tr}`).value = k; ws.getCell(`C${tr}`).value = v; } }

  // the layout of the SAP sales-order upload (the grey columns of the template's Proforma tab)
  const sap = wb.addWorksheet('SAP order');
  const sapHeads = ['Sipariş ID', 'Sipariş Türü', 'Satış Organizasyonu', 'Dağıtım Kanalı', 'Bölüm', 'SAS No', 'Siparişi Veren', 'Malı Teslim Alan', 'Kalem No', 'Malzeme Kodu', 'Miktar', 'Ölçü Birimi', 'Müşteri Termin Tarihi', 'Kalınlık', 'Genişlik', 'Rulo Boyu'];
  sap.addRow(sapHeads).font = { bold: true };
  priced.lines.filter((l) => l.found || l.sap).forEach((l, i) => sap.addRow([1, 'ZS02', 2000, 20, 10, '', h.sapNumber, h.sapNumber, (i + 1) * 10, l.found?.sap ?? l.sap, l.meters, 'M', '', l.thickness, l.width, l.rollLength]));
  sapHeads.forEach((_, i) => (sap.getColumn(i + 1).width = 16));
  return Buffer.from(await wb.xlsx.writeBuffer());
}

export const proformaFileName = (company: string, ext: string, version?: number) =>
  `TECE-Proforma-${path.basename(company || 'customer').normalize('NFKD').replace(/[^\w.-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40) || 'customer'}-${new Date().toISOString().slice(0, 10)}${version && version > 1 ? `-v${version}` : ''}.${ext}`;
