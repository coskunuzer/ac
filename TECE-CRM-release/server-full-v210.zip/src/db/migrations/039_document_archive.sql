-- Every price-list PDF and every proforma PDF that was made is kept, so an earlier version can always be opened again.
CREATE TABLE IF NOT EXISTS document_archive (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT NOT NULL,                 -- 'price_list' or 'proforma'
  card_id INTEGER,                    -- the customer (proformas)
  price_list_id INTEGER,              -- the price workbook it was made from
  title TEXT,
  file_name TEXT NOT NULL,
  stored_name TEXT NOT NULL,
  hash TEXT,
  created_by INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_archive_card ON document_archive (card_id, kind);
CREATE INDEX IF NOT EXISTS idx_archive_kind ON document_archive (kind, created_at);
