/* eslint-disable @typescript-eslint/no-explicit-any */
// The summary of the sales list (pure: no database). Used by the upload and by the script that makes the history file shipped with the CRM.
const GROUPCOS = /TECE\s*DE[CK]|TEZER/i;
export const HORIZON_MONTHS = 38; // monthly detail is kept this long; older years are kept as yearly totals

export interface Agg {
  through?: string;
  cust: string[][];                  // code, name, region, city, rep, first, last
  mat: string[][];                   // code, description, group, type, finish, first, last
  fact: (string | number)[][];       // period, customer, material, doc_type, reason, thickness, width, eur, meters, m2, kg
  month: (string | number)[][];      // ym, channel, group, eur, m2, meters
  spec: (string | number)[][];       // period, thickness, width, group, eur, meters
  events: (string | number)[][];     // customer, date, eur
}
const monthsBack = (ym: string, n: number): string => { let y = +ym.slice(0, 4), m = +ym.slice(5, 7) - n; while (m < 1) { m += 12; y--; } return `${y}-${String(m).padStart(2, '0')}`; };
export const horizonFor = (cut: string): string => monthsBack(cut.slice(0, 7), HORIZON_MONTHS); // the first month kept month by month
const chOf = (code: string, name: string) => (code.startsWith('1202') ? 0 : code.startsWith('1201') ? 1 : 2) + (GROUPCOS.test(name) ? 10 : 0);
export const monthEnd = (ym: string) => new Date(Date.UTC(+ym.slice(0, 4), +ym.slice(5, 7), 0)).toISOString().slice(0, 10);
const rd = (v: number) => Math.round(v * 100) / 100;

export function aggregateRows(rows: unknown[][], horizon: string): Agg {
  const cust = new Map<string, any>(), mat = new Map<string, any>(), fact = new Map<string, number[]>(), month = new Map<string, number[]>(), spec = new Map<string, number[]>(), ev = new Map<string, number>();
  const sorted = [...rows].sort((a, b) => (String(a[3]) < String(b[3]) ? -1 : 1));
  for (const r of sorted) {
    const [, , type, d, , code, cname, mcode, desc, grp, typ, fin, th, w, m, m2, kg, eur, region, city, rep, reason] = r as (string | number)[];
    const date = String(d), ym = date.slice(0, 7), monthly = ym >= horizon, period = monthly ? ym : `${date.slice(0, 4)}-00`;
    let c = cust.get(String(code)); if (!c) { c = { name: '', region: '', city: '', rep: '', first: date, last: date }; cust.set(String(code), c); }
    if (date < c.first) c.first = date;
    if (date >= c.last) { c.last = date; c.name = String(cname) || c.name; if (region) c.region = String(region); if (city) c.city = String(city); if (rep) c.rep = String(rep); }
    let mm = mat.get(String(mcode)); if (!mm) { mm = { desc: '', grp: '', typ: '', fin: '', first: date, last: date }; mat.set(String(mcode), mm); }
    if (date < mm.first) mm.first = date;
    if (date >= mm.last) { mm.last = date; mm.desc = String(desc) || mm.desc; mm.grp = String(grp); mm.typ = String(typ); mm.fin = String(fin); }
    const ret = type === 'R', wk = +w > 0 && +w < 200 ? +w : 999, tk = monthly ? +th : 0, wf = monthly ? wk : 0;
    const fk = [period, code, mcode, type, ret ? String(reason || 'Unspecified') : '', tk, wf].join('|');
    let f = fact.get(fk); if (!f) { f = [0, 0, 0, 0]; fact.set(fk, f); }
    f[0] += +eur; f[1] += +m; f[2] += +m2; f[3] += +kg;
    const mk = [ym, chOf(String(code), String(cname)), String(grp) || 'Other'].join('|'); let o = month.get(mk); if (!o) { o = [0, 0, 0]; month.set(mk, o); }
    o[0] += +eur; o[1] += +m2; o[2] += +m;
    if (!ret && +th > 0) { const sk = [period, +th, +w > 0 && +w <= 100 ? +w : 999, String(grp) || 'Other'].join('|'); let s = spec.get(sk); if (!s) { s = [0, 0]; spec.set(sk, s); } s[0] += +eur; s[1] += +m; }
    if (!ret && +eur > 0) { const ek = String(code) + '|' + date; ev.set(ek, (ev.get(ek) || 0) + +eur); }
  }
  return {
    cust: [...cust].map(([k, c]) => [k, c.name, c.region, c.city, c.rep, c.first, c.last]), mat: [...mat].map(([k, c]) => [k, c.desc, c.grp, c.typ, c.fin, c.first, c.last]),
    fact: [...fact].map(([k, v]) => { const p = k.split('|'); return [p[0], p[1], p[2], p[3], p[4], +p[5], +p[6], rd(v[0]), Math.round(v[1]), rd(v[2]), rd(v[3])]; }),
    month: [...month].map(([k, v]) => { const p = k.split('|'); return [p[0], +p[1], p[2], rd(v[0]), rd(v[1]), Math.round(v[2])]; }),
    spec: [...spec].map(([k, v]) => { const p = k.split('|'); return [p[0], +p[1], +p[2], p[3], rd(v[0]), Math.round(v[1])]; }),
    events: [...ev].map(([k, v]) => { const p = k.split('|'); return [p[0], p[1], rd(v)]; }),
  };
}

