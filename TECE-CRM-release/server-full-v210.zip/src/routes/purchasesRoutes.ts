import { Router, type Response } from 'express';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { cardModel } from '../models/cardModel';
import { canSeeCard } from '../services/visibility';
import { maySeeSales, mayOpenCountry, purchasesForCard, purchasesForCountry } from '../services/purchases';

// What a customer bought (on the customer page) and what a whole country bought (in the Country explorer), from the Sales intelligence summary.
// A customer: whoever may open the customer and may see sales figures. A country: admins, Sales intelligence, and the salesperson responsible for it.
const router = Router();
router.use(requireAuth);
const fail = (res: Response, err: unknown, code = 400) => res.status(code).json({ error: err instanceof Error ? err.message : String(err) });
type U = Parameters<typeof maySeeSales>[0];

router.get('/card/:cardId', (req: AuthedRequest, res) => {
  try {
    const card = cardModel.findById(Number(req.params.cardId));
    if (!card || !canSeeCard(req.user, card)) return res.status(404).json({ error: 'Customer not found' });
    if (!maySeeSales(req.user as unknown as U)) return res.status(403).json({ error: 'Sales figures are not switched on for you.' });
    res.json(purchasesForCard(card as never));
  } catch (e) { console.error('Purchases (customer) failed:', e); fail(res, e, 500); }
});

router.get('/country/:country', (req: AuthedRequest, res) => {
  try {
    const country = String(req.params.country || '').trim();
    if (!country) return fail(res, new Error('Which country?'));
    if (!mayOpenCountry(req.user as unknown as U, country)) return res.status(403).json({ error: 'The purchases of a whole country are open to admins, Sales intelligence and the salesperson responsible for the country.' });
    res.json(purchasesForCountry(country, req.user as unknown as U));
  } catch (e) { console.error('Purchases (country) failed:', e); fail(res, e, 500); }
});

export default router;
