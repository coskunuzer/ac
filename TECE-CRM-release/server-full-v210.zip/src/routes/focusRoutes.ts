import { Router, type Response } from 'express';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { access } from '../services/teamPerf';
import { focusFor, snoozeFocus, unsnoozeFocus } from '../services/focusAreas';
import type { PublicUser } from '../models/userModel';
import type { Perms } from '../services/permissions';

// /api/focus - "Your focus" on Today (services/focusAreas.ts).
//   GET  /me                    my 1-3 focus areas (?all=1: every candidate with its list, for the run page)
//   GET  /person/:id            a person's focus areas: yourself; a manager (Manager mode) the people below him; an admin everybody (teamPerf.access)
//   POST /snooze {key, days?}   "Not now": hidden for me until tomorrow (queue_state, key f:<focus key>); POST /unsnooze {key} brings it back
// Money (expected values, sales in the reasons) only with the money switch "ledger" (a person without a permissions row keeps it, as before).
// An assistant works as the person she assists (auth middleware), never in Manager mode; Operations (can_ship without a permissions row) gets none.

const router = Router();
router.use(requireAuth);
const fail = (res: Response, err: unknown) => { console.error('Focus failed:', err); res.status(500).json({ error: err instanceof Error ? err.message : String(err) }); };
type U = PublicUser & { perms?: Perms | null };
const moneyOf = (u: U) => u.role === 'admin' || !u.perms || u.perms.money.includes('ledger');

router.get('/me', (req: AuthedRequest, res) => {
  try {
    const u = req.user as U;
    const name = u.display_name || u.username;
    const off = { applies: false, focus: [], more: [], empty: null, snoozed: 0, money: false, person: { id: u.id, name, self: true } };
    // Operations and the complaints logins do not sell; the admin login has no customers of its own
    if ((u.can_ship && !u.perms && !req.actor) || (u.area && u.area !== 'brand' && !u.perms)) return res.json(off);
    const t0 = Date.now();
    const out = focusFor(u as never, { id: u.id, name, self: true, email: u.email ?? null, lang: u.ui_language ?? null }, moneyOf(u), { snoozeOf: u.id, all: req.query.all === '1' });
    res.setHeader('Server-Timing', `focus;dur=${Date.now() - t0}`);
    res.json(out);
  } catch (e) { fail(res, e); }
});

router.get('/person/:id', (req: AuthedRequest, res) => {
  try {
    const a = access(req.user as never, req.actor ?? null);
    if (!a.ok) return res.status(403).json({ error: a.error });
    const s = a.people.find((p) => p.id === Number(req.params.id));
    if (!s) return res.status(403).json({ error: 'You can see only yourself and the people who report to you.' });
    const t0 = Date.now();
    const out = focusFor(req.user as never, s, a.money, { snoozeOf: s.self ? req.user!.id : null, all: req.query.all === '1' });
    res.setHeader('Server-Timing', `focus;dur=${Date.now() - t0}`);
    res.json(out);
  } catch (e) { fail(res, e); }
});

router.post('/snooze', (req: AuthedRequest, res) => {
  const key = String(req.body?.key ?? '').trim();
  if (!key || key.length > 120) return res.status(400).json({ error: 'Which focus?' });
  snoozeFocus(req.user!.id, key, Number(req.body?.days ?? 1) || 1);
  res.json({ ok: true });
});
router.post('/unsnooze', (req: AuthedRequest, res) => {
  const key = String(req.body?.key ?? '').trim();
  if (!key) return res.status(400).json({ error: 'Which focus?' });
  unsnoozeFocus(req.user!.id, key);
  res.json({ ok: true });
});

export default router;
