// Short messages for a meeting and for a trip, in the language of the customer (en ru tr es fr; English otherwise).
// The dates and times in them are always the customer's own (their country's time), never ours.
type Lang = 'en' | 'ru' | 'tr' | 'es' | 'fr';
export const langOf = (l: string | null | undefined): Lang => (l === 'ru' || l === 'tr' || l === 'es' || l === 'fr' ? l : 'en');

export const LOCALE: Record<Lang, string> = { en: 'en-GB', ru: 'ru-RU', tr: 'tr-TR', es: 'es-ES', fr: 'fr-FR' };
const fill = (s: string, v: Record<string, string>) =>
  s.replace(/\{(\w+)\}/g, (_, k: string) => v[k] ?? '').replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').replace(/\s+([,.!?])/g, '$1').trim();

const HELLO: Record<Lang, string> = {
  en: 'Hello {name},', ru: 'Здравствуйте, {name}!', tr: 'Merhaba {name},', es: 'Hola {name},', fr: 'Bonjour {name},',
};
const FROM: Record<Lang, string> = {
  en: 'This is {user} from TECE, the edgebanding company.', ru: 'Это {user} из компании TECE, производителя кромочной ленты.',
  tr: 'Ben TECE kenar bandı şirketinden {user}.', es: 'Soy {user} de TECE, la empresa de cantos.', fr: "Ici {user} de TECE, l'entreprise de chants.",
};

const MEETING: Record<Lang, string> = {
  en: 'We have a meeting planned: {title}.\n{date} at {time} ({zone} time).\n{link}\nPlease tell me if another time suits you better.',
  ru: 'Мы запланировали встречу: {title}.\n{date} в {time} (время: {zone}).\n{link}\nСообщите, пожалуйста, если вам удобнее другое время.',
  tr: 'Bir görüşme planladık: {title}.\n{date}, saat {time} ({zone} saati).\n{link}\nBaşka bir saat daha uygunsa lütfen haber verin.',
  es: 'Tenemos una reunión prevista: {title}.\n{date} a las {time} (hora de {zone}).\n{link}\nAvíseme si le conviene otra hora.',
  fr: 'Nous avons prévu un rendez-vous : {title}.\n{date} à {time} (heure de {zone}).\n{link}\nDites-moi si un autre horaire vous convient mieux.',
};

const TRIP: Record<Lang, string> = {
  en: 'I will be travelling to {place}{when}.\nWould you have time for a meeting{at}?\n{extra}',
  ru: 'Я буду в поездке: {place}{when}.\nНайдётся ли у вас время для встречи{at}?\n{extra}',
  tr: '{place} seyahatinde olacağım{when}.\nBir görüşme için vaktiniz olur mu{at}?\n{extra}',
  es: 'Viajaré a {place}{when}.\n¿Tendría tiempo para una reunión{at}?\n{extra}',
  fr: 'Je serai en déplacement à {place}{when}.\nAuriez-vous le temps pour un rendez-vous{at} ?\n{extra}',
};

export function meetingMessage(lang: string | null | undefined, v: { name: string; user: string; title: string; date: string; time: string; zone: string; link?: string | null }): string {
  const l = langOf(lang);
  return fill(`${HELLO[l]}\n${FROM[l]}\n\n${MEETING[l]}`, { name: v.name, user: v.user, title: v.title, date: v.date, time: v.time, zone: v.zone, link: v.link ?? '' });
}

// "when" is the date(s) already written ("17-20 November 2026"); "at" is the time of the visit ("10:00"): both are put in brackets here.
export function tripMessage(lang: string | null | undefined, v: { name: string; user: string; place: string; when?: string; at?: string; extra?: string }): string {
  const l = langOf(lang);
  return fill(`${HELLO[l]}\n${FROM[l]}\n\n${TRIP[l]}`, { name: v.name, user: v.user, place: v.place, when: v.when ? ` (${v.when})` : '', at: v.at ? ` (${v.at})` : '', extra: v.extra ?? '' });
}

// The subject of a trip e-mail.
export const tripSubject = (lang: string | null | undefined, place: string, when: string): string => {
  const l = langOf(lang);
  const t: Record<Lang, string> = { en: `Meeting in ${place} (${when})`, ru: `Встреча: ${place} (${when})`, tr: `${place} görüşmesi (${when})`, es: `Reunión en ${place} (${when})`, fr: `Rendez-vous à ${place} (${when})` };
  return t[l];
};
