import { createHash } from 'node:crypto';
import { db } from '../db/connection';
import { memoTables } from '../db/dataVersion';
import { canonicalReps, linkMap, repOf } from './perfAnalytics';
import { niceName } from './niceName';
import { activePriceBook } from './priceBook/store';
import { paramsFor } from './proforma';
import { GROUPCOS, MIN_EUR, MIN_QTY, PRICE_UNIT, benchAvg, priceIndexOf } from './priceIndex';

// Price performance (the Performance page, "Price performance" tab): for each sales person, their customers' status, success and value, and
// above all the PRICE they sell at. Everything is read from the Sales intelligence summary of the SAP sales list (intel_fact: net EUR, kg, m2
// per month, customer, colour and thickness) and worked out once per data version for ALL customers; a request only picks its people out.
//
//  Who looks after a customer: the same rule as the rest of the Performance page (perfAnalytics.repOf): what an admin set > the person on the
//  CRM card > the person of the country > the sales person SAP shows, written as the user's name (canonicalReps). Linked SAP numbers count as
//  their parent (perf_links). Group companies (TECE DEKOR / TEZER) and accounts marked "not a customer" (intel_excluded) are left out.
//
//  "Today" is the last invoice day in the data (salesTargets.dataCut: the list is uploaded now and then), not the calendar day.
//
//  Status (from purchase recency and trend, worked out here: the SAP status_key of the Performance page only says active / passive / dormant
//  and its "health" measures the pace against a target, not the buying itself):
//    new      first purchase in the last 12 months
//    lost     nothing bought for more than 12 months
//    passive  nothing bought for 6 to 12 months
//    slowing  bought in the last 6 months, but the last 12 months are under 75 % of the 12 months before
//    active   everything else (bought in the last 6 months, steady or growing)
//
//  Prices, by the owner's rule (OWNER-RULES, 21 Nov), the headline "is this customer's price good?" - worked out by services/priceIndex.ts,
//  the one implementation the customer purchases view and the team analysis use as well:
//    unit               EUR per kg for PVC / ABS / PP (and their two-colour, laser and hot-air kinds, PMMA); EUR per m2 for melamine and veneer (Ahşap).
//                       Other groups (caps, metal, accessories) have no price benchmark: they count in the revenue, never in a price or an index.
//    benchmark          the volume-weighted average of ALL customers (group companies and "not a customer" accounts left out) in the same product
//                       group within the same window: total EUR / total kg (or m2). Each window has its own average; years are never compared.
//    price index        the customer's EUR/unit in a group ÷ that benchmark × 100 (above 100 = a good price). Several groups: weighted by the customer's
//                       revenue per group. A group counts only with at least MIN_QTY kg/m2 and MIN_EUR in the window; a customer whose counted groups
//                       are under half of their priced revenue is "low confidence" (shown, never flagged).
//    index trend        the index in this window against the index in the window before (each against its own average), in points. No raw
//                       price changes across years.
//    returns            sales lines only, in the customer's price and in the benchmark alike; revenue is net (sales minus returns). Only the
//                       monthly rows (the last ~3 years) are used for prices.
//    price realisation  (extra) sales EUR / (m2 × the list price per m2 of the colour's product, price category and thickness) for the lines whose
//                       list price can be worked out (active export price list + the colour database); the rest is left out without a word

export type PeriodKey = '12m' | 'ytd' | 'ly';
export const STATUSES = ['active', 'new', 'slowing', 'passive', 'lost'] as const;
export type Status = (typeof STATUSES)[number];
const LEAK_INDEX = 90; // a customer this far under the company average for the same products is "discount leakage"
const FALL_PTS = -5; // an index that fell at least this many points against the window before, while the volume did not grow
// the price unit of a product group: services/priceIndex.ts
export { PRICE_UNIT };

const shift = (ym: string, n: number): string => { let y = +ym.slice(0, 4), m = +ym.slice(5, 7) + n; while (m < 1) { m += 12; y--; } while (m > 12) { m -= 12; y++; } return `${y}-${String(m).padStart(2, '0')}`; };
const monthEnd = (ym: string) => new Date(Date.UTC(+ym.slice(0, 4), +ym.slice(5, 7), 0)).toISOString().slice(0, 10);
const r1 = (v: number) => Math.round(v * 10) / 10;
const r2 = (v: number) => Math.round(v * 100) / 100;
const pctChange = (a: number, b: number): number | null => (b > 0 ? r1(((a - b) / b) * 100) : null);

export interface Win { key: string; from: string; to: string }
// every period has the window before it (for growth, retention and the index trend); the rolling 12 months also have the one before that
// (the index per 12-month window, three in a row, is the price trend)
export function windowsFor(cutYm: string): Record<PeriodKey, { cur: Win; prev: Win; pprev?: Win }> {
  const y = +cutYm.slice(0, 4), m = cutYm.slice(5, 7);
  return {
    '12m': { cur: { key: '12m', from: shift(cutYm, -11), to: cutYm }, prev: { key: '12m_p', from: shift(cutYm, -23), to: shift(cutYm, -12) }, pprev: { key: '12m_pp', from: shift(cutYm, -35), to: shift(cutYm, -24) } },
    ytd: { cur: { key: 'ytd', from: `${y}-01`, to: cutYm }, prev: { key: 'ytd_p', from: `${y - 1}-01`, to: `${y - 1}-${m}` } },
    ly: { cur: { key: 'ly', from: `${y - 1}-01`, to: `${y - 1}-12` }, prev: { key: 'ly_p', from: `${y - 2}-01`, to: `${y - 2}-12` } },
  };
}

// sales of one product group in one window (returns are not in here)
interface GSum { eur: number; kg: number; m2: number }
interface Agg {
  net: number; kgNet: number; eurS: number; kgS: number; m2S: number;
  grp: Map<string, GSum>;
  listEur: number; listBase: number; // realisation: sales EUR of the lines with a list price, and m2 × list price of those lines
}
const emptyAgg = (): Agg => ({ net: 0, kgNet: 0, eurS: 0, kgS: 0, m2S: 0, grp: new Map(), listEur: 0, listBase: 0 });

interface Cust {
  sap: string; name: string; country: string; rep: string; cardId: number | null;
  first: string | null; last: string | null; lifetime: number; status: Status;
  win: Map<string, Agg>; // window key -> sums
}
export interface Base {
  cut: string | null; cutYm: string | null;
  custs: Map<string, Cust>;
  bench: Map<string, Map<string, number>>; // window key -> product group -> company EUR per unit (kg or m2, PRICE_UNIT)
  offers: { rep: string; sap: string | null; first: string }[]; // first offer per card (the last ~3 years)
  hasList: boolean; listName: string | null;
}

// the list price per m2 of a product, price category and thickness: from the active export price list (null where it cannot be worked out)
function listPricer(): { fn: (product: string, cat: number, th: number) => number | null; name: string | null } {
  let pb: ReturnType<typeof activePriceBook> = null;
  try { pb = activePriceBook('export'); } catch { pb = null; }
  if (!pb) return { fn: () => null, name: null };
  const book = pb.book;
  const params = paramsFor(book, { currency: 'EUR', usdRate: 1, transportPct: 0 });
  const kept = new Map<string, number | null>();
  return {
    name: pb.row.original_name ?? null,
    fn: (product, cat, th) => {
      if (product !== 'PVC' && product !== 'ABS' && product !== 'PP') return null;
      const k = `${product}|${cat}|${th}`;
      if (!kept.has(k)) { let v: number | null = null; try { v = book.m2Price(product, cat, th, params)?.price ?? null; } catch { v = null; } kept.set(k, v); }
      return kept.get(k) ?? null;
    },
  };
}

// Kept until one of these tables is written. Customers and offers are written all day (a note, a rating, an offer to someone else): of those only
// a fingerprint of what is read here counts (the SAP number, person, country and name of a customer with a SAP number; the newest offer).
const TABLES = ['intel_fact', 'intel_cust', 'intel_mat', 'intel_master', 'intel_excluded', 'color_codes', 'sap_customers', 'perf_rep_override', 'perf_links', 'country_assignments', 'price_lists'];
export const cardsMark = memoTables(['cards'], () => {
  const h = createHash('sha1');
  for (const r of db.prepare("SELECT id, sap, person, country, market, company, name FROM cards WHERE sap IS NOT NULL AND TRIM(sap) <> '' ORDER BY id").all() as Record<string, unknown>[]) h.update(`${r.id}\u0001${r.sap}\u0001${r.person}\u0001${r.country}\u0001${r.market}\u0001${r.company}\u0001${r.name}\u0002`);
  return h.digest('hex');
});
// the users: only who they are, their names and their place in the team count (a theme toggle or a profile save does not)
export const usersMark = memoTables(['users'], () => {
  const h = createHash('sha1');
  for (const r of db.prepare('SELECT id, username, display_name, role, market, manager_id, is_active, is_assistant, assists_id FROM users ORDER BY id').all() as Record<string, unknown>[]) h.update(Object.values(r).join('\u0001') + '\u0002');
  return h.digest('hex');
});
const offersMark = memoTables(['offers_sent'], () => { const r = db.prepare('SELECT COUNT(*) n, MAX(id) m FROM offers_sent').get() as { n: number; m: number | null }; return `${r.n}.${r.m ?? 0}`; });
const byTables = memoTables(TABLES, () => ({ mark: '', base: null as Base | null }));
export function pricePerfBase(): Base {
  const kept = byTables();
  const mark = cardsMark() + '|' + offersMark() + '|' + usersMark();
  if (!kept.base || kept.mark !== mark) { kept.base = buildBase(listPricer()); kept.mark = mark; }
  return kept.base;
}

export function buildBase(list: ReturnType<typeof listPricer>): Base {
  const cut = (db.prepare('SELECT MAX(last_date) d FROM intel_cust').get() as { d: string | null }).d;
  const empty: Base = { cut, cutYm: cut ? cut.slice(0, 7) : null, custs: new Map(), bench: new Map(), offers: [], hasList: false, listName: list.name };
  if (!cut) return empty;
  const cutYm = cut.slice(0, 7);
  const W = windowsFor(cutYm);
  const wins: Win[] = Object.values(W).flatMap((w) => [w.cur, w.prev, ...(w.pprev ? [w.pprev] : [])]);
  const L = linkMap();
  const P = (s: string) => L.get(s) ?? s;
  const canon = canonicalReps();

  // who is who: card, SAP list, overrides, the SAP sales list's own name and rep
  const cardBy = new Map<string, { id: number; person: string | null; country: string | null; company: string | null }>();
  for (const c of db.prepare("SELECT id, TRIM(sap) sap, person, country, market, COALESCE(NULLIF(company, ''), name) company FROM cards WHERE sap IS NOT NULL AND TRIM(sap) <> '' ORDER BY id").all() as { id: number; sap: string; person: string | null; country: string | null; market: string | null; company: string | null }[]) {
    // a card can carry several SAP numbers ('103594 / 100002', as on the customer page): each of them finds the card
    for (const code of sapList(c.sap)) if (!cardBy.has(code)) cardBy.set(code, { id: c.id, person: c.person, country: c.market === 'domestic' ? 'Turkey' : c.country, company: c.company });
  }
  const sapBy = new Map((db.prepare('SELECT sap_no, name, country FROM sap_customers').all() as { sap_no: string; name: string; country: string | null }[]).map((r) => [r.sap_no, r]));
  const repSet = new Map((db.prepare('SELECT sap_no, rep FROM perf_rep_override').all() as { sap_no: string; rep: string }[]).map((r) => [r.sap_no, r.rep]));
  const master = new Map((db.prepare('SELECT code, country FROM intel_master').all() as { code: string; country: string | null }[]).map((r) => [r.code, r.country ?? '']));
  const excluded = new Set((db.prepare('SELECT code FROM intel_excluded').all() as { code: string }[]).map((r) => r.code));
  const custs = new Map<string, Cust>();
  const skip = new Set<string>();
  for (const r of db.prepare('SELECT code, name, rep, first_date, last_date FROM intel_cust').all() as { code: string; name: string | null; rep: string | null; first_date: string | null; last_date: string | null }[]) {
    if (excluded.has(r.code) || GROUPCOS.test(r.name ?? '')) { skip.add(r.code); continue; }
    const sap = P(r.code);
    let c = custs.get(sap);
    if (!c) {
      const card = cardBy.get(sap); const s = sapBy.get(sap);
      const country = (card?.country?.trim() || s?.country || master.get(sap) || '').trim();
      const rep = canon(repSet.get(sap) ?? repOf(country, card?.person ?? null, r.rep ?? null));
      c = { sap, name: niceName(card?.company || s?.name || r.name || sap), country, rep, cardId: card?.id ?? null, first: null, last: null, lifetime: 0, status: 'active', win: new Map() };
      custs.set(sap, c);
    }
    if (r.first_date && (!c.first || r.first_date < c.first)) c.first = r.first_date;
    if (r.last_date && (!c.last || r.last_date > c.last)) c.last = r.last_date;
  }

  // lifetime (every period, the old yearly rows too) and the sums of every window, in SQL
  for (const r of db.prepare('SELECT customer, SUM(eur) eur FROM intel_fact GROUP BY customer').all() as { customer: string; eur: number }[]) {
    if (skip.has(r.customer)) continue; const c = custs.get(P(r.customer)); if (c) c.lifetime += r.eur;
  }
  const winSql = wins.map(() => 'SELECT ? k, ? a, ? b').join(' UNION ALL ');
  const winArgs = wins.flatMap((w) => [w.key, w.from, w.to]);
  // only the monthly rows (YYYY-MM): the yearly rows (YYYY-00) of the old years never fall in a window, and are kept out explicitly as well
  const rows = db.prepare(`WITH win(k, a, b) AS (${winSql})
    SELECT win.k wk, f.customer cust, COALESCE(NULLIF(m.grp, ''), 'Other') grp, f.thickness th, f.doc_type dt, cc.product_type pt, cc.category_no cat,
      SUM(f.eur) eur, SUM(f.kg) kg, SUM(f.m2) m2
    FROM intel_fact f JOIN win ON f.period >= win.a AND f.period <= win.b
    LEFT JOIN intel_mat m ON m.code = f.material LEFT JOIN color_codes cc ON cc.sap = f.material
    WHERE f.period NOT LIKE '%-00'
    GROUP BY win.k, f.customer, grp, f.thickness, f.doc_type, cc.product_type, cc.category_no`).all(...winArgs) as { wk: string; cust: string; grp: string; th: number; dt: string; pt: string | null; cat: number | null; eur: number; kg: number; m2: number }[];
  let listed = 0;
  for (const r of rows) {
    if (skip.has(r.cust)) continue;
    const c = custs.get(P(r.cust)); if (!c) continue;
    const a = c.win.get(r.wk) ?? c.win.set(r.wk, emptyAgg()).get(r.wk)!;
    a.net += r.eur; a.kgNet += r.kg;
    if (r.dt !== 'S') continue; // returns: in the net revenue only, never in a price
    a.eurS += r.eur; a.kgS += r.kg; a.m2S += r.m2;
    const g = a.grp.get(r.grp) ?? { eur: 0, kg: 0, m2: 0 };
    g.eur += r.eur; g.kg += r.kg; g.m2 += r.m2; a.grp.set(r.grp, g);
    if (r.pt && r.cat && r.th > 0 && r.m2 > 0) {
      const lp = list.fn(r.pt, r.cat, r.th);
      if (lp && lp > 0) { a.listEur += r.eur; a.listBase += r.m2 * lp; listed += 1; }
    }
  }
  // the company average per group and window: the shared benchmark (services/priceIndex.ts; empty for a window the monthly rows do not cover)
  const bench = new Map(wins.map((w) => [w.key, benchAvg(w.from, w.to)]));

  // status, from the recency and the trend of the buying
  const c12 = shift(cutYm, -11), c6 = monthEnd(shift(cutYm, -6)).slice(0, 10), c12d = `${c12}-01`;
  const lostBefore = monthEnd(shift(cutYm, -12));
  for (const c of custs.values()) {
    const cur = c.win.get('12m')?.net ?? 0, prev = c.win.get('12m_p')?.net ?? 0;
    c.status = c.first && c.first >= c12d ? 'new' : !c.last || c.last <= lostBefore ? 'lost' : c.last <= c6 ? 'passive' : prev > 0 && cur < prev * 0.75 ? 'slowing' : 'active';
  }

  // offers: the first offer of every CRM customer (for "offers that became first orders")
  const offers = (db.prepare(`SELECT c.person rep, TRIM(c.sap) sap, MIN(o.sent_at) first FROM offers_sent o JOIN cards c ON c.id = o.card_id
    WHERE o.sent_at >= ? AND o.kind = 'offer' AND c.person IS NOT NULL AND TRIM(c.person) <> '' GROUP BY o.card_id`).all(`${shift(cutYm, -36)}-01`) as { rep: string; sap: string | null; first: string }[])
    .map((o) => ({ rep: canon(o.rep), sap: o.sap ? P(o.sap) : null, first: o.first.slice(0, 10) }));

  return { cut, cutYm, custs, bench, offers, hasList: listed > 0, listName: list.name };
}

// the SAP numbers of a card (the same split as services/purchases.ts sapCodes; the whole text first, so a plain number stays as it was)
const sapList = (sap: string): string[] => [...new Set([sap.trim(), ...sap.split(/[\s,;/|]+/).map((x) => x.trim()).filter((x) => /^[A-Za-z0-9-]{3,20}$/.test(x))])];

// ---- the owner's price index of a set of group sums (one customer, or a person's / team's customers together) in one window --------------
export interface GroupPrice { grp: string; unit: 'kg' | 'm2'; eur: number; qty: number; price: number; avg: number; index: number; ok: boolean }
export interface PriceIdx { index: number | null; sure: boolean; groups: GroupPrice[] }
export function priceIndex(groups: Map<string, GSum> | undefined, bench: Map<string, number> | undefined): PriceIdx {
  return priceIndexOf(groups, bench); // the one implementation (services/priceIndex.ts)
}
const addGroups = (into: Map<string, GSum>, from: Map<string, GSum> | undefined) => { if (from) for (const [g, s] of from) { const o = into.get(g) ?? { eur: 0, kg: 0, m2: 0 }; o.eur += s.eur; o.kg += s.kg; o.m2 += s.m2; into.set(g, o); } };
// EUR per kg over the kg groups only, EUR per m2 over the m2 groups only
function unitPrices(groups: Map<string, GSum> | undefined): { ppk: number | null; ppm2: number | null } {
  let ek = 0, k = 0, em = 0, m = 0;
  if (groups) for (const [g, s] of groups) { const u = PRICE_UNIT[g]; if (u === 'kg') { ek += s.eur; k += s.kg; } else if (u === 'm2') { em += s.eur; m += s.m2; } }
  return { ppk: k > 0 ? r2(ek / k) : null, ppm2: m > 0 ? r2(em / m) : null };
}
const pts = (a: number | null, b: number | null) => (a != null && b != null ? r1(a - b) : null);

// ---- the view of a set of people ---------------------------------------------------------------------------------------------------
export interface CustRow {
  sap: string; cardId: number | null; name: string; country: string; rep: string; status: Status;
  rev12: number; rev: number; revPrev: number; growth: number | null; kg: number; kgPrev: number; kgGrowth: number | null;
  ppk: number | null; ppm2: number | null; index: number | null; indexPrev: number | null; change: number | null; sure: boolean; realisation: number | null;
  share: number | null; lifetime: number; first: string | null; last: string | null; flags: ('leak' | 'fall')[];
  groups: { grp: string; unit: 'kg' | 'm2'; eur: number; qty: number; price: number; avg: number; index: number; ok: boolean }[];
}

export interface Summary {
  customers: number; buying: number; newThisYear: number; status: Record<Status, number>;
  rev: number; revPrev: number; growth: number | null; rev12: number; rev12Prev: number; rev12Growth: number | null; kg: number; kgPrev: number; lifetime: number;
  ppk: number | null; ppm2: number | null; index: number | null; indexPrev: number | null; change: number | null; trend: { from: string; to: string; index: number | null }[]; realisation: number | null;
  retention: { kept: number; of: number; pct: number | null }; conversion: { offered: number; won: number; pct: number | null };
  leaks: number; falls: number; lowConfidence: number;
}
export interface GroupRow { grp: string; unit: 'kg' | 'm2' | null; eur: number; qty: number; price: number | null; avg: number | null; index: number | null; indexPrev: number | null; change: number | null }

export function summarise(base: Base, reps: Set<string>, period: PeriodKey): { summary: Summary; rows: CustRow[]; groups: GroupRow[] } {
  const W = base.cutYm ? windowsFor(base.cutYm)[period] : null;
  const status = Object.fromEntries(STATUSES.map((s) => [s, 0])) as Record<Status, number>;
  const rows: CustRow[] = [];
  const gCur = new Map<string, GSum>(), gPrev = new Map<string, GSum>(), gPP = new Map<string, GSum>();
  let rev = 0, revPrev = 0, rev12 = 0, rev12Prev = 0, kg = 0, kgPrev = 0, life = 0, buying = 0, newY = 0, keptN = 0, ofN = 0, listEur = 0, listBase = 0;
  const year = base.cut ? base.cut.slice(0, 4) : '';
  const bCur = W ? base.bench.get(W.cur.key) : undefined, bPrev = W ? base.bench.get(W.prev.key) : undefined;
  for (const c of base.custs.values()) {
    if (!reps.has(c.rep) || c.lifetime <= 0 || !W) continue;
    const cur = c.win.get(W.cur.key), prev = c.win.get(W.prev.key);
    addGroups(gCur, cur?.grp); addGroups(gPrev, prev?.grp); if (W.pprev) addGroups(gPP, c.win.get(W.pprev.key)?.grp);
    listEur += cur?.listEur ?? 0; listBase += cur?.listBase ?? 0;
    status[c.status] += 1;
    const net = cur?.net ?? 0, netP = prev?.net ?? 0;
    rev += net; revPrev += netP; kg += cur?.kgNet ?? 0; kgPrev += prev?.kgNet ?? 0; life += c.lifetime;
    rev12 += c.win.get('12m')?.net ?? 0; rev12Prev += c.win.get('12m_p')?.net ?? 0;
    if (net > 0) buying += 1;
    if (c.first && c.first.slice(0, 4) === year) newY += 1;
    if (netP > 0) { ofN += 1; if (net > 0) keptN += 1; }
    const pi = priceIndex(cur?.grp, bCur), pp = priceIndex(prev?.grp, bPrev);
    const kgS = cur?.kgS ?? 0, kgSP = prev?.kgS ?? 0;
    const change = pi.sure && pp.sure ? pts(pi.index, pp.index) : null;
    const flags: CustRow['flags'] = [];
    if (pi.sure && pi.index !== null && pi.index < LEAK_INDEX && net > 0) flags.push('leak');
    if (change !== null && change <= FALL_PTS && kgSP > 0 && kgS <= kgSP) flags.push('fall');
    const up = unitPrices(cur?.grp);
    rows.push({
      sap: c.sap, cardId: c.cardId, name: c.name, country: c.country, rep: c.rep, status: c.status,
      rev12: r2(c.win.get('12m')?.net ?? 0), rev: r2(net), revPrev: r2(netP), growth: pctChange(net, netP), kg: Math.round(cur?.kgNet ?? 0), kgPrev: Math.round(prev?.kgNet ?? 0), kgGrowth: pctChange(kgS, kgSP),
      ppk: up.ppk, ppm2: up.ppm2, index: pi.index, indexPrev: pp.index, change, sure: pi.sure,
      realisation: cur && cur.listBase > 0 ? r1((cur.listEur / cur.listBase) * 100) : null,
      share: null, lifetime: r2(c.lifetime), first: c.first, last: c.last, flags,
      groups: pi.groups.slice(0, 4).map((g) => ({ ...g, eur: r2(g.eur), qty: Math.round(g.qty), price: r2(g.price), avg: r2(g.avg), index: r1(g.index) })),
    });
  }
  for (const r of rows) r.share = rev > 0 ? r1((r.rev / rev) * 100) : null;
  rows.sort((a, b) => b.rev12 - a.rev12 || b.lifetime - a.lifetime);

  // offers sent in the period to customers who had not bought before, and how many of them bought for the first time after it
  let offered = 0, won = 0;
  if (W) {
    const a = `${W.cur.from}-01`, b = monthEnd(W.cur.to);
    for (const o of base.offers) {
      if (!reps.has(o.rep) || o.first < a || o.first > b) continue;
      const c = o.sap ? base.custs.get(o.sap) : undefined;
      if (c?.first && c.first < o.first) continue; // already a customer
      offered += 1;
      if (c?.first && c.first >= o.first && c.first <= (base.cut ?? b)) won += 1;
    }
  }
  // the people's own price per group against the company average (their customers together), and the index per window
  const tCur = priceIndex(gCur, bCur), tPrev = priceIndex(gPrev, bPrev);
  const prevBy = new Map(tPrev.groups.map((g) => [g.grp, g]));
  const groups: GroupRow[] = tCur.groups.map((g) => { const p = prevBy.get(g.grp); const ip = p && p.ok ? r1(p.index) : null; const ic = g.ok ? r1(g.index) : null; return { grp: g.grp, unit: g.unit, eur: r2(g.eur), qty: Math.round(g.qty), price: r2(g.price), avg: r2(g.avg), index: ic, indexPrev: ip, change: pts(ic, ip) }; });
  const unpriced = [...gCur].filter(([g]) => !groups.some((x) => x.grp === g)).reduce((s, [, v]) => s + v.eur, 0);
  if (unpriced > 0) groups.push({ grp: 'Other', unit: null, eur: r2(unpriced), qty: 0, price: null, avg: null, index: null, indexPrev: null, change: null });
  const trend = W?.pprev && base.cutYm
    ? [W.pprev, W.prev, W.cur].map((w, i) => ({ from: w.from, to: w.to, index: i === 0 ? priceIndex(gPP, base.bench.get(w.key)).index : i === 1 ? tPrev.index : tCur.index }))
    : [W?.prev, W?.cur].filter((w): w is Win => !!w).map((w, i) => ({ from: w.from, to: w.to, index: i === 0 ? tPrev.index : tCur.index }));
  const up = unitPrices(gCur);
  return {
    rows, groups,
    summary: {
      customers: rows.length, buying, newThisYear: newY, status,
      rev: r2(rev), revPrev: r2(revPrev), growth: pctChange(rev, revPrev), rev12: r2(rev12), rev12Prev: r2(rev12Prev), rev12Growth: pctChange(rev12, rev12Prev), kg: Math.round(kg), kgPrev: Math.round(kgPrev), lifetime: r2(life),
      ppk: up.ppk, ppm2: up.ppm2, index: tCur.index, indexPrev: tPrev.index, change: pts(tCur.index, tPrev.index), trend, realisation: listBase > 0 ? r1((listEur / listBase) * 100) : null,
      retention: { kept: keptN, of: ofN, pct: ofN ? r1((keptN / ofN) * 100) : null }, conversion: { offered, won, pct: offered ? r1((won / offered) * 100) : null },
      leaks: rows.filter((r) => r.flags.includes('leak')).length, falls: rows.filter((r) => r.flags.includes('fall')).length,
      lowConfidence: rows.filter((r) => r.index !== null && !r.sure && r.rev > 0).length,
    },
  };
}

export function periodInfo(base: Base, period: PeriodKey): { cur: Win; prev: Win } | null {
  if (!base.cutYm) return null;
  const w = windowsFor(base.cutYm)[period];
  return { cur: w.cur, prev: w.prev };
}
export const LIMITS = { leakIndex: LEAK_INDEX, fallPts: FALL_PTS, minQty: MIN_QTY, minEur: MIN_EUR };
