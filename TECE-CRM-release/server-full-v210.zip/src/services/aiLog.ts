import { db } from '../db/connection';
import { activityModel } from '../models/activityModel';
import { aiContext } from './aiGate';

// "The AI did this for the customer", written in the customer's history (Activities tab). It is not anybody's work: it is stored as an
// imported activity, so it never counts for the team page, the points or the goals. It stays with the customer when records are merged.
export function logAi(cardId: number, text: string): void {
  try {
    const uid =
      aiContext.get().userId ??
      (db.prepare("SELECT id FROM users WHERE role = 'admin' AND is_active = 1 ORDER BY id LIMIT 1").get() as { id: number } | undefined)?.id;
    if (!uid) return;
    activityModel.add({ userId: uid, cardId, type: 'ai', text, imported: true });
  } catch (err) {
    console.error('Could not write the AI activity', err);
  }
}

// Runs `fn` so that the tokens the AI uses inside it are booked on this customer.
export function runForCard<T>(cardId: number, fn: () => T): T {
  return aiContext.run({ cardId }, fn);
}
