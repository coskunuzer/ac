// tsc only compiles .ts files, so the plain .sql migration files need a
// separate copy step into dist/ after every build.
const fs = require('fs');
const path = require('path');

const src = path.resolve(__dirname, '../src/db/migrations');
const dest = path.resolve(__dirname, '../dist/db/migrations');

fs.cpSync(src, dest, { recursive: true });
console.log(`Copied migrations: ${src} -> ${dest}`);
