-- The AI / rules priority (cards.ai_rate) is on a 0-10 scale everywhere in the app (setAiRate clamps to 0..10). Old imported rows that
-- carry a 0-100 value are brought onto the same scale once, so every screen can read COALESCE(rate, ai_rate) the same way.
UPDATE cards SET ai_rate = CAST(ROUND(ai_rate / 10.0) AS INTEGER) WHERE ai_rate > 10;
