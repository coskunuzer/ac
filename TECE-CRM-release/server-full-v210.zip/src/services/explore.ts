import { db } from '../db/connection';
import { SQL_LEADS, SQL_RATING } from '../models/cardModel';
import { visibilitySql, accessOf, type Viewer } from './visibility';
import { countryKey } from '../models/countryModel';
import { cityKey } from '../models/cityModel';
import { countryScope } from './countryExplorer';

// Every salesperson spends at least 30 minutes a day in the big list of leads. The system gives each of them one country
// (a city for the domestic team) to explore that day, at random: not one of the last few days, except a place where
// customers rated above 5 are waiting - those can come back sooner, and are more likely to be picked.
export const EXPLORE_MINUTES = 30;

export interface ExploreToday {
  day: string;
  country: string;
  market: 'export' | 'domestic';
  leads: number;
  strong: number;
  minutes: number;
  target: number;
  done: boolean;
}

const today = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });

function read(userId: number, day: string): ExploreToday | null {
  const r = db.prepare('SELECT * FROM daily_explore WHERE user_id = ? AND day = ?').get(userId, day) as { country: string; market: string; minutes: number; done: number } | undefined;
  if (!r) return null;
  return { day, country: r.country, market: r.market === 'domestic' ? 'domestic' : 'export', leads: 0, strong: 0, minutes: r.minutes, target: EXPLORE_MINUTES, done: !!r.done };
}

function counts(viewer: Viewer, market: 'export' | 'domestic', place: string) {
  const params: Record<string, string | number> = { place };
  const vis = visibilitySql(viewer, params);
  const col = market === 'domestic' ? 'city' : 'country';
  const base = `${market === 'domestic' ? "market = 'domestic'" : "market != 'domestic'"} AND ${col} = @place${vis ? ` AND ${vis}` : ''}`;
  const leads = (db.prepare(`SELECT COUNT(*) AS n FROM cards WHERE ${base} AND ${SQL_LEADS}`).get(params) as { n: number }).n;
  const strong = (db.prepare(`SELECT COUNT(*) AS n FROM cards WHERE ${base} AND COALESCE(${SQL_RATING}, 0) > 5`).get(params) as { n: number }).n;
  return { leads, strong };
}

// The places this person may be sent to: only the countries (cities, for the domestic team) they are responsible for - their own, those an admin
// granted them and, in Manager mode, those of their team. An admin has no limit. A place nobody gave them is never suggested.
function allowed(viewer: Viewer, market: 'export' | 'domestic'): ((place: string) => boolean) {
  if (viewer.role === 'admin') return () => true;
  if (market === 'domestic') { const c = accessOf(viewer).cities; return (p) => c.has(cityKey(p)); }
  const keys = countryScope(viewer) ?? new Set<string>();
  return (p) => keys.has(countryKey(p));
}

function poolOf(viewer: Viewer): { market: 'export' | 'domestic'; pool: { place: string; n: number; strong: number | null }[] } {
  const market: 'export' | 'domestic' = viewer.market === 'domestic' ? 'domestic' : 'export';
  const col = market === 'domestic' ? 'city' : 'country';
  const params: Record<string, string | number> = {};
  const vis = visibilitySql(viewer, params);
  const ok = allowed(viewer, market);
  const rows = db
    .prepare(`SELECT ${col} AS place, COUNT(*) AS n, SUM(CASE WHEN COALESCE(${SQL_RATING}, 0) > 5 THEN 1 ELSE 0 END) AS strong FROM cards
              WHERE ${market === 'domestic' ? "market = 'domestic'" : "market != 'domestic'"} AND ${col} IS NOT NULL AND ${col} != '' AND ${SQL_LEADS}${vis ? ` AND ${vis}` : ''}
              GROUP BY ${col}`)
    .all(params) as { place: string; n: number; strong: number | null }[];
  return { market, pool: rows.filter((r) => ok(r.place)) };
}

// For the country list on the sprint page: the same places as the suggestion.
export function explorePlaces(viewer: Viewer): string[] {
  return poolOf(viewer).pool.map((p) => p.place).sort((x, y) => x.localeCompare(y));
}

function draw(viewer: Viewer, day: string, skip: Set<string>): { place: string; market: 'export' | 'domestic' } | null {
  {
    const { market, pool } = poolOf(viewer);
    if (!pool.length) return null;
    const free = pool.filter((p) => !skip.has(p.place));
    if (!free.length) return null;
    const span = Math.max(0, Math.min(pool.length - 1, 14));
    const recent = new Set(
      (db.prepare("SELECT country FROM daily_explore WHERE user_id = ? AND day != ? AND day >= date(?, ?) ").all(viewer.id, day, day, `-${span} day`) as { country: string }[]).map((r) => r.country)
    );
    // countries where customers above 5 wait can come back; the others wait for their turn
    const withStrong = new Map<string, number>();
    for (const p of pool) withStrong.set(p.place, counts(viewer, market, p.place).strong);
    let eligible = free.filter((p) => !recent.has(p.place) || (withStrong.get(p.place) ?? 0) > 0);
    if (!eligible.length) eligible = free;
    const weights = eligible.map((p) => 1 + Math.min(5, withStrong.get(p.place) ?? 0));
    let pick = Math.random() * weights.reduce((a, b) => a + b, 0);
    let chosen = eligible[0];
    for (let i = 0; i < eligible.length; i += 1) {
      pick -= weights[i];
      if (pick <= 0) { chosen = eligible[i]; break; }
    }
    return { place: chosen.place, market };
  }
}

// Today's place to explore for this person: kept for the whole day once drawn.
export function exploreToday(viewer: Viewer, guard = false): ExploreToday | null {
  const day = today();
  let row = read(viewer.id, day);
  if (!row) {
    const d = draw(viewer, day, new Set());
    if (!d) return null;
    db.prepare('INSERT OR IGNORE INTO daily_explore (user_id, day, country, market) VALUES (?, ?, ?, ?)').run(viewer.id, day, d.place, d.market);
    row = read(viewer.id, day);
  }
  if (!row) return null;
  const c = counts(viewer, row.market, row.country);
  // nothing left to go through there (all rated or deleted): that place is finished, so move on instead of showing it again
  if (c.leads === 0 && !row.done && !guard) {
    const nx = exploreNext(viewer, true);
    if (nx) return nx;
    db.prepare('UPDATE daily_explore SET done = 1 WHERE user_id = ? AND day = ?').run(viewer.id, day);
    return { ...row, done: true, leads: 0, strong: c.strong };
  }
  return { ...row, leads: c.leads, strong: c.strong };
}

// The minutes spent today (the timer on the page adds them).
export function addExploreMinutes(viewer: Viewer, minutes: number): ExploreToday | null {
  const day = today();
  const m = Math.max(0, Math.min(240, Math.round(minutes)));
  if (m > 0) db.prepare('UPDATE daily_explore SET minutes = MIN(600, minutes + ?), done = CASE WHEN minutes + ? >= ? THEN 1 ELSE done END WHERE user_id = ? AND day = ?').run(m, m, EXPLORE_MINUTES, viewer.id, day);
  return exploreToday(viewer);
}

// For the team page: who has done their 30 minutes today.
export function exploreByUser(day = today()): Map<number, { country: string; minutes: number; done: boolean }> {
  const rows = db.prepare('SELECT user_id, country, minutes, done FROM daily_explore WHERE day = ?').all(day) as { user_id: number; country: string; minutes: number; done: number }[];
  return new Map(rows.map((r) => [r.user_id, { country: r.country, minutes: r.minutes, done: !!r.done }]));
}

// Finished today's place: move on to the next one (never one already finished today). Returns null when there is none left.
export function exploreNext(viewer: Viewer, guard = false): ExploreToday | null {
  const day = today();
  const r = db.prepare('SELECT country, done, finished FROM daily_explore WHERE user_id = ? AND day = ?').get(viewer.id, day) as { country: string; done: number; finished: string } | undefined;
  if (!r) return exploreToday(viewer, guard);
  const skip = new Set((r.finished ? r.finished.split('|') : []).concat(r.country));
  const d = draw(viewer, day, skip);
  if (!d) return null;
  db.prepare('UPDATE daily_explore SET country = ?, market = ?, minutes = 0, done = 0, finished = ? WHERE user_id = ? AND day = ?').run(d.place, d.market, [...skip].join('|'), viewer.id, day);
  return exploreToday(viewer, guard);
}

// The places finished today (for the congratulation on the home page).
export function exploreFinished(viewer: Viewer): string[] {
  const r = db.prepare('SELECT finished FROM daily_explore WHERE user_id = ? AND day = ?').get(viewer.id, today()) as { finished: string } | undefined;
  return r?.finished ? r.finished.split('|') : [];
}
