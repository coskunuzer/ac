import { db } from '../db/connection';
import { exhibitionModel } from '../models/exhibitionModel';
import { settingsModel } from '../models/settingsModel';
import { accountOfSapAny } from './perfAnalytics';

// The sales pipeline of a customer record.
//  - Mode A, no SAP number (a prospect): six stages, and three exit states off to the side (on hold, lost, disqualified).
//  - Mode B, a SAP number (a customer): the account health, worked out from the days since the last invoice on the ledger.
// The old "stage" column (lead, contacted, interested, quoted, customer, lost) is kept in step, because lists and filters still use it.

export const PIPELINE_STAGES = ['New lead', 'Contacted', 'Qualified', 'Samples / Matching', 'Offer / Negotiation', 'Won (first order)'];
export const LOST_REASONS = ['Price', 'Their price target is well below our prices', 'Lead Time', 'Payment Terms', 'Color Match / Quality', 'Competitor', 'Unresponsive'];
export const DISQUALIFY_REASONS = ['Not a Target Industry', 'Below MOQ', 'Bad Credit / Risk', 'Duplicate / Invalid Data'];
export const FIXED_SOURCES = [
  'Trade Fair - IWF Atlanta', 'Trade Fair - SICAM', 'Trade Fair - Interzum / Other', 'AI Lead Scoring / Outbound', 'Website / Inbound Inquiry', 'Referral / Distributor', 'Direct Contact / Cold Call',
];

// the spec's seven values, and a "Trade Fair - <name>" for every fair already in the app
export function leadSources(): string[] {
  const fairs = exhibitionModel.listAll().map((e) => e.name).filter((n) => !/^(direct contacts|domestic customers)$/i.test(n)).map((n) => `Trade Fair - ${n}`);
  return [...FIXED_SOURCES, ...fairs.filter((f) => !FIXED_SOURCES.includes(f))];
}

const LEGACY: Record<number, string> = { 1: 'lead', 2: 'contacted', 3: 'interested', 4: 'interested', 5: 'quoted', 6: 'customer' };
export const legacyStage = (n: number): string => LEGACY[n] ?? 'lead';

// a stage moved the old way (the offer was sent, a note was logged): the new stage follows (never backwards inside "qualified / samples")
export function followLegacyStage(cardId: number): void {
  const c = db.prepare('SELECT stage, pipeline_stage FROM cards WHERE id = ?').get(cardId) as { stage: string | null; pipeline_stage: number | null } | undefined;
  if (!c) return;
  const map: Record<string, number> = { lead: 1, contacted: 2, interested: 3, quoted: 5, customer: 6 };
  const mapped = c.stage ? map[c.stage] : 1;
  if (!mapped) return;
  const keep = c.pipeline_stage === 4 && mapped === 3;
  if (!keep && c.pipeline_stage !== mapped) db.prepare('UPDATE cards SET pipeline_stage = ? WHERE id = ?').run(mapped, cardId);
}

// ---- Mode B: the account health -------------------------------------------------------------------------------------------------------
export type HealthState = 'active' | 'reorder' | 'at_risk' | 'inactive' | 'unknown';
export interface Health { state: HealthState; days: number | null; lastInvoice: string | null; status: 'prospect' | 'active' | 'inactive' | 'former' | 'customer'; overdue: boolean; orders: { production: number; waiting: number; ready: number; currency: string }; softened: boolean; mode: string }

// how open orders count for the health: off = only the invoices (the spec), note = the same colour but a note about the orders, soften = a customer with an order on its way counts as active (normal)
export const healthOrdersMode = (): 'off' | 'note' | 'soften' => {
  const v = settingsModel.get('health_orders_mode');
  return v === 'off' || v === 'note' ? v : 'soften';
};
const NO_ORDERS = { production: 0, waiting: 0, ready: 0, currency: 'EUR' };

const todayIso = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });

export function healthOf(sap: string | null | undefined): Health {
  const s = (sap ?? '').trim();
  const mode = healthOrdersMode();
  if (!s) return { state: 'unknown', days: null, lastInvoice: null, status: 'prospect', overdue: false, orders: NO_ORDERS, softened: false, mode };
  const a = accountOfSapAny(s);
  const orders = a ? { production: a.backlogValue, waiting: a.waitingValue, ready: a.readyValue, currency: a.currency } : NO_ORDERS;
  const open = orders.production + orders.waiting + orders.ready > 0;
  const last = a?.lastInvoice ?? null;
  if (!last) return { state: 'unknown', days: null, lastInvoice: null, status: 'customer', overdue: !!a && a.overdue > 0.5, orders, softened: false, mode };
  const days = Math.round((Date.parse(todayIso()) - Date.parse(last)) / 86_400_000);
  let state: HealthState = days <= 60 ? 'active' : days <= 90 ? 'reorder' : days <= 180 ? 'at_risk' : 'inactive';
  let softened = false;
  // a customer who already has a new order in the system is a normal, active customer: no warning flag (the order is the proof)
  if (mode === 'soften' && open && state !== 'active') { state = 'active'; softened = true; }
  const status: Health['status'] = softened || days <= 180 ? 'active' : days <= 365 ? 'inactive' : 'former';
  return { state, days, lastInvoice: last, status, overdue: !!a && a.overdue > 0.5, orders, softened, mode };
}
