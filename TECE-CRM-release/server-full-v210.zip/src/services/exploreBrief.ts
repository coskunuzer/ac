import { db } from '../db/connection';
import { env } from '../config/env';
import { SQL_LEADS, SQL_RATING } from '../models/cardModel';
import { visibilitySql, type Viewer } from './visibility';
import { blockedReason } from './aiGate';

// What the person sees on the card of the day about the country (export) or the city (domestic team): OUR numbers there, counted from the list
// (everything the person may see), and a short text of the AI about the place and what could be improved. The text is general knowledge of the AI,
// not a research: it is marked so, and kept for three weeks per place.
export interface Brief {
  place: string;
  market: 'export' | 'domestic';
  numbers: { customers: number; existing: number; leads: number; strong: number; neverContacted: number; offered: number; offerNoSample: number };
  improve: string[];
  text: { situation: string; economy: string; opportunity: string } | null;
}

const GEMINI_URL = process.env.GEMINI_BASE_URL || 'https://generativelanguage.googleapis.com/v1beta/models'; // (the gate sends it to DeepSeek)
const MODEL = 'gemini-3.6-flash';

function numbersFor(viewer: Viewer, market: 'export' | 'domestic', place: string): Brief['numbers'] {
  const params: Record<string, string | number> = { place };
  const vis = visibilitySql(viewer, params);
  const col = market === 'domestic' ? 'city' : 'country';
  const base = `${market === 'domestic' ? "market = 'domestic'" : "market != 'domestic'"} AND ${col} = @place${vis ? ` AND ${vis}` : ''}`;
  const n = (extra: string) => (db.prepare(`SELECT COUNT(*) AS n FROM cards WHERE ${base}${extra ? ` AND ${extra}` : ''}`).get(params) as { n: number }).n;
  const touched = "EXISTS (SELECT 1 FROM activities a WHERE a.card_id = cards.id AND a.imported = 0 AND a.type IN ('note','call','visit','meeting','sample','offer','thank_you','documents','email'))";
  const offered = "EXISTS (SELECT 1 FROM offers_sent o WHERE o.card_id = cards.id AND o.kind = 'offer')";
  const sample = "EXISTS (SELECT 1 FROM activities s WHERE s.card_id = cards.id AND s.type = 'sample')";
  return {
    customers: n(''), existing: n("stage = 'customer'"), leads: n(SQL_LEADS), strong: n(`COALESCE(${SQL_RATING}, 0) > 5`),
    neverContacted: n(`NOT ${touched}`), offered: n(offered), offerNoSample: n(`${offered} AND NOT ${sample}`),
  };
}

// what could be improved: plain rules over the numbers (no AI)
function improvements(n: Brief['numbers'], place: string): string[] {
  const out: string[] = [];
  if (n.customers === 0) return [`No customer in ${place} yet: start with the biggest names of the lead list and ask for a distributor.`];
  if (n.existing === 0) out.push(`Nobody buys from us in ${place} yet: ${n.strong ? `start with the ${n.strong} rated above 5` : 'rate the leads and start with the best'}.`);
  if (n.neverContacted > 0) out.push(`${n.neverContacted} of ${n.customers} have never been contacted.`);
  if (n.strong > 0 && n.offered < n.strong) out.push(`${n.strong} customers are rated above 5 but only ${n.offered} got an offer.`);
  if (n.offerNoSample > 0) out.push(`${n.offerNoSample} got an offer but no sample: ask if the colour matches.`);
  if (n.leads > 20) out.push(`${n.leads} leads wait: rate them, add a web site, delete the useless ones.`);
  return out.slice(0, 4);
}

async function writeText(place: string, market: 'export' | 'domestic', lang: string, n: Brief['numbers']): Promise<Brief['text']> {
  if (!env.geminiApiKey || blockedReason()) return null;
  const turkish = lang === 'tr';
  const prompt = [
    `You write a short briefing for a salesperson of TECE (a Turkish maker of edgebanding for furniture panels: PVC, ABS, PP, melamine, veneer) who will spend 30 minutes with the leads of ${market === 'domestic' ? `the city of ${place} in Turkey` : `the country ${place}`}.`,
    `Write in ${turkish ? 'Turkish' : 'English'}. Use only general knowledge you are sure of; where unsure, say so. No invented numbers or names of companies. Each part at most 3 short sentences.`,
    market === 'domestic'
      ? 'Parts: situation (the city: its industry, whether it is a furniture, kitchen, door or panel centre, the organised industrial zones), economy (the economic picture of the city and the region, how it matters for furniture and panel makers), opportunity (what kinds of customers to look for there and how to approach them).'
      : 'Parts: situation (the furniture and wood-panel industry of the country, how it is supplied, imports from Turkey or the EU), economy (the economic picture: growth, currency, construction and housing, anything that helps or hurts a buyer of edgebanding), opportunity (what kinds of customers to look for and how to approach them).',
    `Our own numbers there (for context, do not repeat them): ${n.customers} customers and leads, ${n.existing} buy from us, ${n.strong} rated above 5.`,
  ].join('\n');
  const schema = { type: 'OBJECT', properties: { situation: { type: 'STRING' }, economy: { type: 'STRING' }, opportunity: { type: 'STRING' } }, required: ['situation', 'economy', 'opportunity'] };
  try {
    const res = await fetch(`${GEMINI_URL}/${MODEL}:generateContent`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-goog-api-key': env.geminiApiKey },
      body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { temperature: 0.3, responseMimeType: 'application/json', responseSchema: schema } }),
      signal: AbortSignal.timeout(60000),
    });
    if (!res.ok) return null;
    const data = (await res.json()) as { candidates?: { content?: { parts?: { text?: string }[] } }[] };
    const j = JSON.parse((data.candidates?.[0]?.content?.parts ?? []).map((p) => p.text ?? '').join('')) as Record<string, unknown>;
    if (!j.situation) return null;
    return { situation: String(j.situation), economy: String(j.economy ?? ''), opportunity: String(j.opportunity ?? '') };
  } catch {
    return null;
  }
}

export async function briefFor(viewer: Viewer, place: string, market: 'export' | 'domestic', lang: string): Promise<Brief> {
  const numbers = numbersFor(viewer, market, place);
  const l = lang === 'tr' ? 'tr' : 'en';
  const row = db.prepare("SELECT body FROM explore_briefs WHERE place = ? AND market = ? AND lang = ? AND made_at >= datetime('now', '-21 days')").get(place, market, l) as { body: string } | undefined;
  let text: Brief['text'] = null;
  if (row) { try { text = JSON.parse(row.body); } catch { text = null; } }
  if (!text) {
    text = await writeText(place, market, l, numbers);
    if (text) db.prepare("INSERT OR REPLACE INTO explore_briefs (place, market, lang, body, made_at) VALUES (?, ?, ?, ?, datetime('now'))").run(place, market, l, JSON.stringify(text));
  }
  return { place, market, numbers, improve: improvements(numbers, place), text };
}
