import { db } from '../db/connection';
import { colorBySap } from './colorDb';
import type { DocLine } from './customerPrices';
import type { PriceBook } from './priceBook';

// An OLD customer keeps their own prices (learned from their SAP proformas). Their offer must show exactly those prices, not the price list with a percentage on it:
// every row of the offer (product, thickness, solid / woodgrain / high gloss ...) takes the price per m² this customer paid for that kind of product, and the
// per-meter columns follow from it (the workbook's own formula: price per m² x width / 1000). Rows the customer never bought are left out of their offer.
export interface OwnPrices {
  currency: 'EUR' | 'USD';
  // 'Sheet!D13' -> price per m² (their price, with their usual general discount / increase)
  cellOverrides: Record<string, number>;
  rows: { sheet: string; row: number; cell: string; label: string; price: number; m2: number }[];
}

const TAB_OF: Record<string, string> = { PVC: 'PVC M2+22', ABS: 'ABS M2+22' };
// the price categories of the colour database: 1 plain, 2 wood, 3 high gloss plain, 4 high gloss wood, 5 intense plain
const CODE_OF: Record<number, string> = { 1: 'SC', 5: 'IC', 2: 'W', 3: 'HG', 4: 'HW' };

const thick = (s: string): number | null => { const m = /(\d+)[,.](\d+)\s*mm/.exec(s); return m ? Number(`${m[1]}.${m[2]}`) : null; };

export function ownPrices(book: PriceBook, cardId: number): OwnPrices | null {
  const docs = db.prepare("SELECT currency, adjust_pct, lines_json FROM customer_price_docs WHERE card_id = ? ORDER BY COALESCE(doc_date, '') DESC, proforma_no DESC").all(cardId) as { currency: string; adjust_pct: number; lines_json: string }[];
  if (!docs.length) return null;
  const currency = docs[0].currency === 'USD' ? 'USD' : 'EUR';
  // the rows of the offer, found by tab + thickness + kind + preglued
  const rowOf = new Map<string, { sheet: string; row: number; label: string; col: string }>();
  for (const sec of book.catalog) {
    if (!Object.values(TAB_OF).includes(sec.sheet)) continue;
    const priceCol = sec.columns.find((c) => /square meter|m²/i.test(c.label))?.id;
    if (!priceCol) continue;
    for (const r of sec.rows) {
      const code = /\|\s*(?:PVC|ABS)\s+(SC|IC|W|HG|HW)\b/.exec(r.name)?.[1];
      const t = thick(r.detail);
      if (!code || t === null) continue;
      rowOf.set(`${sec.sheet}|${t.toFixed(2)}|${code}|${/pregl/i.test(r.detail) ? 1 : 0}`, { sheet: sec.sheet, row: r.id, label: `${r.name} ${r.detail}`, col: priceCol });
    }
  }
  // the newest proforma that has a row wins; inside it the price is weighted by m²
  const got = new Map<string, { price: number; m2: number; at: number }>();
  docs.forEach((d, idx) => {
    if (d.currency !== currency) return;
    const adj = 1 + d.adjust_pct / 100;
    const acc = new Map<string, { w: number; m2: number }>();
    for (const l of JSON.parse(d.lines_json) as DocLine[]) {
      let product = ''; let cat: number | null = null;
      try { const c = colorBySap(l.sap).color; product = c?.productType ?? ''; cat = c?.categoryNo ?? null; } catch { /* the colour database may be empty */ }
      if (!product) product = l.sap.endsWith('.012') ? 'PVC' : l.sap.endsWith('.042') ? 'ABS' : '';
      const tab = TAB_OF[product]; const code = cat ? CODE_OF[cat] : undefined;
      if (!tab || !code || l.thickness == null || !(l.priceM2 > 0)) continue;
      const glued = /pre-?\s?glu|hot\s?melt|adhesive/i.test(`${l.description} ${l.reference}`) ? 1 : 0;
      const key = `${tab}|${l.thickness.toFixed(2)}|${code}|${glued}`;
      const m2 = l.meters && l.width ? (l.meters * l.width) / 1000 : 1;
      const a = acc.get(key) ?? { w: 0, m2: 0 };
      a.w += l.priceM2 * adj * m2; a.m2 += m2; acc.set(key, a);
    }
    for (const [key, a] of acc) if (!got.has(key) && a.m2 > 0) got.set(key, { price: a.w / a.m2, m2: a.m2, at: idx });
  });
  const cellOverrides: Record<string, number> = {}; const rows: OwnPrices['rows'] = [];
  for (const [key, g] of got) {
    const r = rowOf.get(key);
    if (!r) continue;
    const price = Math.round(g.price * 10000) / 10000;
    cellOverrides[`${r.sheet}!${r.col}${r.row}`] = price;
    rows.push({ sheet: r.sheet, row: r.row, cell: `${r.sheet}!${r.col}${r.row}`, label: r.label, price, m2: Math.round(g.m2) });
  }
  return rows.length ? { currency, cellOverrides, rows } : null;
}
