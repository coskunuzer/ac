import { db } from '../db/connection';
import { askJson } from './perfActions';
import { logEvent, sendShipMail, shipConfig } from './shipMail';
import { renderTemplate } from './shipTemplates';

// Reading the price from a forwarder's reply, and what a person can do with a quote. The price is read by rules first; DeepSeek is asked only when the rules are unsure,
// and anything that does not add up goes to manual review (a person types the price). Nothing is accepted by itself.

// ---- the new text of a reply (without the quoted earlier mails) --------------------------------------------------------------------------------
export function newText(raw: string): string {
  const out: string[] = [];
  for (const l of String(raw ?? '').replace(/\r/g, '').split('\n')) {
    const t = l.trim();
    if (/^(on .{5,120} wrote:|.{5,120} tarihinde .{5,120} yazdı:?|-{2,}\s*(original message|orijinal mesaj|forwarded message)|_{8,}|from:\s.+|kimden:\s.+|von:\s.+|de:\s.+@)/i.test(t)) break;
    if (/^>/.test(t)) continue;
    out.push(l);
  }
  return out.join('\n').trim();
}

// ---- money --------------------------------------------------------------------------------------------------------------------------------
const CURRENCY: Record<string, string> = { EUR: 'EUR', '€': 'EUR', EURO: 'EUR', EUROS: 'EUR', AVRO: 'EUR', USD: 'USD', $: 'USD', 'US$': 'USD', DOLLAR: 'USD', DOLLARS: 'USD', DOLAR: 'USD', TRY: 'TRY', TL: 'TRY', '₺': 'TRY', YTL: 'TRY' };
export const normCurrency = (v: string | null | undefined): string | null => CURRENCY[String(v ?? '').trim().toUpperCase()] ?? null;
export function parseAmount(raw: string): number | null {
  let s = raw.replace(/\s/g, '');
  if (!/\d/.test(s)) return null;
  const dot = s.lastIndexOf('.'), comma = s.lastIndexOf(',');
  if (dot > -1 && comma > -1) s = dot > comma ? s.replace(/,/g, '') : s.replace(/\./g, '').replace(',', '.');
  else if (comma > -1) s = /,\d{1,2}$/.test(s) ? s.replace(/,(?=\d{1,2}$)/, '.').replace(/,/g, '') : s.replace(/,/g, '');
  else if (dot > -1 && /^\d{1,3}(\.\d{3})+$/.test(s)) s = s.replace(/\./g, '');
  const n = Number(s);
  return Number.isFinite(n) ? n : null;
}

export type ReviewReason = 'parse_failed' | 'total_mismatch' | 'invalid_currency' | 'invalid_amount';
export interface Parsed { base: number; extras: { description: string; amount: number }[]; total: number; currency: string; excluded: string[] }
export function check(p: Parsed | null): { reason: ReviewReason | null; currency: string } {
  if (!p || !(p.total > 0)) return { reason: 'parse_failed', currency: normCurrency(p?.currency) ?? '' };
  if (p.base < 0 || (p.extras ?? []).some((e) => e.amount < 0)) return { reason: 'invalid_amount', currency: p.currency };
  const cur = normCurrency(p.currency);
  if (!cur) return { reason: 'invalid_currency', currency: p.currency ?? '' };
  const sum = p.base + (p.extras ?? []).reduce((a, e) => a + e.amount, 0);
  if (Math.abs(sum - p.total) > 1) return { reason: 'total_mismatch', currency: cur };
  return { reason: null, currency: cur };
}

// costs the supplier says are not in the price ("+ YDG", "T1 hariç", "gümrük masrafları alıcıya aittir")
const OUT_WORDS = 'ydg|t1|gümrük|gumruk|customs|port|liman|terminal|sigorta|insurance|vergi|vat|kdv|yakıt|fuel';
export function excludedOf(text: string): string[] {
  const t = text.replace(/\s+/g, ' ');
  const found: string[] = [];
  const add = (w: string) => { const v = w.trim().toUpperCase().replace('GUMRUK', 'GÜMRÜK'); if (v && !found.includes(v)) found.push(v); };
  const priced = (idx: number, len: number) => /^\s*[:=-]?\s*(\d[\d.,]*\s*(eur|euro|€|usd|\$|tl|₺)|(eur|euro|€|usd|\$|tl|₺)\s*\d)/i.test(t.slice(idx + len, idx + len + 24));
  for (const m of t.matchAll(new RegExp(`\\+\\s*(${OUT_WORDS})(?![a-zçğıöşü])`, 'gi'))) if (!priced(m.index ?? 0, m[0].length)) add(m[1]);
  for (const m of t.matchAll(new RegExp(`(${OUT_WORDS})[^.]{0,30}?(hariç|haric|excluded|not included|alıcıya|aliciya|buyer)`, 'gi'))) add(m[1]);
  for (const m of t.matchAll(new RegExp(`(excluding|hariç|haric|without)\\s+(${OUT_WORDS})`, 'gi'))) add(m[2]);
  return found;
}

// ---- the rules ---------------------------------------------------------------------------------------------------------------------------------
const CUR_RE = '(eur|euro|euros|avro|€|usd|us\\$|\\$|dolar|dollars?|try|tl|₺|ytl)';
export function readByRules(text: string): { parsed: Parsed | null; sure: boolean } {
  const t = newText(text);
  const money: { amount: number; cur: string; at: number }[] = [];
  // Turkish endings are fine: "15000 eurodur", "500 euroya"
  const SUFFIX = '(?:d[uüıi]r|y[aeı]|[’\']?[dt][aeıi])?';
  const re = new RegExp(`(\\d[\\d.,]*\\d|\\d)\\s*${CUR_RE}${SUFFIX}(?![a-zçğıöşü])|${CUR_RE}\\s*(\\d[\\d.,]*\\d|\\d)`, 'gi');
  for (const m of t.matchAll(re)) {
    const amountRaw = m[1] ?? m[4]; const cur = normCurrency(m[2] ?? m[3]);
    const amount = amountRaw ? parseAmount(amountRaw) : null;
    if (amount && cur && amount >= 20) money.push({ amount, cur, at: m.index ?? 0 });
  }
  const excluded = excludedOf(t);
  if (!money.length) return { parsed: null, sure: false };
  // an amount the sender says to ADD ("500 euro ekleyin", "+ 500 EUR", "plus 500 USD") is an extra on top of the main price
  const isExtra = (x: { at: number }) => /(\+|ekle|ilave|add|plus|extra|ek )[^\d]{0,25}$/i.test(t.slice(Math.max(0, x.at - 30), x.at)) || /^[^\d]{0,12}(ekle|ilave|eklenir|added|extra|ek masraf)/i.test(t.slice(x.at + 6, x.at + 40));
  if (money.length >= 2 && money.every((x) => x.cur === money[0].cur)) {
    const extra = money.filter(isExtra), main = money.filter((x) => !isExtra(x));
    const mainAmounts = [...new Set(main.map((x) => x.amount))];
    if (extra.length && mainAmounts.length === 1) {
      const base = mainAmounts[0], ex = extra.map((x, i) => ({ description: `Ek masraf ${i + 1}`, amount: x.amount }));
      return { parsed: { base, extras: ex, total: base + ex.reduce((a, e) => a + e.amount, 0), currency: money[0].cur, excluded }, sure: true };
    }
  }
  const cur = money[0].cur;
  const same = money.filter((x) => x.cur === cur);
  const distinct = [...new Set(same.map((x) => x.amount))];
  if (money.some((x) => x.cur !== cur)) return { parsed: null, sure: false };
  if (distinct.length === 1) {
    const total = distinct[0];
    return { parsed: { base: total, extras: [], total, currency: cur, excluded }, sure: true };
  }
  // several amounts: sure only when one is labelled as the total and the others add up to it
  const label = /(toplam|total|all[- ]?in|genel toplam)[^\d€$]{0,20}(\d[\d.,]*\d|\d)/i.exec(t);
  // the label can come before the number ("toplam 1.720 EUR") or after it ("1.510 EUR all-in")
  const after = new RegExp(`(\\d[\\d.,]*\\d|\\d)\\s*${CUR_RE}?\\s*(all[- ]?in|total|toplam)`, 'i').exec(t);
  const candidates = [label ? parseAmount(label[2]) : null, after ? parseAmount(after[1]) : null];
  const labelled = candidates.find((x) => x !== null && distinct.includes(x)) ?? null;
  if (labelled && distinct.includes(labelled)) {
    const parts = distinct.filter((x) => x !== labelled).sort((a, b) => b - a);
    const sum = parts.reduce((a, b) => a + b, 0);
    if (parts.length && Math.abs(sum - labelled) <= 1) return { parsed: { base: parts[0], extras: parts.slice(1).map((a, i) => ({ description: `Ek masraf ${i + 1}`, amount: a })), total: labelled, currency: cur, excluded }, sure: true };
  }
  return { parsed: null, sure: false };
}

// ---- the AI (DeepSeek) for what the rules cannot read ----------------------------------------------------------------------------------------------------
const SCHEMA = { type: 'OBJECT', properties: { base: { type: 'NUMBER' }, extras: { type: 'ARRAY', items: { type: 'OBJECT', properties: { description: { type: 'STRING' }, amount: { type: 'NUMBER' } }, required: ['description', 'amount'] } }, total: { type: 'NUMBER' }, currency: { type: 'STRING' }, excluded: { type: 'ARRAY', items: { type: 'STRING' } } }, required: ['base', 'extras', 'total', 'currency', 'excluded'] };
export async function readByAi(text: string): Promise<Parsed | null> {
  const body = text.replace(/\s+/g, ' ').trim().slice(0, 6000);
  if (!body) return null;
  const j = await askJson(
    `You read a freight forwarder's price quotation e-mail (Turkish or English, often badly spelled, with Turkish endings like "eurodur"). Extract: base = the main freight price; extras = every additional amount the supplier says to add or charges on top (description, amount), for example "ayrıca ... 500 euro ekleyin" means an extra of 500; total = base plus all extras that have an amount; currency = EUR, USD or TRY; excluded = costs the supplier says are NOT included or are payable separately but gives NO amount for (for example YDG, T1, customs). Example: "bizim fiyatimiz 15000 eurodur. ayrica fiyata fob ve diger masraflar degildir. Onlar icinde 500 euro ekleyin" gives base 15000, extras [{Diğer masraflar (FOB vb.), 500}], total 15500, EUR, excluded []. Use only the supplier's newest message, never the quoted earlier mails or the signature. If there is no price, answer total 0. Never guess a number that is not written.\n\n---EMAIL---\n${body}\n---END---`,
    SCHEMA
  );
  if (!j) return null;
  const arrN = (v: unknown) => (Array.isArray(v) ? v : []);
  return { base: Number(j.base) || 0, total: Number(j.total) || 0, currency: String(j.currency ?? ''), extras: arrN(j.extras).map((e: any) => ({ description: String(e?.description ?? ''), amount: Number(e?.amount) || 0 })), excluded: arrN(j.excluded).map(String) };
}

// the whole reading: rules, then the AI, then the checks. The result says whether a person has to look.
export async function readPrice(text: string, attachmentText = ''): Promise<{ parsed: Parsed | null; reason: ReviewReason | null; currency: string; by: 'rules' | 'ai' | 'none' }> {
  const all = `${newText(text)}\n${attachmentText}`.trim();
  const rules = readByRules(all);
  // the AI reads the mail first (a person writes in many ways: "15000 eurodur, ayrıca 500 euro ekleyin"); the rules are the fallback when the AI is not available
  let ai: Parsed | null = null;
  try { ai = await readByAi(all); } catch { ai = null; }
  if (ai && ai.total > 0) {
    // the total is always base + the extras with an amount: never trust a total that does not add up
    const sum = ai.base + ai.extras.reduce((a, e) => a + e.amount, 0);
    if (Math.abs(sum - ai.total) > 1) ai.total = sum;
    const c = check(ai);
    ai.excluded = [...new Set([...ai.excluded.map((x) => x.toUpperCase()), ...excludedOf(all)])];
    return { parsed: ai, reason: c.reason, currency: c.currency, by: 'ai' };
  }
  if (rules.parsed && rules.sure) { const c = check(rules.parsed); if (!c.reason) return { parsed: rules.parsed, reason: null, currency: c.currency, by: 'rules' }; }
  if (ai) {
    const c = check(ai);
    ai.excluded = [...new Set([...ai.excluded.map((x) => x.toUpperCase()), ...excludedOf(all)])];
    return { parsed: ai, reason: c.reason, currency: c.currency, by: 'ai' };
  }
  return { parsed: rules.parsed, reason: rules.parsed ? check(rules.parsed).reason : 'parse_failed', currency: rules.parsed?.currency ?? '', by: rules.parsed ? 'rules' : 'none' };
}

// ---- a reply becomes a quote ---------------------------------------------------------------------------------------------------------------------------
interface MsgRow { id: number; request_id: string | null; address: string | null; body: string | null; attachments: string; status: string; forwarder_id: number | null; in_reply_to: string | null; msg_key: string | null }
export async function applyReply(messageId: number): Promise<'read' | 'review' | 'late' | 'skipped'> {
  const m = db.prepare("SELECT * FROM ship_messages WHERE id = ? AND direction = 'in' AND status IN ('stored', 'review')").get(messageId) as MsgRow | undefined;
  if (!m || !m.request_id) return 'skipped';
  const req = db.prepare('SELECT * FROM ship_requests WHERE id = ?').get(m.request_id) as { id: string; status: string; archived: number } | undefined;
  if (!req || req.status !== 'open') { db.prepare("UPDATE ship_messages SET status = 'late' WHERE id = ? AND status = 'stored'").run(m.id); return 'late'; }
  const fw = m.forwarder_id ? (db.prepare('SELECT * FROM ship_request_fw WHERE request_id = ? AND forwarder_id = ?').get(m.request_id, m.forwarder_id) as { forwarder_name: string } | undefined) : undefined;
  const files = JSON.parse(m.attachments || '[]') as { name: string; text?: string }[];
  const r = await readPrice(m.body ?? '', files.map((f) => f.text ?? '').join('\n'));
  const p = r.parsed;
  const out = p ? [...new Set(p.excluded)].join(', ') || null : null;
  const hasOut = !!out;
  const manual = !!r.reason;
  const name = fw?.forwarder_name ?? m.address ?? 'Firma';
  const existing = db.prepare("SELECT id, status FROM ship_quotes WHERE request_id = ? AND forwarder_id IS ? AND status IN ('open', 'countered', 'manual') ORDER BY id DESC LIMIT 1").get(m.request_id, m.forwarder_id) as { id: number; status: string } | undefined;
  const base = p && !manual ? p.base : p?.base ?? null;
  const total = p && !manual && !hasOut ? p.total : p && !manual && hasOut ? null : p?.total ?? null;
  let quoteId: number;
  db.exec('BEGIN');
  try {
    const vals = [base, p ? p.extras.reduce((a, e) => a + e.amount, 0) : null, total, r.currency || null, out, manual ? 'manual' : 'open', r.reason];
    if (existing) {
      db.prepare("UPDATE ship_quotes SET base = ?, extra = ?, total = ?, currency = ?, out_items = ?, status = ?, review_reason = ?, sender_email = ?, updated_at = datetime('now') WHERE id = ?").run(...vals, m.address, existing.id);
      quoteId = existing.id;
    } else quoteId = Number(db.prepare('INSERT INTO ship_quotes (request_id, forwarder_id, forwarder_name, sender_email, base, extra, total, currency, out_items, status, review_reason) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').run(m.request_id, m.forwarder_id, name, m.address, ...vals).lastInsertRowid);
    db.prepare("UPDATE ship_messages SET status = ?, quote_id = ? WHERE id = ?").run(manual ? 'review' : 'read', quoteId, m.id);
    if (m.forwarder_id) db.prepare("UPDATE ship_request_fw SET answered_at = COALESCE(answered_at, datetime('now')) WHERE request_id = ? AND forwarder_id = ?").run(m.request_id, m.forwarder_id);
    db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); throw e; }
  logEvent(m.request_id, quoteId, existing ? 'revised' : 'quoted', manual ? `${name}: yanıt geldi, fiyat okunamadı (${r.reason}); elle girilmeli` : `${name}: ${total ?? p?.base} ${r.currency}${hasOut ? ` (all-in değil: ${out})` : ''} · ${r.by === 'ai' ? 'DeepSeek ile okundu' : 'kurallarla okundu'}`, null);
  return manual ? 'review' : 'read';
}
export async function processStored(limit = 20): Promise<number> {
  const rows = db.prepare("SELECT id FROM ship_messages WHERE direction = 'in' AND status = 'stored' ORDER BY id LIMIT ?").all(limit) as { id: number }[];
  let n = 0;
  for (const r of rows) {
    try { await applyReply(r.id); n++; } catch (e) {
      console.error('Reading a shipping reply failed:', r.id, e);
      db.prepare("UPDATE ship_messages SET attempts = attempts + 1, error = ?, status = CASE WHEN attempts >= 3 THEN 'failed' ELSE status END WHERE id = ?").run(String((e as Error).message).slice(0, 200), r.id);
    }
  }
  return n;
}

// ---- e-mails to the forwarders (Turkish; English when the firm writes English) ----------------------------------------------------------------------------------
interface Req { id: string; mode: string; country: string | null; city: string | null }
const MODE_SUBJ: Record<string, string> = { Karayolu: 'Karayolu Taşımacılığı', 'Denizyolu (Konteyner)': 'Denizyolu Taşımacılığı (Konteyner)', 'Denizyolu (LCL)': 'Denizyolu Taşımacılığı (LCL)', Havayolu: 'Havayolu Taşımacılığı' };
export const subjectOf = (r: Req) => `TECE - Navlun Talebi #${r.id}${r.country ? ` - ${r.country}` : ''} - ${MODE_SUBJ[r.mode] ?? r.mode}`;
const money = (n: number, c: string) => `${Number(n).toLocaleString('tr-TR')} ${c}`;
const sign = (en: boolean) => (en ? 'Best regards,\nTECE Dekor - Operations' : 'Saygılarımızla,\nTECE Dekor - Operasyon');
const hello = (name: string, en: boolean) => (en ? `Dear ${name},` : `Sayın ${name},`);
type FwInfo = { name: string; contact: string | null; lang: string; emails: string[] };
// the wording lives in shipTemplates.ts (the defaults) and can be changed by an admin on the Nakliye page
const vars = (r: Req, f: FwInfo, extra: Record<string, string> = {}): Record<string, string> => {
  const en = f.lang === 'en';
  return { hello: hello(f.contact || (en ? f.name : 'yetkili'), en), sign: sign(en), id: r.id, place: [r.city, r.country].filter(Boolean).join(', '), ...extra };
};
export const TEXT = {
  acceptance: (r: Req, f: FwInfo, total: number, cur: string) => renderTemplate('acceptance', f.lang, vars(r, f, { total: money(total, cur) })),
  rejection: (r: Req, f: FwInfo) => renderTemplate('rejection', f.lang, vars(r, f)),
  cancel: (r: Req, f: FwInfo) => renderTemplate('cancel', f.lang, vars(r, f)),
  counter: (r: Req, f: FwInfo, price: number, cur: string) => renderTemplate('counter', f.lang, vars(r, f, { price: money(price, cur) })),
  allIn: (r: Req, f: FwInfo) => renderTemplate('allIn', f.lang, vars(r, f)),
  reminder: (r: Req, f: FwInfo) => renderTemplate('reminder', f.lang, vars(r, f)),
};

interface QuoteRow { id: number; request_id: string; forwarder_id: number | null; forwarder_name: string; base: number | null; total: number | null; currency: string | null; out_items: string | null; status: string; sender_email: string | null }
const quote = (id: number) => db.prepare('SELECT * FROM ship_quotes WHERE id = ?').get(id) as QuoteRow | undefined;
const request = (id: string) => db.prepare('SELECT * FROM ship_requests WHERE id = ?').get(id) as (Req & { status: string }) | undefined;
function fwInfo(requestId: string, forwarderId: number | null, name: string): FwInfo {
  const f = db.prepare('SELECT * FROM ship_request_fw WHERE request_id = ? AND forwarder_id = ?').get(requestId, forwarderId ?? -1) as { forwarder_name: string; emails: string; lang: string } | undefined;
  const person = forwarderId ? (db.prepare('SELECT contact FROM ship_forwarders WHERE id = ?').get(forwarderId) as { contact: string | null } | undefined)?.contact ?? null : null;
  return { name: f?.forwarder_name ?? name, contact: person, lang: f?.lang ?? 'tr', emails: f ? (JSON.parse(f.emails) as string[]) : [] };
}
const lastInbound = (requestId: string, forwarderId: number | null) => (db.prepare("SELECT msg_key FROM ship_messages WHERE direction = 'in' AND request_id = ? AND forwarder_id IS ? AND msg_key IS NOT NULL ORDER BY id DESC LIMIT 1").get(requestId, forwarderId) as { msg_key: string } | undefined)?.msg_key ?? null;
async function mailTo(q: QuoteRow | { request_id: string; forwarder_id: number | null; forwarder_name: string; id?: number; sender_email?: string | null }, kind: string, body: (r: Req, f: FwInfo) => string, userId: number | null) {
  const r = request(q.request_id)!;
  const f = fwInfo(q.request_id, q.forwarder_id, q.forwarder_name);
  const to = f.emails.length ? f.emails : q.sender_email ? [q.sender_email] : [];
  if (!to.length) return;
  await sendShipMail({ to, subject: `Re: ${subjectOf(r)}`, body: body(r, f), inReplyTo: lastInbound(q.request_id, q.forwarder_id), kind, requestId: q.request_id, forwarderId: q.forwarder_id, quoteId: 'id' in q ? q.id ?? null : null, userId });
}

// a person accepts one price: everybody else is answered, those who stayed silent are told the request is closed, and the manager gets the summary
export async function acceptQuote(quoteId: number, userId: number): Promise<{ ok: boolean; error?: string }> {
  const q = quote(quoteId);
  if (!q) return { ok: false, error: 'Teklif bulunamadı.' };
  const r = request(q.request_id)!;
  if (r.status !== 'open') return { ok: false, error: 'Bu talep zaten kapalı.' };
  if (!(q.total && q.total > 0) || q.status !== 'open') return { ok: false, error: 'Bu teklif kabul edilemez: all-in fiyat yok veya durumu uygun değil.' };
  const others = db.prepare("SELECT * FROM ship_quotes WHERE request_id = ? AND id != ? AND status IN ('open', 'countered', 'manual')").all(q.request_id, q.id) as unknown as QuoteRow[];
  const silent = db.prepare('SELECT * FROM ship_request_fw WHERE request_id = ? AND cancelled_at IS NULL AND sent_at IS NOT NULL AND forwarder_id NOT IN (SELECT forwarder_id FROM ship_quotes WHERE request_id = ? AND forwarder_id IS NOT NULL)').all(q.request_id, q.request_id) as unknown as { forwarder_id: number; forwarder_name: string }[];
  db.exec('BEGIN');
  try {
    db.prepare("UPDATE ship_quotes SET status = 'accepted', updated_at = datetime('now') WHERE id = ?").run(q.id);
    db.prepare("UPDATE ship_quotes SET status = 'rejected', updated_at = datetime('now') WHERE request_id = ? AND id != ? AND status IN ('open', 'countered', 'manual')").run(q.request_id, q.id);
    db.prepare("UPDATE ship_requests SET status = 'closed', closed_at = datetime('now'), accepted_quote = ? WHERE id = ?").run(q.id, q.request_id);
    db.prepare("UPDATE ship_request_fw SET cancelled_at = datetime('now') WHERE request_id = ? AND forwarder_id IN (" + (silent.map(() => '?').join(',') || 'NULL') + ')').run(q.request_id, ...silent.map((s) => s.forwarder_id));
    db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); throw e; }
  logEvent(q.request_id, q.id, 'accepted', `${q.forwarder_name}: ${money(q.total, q.currency ?? '')} kabul edildi`, userId);
  await mailTo(q, 'acceptance', (rq, f) => TEXT.acceptance(rq, f, q.total!, q.currency ?? ''), userId);
  for (const o of others) { logEvent(q.request_id, o.id, 'rejected', `${o.forwarder_name}: reddedildi (başka firma seçildi)`, userId); await mailTo(o, 'rejection', (rq, f) => TEXT.rejection(rq, f), userId); }
  for (const s of silent) await mailTo({ request_id: q.request_id, forwarder_id: s.forwarder_id, forwarder_name: s.forwarder_name }, 'cancel', (rq, f) => TEXT.cancel(rq, f), userId);
  await managerSummary(q.request_id, q.id);
  return { ok: true };
}

async function managerSummary(requestId: string, acceptedId: number): Promise<void> {
  const to = shipConfig().managerEmail;
  if (!to) return;
  const r = request(requestId) as unknown as { id: string; country: string | null; city: string | null; pallets: number | null; weight_kg: number | null; mode: string };
  const qs = db.prepare('SELECT * FROM ship_quotes WHERE request_id = ? ORDER BY total IS NULL, total').all(requestId) as unknown as QuoteRow[];
  const acc = qs.find((x) => x.id === acceptedId)!;
  const hist = db.prepare('SELECT created_at, text FROM ship_events WHERE request_id = ? ORDER BY id').all(requestId) as { created_at: string; text: string }[];
  const body = [`Nakliye kabul edildi: #${requestId}`, `Varış: ${[r.city, r.country].filter(Boolean).join(', ')} · ${r.mode} · ${r.pallets ?? '-'} palet · ${r.weight_kg ?? '-'} kg`, `Kabul edilen: ${acc.forwarder_name} - ${money(acc.total ?? 0, acc.currency ?? '')}`, '', 'Diğer teklifler:', ...qs.filter((x) => x.id !== acceptedId).map((x) => `- ${x.forwarder_name}: ${x.total ? money(x.total, x.currency ?? '') : x.base ? `${money(x.base, x.currency ?? '')} (all-in değil: ${x.out_items ?? '?'})` : 'fiyat yok'}`), '', 'Geçmiş:', ...hist.map((h) => `${h.created_at.slice(0, 16)}  ${h.text}`)].join('\n');
  await sendShipMail({ to: [to], subject: `[Nakliye Onaylandı] #${requestId} - ${acc.forwarder_name} - ${money(acc.total ?? 0, acc.currency ?? '')}`, body, kind: 'summary', requestId, quoteId: acceptedId });
}

export async function rejectQuote(quoteId: number, userId: number): Promise<{ ok: boolean; error?: string }> {
  const q = quote(quoteId);
  if (!q || !['open', 'manual', 'countered'].includes(q.status)) return { ok: false, error: 'Teklif uygun durumda değil.' };
  db.prepare("UPDATE ship_quotes SET status = 'rejected', updated_at = datetime('now') WHERE id = ?").run(q.id);
  logEvent(q.request_id, q.id, 'rejected', `${q.forwarder_name}: reddedildi`, userId);
  await mailTo(q, 'rejection', (rq, f) => TEXT.rejection(rq, f), userId);
  return { ok: true };
}
export async function counterQuote(quoteId: number, price: number, userId: number): Promise<{ ok: boolean; error?: string }> {
  const q = quote(quoteId);
  if (!q || q.status !== 'open' || !(price > 0)) return { ok: false, error: 'Karşı teklif gönderilemez.' };
  db.prepare("UPDATE ship_quotes SET status = 'countered', counter = ?, updated_at = datetime('now') WHERE id = ?").run(price, q.id);
  logEvent(q.request_id, q.id, 'countered', `${q.forwarder_name}: karşı teklif ${money(price, q.currency ?? '')}`, userId);
  await mailTo(q, 'counter', (rq, f) => TEXT.counter(rq, f, price, q.currency ?? ''), userId);
  return { ok: true };
}
export async function askAllIn(quoteId: number, userId: number): Promise<{ ok: boolean }> {
  const q = quote(quoteId);
  if (!q) return { ok: false };
  logEvent(q.request_id, q.id, 'question', `${q.forwarder_name}: all-in fiyat soruldu`, userId);
  await mailTo(q, 'question', (rq, f) => TEXT.allIn(rq, f), userId);
  return { ok: true };
}
export function setManualPrice(quoteId: number, price: number, currency: string, userId: number, extra = 0): { ok: boolean; error?: string } {
  const q = quote(quoteId);
  const cur = normCurrency(currency) ?? 'EUR';
  if (!q || !['manual', 'open'].includes(q.status) || !(price > 0)) return { ok: false, error: 'Fiyat kaydedilemedi.' };
  const ex = extra > 0 ? extra : 0;
  db.prepare("UPDATE ship_quotes SET base = ?, extra = ?, total = ?, currency = ?, status = 'open', review_reason = NULL, out_items = NULL, updated_at = datetime('now') WHERE id = ?").run(price, ex, price + ex, cur, q.id);
  db.prepare("UPDATE ship_messages SET status = 'read' WHERE quote_id = ? AND status = 'review'").run(q.id);
  logEvent(q.request_id, q.id, 'manual_price', `${q.forwarder_name}: fiyat elle girildi ${money(price + ex, cur)}${ex ? ` (navlun ${money(price, cur)} + ek ${money(ex, cur)})` : ''}`, userId);
  return { ok: true };
}
// the request is over without choosing anybody
export async function closeRequest(requestId: string, userId: number): Promise<{ ok: boolean }> {
  const r = request(requestId);
  if (!r || r.status !== 'open') return { ok: false };
  const open = db.prepare("SELECT * FROM ship_quotes WHERE request_id = ? AND status IN ('open', 'countered', 'manual')").all(requestId) as unknown as QuoteRow[];
  const silent = db.prepare('SELECT * FROM ship_request_fw WHERE request_id = ? AND cancelled_at IS NULL AND sent_at IS NOT NULL AND forwarder_id NOT IN (SELECT forwarder_id FROM ship_quotes WHERE request_id = ? AND forwarder_id IS NOT NULL)').all(requestId, requestId) as unknown as { forwarder_id: number; forwarder_name: string }[];
  db.prepare("UPDATE ship_requests SET status = 'closed', closed_at = datetime('now') WHERE id = ?").run(requestId);
  db.prepare("UPDATE ship_quotes SET status = 'rejected', updated_at = datetime('now') WHERE request_id = ? AND status IN ('open', 'countered', 'manual')").run(requestId);
  logEvent(requestId, null, 'closed', 'Talep kimse seçilmeden kapatıldı', userId);
  for (const q of open) await mailTo(q, 'cancel', (rq, f) => TEXT.cancel(rq, f), userId);
  for (const s of silent) { db.prepare("UPDATE ship_request_fw SET cancelled_at = datetime('now') WHERE request_id = ? AND forwarder_id = ?").run(requestId, s.forwarder_id); await mailTo({ request_id: requestId, forwarder_id: s.forwarder_id, forwarder_name: s.forwarder_name }, 'cancel', (rq, f) => TEXT.cancel(rq, f), userId); }
  return { ok: true };
}
// one reminder to every firm that has not answered
export async function remindSilent(requestId: string, userId: number): Promise<{ sent: number }> {
  const silent = db.prepare('SELECT * FROM ship_request_fw WHERE request_id = ? AND sent_at IS NOT NULL AND answered_at IS NULL AND reminded_at IS NULL AND cancelled_at IS NULL').all(requestId) as unknown as { forwarder_id: number; forwarder_name: string }[];
  for (const s of silent) {
    db.prepare("UPDATE ship_request_fw SET reminded_at = datetime('now') WHERE request_id = ? AND forwarder_id = ?").run(requestId, s.forwarder_id);
    await mailTo({ request_id: requestId, forwarder_id: s.forwarder_id, forwarder_name: s.forwarder_name }, 'reminder', (rq, f) => TEXT.reminder(rq, f), userId);
  }
  if (silent.length) logEvent(requestId, null, 'reminder', `${silent.length} firmaya hatırlatma gitti`, userId);
  return { sent: silent.length };
}
// an offer given by phone or WhatsApp: the text is saved like a reply and read the same way
export async function pasteReply(requestId: string, forwarderId: number, text: string, userId: number): Promise<{ ok: boolean; error?: string }> {
  const f = db.prepare('SELECT * FROM ship_request_fw WHERE request_id = ? AND forwarder_id = ?').get(requestId, forwarderId) as { forwarder_name: string; emails: string } | undefined;
  if (!f) return { ok: false, error: 'Bu firma bu talepte yok.' };
  const id = Number(db.prepare("INSERT INTO ship_messages (direction, kind, request_id, forwarder_id, address, subject, body, msg_key, status, user_id) VALUES ('in', 'reply', ?, ?, ?, ?, ?, ?, 'stored', ?)")
    .run(requestId, forwarderId, (JSON.parse(f.emails) as string[])[0] ?? null, `(elle girildi) ${f.forwarder_name}`, text.slice(0, 8000), `manual-${Date.now()}-${forwarderId}`, userId).lastInsertRowid);
  await applyReply(id);
  return { ok: true };
}
