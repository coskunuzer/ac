-- Visitors imported from a badge-scanner export (no photo of a paper form).
-- badge_id is the visitor's ID in that export, so uploading the same file again
-- does not create the same visitor twice.
ALTER TABLE cards ADD COLUMN badge_id TEXT;
CREATE INDEX IF NOT EXISTS idx_cards_badge ON cards(exhibition_id, badge_id);
