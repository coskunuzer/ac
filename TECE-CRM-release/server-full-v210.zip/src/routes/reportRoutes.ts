import { Router } from 'express';
import { cardModel, SQL_IMPORTANT, SQL_LEADS, SQL_REACTIVATE } from '../models/cardModel';
import { offerWanted } from '../services/aiInsight';
import { exhibitionModel } from '../models/exhibitionModel';
import { HOT_RATE, reportModel } from '../models/reportModel';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { filterVisible, visibilitySql } from '../services/visibility';
import { db } from '../db/connection';
import { activityModel } from '../models/activityModel';
import { dayRange, getGoals, summaryFor, todayLocal, descendants } from '../services/team';
import type { CardRow } from '../models/cardModel';
import { offerLogModel } from '../models/pricingModels';
import { buildPlan } from '../services/followUpPlan';
import { focusFor } from '../services/focus';
import { secondsBetween } from '../services/usage';
import { renderExhibitionReport } from '../services/exhibitionReport';

const router = Router();

router.use(requireAuth);

// Available to everyone, but scoped differently: admin can view any
// exhibition or all of them combined; a plain staff member always sees only
// the current default exhibition's numbers (confirmed directly by the user:
// "show the default exhibition result to all people. But for admin, show
// all.") - the exhibitionId query param is only honored for admins, so a
// non-admin can't request another exhibition's aggregate by crafting one.
router.get('/visitors-by-country', (req: AuthedRequest, res) => {
  const isAdmin = req.user!.role === 'admin';
  let exhibitionId: number | undefined;
  let exhibitionName: string | null = null;

  // everybody can pick a fair (or all of them); a person's numbers only count the customers they may see
  if (typeof req.query.exhibitionId === 'string') {
    exhibitionId = parseInt(req.query.exhibitionId, 10) || undefined;
    exhibitionName = exhibitionId ? exhibitionModel.findById(exhibitionId)?.name ?? null : null;
    if (exhibitionId && !exhibitionName) return res.status(404).json({ error: 'That fair does not exist.' });
  } else {
    const def = exhibitionModel.findDefault();
    exhibitionId = def?.id;
    exhibitionName = def?.name ?? null;
  }

  // staff count only the customers they may see
  const byCountry = isAdmin
    ? cardModel.countByCountry(exhibitionId)
    : [...filterVisible(req.user!, cardModel.search({ exhibitionId, fairWork: true })).filter((c) => c.stage !== 'lead' && c.market !== 'domestic').reduce((m, c) => (c.country?.trim() ? m.set(c.country.trim(), (m.get(c.country.trim()) ?? 0) + 1) : m), new Map<string, number>())]
        .map(([country, count]) => ({ country, count }))
        .sort((a, b) => b.count - a.count);
  const totalVisitors = byCountry.reduce((sum, row) => sum + row.count, 0);

  res.json({ exhibitionId: exhibitionId ?? null, exhibitionName, byCountry, totalVisitors });
});

// The mission board: the few things worth doing today, and how far they take me toward the daily goal.
router.get('/focus', (req: AuthedRequest, res) => {
  const u = req.user!;
  res.json(focusFor({ id: u.id, role: u.role, display_name: u.display_name, market: u.market }));
});

// The CRM home page: what is in my customer list, what waits for me, and what I did today. Everything is limited to the
// customers this person may see (an admin sees all of them).
router.get('/home', (req: AuthedRequest, res) => {
  const user = req.user!;
  const params: Record<string, string | number> = {};
  const vis = visibilitySql(user, params);
  const and = vis ? ` AND ${vis}` : '';
  const where = vis ? `WHERE ${vis}` : '';

  const stages: Record<string, number> = {};
  for (const r of db.prepare(`SELECT COALESCE(stage, 'visitor') AS stage, COUNT(*) AS n FROM cards ${where} GROUP BY 1`).all(params) as { stage: string; n: number }[]) stages[r.stage] = r.n;
  const total = Object.values(stages).reduce((a, b) => a + b, 0);
  const needsReview = (db.prepare(`SELECT COUNT(*) AS n FROM cards WHERE status = 'needs_review'${and}`).get(params) as { n: number }).n;
  const count = (cond: string) => (db.prepare(`SELECT COUNT(*) AS n FROM cards WHERE ${cond}${and}`).get(params) as { n: number }).n;
  const portfolio = {
    active: count("stage = 'customer'"),
    hot: count(`${SQL_IMPORTANT} AND COALESCE(stage, '') != 'customer'`),
    reactivate: count(SQL_REACTIVATE),
    leadPool: count(SQL_LEADS),
    samplesOpen: count("EXISTS (SELECT 1 FROM activities s WHERE s.card_id = cards.id AND s.type = 'sample' AND s.created_at >= datetime('now', '-14 days')) AND NOT EXISTS (SELECT 1 FROM activities n WHERE n.card_id = cards.id AND n.type IN ('note', 'call', 'visit', 'meeting', 'offer') AND n.created_at > (SELECT MAX(s2.created_at) FROM activities s2 WHERE s2.card_id = cards.id AND s2.type = 'sample'))"),
  };
  const noPerson = user.role === 'admin' ? (db.prepare("SELECT COUNT(*) AS n FROM cards WHERE person IS NULL OR TRIM(person) = ''").get() as { n: number }).n : 0;

  // customers who are being worked on (not the database leads, not the ones who already buy)
  const open = db
    .prepare(`SELECT * FROM cards WHERE (stage IS NULL OR stage IN ('contacted', 'interested', 'quoted'))${and} ORDER BY created_at DESC LIMIT 3000`)
    .all(params) as unknown as CardRow[];
  const ids = new Set(open.map((c) => c.id));
  const plan = buildPlan(open, offerLogModel.listForIdSet(ids));

  const today = todayLocal();
  const { from, to } = dayRange(today);
  const mine = activityModel.between([user.id], from, to);
  const recent = db
    .prepare(`SELECT id, company, name, country, city, market, stage, person, created_at FROM cards ${where} ORDER BY created_at DESC, id DESC LIMIT 6`)
    .all(params);

  // my last 7 days, and how many working days in a row I have noted something
  const dayExpr = "date(datetime(created_at, '+3 hours'))";
  const perDay = db
    .prepare(`SELECT ${dayExpr} AS d, type, COUNT(*) AS n FROM activities WHERE user_id = ? AND imported = 0 AND created_at >= datetime('now', '-70 days') GROUP BY d, type`)
    .all(user.id) as { d: string; type: string; n: number }[];
  const human = ['note', 'call', 'visit', 'meeting', 'sample'];
  const byDay = new Map<string, { contacts: number; visits: number; offers: number; other: number }>();
  for (const r of perDay) {
    const e = byDay.get(r.d) ?? { contacts: 0, visits: 0, offers: 0, other: 0 };
    if (human.includes(r.type)) e.contacts += r.n;
    else if (r.type === 'offer') e.offers += r.n;
    else e.other += r.n;
    if (r.type === 'visit') e.visits += r.n;
    byDay.set(r.d, e);
  }
  const shiftDay = (d: string, by: number) => {
    const x = new Date(`${d}T12:00:00Z`);
    x.setUTCDate(x.getUTCDate() + by);
    return x.toISOString().slice(0, 10);
  };
  const week = Array.from({ length: 7 }, (_, i) => {
    const d = shiftDay(today, i - 6);
    return { date: d, ...(byDay.get(d) ?? { contacts: 0, visits: 0, offers: 0, other: 0 }) };
  });
  let streak = 0;
  for (let d = today, guard = 0; guard < 70; d = shiftDay(d, -1), guard += 1) {
    const dow = new Date(`${d}T12:00:00Z`).getUTCDay();
    if (dow === 0 || dow === 6) continue; // weekends do not break it
    if ((byDay.get(d)?.contacts ?? 0) > 0) streak += 1;
    else if (d !== today) break; // today may still be empty
  }
  // my progress: what I did in the last day, 7 days, 30 days, 6 months and a year
  const periods = [{ key: 'day', days: 1 }, { key: 'week', days: 7 }, { key: 'month', days: 30 }, { key: 'half', days: 182 }, { key: 'year', days: 365 }];
  const yearFrom = dayRange(shiftDay(today, -364)).from;
  const yearActs = activityModel.between([user.id], yearFrom, dayRange(today).to);
  const progress = periods.map((p) => {
    const startDay = shiftDay(today, -(p.days - 1));
    const from = dayRange(startDay).from;
    const inside = yearActs.filter((a) => a.at >= from);
    return {
      key: p.key,
      days: p.days,
      notes: inside.filter((a) => ['note', 'call', 'visit', 'meeting', 'sample'].includes(a.type)).length,
      offers: inside.filter((a) => a.type === 'offer').length,
      newContacts: inside.filter((a) => a.type === 'scan' || a.type === 'created').length,
      appSeconds: secondsBetween([user.id], startDay, today).get(user.id) ?? 0,
    };
  });
  const weekTotals = week.reduce((t, w) => ({ contacts: t.contacts + w.contacts, visits: t.visits + w.visits, offers: t.offers + w.offers }), { contacts: 0, visits: 0, offers: 0 });

  // customers worth a first contact: the AI likes them and nobody has written a note about them yet
  const oppParams: Record<string, string | number> = { ...params, me: user.display_name ?? '' };
  const opportunities = db
    .prepare(
      `SELECT id, company, name, position, email, country, city, market, stage, ai_rate, ai_rate_reason, ai_rate_source, rate FROM cards
       WHERE ai_rate >= 7 AND (stage IS NULL OR stage IN ('lead', 'contacted'))${and}
         AND NOT EXISTS (SELECT 1 FROM activities a WHERE a.card_id = cards.id AND a.type IN ('note', 'call', 'visit', 'meeting', 'sample'))
       ORDER BY (person = @me) DESC, ai_rate DESC, COALESCE(rate, 0) DESC, id LIMIT 8`
    )
    .all(oppParams);

  // for managers: how the team is doing today
  const hasTeam = user.role === 'admin' || !!user.can_oversee || descendants(user.id).length > 0;
  const team = hasTeam
    ? summaryFor(user, today, 1).rows.filter((r) => r.person.id !== user.id).map((r) => ({ id: r.person.id, name: r.person.name, contacts: r.contacts, offers: r.offers, sent: r.sent, newCustomers: r.newCustomers, lastAt: r.lastAt }))
    : [];

  res.json({
    market: user.market,
    goals: getGoals(),
    week,
    weekTotals,
    streak,
    opportunities,
    team,
    today,
    total,
    stages,
    needsReview,
    noPerson,
    portfolio,
    progress,
    plan,
    todayCount: mine.length,
    todayContacts: mine.filter((a) => ['note', 'call', 'visit', 'meeting', 'sample'].includes(a.type)).length,
    recent,
  });
});

// with no fair chosen: the latest real fair that has started (else the next one), not the imported customer base ('Database')
function latestFair(): { id: number; name: string } | null {
  const today = new Date().toISOString().slice(0, 10);
  return (db.prepare("SELECT id, name FROM exhibitions WHERE COALESCE(is_default, 0) = 0 AND COALESCE(is_archived, 0) = 0 AND start_date IS NOT NULL AND start_date <= ? ORDER BY start_date DESC LIMIT 1").get(today) as { id: number; name: string } | undefined)
    ?? (db.prepare("SELECT id, name FROM exhibitions WHERE COALESCE(is_default, 0) = 0 AND COALESCE(is_archived, 0) = 0 AND start_date IS NOT NULL ORDER BY start_date LIMIT 1").get() as { id: number; name: string } | undefined) ?? null;
}
// Everything the dashboard shows in one call. Everybody can pick the fair (or all of them); what they see is only
// their own customers - an admin sees everything.
router.get('/dashboard', (req: AuthedRequest, res) => {
  const isAdmin = req.user!.role === 'admin';
  let exhibitionId: number | undefined;
  let exhibitionName: string | null = null;

  if (typeof req.query.exhibitionId === 'string') {
    // a chosen fair, or '' = all of them
    exhibitionId = parseInt(req.query.exhibitionId, 10) || undefined;
    exhibitionName = exhibitionId ? exhibitionModel.findById(exhibitionId)?.name ?? null : null;
    if (exhibitionId && !exhibitionName) return res.status(404).json({ error: 'That fair does not exist.' });
  } else if (isAdmin) {
    const def = latestFair() ?? exhibitionModel.findDefault();
    exhibitionId = def?.id;
    exhibitionName = def?.name ?? null;
  } else {
    const def = latestFair() ?? exhibitionModel.findDefault();
    if (!def) {
      return res.json({ exhibitionId: null, exhibitionName: null, empty: true });
    }
    exhibitionId = def.id;
    exhibitionName = def.name;
  }

  // Staff see the numbers of their own customers only; an admin sees everything.
  const visible = cardModel.search({ exhibitionId, visibleTo: req.user!, fairWork: true }).filter((c) => c.stage !== 'lead' && c.market !== 'domestic');
  const ids = isAdmin ? undefined : visible.map((c) => c.id);
  const idSet = new Set(visible.map((c) => c.id));

  // the contacts of this fair that are mine, and every e-mail that went to them (thank-you notes, offers)
  const sentLog = offerLogModel.listForIdSet(idSet);
  const byId = new Map(visible.map((c) => [c.id, c]));
  const lastSent = new Map<string, string>();
  for (const o of sentLog) if (!lastSent.has(`${o.cardId}|${o.kind}`) || o.sentAt > lastSent.get(`${o.cardId}|${o.kind}`)!) lastSent.set(`${o.cardId}|${o.kind}`, o.sentAt);
  const contacts = visible.slice(0, 1000).map((c) => ({
    id: c.id, company: c.company, name: c.name, position: c.position, country: c.country, email: c.email, rate: c.rate, aiRate: c.ai_rate, stage: c.stage,
    thankYouAt: lastSent.get(`${c.id}|thank_you`) ?? c.thank_you_sent_at ?? null,
    offerAt: lastSent.get(`${c.id}|offer`) ?? null,
  }));
  const emails = sentLog
    .filter((o) => o.kind === 'thank_you' || o.kind === 'offer' || o.kind === 'documents')
    .sort((a, b) => (a.sentAt < b.sentAt ? 1 : -1))
    .slice(0, 500)
    .map((o) => ({ id: o.id, cardId: o.cardId, company: byId.get(o.cardId)?.company ?? null, name: byId.get(o.cardId)?.name ?? null, kind: o.kind, sentAt: o.sentAt, subject: o.subject, sentBy: o.sentBy, percent: o.percent, pages: o.pages.map((p) => p.title) }));

  // "Don't miss anything": every step that is still open for this fair, each with a link to exactly those customers
  const sampleIds = new Set(
    visible.length
      ? (db.prepare(`SELECT DISTINCT card_id FROM activities WHERE type = 'sample' AND card_id IN (${visible.map((c) => c.id).join(',')})`).all() as { card_id: number }[]).map((r) => r.card_id)
      : []
  );
  const offerSent = new Set(sentLog.filter((o) => o.kind === 'offer').map((o) => o.cardId));
  const rating = (c: CardRow) => c.rate ?? (c.ai_rate_source === 'ai' ? c.ai_rate : null);
  const hasMail = (c: CardRow) => !!(c.email ?? '').trim();
  const sentThanks = (c: CardRow) => !!c.thank_you_sent_at || lastSent.has(`${c.id}|thank_you`);
  const base = exhibitionId ? `exhibitionId=${exhibitionId}&` : '';
  const step = (key: string, label: string, hint: string, count: number, query: string) => ({ key, label, hint, count, link: `/records?${base}${query}` });
  const todo = [
    step('review', 'Check the forms the AI read', 'Open each form, correct what is wrong and press save.', visible.filter((c) => c.status === 'needs_review').length, 'status=needs_review'),
    step('owner', 'Give every visitor to a sales person', 'Nobody looks after these visitors yet, so only admins see them.', visible.filter((c) => !(c.person ?? '').trim()).length, 'person=%E2%80%94'),
    step('noemail', 'Find the e-mail address', 'No thank-you can be sent without it. Ask on the phone, look at the web site.', visible.filter((c) => !hasMail(c)).length, 'hasEmail=no'),
    step('thanks', 'Send the thank-you e-mail', 'Visitors with an e-mail address who were not thanked yet.', visible.filter((c) => hasMail(c) && !sentThanks(c)).length, 'thankYou=not&hasEmail=yes'),
    step('rate', 'Rate the visitors', 'Give each visitor your own rating (1-10): the best ones are found by it.', visible.filter((c) => c.rate === null || c.rate === undefined).length, 'rated=none'),
    step('offer', 'Send an offer to the good visitors', 'Rated 5 or more (or in conversation) and no offer sent yet.', visible.filter((c) => (rating(c) ?? 0) >= 5 && !offerSent.has(c.id)).length, 'rated=hot&offer=not'),
    step('wanted', 'Send the offer they asked for', 'They asked for an offer on the form or in the notes.', visible.filter((c) => offerWanted(c) && !offerSent.has(c.id)).length, 'offer=wanted'),
    step('sample', 'Send the sample or colour card', 'An offer went out, but no sample or colour card is noted yet.', visible.filter((c) => offerSent.has(c.id) && !sampleIds.has(c.id)).length, 'offer=sent&sample=missing'),
  ];
  const quality = {
    rated: visible.filter((c) => c.rate !== null && c.rate !== undefined).length,
    unrated: visible.filter((c) => c.rate === null || c.rate === undefined).length,
    hot: visible.filter((c) => (rating(c) ?? 0) >= 5).length,
    offersToUnrated: visible.filter((c) => offerSent.has(c.id) && (c.rate === null || c.rate === undefined)).length,
    offersSent: visible.filter((c) => offerSent.has(c.id)).length,
    samples: visible.filter((c) => sampleIds.has(c.id)).length,
    captured: visible.length,
  };

  res.json({
    exhibitionId: exhibitionId ?? null,
    exhibitionName,
    todo,
    quality,
    contacts,
    emails,
    hotRate: HOT_RATE,
    totals: reportModel.totals(exhibitionId, ids),
    byDay: reportModel.byDay(exhibitionId, ids),
    byCountry: reportModel.byColumn('country', exhibitionId, ids),
    byInterest: reportModel.byInterest(exhibitionId, ids),
    byStaff: reportModel.byStaff(exhibitionId, ids),
    // what to do next with whom, from the notes and from what has been sent
    plan: buildPlan(visible, offerLogModel.listForIdSet(idSet)),
  });
});

// Everybody's own result for one fair as a PDF: how many visitors, by country, and what was done
// with each - only the customers they may see (an admin gets all of them, as on the Export page).
router.get('/my-result', async (req: AuthedRequest, res) => {
  const exhibitionId = parseInt(String(req.query.exhibitionId ?? ''), 10);
  const exhibition = Number.isInteger(exhibitionId) ? exhibitionModel.findById(exhibitionId) : undefined;
  if (!exhibition) return res.status(404).json({ error: 'Choose an exhibition first.' });
  const isAdmin = req.user!.role === 'admin';
  const cards = cardModel.search({ exhibitionId: exhibition.id, visibleTo: req.user!, fairWork: true }).filter((c) => c.stage !== 'lead' && c.market !== 'domestic');
  if (cards.length === 0) return res.status(404).json({ error: 'You have no customers in this exhibition yet.' });
  const ids = new Set(cards.map((c) => c.id));
  const pdf = await renderExhibitionReport({
    exhibition,
    cards,
    offers: offerLogModel.listForIdSet(ids),
    generatedAt: new Date(),
    forPerson: isAdmin ? null : req.user!.display_name,
  });
  const slug = (s: string) => s.normalize('NFD').replace(/\p{Diacritic}/gu, '').replace(/[^A-Za-z0-9]+/g, '-').replace(/^-|-$/g, '');
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="${slug(exhibition.name) || 'exhibition'}-${slug(req.user!.display_name || req.user!.username) || 'my'}-result.pdf"`);
  res.send(pdf);
});

export default router;
