import { db } from '../db/connection';

export type UserRole = 'admin' | 'user';
export type Market = 'export' | 'domestic';
export const asMarket = (v: unknown): Market => (v === 'domestic' ? 'domestic' : 'export');

export interface User {
  id: number;
  username: string;
  password_hash: string;
  role: UserRole;
  display_name: string | null;
  email: string | null;
  email_template_subject: string | null;
  email_template_body: string | null;
  photo_path: string | null;
  is_active: number;
  // An assistant is only a name and an email address that gets copied on
  // thank-you emails: no login, and never offered as a "Person".
  is_assistant: number;
  // with is_assistant: a sales person without a login (offered as responsible person)
  is_sales_contact: number;
  // this person's own signature layout (empty = the company default)
  signature_style: string | null;
  // a signature this person wrote or edited themselves (empty = the layout above)
  signature_text: string | null;
  // who this person reports to (the team report goes up this chain)
  manager_id: number | null;
  // the offer design this person prefers: '' = the company's, 'tece' = new, 'classic' = as in Excel
  offer_style: string | null;
  // the language of the screens: 'en', 'tr', or empty = the company's default
  ui_language: string | null;
  // the team this person works in: 'export' (countries) or 'domestic' (cities of Turkey)
  market: Market;
  // may watch what everybody does (read-only overview page)
  can_oversee: number;
  can_ship: number;
  // Lines of the signature under every email this person sends
  job_title: string | null;
  mobile: string | null;
  office_phone: string | null;
  // an assistant with a login: the person they work for (they see that person's customers and activities, nobody else's)
  assists_id: number | null;
  // 'light', 'dark' or empty (= follow the computer)
  theme: string | null;
  // NULL = sales (or admin); 'quality' = the quality (KYS) person; 'dept' = the head of a department: both see the complaints module only; 'brand' = the brand manager (works through the Permissions page: Brand dashboard, leads, campaigns)
  area: string | null;
  created_at: string;
}

export type PublicUser = Omit<User, 'password_hash'>;

const PUBLIC_COLUMNS =
  'id, username, role, display_name, email, email_template_subject, email_template_body, photo_path, is_active, is_assistant, is_sales_contact, signature_style, signature_text, manager_id, offer_style, ui_language, market, can_oversee, can_ship, job_title, mobile, office_phone, assists_id, theme, area, created_at';

export interface UserUpdateInput {
  displayName?: string | null;
  email?: string | null;
  emailTemplateSubject?: string | null;
  emailTemplateBody?: string | null;
  // undefined keeps the stored value; an empty string clears it
  jobTitle?: string | null;
  mobile?: string | null;
  officePhone?: string | null;
  signatureStyle?: string | null;
  signatureText?: string | null;
  managerId?: number | null;
  offerStyle?: string | null;
  market?: Market;
  canOversee?: boolean;
  canShip?: boolean;
  uiLanguage?: string | null;
}

const keepOrSet = (next: string | null | undefined, current: string | null) =>
  next === undefined ? current : (next ?? '').trim().slice(0, 120) || null;

export const userModel = {
  findByUsername(username: string): User | undefined {
    return db.prepare('SELECT * FROM users WHERE username = ?').get(username) as User | undefined;
  },

  findById(id: number): User | undefined {
    return db.prepare('SELECT * FROM users WHERE id = ?').get(id) as User | undefined;
  },

  create(input: {
    username: string;
    passwordHash: string;
    role: UserRole;
    displayName?: string;
    email?: string;
    isAssistant?: boolean;
    isSalesContact?: boolean;
    market?: Market;
    canOversee?: boolean;
  }): PublicUser {
    const result = db
      .prepare('INSERT INTO users (username, password_hash, role, display_name, email, is_assistant, is_sales_contact, market, can_oversee) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
      .run(input.username, input.passwordHash, input.role, input.displayName || null, input.email || null, input.isAssistant || input.isSalesContact ? 1 : 0, input.isSalesContact ? 1 : 0, asMarket(input.market), input.canOversee ? 1 : 0);
    return this.findPublicById(result.lastInsertRowid as number)!;
  },

  update(id: number, input: UserUpdateInput): PublicUser | undefined {
    const existing = this.findPublicById(id);
    if (!existing) return undefined;
    db.prepare(
      `UPDATE users SET display_name = @displayName, email = @email,
       email_template_subject = @emailTemplateSubject, email_template_body = @emailTemplateBody,
       job_title = @jobTitle, mobile = @mobile, office_phone = @officePhone, signature_style = @signatureStyle,
       signature_text = @signatureText, manager_id = @managerId, offer_style = @offerStyle,
       market = @market, can_oversee = @canOversee, can_ship = @canShip, ui_language = @uiLanguage
       WHERE id = @id`
    ).run({
      id,
      uiLanguage: input.uiLanguage === undefined ? existing.ui_language : input.uiLanguage === 'en' || input.uiLanguage === 'tr' ? input.uiLanguage : null,
      market: input.market === undefined ? existing.market : asMarket(input.market),
      canOversee: input.canOversee === undefined ? existing.can_oversee : input.canOversee ? 1 : 0,
      canShip: input.canShip === undefined ? existing.can_ship : input.canShip ? 1 : 0,
      displayName: input.displayName ?? existing.display_name,
      email: input.email ?? existing.email,
      emailTemplateSubject: input.emailTemplateSubject ?? existing.email_template_subject,
      emailTemplateBody: input.emailTemplateBody ?? existing.email_template_body,
      jobTitle: keepOrSet(input.jobTitle, existing.job_title),
      mobile: keepOrSet(input.mobile, existing.mobile),
      officePhone: keepOrSet(input.officePhone, existing.office_phone),
      signatureStyle: input.signatureStyle === undefined ? existing.signature_style : (input.signatureStyle || null),
      managerId: input.managerId === undefined ? existing.manager_id : input.managerId,
      offerStyle: input.offerStyle === undefined ? existing.offer_style : input.offerStyle === 'tece' || input.offerStyle === 'classic' ? input.offerStyle : null,
      signatureText: input.signatureText === undefined ? existing.signature_text : (input.signatureText ?? '').replace(/\r\n/g, '\n').trim().slice(0, 1500) || null,
    });
    return this.findPublicById(id);
  },

  // A person without a login (an assistant) gets one, and works for somebody: username, password and whom they assist.
  giveLogin(id: number, username: string, passwordHash: string, assistsId: number | null): PublicUser | undefined {
    db.prepare('UPDATE users SET username = ?, password_hash = ?, is_assistant = 0, is_sales_contact = 0, assists_id = ? WHERE id = ?').run(username, passwordHash, assistsId, id);
    return this.findPublicById(id);
  },

  setArea(id: number, area: string | null): void {
    db.prepare('UPDATE users SET area = ? WHERE id = ?').run(area === 'quality' || area === 'dept' || area === 'brand' ? area : null, id);
  },

  setTheme(id: number, theme: string | null): void {
    db.prepare('UPDATE users SET theme = ? WHERE id = ?').run(theme === 'light' || theme === 'dark' ? theme : null, id);
  },

  setAssists(id: number, assistsId: number | null): void {
    db.prepare('UPDATE users SET assists_id = ? WHERE id = ?').run(assistsId, id);
  },

  updatePhoto(id: number, photoPath: string): PublicUser | undefined {
    db.prepare('UPDATE users SET photo_path = ? WHERE id = ?').run(photoPath, id);
    return this.findPublicById(id);
  },

  findPublicById(id: number): PublicUser | undefined {
    return db.prepare(`SELECT ${PUBLIC_COLUMNS} FROM users WHERE id = ?`).get(id) as PublicUser | undefined;
  },

  listAll(): PublicUser[] {
    return db.prepare(`SELECT ${PUBLIC_COLUMNS} FROM users ORDER BY created_at DESC`).all() as unknown as PublicUser[];
  },

  // Everyone who can be the responsible "Person": staff who log in, plus sales
  // people without a login (the Person dropdown, the AI's person list...).
  listActive(): PublicUser[] {
    return db
      .prepare(`SELECT ${PUBLIC_COLUMNS} FROM users WHERE is_active = 1 AND assists_id IS NULL AND (is_assistant = 0 OR is_sales_contact = 1) ORDER BY display_name`)
      .all() as unknown as PublicUser[];
  },

  listAssistants(): PublicUser[] {
    return db
      .prepare(`SELECT ${PUBLIC_COLUMNS} FROM users WHERE is_active = 1 AND is_assistant = 1 AND is_sales_contact = 0 ORDER BY display_name`)
      .all() as unknown as PublicUser[];
  },

  findByDisplayName(name: string): PublicUser | undefined {
    return db
      .prepare(`SELECT ${PUBLIC_COLUMNS} FROM users WHERE display_name = ? AND is_active = 1`)
      .get(name) as PublicUser | undefined;
  },

  // Deletes a person. What they wrote stays: every record that points at them is handed to `heirId` (or left without an author when that column allows it).
  remove(id: number, heirId: number): void {
    const tables = db.prepare("SELECT name FROM sqlite_master WHERE type = 'table'").all() as { name: string }[];
    db.exec('BEGIN');
    try {
      for (const { name } of tables) {
        const fks = db.prepare(`PRAGMA foreign_key_list("${name}")`).all() as { table: string; from: string; on_delete: string }[];
        for (const fk of fks.filter((f) => f.table === 'users' && f.on_delete !== 'CASCADE')) {
          const notNull = (db.prepare(`PRAGMA table_info("${name}")`).all() as { name: string; notnull: number }[]).find((c) => c.name === fk.from)?.notnull;
          db.prepare(`UPDATE "${name}" SET "${fk.from}" = ? WHERE "${fk.from}" = ?`).run(notNull ? heirId : null, id);
        }
      }
      db.prepare('UPDATE users SET manager_id = NULL WHERE manager_id = ?').run(id);
      db.prepare('DELETE FROM users WHERE id = ?').run(id);
      db.exec('COMMIT');
    } catch (err) {
      db.exec('ROLLBACK');
      throw err;
    }
  },

  setActive(id: number, isActive: boolean): void {
    db.prepare('UPDATE users SET is_active = ? WHERE id = ?').run(isActive ? 1 : 0, id);
  },

  setPasswordHash(id: number, passwordHash: string): void {
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(passwordHash, id);
  },
};
