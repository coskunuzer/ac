/* eslint-disable @typescript-eslint/no-explicit-any */
import { db } from '../db/connection';
import { memoTables, memoTablesBy } from '../db/dataVersion';
import { countryMap } from './intelCountry';
import { windows } from './intelEngine';
import { canonicalCountry, countryKey } from '../models/countryModel';
import { accessOf, myCountryKeys, visibilityFor, type Viewer } from './visibility';
import { viewMode } from './viewMode';
import { hasIntel, type Perms } from './permissions';
import { benchAvg, indexSeries, notCounted, priceIndexOf, windows12, type PriceIdx, type Win12 } from './priceIndex';

// What a customer (or a whole country) bought: read from the Sales intelligence summary (intel_fact, see 084_sales_intel.sql), never written.
// Everything is worked out here, so the page only draws. The answer for a set of SAP accounts is kept until one of the tables it is made from
// is written (db/dataVersion.ts): a customer page opens in a millisecond after the first time.

const INTEL = ['intel_fact', 'intel_mat', 'intel_cust', 'intel_events', 'intel_excluded', 'color_codes'] as const;
const r0 = Math.round, r2 = (v: number) => Math.round(v * 100) / 100, r3 = (v: number) => Math.round(v * 1000) / 1000;
const per = (eur: number, q: number) => (q > 0.0001 ? r3(eur / q) : null);
const dec = (mat: string) => String(mat).split('.')[0];
const monthsBack = (ym: string, n: number): string => { let y = +ym.slice(0, 4), m = +ym.slice(5, 7) - n; while (m < 1) { m += 12; y--; } return `${y}-${String(m).padStart(2, '0')}`; };
const quarterOf = (ym: string) => `${ym.slice(0, 4)}-Q${Math.floor((+ym.slice(5, 7) - 1) / 3) + 1}`;

// ---------------------------------------------------------------- who may see what
type U = Viewer & { perms?: Perms | null };
// sales figures: an admin, a person without a permissions row (as before), a person whose row has "ledger", or Sales intelligence (which shows them anyway)
export const maySeeSales = (u: U): boolean => u.role === 'admin' || !u.perms || u.perms.money.includes('ledger') || hasIntel(u as never);
export function mayOpenCountry(u: U, country: string): boolean {
  if (u.role === 'admin' || hasIntel(u as never)) return true;
  if (!maySeeSales(u)) return false;
  const k = countryKey(country);
  if (accessOf(u).countries.has(k)) return true; // responsible for it, or an admin granted it
  return viewMode.team(u.id).names.some((n) => myCountryKeys(n).has(k)); // manager mode: the countries of the people below them
}

// ---------------------------------------------------------------- lookups that are kept
interface Mat { descr: string; grp: string }
const matDim = memoTables(['intel_mat'], () => {
  const m = new Map<string, Mat>();
  for (const r of db.prepare('SELECT code, descr, grp FROM intel_mat').all() as any[]) m.set(r.code, { descr: r.descr || '', grp: r.grp || 'Other' });
  return m;
});
// the colour of a decor (the first part of the material code): its name and board code from the colour database when it is there
interface Dec { name: string; board: string | null; swatch: string | null; cat: string | null; express: boolean }
const decDim = memoTables(['color_codes', 'intel_mat'], () => {
  const m = new Map<string, Dec>();
  for (const r of db.prepare("SELECT sap, description, board_code, swatch, category, status FROM color_codes ORDER BY (status = 'Express') DESC, sap").all() as any[]) {
    const k = dec(r.sap); if (m.has(k)) continue;
    m.set(k, { name: r.swatch || r.description || '', board: r.board_code || null, swatch: r.swatch || null, cat: r.category || null, express: r.status === 'Express' });
  }
  return m;
});
const cleanName = (s: string) => s.replace(/\s*\b(pvc|abs|pp|pmma)\s*-?\s*(kb|tapa)?\b\.?/gi, ' ').replace(/^(str|ntrl|lrs|wlrs)[-.\d ]*\s*/i, '').replace(/\s+/g, ' ').trim() || s;

// SAP account -> country (the rule of Sales intelligence: the card first, then the SAP lists), and the CRM card of each account
const countryCodes = memoTables(['intel_cust', 'cards', 'intel_master', 'sap_customers', 'countries', 'country_assignments'], () => {
  const by = new Map<string, string[]>();
  for (const [code, c] of countryMap()) { if (!c.country) continue; const a = by.get(c.country) ?? []; a.push(code); by.set(c.country, a); }
  for (const a of by.values()) a.sort();
  return by;
});
interface CardLite { id: number; company: string; person: string | null; country: string | null; city: string | null; market: string | null; owner_override: number | null; uploaded_by: number | null; status: string }
const cardBySap = memoTables(['cards'], () => {
  const m = new Map<string, CardLite>();
  for (const c of db.prepare("SELECT id, company, name, person, country, city, market, owner_override, uploaded_by, status, sap FROM cards WHERE sap IS NOT NULL AND TRIM(sap) <> '' ORDER BY id").all() as any[]) {
    for (const s of sapCodes(c.sap)) if (!m.has(s)) m.set(s, { ...c, company: c.company || c.name || '' });
  }
  return m;
});
// a card can carry one SAP number, or several written together ("1202000155 / 1202000156")
export function sapCodes(sap: string | null | undefined): string[] {
  return [...new Set(String(sap ?? '').split(/[\s,;/|]+/).map((s) => s.trim()).filter((s) => /^[A-Za-z0-9-]{3,20}$/.test(s)))];
}

// ---------------------------------------------------------------- is the price good? (the owner's rule, OWNER-RULES 21 Nov)
// One implementation for this view, Price performance and the team analysis: services/priceIndex.ts (EUR per kg / per m2, the volume-weighted
// average of all customers - group companies and "not a customer" left out - per group and rolling 12-month window ending at the data cut,
// sales lines only, at least 100 kg/m2 and EUR 300 per group, weighted by revenue). Here only the shape the page draws.
const winOf = (ws: Win12[], ym: string) => { for (let i = 0; i < ws.length; i++) if (ym >= ws[i].from && ym <= ws[i].to) return i; return -1; };
const fmtIdx = (w: Win12, p: PriceIdx) => ({ from: w.from, to: w.to, index: p.index == null ? null : r0(p.index), sure: p.sure, groups: p.groups.map((g) => ({ g: g.grp, unit: g.unit, price: r3(g.price), avg: r3(g.avg), index: r0(g.index), eur: r0(g.eur), qty: r0(g.qty), ok: g.ok })) });
// the index of a set of accounts per window, from its own sales per window and group
function priceIndex(gw: Map<string, Sum[]>, ws: Win12[] = windows12()) {
  return ws.map((w, i) => {
    const groups = new Map<string, Sum>(); for (const [g, sums] of gw) if (sums[i]) groups.set(g, sums[i]);
    return fmtIdx(w, priceIndexOf(groups, benchAvg(w.from, w.to)));
  });
}

// ---------------------------------------------------------------- the analysis of a set of SAP accounts
// one summary row as an array (period, customer, material, doc_type, reason, thickness, width, eur, meters, m2, kg): tens of thousands are read for a country,
// and rows as arrays are read faster and leave less garbage than rows as objects
type Fact = [string, string, string, string, string, number, number, number, number, number, number];
interface Sum { eur: number; kg: number; m2: number; meters: number }
const z = (): Sum => ({ eur: 0, kg: 0, m2: 0, meters: 0 });
const add = (s: Sum, f: Fact) => { s.eur += f[7]; s.kg += f[10]; s.m2 += f[9]; s.meters += f[8]; };
const out = (s: Sum) => ({ eur: r0(s.eur), kg: r0(s.kg), m2: r0(s.m2), meters: r0(s.meters) });
const prices = (s: Sum) => ({ pkg: per(s.eur, s.kg), pm2: per(s.eur, s.m2), pm: per(s.eur, s.meters) });

function analyse(codes: string[], withCustomers: boolean) {
  const W = windows(), WS = windows12(), skipBench = withCustomers ? notCounted() : null;
  if (!codes.length) return { empty: true, cut: W.cut };
  const ph = codes.map(() => '?').join(',');
  const st = db.prepare(`SELECT period, customer, material, doc_type, reason, thickness, width, eur, meters, m2, kg FROM intel_fact WHERE customer IN (${ph})`) as any;
  let facts: Fact[];
  if (typeof st.setReturnArrays === 'function') { st.setReturnArrays(true); facts = st.all(...codes) as Fact[]; }
  else facts = (st.all(...codes) as any[]).map((r) => [r.period, r.customer, r.material, r.doc_type, r.reason, r.thickness, r.width, r.eur, r.meters, r.m2, r.kg] as Fact);
  if (!facts.length) return { empty: true, cut: W.cut };
  const M = matDim(), D = decDim();
  // "last 12 months" = the same rolling window as the price index (priceIndex.windows12: it ends AT the data month, so this month so far counts),
  // so revenue and the price index beside it always cover the same 12 months
  const lastFull = W.lastFull, l12s = WS[0]?.from ?? W.L12S.slice(0, 7), l12e = WS[0]?.to ?? lastFull, p12s = WS[1]?.from ?? W.P12S.slice(0, 7), cutYm = W.cut.slice(0, 7);
  const m24 = monthsBack(cutYm, 23);
  const curY = +W.cut.slice(0, 4), ytdEnd = W.cut.slice(5, 7);
  const tot = z(), sales = z(), l12 = z(), p12 = z(), ytd = z(), pytd = z(), ret = z();
  const years = new Map<number, Sum>(), months = new Map<string, Sum>(), groups = new Map<string, { all: Sum; l12: Sum; p12: Sum; sales: Sum; last: string; l12s: number }>();
  const prods = new Map<string, { s: Sum; sales: Sum; l12: number; last: string; dims: Map<number, number>; q: Map<string, number> }>();
  const decs = new Map<string, { s: Sum; l12: number; last: string; g: Map<string, number>; mat: string }>();
  const trend = new Map<string, Map<string, Sum>>(); // group -> quarter -> sales
  const spec = new Map<string, Sum>(); const ths = new Set<number>(), wds = new Set<number>();
  const reasons = new Map<string, { eur: number; n: number }>();
  const custs = new Map<string, { s: Sum; l12: number; p12: number; last: string; first: string; gw: Map<string, Sum[]> }>();
  const gw = new Map<string, Sum[]>(); // group -> 12-month window -> sums (for the price index)
  const activeM = new Set<string>(); let first = '', last = '';
  const qKeys: string[] = []; { let q = ''; for (let i = 35; i >= 0; i--) { const k = quarterOf(monthsBack(cutYm, i)); if (k !== q) { qKeys.push(k); q = k; } } }
  // what a period and a material mean is worked out once each (a country has tens of thousands of rows, a few hundred periods and materials)
  interface PInfo { ym: string; key: string; ys: Sum; ms: Sum | null; l12: boolean; p12: boolean; ytd: boolean; pytd: boolean; q: string; w: number }
  const pinfo = new Map<string, PInfo>();
  const pOf = (period: string): PInfo => {
    let o = pinfo.get(period); if (o) return o;
    const yearly = period.endsWith('-00'), y = +period.slice(0, 4), ym = yearly ? '' : period;
    let ys = years.get(y); if (!ys) { ys = z(); years.set(y, ys); }
    let ms: Sum | null = null; if (ym && ym >= m24) { ms = months.get(ym) ?? z(); months.set(ym, ms); }
    o = { ym, key: ym || `${y}-00`, ys, ms, l12: !!ym && ym >= l12s && ym <= l12e, p12: !!ym && ym >= p12s && ym < l12s, ytd: y === curY && !!ym && ym.slice(5, 7) <= ytdEnd, pytd: y === curY - 1 && !!ym && ym.slice(5, 7) <= ytdEnd, q: ym ? quarterOf(ym) : '', w: ym ? winOf(WS, ym) : -1 };
    pinfo.set(period, o); return o;
  };
  interface MInfo { g: string; gs: { all: Sum; l12: Sum; p12: Sum; sales: Sum; last: string; l12s: number }; p: { s: Sum; sales: Sum; l12: number; last: string; dims: Map<number, number>; q: Map<string, number> }; d: { s: Sum; l12: number; last: string; g: Map<string, number>; mat: string }; tg: Map<string, Sum> }
  const minfo = new Map<string, MInfo>();
  const mOf = (material: string): MInfo => {
    let o = minfo.get(material); if (o) return o;
    const g = M.get(material)?.grp || 'Other';
    let gs = groups.get(g); if (!gs) { gs = { all: z(), l12: z(), p12: z(), sales: z(), last: '', l12s: 0 }; groups.set(g, gs); }
    let p = prods.get(material); if (!p) { p = { s: z(), sales: z(), l12: 0, last: '', dims: new Map(), q: new Map() }; prods.set(material, p); }
    const dk = dec(material); let d = decs.get(dk); if (!d) { d = { s: z(), l12: 0, last: '', g: new Map(), mat: material }; decs.set(dk, d); }
    let tg = trend.get(g); if (!tg) { tg = new Map(); trend.set(g, tg); }
    o = { g, gs, p, d, tg }; minfo.set(material, o); return o;
  };
  const specN = new Map<number, Sum>();
  for (const f of facts) {
    const P = pOf(f[0]), I = mOf(f[2]), gs = I.gs, isRet = f[3] === 'R', key = P.key;
    add(tot, f); add(P.ys, f); if (P.ms) add(P.ms, f);
    if (P.l12) add(l12, f); else if (P.p12) add(p12, f);
    if (P.ytd) add(ytd, f); else if (P.pytd) add(pytd, f);
    add(gs.all, f); if (P.l12) add(gs.l12, f); else if (P.p12) add(gs.p12, f);
    if (withCustomers) { let c = custs.get(f[1]); if (!c) { c = { s: z(), l12: 0, p12: 0, last: '', first: '9', gw: new Map() }; custs.set(f[1], c); } if (P.w === 0 && !isRet) { let a = c.gw.get(I.g); if (!a) { a = []; c.gw.set(I.g, a); } add(a[0] ??= z(), f); } add(c.s, f); if (P.l12) c.l12 += f[7]; else if (P.p12) c.p12 += f[7]; if (!isRet && key > c.last) c.last = key; if (key < c.first) c.first = key; }
    // prices: sales lines only (returns are shown separately); a country's index leaves out the accounts the benchmark leaves out
    if (P.w >= 0 && !isRet && !(skipBench && skipBench.has(f[1]))) { let a = gw.get(I.g); if (!a) { a = []; gw.set(I.g, a); } add(a[P.w] ??= z(), f); }
    if (isRet) { add(ret, f); const rk = f[4] || 'Unspecified'; const r = reasons.get(rk) ?? { eur: 0, n: 0 }; r.eur += -f[7]; r.n += 1; reasons.set(rk, r); continue; }
    add(sales, f); add(gs.sales, f); if (key > gs.last) gs.last = key; if (P.l12) gs.l12s += f[7];
    if (P.ym) activeM.add(P.ym);
    if (!first || key < first) first = key; if (key > last) last = key;
    const p = I.p; add(p.s, f); add(p.sales, f); if (P.l12) p.l12 += f[7]; if (key > p.last) p.last = key;
    const d = I.d; add(d.s, f); if (P.l12) d.l12 += f[7]; if (key > d.last) d.last = key; d.g.set(I.g, (d.g.get(I.g) ?? 0) + f[7]);
    if (P.ym) {
      const nk = Math.round(f[5] * 1000) * 1000 + Math.min(Math.round(f[6]), 999); // one number for a thickness and a width
      if (f[5] > 0) p.dims.set(nk, (p.dims.get(nk) ?? 0) + f[8]);
      p.q.set(P.q, (p.q.get(P.q) ?? 0) + f[7]);
      let ts = I.tg.get(P.q); if (!ts) { ts = z(); I.tg.set(P.q, ts); } add(ts, f);
      if (f[5] > 0 && f[6] > 0) { let ss = specN.get(nk); if (!ss) { ss = z(); specN.set(nk, ss); } add(ss, f); }
    }
  }
  const thOf = (nk: number) => Math.floor(nk / 1000) / 1000, wOf = (nk: number) => nk % 1000;
  for (const [nk, ss] of specN) { ths.add(thOf(nk)); wds.add(wOf(nk)); spec.set(`${thOf(nk)}|${wOf(nk)}`, ss); }
  const evRows = db.prepare(`SELECT COUNT(*) n, MIN(d) a, MAX(d) b FROM intel_events WHERE customer IN (${ph})`).get(...codes) as any;
  const totEur = tot.eur || 1, salesEur = sales.eur || 1;
  const yKeys = [...years.keys()]; const y0 = Math.min(...yKeys), y1 = Math.max(...yKeys); // a year without purchases between two with is shown as 0, so the axis stays a time axis
  const yearList: any[] = []; for (let y = y0; y <= y1; y++) { const s = years.get(y) ?? z(); yearList.push({ y, ...out(s), ...prices(s), partial: y === curY }); }
  const monthList: any[] = []; for (let i = 23; i >= 0; i--) { const ym = monthsBack(cutYm, i); const s = months.get(ym) ?? z(); monthList.push({ ym, ...out(s), pkg: per(s.eur, s.kg), partial: ym === cutYm && W.cut.slice(0, 7) !== lastFull }); }
  const groupList = [...groups].map(([g, o]) => ({ g, ...out(o.all), share: r3(o.all.eur / totEur), l12: r0(o.l12.eur), p12: r0(o.p12.eur), ...prices(o.sales), last: o.last, l12s: r0(o.l12s) })).sort((a, b) => b.eur - a.eur);
  const topGroups = groupList.slice(0, 6).map((g) => g.g);
  const trendOut = { quarters: qKeys, series: topGroups.filter((g) => trend.has(g)).map((g) => ({ g, pkg: qKeys.map((q) => { const s = trend.get(g)!.get(q); return s && s.kg > 5 ? r2(s.eur / s.kg) : null; }), kg: qKeys.map((q) => r0(trend.get(g)!.get(q)?.kg ?? 0)) })) };
  const prodList = [...prods].sort((a, b) => b[1].s.eur - a[1].s.eur).slice(0, 30).map(([code, p]) => {
    const m = M.get(code) ?? { descr: '', grp: 'Other' }; const dims = [...p.dims].sort((a, b) => b[1] - a[1]); const [th, w] = dims.length ? [thOf(dims[0][0]), wOf(dims[0][0])] : [0, 0];
    const dd = D.get(dec(code));
    return { mat: code, desc: m.descr, g: m.grp || 'Other', th, w, sizes: dims.length, ...out(p.s), ...prices(p.sales), l12: r0(p.l12), last: p.last, share: r3(p.s.eur / salesEur), q: qKeys.slice(-8).map((q) => r0(p.q.get(q) ?? 0)), colour: dd ? { name: dd.name, board: dd.board } : null };
  });
  const decName = (k: string, mat: string) => { const d = D.get(k); return d ? { name: d.name || cleanName(M.get(mat)?.descr ?? ''), board: d.board, cat: d.cat, express: d.express, known: true } : { name: cleanName(M.get(mat)?.descr ?? k), board: null, cat: null, express: false, known: false }; };
  const decList = [...decs].filter(([, d]) => d.g.size > 0).sort((a, b) => b[1].s.eur - a[1].s.eur);
  const colours = {
    count: decList.length, l12: decList.filter(([, d]) => d.l12 > 0).length,
    known: decList.filter(([k]) => D.has(k)).length,
    top: decList.slice(0, 24).map(([k, d]) => ({ dec: k, ...decName(k, d.mat), g: [...d.g].sort((a, b) => b[1] - a[1])[0][0], eur: r0(d.s.eur), kg: r0(d.s.kg), share: r3(d.s.eur / salesEur), last: d.last })),
    rest: r0(decList.slice(24).reduce((s, [, d]) => s + d.s.eur, 0)),
  };
  const thList = [...ths].sort((a, b) => a - b), wdList = [...wds].sort((a, b) => a - b);
  const specOut = { th: thList, w: wdList, cells: [...spec].map(([k, s]) => { const [t, w] = k.split('|').map(Number); return [thList.indexOf(t), wdList.indexOf(w), r0(s.meters), r0(s.eur), r0(s.kg)]; }) };
  const thMix = thList.map((t) => { let e = 0, m = 0; for (const [k, s] of spec) if (+k.split('|')[0] === t) { e += s.eur; m += s.meters; } return { th: t, eur: r0(e), meters: r0(m) }; });
  const wMix = wdList.map((w) => { let e = 0, m = 0; for (const [k, s] of spec) if (+k.split('|')[1] === w) { e += s.eur; m += s.meters; } return { w, eur: r0(e), meters: r0(m) }; });
  // what they used to buy and no longer do: bought before the last 12 months, nothing in them
  const stopped = {
    groups: groupList.filter((g) => g.l12s <= 0 && g.eur > 0 && g.last).map((g) => ({ g: g.g, eur: g.eur, last: g.last })).slice(0, 8),
    decors: decList.filter(([, d]) => d.l12 <= 0 && d.s.eur > 0).slice(0, 12).map(([k, d]) => ({ dec: k, ...decName(k, d.mat), eur: r0(d.s.eur), last: d.last, g: [...d.g].sort((a, b) => b[1] - a[1])[0][0] })),
    decorsCount: decList.filter(([, d]) => d.l12 <= 0).length,
  };
  const retOut = { eur: r0(-ret.eur), kg: r0(-ret.kg), share: sales.eur > 0 ? r3(-ret.eur / sales.eur) : 0, reasons: [...reasons].sort((a, b) => b[1].eur - a[1].eur).map(([r, o]) => ({ r, eur: r0(o.eur), n: o.n })) };
  const res: any = {
    empty: false, cut: W.cut, lastFull, l12From: l12s, l12To: l12e, monthlyFrom: facts.reduce((m, f) => (!f[0].endsWith('-00') && f[0] < m ? f[0] : m), '9999'),
    totals: { ...out(tot), ...prices(sales), lines: facts.length, orders: evRows?.n ?? 0, first: evRows?.a || first, last: evRows?.b || last, activeMonths: activeM.size, products: [...prods.values()].filter((p) => p.s.eur > 0 || p.s.kg > 0).length },
    l12: { ...out(l12), ...prices(l12) }, p12: { ...out(p12), ...prices(p12) }, ytd: out(ytd), pytd: out(pytd),
    price: priceIndex(gw, WS),
    years: yearList, months: monthList, groups: groupList, trend: trendOut, top: prodList, colours, spec: specOut, thMix, wMix, returns: retOut, stopped,
  };
  if (withCustomers) {
    res.customerList = [...custs].sort((a, b) => b[1].s.eur - a[1].s.eur).map(([code, c]) => ({ code, eur: r0(c.s.eur), share: r3(c.s.eur / totEur), l12: r0(c.l12), p12: r0(c.p12), last: c.last, first: c.first, gw: c.gw }));
    res.customers = custs.size; res.activeCustomers = res.customerList.filter((c: any) => c.l12 > 0).length;
  }
  return res;
}

const byCodes = memoTablesBy(INTEL as unknown as string[], (key: string) => analyse(key ? key.split(',') : [], false), 300);
const byCountry = memoTablesBy(INTEL as unknown as string[], (key: string) => { const cut = key.indexOf('#'); const codes = key.slice(cut + 1); return analyse(codes ? codes.split(',') : [], true); }, 100);

export function purchasesForCard(card: { id: number; sap: string | null; country: string | null; market?: string | null }) {
  const codes = sapCodes(card.sap);
  if (!codes.length) return { sap: [], noSap: true, empty: true };
  const known = new Set((db.prepare(`SELECT code FROM intel_cust WHERE code IN (${codes.map(() => '?').join(',')})`).all(...codes) as any[]).map((r) => r.code));
  const use = codes.filter((c) => known.has(c));
  const data = byCodes(use.join(','));
  const country = card.market === 'domestic' ? 'Turkey' : (canonicalCountry(card.country) as string) || '';
  // the price index from the one shared implementation, over the customer's linked SAP numbers too: the same number Price performance shows
  if (!data.empty) return { sap: codes, country, ...data, price: indexSeries(use).map((w) => fmtIdx(w, w)) };
  return { sap: codes, country, ...data };
}

const ANON = null;
export function purchasesForCountry(country: string, viewer: U) {
  const c = (canonicalCountry(country) as string) || country;
  const excluded = new Set((db.prepare('SELECT code FROM intel_excluded').all() as any[]).map((r) => r.code));
  const codes = (countryCodes().get(c) ?? []).filter((x) => !excluded.has(x));
  const data = byCountry(`${c}#${codes.join(',')}`);
  if (data.empty) return { country: c, ...data };
  const { customerList, ...rest } = data;
  const admin = viewer.role === 'admin';
  const see = visibilityFor(viewer); const cards = cardBySap();
  const names = new Map((db.prepare(`SELECT code, name FROM intel_cust WHERE code IN (${customerList.slice(0, 25).map(() => '?').join(',') || "''"})`).all(...customerList.slice(0, 25).map((x: any) => x.code)) as any[]).map((r) => [r.code, r.name]));
  const top = customerList.slice(0, 25).map((x: any, i: number) => {
    const card = cards.get(x.code);
    const open = !!card && see(card as never);
    const named = admin || open;
    const { gw: cgw, ...xs } = x; const pi = priceIndex(cgw as Map<string, Sum[]>, windows12(1))[0]; // the customer's price index in the last 12 months
    return { rank: i + 1, ...xs, index: pi?.index ?? null, indexSure: !!pi?.sure, code: named ? x.code : null, name: named ? (card?.company || names.get(x.code) || x.code) : ANON, cardId: open ? card!.id : null, mine: !!card && card.person === viewer.display_name };
  });
  const rest25 = customerList.slice(25).reduce((s: number, x: any) => s + x.eur, 0);
  return { country: c, ...rest, topCustomers: top, otherCustomersEur: r0(rest25) };
}
