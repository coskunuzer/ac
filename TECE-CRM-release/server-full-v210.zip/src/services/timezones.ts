import { isoOf } from './phone';

// We always talk in the time of the CUSTOMER's country, but the team types Turkish time. This gives the usual time zone of a country
// (the zone of its capital or main business city; a person can still choose another zone in the form).
export const TURKEY_ZONE = 'Europe/Istanbul';

const ZONES: Record<string, string> = {
  // Americas
  US: 'America/New_York', CA: 'America/Toronto', MX: 'America/Mexico_City', GT: 'America/Guatemala', BZ: 'America/Belize', SV: 'America/El_Salvador', HN: 'America/Tegucigalpa',
  NI: 'America/Managua', CR: 'America/Costa_Rica', PA: 'America/Panama', CU: 'America/Havana', DO: 'America/Santo_Domingo', HT: 'America/Port-au-Prince', JM: 'America/Jamaica',
  PR: 'America/Puerto_Rico', TT: 'America/Port_of_Spain', BS: 'America/Nassau', BB: 'America/Barbados', AW: 'America/Aruba', CW: 'America/Curacao', CO: 'America/Bogota',
  VE: 'America/Caracas', EC: 'America/Guayaquil', PE: 'America/Lima', BO: 'America/La_Paz', CL: 'America/Santiago', AR: 'America/Argentina/Buenos_Aires', UY: 'America/Montevideo',
  PY: 'America/Asuncion', BR: 'America/Sao_Paulo', GY: 'America/Guyana', SR: 'America/Paramaribo',
  // Europe
  GB: 'Europe/London', IE: 'Europe/Dublin', PT: 'Europe/Lisbon', ES: 'Europe/Madrid', FR: 'Europe/Paris', DE: 'Europe/Berlin', IT: 'Europe/Rome', NL: 'Europe/Amsterdam',
  BE: 'Europe/Brussels', LU: 'Europe/Luxembourg', CH: 'Europe/Zurich', AT: 'Europe/Vienna', DK: 'Europe/Copenhagen', SE: 'Europe/Stockholm', NO: 'Europe/Oslo', FI: 'Europe/Helsinki',
  PL: 'Europe/Warsaw', CZ: 'Europe/Prague', SK: 'Europe/Bratislava', HU: 'Europe/Budapest', RO: 'Europe/Bucharest', BG: 'Europe/Sofia', GR: 'Europe/Athens', RS: 'Europe/Belgrade',
  HR: 'Europe/Zagreb', SI: 'Europe/Ljubljana', BA: 'Europe/Sarajevo', ME: 'Europe/Podgorica', MK: 'Europe/Skopje', AL: 'Europe/Tirane', XK: 'Europe/Belgrade', MD: 'Europe/Chisinau',
  UA: 'Europe/Kyiv', BY: 'Europe/Minsk', RU: 'Europe/Moscow', LT: 'Europe/Vilnius', LV: 'Europe/Riga', EE: 'Europe/Tallinn', CY: 'Asia/Nicosia', MT: 'Europe/Malta', IS: 'Atlantic/Reykjavik',
  TR: 'Europe/Istanbul',
  // Caucasus and Central Asia
  GE: 'Asia/Tbilisi', AM: 'Asia/Yerevan', AZ: 'Asia/Baku', KZ: 'Asia/Almaty', UZ: 'Asia/Tashkent', TM: 'Asia/Ashgabat', KG: 'Asia/Bishkek', TJ: 'Asia/Dushanbe', MN: 'Asia/Ulaanbaatar',
  // Middle East
  IL: 'Asia/Jerusalem', PS: 'Asia/Hebron', LB: 'Asia/Beirut', SY: 'Asia/Damascus', JO: 'Asia/Amman', IQ: 'Asia/Baghdad', IR: 'Asia/Tehran', SA: 'Asia/Riyadh', KW: 'Asia/Kuwait',
  BH: 'Asia/Bahrain', QA: 'Asia/Qatar', AE: 'Asia/Dubai', OM: 'Asia/Muscat', YE: 'Asia/Aden',
  // Asia and Oceania
  IN: 'Asia/Kolkata', PK: 'Asia/Karachi', BD: 'Asia/Dhaka', LK: 'Asia/Colombo', NP: 'Asia/Kathmandu', AF: 'Asia/Kabul', CN: 'Asia/Shanghai', HK: 'Asia/Hong_Kong', TW: 'Asia/Taipei',
  JP: 'Asia/Tokyo', KR: 'Asia/Seoul', TH: 'Asia/Bangkok', VN: 'Asia/Ho_Chi_Minh', MY: 'Asia/Kuala_Lumpur', SG: 'Asia/Singapore', ID: 'Asia/Jakarta', PH: 'Asia/Manila', MM: 'Asia/Yangon',
  KH: 'Asia/Phnom_Penh', LA: 'Asia/Vientiane', AU: 'Australia/Sydney', NZ: 'Pacific/Auckland',
  // Africa
  EG: 'Africa/Cairo', LY: 'Africa/Tripoli', TN: 'Africa/Tunis', DZ: 'Africa/Algiers', MA: 'Africa/Casablanca', NG: 'Africa/Lagos', GH: 'Africa/Accra', CI: 'Africa/Abidjan',
  SN: 'Africa/Dakar', KE: 'Africa/Nairobi', ET: 'Africa/Addis_Ababa', TZ: 'Africa/Dar_es_Salaam', UG: 'Africa/Kampala', ZA: 'Africa/Johannesburg', AO: 'Africa/Luanda',
  MZ: 'Africa/Maputo', ZW: 'Africa/Harare', ZM: 'Africa/Lusaka', CM: 'Africa/Douala', SD: 'Africa/Khartoum', SO: 'Africa/Mogadishu', DJ: 'Africa/Djibouti', CD: 'Africa/Kinshasa',
};

// Countries with more than one zone where the city tells: the main cities that matter to TECE.
const CITY_ZONES: Record<string, string> = {
  'us|los angeles': 'America/Los_Angeles', 'us|san francisco': 'America/Los_Angeles', 'us|seattle': 'America/Los_Angeles', 'us|chicago': 'America/Chicago', 'us|houston': 'America/Chicago',
  'us|dallas': 'America/Chicago', 'us|denver': 'America/Denver', 'us|phoenix': 'America/Phoenix', 'us|miami': 'America/New_York',
  'ca|vancouver': 'America/Vancouver', 'ca|calgary': 'America/Edmonton', 'ca|edmonton': 'America/Edmonton',
  'mx|tijuana': 'America/Tijuana', 'mx|cancun': 'America/Cancun',
  'br|manaus': 'America/Manaus', 'br|brasilia': 'America/Sao_Paulo', 'br|recife': 'America/Recife', 'br|fortaleza': 'America/Fortaleza',
  'ru|novosibirsk': 'Asia/Novosibirsk', 'ru|yekaterinburg': 'Asia/Yekaterinburg', 'ru|vladivostok': 'Asia/Vladivostok',
  'au|perth': 'Australia/Perth', 'au|brisbane': 'Australia/Brisbane', 'au|adelaide': 'Australia/Adelaide',
  'cl|punta arenas': 'America/Punta_Arenas', 'id|bali': 'Asia/Makassar', 'id|denpasar': 'Asia/Makassar',
};
const plain = (s: string) => s.normalize('NFD').replace(/\p{Diacritic}/gu, '').toLowerCase().trim();

export function zoneOf(country: string | null | undefined, city?: string | null): string | null {
  const iso = isoOf(country);
  if (!iso) return null;
  if (city) {
    const c = CITY_ZONES[`${iso.toLowerCase()}|${plain(city)}`];
    if (c) return c;
  }
  return ZONES[iso] ?? null;
}

// The clock of a moment in a zone: { date: "2026-11-17", time: "09:00", long: "Tuesday 17 November 2026" }.
export function clockIn(iso: string | Date, zone: string, locale = 'en-GB'): { date: string; time: string; long: string; abbr: string } {
  const d = typeof iso === 'string' ? new Date(iso) : iso;
  const date = new Intl.DateTimeFormat('en-CA', { timeZone: zone }).format(d);
  const time = new Intl.DateTimeFormat('en-GB', { timeZone: zone, hour: '2-digit', minute: '2-digit', hour12: false }).format(d);
  const long = new Intl.DateTimeFormat(locale, { timeZone: zone, weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(d);
  const abbr = new Intl.DateTimeFormat('en-GB', { timeZone: zone, timeZoneName: 'short' }).formatToParts(d).find((p) => p.type === 'timeZoneName')?.value ?? zone;
  return { date, time, long, abbr };
}

export const isZone = (z: unknown): z is string => {
  if (typeof z !== 'string' || !z) return false;
  try { new Intl.DateTimeFormat('en', { timeZone: z }); return true; } catch { return false; }
};

// What a person typed as Turkish time ("2026-11-17" + "17:00") as the real moment (Turkey has no summer time: always UTC+3).
export const fromTurkishTime = (day: string, time: string): Date => new Date(`${day}T${time}:00+03:00`);

// The place of the zone as people say it: "Lima".
export const zoneCity = (zone: string): string => zone.split('/').pop()!.replace(/_/g, ' ');
