import { Router } from 'express';
import { db } from '../db/connection';
import { requireAuth, requireAdmin, type AuthedRequest } from '../middleware/auth';
import { cardModel } from '../models/cardModel';
import { activityModel } from '../models/activityModel';
import { settingsModel } from '../models/settingsModel';
import { canSeeCard } from '../services/visibility';
import { sendThankYouEmail } from '../services/thankYouEmail';
import { buildSignature, styleFor } from '../services/signature';
import { splitEmails } from '../services/emailAddresses';
import { isLang, type Lang } from '../services/translate';
import { CARRIERS } from '../services/noteAssist';
import { trackingMail, TRACKING_URL } from '../services/samples';
import { markDelivered, refreshSample, setTrackingKey, trackingConfigured } from '../services/tracking';

// The samples of a customer (what was sent, the tracking number, the e-mail that told the customer) and the e-mails the CRM has sent to a customer.
const router = Router();
router.use(requireAuth);

const str = (v: unknown, max = 400) => String(v ?? '').trim().slice(0, max);
interface SampleRow { id: number; card_id: number; user_id: number | null; items: string; note: string | null; carrier: string | null; requested_at: string; tracking_no: string | null; shipped_at: string | null; customer_mail_id: number | null; activity_id: number | null; delivery_status: string | null; delivery_detail: string | null; delivered_at: string | null; checked_at: string | null }

function cardFor(req: AuthedRequest, res: import('express').Response) {
  const card = cardModel.findById(parseInt(String(req.params.id), 10));
  if (!card) { res.status(404).json({ error: 'Not found' }); return null; }
  if (!canSeeCard(req.user, card)) { res.status(403).json({ error: 'You do not have access to this record' }); return null; }
  return card;
}

router.get('/:id/samples', (req: AuthedRequest, res) => {
  const card = cardFor(req, res);
  if (!card) return;
  const rows = db.prepare('SELECT * FROM card_samples WHERE card_id = ? ORDER BY id DESC').all(card.id) as unknown as SampleRow[];
  res.json({ samples: rows.map((r) => ({ id: r.id, items: r.items, note: r.note, carrier: r.carrier, requestedAt: r.requested_at, trackingNo: r.tracking_no, shippedAt: r.shipped_at, mailed: !!r.customer_mail_id, activityId: r.activity_id, deliveryStatus: r.delivery_status, deliveryDetail: r.delivery_detail, deliveredAt: r.delivered_at, checkedAt: r.checked_at, trackUrl: r.tracking_no && r.carrier && TRACKING_URL[r.carrier] ? TRACKING_URL[r.carrier](r.tracking_no) : null })), carriers: CARRIERS, followed: trackingConfigured() });
});

// the e-mail to the customer, written for the tracking number (the salesperson reads and changes it, then sends)
router.post('/:id/samples/:sid/tracking-draft', (req: AuthedRequest, res) => {
  const card = cardFor(req, res);
  if (!card) return;
  const s = db.prepare('SELECT * FROM card_samples WHERE id = ? AND card_id = ?').get(parseInt(String(req.params.sid), 10), card.id) as SampleRow | undefined;
  if (!s) return res.status(404).json({ error: 'Sample not found' });
  const trackingNo = str(req.body?.trackingNo, 60);
  if (!trackingNo) return res.status(400).json({ error: 'Write the tracking number.' });
  const carrier = CARRIERS.includes(str(req.body?.carrier, 20)) ? str(req.body?.carrier, 20) : s.carrier ?? '';
  const lang: Lang = isLang(req.body?.language) ? req.body.language : isLang(card.language) ? card.language : 'en';
  const mail = trackingMail(card, lang, s.items, carrier, trackingNo, req.user!.display_name || req.user!.username);
  const to = [card.email ?? '', ...(db.prepare('SELECT email FROM card_contacts WHERE card_id = ? AND email IS NOT NULL').all(card.id) as { email: string }[]).map((r) => r.email)].filter(Boolean);
  res.json({ ...mail, language: lang, to: [...new Set(to)].slice(0, 6), me: req.user!.email });
});

// saves the tracking number and (when asked) sends the e-mail to the customer; the e-mail is kept in the customer's history
router.post('/:id/samples/:sid/tracking', async (req: AuthedRequest, res) => {
  const card = cardFor(req, res);
  if (!card) return;
  const s = db.prepare('SELECT * FROM card_samples WHERE id = ? AND card_id = ?').get(parseInt(String(req.params.sid), 10), card.id) as SampleRow | undefined;
  if (!s) return res.status(404).json({ error: 'Sample not found' });
  const trackingNo = str(req.body?.trackingNo, 60);
  if (!trackingNo) return res.status(400).json({ error: 'Write the tracking number.' });
  const carrier = CARRIERS.includes(str(req.body?.carrier, 20)) ? str(req.body?.carrier, 20) : s.carrier ?? '';
  const send = req.body?.send === true;
  let mailId: number | null = s.customer_mail_id;
  if (send) {
    const to = (Array.isArray(req.body?.to) ? req.body.to : splitEmails(str(req.body?.to, 400))).map(String).filter((a: string) => /@/.test(a));
    const subject = str(req.body?.subject, 200);
    const body = str(req.body?.body, 6000);
    if (!to.length) return res.status(400).json({ error: 'Choose who gets the e-mail.' });
    if (!subject || !body) return res.status(400).json({ error: 'The e-mail needs a subject and a text.' });
    const wanted = req.body?.test === true || settingsModel.get('test_mode') === '1';
    const testTo = wanted ? settingsModel.get('test_email') || req.user!.email || '' : null;
    if (testTo === '') return res.status(400).json({ error: 'There is no test address. Add your e-mail under My account.' });
    try {
      await sendThankYouEmail({ to: to.join(', '), cc: req.user!.email || null, subject, body, replyTo: req.user!.email, signature: buildSignature(req.user, styleFor(req.user)), testTo, record: { cardId: card.id, userId: req.user!.id, kind: 'sample_tracking' } });
    } catch (err) {
      console.error('Tracking e-mail failed:', err);
      return res.status(502).json({ error: 'Failed to send email', message: (err as Error).message });
    }
    if (testTo) return res.json({ test: true, sentTo: testTo });
    mailId = (db.prepare("SELECT id FROM sent_emails WHERE card_id = ? AND kind = 'sample_tracking' ORDER BY id DESC LIMIT 1").get(card.id) as { id: number } | undefined)?.id ?? null;
    activityModel.add({ userId: req.user!.id, cardId: card.id, type: 'email', text: `Tracking number sent to the customer: ${carrier ? `${carrier} ` : ''}${trackingNo}` });
  }
  db.prepare("UPDATE card_samples SET tracking_no = ?, carrier = ?, shipped_at = COALESCE(shipped_at, datetime('now')), customer_mail_id = ?, delivery_status = CASE WHEN tracking_no = ? THEN delivery_status ELSE NULL END WHERE id = ?").run(trackingNo, carrier || null, mailId, trackingNo, s.id);
  void refreshSample(s.id); // the first look at the courier, in the background
  res.json({ ok: true, mailed: !!mailId });
});

// look the shipment up now
router.post('/:id/samples/:sid/refresh', async (req: AuthedRequest, res) => {
  const card = cardFor(req, res);
  if (!card) return;
  const s = db.prepare('SELECT id FROM card_samples WHERE id = ? AND card_id = ?').get(parseInt(String(req.params.sid), 10), card.id) as { id: number } | undefined;
  if (!s) return res.status(404).json({ error: 'Sample not found' });
  if (!trackingConfigured()) return res.status(400).json({ error: 'The tracking service is not set up yet. An admin can add its key under Admin > E-mail texts. Meanwhile open the courier page or mark the sample as delivered.' });
  res.json(await refreshSample(s.id));
});

// a person says the samples arrived
router.post('/:id/samples/:sid/delivered', (req: AuthedRequest, res) => {
  const card = cardFor(req, res);
  if (!card) return;
  const s = db.prepare('SELECT id FROM card_samples WHERE id = ? AND card_id = ?').get(parseInt(String(req.params.sid), 10), card.id) as { id: number } | undefined;
  if (!s) return res.status(404).json({ error: 'Sample not found' });
  markDelivered(s.id);
  res.json({ ok: true });
});

// the courier tracking service key (admin)
router.get('/tracking/config', requireAdmin, (_req, res) => res.json({ configured: trackingConfigured() }));
router.put('/tracking/config', requireAdmin, (req, res) => {
  setTrackingKey(String(req.body?.key ?? ''));
  res.json({ configured: trackingConfigured() });
});

// every e-mail sent to this customer (and the internal ones about it)
router.get('/:id/emails', (req: AuthedRequest, res) => {
  const card = cardFor(req, res);
  if (!card) return;
  const rows = db.prepare('SELECT e.*, u.display_name AS sender FROM sent_emails e LEFT JOIN users u ON u.id = e.user_id WHERE e.card_id = ? ORDER BY e.id DESC LIMIT 200').all(card.id) as unknown as { id: number; kind: string; internal: number; to_addr: string | null; cc_addr: string | null; subject: string | null; body: string | null; attachments: string | null; sent_at: string; sender: string | null }[];
  res.json({ emails: rows.map((r) => ({ id: r.id, kind: r.kind, internal: !!r.internal, to: r.to_addr, cc: r.cc_addr, subject: r.subject, body: r.body, attachments: r.attachments ? r.attachments.split(', ') : [], at: r.sent_at, sender: r.sender })) });
});

export default router;
