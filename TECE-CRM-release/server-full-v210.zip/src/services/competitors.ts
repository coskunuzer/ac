import crypto from 'crypto';
import { db } from '../db/connection';
import { askJson } from './perfActions';
import { cardModel, type CardRow } from '../models/cardModel';

// Battle cards: what we know about each competitor, written by PEOPLE. The cards below are DRAFTS made from what the companies say about themselves and from public
// listings (the sources are on each card); they are marked "not confirmed" until a person checks them. The AI never adds facts about a competitor: it only
// tailors a card to one customer.
export interface BattleCard { summary: string; strengths: string[]; weaknesses: string[]; complaints: string[]; angle: string[]; questions: string[]; avoid: string[]; proof: string[]; sources: string[] }
export interface Competitor { id: number; name: string; kind: 'edge' | 'board' | 'other'; region: string | null; card: BattleCard; verified: number; updated_at: string }
export const emptyCard = (): BattleCard => ({ summary: '', strengths: [], weaknesses: [], complaints: [], angle: [], questions: [], avoid: [], proof: [], sources: [] });

const AVOID = ['Do not criticise the competitor or say anything about their quality, prices or delivery that we cannot document.', 'Do not promise an exact colour match before a sample has been checked.'];
const TECE_ANGLE = ['One maker for a wide range: PVC, ABS, hybrid, recycled PP, melamine, Zero-Line (hot air), wood and specialty edgebands (tece.com.tr).', 'Colour matching to the decors of the board makers (our decor database: ask for the code list).', 'Ask for a sample of the exact decor first; the express range and minimum quantities depend on the decor (check with sales).'];

const SEEDS: { name: string; kind: Competitor['kind']; region: string; card: Partial<BattleCard> }[] = [
  { name: 'Egger (boards)', kind: 'board', region: 'Europe', card: {
    summary: 'The customer buys EGGER BOARDS. That is not a competitor for edgebanding: it is our selling point, because we match edges to the EGGER decors.',
    angle: ['Offer edges matched to the EGGER decors the customer already uses.', 'Send a sample of the exact decor code.', ...TECE_ANGLE.slice(1)],
    questions: ['Which EGGER decors do you use most?', 'Where do you buy the matching edge today, and how long does it take to arrive?', 'Do you need small quantities of many decors?'],
    avoid: AVOID, proof: ['Decor database: the matched decor codes (ask sales).'], sources: ['TECE decor database'] } },
  { name: 'Kronospan (boards)', kind: 'board', region: 'Europe', card: {
    summary: 'The customer buys KRONOSPAN BOARDS. Same idea as for EGGER boards: match the decor.',
    angle: ['Offer edges matched to the KRONOSPAN decors the customer uses.', 'Send a sample of the exact decor code.', ...TECE_ANGLE.slice(1)],
    questions: ['Which KRONOSPAN decors do you use most?', 'Where do you buy the matching edge, and how long does it take?'],
    avoid: AVOID, proof: ['Decor database: the matched decor codes (ask sales).'], sources: ['TECE decor database'] } },
  { name: 'Rehau', kind: 'edge', region: 'Germany / worldwide', card: {
    summary: 'Edgebands under the name RAUKANTEX, in three families (company information). Strong in zero-joint edges.',
    strengths: ['RAUKANTEX pro: zero-joint, fully polymer (the former "laser edge") - REHAU.', 'RAUKANTEX plus: adhesive-based zero-joint, also from the Express collection in quantities as small as 1 m - REHAU.', 'RAUKANTEX pure: the classic primer edgeband - REHAU.'],
    angle: ['Ask which RAUKANTEX family they buy and which edgebander technology they run (laser, hot air, NIR).', 'Offer TECE Zero-Line (hot air) as a zero-joint option, with samples.', ...TECE_ANGLE.slice(1)],
    questions: ['Which RAUKANTEX family do you buy (pro, plus, pure)?', 'Which edgebander technology do you run?', 'What quantities and lead time do you get today?', 'What would make you try a second supplier for part of the volume?'],
    avoid: AVOID, proof: [], sources: ['https://www.rehau.com/downloads/1272916/raukantex-zero-joint-edgebands-.pdf', 'https://interior.rehau.com/uk-en/products/raukantex-furniture-edgebands/furniture-edgebands/raukantex-pro'] } },
  { name: 'Döllken / SURTECO', kind: 'edge', region: 'Germany / worldwide', card: {
    summary: 'Döllken is part of the SURTECO Group (company information). Range: ABS, PVC, acrylic and 3D edging, and a laser-compatible line (FusionEdge).',
    strengths: ['Part of the SURTECO Group.', 'Range with ABS, PVC, acrylic and 3D edging.', 'FusionEdge for laser, hot air and infrared edgebanders (company/trade sources; the base material differs between sources: check).'],
    angle: ['Ask which Döllken range they buy (PVC, ABS, FusionEdge).', 'Offer a sample of the same decor and thickness to compare.', ...TECE_ANGLE.slice(1)],
    questions: ['Which Döllken products do you buy (PVC, ABS, FusionEdge)?', 'Which edgebander technology do you run?', 'What quantities and lead time do you get today?', 'What would make you try a second supplier?'],
    avoid: AVOID, proof: [], sources: ['https://na.doellken.com', 'https://www.surteco.com/fileadmin/surteco.com/services/downloads/verarbeitungsinformationen/SUR_Verarbeitungsinformation_PVC_EN_L01.pdf'] } },
  { name: 'Portakal', kind: 'edge', region: 'Turkey (Istanbul)', card: {
    summary: 'Turkish maker of PVC, ABS and acrylic edgebands (own information).',
    strengths: ['Says it was founded in 1994 in Istanbul, with a capacity of 850 tons a month, exporting to 50 countries (own listing).'],
    angle: ['A near competitor with the same shipping advantage: compete on decor match, range and service.', ...TECE_ANGLE],
    questions: ['Which products do you buy from them (PVC, ABS, acrylic)?', 'How is the colour match to your boards?', 'What are the lead time and the minimum quantity?'],
    avoid: AVOID, proof: [], sources: ['https://intermobistanbul.com/en/product-detail/brand/portakal-plastik-uretim-paz-san-ve-tic-as'] } },
  { name: 'Boyut', kind: 'edge', region: 'Turkey (Istanbul)', card: {
    summary: 'Turkish maker of edgebands for furniture and door panels: PVC, ABS, PP and acrylic (Intermob listing).',
    strengths: ['Established in 2005 in Istanbul (listing).'],
    angle: ['A near competitor: compete on decor match, range and service.', ...TECE_ANGLE],
    questions: ['Which products do you buy from them (PVC, ABS, PP, acrylic)?', 'How is the colour match to your boards?', 'What are the lead time and the minimum quantity?'],
    avoid: AVOID, proof: [], sources: ['https://intermobistanbul.com/en/brand/boyut-plprofil-ve-folyo-imlsanticas'] } },
  { name: 'Mobelkant (ASTS Profil)', kind: 'edge', region: 'Turkey', card: {
    summary: 'Mobelkant is a brand of ASTS Profil. Range: PVC, ABS, 3D dual-colour, aluminium, flexible, hybrid, melamine and pre-glued edgebands, 0.4-3 mm, 8-390 mm wide (Intermob listing).',
    strengths: ['Described by Intermob Istanbul as the largest domestically funded edgeband maker in Türkiye.', 'Wide range of materials and sizes (listing).'],
    angle: ['A strong Turkish competitor with a wide range: compete on decor match, service and the Zero-Line / recycled PP products.', ...TECE_ANGLE],
    questions: ['Which Mobelkant products do you buy?', 'How is the colour match to your boards?', 'What are the lead time and the minimum quantity?', 'What do you wish was better?'],
    avoid: AVOID, proof: [], sources: ['https://intermobistanbul.com/en/product-detail/390539', 'https://iwfatlanta.com/attend-iwf/exhibitor/20210-mobelkant/'] } },
  { name: 'Chinese manufacturers', kind: 'edge', region: 'China', card: {
    summary: 'Many makers, usually selling on price. The figures below are from supplier listings (indicative, not quotes).',
    strengths: ['Listings show minimums of 3,000-5,000 m per colour, FOB prices of about USD 0.05-0.45 per metre, 7-10 days for stock colours and 20-30 days for custom colours.'],
    angle: ['Do not argue price first: ask about decor accuracy to the boards, claims, and lead time to the customer.', 'Offer small quantities and quick samples of exact decors.', ...TECE_ANGLE.slice(0, 2)],
    questions: ['How well do the colours match your boards, and how do you handle a mismatch?', 'What are the real lead time to your door and the minimum per colour?', 'Have you had claims, and how were they solved?', 'Do you need smaller quantities of more decors?'],
    avoid: AVOID, proof: [], sources: ['https://asiaedgebanding.com/?p=12327', 'https://asiaedgebanding.com/edge-banding-manufacturers-2/'] } },
  { name: 'Karebant', kind: 'edge', region: '', card: { summary: 'No information yet. Add what you know: who they are, their range, strengths, what customers say.', questions: ['Which products do you buy from them?', 'What do you like and dislike?', 'What are the lead time and the minimum quantity?'], avoid: AVOID } },
  { name: 'Other supplier', kind: 'other', region: '', card: { summary: 'A supplier that is not on the list.', questions: ['Who is the supplier and which products do you buy?', 'What would make you try a second supplier?'], avoid: AVOID, angle: TECE_ANGLE } },
];

export function ensureSeeded(): void {
  const n = (db.prepare('SELECT COUNT(*) AS n FROM competitors').get() as { n: number }).n;
  if (n > 0) return;
  const ins = db.prepare('INSERT OR IGNORE INTO competitors (name, kind, region, card_json, verified) VALUES (?, ?, ?, ?, 0)');
  for (const s of SEEDS) ins.run(s.name, s.kind, s.region, JSON.stringify({ ...emptyCard(), ...s.card }));
}

const parse = (j: string): BattleCard => { try { return { ...emptyCard(), ...(JSON.parse(j) as Partial<BattleCard>) }; } catch { return emptyCard(); } };
export function listCompetitors(): Competitor[] {
  ensureSeeded();
  return (db.prepare('SELECT id, name, kind, region, card_json, verified, updated_at FROM competitors ORDER BY CASE kind WHEN \'edge\' THEN 0 WHEN \'board\' THEN 1 ELSE 2 END, name').all() as { id: number; name: string; kind: Competitor['kind']; region: string | null; card_json: string; verified: number; updated_at: string }[])
    .map((r) => ({ id: r.id, name: r.name, kind: r.kind, region: r.region, card: parse(r.card_json), verified: r.verified, updated_at: r.updated_at }));
}
const lines = (v: unknown): string[] => (Array.isArray(v) ? v : String(v ?? '').split('\n')).map((x) => String(x).trim()).filter(Boolean).slice(0, 30).map((x) => x.slice(0, 400));
export function cleanCard(b: Record<string, unknown>): BattleCard {
  return { summary: String(b.summary ?? '').trim().slice(0, 800), strengths: lines(b.strengths), weaknesses: lines(b.weaknesses), complaints: lines(b.complaints), angle: lines(b.angle), questions: lines(b.questions), avoid: lines(b.avoid), proof: lines(b.proof), sources: lines(b.sources) };
}

// ---- the suppliers of a customer ----------------------------------------------------------------------------------------------------------------------
export interface SupplierRow { id: number; competitorId: number | null; name: string; kind: string | null; source: string; sharePct: number | null; note: string | null }
export function suppliersOf(cardId: number): SupplierRow[] {
  return db.prepare('SELECT s.id, s.competitor_id AS competitorId, COALESCE(c.name, s.name) AS name, c.kind AS kind, s.source, s.share_pct AS sharePct, s.note FROM card_suppliers s LEFT JOIN competitors c ON c.id = s.competitor_id WHERE s.card_id = ? ORDER BY s.id').all(cardId) as unknown as SupplierRow[];
}
// a brand found on the customer's web site: put on their suppliers when it is a competitor we know (never twice)
export function addSiteSuppliers(cardId: number, brands: string[]): void {
  ensureSeeded();
  const comps = db.prepare('SELECT id, name FROM competitors').all() as { id: number; name: string }[];
  for (const b of brands) {
    const key = b.toLowerCase().replace(/[^a-z0-9ö]+/g, '');
    if (key.length < 4) continue;
    const c = comps.find((x) => { const n = x.name.toLowerCase().replace(/[^a-z0-9ö]+/g, ''); return n.includes(key) || key.includes(n.replace(/\(.*$/, '')); });
    if (!c) continue;
    const has = db.prepare('SELECT 1 FROM card_suppliers WHERE card_id = ? AND competitor_id = ?').get(cardId, c.id);
    if (!has) db.prepare("INSERT INTO card_suppliers (card_id, competitor_id, source, note) VALUES (?, ?, 'site', 'Found on the customer web site')").run(cardId, c.id);
  }
}

// ---- the approach (one AI question, kept until something changes) -----------------------------------------------------------------------------------
export interface Approach { angle: string; questions: string[]; firstOffer: string; objections: { objection: string; answer: string }[]; message: string; cautions: string[]; language: string; unverified: boolean; madeAt: string }
const SCHEMA = { type: 'OBJECT', properties: { angle: { type: 'STRING' }, questions: { type: 'ARRAY', items: { type: 'STRING' } }, firstOffer: { type: 'STRING' }, objections: { type: 'ARRAY', items: { type: 'OBJECT', properties: { objection: { type: 'STRING' }, answer: { type: 'STRING' } }, required: ['objection', 'answer'] } }, message: { type: 'STRING' }, cautions: { type: 'ARRAY', items: { type: 'STRING' } } }, required: ['angle', 'questions', 'firstOffer', 'objections', 'message'] };
const LANG_NAME: Record<string, string> = { en: 'English', tr: 'Turkish', ru: 'Russian', es: 'Spanish', fr: 'French', de: 'German' };

function facts(card: CardRow, boards: string[], sup: SupplierRow[]): Record<string, unknown> {
  const cut = (s: string | null | undefined, n: number) => (s ? s.replace(/\s+/g, ' ').trim().slice(0, n) : undefined);
  return { company: cut(card.company, 80), country: card.market === 'domestic' ? `Turkey, ${card.city ?? ''}` : card.country, stage: card.stage, workArea: cut(card.work_area, 100), interestedIn: cut(card.interested_in, 120), notes: cut(card.notes, 400), boardsBought: boards, edgebandingSuppliers: sup.map((s) => ({ name: s.name, source: s.source, sharePct: s.sharePct, note: cut(s.note, 100) })), language: card.language ?? 'en' };
}
export function approachBasis(card: CardRow): { boards: string[]; sup: SupplierRow[]; hash: string } {
  const boards = (db.prepare('SELECT b.name FROM card_boards cb JOIN board_brands b ON b.id = cb.brand_id WHERE cb.card_id = ?').all(card.id) as { name: string }[]).map((r) => r.name);
  const sup = suppliersOf(card.id);
  const cards = listCompetitors().filter((c) => sup.some((s) => s.competitorId === c.id) || boards.some((b) => c.name.toLowerCase().startsWith(b.toLowerCase().split(' ')[0]) && c.kind === 'board'));
  const hash = crypto.createHash('sha1').update(JSON.stringify([facts(card, boards, sup), cards.map((c) => [c.id, c.updated_at])])).digest('hex');
  return { boards, sup, hash };
}
export const cachedApproach = (cardId: number): { approach: Approach | null; stale: boolean } => {
  const r = db.prepare('SELECT basis_hash, body_json, made_at FROM card_approach WHERE card_id = ?').get(cardId) as { basis_hash: string; body_json: string; made_at: string } | undefined;
  const card = cardModel.findById(cardId);
  if (!r || !card) return { approach: null, stale: false };
  return { approach: { ...(JSON.parse(r.body_json) as Approach), madeAt: r.made_at }, stale: r.basis_hash !== approachBasis(card).hash };
};

export async function makeApproach(card: CardRow): Promise<Approach | null> {
  const { boards, sup, hash } = approachBasis(card);
  const all = listCompetitors();
  const chosen = all.filter((c) => sup.some((s) => s.competitorId === c.id) || (c.kind === 'board' && boards.some((b) => c.name.toLowerCase().startsWith(b.toLowerCase().split(' ')[0]))));
  const lang = LANG_NAME[card.language ?? 'en'] ? (card.language ?? 'en') : 'en';
  const unverified = chosen.some((c) => !c.verified);
  const prompt = [
    'You help a TECE sales person (TECE makes edgebanding for furniture panels, Bursa, Turkey) to approach ONE customer who buys from other suppliers.',
    'Use ONLY the facts below: the customer facts and the battle cards (written by TECE staff; a card marked notConfirmed is a draft). NEVER add a fact about a competitor (quality, price, delivery, weakness) that is not on its card. Never disparage a competitor. Do not promise an exact colour match before a sample. If there is no card for a supplier, say what to ASK, not what to claim.',
    'A board supplier (like EGGER or KRONOSPAN boards) is NOT a competitor for edgebanding: it is a reason to offer the matching decor.',
    'Answer: angle (2-3 sentences: why this customer might talk to TECE), questions (exactly 3 opening questions), firstOffer (one concrete first step, e.g. a sample of an exact decor; do not invent prices), objections (up to 3 likely objections with a short honest answer), message (a short e-mail or WhatsApp text, 70 words at most, no price, in ' + (LANG_NAME[lang] ?? 'English') + '), cautions (what to avoid saying).',
    `Customer facts: ${JSON.stringify(facts(card, boards, sup))}`,
    `Battle cards: ${JSON.stringify(chosen.map((c) => ({ name: c.name, kind: c.kind, notConfirmed: !c.verified, ...c.card })))}`,
    chosen.length ? '' : 'There is no battle card for this customer\'s suppliers yet: give general questions to find out who they buy from and what they dislike, and the decor-matching offer.',
  ].join('\n\n');
  const j = await askJson(prompt, SCHEMA);
  if (!j) return null;
  const arr = (v: unknown, n: number) => (Array.isArray(v) ? v.map((x) => String(x).trim().slice(0, 300)).filter(Boolean).slice(0, n) : []);
  const body: Approach = {
    angle: String(j.angle ?? '').slice(0, 700), questions: arr(j.questions, 3), firstOffer: String(j.firstOffer ?? '').slice(0, 500),
    objections: (Array.isArray(j.objections) ? j.objections : []).slice(0, 3).map((o) => ({ objection: String((o as { objection?: string }).objection ?? '').slice(0, 200), answer: String((o as { answer?: string }).answer ?? '').slice(0, 400) })).filter((o) => o.objection),
    message: String(j.message ?? '').slice(0, 700), cautions: arr(j.cautions, 5), language: lang, unverified, madeAt: '',
  };
  db.prepare("INSERT OR REPLACE INTO card_approach (card_id, basis_hash, body_json, made_at) VALUES (?, ?, ?, datetime('now'))").run(card.id, hash, JSON.stringify(body));
  return { ...body, madeAt: new Date().toISOString() };
}
