import * as XLSX from 'xlsx';
import { db } from '../db/connection';
import { cardModel } from '../models/cardModel';
import { cityModel } from '../models/cityModel';
import { userModel } from '../models/userModel';
import { guessCityFromAddress, placeKey, resolveCity } from '../data/turkeyPlaces';
import { matchPerson } from './countryAssignment';
import type { ExtractedCardFields, FieldStatusMap } from '../schema/cardSchema';

// The domestic customer list as Excel (the SAP customer list, the "customers" sheet ...): one row per company, the
// columns found by their names in Turkish or English. Customers come in as domestic customers, filed under their city
// (a district such as "Nilüfer" is filed under its province, Bursa) and given to the person looking after that city.

const ALIASES: Record<string, string[]> = {
  company: ['cariunvan', 'unvan', 'firmaunvani', 'firmaadi', 'firma', 'company', 'companyname', 'customername', 'musteriadi', 'ad1', 'isim'],
  sap: ['sapcarino', 'sapno', 'sapkodu', 'carino', 'musteri', 'musterino', 'customerno'],
  scope: ['yurticiyurtdisiihrackayitli', 'yurticiyurtdisi', 'yurtici', 'scope'],
  kind: ['kontakturu', 'tur'],
  country: ['ulke', 'country'],
  city: ['ilsehir', 'sehir', 'il', 'kent', 'city', 'province'],
  district: ['ilce', 'district'],
  address: ['adres', 'address'],
  email: ['firmamaili', 'email', 'eposta', 'mail', 'emailaddress'],
  email2: ['yetkilimail2', 'yetlilimail2', 'email2'],
  email3: ['yetkilimail3', 'email3'],
  phone: ['telefon1', 'telefon', 'tel', 'phone', 'gsm'],
  phone2: ['telefon2', 'gsm2'],
  contact: ['yetkilikisi', 'yetkili', 'ilgilikisi', 'contact', 'contactperson', 'kisi'],
  contact2: ['yetkilikisi2'],
  website: ['webstesi', 'websitesi', 'website', 'web', 'site'],
  rep: ['musteritemsilcisi', 'temsilci', 'sorumlu', 'satisci', 'person'],
  notes: ['notlarmetin', 'notlar', 'notes', 'not'],
  score: ['puanlama', 'puan', 'score'],
  sector: ['sektoralsaturetici', 'sektor', 'sector'],
};

const norm = (s: string) => s.replace(/İ/g, 'i').normalize('NFD').replace(/\p{Diacritic}/gu, '').replace(/ı/g, 'i').toLowerCase().replace(/[^a-z0-9]/g, '');
const clean = (v: unknown) => String(v ?? '').replace(/\s+/g, ' ').trim();
const emailsOf = (raw: string) => [...new Set(raw.split(/[;,|\s]+/).filter((e) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)).map((e) => e.toLowerCase()))];

export interface DomesticImportReport {
  sheet: string;
  rows: number;
  created: number;
  duplicates: number;
  skipped: number;
  notDomestic: number;
  withEmail: number;
  withCity: number;
  withPerson: number;
  // places that are not provinces or known districts (kept as written; an admin can place them)
  unknownPlaces: string[];
  byCity: { city: string; count: number }[];
  sample: { company: string; city: string | null; email: string | null; person: string | null }[];
  columnsFound: string[];
}

function pickSheet(wb: XLSX.WorkBook): { name: string; rows: unknown[][] } {
  for (const name of wb.SheetNames) {
    const rows = XLSX.utils.sheet_to_json<unknown[]>(wb.Sheets[name], { header: 1, defval: '', blankrows: false });
    const head = (rows[0] ?? []).map((h) => norm(String(h)));
    if (head.some((h) => ALIASES.company.includes(h))) return { name, rows };
  }
  throw new Error('Could not find a sheet with a company column (for example "Cari Ünvan", "Ad 1" or "Company"). The first line must name the columns.');
}

export async function importDomestic(opts: { buffer: Buffer; exhibitionId: number; userId: number; dryRun: boolean }): Promise<DomesticImportReport> {
  const wb = XLSX.read(opts.buffer, { type: 'buffer' });
  const { name, rows } = pickSheet(wb);
  const head = (rows[0] ?? []).map((h) => norm(String(h)));
  const col: Record<string, number> = {};
  for (const [key, names] of Object.entries(ALIASES)) {
    const i = head.findIndex((h) => names.includes(h));
    if (i >= 0) col[key] = i;
  }
  // a column named "Müşteri" is the SAP number only when another column holds the name
  if (col.company !== undefined && col.company === col.sap) delete col.sap;
  const get = (r: unknown[], key: string) => (col[key] === undefined ? '' : clean(r[col[key]]));

  const have = new Set(
    (db.prepare("SELECT badge_id FROM cards WHERE badge_id LIKE 'dom:%'").all() as { badge_id: string }[]).map((r) => r.badge_id)
  );
  const report: DomesticImportReport = {
    sheet: name, rows: rows.length - 1, created: 0, duplicates: 0, skipped: 0, notDomestic: 0, withEmail: 0, withCity: 0, withPerson: 0,
    unknownPlaces: [], byCity: [], sample: [], columnsFound: Object.keys(col),
  };
  const unknown = new Map<string, number>();
  const byCity = new Map<string, number>();
  const FOUND: FieldStatusMap = {
    name: 'found', company: 'found', address: 'found', country: 'found', tel: 'found', email: 'found', position: 'found', interestedIn: 'found',
    workArea: 'found', date: 'found', person: 'found', rate: 'found', notes: 'found',
  };
  const staff = userModel.listActive();
  const cityOwner = new Map<string, string | null>();
  const ownerOfCity = (city: string | null) => {
    if (!city) return null;
    const k = placeKey(city);
    if (!cityOwner.has(k)) cityOwner.set(k, cityModel.findByCity(city)?.responsible ?? null);
    return cityOwner.get(k)!;
  };

  if (!opts.dryRun) db.exec('BEGIN');
  try {
    for (let i = 1; i < rows.length; i += 1) {
      const r = rows[i];
      const company = get(r, 'company');
      if (!company) {
        report.skipped += 1;
        continue;
      }
      // a sheet that mixes domestic and export customers: only the domestic ones
      const scope = placeKey(get(r, 'scope'));
      const country = get(r, 'country');
      const countryKey = placeKey(country);
      if ((scope && !scope.startsWith('yurtici')) || (!scope && country && !['turkiye', 'turkey', 'tr', 'turkei'].includes(countryKey))) {
        report.notDomestic += 1;
        continue;
      }

      const rawCity = get(r, 'city');
      const district = get(r, 'district');
      let place = resolveCity(rawCity);
      if (!place.known && district) {
        const byDistrict = resolveCity(district);
        if (byDistrict.known) place = byDistrict;
      }
      const address = [get(r, 'address'), district && !placeKey(get(r, 'address')).includes(placeKey(district)) ? district : '', !place.known ? rawCity : ''].filter(Boolean).join(' ');
      if (!place.known) {
        const guess = guessCityFromAddress(`${get(r, 'address')} ${rawCity}`);
        if (guess) place = { city: guess, known: true };
      }
      const city = place.city;
      if (rawCity && !place.known) unknown.set(rawCity, (unknown.get(rawCity) ?? 0) + 1);
      const sap = get(r, 'sap');
      const key = `dom:${sap || placeKey(company).replace(/[^a-z0-9]/g, '')}|${city ? placeKey(city) : ''}`;
      if (have.has(key)) {
        report.duplicates += 1;
        continue;
      }
      have.add(key);

      const emails = [...new Set([...emailsOf(get(r, 'email')), ...emailsOf(get(r, 'email2')), ...emailsOf(get(r, 'email3'))])];
      const rep = get(r, 'rep');
      const repIsNobody = !rep || ['tece', '-', 'none', 'yok'].includes(placeKey(rep));
      const matched = repIsNobody ? null : matchPerson(rep, staff).name;
      const person = matched ?? ownerOfCity(city);
      const phones = [get(r, 'phone'), get(r, 'phone2')].filter(Boolean);
      const kind = placeKey(get(r, 'kind'));
      const fields: ExtractedCardFields = {
        name: [get(r, 'contact'), get(r, 'contact2')].filter(Boolean).join(', ') || null,
        company,
        address: address || null,
        country: 'Turkey',
        tel: phones.join(' / ') || null,
        email: emails.join(', ') || null,
        position: null,
        interestedIn: null,
        workArea: get(r, 'sector') || null,
        date: null,
        person,
        rate: null,
        notes: get(r, 'notes') || null,
      };
      report.created += 1;
      if (emails.length) report.withEmail += 1;
      if (city) {
        report.withCity += 1;
        byCity.set(city, (byCity.get(city) ?? 0) + 1);
      }
      if (person) report.withPerson += 1;
      if (report.sample.length < 12) report.sample.push({ company, city, email: emails[0] ?? null, person });

      if (!opts.dryRun) {
        cardModel.createFromExtraction({
          exhibitionId: opts.exhibitionId,
          uploadedBy: opts.userId,
          imagePath: '',
          fields,
          fieldStatus: FOUND,
          extractionModel: 'domestic-list',
          status: 'confirmed',
          badgeId: key,
          // somebody with a SAP number has bought from us; the rest are still leads
          stage: sap || kind.startsWith('musteri') ? 'customer' : 'lead',
          website: get(r, 'website') || null,
          market: 'domestic',
          city,
          sap: sap || null,
          leadInfo: { sap: sap || null, score: Number(get(r, 'score')) || null, businessType: get(r, 'sector') || null, source: 'domestic list' },
        });
      }
      if (i % 1000 === 0) {
        if (!opts.dryRun) db.exec('COMMIT');
        await new Promise((resolve) => setImmediate(resolve));
        if (!opts.dryRun) db.exec('BEGIN');
      }
    }
    if (!opts.dryRun) db.exec('COMMIT');
  } catch (err) {
    if (!opts.dryRun) db.exec('ROLLBACK');
    throw err;
  }
  report.unknownPlaces = [...unknown.entries()].sort((a, b) => b[1] - a[1]).slice(0, 25).map(([c, n]) => `${c} (${n})`);
  report.byCity = [...byCity.entries()].sort((a, b) => b[1] - a[1]).slice(0, 15).map(([city, count]) => ({ city, count }));
  return report;
}
