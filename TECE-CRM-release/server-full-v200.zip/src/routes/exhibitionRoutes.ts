import { Router } from 'express';
import { exhibitionModel, visibleFor } from '../models/exhibitionModel';
import { cardModel } from '../models/cardModel';
import { requireAuth, requireAdmin, type AuthedRequest } from '../middleware/auth';
import { syncExhibitionFolders } from '../services/customerFiles';
import { upload } from '../middleware/upload';
import { compressScan } from '../services/scanImage';
import fs from 'fs';
import path from 'path';
import { paths } from '../config/env';
import { db } from '../db/connection';
import { visibilitySql } from '../services/visibility';
import { hasBudget } from '../services/permissions';
import { eventTotals } from '../services/eventBudget';

const router = Router();

router.use(requireAuth);

// The fairs the team can pick (the fair scanner, the filters): a fair starts to show the day before it begins, and goes 6 months after it ended. The admin sees all.
router.get('/', (req: AuthedRequest, res) => {
  res.json(exhibitionModel.withAttendees(visibleFor(exhibitionModel.listActive(), req.user!.role === 'admin')));
});

// The coming fairs (from today), for the Home page: everybody sees them, with who goes.
router.get('/upcoming', (_req, res) => {
  res.json(exhibitionModel.withAttendees(exhibitionModel.upcoming()));
});

// The fairs that have started or are over (the Home page): for each, how many people were met (that this person may see), how many of them
// somebody has already been in touch with, and how many of those this person did. Nothing here is counted for fairs the person has no customers of.
router.get('/recent', (req: AuthedRequest, res) => {
  const user = req.user!;
  const isAdmin = user.role === 'admin';
  const today = new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });
  const list = visibleFor(exhibitionModel.listActive(), isAdmin)
    .filter((e) => e.start_date && e.start_date <= today)
    .sort((a, b) => ((b.end_date || b.start_date) ?? '').localeCompare((a.end_date || a.start_date) ?? ''))
    .slice(0, req.query.all ? 200 : 3);
  const days = (iso: string) => Math.round((Date.parse(`${today}T12:00:00Z`) - Date.parse(`${iso}T12:00:00Z`)) / 86400000);
  const worked = "EXISTS (SELECT 1 FROM activities w WHERE w.card_id = cards.id AND w.imported = 0 AND w.type IN ('note', 'call', 'visit', 'meeting', 'sample', 'thank_you', 'offer', 'documents', 'email')";
  const out = list
    .map((e) => {
      const base: Record<string, string | number> = { ex: e.id };
      const vis = visibilitySql(user, base);
      const where = `exhibition_id = @ex${vis ? ` AND ${vis}` : ''}`;
      const n = (extra: string, params: Record<string, string | number> = base) =>
        (db.prepare(`SELECT COUNT(*) AS n FROM cards WHERE ${where}${extra}`).get(params) as { n: number }).n;
      const met = n('');
      return {
        id: e.id,
        name: e.name,
        location: e.location,
        startDate: e.start_date,
        endDate: e.end_date,
        presence: e.presence,
        photo: e.photo_path,
        ongoing: (e.end_date || e.start_date)! >= today,
        daysAgo: Math.max(0, days((e.end_date || e.start_date)!)),
        met,
        contacted: n(` AND ${worked})`),
        contactedByMe: n(` AND ${worked} AND w.user_id = @me)`, { ...base, me: user.id }),
        offers: n(' AND EXISTS (SELECT 1 FROM offers_sent o WHERE o.card_id = cards.id)'),
      };
    })
    // a person who has no customer from a fair (the domestic team, for one) does not need it on the Home page
    .filter((f) => isAdmin || f.met > 0);
  res.json(out);
});

// ---- The fair board: every fair that is over or running (what became of the people we met) and the fairs that come next ---------------------------
// One answer for the Fairs page and for the Home page. All the numbers are the visitors THIS person may see.
const TOUCH = "('note', 'call', 'visit', 'meeting', 'sample', 'thank_you', 'offer', 'documents', 'email')";
const istToday = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });
const daysBetween = (a: string, b: string) => Math.round((Date.parse(`${b}T12:00:00Z`) - Date.parse(`${a}T12:00:00Z`)) / 86400000);

router.get('/board', (req: AuthedRequest, res) => {
  const user = req.user!;
  const isAdmin = user.role === 'admin';
  const today = istToday();
  const all = visibleFor(exhibitionModel.listActive(), isAdmin).filter((e) => e.start_date);
  const past = all.filter((e) => e.start_date! <= today).sort((a, b) => ((b.end_date || b.start_date) ?? '').localeCompare((a.end_date || a.start_date) ?? '')).slice(0, 60);
  const budgetOk = hasBudget(user as never);
  const money = budgetOk ? eventTotals('exhibition', [...past.map((e) => e.id), ...exhibitionModel.upcoming().map((e) => e.id)]) : null;
  const rows = past.map((e) => {
    const p: Record<string, string | number> = { ex: e.id, me: user.id };
    const vis = visibilitySql(user, p);
    const scope = `cards.exhibition_id = @ex${vis ? ` AND ${vis}` : ''}`;
    const touched = `EXISTS (SELECT 1 FROM activities w WHERE w.card_id = cards.id AND w.imported = 0 AND w.type IN ${TOUCH})`;
    const r = db.prepare(`SELECT COUNT(*) AS met,
        SUM(CASE WHEN ${touched} THEN 1 ELSE 0 END) AS contacted,
        SUM(CASE WHEN EXISTS (SELECT 1 FROM activities w WHERE w.card_id = cards.id AND w.imported = 0 AND w.user_id = @me AND w.type IN ${TOUCH}) THEN 1 ELSE 0 END) AS byMe,
        SUM(CASE WHEN thank_you_sent_at IS NOT NULL THEN 1 ELSE 0 END) AS thanked,
        SUM(CASE WHEN EXISTS (SELECT 1 FROM offers_sent o WHERE o.card_id = cards.id) THEN 1 ELSE 0 END) AS offers,
        SUM(CASE WHEN stage = 'customer' OR COALESCE(sap, '') != '' THEN 1 ELSE 0 END) AS won,
        SUM(CASE WHEN COALESCE(rate, CASE WHEN ai_rate IS NOT NULL THEN ai_rate / 10 END, 0) >= 7 THEN 1 ELSE 0 END) AS hot,
        SUM(CASE WHEN COALESCE(rate, CASE WHEN ai_rate IS NOT NULL THEN ai_rate / 10 END, 0) >= 7 AND NOT ${touched} THEN 1 ELSE 0 END) AS hotWaiting,
        COUNT(DISTINCT NULLIF(TRIM(COALESCE(country, '')), '')) AS countries
      FROM cards WHERE ${scope}`).get(p) as Record<string, number | null>;
    const met = Number(r.met ?? 0);
    const last = (e.end_date || e.start_date)!;
    const m = money?.get(e.id);
    return {
      id: e.id, name: e.name, location: e.location, startDate: e.start_date, endDate: e.end_date, presence: e.presence, photo: e.photo_path,
      ongoing: last >= today, daysAgo: Math.max(0, daysBetween(last, today)),
      met, contacted: Number(r.contacted ?? 0), contactedByMe: Number(r.byMe ?? 0), thanked: Number(r.thanked ?? 0), offers: Number(r.offers ?? 0), won: Number(r.won ?? 0),
      hot: Number(r.hot ?? 0), hotWaiting: Number(r.hotWaiting ?? 0), waiting: met - Number(r.contacted ?? 0), countries: Number(r.countries ?? 0),
      budget: m && (m.planned > 0 || m.spent > 0) ? m : null,
    };
  }).filter((f) => isAdmin || f.met > 0);
  const next = exhibitionModel.withAttendees(exhibitionModel.upcoming()).filter((e) => e.start_date! > today).map((e) => {
    const m = money?.get(e.id);
    return { id: e.id, name: e.name, location: e.location, startDate: e.start_date, endDate: e.end_date, presence: e.presence, photo: e.photo_path, inDays: daysBetween(today, e.start_date!), attendees: e.attendees ?? [], budget: m && (m.planned > 0 || m.spent > 0) ? m : null };
  });
  res.json({ today, past: rows, next, canBudget: budgetOk, isAdmin });
});

// ---- Fair focus: the visitors of one fair, one after the other (like a sprint): who is still waiting, who is hot, what was said at the stand ------------
router.get('/:id/focus', (req: AuthedRequest, res) => {
  const user = req.user!;
  const e = exhibitionModel.findById(parseInt(String(req.params.id), 10));
  if (!e) return res.status(404).json({ error: 'Fair not found' });
  const p: Record<string, string | number> = { ex: e.id };
  const vis = visibilitySql(user, p);
  const q: Record<string, string | number> = { ...p, me: user.id };
  const rows = db.prepare(`SELECT c.id, c.company, c.name, c.last_name AS lastName, c.position, c.country, c.city, c.email, c.tel, c.mobile, c.website, c.rate, c.ai_rate AS aiRate, c.ai_rate_reason AS aiReason,
      c.notes, c.interested_in AS interestedIn, c.interest_products AS products, c.work_area AS workArea, c.stage, c.pipeline_stage AS pipelineStage, c.exit_status AS exitStatus, c.person AS owner, c.thank_you_sent_at AS thankedAt,
      c.image_path AS image, c.sap, c.created_at AS metAt, c.language,
      (SELECT MAX(a.created_at) FROM activities a WHERE a.card_id = c.id AND a.imported = 0 AND a.type IN ${TOUCH}) AS lastTouch,
      (SELECT COUNT(*) FROM activities a WHERE a.card_id = c.id AND a.imported = 0 AND a.type IN ${TOUCH}) AS touches,
      (SELECT COUNT(*) FROM activities a WHERE a.card_id = c.id AND a.imported = 0 AND a.user_id = @me AND a.type IN ${TOUCH}) AS myTouches,
      (SELECT COUNT(*) FROM offers_sent o WHERE o.card_id = c.id) AS offers,
      (SELECT MIN(t.due_date) FROM todos t WHERE t.card_id = c.id AND t.done_at IS NULL) AS todoDue,
      (SELECT f.state FROM fair_focus_state f WHERE f.card_id = c.id AND f.user_id = @me AND (f.until IS NULL OR f.until > date('now'))) AS parked
    FROM cards c WHERE c.id IN (SELECT id FROM cards WHERE exhibition_id = @ex${vis ? ` AND ${vis}` : ''}) ORDER BY c.id LIMIT 5000`).all(q) as Record<string, unknown>[];
  const last = new Map<number, { type: string; text: string | null; at: string; by: string | null }>();
  if (rows.length) {
    const acts = db.prepare(`SELECT a.card_id AS cardId, a.type, a.text, a.created_at AS at, u.display_name AS by FROM activities a LEFT JOIN users u ON u.id = a.user_id
      WHERE a.imported = 0 AND a.type IN ${TOUCH} AND a.card_id IN (SELECT id FROM cards WHERE exhibition_id = @ex) ORDER BY a.created_at DESC`).all({ ex: e.id }) as unknown as { cardId: number; type: string; text: string | null; at: string; by: string | null }[];
    for (const a of acts) if (!last.has(a.cardId)) last.set(a.cardId, { type: a.type, text: a.text ? a.text.slice(0, 280) : null, at: a.at, by: a.by });
  }
  const me = user.display_name;
  const visitors = rows.map((r) => {
    const score = typeof r.rate === 'number' ? r.rate : typeof r.aiRate === 'number' ? Math.round((r.aiRate as number) / 10) : null;
    let products: string[] = [];
    try { const v = JSON.parse(String(r.products ?? '[]')); if (Array.isArray(v)) products = v.map(String).slice(0, 8); } catch { products = []; }
    return { ...r, products, score, mine: !!me && r.owner === me, lastNote: last.get(r.id as number) ?? null };
  });
  const today = istToday();
  const lastDay = e.end_date || e.start_date;
  res.json({
    fair: { id: e.id, name: e.name, location: e.location, startDate: e.start_date, endDate: e.end_date, presence: e.presence, photo: e.photo_path, feedback: e.feedback, ongoing: !!lastDay && lastDay >= today && !!e.start_date && e.start_date <= today, daysAgo: lastDay ? Math.max(0, daysBetween(lastDay, today)) : null },
    visitors, today,
  });
});

// park a visitor for later, close it ("nothing to do here") or bring it back
router.post('/:id/focus/state', (req: AuthedRequest, res) => {
  const user = req.user!;
  const cardId = parseInt(String(req.body?.cardId ?? ''), 10);
  const card = cardModel.findById(cardId);
  if (!card || card.exhibition_id !== parseInt(String(req.params.id), 10)) return res.status(404).json({ error: 'Not found' });
  const state = req.body?.state;
  if (state === 'later' || state === 'closed') {
    const days = Math.max(1, Math.min(60, parseInt(String(req.body?.days ?? '3'), 10) || 3));
    db.prepare(`INSERT INTO fair_focus_state (user_id, card_id, state, until) VALUES (?, ?, ?, ${state === 'later' ? "date('now', ?)" : 'NULL'})
      ON CONFLICT(user_id, card_id) DO UPDATE SET state = excluded.state, until = excluded.until, at = datetime('now')`).run(...(state === 'later' ? [user.id, cardId, state, `+${days} day`] : [user.id, cardId, state]));
  } else db.prepare('DELETE FROM fair_focus_state WHERE user_id = ? AND card_id = ?').run(user.id, cardId);
  res.json({ ok: true });
});

router.get('/all', requireAdmin, (_req, res) => {
  res.json(exhibitionModel.withAttendees(exhibitionModel.listAll()));
});

router.get('/default', (_req, res) => {
  res.json(exhibitionModel.findDefault() || null);
});

router.post('/', requireAdmin, (req: AuthedRequest, res) => {
  const { name, location, startDate, endDate, presence, attendeeIds } = req.body || {};
  if (!name) {
    return res.status(400).json({ error: 'name is required' });
  }
  const ids = Array.isArray(attendeeIds) ? attendeeIds.map((n: unknown) => Math.trunc(Number(n))) : undefined;
  const exhibition = exhibitionModel.create({ name, location, startDate, endDate, createdBy: req.user!.id, presence, attendeeIds: ids });
  res.status(201).json(exhibitionModel.withAttendees([exhibition])[0]);
});

router.patch('/:id', requireAdmin, (req, res) => {
  const id = parseInt(String(req.params.id), 10);
  const existing = exhibitionModel.findById(id);
  if (!existing) return res.status(404).json({ error: 'Not found' });

  const { name, location, startDate, endDate, isArchived, emailTemplateSubject, emailTemplateBody, feedback, presence, attendeeIds } = req.body || {};
  const updated = exhibitionModel.update(id, {
    presence,
    attendeeIds: Array.isArray(attendeeIds) ? attendeeIds.map((n: unknown) => Math.trunc(Number(n))) : undefined,
    feedback,
    name,
    location,
    startDate,
    endDate,
    isArchived,
    emailTemplateSubject,
    emailTemplateBody,
  });
  // the exhibition's folder is named after it
  if (name !== undefined && name !== existing.name) syncExhibitionFolders(id);
  res.json(updated ? exhibitionModel.withAttendees([updated])[0] : updated);
});

// A photo of the fair, printed at the top of the PDF reports (shrunk like the scans).
router.post('/:id/photo', requireAdmin, upload.single('photo'), async (req, res) => {
  const id = parseInt(String(req.params.id), 10);
  const existing = exhibitionModel.findById(id);
  if (!existing) return res.status(404).json({ error: 'Not found' });
  if (!req.file) return res.status(400).json({ error: 'photo file is required' });
  const stored = await compressScan(path.basename(req.file.path));
  if (existing.photo_path) fs.unlink(path.join(paths.uploadsDir, existing.photo_path), () => undefined);
  exhibitionModel.setPhoto(id, stored);
  res.json(exhibitionModel.findById(id));
});

router.delete('/:id/photo', requireAdmin, (req, res) => {
  const id = parseInt(String(req.params.id), 10);
  const existing = exhibitionModel.findById(id);
  if (!existing) return res.status(404).json({ error: 'Not found' });
  if (existing.photo_path) fs.unlink(path.join(paths.uploadsDir, existing.photo_path), () => undefined);
  exhibitionModel.setPhoto(id, null);
  res.json(exhibitionModel.findById(id));
});

router.delete('/:id', requireAdmin, (req, res) => {
  const id = parseInt(String(req.params.id), 10);
  const existing = exhibitionModel.findById(id);
  if (!existing) return res.status(404).json({ error: 'Not found' });
  if (cardModel.countForExhibition(id) > 0) {
    return res.status(400).json({ error: 'This exhibition already has scanned cards - it can only be archived, not deleted.' });
  }
  exhibitionModel.delete(id);
  res.json({ ok: true });
});

router.patch('/:id/set-default', requireAdmin, (req, res) => {
  const id = parseInt(String(req.params.id), 10);
  const target = exhibitionModel.findById(id);
  if (!target) return res.status(404).json({ error: 'Not found' });
  if (target.is_archived) return res.status(400).json({ error: 'Cannot set an archived exhibition as default' });
  res.json(exhibitionModel.setDefault(id));
});

export default router;
