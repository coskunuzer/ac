import path from 'path';
import fs from 'fs';
import PDFDocument from 'pdfkit';
import { env } from '../config/env';
import { drawLogo, registerDesignFonts } from './priceBook/designed';

// A customer complaint: what the salesperson wrote, the numbers of the order (for a quantity complaint), the photos, and a clean Turkish text
// that the AI writes from them. The PDF is in the TECE design and goes to the people who deal with it.

export const KINDS = ['quantity', 'quality', 'delivery', 'other'] as const;
export type ComplaintKind = (typeof KINDS)[number];
export const KIND_TR: Record<ComplaintKind, string> = { quantity: 'Miktar farkı', quality: 'Kalite sorunu', delivery: 'Teslimat sorunu', other: 'Diğer' };

export interface ComplaintItem { ref: string; width: number | null; thickness: number | null; ordered: number | null; shipped: number | null }
export interface ItemResult extends ComplaintItem { variance: number | null; shortage: number; excess: number; fulfillment: number | null; status: string }

export interface Polished {
  title: string;
  summary: string;
  details: string[];
  impact: string;
  requested: string;
}

export const complaintsDir = path.resolve(__dirname, '../../data/complaints');

const num = (v: unknown): number | null => {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(String(v).replace(',', '.'));
  return Number.isFinite(n) ? n : null;
};

export function cleanItems(raw: unknown): ComplaintItem[] {
  return (Array.isArray(raw) ? raw : []).slice(0, 60).map((x) => {
    const r = (x ?? {}) as Record<string, unknown>;
    return { ref: String(r.ref ?? '').trim().slice(0, 80), width: num(r.width), thickness: num(r.thickness), ordered: num(r.ordered), shipped: num(r.shipped) };
  }).filter((i) => i.ref || i.ordered !== null || i.shipped !== null);
}

// the figures of a quantity complaint: shipped against ordered
export function workOut(items: ComplaintItem[]): { rows: ItemResult[]; total: { ordered: number; shipped: number; variance: number; shortage: number; excess: number; fulfillment: number | null } } {
  const rows = items.map((i) => {
    const variance = i.ordered !== null && i.shipped !== null ? i.shipped - i.ordered : null;
    const fulfillment = i.ordered ? (i.shipped !== null ? Math.round((i.shipped / i.ordered) * 1000) / 10 : null) : null;
    const status = variance === null ? '' : variance < 0 ? 'Short shipped' : variance > 0 ? 'Over shipped' : 'Complete';
    return { ...i, variance, shortage: variance !== null && variance < 0 ? -variance : 0, excess: variance !== null && variance > 0 ? variance : 0, fulfillment, status };
  });
  const ordered = rows.reduce((a, r) => a + (r.ordered ?? 0), 0);
  const shipped = rows.reduce((a, r) => a + (r.shipped ?? 0), 0);
  return {
    rows,
    total: { ordered, shipped, variance: shipped - ordered, shortage: rows.reduce((a, r) => a + r.shortage, 0), excess: rows.reduce((a, r) => a + r.excess, 0), fulfillment: ordered ? Math.round((shipped / ordered) * 1000) / 10 : null },
  };
}

// ---- the AI writes the clean text ---------------------------------------------------------------------------------------------------------
const GEMINI_URL = process.env.GEMINI_BASE_URL || 'https://generativelanguage.googleapis.com/v1beta/models';
const MODEL = 'gemini-3.6-flash';
const SCHEMA = {
  type: 'OBJECT',
  properties: {
    title: { type: 'STRING' }, summary: { type: 'STRING' }, details: { type: 'ARRAY', items: { type: 'STRING' } }, impact: { type: 'STRING' }, requested: { type: 'STRING' },
  },
  required: ['title', 'summary', 'details', 'impact', 'requested'],
};

// What the AI must know to understand a complaint of this trade, even when it is written in a hurry or in another language.
const EXPERT = [
  'You are a senior edgebanding expert at TECE (TECE Dekor A.S., Bursa, Turkey) with 20 years in quality control, production planning and export logistics. You help a salesperson turn a customer complaint into a clear report for the internal teams (quality, production, logistics, management).',
  'Your knowledge of the trade:',
  '- Edgebanding is the thin plastic or veneer tape glued on the edge of furniture panels (chipboard, MDF). Materials: PVC, ABS, PP (recycled), melamine, real wood veneer, acrylic / high gloss, laser and zero-joint (air, hot-air) edges. The decor is colour-matched to the panel brands (Egger, Kronospan, Kastamonu, AGT, Swiss Krono ...).',
  '- Sizes: thickness in mm (0.4 to 3), width in mm (about 9 to 610; typical 22, 33, 44), sold in rolls of a fixed length (for example 300 m for 0.4 mm, 100 m for 2 mm) or by the meter; rolls are packed in boxes. Orders are in meters; the price is per meter or per m2. Every colour has a SAP code (for example 12000.012 for PVC, 40001.042 for ABS).',
  '- Typical complaints and the words used for them: colour difference or shade deviation against the panel or the earlier delivery (renk farkı, delta E); wrong decor or wrong SAP code sent; wrong thickness or width, or a roll that is narrower/wider than ordered (tolerance is normally a fraction of a mm); too short rolls or fewer meters than ordered (eksik metre / short shipment) or more than ordered (excess); surface faults: scratches, dirt, dots, stripes, print defects, gloss or matt not as the sample, embossing (texture) different; curling or warping, brittleness or cracking (especially in cold), edges that do not stick or peel (adhesion, primer, glue line, hot melt problem - which can also come from the customer machine settings); white edge or glue line visible after trimming; splices or joints in the roll; core, winding and packaging damage; delay in delivery, wrong address or missing documents (packing list, invoice, certificates); price or invoice differences.',
  '- Tolerance on quantity in the contract is usually +10% / -10%: say clearly when a difference is inside or outside it, if the numbers show it.',
  'Rules for the report: understand what the salesperson means even if the text is short, mixed in two languages or full of abbreviations (EB, mt, kg, MOQ, PVC/ABS/PP, "22x1" meaning 22 mm wide and 1 mm thick). Name the problem with the correct trade word. Use only the facts given: never invent a cause, a number, a name or a date; if the cause is not known, write that it must be investigated. Do not blame the customer or a colleague.',
  'Write for TECE colleagues who must act: clear, short, well structured.',
];

export async function polishComplaint(input: { kind: ComplaintKind; customer: string; country: string; orderNo: string; text: string; items: ItemResult[]; amount: number | null; currency: string; photos: number }): Promise<Polished | null> {
  if (!env.geminiApiKey) return null;
  const figures = input.items.length
    ? 'Order lines (shipped against ordered, in meters): ' + input.items.map((i) => `${i.ref} ${i.width ?? ''}x${i.thickness ?? ''}: ordered ${i.ordered ?? '?'}, shipped ${i.shipped ?? '?'}, ${i.status}`).join('; ')
    : '';
  const prompt = [
    ...EXPERT,
    'Write in clear, natural, polite business Turkish. Be short and well structured; no long sentences, no repetition, no blame, no invented facts. Use only what is given. Keep numbers, codes, names and units exactly.',
    'Return JSON: title (a short title, at most 10 words), summary (2 or 3 sentences: what happened), details (3 to 6 short bullet sentences with the facts: what, where, how much), impact (1 or 2 sentences: what it caused for the customer and for TECE, including the amount if given), requested (1 or 2 sentences: what is asked from the team, for example investigate, replace, credit note; if nothing is stated, a sensible neutral request).',
    `Type of complaint: ${KIND_TR[input.kind]}. Customer: ${input.customer || '-'} (${input.country || '-'}). Order number: ${input.orderNo || '-'}. Amount lost: ${input.amount !== null ? `${input.amount} ${input.currency}` : 'not given'}. Photos attached: ${input.photos}.`,
    figures,
    `What the salesperson wrote (any language): """${input.text.slice(0, 4000)}"""`,
  ].filter(Boolean).join('\n');
  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      const res = await fetch(`${GEMINI_URL}/${MODEL}:generateContent`, {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-goog-api-key': env.geminiApiKey },
        body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { responseMimeType: 'application/json', responseSchema: SCHEMA, temperature: 0.3 } }),
        signal: AbortSignal.timeout(60000),
      });
      if (!res.ok) { if (res.status === 429 || res.status >= 500) { await new Promise((r) => setTimeout(r, 1500)); continue; } return null; }
      const data = (await res.json()) as { candidates?: { content?: { parts?: { text?: string; thought?: boolean }[] } }[] };
      const parts = data.candidates?.[0]?.content?.parts?.filter((p) => !p.thought && p.text) ?? [];
      const text = parts[parts.length - 1]?.text;
      if (!text) return null;
      const j = JSON.parse(text) as Partial<Polished>;
      if (!j.title || !j.summary) return null;
      return { title: String(j.title), summary: String(j.summary), details: (Array.isArray(j.details) ? j.details : []).map(String).filter(Boolean).slice(0, 8), impact: String(j.impact ?? ''), requested: String(j.requested ?? '') };
    } catch { await new Promise((r) => setTimeout(r, 1000)); }
  }
  return null;
}

// ---- the PDF ------------------------------------------------------------------------------------------------------------------------------
const NAVY = '#17243E';
const RED = '#8B1931';
const STEEL = '#5E6676';
const MIST = '#F3F4F7';
const SMOKE = '#E3E6EC';

export interface ComplaintPdfInput {
  id: number;
  kind: ComplaintKind;
  date: string;
  customer: { name: string; contact: string; email: string; country: string };
  orderNo: string;
  by: string;
  polished: Polished;
  items: ComplaintItem[];
  amount: number | null;
  currency: string;
  images: { file: string; caption: string }[];
}

const tr = (n: number | null, d = 0) => (n === null ? '' : n.toLocaleString('tr-TR', { minimumFractionDigits: d, maximumFractionDigits: d }));
const STATUS_TR: Record<string, string> = { 'Short shipped': 'Eksik sevk', 'Over shipped': 'Fazla sevk', Complete: 'Tam' };

export async function renderComplaintPdf(c: ComplaintPdfInput): Promise<Buffer> {
  const doc = new PDFDocument({ size: 'A4', margin: 0, autoFirstPage: false, info: { Title: `TECE şikâyet formu #${c.id}`, Author: 'TECE' } });
  const chunks: Buffer[] = [];
  doc.on('data', (b: Buffer) => chunks.push(b));
  const done = new Promise<Buffer>((resolve, reject) => { doc.on('end', () => resolve(Buffer.concat(chunks))); doc.on('error', reject); });
  registerDesignFonts(doc);
  const F = { r: 'TD-400', m: 'TD-500', b: 'TD-600', h: 'TD-700' };
  const PW = 595.28;
  const PH = 841.89;
  const L = 40;
  const CW = PW - 2 * L;
  const BOTTOM = PH - 46;
  let y = 0;

  const page = () => {
    doc.addPage();
    doc.rect(0, 0, PW, 58).fill(NAVY);
    drawLogo(doc, 'TECE_SloganliLogo_Beyaz_RGB.svg', L, (58 - 190 * (522 / 5990)) / 2, 190);
    doc.rect(0, 58, PW, 3).fill(RED);
    doc.font(F.h).fontSize(13).fillColor('#FFFFFF').text('MÜŞTERİ ŞİKÂYET FORMU', L, 22, { width: CW, align: 'right', lineBreak: false });
    y = 80;
  };
  const need = (h: number) => { if (y + h > BOTTOM) page(); };
  const heading = (text: string) => {
    need(40);
    doc.font(F.h).fontSize(9).fillColor(RED).text(text.toLocaleUpperCase('tr-TR'), L, y, { lineBreak: false });
    doc.rect(L, y + 14, CW, 0.8).fill(SMOKE);
    y += 22;
  };
  const para = (text: string, size = 10, font = F.r, color = '#222222', width = CW, x = L) => {
    doc.font(font).fontSize(size);
    const h = doc.heightOfString(text, { width, lineGap: 2.5 });
    need(h + 4);
    doc.fillColor(color).text(text, x, y, { width, lineGap: 2.5 });
    y += h + 6;
  };

  page();
  // title block
  doc.font(F.h).fontSize(17).fillColor(NAVY);
  const th = doc.heightOfString(c.polished.title, { width: CW });
  doc.text(c.polished.title, L, y, { width: CW });
  y += th + 6;
  doc.font(F.m).fontSize(9).fillColor(STEEL).text(`${KIND_TR[c.kind]}  ·  Şikâyet no: ${String(c.id).padStart(4, '0')}  ·  Tarih: ${c.date}`, L, y, { lineBreak: false });
  y += 22;

  // customer card
  const box = 74;
  doc.rect(L, y, CW, box).fill(MIST);
  doc.rect(L, y, 3, box).fill(RED);
  const cust: [string, string][] = [['Müşteri', c.customer.name], ['İlgili kişi', c.customer.contact], ['E-posta', c.customer.email], ['Ülke', c.customer.country]];
  const ord: [string, string][] = [['Sipariş no', c.orderNo], ['Hazırlayan', c.by], ['Kayıp tutar', c.amount !== null ? `${tr(c.amount, 2)} ${c.currency}` : '']];
  const colW = CW / 2 - 14;
  cust.filter(([, v]) => v).forEach(([k, v], i) => {
    doc.font(F.r).fontSize(8).fillColor(STEEL).text(k, L + 14, y + 10 + i * 14, { width: 62, lineBreak: false });
    doc.font(F.b).fontSize(9).fillColor('#222222').text(v, L + 78, y + 10 + i * 14, { width: colW - 66, lineBreak: false, ellipsis: true });
  });
  ord.filter(([, v]) => v).forEach(([k, v], i) => {
    doc.font(F.r).fontSize(8).fillColor(STEEL).text(k, L + CW / 2 + 6, y + 10 + i * 14, { width: 66, lineBreak: false });
    doc.font(i === 2 ? F.h : F.b).fontSize(i === 2 ? 11 : 9).fillColor(i === 2 ? RED : '#222222').text(v, L + CW / 2 + 74, y + 10 + i * 14 - (i === 2 ? 1 : 0), { width: colW - 66, lineBreak: false, ellipsis: true });
  });
  y += box + 18;

  heading('Özet');
  para(c.polished.summary, 10.5);
  if (c.polished.details.length) {
    heading('Ayrıntılar');
    for (const d of c.polished.details) {
      doc.font(F.r).fontSize(10);
      const h = doc.heightOfString(d, { width: CW - 16, lineGap: 2.5 });
      need(h + 6);
      doc.circle(L + 4, y + 5.5, 1.8).fill(RED);
      doc.fillColor('#222222').text(d, L + 16, y, { width: CW - 16, lineGap: 2.5 });
      y += h + 5;
    }
    y += 4;
  }

  // the quantities (a quantity complaint)
  const work = workOut(c.items);
  if (work.rows.length) {
    heading('Sipariş ve sevkiyat karşılaştırması (metre)');
    const cols: { t: string; w: number; a: 'left' | 'right' }[] = [
      { t: 'Referans', w: 96, a: 'left' }, { t: 'En', w: 30, a: 'right' }, { t: 'Kalınlık', w: 40, a: 'right' }, { t: 'Sipariş', w: 52, a: 'right' }, { t: 'Sevk', w: 52, a: 'right' },
      { t: 'Fark', w: 46, a: 'right' }, { t: 'Eksik', w: 46, a: 'right' }, { t: 'Fazla', w: 40, a: 'right' }, { t: 'Karşılama', w: 44, a: 'right' }, { t: 'Durum', w: 66, a: 'left' },
    ];
    const sc = CW / cols.reduce((s, x) => s + x.w, 0);
    const xs: number[] = [];
    let ax = L;
    for (const x of cols) { xs.push(ax); ax += x.w * sc; }
    const head = () => {
      need(40);
      cols.forEach((x, i) => {
        doc.rect(xs[i], y, x.w * sc, 20).fill(NAVY);
        doc.font(F.b).fontSize(7).fillColor('#FFFFFF').text(x.t, xs[i] + 3, y + 7, { width: x.w * sc - 6, align: x.a, lineBreak: false });
      });
      y += 20;
    };
    head();
    const put = (vals: string[], font: string, fill: string | null, colors: (string | null)[] = []) => {
      if (y + 17 > BOTTOM) { page(); head(); }
      if (fill) doc.rect(L, y, CW, 17).fill(fill);
      cols.forEach((x, i) => doc.font(font).fontSize(8).fillColor(colors[i] ?? '#222222').text(vals[i], xs[i] + 3, y + 5, { width: x.w * sc - 6, align: x.a, lineBreak: false, ellipsis: true }));
      y += 17;
    };
    work.rows.forEach((r, i) => put(
      [r.ref, tr(r.width), tr(r.thickness, 2), tr(r.ordered), tr(r.shipped), tr(r.variance), r.shortage ? tr(r.shortage) : '', r.excess ? tr(r.excess) : '', r.fulfillment !== null ? `%${tr(r.fulfillment, 1)}` : '', STATUS_TR[r.status] ?? r.status],
      F.r, i % 2 ? MIST : null, [null, null, null, null, null, null, r.shortage ? RED : null, null, null, r.status === 'Short shipped' ? RED : null],
    ));
    const t = work.total;
    put(['TOPLAM', '', '', tr(t.ordered), tr(t.shipped), tr(t.variance), tr(t.shortage), tr(t.excess), t.fulfillment !== null ? `%${tr(t.fulfillment, 1)}` : '', ''], F.h, SMOKE);
    y += 10;
  }

  if (c.polished.impact) { heading('Etki'); para(c.polished.impact); }
  if (c.polished.requested) { heading('Talep edilen'); para(c.polished.requested); }

  // photos: one per row, the whole width of the page, so the damage can be seen (a landscape photo is 527 x 330 pt)
  if (c.images.length) {
    const w = CW;
    const hgt = 330;
    need(hgt + 22 + 40);
    heading('Fotoğraflar');
    for (const img of c.images) {
      need(hgt + 22);
      doc.rect(L, y, w, hgt).fill(MIST);
      try { doc.image(img.file, L + 2, y + 2, { fit: [w - 4, hgt - 4], align: 'center', valign: 'center' }); } catch { /* an unreadable photo is left out */ }
      if (img.caption) doc.font(F.r).fontSize(9).fillColor(STEEL).text(img.caption, L, y + hgt + 3, { width: w, lineBreak: false, ellipsis: true });
      y += hgt + 22;
    }
  }

  doc.end();
  return done;
}

export const imagePath = (stored: string) => path.join(complaintsDir, stored);
export function ensureDir() { fs.mkdirSync(complaintsDir, { recursive: true }); }
