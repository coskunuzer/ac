-- A safe view of the people for the admin assistant: no password hash, nothing secret.
DROP VIEW IF EXISTS v_staff;
CREATE VIEW v_staff AS SELECT id, display_name, username, role, job_title, market, is_active, area FROM users;
