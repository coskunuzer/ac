import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { db } from '../db/connection';

// The archive of generated PDFs: a price list as it was on the day, a proforma as the customer got it. Prices change; these files do not.
export const archiveDir = path.resolve(__dirname, '../../data/archive');

export interface ArchiveRow { dropped_at?: string | null; dropped_by?: number | null; superseded_by?: number | null; confirmed_at?: string | null; confirmed_by?: number | null; id: number; kind: 'price_list' | 'proforma'; card_id: number | null; price_list_id: number | null; title: string | null; file_name: string; stored_name: string; created_by: number | null; created_at: string }

// Keeps a PDF. The same document made again at once is not stored twice.
export function archivePdf(input: { kind: 'price_list' | 'proforma'; cardId?: number | null; priceListId?: number | null; title: string; fileName: string; pdf: Buffer; userId?: number | null }): number | null {
  try {
    const hash = crypto.createHash('sha1').update(input.pdf).digest('hex');
    // the same document asked for again within two minutes (or exactly the same file) is kept once
    const same = db.prepare("SELECT id FROM document_archive WHERE kind = ? AND COALESCE(card_id, 0) = ? AND (hash = ? OR (title = ? AND created_at >= datetime('now', '-2 minutes')))").get(input.kind, input.cardId ?? 0, hash, input.title.slice(0, 160)) as { id: number } | undefined;
    if (same) return same.id;
    fs.mkdirSync(archiveDir, { recursive: true });
    const stored = `${Date.now()}-${hash.slice(0, 8)}.pdf`;
    fs.writeFileSync(path.join(archiveDir, stored), input.pdf);
    const r = db.prepare('INSERT INTO document_archive (kind, card_id, price_list_id, title, file_name, stored_name, hash, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)').run(
      input.kind, input.cardId ?? null, input.priceListId ?? null, input.title.slice(0, 160), input.fileName.slice(0, 160), stored, hash, input.userId ?? null
    );
    return Number(r.lastInsertRowid);
  } catch (err) {
    console.error('Archiving a PDF failed:', err);
    return null;
  }
}

export const archiveFile = (row: Pick<ArchiveRow, 'stored_name'>) => path.join(archiveDir, path.basename(row.stored_name));
