import ExcelJS from 'exceljs';
import { COUNTRY_NAMES } from '../data/countries';
import { countryKey, countryModel, type CountryRowInput } from '../models/countryModel';
import { createAssistant } from './assistants';
import { userModel, type PublicUser } from '../models/userModel';
import type { ExtractedCardFields, FieldStatusMap } from '../schema/cardSchema';

function plain(s: string): string {
  return s.normalize('NFD').replace(/\p{Diacritic}/gu, '').replace(/ı/g, 'i').toLowerCase().replace(/\s+/g, ' ').trim();
}

// "TECE" in the list means "head office, no named person" - stored as empty.
function isNobody(raw: string): boolean {
  const p = plain(raw);
  return !p || p === 'tece' || p === '-' || p === 'n/a' || p === 'none';
}

// Match a name written in the list ("Insaf", "Sunay Balaban") to a person's
// display name. Exact first, then a first-name match - the list usually has only
// the first name. If two people share that first name it is "ambiguous".
export function matchPerson(raw: string, people: PublicUser[]): { name: string | null; ambiguous: string[] } {
  const want = plain(raw);
  const names = people.map((u) => u.display_name).filter((n): n is string => !!n);
  const exact = names.find((n) => plain(n) === want);
  if (exact) return { name: exact, ambiguous: [] };
  // the same name twice (two accounts for one person) is still one person
  const loose = [...new Set(names.filter((n) => {
    const p = plain(n);
    return p.startsWith(want + ' ') || want.startsWith(p + ' ') || p.split(' ')[0] === want;
  }))];
  return loose.length === 1 ? { name: loose[0], ambiguous: [] } : { name: null, ambiguous: loose };
}

export function matchStaffName(raw: string, staff: PublicUser[]): string | null {
  return matchPerson(raw, staff).name;
}

export interface ImportSummary {
  countries: number;
  withResponsible: number;
  withAssistant: number;
  noNamedResponsible: number;
  // names that match more than one person ("Ivan" when there are two Ivans): left for you to pick
  unmatchedNames: string[];
  // sales people added without a login by this upload, and which of them still need an email
  salesAdded: string[];
  salesWithoutEmail: string[];
  // assistants added without a login by this upload, and which of them still need an email
  assistantsAdded: string[];
  assistantsWithoutEmail: string[];
  notInAppList: string[];
  // countries that had a person set before but are not in this file (left as they were)
  notInFile: string[];
}

const EMAIL_RE = /^[^\s@,;]+@[^\s@,;]+\.[^\s@,;]+$/;

function cellText(v: ExcelJS.CellValue): string {
  if (v === null || v === undefined) return '';
  if (typeof v === 'object') {
    if ('richText' in v) return v.richText.map((r) => r.text).join('').trim();
    if ('text' in v && typeof v.text === 'string') return v.text.trim();
    if ('result' in v && v.result !== undefined) return String(v.result).trim();
    return '';
  }
  return String(v).trim();
}

// Reads the country list workbook: row 1 headers, with "Country", "Sales
// Manager" and "Assist" (other columns are ignored). Every country in the file
// is set to exactly what the file says, replacing what was there. People in the
// list who are not in the app yet (no login) are added as email-only people.
export async function importCountryList(buffer: Buffer): Promise<ImportSummary> {
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.load(buffer as unknown as ArrayBuffer);
  const ws = wb.worksheets[0];
  if (!ws) throw new Error('The workbook has no sheets.');

  const header: Record<string, number> = {};
  ws.getRow(1).eachCell((cell, col) => {
    header[plain(cellText(cell.value))] = col;
  });
  const colCountry = header['country'];
  const colSales = header['sales manager'] ?? header['responsible'];
  const colSalesEmail = header['sales manager email'] ?? header['sales email'] ?? header['responsible email'];
  // The assistant is the "Assist" column. (The older "Operation Manager" column
  // is only used if there is no such column.)
  const colAssist = header['assist'] ?? header['assistant'] ?? header['operation manager'];
  const colAssistEmail = header['assist email'] ?? header['assistant email'] ?? header['operation manager email'];
  const colContinent = header['continent'];
  if (!colCountry || (!colSales && !colAssist)) {
    throw new Error('Expected a header row with "Country", "Sales Manager" and "Assist" columns.');
  }

  const staff = userModel.listActive(); // staff + sales people without a login
  const assistants = userModel.listAssistants();
  const unmatched = new Set<string>();
  const newSales = new Map<string, string | null>(); // name -> email found in the file
  const newAssistants = new Map<string, string | null>();
  const emailIn = (email: string) => (EMAIL_RE.test(email) ? email : null);

  const resolveResponsible = (raw: string, email: string): string | null => {
    if (isNobody(raw)) return null;
    const found = matchPerson(raw, staff);
    if (found.name) return found.name;
    if (found.ambiguous.length > 1) {
      unmatched.add(`${raw} (could be ${found.ambiguous.join(' or ')})`);
      return raw;
    }
    newSales.set(raw, newSales.get(raw) ?? emailIn(email));
    return raw;
  };
  // An assistant may be an existing assistant or staff member; anyone new is
  // added as an email-only assistant after the file has been read.
  const resolveAssistant = (raw: string, email: string): string | null => {
    if (isNobody(raw)) return null;
    const found = matchPerson(raw, [...assistants, ...staff]);
    if (found.name) return found.name;
    if (found.ambiguous.length > 1) {
      unmatched.add(`${raw} (could be ${found.ambiguous.join(' or ')})`);
      return raw;
    }
    newAssistants.set(raw, newAssistants.get(raw) ?? emailIn(email));
    return raw;
  };

  const appKeys = new Set(COUNTRY_NAMES.map(countryKey));
  const notInApp: string[] = [];
  const rows: CountryRowInput[] = [];
  const seen = new Set<string>();

  ws.eachRow((row, i) => {
    if (i === 1) return;
    const country = cellText(row.getCell(colCountry).value);
    if (!country || seen.has(countryKey(country))) return;
    seen.add(countryKey(country));
    if (!appKeys.has(countryKey(country))) notInApp.push(country);
    rows.push({
      country,
      continent: colContinent ? cellText(row.getCell(colContinent).value) || null : null,
      responsible: colSales
        ? resolveResponsible(cellText(row.getCell(colSales).value), colSalesEmail ? cellText(row.getCell(colSalesEmail).value) : '')
        : null,
      assistant: colAssist
        ? resolveAssistant(cellText(row.getCell(colAssist).value), colAssistEmail ? cellText(row.getCell(colAssistEmail).value) : '')
        : null,
    });
  });
  if (!rows.length) throw new Error('No country rows found in the first sheet.');

  for (const [name, email] of newSales) createAssistant(name, email, 'sales');
  for (const [name, email] of newAssistants) {
    if (!newSales.has(name)) createAssistant(name, email, 'assistant');
  }
  const notInFile = countryModel.listAll().filter((r) => !seen.has(r.key) && (r.responsible || r.assistant)).map((r) => r.country);
  countryModel.upsertMany(rows);
  return {
    countries: rows.length,
    withResponsible: rows.filter((r) => r.responsible).length,
    withAssistant: rows.filter((r) => r.assistant).length,
    noNamedResponsible: rows.filter((r) => !r.responsible).length,
    unmatchedNames: [...unmatched],
    salesAdded: [...newSales.keys()],
    salesWithoutEmail: [...newSales].filter(([, email]) => !email).map(([name]) => name),
    assistantsAdded: [...newAssistants.keys()].filter((n) => !newSales.has(n)),
    assistantsWithoutEmail: [...newAssistants].filter(([n, email]) => !email && !newSales.has(n)).map(([name]) => name),
    notInAppList: notInApp,
    notInFile,
  };
}

// Today as YYYY-MM-DD, in the server's own time zone.
export function todayIso(): string {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

// After the AI has read a form:
//  - no date on the paper: today's date is filled in (staff can change it);
//  - nobody named as the person: the country's responsible person is filled in
//    (flagged "uncertain" so staff look at it). A person written on the form, or
//    chosen by hand, is never replaced - e.g. Insaf owns a country but Abdullah
//    handles one particular customer.
export function applyCountryDefaults(
  fields: ExtractedCardFields,
  status: FieldStatusMap
): { fields: ExtractedCardFields; status: FieldStatusMap } {
  let next = fields;
  let nextStatus = status;
  if (!next.date) {
    next = { ...next, date: todayIso() };
    nextStatus = { ...nextStatus, date: 'found' };
  }
  if (!next.person) {
    const owner = countryModel.findByCountry(next.country)?.responsible;
    if (owner) {
      next = { ...next, person: owner };
      nextStatus = { ...nextStatus, person: 'uncertain' };
    }
  }
  return { fields: next, status: nextStatus };
}
