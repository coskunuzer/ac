import PDFDocument from 'pdfkit';
import { drawLogo, registerDesignFonts } from './priceBook/designed';
import { COMPANY_ADDRESS_LINE } from './signature';

// A plain, printable report in the TECE look: a title, a few facts, then one or more tables. Used for the Buying rhythm and the Pricing analysis PDFs.
export interface PdfColumn { label: string; w: number; right?: boolean }
export interface PdfSection { heading?: string; note?: string; columns: PdfColumn[]; rows: (string | { text: string; tone?: 'bad' | 'good' | 'warn' })[][]; empty?: string }
export interface TablePdfInput { title: string; subtitle?: string; facts?: string[]; sections: PdfSection[]; landscape?: boolean }

const NAVY = '#17243E', RED = '#8B1931', STEEL = '#5E6676', SMOKE = '#E3E6EC';
const TONE: Record<string, string> = { bad: '#B3261E', good: '#2E7D32', warn: '#9A6700' };

export async function renderTablePdf(input: TablePdfInput): Promise<Buffer> {
  const land = input.landscape !== false;
  const PW = land ? 841.89 : 595.28, PH = land ? 595.28 : 841.89, L0 = 32, CW = PW - 2 * L0, BOTTOM = PH - 44;
  const doc = new PDFDocument({ size: 'A4', layout: land ? 'landscape' : 'portrait', margin: 0, autoFirstPage: false, info: { Title: input.title, Author: 'TECE' } });
  const chunks: Buffer[] = [];
  doc.on('data', (b: Buffer) => chunks.push(b));
  const done = new Promise<Buffer>((resolve, reject) => { doc.on('end', () => resolve(Buffer.concat(chunks))); doc.on('error', reject); });
  registerDesignFonts(doc);
  const F = { r: 'TD-400', m: 'TD-500', b: 'TD-600', h: 'TD-700' };
  let y = 0;
  let pageNo = 0;
  const page = () => {
    doc.addPage();
    pageNo += 1;
    doc.rect(0, 0, PW, 50).fill(NAVY);
    drawLogo(doc, 'TECE_SloganliLogo_Beyaz_RGB.svg', L0, (50 - 170 * (522 / 5990)) / 2, 170);
    doc.rect(0, 50, PW, 3).fill(RED);
    doc.font(F.h).fontSize(12).fillColor('#FFFFFF').text(input.title.toUpperCase(), L0, 19, { width: CW, align: 'right', lineBreak: false });
    doc.font(F.r).fontSize(7).fillColor(STEEL).text(`${COMPANY_ADDRESS_LINE}   ·   ${pageNo}`, L0, PH - 24, { width: CW, align: 'center', lineBreak: false });
    y = 68;
  };
  page();
  if (input.subtitle) { doc.font(F.m).fontSize(9.5).fillColor(NAVY).text(input.subtitle, L0, y, { width: CW }); y = doc.y + 4; }
  if (input.facts?.length) { doc.font(F.r).fontSize(8.5).fillColor(STEEL).text(input.facts.join('   ·   '), L0, y, { width: CW }); y = doc.y + 8; }

  for (const s of input.sections) {
    if (y > BOTTOM - 60) page();
    if (s.heading) { doc.font(F.h).fontSize(11).fillColor(NAVY).text(s.heading, L0, y, { width: CW }); y = doc.y + 3; }
    if (s.note) { doc.font(F.r).fontSize(8).fillColor(STEEL).text(s.note, L0, y, { width: CW }); y = doc.y + 5; }
    const total = s.columns.reduce((n, c) => n + c.w, 0) || 1;
    let x = L0;
    const cols = s.columns.map((c) => { const w = (c.w / total) * CW; const r = { ...c, x, w }; x += w; return r; });
    const head = () => {
      doc.font(F.b).fontSize(7).fillColor(STEEL);
      for (const c of cols) doc.text(c.label.toUpperCase(), c.x + 2, y, { width: c.w - 5, align: c.right ? 'right' : 'left', lineBreak: false, ellipsis: true });
      doc.rect(L0, y + 11, CW, 1).fill(NAVY);
      y += 15;
    };
    head();
    if (!s.rows.length) { doc.font(F.r).fontSize(9).fillColor(STEEL).text(s.empty ?? '—', L0 + 2, y, { width: CW }); y = doc.y + 10; continue; }
    const RH = 15;
    s.rows.forEach((row, i) => {
      if (y + RH > BOTTOM) { page(); head(); }
      if (i % 2 === 1) doc.rect(L0, y - 2, CW, RH).fill('#F4F6FA');
      row.forEach((cell, k) => {
        const c = cols[k]; if (!c) return;
        const text = typeof cell === 'string' ? cell : cell.text;
        const tone = typeof cell === 'string' ? undefined : cell.tone;
        doc.font(k === 0 ? F.b : F.r).fontSize(8).fillColor(tone ? TONE[tone] : '#222222').text(text, c.x + 2, y, { width: c.w - 5, align: c.right ? 'right' : 'left', lineBreak: false, ellipsis: true });
      });
      doc.rect(L0, y + RH - 3, CW, 0.4).fill(SMOKE);
      y += RH;
    });
    y += 12;
  }
  doc.end();
  return done;
}
