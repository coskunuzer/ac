-- What the AI found out about a company on the web (JSON: what they do, size, fit for TECE, why, when) and the daily lead-exploration task.
ALTER TABLE cards ADD COLUMN company_check TEXT;

-- The country each salesperson explores in the lead list on a day (30 minutes a day): one row per person and day.
CREATE TABLE IF NOT EXISTS daily_explore (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  day TEXT NOT NULL,
  country TEXT NOT NULL,
  market TEXT NOT NULL DEFAULT 'export',
  minutes INTEGER NOT NULL DEFAULT 0,
  done INTEGER NOT NULL DEFAULT 0,
  reviewed INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, day)
);
