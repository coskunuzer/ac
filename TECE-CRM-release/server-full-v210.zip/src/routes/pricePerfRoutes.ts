import { Router } from 'express';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { userModel } from '../models/userModel';
import { hasMenu, type Perms } from '../services/permissions';
import { viewMode } from '../services/viewMode';
import { LIMITS, periodInfo, pricePerfBase, summarise, type PeriodKey } from '../services/pricePerf';

// GET /api/price-perf?user=<id>|team&period=12m|ytd|ly — the "Price performance" tab of the Performance page, one call per view.
// Who sees whom (the same rules as the Performance page, services/perfAnalytics.scopeOf):
//   an admin: every sales person and the whole team;
//   a manager in Manager mode: themselves, everybody below them and their team total (in Salesperson mode: only themselves);
//   everybody else: only themselves (an assistant works as the person they assist, never in Manager mode);
//   a person with a permissions row needs the Performance menu AND the money switch "ledger" (sales figures), like /api/performance/sales-report;
//   an Operations login (shipping only, no permissions row) has no Performance page at all.

const router = Router();
router.use(requireAuth);

const PERIODS: PeriodKey[] = ['12m', 'ytd', 'ly'];

router.get('/', (req: AuthedRequest, res) => {
  try {
    const u = req.user!;
    const perms = (u as { perms?: Perms | null }).perms ?? null;
    if (!hasMenu(u as never, 'perf')) return res.status(403).json({ error: 'This page is not switched on for you.' });
    if (u.role !== 'admin' && perms && !perms.money.includes('ledger')) return res.status(403).json({ error: 'Sales figures are not switched on for you.' });
    if (u.role !== 'admin' && !perms && u.can_ship && !req.actor) return res.status(403).json({ error: 'This page is not switched on for you.' });

    const base = pricePerfBase();
    const period: PeriodKey = PERIODS.includes(req.query.period as PeriodKey) ? (req.query.period as PeriodKey) : '12m';
    const users = userModel.listAll().filter((x) => x.is_active && !x.is_assistant && !x.assists_id);
    const nameOf = (x: { display_name: string | null; username: string }) => x.display_name || x.username;
    const repCount = new Map<string, number>();
    for (const c of base.custs.values()) if (c.lifetime > 0) repCount.set(c.rep, (repCount.get(c.rep) ?? 0) + 1);

    // the people this viewer may look at
    let people: { id: number; name: string; self: boolean }[];
    if (u.role === 'admin') {
      people = users.filter((x) => repCount.has(nameOf(x)) || x.id === u.id).map((x) => ({ id: x.id, name: nameOf(x), self: x.id === u.id }));
      people = people.filter((p) => !p.self || repCount.has(p.name));
    } else {
      const below = new Set(viewMode.team(u.id).ids);
      people = [{ id: u.id, name: nameOf(u), self: true }, ...users.filter((x) => below.has(x.id)).map((x) => ({ id: x.id, name: nameOf(x), self: false }))];
    }
    people.sort((a, b) => Number(b.self) - Number(a.self) || (repCount.get(b.name) ?? 0) - (repCount.get(a.name) ?? 0) || a.name.localeCompare(b.name));
    const canTeam = people.length > 1;

    const raw = typeof req.query.user === 'string' ? req.query.user : '';
    let pick: 'team' | number;
    if (!raw) pick = canTeam ? 'team' : (people.find((p) => p.self)?.id ?? u.id);
    else if (raw === 'team') pick = 'team';
    else pick = Number(raw);
    if (pick === 'team' ? !canTeam : !people.some((p) => p.id === pick)) {
      return res.status(403).json({ error: 'You can see only your own customers and the people who report to you.' });
    }
    const reps = new Set(pick === 'team' ? people.map((p) => p.name) : [people.find((p) => p.id === pick)!.name]);
    const view = summarise(base, reps, period);
    const team = canTeam
      ? people.map((p) => { const s = summarise(base, new Set([p.name]), period).summary; return { id: p.id, name: p.name, self: p.self, customers: s.customers, buying: s.buying, rev: s.rev, growth: s.growth, rev12: s.rev12, ppk: s.ppk, ppm2: s.ppm2, index: s.index, indexPrev: s.indexPrev, change: s.change, realisation: s.realisation, leaks: s.leaks }; })
      : [];
    res.json({
      hasData: !!base.cut, asOf: base.cut, period, window: periodInfo(base, period), user: pick, canTeam, people: people.map((p) => ({ ...p, customers: repCount.get(p.name) ?? 0 })),
      list: { active: base.hasList, name: base.listName }, limits: LIMITS,
      summary: view.summary, groups: view.groups, team, customers: view.rows,
    });
  } catch (err) {
    console.error('Price performance failed:', err);
    res.status(500).json({ error: (err as Error).message || 'Something went wrong' });
  }
});

export default router;
