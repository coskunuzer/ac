-- Unverified customers (customers that are just a name): every download of the list is kept as a batch with the numbers it held.
-- Only a customer that was in THAT download can be deleted by uploading the file back, so an old or a partial file can never take away
-- customers that were added (or changed) after it was downloaded.
CREATE TABLE IF NOT EXISTS unverified_batches (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token TEXT NOT NULL UNIQUE,            -- written into the file (README and a hidden sheet): which download a file comes from
  created_by INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  criteria TEXT NOT NULL,                -- JSON: the rules and filters the list was made with
  row_count INTEGER NOT NULL DEFAULT 0,
  applied_at TEXT,                       -- when a file of this download was applied (a download is used once)
  applied_by INTEGER,
  result TEXT                            -- JSON: what was done (kept, enriched, moved to junk)
);
CREATE TABLE IF NOT EXISTS unverified_batch_cards (
  batch_id INTEGER NOT NULL REFERENCES unverified_batches(id) ON DELETE CASCADE,
  card_id INTEGER NOT NULL,
  company TEXT,                          -- the name at the time of the download (a row whose number was changed is recognised by it)
  updated_at TEXT,                       -- the customer's last change at the time of the download (changed since = never deleted)
  PRIMARY KEY (batch_id, card_id)
);
