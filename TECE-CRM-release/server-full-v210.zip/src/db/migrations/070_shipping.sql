-- Operations: the shipping (Nakliye) module. Freight requests are sent to forwarders, their replies are read, the prices are compared and one is accepted.
-- Plus the list of latest exports with the check that the documents were sent. Nothing here is ever deleted for good: requests are archived, firms made passive.

-- who may open the Shipping section (admins always; Operations through this flag)
ALTER TABLE users ADD COLUMN can_ship INTEGER NOT NULL DEFAULT 0;
UPDATE users SET can_ship = 1 WHERE lower(email) = 'operasyon@tece.com.tr';

-- regions and the countries in them (ISO codes; a region may hold other regions); editable
CREATE TABLE IF NOT EXISTS ship_regions (
  name TEXT PRIMARY KEY,
  countries TEXT NOT NULL DEFAULT '[]',
  parts TEXT NOT NULL DEFAULT '[]',
  aliases TEXT NOT NULL DEFAULT '[]'
);

-- one row per firm; the addresses and the coverage are lists, not one row for each
CREATE TABLE IF NOT EXISTS ship_forwarders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  name_key TEXT NOT NULL,
  contact TEXT,
  emails TEXT NOT NULL DEFAULT '[]',
  modes TEXT NOT NULL DEFAULT '[]',          -- Karayolu | Denizyolu (Konteyner) | Denizyolu (LCL) | Havayolu
  lang TEXT NOT NULL DEFAULT 'tr',
  active INTEGER NOT NULL DEFAULT 1,
  note TEXT,
  cov_all INTEGER NOT NULL DEFAULT 0,
  cov_regions TEXT NOT NULL DEFAULT '[]',
  cov_countries TEXT NOT NULL DEFAULT '[]',           -- ISO codes
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_ship_fw_key ON ship_forwarders (name_key);

CREATE TABLE IF NOT EXISTS ship_requests (
  id TEXT PRIMARY KEY,                       -- YYYYMMDD-NN
  original_text TEXT NOT NULL DEFAULT '',
  country TEXT,                              -- the name of the destination country
  country_iso TEXT,
  city TEXT,
  mode TEXT NOT NULL DEFAULT 'Karayolu',
  pallets INTEGER,
  weight_kg REAL,
  size TEXT,
  ready TEXT,
  pickup TEXT,
  status TEXT NOT NULL DEFAULT 'open',       -- open | closed
  owner_id INTEGER,
  card_id INTEGER,                           -- an optional customer
  export_key TEXT,                           -- an optional export (invoice) it is for
  archived INTEGER NOT NULL DEFAULT 0,
  imported INTEGER NOT NULL DEFAULT 0,       -- 1 = history from the old app
  accepted_quote INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  closed_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_ship_req_status ON ship_requests (status, archived);

-- who was asked in a request (the addresses are the ones used at the time: replies are checked against them)
CREATE TABLE IF NOT EXISTS ship_request_fw (
  request_id TEXT NOT NULL,
  forwarder_id INTEGER NOT NULL,
  forwarder_name TEXT NOT NULL,
  emails TEXT NOT NULL DEFAULT '[]',
  lang TEXT NOT NULL DEFAULT 'tr',
  sent_at TEXT,
  reminded_at TEXT,
  answered_at TEXT,
  cancelled_at TEXT,                         -- "request closed" was sent
  PRIMARY KEY (request_id, forwarder_id)
);

CREATE TABLE IF NOT EXISTS ship_quotes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  request_id TEXT NOT NULL,
  forwarder_id INTEGER,
  forwarder_name TEXT NOT NULL,
  sender_email TEXT,
  base REAL,
  extra REAL,
  total REAL,
  currency TEXT,
  out_items TEXT,                            -- costs left out of the price ("YDG, T1")
  status TEXT NOT NULL DEFAULT 'open',       -- open | accepted | rejected | countered | manual
  review_reason TEXT,                        -- why a person has to look at it
  counter REAL,
  imported INTEGER NOT NULL DEFAULT 0,
  received_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_ship_quotes_req ON ship_quotes (request_id);

-- every e-mail in or out: stored in full before anything else is done with it
CREATE TABLE IF NOT EXISTS ship_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  direction TEXT NOT NULL,                   -- in | out
  kind TEXT,                                 -- rfq | reminder | acceptance | rejection | counter | manual | cancel | summary | question | reply
  request_id TEXT,
  forwarder_id INTEGER,
  quote_id INTEGER,
  address TEXT,
  subject TEXT,
  body TEXT,
  attachments TEXT NOT NULL DEFAULT '[]',    -- [{name, file, size, text?}]
  msg_key TEXT UNIQUE,                       -- the Message-ID (in), or a key made when it was written (out)
  in_reply_to TEXT,
  status TEXT NOT NULL,                      -- in: stored | read | review | held | dismissed | late | failed ; out: pending | sent | failed | dismissed
  error TEXT,
  attempts INTEGER NOT NULL DEFAULT 0,
  user_id INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  sent_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_ship_msg_req ON ship_messages (request_id, direction);
CREATE INDEX IF NOT EXISTS idx_ship_msg_status ON ship_messages (direction, status);

-- the history of a request and its quotes: who did what, when
CREATE TABLE IF NOT EXISTS ship_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  request_id TEXT,
  quote_id INTEGER,
  kind TEXT NOT NULL,
  text TEXT,
  user_id INTEGER,
  imported INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_ship_events_req ON ship_events (request_id);

-- the documents of an export (an invoice line of the ledger): sent or not, how, and which
CREATE TABLE IF NOT EXISTS ship_export_docs (
  invoice_key TEXT PRIMARY KEY,              -- "sheet|date|description" of the ledger line
  status TEXT NOT NULL,                      -- sent | none | ignored
  how TEXT,                                  -- crm | manual
  at TEXT,
  user_id INTEGER,
  to_addr TEXT,
  files TEXT,
  note TEXT,
  mail_id INTEGER,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

INSERT OR IGNORE INTO ship_regions (name, countries, parts, aliases) VALUES
  ('Avrupa', '["PT","CH","LU","DK","SE","NO","FI","IS","LT","LV","EE","UA","BY","MD","MT","CY"]', '["Balkanlar","Orta Avrupa","Batı Avrupa","Birleşik Krallık ve İrlanda"]', '["europe","avrupa geneli"]'),
  ('Balkanlar', '["GR","BG","RS","HR","BA","ME","MK","AL","XK","SI","RO"]', '[]', '["balkan","balkans"]'),
  ('Orta Avrupa', '["PL","HU","CZ","SK","AT"]', '[]', '["central europe"]'),
  ('Batı Avrupa', '["DE","FR","IT","ES","NL","BE"]', '[]', '["western europe"]'),
  ('Birleşik Krallık ve İrlanda', '["GB","IE"]', '[]', '["uk / ireland","uk/ireland","uk ireland"]'),
  ('Orta Doğu', '["IL","AE","SA","EG","LB","JO","IQ","KW","QA","BH","OM"]', '[]', '["middle east"]'),
  ('Kuzey Amerika', '["US","CA"]', '[]', '["north america"]');

-- VF04 (ready to dispatch): back orders the customer does not want for a while can be silenced for a time (one SD document, or everything of a customer).
-- Silenced rows disappear from the dispatch lists and the "ready" figures until the date, and come back by themselves. Nothing is deleted.
CREATE TABLE IF NOT EXISTS ship_snooze (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  scope TEXT NOT NULL,                        -- sd | customer
  sd_no TEXT,
  sap_no TEXT NOT NULL,
  customer TEXT,
  until TEXT,                                 -- a date; NULL = until a person brings it back
  reason TEXT,
  user_id INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  cleared_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_ship_snooze_active ON ship_snooze (cleared_at, sap_no, sd_no);

-- Sales asks Operations to organise the transport of what is ready (also made when the dispatch request e-mail is sent)
CREATE TABLE IF NOT EXISTS ship_asks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sap_no TEXT NOT NULL,
  customer TEXT,
  card_id INTEGER,
  sd_nos TEXT NOT NULL DEFAULT '[]',
  note TEXT,
  from_user INTEGER,
  status TEXT NOT NULL DEFAULT 'open',        -- open | done | dismissed
  request_id TEXT,                            -- the freight request made for it
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  handled_at TEXT,
  handled_by INTEGER
);
CREATE INDEX IF NOT EXISTS idx_ship_asks_status ON ship_asks (status);
