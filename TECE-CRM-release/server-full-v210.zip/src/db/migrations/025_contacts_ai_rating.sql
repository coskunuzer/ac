-- Several people at one company, the AI's rating of each customer, and the key that finds the same company twice.

-- The AI's rating of the customer, 0 (not worth the time) to 10 (call them today), and why. The person's own rating stays in "rate".
ALTER TABLE cards ADD COLUMN ai_rate INTEGER;
ALTER TABLE cards ADD COLUMN ai_rate_reason TEXT;
-- 'ai' = rated by Gemini, 'rules' = a quick estimate from what the database knows (replaced when the AI rates it)
ALTER TABLE cards ADD COLUMN ai_rate_source TEXT;
ALTER TABLE cards ADD COLUMN ai_rated_at TEXT;
CREATE INDEX IF NOT EXISTS idx_cards_ai_rate ON cards(ai_rate);

-- The company name without punctuation, legal endings (Ltd, GmbH, A.S. ...) and spaces: two records with the same key are the same company.
ALTER TABLE cards ADD COLUMN company_key TEXT;
CREATE INDEX IF NOT EXISTS idx_cards_company_key ON cards(company_key);

-- More people (and positions, e-mails) under one company. The first person stays on the customer itself.
CREATE TABLE IF NOT EXISTS card_contacts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  card_id INTEGER NOT NULL REFERENCES cards(id) ON DELETE CASCADE,
  name TEXT,
  position TEXT,
  email TEXT,
  tel TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_card_contacts_card ON card_contacts(card_id);
