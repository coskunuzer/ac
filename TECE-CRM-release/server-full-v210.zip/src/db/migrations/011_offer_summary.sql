-- Every email sent to a customer is logged: a price offer, documents only, or a
-- plain thank-you note. "summary" is a readable snapshot (percentage, pages,
-- attachments, subject...) written at send time.
ALTER TABLE offers_sent ADD COLUMN summary TEXT;
ALTER TABLE offers_sent ADD COLUMN kind TEXT NOT NULL DEFAULT 'offer';
UPDATE offers_sent SET kind = CASE WHEN params = 'null' THEN 'documents' ELSE 'offer' END;
