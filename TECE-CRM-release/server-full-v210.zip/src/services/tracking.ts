import { db } from '../db/connection';
import { activityModel } from '../models/activityModel';
import { settingsModel } from '../models/settingsModel';
import { addBusinessDays, todayIstanbul, todoModel } from './todos';

// Following a sample after it has left: the status of the courier shipment is read from the 17TRACK service (one key typed by an admin; the carrier is
// recognised from the number) and kept with the sample. When it is delivered the customer page gets a note and the salesperson a to-do to ask the customer
// what they think. Without a key nothing is looked up: the sample keeps its link to the courier's page and a person can mark it delivered by hand.
const API = process.env.TRACK17_API || 'https://api.17track.net/track/v2.2';
const keyOf = (): string => settingsModel.get('tracking_17track_key') || process.env.TRACK17_KEY || '';
export const trackingConfigured = (): boolean => !!keyOf();
export const setTrackingKey = (k: string): void => settingsModel.set('tracking_17track_key', k.trim());

export type Delivery = 'in_transit' | 'out_for_delivery' | 'delivered' | 'problem' | 'unknown';
const STATUS: Record<string, Delivery> = {
  Delivered: 'delivered', OutForDelivery: 'out_for_delivery', AvailableForPickup: 'out_for_delivery', InTransit: 'in_transit', InfoReceived: 'in_transit',
  DeliveryFailure: 'problem', Exception: 'problem', Expired: 'problem', NotFound: 'unknown',
};

async function call(path: string, body: unknown): Promise<Record<string, any> | null> {
  try {
    const res = await fetch(`${API}${path}`, { method: 'POST', headers: { '17token': keyOf(), 'content-type': 'application/json' }, body: JSON.stringify(body), signal: AbortSignal.timeout(20000) });
    return res.ok ? ((await res.json()) as Record<string, any>) : null;
  } catch {
    return null;
  }
}

// the status of one shipment: null when the service did not answer (nothing is changed then)
export async function lookup(trackingNo: string): Promise<{ status: Delivery; detail: string; deliveredAt: string | null } | null> {
  if (!keyOf()) return null;
  await call('/register', [{ number: trackingNo }]); // already registered is fine
  const r = await call('/gettrackinfo', [{ number: trackingNo }]);
  const item = r?.data?.accepted?.[0];
  if (!item) return null;
  const info = item.track_info ?? {};
  const status = STATUS[String(info.latest_status?.status ?? 'NotFound')] ?? 'unknown';
  const ev = info.latest_event ?? {};
  const detail = [ev.description, ev.location, String(ev.time_iso ?? '').slice(0, 10)].filter(Boolean).join(' · ').slice(0, 300);
  return { status, detail, deliveredAt: status === 'delivered' ? String(ev.time_iso ?? new Date().toISOString()).slice(0, 19).replace('T', ' ') : null };
}

interface SampleRow { id: number; card_id: number; user_id: number | null; items: string; carrier: string | null; tracking_no: string | null; delivery_status: string | null }

function onDelivered(s: SampleRow, detail: string): void {
  activityModel.add({ userId: s.user_id ?? 0, cardId: s.card_id, type: 'sample', text: `Sample delivered (${[s.carrier, s.tracking_no].filter(Boolean).join(' ')})${detail ? ` - ${detail}` : ''}`, imported: true });
  if (s.user_id) todoModel.add({ userId: s.user_id, cardId: s.card_id, text: 'The samples arrived: ask the customer what they think', dueDate: addBusinessDays(todayIstanbul(), 2) });
}

// look the sample up again and keep what the courier says
export async function refreshSample(id: number): Promise<{ status: Delivery | null; detail: string | null }> {
  const s = db.prepare('SELECT * FROM card_samples WHERE id = ?').get(id) as SampleRow | undefined;
  if (!s || !s.tracking_no) return { status: null, detail: null };
  const r = await lookup(s.tracking_no);
  db.prepare("UPDATE card_samples SET checked_at = datetime('now') WHERE id = ?").run(id);
  if (!r) return { status: (s.delivery_status as Delivery | null) ?? null, detail: null };
  const wasDelivered = s.delivery_status === 'delivered';
  db.prepare('UPDATE card_samples SET delivery_status = ?, delivery_detail = ?, delivered_at = COALESCE(?, delivered_at) WHERE id = ?').run(r.status, r.detail || null, r.deliveredAt, id);
  if (r.status === 'delivered' && !wasDelivered) onDelivered(s, r.detail);
  return { status: r.status, detail: r.detail };
}

// a person says "it arrived" (no key, or the courier page said so)
export function markDelivered(id: number): void {
  const s = db.prepare('SELECT * FROM card_samples WHERE id = ?').get(id) as SampleRow | undefined;
  if (!s || s.delivery_status === 'delivered') return;
  db.prepare("UPDATE card_samples SET delivery_status = 'delivered', delivered_at = datetime('now'), delivery_detail = COALESCE(delivery_detail, 'Marked as delivered by hand') WHERE id = ?").run(id);
  onDelivered(s, '');
}

// every few hours: the samples that left in the last 45 days and have not arrived yet
export function startTrackingScheduler(): void {
  const run = async () => {
    if (!trackingConfigured()) return;
    const rows = db.prepare("SELECT id FROM card_samples WHERE tracking_no IS NOT NULL AND tracking_no != '' AND COALESCE(delivery_status, '') != 'delivered' AND shipped_at >= datetime('now', '-45 days') ORDER BY COALESCE(checked_at, '') LIMIT 60").all() as { id: number }[];
    for (const r of rows) { try { await refreshSample(r.id); } catch (e) { console.error('Tracking refresh failed:', e); } await new Promise((x) => setTimeout(x, 1500)); }
  };
  setTimeout(() => void run(), 60_000);
  setInterval(() => void run(), 3 * 3600_000).unref();
}

// ---- every sample note is a sample record, so a tracking number can be added to it later --------------------------------------------------
export function createSampleFromNote(cardId: number, userId: number, text: string, activityId: number): void {
  db.prepare('INSERT INTO card_samples (card_id, user_id, items, activity_id) VALUES (?, ?, ?, ?)').run(cardId, userId, text.trim() || 'Sample', activityId);
}
// once and again at every start (cheap): the sample notes that are not a sample record yet
export function backfillSampleNotes(): number {
  const r = db.prepare(
    `INSERT INTO card_samples (card_id, user_id, items, activity_id, requested_at)
       SELECT a.card_id, a.user_id, COALESCE(NULLIF(TRIM(a.text), ''), 'Sample'), a.id, a.created_at FROM activities a
        WHERE a.type = 'sample' AND a.card_id IS NOT NULL AND COALESCE(a.imported, 0) = 0 AND COALESCE(a.text, '') NOT LIKE 'Sample request:%' AND COALESCE(a.text, '') NOT LIKE 'Sample delivered%'
          AND NOT EXISTS (SELECT 1 FROM card_samples s WHERE s.activity_id = a.id)`
  ).run();
  return Number(r.changes);
}
