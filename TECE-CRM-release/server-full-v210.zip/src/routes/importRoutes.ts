import { Router } from 'express';
import multer from 'multer';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { hasAction } from '../services/permissions';
import { exhibitionModel } from '../models/exhibitionModel';
import { importBadgeVisitors, resolveCountry } from '../services/badgeImport';
import { enrichCompanies } from '../services/companyEnrich';
import { importLeads } from '../services/leadImport';
import { updateDomesticList } from '../services/domesticListUpdate';
import { importDomestic } from '../services/domesticImport';
import { importDatabase } from '../services/databaseImport';
import { db } from '../db/connection';
import { removeCustomerFolder } from '../services/customerFiles';
import type { CardRow } from '../models/cardModel';
import { rateMissingWithRules } from '../services/aiRating';

const router = Router();
// admin only, except the uploads an admin switched on for a person on the Permissions page (leads / customer lists)
router.use(requireAuth, (req: AuthedRequest, res, next) => {
  const act = req.path === '/leads' || req.path === '/my-leads' ? 'upLeads' : /^\/(database|domestic|domestic-update|badges)$/.test(req.path) ? 'upCust' : 'admin';
  if (act === 'admin' ? req.user?.role === 'admin' : hasAction(req.user as never, act)) return next();
  // the Leads page asks every person for "the leads I uploaded": somebody who may not upload has none - that is an empty list, not an error
  if (req.method === 'GET' && req.path === '/my-leads') return res.json({ total: 0, rows: [] });
  res.status(403).json({ error: 'Admin only' });
});

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });

// The country that was chosen on the page for a file that has none (the name of the app's list, or nothing).
const chosenCountry = (v: unknown): string | null => {
  const c = typeof v === 'string' ? v.trim() : '';
  return c ? resolveCountry(c) ?? c : null;
};

// POST /api/import/badges  (multipart: file, exhibitionId, dryRun=1)
// Reads a badge-scanner CSV into one exhibition. dryRun=1 only reports what would happen.
router.post('/badges', upload.single('file'), async (req: AuthedRequest, res) => {
  if (!req.file) return res.status(400).json({ error: 'Choose the CSV file first.' });
  const exhibition = exhibitionModel.findById(Number(req.body.exhibitionId));
  if (!exhibition) return res.status(400).json({ error: 'Choose the exhibition these visitors belong to.' });
  try {
    const report = await importBadgeVisitors({
      buffer: req.file.buffer,
      exhibitionId: exhibition.id,
      userId: req.user!.id,
      dryRun: req.body.dryRun === '1' || req.body.dryRun === 'true',
      useAi: req.body.useAi === '1',
    });
    res.json({ exhibition: exhibition.name, ...report });
    // only when the admin asked for the AI: the company web sites are read afterwards, a few at a time
    if (req.body.useAi === '1' && report.cardIds.length) void enrichCompanies(report.cardIds);
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

// The list a customer file goes into: a name typed on the page (for example "Ivan Research"; an existing list of that name is used, a new one is made), or the default "Customer database".
function listFor(req: AuthedRequest, dryRun: boolean) {
  const typed = String(req.body?.listName ?? '').trim().slice(0, 80);
  const name = typed || 'Customer database';
  let exhibition = exhibitionModel.listAll().find((e) => e.name.trim().toLowerCase() === name.toLowerCase());
  if (!exhibition && !dryRun) exhibition = exhibitionModel.create({ name, location: typed ? 'Customer list' : 'All customers and leads', createdBy: req.user!.id });
  return { exhibition, name };
}

// "Only an admin may delete these": every customer this upload just added is locked against deletion by sales staff
const nowUtc = () => new Date().toISOString().slice(0, 19).replace('T', ' ');
function lockNew(req: AuthedRequest, since: string) {
  if (req.body?.lockDelete === '1' || req.body?.lockDelete === 'true') db.prepare('UPDATE cards SET delete_locked = 1 WHERE created_at >= ?').run(since);
}

// POST /api/import/leads  (multipart: file = the customer database as Excel, exhibitionId or none, dryRun)
// The companies come in as leads (not as visitors: no thank-you is waiting for them), in one list.
const bigUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 60 * 1024 * 1024 } });
router.post('/leads', bigUpload.single('file'), async (req: AuthedRequest, res) => {
  if (!req.file) return res.status(400).json({ error: 'Choose the Excel file first.' });
  const dryRun = req.body.dryRun === '1' || req.body.dryRun === 'true';
  let exhibition = req.body.exhibitionId ? exhibitionModel.findById(Number(req.body.exhibitionId)) : undefined;
  let listName = exhibition?.name;
  if (!exhibition) {
    const l = listFor(req, dryRun);
    exhibition = l.exhibition; listName = l.name;
  }
  try {
    const startedAt = nowUtc();
    const report = await importLeads({ buffer: req.file.buffer, exhibitionId: exhibition?.id ?? 0, userId: req.user!.id, dryRun, defaultCountry: chosenCountry(req.body.defaultCountry) });
    if (!dryRun) { lockNew(req, startedAt); rateMissingWithRules(); }
    res.json({ list: exhibition?.name ?? listName ?? 'Customer database', dryRun, ...report });
  } catch (err) {
    console.error('Lead import failed:', err);
    res.status(400).json({ error: (err as Error).message });
  }
});

// POST /api/import/database  (multipart: file = the customer database in three tabs, dryRun)
// Existing customers / potential with e-mail or web / potential with no contact: each company lands in its group.
router.post('/database', bigUpload.single('file'), async (req: AuthedRequest, res) => {
  if (!req.file) return res.status(400).json({ error: 'Choose the Excel file first.' });
  const dryRun = req.body.dryRun === '1' || req.body.dryRun === 'true';
  const { exhibition } = listFor(req, dryRun);
  try {
    const startedAt = nowUtc();
    const report = await importDatabase({ buffer: req.file.buffer, exhibitionId: exhibition?.id ?? 0, userId: req.user!.id, dryRun, defaultCountry: chosenCountry(req.body.defaultCountry) });
    if (!dryRun) { lockNew(req, startedAt); rateMissingWithRules(); }
    res.json(report);
  } catch (err) {
    console.error('Database import failed:', err);
    res.status(400).json({ error: (err as Error).message });
  }
});

// What came from the uploaded customer databases (not the fairs): how many, and how many of them somebody has already worked on.
const UPLOADED = "extraction_model IN ('lead-database', 'domestic-list', 'customer-database')";
const WORKED = "(EXISTS (SELECT 1 FROM activities a WHERE a.card_id = cards.id AND a.type IN ('note', 'call', 'visit', 'meeting', 'sample', 'thank_you', 'offer', 'documents', 'email', 'bulgaria', 'file')) OR EXISTS (SELECT 1 FROM offers_sent o WHERE o.card_id = cards.id))";
router.get('/uploaded-summary', (_req, res) => {
  const total = (db.prepare(`SELECT COUNT(*) AS n FROM cards WHERE ${UPLOADED}`).get() as { n: number }).n;
  const worked = (db.prepare(`SELECT COUNT(*) AS n FROM cards WHERE ${UPLOADED} AND ${WORKED}`).get() as { n: number }).n;
  const fairs = (db.prepare("SELECT COUNT(*) AS n FROM cards WHERE extraction_model NOT IN ('lead-database', 'domestic-list', 'customer-database')").get() as { n: number }).n;
  res.json({ total, worked, untouched: total - worked, keptAnyway: fairs });
});

// Delete everything that was uploaded as a customer database (the fairs and the customers added by hand stay).
router.post('/delete-uploaded', (req: AuthedRequest, res) => {
  if (req.body?.confirm !== 'DELETE') return res.status(400).json({ error: 'Type DELETE to confirm.' });
  const keepWorked = req.body?.keepWorked !== false;
  const where = `${UPLOADED}${keepWorked ? ` AND NOT ${WORKED}` : ''}`;
  const ids = (db.prepare(`SELECT id FROM cards WHERE ${where}`).all() as { id: number }[]).map((r) => r.id);
  const withFolder = db.prepare(`SELECT * FROM cards WHERE ${where} AND archive_dir IS NOT NULL`).all() as unknown as CardRow[];
  db.exec('BEGIN');
  try {
    for (let i = 0; i < ids.length; i += 800) {
      const list = ids.slice(i, i + 800).join(',');
      db.exec(`DELETE FROM activities WHERE card_id IN (${list}); DELETE FROM price_changes WHERE card_id IN (${list}); DELETE FROM offers_sent WHERE card_id IN (${list}); DELETE FROM card_contacts WHERE card_id IN (${list}); DELETE FROM cards WHERE id IN (${list});`);
    }
    db.exec('COMMIT');
  } catch (err) {
    db.exec('ROLLBACK');
    console.error('Deleting the uploaded database failed:', err);
    return res.status(500).json({ error: 'Could not delete. Nothing was removed.' });
  }
  for (const c of withFolder) removeCustomerFolder(c);
  res.json({ deleted: ids.length });
});

// POST /api/import/domestic-update  (multipart: file = the updated domestic list with the sheets Existing, Potential, Removed - No Sales, Field Visits, dryRun)
router.post('/domestic-update', bigUpload.single('file'), async (req: AuthedRequest, res) => {
  if (!req.file) return res.status(400).json({ error: 'Choose the Excel file first.' });
  const dryRun = req.body.dryRun === '1' || req.body.dryRun === 'true';
  let exhibition = exhibitionModel.listAll().find((e) => e.name === 'Domestic customers');
  if (!exhibition && !dryRun) exhibition = exhibitionModel.create({ name: 'Domestic customers', location: 'Customers in Turkey', createdBy: req.user!.id });
  try {
    const report = updateDomesticList({ buffer: req.file.buffer, exhibitionId: exhibition?.id ?? 0, userId: req.user!.id, dryRun });
    if (!dryRun) rateMissingWithRules();
    res.json(report);
  } catch (err) {
    console.error('Domestic list update failed:', err);
    res.status(400).json({ error: (err as Error).message });
  }
});

// POST /api/import/domestic  (multipart: file = the domestic customer list as Excel, dryRun)
// Customers in Turkey: filed under their city and given to the person who looks after that city.
router.post('/domestic', bigUpload.single('file'), async (req: AuthedRequest, res) => {
  if (!req.file) return res.status(400).json({ error: 'Choose the Excel file first.' });
  const dryRun = req.body.dryRun === '1' || req.body.dryRun === 'true';
  let exhibition = exhibitionModel.listAll().find((e) => e.name === 'Domestic customers');
  if (!exhibition && !dryRun) exhibition = exhibitionModel.create({ name: 'Domestic customers', location: 'Customers in Turkey', createdBy: req.user!.id });
  try {
    const report = await importDomestic({ buffer: req.file.buffer, exhibitionId: exhibition?.id ?? 0, userId: req.user!.id, dryRun });
    if (!dryRun) rateMissingWithRules();
    res.json({ list: exhibition?.name ?? 'Domestic customers', dryRun, ...report });
  } catch (err) {
    console.error('Domestic import failed:', err);
    res.status(400).json({ error: (err as Error).message });
  }
});

// the leads this person uploaded (an admin sees everybody's): what the Leads page lists
router.get('/my-leads', (req: AuthedRequest, res) => {
  const admin = req.user!.role === 'admin';
  const rows = db.prepare(`SELECT c.id, c.company, c.name, c.country, c.email, c.tel, c.website, c.created_at, e.name AS list, u.display_name AS by
    FROM cards c JOIN exhibitions e ON e.id = c.exhibition_id LEFT JOIN users u ON u.id = c.uploaded_by
    WHERE c.extraction_model = 'lead-database' ${admin ? '' : 'AND c.uploaded_by = ?'} ORDER BY c.id DESC LIMIT 1000`).all(...(admin ? [] : [req.user!.id]));
  const total = db.prepare(`SELECT COUNT(*) AS n FROM cards WHERE extraction_model = 'lead-database' ${admin ? '' : 'AND uploaded_by = ?'}`).get(...(admin ? [] : [req.user!.id])) as { n: number };
  res.json({ total: total.n, rows });
});

export default router;
