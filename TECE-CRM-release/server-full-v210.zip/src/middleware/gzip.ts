import zlib from 'zlib';
import type { NextFunction, Request, Response } from 'express';

// Compresses text answers (JSON, HTML, JS, CSS) for browsers that accept it: the same page loads in a fraction of the bytes. Files, PDFs, images and event streams pass untouched.
export function gzip(req: Request, res: Response, next: NextFunction) {
  if (req.method === 'HEAD' || !/\bgzip\b/.test(String(req.headers['accept-encoding'] ?? ''))) return next();
  /* eslint-disable @typescript-eslint/no-explicit-any */
  const origWrite = res.write.bind(res) as any;
  const origEnd = res.end.bind(res) as any;
  let gz: zlib.Gzip | null = null;
  let decided = false;
  const decide = () => {
    if (decided) return;
    decided = true;
    const type = String(res.getHeader('Content-Type') ?? '');
    const len = Number(res.getHeader('Content-Length') ?? 0);
    if (res.getHeader('Content-Encoding') || res.getHeader('Content-Range') || !/json|javascript|css|html|svg|xml|text\/plain|text\/csv/.test(type) || /event-stream/.test(type) || (len > 0 && len < 1024) || res.statusCode === 204 || res.statusCode === 304) return;
    gz = zlib.createGzip({ level: 5 });
    res.setHeader('Content-Encoding', 'gzip');
    res.setHeader('Vary', 'Accept-Encoding');
    res.removeHeader('Content-Length');
    gz.on('data', (c: Buffer) => origWrite(c));
    gz.on('end', () => origEnd());
  };
  (res as any).write = (chunk: any, ...a: any[]) => { decide(); return gz ? gz.write(chunk, ...a) : origWrite(chunk, ...a); };
  (res as any).end = (chunk?: any, ...a: any[]) => {
    decide();
    if (!gz) return origEnd(chunk, ...a);
    if (chunk && typeof chunk !== 'function') gz.write(chunk);
    gz.end();
    return res;
  };
  next();
}
