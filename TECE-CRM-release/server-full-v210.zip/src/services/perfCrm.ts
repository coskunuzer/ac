import { db } from '../db/connection';
import { cardModel, type CardRow } from '../models/cardModel';
import { exhibitionModel } from '../models/exhibitionModel';
import { companyKey } from './companyKey';
import { setLanguageByRule } from './offerLanguage';
import { moveToJunk } from './junk';
import type { ExtractedCardFields, FieldStatusMap } from '../schema/cardSchema';
import { allAccountSets, type Account } from './perfAnalytics';

// SAP customers that have no record in the CRM yet: find them, and create them (one by one, or all at once). A record that already exists
// under the same company name only gets the SAP number.

const FIELD_KEYS: (keyof ExtractedCardFields)[] = ['name', 'company', 'address', 'country', 'tel', 'email', 'position', 'interestedIn', 'workArea', 'date', 'person', 'rate', 'notes'];

export interface MissingRow { sap: string; name: string; country: string; rep: string; status: string; match: { id: number; company: string | null } | null }

export function missingInCrm(viewerId: number): MissingRow[] {
  const has = new Set((db.prepare("SELECT TRIM(sap) AS s FROM cards WHERE sap IS NOT NULL AND TRIM(sap) != ''").all() as { s: string }[]).map((r) => r.s));
  const byKey = new Map<string, { id: number; company: string | null }>();
  for (const c of db.prepare("SELECT id, company, company_key FROM cards WHERE company_key IS NOT NULL AND (sap IS NULL OR TRIM(sap) = '') ORDER BY id").all() as { id: number; company: string | null; company_key: string }[]) {
    if (!byKey.has(c.company_key)) byKey.set(c.company_key, { id: c.id, company: c.company });
  }
  return allAccountSets(viewerId).live
    .filter((a) => !has.has(a.sap))
    .map((a) => ({ sap: a.sap, name: a.name, country: a.country, rep: a.rep, status: a.status, match: byKey.get(companyKey(a.name) ?? '\u0000') ?? null }))
    .sort((a, b) => a.name.localeCompare(b.name));
}

function directList(userId: number) {
  const found = exhibitionModel.listAll().find((e) => e.name === 'Direct contacts');
  return found ?? exhibitionModel.create({ name: 'Direct contacts', location: 'Visits, e-mails, calls and recommendations', createdBy: userId });
}

export interface CreateResult { created: number; linked: number; skipped: number }

export function createInCrm(saps: string[] | 'all', userId: number): CreateResult {
  const list = missingInCrm(userId).filter((m) => saps === 'all' || saps.includes(m.sap));
  const sapRows = new Map((db.prepare('SELECT sap_no, contact, email, phone, website FROM sap_customers').all() as { sap_no: string; contact: string; email: string; phone: string; website: string }[]).map((r) => [r.sap_no, r]));
  const out: CreateResult = { created: 0, linked: 0, skipped: 0 };
  const found = Object.fromEntries(FIELD_KEYS.map((k) => [k, 'found'])) as FieldStatusMap;
  db.exec('BEGIN');
  try {
    for (const m of list) {
      if (m.match) {
        db.prepare("UPDATE cards SET sap = ?, stage = COALESCE(NULLIF(stage, ''), 'customer'), updated_at = datetime('now') WHERE id = ?").run(m.sap, m.match.id);
        out.linked += 1;
        continue;
      }
      const s = sapRows.get(m.sap);
      const email = (s?.email ?? '').split(/[;,\s]+/)[0] || null;
      const fields: ExtractedCardFields = {
        name: s?.contact || null, company: m.name, address: null, country: m.country || null, tel: s?.phone || null, email,
        position: null, interestedIn: null, workArea: null, date: null, person: m.rep || null, rate: null, notes: null,
      };
      try {
        const card: CardRow = cardModel.createFromExtraction({
          exhibitionId: directList(userId).id, uploadedBy: userId, imagePath: '', fields, fieldStatus: found, extractionModel: 'sap-list', status: 'confirmed',
          stage: 'customer', website: s?.website || null, market: 'export', sap: m.sap,
        });
        setLanguageByRule(card.id);
        out.created += 1;
      } catch (err) {
        console.error('Create CRM customer failed:', m.sap, err);
        out.skipped += 1;
      }
    }
    db.exec('COMMIT');
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
  return out;
}

// An admin removes a customer: it leaves the Performance page for good (a new SAP upload does not bring it back), and its CRM record goes
// to the Junk folder, where it can be restored.
export function removeCustomer(sap: string, userId: number): { junked: number } {
  db.prepare('INSERT OR IGNORE INTO perf_excluded (sap_no, by_user) VALUES (?, ?)').run(sap, userId);
  let junked = 0;
  for (const c of db.prepare("SELECT id FROM cards WHERE TRIM(sap) = ?").all(sap) as { id: number }[]) {
    const card = cardModel.findById(c.id);
    if (card) { moveToJunk(card, 'Removed from Performance by an admin', userId); junked += 1; }
  }
  return { junked };
}

export function restoreExcluded(sap: string): void {
  db.prepare('DELETE FROM perf_excluded WHERE sap_no = ?').run(sap);
}

export type { Account };
