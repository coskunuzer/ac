-- Complaints, round 2: the workflow of "TECE CRM Müşteri Şikayeti Paneli.xlsx" (entry by sales -> quality review and routing -> departments -> quality closing),
-- the 67 standard reasons, the 27 departments, the 13 statuses (with what sales may see), and a quality / department login.

-- who a login is: NULL = sales (or admin), 'quality' = the quality (KYS) person, 'dept' = the head of a department
ALTER TABLE users ADD COLUMN area TEXT;

ALTER TABLE complaints ADD COLUMN reported_date TEXT;       -- the day the customer reported it
ALTER TABLE complaints ADD COLUMN product_code TEXT;
ALTER TABLE complaints ADD COLUMN order_qty TEXT;           -- quantity and unit of the order, as written
ALTER TABLE complaints ADD COLUMN complained_qty TEXT;      -- the quantity the customer says is affected
ALTER TABLE complaints ADD COLUMN reason_code TEXT;         -- S001 .. S067
ALTER TABLE complaints ADD COLUMN channel TEXT;             -- email | phone | visit
ALTER TABLE complaints ADD COLUMN customer_request TEXT;    -- what the customer asks for
ALTER TABLE complaints ADD COLUMN complaint_no TEXT;        -- MHBK281-07-031126, given by quality
ALTER TABLE complaints ADD COLUMN internal_status TEXT;     -- NULL while sales is still writing; then one of the 13 statuses
ALTER TABLE complaints ADD COLUMN priority TEXT;            -- low | normal | high | urgent
ALTER TABLE complaints ADD COLUMN op_occurred TEXT;         -- Hatanın Oluştuğu Operasyon
ALTER TABLE complaints ADD COLUMN op_detected TEXT;         -- Hatanın Belirlendiği Operasyon
ALTER TABLE complaints ADD COLUMN eval_team TEXT;           -- Değerlendirmeyi Yapan Ekip
ALTER TABLE complaints ADD COLUMN root_cause TEXT;          -- internal until quality approves
ALTER TABLE complaints ADD COLUMN result_action TEXT;       -- Sonuç / Aksiyon
ALTER TABLE complaints ADD COLUMN capa_required INTEGER;    -- Düzeltici faaliyet gerekli mi
ALTER TABLE complaints ADD COLUMN capa_date TEXT;
ALTER TABLE complaints ADD COLUMN customer_replied INTEGER; -- Satış temsilcisine / müşteriye dönüş yapıldı mı
ALTER TABLE complaints ADD COLUMN customer_reply_date TEXT;
ALTER TABLE complaints ADD COLUMN approved_reply TEXT;      -- the explanation quality has approved for sales to give the customer
ALTER TABLE complaints ADD COLUMN info_request TEXT;        -- what quality asks sales for
ALTER TABLE complaints ADD COLUMN info_due TEXT;
ALTER TABLE complaints ADD COLUMN submitted_at TEXT;
ALTER TABLE complaints ADD COLUMN closed_at TEXT;
ALTER TABLE complaints ADD COLUMN reopen_count INTEGER NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS complaint_reasons (
  code TEXT PRIMARY KEY,
  name TEXT NOT NULL
);

-- the departments that can be blamed or asked; a department head is a login of the area "dept" (or only an e-mail address)
CREATE TABLE IF NOT EXISTS complaint_departments (
  name TEXT PRIMARY KEY,
  head_user_id INTEGER,
  head_email TEXT
);

-- one task for each department quality asks (K01): who, until when, and the answer
CREATE TABLE IF NOT EXISTS complaint_tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  complaint_id INTEGER NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
  department TEXT NOT NULL,
  owner_user_id INTEGER,
  due_date TEXT,
  instruction TEXT,
  state TEXT NOT NULL DEFAULT 'open',     -- open | sent | accepted | more_info
  root_cause TEXT,
  correction TEXT,
  corrective TEXT,
  preventive TEXT,
  effectiveness TEXT,
  review_note TEXT,
  created_by INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  submitted_at TEXT,
  reviewed_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_ctask_complaint ON complaint_tasks (complaint_id);
CREATE INDEX IF NOT EXISTS idx_ctask_owner ON complaint_tasks (owner_user_id, state);

-- every status change and every internal note (K02): who, when, from, to, why. Internal ones never reach the sales screen (K04).
CREATE TABLE IF NOT EXISTS complaint_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  complaint_id INTEGER NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
  user_id INTEGER,
  at TEXT NOT NULL DEFAULT (datetime('now')),
  kind TEXT NOT NULL,                      -- status | note | task | info | reply
  from_status TEXT,
  to_status TEXT,
  note TEXT,
  internal INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_cevent_complaint ON complaint_events (complaint_id, at);

-- what sales and the customer said to each other about it (K10)
CREATE TABLE IF NOT EXISTS complaint_comms (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  complaint_id INTEGER NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
  user_id INTEGER,
  at TEXT NOT NULL DEFAULT (datetime('now')),
  kind TEXT NOT NULL,                      -- info (answer to quality) | customer (what was told to the customer / what came back)
  channel TEXT,
  text TEXT,
  feedback TEXT
);
CREATE INDEX IF NOT EXISTS idx_ccomm_complaint ON complaint_comms (complaint_id, at);

-- complaints that were already sent before this round are "Yeni kayıt" for quality
UPDATE complaints SET internal_status = 'Yeni kayıt', submitted_at = COALESCE(sent_at, created_at), reported_date = COALESCE(reported_date, substr(created_at, 1, 10)) WHERE status = 'sent' AND internal_status IS NULL;
