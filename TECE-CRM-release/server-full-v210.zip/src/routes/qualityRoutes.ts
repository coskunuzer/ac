import { Router, type Response } from 'express';
import { shrinkUpload } from '../services/shrinkImage';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import multer from 'multer';
import { settingsModel } from '../models/settingsModel';
import { db } from '../db/connection';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { userModel } from '../models/userModel';
import { todoModel } from '../services/todos';
import { REASONS, STATUSES } from '../data/complaintPanel';
import { complaintsDir, ensureDir, imagePath } from '../services/complaints';
import {
  statusBeforeInfo, ensurePanel, formWorkbook, isQuality, logEvent, moveStatus, nextComplaintNo, nextStatuses, noticeToDepartment, noticeToQuality, noticeToSales, registerRows, registerWorkbook, dashboard, statusInfo,
  type CRow, type TaskRow,
} from '../services/quality';

// The quality (KYS) side of the complaints: the dashboard, the register, the review and routing of one complaint, and the department tasks.
// Sales writes its complaints in /api/complaints; quality and the heads of departments work here.
const router = Router();
router.use(requireAuth);
router.use((_req, _res, next) => { ensurePanel(); next(); }); // (the tables exist only after the migrations, which run after the routes are loaded)

const str = (v: unknown, max = 2000) => String(v ?? '').trim().slice(0, max);
const day = (v: unknown): string | null => { const s = str(v, 10); return /^\d{4}-\d{2}-\d{2}$/.test(s) ? s : null; };
const parse = <T,>(s: string | null, fb: T): T => { try { return s ? (JSON.parse(s) as T) : fb; } catch { return fb; } };
const who = (req: AuthedRequest) => req.user!.display_name || req.user!.username;

function needQuality(req: AuthedRequest, res: Response): boolean {
  if (isQuality(req.user!)) return true;
  res.status(403).json({ error: 'Only the quality person can do this.' });
  return false;
}
const complaintOf = (id: number) => db.prepare('SELECT * FROM complaints WHERE id = ?').get(id) as CRow | undefined;
const taskOf = (id: number) => db.prepare('SELECT * FROM complaint_tasks WHERE id = ?').get(id) as TaskRow | undefined;
const nameOf = (id: number | null) => (id ? userModel.findById(id)?.display_name ?? null : null);

// a department head sees the tasks of the departments they head (or that are given to them by name)
function myDepartments(userId: number): string[] {
  return (db.prepare('SELECT name FROM complaint_departments WHERE head_user_id = ?').all(userId) as { name: string }[]).map((r) => r.name);
}
function mayDoTask(req: AuthedRequest, task: TaskRow): boolean {
  const u = req.user!;
  if (u.role === 'admin' || u.area === 'quality') return true;
  return task.owner_user_id === u.id || myDepartments(u.id).includes(task.department);
}

// ---- lists the pages need -----------------------------------------------------------------------------------------------------------------------
router.get('/meta', (req: AuthedRequest, res) => {
  const departments = db.prepare('SELECT name, head_user_id, head_email FROM complaint_departments ORDER BY name').all() as { name: string; head_user_id: number | null; head_email: string | null }[];
  res.json({
    reasons: REASONS, statuses: STATUSES,
    departments: departments.map((d) => ({ name: d.name, headUserId: d.head_user_id, headName: nameOf(d.head_user_id), headEmail: d.head_email })),
    deptUsers: userModel.listAll().filter((u) => u.is_active && u.area === 'dept').map((u) => ({ id: u.id, name: u.display_name || u.username })),
    area: req.user!.area ?? null, isQuality: isQuality(req.user!),
    salesUsers: userModel.listAll().filter((u) => u.is_active && !u.area && !u.is_assistant && u.role !== 'admin').map((u) => ({ id: u.id, name: u.display_name || u.username })),
    complaintTo: settingsModel.get('complaint_to') ?? 'tarik@tece.com.tr',
  });
});

router.put('/departments/:name', (req: AuthedRequest, res) => {
  if (!needQuality(req, res)) return;
  const name = decodeURIComponent(String(req.params.name));
  if (!db.prepare('SELECT 1 FROM complaint_departments WHERE name = ?').get(name)) return res.status(404).json({ error: 'Unknown department' });
  const head = Number(req.body?.headUserId) || null;
  db.prepare('UPDATE complaint_departments SET head_user_id = ?, head_email = ? WHERE name = ?').run(head, str(req.body?.headEmail, 200) || null, name);
  res.json({ ok: true });
});

// the address where every new complaint is sent (the customer complaints mailbox)
router.put('/settings', (req: AuthedRequest, res) => {
  if (!needQuality(req, res)) return;
  const list = str(req.body?.complaintTo, 400).split(/[,;\s]+/).filter(Boolean);
  if (list.some((a) => !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(a))) return res.status(400).json({ error: 'Write valid e-mail addresses.' });
  settingsModel.set('complaint_to', list.join(', '));
  res.json({ ok: true });
});

router.get('/dashboard', (req: AuthedRequest, res) => { if (needQuality(req, res)) res.json(dashboard()); });

router.get('/register', (req: AuthedRequest, res) => {
  if (!needQuality(req, res)) return;
  const q = req.query as Record<string, string>;
  const rows = registerRows({ status: q.status, q: q.q, dept: q.dept, reason: q.reason, scope: q.scope as never });
  res.json({ rows: rows.map((r) => ({
    id: r.id, no: r.complaint_no, date: r.reported_date, customer: r.customer_name, country: r.customer_country, reporter: r.reporter, order: r.order_no, product: r.product_code,
    reason: r.reason_name, priority: r.priority, status: r.internal_status, depts: r.depts, openTasks: r.open_tasks, lateTasks: r.late_tasks, submittedAt: r.submitted_at, closedAt: r.closed_at,
    rootCause: r.root_cause, result: r.result_text, action: r.result_action, shared: !!r.share_result,
  })) });
});

router.get('/register.xlsx', async (req: AuthedRequest, res) => {
  if (!needQuality(req, res)) return;
  const q = req.query as Record<string, string>;
  const buf = await registerWorkbook(registerRows({ status: q.status, q: q.q, dept: q.dept, reason: q.reason, scope: q.scope as never }));
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', 'attachment; filename="TECE-sikayet-kayitlari.xlsx"');
  res.send(buf);
});

// ---- the department head: my tasks -------------------------------------------------------------------------------------------------------------------
router.get('/tasks/mine', (req: AuthedRequest, res) => {
  const u = req.user!;
  const deps = myDepartments(u.id);
  const marks = deps.map(() => '?').join(',');
  const rows = db.prepare(`SELECT t.*, c.complaint_no, c.customer_name, c.product_code, c.order_no, c.reason_code FROM complaint_tasks t JOIN complaints c ON c.id = t.complaint_id
    WHERE (t.owner_user_id = ?${deps.length ? ` OR t.department IN (${marks})` : ''}) ORDER BY (t.state IN ('open', 'more_info')) DESC, t.due_date`).all(u.id, ...deps) as unknown as (TaskRow & { complaint_no: string | null; customer_name: string | null; product_code: string | null; order_no: string | null; reason_code: string | null })[];
  const today = new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });
  res.json({ tasks: rows.map((t) => ({ id: t.id, complaintId: t.complaint_id, no: t.complaint_no, customer: t.customer_name, product: t.product_code, order: t.order_no, department: t.department, due: t.due_date, state: t.state, late: !!t.due_date && t.due_date < today && (t.state === 'open' || t.state === 'more_info'), reason: REASONS.find((r) => r.code === t.reason_code)?.name ?? null })) });
});

router.get('/tasks/:tid', (req: AuthedRequest, res) => {
  const task = taskOf(parseInt(String(req.params.tid), 10));
  if (!task) return res.status(404).json({ error: 'Not found' });
  if (!mayDoTask(req, task)) return res.status(403).json({ error: 'This task is not for you.' });
  const c = complaintOf(task.complaint_id)!;
  const polished = parse<{ title?: string; summary?: string; details?: string[] } | null>(c.polished_json, null);
  res.json({
    task: { id: task.id, department: task.department, due: task.due_date, instruction: task.instruction, state: task.state, rootCause: task.root_cause, correction: task.correction, corrective: task.corrective, preventive: task.preventive, effectiveness: task.effectiveness, reviewNote: task.review_note },
    complaint: { id: c.id, no: c.complaint_no, customer: c.customer_name, country: c.customer_country, product: c.product_code, order: c.order_no, orderQty: c.order_qty, complainedQty: c.complained_qty, reason: REASONS.find((r) => r.code === c.reason_code)?.name ?? null, text: c.raw_text, summary: polished?.summary ?? null, title: polished?.title ?? null, request: c.customer_request },
    images: (db.prepare('SELECT id, original_name, caption FROM complaint_images WHERE complaint_id = ? ORDER BY id').all(c.id) as { id: number; original_name: string | null; caption: string | null }[]).map((i) => ({ id: i.id, name: i.original_name, caption: i.caption ?? '' })),
  });
});

router.put('/tasks/:tid', (req: AuthedRequest, res) => {
  const task = taskOf(parseInt(String(req.params.tid), 10));
  if (!task) return res.status(404).json({ error: 'Not found' });
  if (!mayDoTask(req, task)) return res.status(403).json({ error: 'This task is not for you.' });
  if (!['open', 'more_info'].includes(task.state)) return res.status(400).json({ error: 'This answer was already sent to quality.' });
  const b = (req.body ?? {}) as Record<string, unknown>;
  const v = { root: str(b.rootCause), cor: str(b.correction), cora: str(b.corrective), pre: str(b.preventive), eff: str(b.effectiveness) };
  const submit = b.submit === true;
  if (submit && (!v.root || !v.cora)) return res.status(400).json({ error: 'Write the root cause and the corrective action before sending.' });
  db.prepare('UPDATE complaint_tasks SET root_cause = ?, correction = ?, corrective = ?, preventive = ?, effectiveness = ? WHERE id = ?').run(v.root || null, v.cor || null, v.cora || null, v.pre || null, v.eff || null, task.id);
  if (submit) {
    db.prepare("UPDATE complaint_tasks SET state = 'sent', submitted_at = datetime('now') WHERE id = ?").run(task.id);
    logEvent(task.complaint_id, req.user!.id, 'task', null, null, `${task.department}: answer sent to quality`, true);
    const c = complaintOf(task.complaint_id)!;
    const still = (db.prepare("SELECT COUNT(*) AS n FROM complaint_tasks WHERE complaint_id = ? AND state IN ('open', 'more_info')").get(c.id) as { n: number }).n;
    if (!still && c.internal_status === 'Birim yanıtı bekleniyor') moveStatus(c, 'KYS değerlendirmesi bekleniyor', req.user!.id, 'All departments answered');
    void noticeToQuality({ ...c, customer_name: `${c.customer_name} - ${task.department} cevabı geldi` } as CRow, who(req));
  }
  res.json({ ok: true });
});

// ---- one complaint (quality) -----------------------------------------------------------------------------------------------------------------
function fullView(c: CRow) {
  const tasks = db.prepare('SELECT * FROM complaint_tasks WHERE complaint_id = ? ORDER BY id').all(c.id) as unknown as TaskRow[];
  const today = new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });
  return {
    id: c.id, no: c.complaint_no, status: c.internal_status, next: nextStatuses(c.internal_status), salesLabel: statusInfo(c.internal_status)?.label ?? null,
    customer: { name: c.customer_name, contact: c.customer_contact, email: c.customer_email, country: c.customer_country, cardId: c.card_id },
    reporter: nameOf(c.created_by), reportedDate: c.reported_date, channel: c.channel, productCode: c.product_code, orderNo: c.order_no, orderQty: c.order_qty, complainedQty: c.complained_qty,
    closeTarget: c.close_target, creditNote: c.credit_note, repUserId: c.rep_user_id, resultText: c.result_text, shareResult: !!c.share_result,
    files: (db.prepare('SELECT id, kind, original_name, uploaded_by, uploaded_at FROM complaint_files WHERE complaint_id = ? ORDER BY id').all(c.id) as { id: number; kind: string; original_name: string | null; uploaded_by: number | null; uploaded_at: string }[]).map((f) => ({ id: f.id, kind: f.kind, name: f.original_name, by: nameOf(f.uploaded_by), at: f.uploaded_at })),
    reasonCode: c.reason_code, text: c.raw_text, request: c.customer_request, polished: parse(c.polished_json, null), amount: c.amount_wasted, currency: c.currency, kind: c.kind,
    priority: c.priority, opOccurred: c.op_occurred, opDetected: c.op_detected, evalTeam: c.eval_team, rootCause: c.root_cause, resultAction: c.result_action,
    capaRequired: c.capa_required, capaDate: c.capa_date, customerReplied: c.customer_replied, customerReplyDate: c.customer_reply_date, approvedReply: c.approved_reply,
    infoRequest: c.info_request, infoDue: c.info_due, submittedAt: c.submitted_at, closedAt: c.closed_at, reopenCount: c.reopen_count,
    tasks: tasks.map((t) => ({ id: t.id, department: t.department, owner: nameOf(t.owner_user_id), due: t.due_date, late: !!t.due_date && t.due_date < today && (t.state === 'open' || t.state === 'more_info'), instruction: t.instruction, state: t.state,
      rootCause: t.root_cause, correction: t.correction, corrective: t.corrective, preventive: t.preventive, effectiveness: t.effectiveness, reviewNote: t.review_note, submittedAt: t.submitted_at })),
    events: (db.prepare('SELECT * FROM complaint_events WHERE complaint_id = ? ORDER BY id DESC').all(c.id) as { id: number; user_id: number | null; at: string; kind: string; from_status: string | null; to_status: string | null; note: string | null; internal: number }[])
      .map((e) => ({ id: e.id, who: nameOf(e.user_id), at: e.at, kind: e.kind, from: e.from_status, to: e.to_status, note: e.note, internal: !!e.internal })),
    comms: (db.prepare('SELECT * FROM complaint_comms WHERE complaint_id = ? ORDER BY id DESC').all(c.id) as { id: number; user_id: number | null; at: string; kind: string; channel: string | null; text: string | null; feedback: string | null }[])
      .map((m) => ({ id: m.id, who: nameOf(m.user_id), at: m.at, kind: m.kind, channel: m.channel, text: m.text, feedback: m.feedback })),
    images: (db.prepare('SELECT id, original_name, caption FROM complaint_images WHERE complaint_id = ? ORDER BY id').all(c.id) as { id: number; original_name: string | null; caption: string | null }[]).map((i) => ({ id: i.id, name: i.original_name, caption: i.caption ?? '' })),
  };
}

router.get('/:id', (req: AuthedRequest, res) => {
  if (!needQuality(req, res)) return;
  const c = complaintOf(parseInt(String(req.params.id), 10));
  if (!c || !c.internal_status) return res.status(404).json({ error: 'Complaint not found' });
  res.json(fullView(c));
});

router.get('/:id/images/:imageId', (req: AuthedRequest, res) => {
  const cid = parseInt(String(req.params.id), 10);
  const allowed = isQuality(req.user!) || !!db.prepare('SELECT 1 FROM complaint_tasks t WHERE t.complaint_id = ? AND (t.owner_user_id = ? OR t.department IN (SELECT name FROM complaint_departments WHERE head_user_id = ?))').get(cid, req.user!.id, req.user!.id);
  if (!allowed) return res.status(403).json({ error: 'No access' });
  const img = db.prepare('SELECT stored_name FROM complaint_images WHERE id = ? AND complaint_id = ?').get(parseInt(String(req.params.imageId), 10), cid) as { stored_name: string } | undefined;
  if (!img || !fs.existsSync(imagePath(img.stored_name))) return res.status(404).json({ error: 'Not found' });
  res.sendFile(imagePath(img.stored_name));
});

// the evaluation block (the fields of the corporate form) and the reason / priority
router.put('/:id/eval', (req: AuthedRequest, res) => {
  if (!needQuality(req, res)) return;
  const c = complaintOf(parseInt(String(req.params.id), 10));
  if (!c || !c.internal_status) return res.status(404).json({ error: 'Complaint not found' });
  const b = (req.body ?? {}) as Record<string, unknown>;
  const reason = str(b.reasonCode, 6);
  if (reason && !REASONS.some((r) => r.code === reason)) return res.status(400).json({ error: 'Unknown reason code' });
  const yn = (v: unknown): number | null => (v === true || v === 1 || v === 'yes' ? 1 : v === false || v === 0 || v === 'no' ? 0 : null);
  const has = (k: string) => Object.prototype.hasOwnProperty.call(b, k);
  const txt = (k: string, cur: string | null, max = 4000) => (has(k) ? str(b[k], max) || null : cur);
  const prio = ['low', 'normal', 'high'].includes(str(b.priority, 10)) ? str(b.priority, 10) : c.priority;
  const rep = has('repUserId') ? (Number(b.repUserId) || null) : c.rep_user_id;
  db.prepare(`UPDATE complaints SET reason_code = ?, priority = ?, op_occurred = ?, op_detected = ?, eval_team = ?, root_cause = ?, result_text = ?, result_action = ?, capa_required = ?, capa_date = ?, customer_replied = ?, customer_reply_date = ?, approved_reply = ?, rep_user_id = ?, share_result = ?, close_target = ?, updated_at = datetime('now') WHERE id = ?`)
    .run(reason || c.reason_code, prio, txt('opOccurred', c.op_occurred, 120), txt('opDetected', c.op_detected, 120), txt('evalTeam', c.eval_team, 200), txt('rootCause', c.root_cause), txt('resultText', c.result_text), txt('resultAction', c.result_action),
      has('capaRequired') ? yn(b.capaRequired) : c.capa_required, has('capaDate') ? day(b.capaDate) : c.capa_date, has('customerReplied') ? yn(b.customerReplied) : c.customer_replied, has('customerReplyDate') ? day(b.customerReplyDate) : c.customer_reply_date,
      txt('approvedReply', c.approved_reply), rep, has('shareResult') ? (b.shareResult === true || b.shareResult === 1 ? 1 : 0) : c.share_result, has('closeTarget') ? day(b.closeTarget) : c.close_target, c.id);
  db.prepare('UPDATE complaints SET capa_date = NULL WHERE id = ? AND COALESCE(capa_required, 0) != 1').run(c.id); // no corrective action: no date
  res.json({ ok: true });
});

// the number is given by quality (KYS): MHBK + running number + the number of the reason + the day
router.post('/:id/number', (req: AuthedRequest, res) => {
  if (!needQuality(req, res)) return;
  const c = complaintOf(parseInt(String(req.params.id), 10));
  if (!c || !c.internal_status) return res.status(404).json({ error: 'Complaint not found' });
  if (c.complaint_no) return res.json({ no: c.complaint_no });
  if (!c.reason_code) return res.status(400).json({ error: 'Choose the reason first: the number contains it.' });
  const no = nextComplaintNo(c.reason_code, c.reported_date ?? c.created_at);
  db.prepare('UPDATE complaints SET complaint_no = ? WHERE id = ?').run(no, c.id);
  logEvent(c.id, req.user!.id, 'note', null, null, `Number given: ${no}`, true);
  res.json({ no });
});

router.post('/:id/status', async (req: AuthedRequest, res) => {
  if (!needQuality(req, res)) return;
  const c = complaintOf(parseInt(String(req.params.id), 10));
  if (!c || !c.internal_status) return res.status(404).json({ error: 'Complaint not found' });
  const to = str(req.body?.to, 60);
  // taking a complaint into review gives it its number
  if (to === 'Ön inceleme' && !c.complaint_no && c.reason_code) {
    db.prepare('UPDATE complaints SET complaint_no = ? WHERE id = ?').run(nextComplaintNo(c.reason_code, c.reported_date ?? c.created_at), c.id);
  }
  const err = moveStatus(complaintOf(c.id)!, to, req.user!.id, str(req.body?.note, 1000) || null);
  if (err) return res.status(400).json({ error: err });
  const fresh = complaintOf(c.id)!;
  if (to === 'Kapatıldı') void noticeToSales(fresh, 'Şikayet kalite tarafından kapatıldı.');
  res.json(fullView(fresh));
});

router.post('/:id/note', (req: AuthedRequest, res) => {
  if (!needQuality(req, res)) return;
  const c = complaintOf(parseInt(String(req.params.id), 10));
  if (!c || !c.internal_status) return res.status(404).json({ error: 'Complaint not found' });
  const text = str(req.body?.text, 2000);
  if (!text) return res.status(400).json({ error: 'Write the note.' });
  logEvent(c.id, req.user!.id, 'note', null, null, text, true); // internal: never shown to sales (K04)
  res.json(fullView(c));
});

// ask sales for more information or a document (K06)
router.post('/:id/request-info', async (req: AuthedRequest, res) => {
  if (!needQuality(req, res)) return;
  const c = complaintOf(parseInt(String(req.params.id), 10));
  if (!c || !c.internal_status) return res.status(404).json({ error: 'Complaint not found' });
  const text = str(req.body?.text, 1500);
  if (!text) return res.status(400).json({ error: 'Write what you need (a document, a photo, a number).' });
  db.prepare('UPDATE complaints SET info_request = ?, info_due = ? WHERE id = ?').run(text, day(req.body?.due), c.id);
  const err = moveStatus(complaintOf(c.id)!, 'Bilgi bekleniyor', req.user!.id, text);
  if (err) return res.status(400).json({ error: err });
  const fresh = complaintOf(c.id)!;
  for (const uid of new Set([c.created_by, c.rep_user_id ?? 0])) if (uid && fresh.info_due) todoModel.add({ userId: uid, cardId: c.card_id, text: `Şikayet ${fresh.complaint_no ?? `#${c.id}`}: kalite ek bilgi istiyor`, dueDate: fresh.info_due });
  void noticeToSales(fresh, `Kalite ek bilgi istiyor: ${text}${fresh.info_due ? `\nSon tarih: ${fresh.info_due}` : ''}`);
  res.json(fullView(fresh));
});

// ask departments (K01): one task for each, with the day it is due; the heads are told at once
router.post('/:id/forward', async (req: AuthedRequest, res) => {
  if (!needQuality(req, res)) return;
  const c = complaintOf(parseInt(String(req.params.id), 10));
  if (!c || !c.internal_status) return res.status(404).json({ error: 'Complaint not found' });
  const list = (Array.isArray(req.body?.departments) ? req.body.departments : []) as { name?: string; due?: string }[];
  const instruction = str(req.body?.instruction, 1000);
  if (!list.length) return res.status(400).json({ error: 'Choose at least one department.' });
  const known = new Set((db.prepare('SELECT name FROM complaint_departments').all() as { name: string }[]).map((d) => d.name));
  if (list.some((d) => !known.has(String(d.name)))) return res.status(400).json({ error: 'Unknown department.' });
  if (!c.reason_code) return res.status(400).json({ error: 'Choose the complaint reason before forwarding.' });
  // bring the status to "Birim yanıtı bekleniyor" along the allowed lines
  const path: Record<string, string[]> = { 'Ön inceleme': ['Birim yanıtı bekleniyor'], 'KYS değerlendirmesi bekleniyor': ['Birim yanıtı bekleniyor'], 'Müşteri yanıtı bekleniyor': ['KYS değerlendirmesi bekleniyor', 'Birim yanıtı bekleniyor'], 'Yeniden açıldı': ['Birim yanıtı bekleniyor'], 'Birim yanıtı bekleniyor': [] };
  const steps = path[c.internal_status];
  if (!steps) return res.status(400).json({ error: `A complaint in "${c.internal_status}" cannot be forwarded. Take it into review first.` });
  if (!c.complaint_no) db.prepare('UPDATE complaints SET complaint_no = ? WHERE id = ?').run(nextComplaintNo(c.reason_code, c.reported_date ?? c.created_at), c.id);
  for (const to of steps) { const err = moveStatus(complaintOf(c.id)!, to, req.user!.id, to === 'Birim yanıtı bekleniyor' ? `Forwarded to ${list.map((d) => d.name).join(', ')}` : null); if (err) return res.status(400).json({ error: err }); }
  const fresh = complaintOf(c.id)!;
  for (const d of list) {
    const dname = String(d.name);
    const head = db.prepare('SELECT head_user_id FROM complaint_departments WHERE name = ?').get(dname) as { head_user_id: number | null };
    const r = db.prepare('INSERT INTO complaint_tasks (complaint_id, department, owner_user_id, due_date, instruction, created_by) VALUES (?, ?, ?, ?, ?, ?)').run(c.id, dname, head.head_user_id, day(d.due), instruction || null, req.user!.id);
    const task = taskOf(Number(r.lastInsertRowid))!;
    logEvent(c.id, req.user!.id, 'task', null, null, `Task opened for ${dname}${task.due_date ? ` (due ${task.due_date})` : ''}`, true);
    if (head.head_user_id && task.due_date) todoModel.add({ userId: head.head_user_id, cardId: null, text: `Şikayet ${fresh.complaint_no}: ${dname} cevabı`, dueDate: task.due_date });
    void noticeToDepartment(fresh, task);
  }
  res.json(fullView(complaintOf(c.id)!));
});

// quality reads a department's answer: accept it, or ask for more (K08)
router.post('/tasks/:tid/review', async (req: AuthedRequest, res) => {
  if (!needQuality(req, res)) return;
  const task = taskOf(parseInt(String(req.params.tid), 10));
  if (!task) return res.status(404).json({ error: 'Not found' });
  if (task.state !== 'sent') return res.status(400).json({ error: 'There is no answer waiting to be read.' });
  const action = str(req.body?.action, 10);
  const note = str(req.body?.note, 1000);
  if (action === 'accept') {
    db.prepare("UPDATE complaint_tasks SET state = 'accepted', review_note = ?, reviewed_at = datetime('now') WHERE id = ?").run(note || null, task.id);
    logEvent(task.complaint_id, req.user!.id, 'task', null, null, `${task.department}: answer accepted${note ? ` (${note})` : ''}`, true);
  } else if (action === 'more') {
    if (!note) return res.status(400).json({ error: 'Write what is missing.' });
    db.prepare("UPDATE complaint_tasks SET state = 'more_info', review_note = ?, reviewed_at = datetime('now') WHERE id = ?").run(note, task.id);
    logEvent(task.complaint_id, req.user!.id, 'task', null, null, `${task.department}: more information asked - ${note}`, true);
    const c = complaintOf(task.complaint_id)!;
    if (c.internal_status === 'KYS değerlendirmesi bekleniyor') moveStatus(c, 'Birim yanıtı bekleniyor', req.user!.id, `Ek bilgi istendi: ${note}`);
    void noticeToDepartment(complaintOf(c.id)!, { ...task, instruction: `Ek bilgi isteniyor: ${note}` });
  } else return res.status(400).json({ error: 'accept or more' });
  res.json(fullView(complaintOf(task.complaint_id)!));
});

// reports of the review and the result (PDF, Excel, photos), added by hand: who and when is kept (K11)
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 15 * 1024 * 1024, files: 5 } });
const FILE_TYPES: Record<string, string> = { 'application/pdf': '.pdf', 'image/jpeg': '.jpg', 'image/png': '.png', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': '.xlsx', 'application/vnd.ms-excel': '.xls', 'application/msword': '.doc', 'message/rfc822': '.eml', 'application/vnd.ms-outlook': '.msg', 'text/csv': '.csv', 'text/plain': '.txt', 'application/zip': '.zip', 'application/x-zip-compressed': '.zip', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document': '.docx' };
router.post('/:id/files', upload.array('files', 5), async (req: AuthedRequest, res) => {
  if (!needQuality(req, res)) return;
  const c = complaintOf(parseInt(String(req.params.id), 10));
  if (!c || !c.internal_status) return res.status(404).json({ error: 'Complaint not found' });
  ensureDir();
  for (const f of (req.files as Express.Multer.File[]) ?? []) {
    const byName = path.extname(Buffer.from(f.originalname, 'latin1').toString('utf8')).toLowerCase();
    const ext = FILE_TYPES[f.mimetype] ?? (['.msg', '.eml', '.csv', '.txt', '.zip', '.xls', '.xlsx', '.doc', '.docx', '.pdf'].includes(byName) ? byName : undefined);
    if (!ext) return res.status(400).json({ error: 'PDF, Word, Excel, e-mail (.eml/.msg), CSV, text, ZIP or JPG/PNG files only.' });
    const small = await shrinkUpload(f, ext);
    const stored = `r${c.id}-${crypto.randomBytes(6).toString('hex')}${small.ext}`;
    fs.writeFileSync(path.join(complaintsDir, stored), small.buffer);
    db.prepare('INSERT INTO complaint_files (complaint_id, kind, stored_name, original_name, uploaded_by) VALUES (?, ?, ?, ?, ?)').run(c.id, 'report', stored, Buffer.from(f.originalname, 'latin1').toString('utf8').slice(0, 140), req.user!.id);
    logEvent(c.id, req.user!.id, 'file', null, null, `Report added: ${f.originalname}`, true);
  }
  res.json(fullView(complaintOf(c.id)!));
});
router.delete('/:id/files/:fid', (req: AuthedRequest, res) => {
  if (!needQuality(req, res)) return;
  const f = db.prepare('SELECT * FROM complaint_files WHERE id = ? AND complaint_id = ?').get(parseInt(String(req.params.fid), 10), parseInt(String(req.params.id), 10)) as { id: number; stored_name: string; original_name: string | null } | undefined;
  if (!f) return res.status(404).json({ error: 'Not found' });
  db.prepare('DELETE FROM complaint_files WHERE id = ?').run(f.id);
  try { fs.unlinkSync(imagePath(f.stored_name)); } catch { /* already gone */ }
  logEvent(parseInt(String(req.params.id), 10), req.user!.id, 'file', null, null, `Report removed: ${f.original_name ?? ''}`, true);
  res.json(fullView(complaintOf(parseInt(String(req.params.id), 10))!));
});
router.get('/:id/files/:fid', (req: AuthedRequest, res) => {
  const cid = parseInt(String(req.params.id), 10);
  const c = complaintOf(cid);
  const f = db.prepare('SELECT * FROM complaint_files WHERE id = ? AND complaint_id = ?').get(parseInt(String(req.params.fid), 10), cid) as { stored_name: string; original_name: string | null } | undefined;
  if (!c || !f || !fs.existsSync(imagePath(f.stored_name))) return res.status(404).json({ error: 'Not found' });
  if (!isQuality(req.user!)) return res.status(403).json({ error: 'No access' });
  res.download(imagePath(f.stored_name), f.original_name ?? f.stored_name);
});

router.get('/:id/form.xlsx', async (req: AuthedRequest, res) => {
  if (!needQuality(req, res)) return;
  const c = complaintOf(parseInt(String(req.params.id), 10));
  if (!c || !c.internal_status) return res.status(404).json({ error: 'Complaint not found' });
  const buf = await formWorkbook(c);
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', `attachment; filename="${(c.complaint_no ?? `MHBK-${c.id}`).replace(/[^\w.-]/g, '_')}-Hata Bildirim Formu.xlsx"`);
  res.send(buf);
});

export default router;
