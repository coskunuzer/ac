import fs from 'fs';
import path from 'path';
import { db } from './connection';

function runMigrations() {
  db.exec(
    `CREATE TABLE IF NOT EXISTS schema_migrations (
      filename TEXT PRIMARY KEY,
      applied_at TEXT NOT NULL DEFAULT (datetime('now'))
    )`
  );

  const dir = path.resolve(__dirname, 'migrations');
  const files = fs.readdirSync(dir).filter((f) => f.endsWith('.sql')).sort();
  const alreadyApplied = db.prepare('SELECT 1 FROM schema_migrations WHERE filename = ?');
  const recordApplied = db.prepare('INSERT INTO schema_migrations (filename) VALUES (?)');

  for (const file of files) {
    if (alreadyApplied.get(file)) {
      console.log(`Skipping already-applied migration: ${file}`);
      continue;
    }
    const sql = fs.readFileSync(path.join(dir, file), 'utf8');
    db.exec(sql);
    recordApplied.run(file);
    console.log(`Applied migration: ${file}`);
  }
}

if (require.main === module) {
  runMigrations();
  console.log('Migrations complete.');
}

export { runMigrations };
