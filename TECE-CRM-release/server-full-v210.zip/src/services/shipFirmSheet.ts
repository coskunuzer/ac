import * as XLSX from 'xlsx';
import { db } from '../db/connection';
import { countryName, findForwarder, listForwarders, MODES, saveForwarder, splitPlaces, type Forwarder } from './shipPlaces';

// The whole list of transport firms as an Excel file, and back: the file is edited (a cell changed, a row added, "Sil" marked) and uploaded again.
// The upload REPLACES what is written for a firm that has an ID, adds a firm that has no ID, and removes only the rows marked "Sil = EVET".
// Every change is shown first; a firm that is removed is kept in the firm log (append-only), and past requests keep its name.

const HEAD = ['ID', 'Firma', 'Yetkili', 'E-posta (birden çoksa virgülle)', 'Taşıma türü (virgülle)', 'Hizmet verdiği yerler (ülke veya bölge, virgülle; "Tüm ülkeler")', 'Dil (TR/EN)', 'Aktif (EVET/HAYIR)', 'Not', 'Sil (EVET yazın)'] as const;

export function firmSheet(): Buffer {
  const rows = listForwarders().map((f) => [f.id, f.name, f.contact ?? '', f.emails.join(', '), f.modes.join(', '), f.covAll ? 'Tüm ülkeler' : [...f.covRegions, ...f.covCountries.map(countryName)].join(', '), f.lang === 'en' ? 'EN' : 'TR', f.active ? 'EVET' : 'HAYIR', f.note ?? '', '']);
  const ws = XLSX.utils.aoa_to_sheet([[...HEAD], ...rows]);
  ws['!cols'] = [{ wch: 6 }, { wch: 30 }, { wch: 20 }, { wch: 40 }, { wch: 30 }, { wch: 50 }, { wch: 10 }, { wch: 12 }, { wch: 30 }, { wch: 14 }];
  const help = XLSX.utils.aoa_to_sheet([
    ['Nasıl kullanılır'],
    ['1. Bu dosyayı Excel\'de düzenleyin: bir hücreyi değiştirin, alta yeni firma satırı ekleyin (ID boş kalsın), silmek için "Sil" sütununa EVET yazın.'],
    ['2. Nakliye > Taşıma firmaları > "Güncel listeyi yükle" ile dosyayı geri yükleyin. Önce neyin değişeceği gösterilir, siz onaylayınca uygulanır.'],
    ['3. ID sütununu değiştirmeyin. ID\'si olan satır o firmayı günceller; ID\'si boş satır yeni firma olur.'],
    ['4. Hizmet verdiği yerler: ülke adı veya bölge adı yazın (ör. "Almanya, Balkanlar"). Tüm ülkeler için "Tüm ülkeler".'],
    ['5. Taşıma türü: Karayolu, Denizyolu (Konteyner), Denizyolu (LCL), Havayolu.'],
    ['6. Silinen firmanın geçmiş talepleri ve teklifleri korunur. Açık bir talepte yanıt bekleyen firma silinmez.'],
  ]);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Firmalar');
  XLSX.utils.book_append_sheet(wb, help, 'Nasıl kullanılır');
  return XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' }) as Buffer;
}

export interface SheetAction { row: number; kind: 'add' | 'update' | 'delete' | 'same' | 'error'; id: number | null; name: string; changes: string[]; error?: string; input?: Parameters<typeof saveForwarder>[1] }

const cell = (r: unknown[], i: number) => String(r[i] ?? '').trim();
const yes = (v: string) => /^(evet|e|yes|y|1|x|true)$/i.test(v.trim());

function parseRow(r: unknown[], n: number): SheetAction {
  const id = Number(cell(r, 0)) || null;
  const name = cell(r, 1);
  const act: SheetAction = { row: n, kind: id ? 'update' : 'add', id, name, changes: [] };
  if (yes(cell(r, 9))) { act.kind = 'delete'; return act; }
  const emails = cell(r, 3).match(/[^\s;,<>]+@[^\s;,<>]+\.[^\s;,<>]+/g) ?? [];
  const modes = MODES.filter((m) => cell(r, 4).toLowerCase().replace(/[()]/g, '').includes(m.toLowerCase().replace(/[()]/g, '')) || (m === 'Karayolu' && /karayolu|kamyon|road/i.test(cell(r, 4))) || (m === 'Havayolu' && /hava|air/i.test(cell(r, 4))));
  const placeText = cell(r, 5);
  const regionsSet: string[] = [], countries: string[] = []; let covAll = false; const bad: string[] = [];
  for (const p of placeText ? splitPlaces(placeText) : []) {
    if (p.type === 'all') covAll = true;
    else if (p.type === 'region') { if (!regionsSet.includes(p.name)) regionsSet.push(p.name); }
    else if (p.type === 'country') { if (!countries.includes(p.iso)) countries.push(p.iso); }
    else bad.push(p.orig);
  }
  if (/^t[uü]m\s*(ulke|ülke|b[oö]lge)/i.test(placeText)) covAll = true;
  if (!name) { act.kind = 'error'; act.error = 'Firma adı boş.'; return act; }
  if (!emails.length) { act.kind = 'error'; act.error = 'Geçerli e-posta yok.'; return act; }
  if (!modes.length) { act.kind = 'error'; act.error = 'Taşıma türü anlaşılamadı.'; return act; }
  if (bad.length) { act.kind = 'error'; act.error = `Tanınmayan yer: ${bad.join(', ')}`; return act; }
  if (!covAll && !regionsSet.length && !countries.length) { act.kind = 'error'; act.error = 'Hizmet verdiği yer yok.'; return act; }
  act.input = { name, contact: cell(r, 2) || null, emails, modes: [...modes], lang: /^en/i.test(cell(r, 6)) ? 'en' : 'tr', active: !/^(hay[ıi]r|h|no|n|0|pasif)$/i.test(cell(r, 7)), note: cell(r, 8) || null, covAll, covRegions: regionsSet, covCountries: countries };
  return act;
}

const same = (a: string[], b: string[]) => a.length === b.length && [...a].sort().join('|') === [...b].sort().join('|');
function diff(old: Forwarder, n: NonNullable<SheetAction['input']>): string[] {
  const c: string[] = [];
  if (old.name !== n.name) c.push(`ad: ${old.name} → ${n.name}`);
  if ((old.contact ?? '') !== (n.contact ?? '')) c.push('yetkili');
  if (!same(old.emails, n.emails)) c.push(`e-posta: ${old.emails.join(', ')} → ${n.emails.join(', ')}`);
  if (!same(old.modes, n.modes)) c.push(`taşıma türü: ${old.modes.join(', ')} → ${n.modes.join(', ')}`);
  if (old.covAll !== !!n.covAll || !same(old.covRegions, n.covRegions ?? []) || !same(old.covCountries, n.covCountries ?? [])) c.push('hizmet verdiği yerler');
  if (old.lang !== n.lang) c.push(`dil: ${n.lang === 'en' ? 'EN' : 'TR'}`);
  if (old.active !== (n.active !== false)) c.push(n.active === false ? 'pasif yapıldı' : 'aktif yapıldı');
  if ((old.note ?? '') !== (n.note ?? '')) c.push('not');
  return c;
}

export function sheetPlan(rows: unknown[][]): SheetAction[] {
  const out: SheetAction[] = [];
  rows.forEach((r, i) => {
    if (i === 0 && /^id$/i.test(cell(r, 0))) return;
    if (r.every((c) => !String(c ?? '').trim())) return;
    const a = parseRow(r, i + 1);
    if (a.kind === 'update' || a.kind === 'delete') {
      const old = a.id ? findForwarder(a.id) : null;
      if (!old) { a.kind = 'error'; a.error = `ID ${a.id} bulunamadı (silinmiş olabilir).`; }
      else if (a.kind === 'delete') {
        a.name = old.name;
        const open = db.prepare("SELECT COUNT(*) AS n FROM ship_request_fw w JOIN ship_requests r ON r.id = w.request_id WHERE w.forwarder_id = ? AND r.status = 'open' AND w.answered_at IS NULL AND w.cancelled_at IS NULL").get(old.id) as { n: number };
        if (open.n > 0) { a.kind = 'error'; a.error = `${old.name}: açık ${open.n} talepte yanıt bekleniyor; silinmedi.`; }
      } else if (a.input) {
        a.changes = diff(old, a.input);
        if (!a.changes.length) a.kind = 'same';
      }
    } else if (a.kind === 'add' && a.input) {
      const dup = listForwarders().find((f) => f.name.trim().toLowerCase() === a.input!.name.toLowerCase());
      if (dup) { a.kind = 'error'; a.error = `"${a.input.name}" zaten var (ID ${dup.id}). Güncellemek için ID'sini yazın.`; }
    }
    out.push(a);
  });
  return out;
}

export function sheetApply(rows: unknown[][], userId: number): { added: number; updated: number; deleted: number; skipped: number } {
  const plan = sheetPlan(rows);
  let added = 0, updated = 0, deleted = 0;
  const log = (f: Forwarder, action: string) => db.prepare('INSERT INTO ship_firm_log (forwarder_id, name, action, snapshot, user_id) VALUES (?, ?, ?, ?, ?)').run(f.id, f.name, action, JSON.stringify(f), userId);
  for (const a of plan) {
    if (a.kind === 'add' && a.input) { saveForwarder(null, a.input); added++; }
    else if (a.kind === 'update' && a.input && a.id) { const old = findForwarder(a.id); if (old) log(old, 'edited (excel)'); saveForwarder(a.id, a.input); updated++; }
    else if (a.kind === 'delete' && a.id) { const old = findForwarder(a.id); if (old) { log(old, 'deleted (excel)'); db.prepare('DELETE FROM ship_forwarders WHERE id = ?').run(a.id); deleted++; } }
  }
  return { added, updated, deleted, skipped: plan.filter((a) => a.kind === 'error').length };
}
