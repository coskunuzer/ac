import { Router } from 'express';
import { requireAuth, requireAdmin, type AuthedRequest } from '../middleware/auth';
import { settingsModel } from '../models/settingsModel';
import { cardModel } from '../models/cardModel';
import { askJson } from '../services/perfActions';
import { useAi } from '../services/aiBudget';
import { aiFailureMessage } from '../services/aiGate';
import { fillModel } from '../services/drafts';
import { mailProblems } from '../services/emailSafety';

// Admin -> Introduction e-mail: the house model of the first e-mail to a potential customer. The admin gives a few versions, the AI writes a better one, the admin
// edits and saves it. From then on every introduction follows it (the AI personalises it for each customer).
const router = Router();
router.use(requireAuth, requireAdmin);

router.get('/', (_req, res) => res.json({ subject: settingsModel.get('intro_model_subject') ?? '', body: settingsModel.get('intro_model_body') ?? '', rules: settingsModel.get('intro_rules') ?? '' }));

router.put('/', (req, res) => {
  const subject = String(req.body?.subject ?? '').slice(0, 200).trim(), body = String(req.body?.body ?? '').slice(0, 4000).trim(), rules = String(req.body?.rules ?? '').slice(0, 800).trim();
  settingsModel.set('intro_model_subject', subject); settingsModel.set('intro_model_body', body); settingsModel.set('intro_rules', rules);
  res.json({ ok: true });
});

router.post('/improve', async (req: AuthedRequest, res) => {
  const options = (Array.isArray(req.body?.options) ? req.body.options : []).map((x: unknown) => String(x ?? '').trim()).filter((x: string) => x.length > 20).slice(0, 5);
  if (!options.length) return res.status(400).json({ error: 'Paste at least one version first (a few lines).' });
  if (!useAi(req.user!, res)) return;
  const wish = String(req.body?.wish ?? '').trim().slice(0, 400);
  const lang = req.body?.language === 'Turkish' ? 'Turkish' : 'English';
  const j = await askJson([
    'You are the best B2B sales copywriter for TECE, a Turkish maker of PVC, ABS and PP edgebanding for furniture and panel factories.',
    `Below are ${options.length} draft version(s) of the FIRST e-mail to a potential customer, written by the sales director. Write ONE better version in ${lang}: it keeps the best lines and the facts of the drafts, is warm and direct, in short paragraphs, under 120 words, plain words (no "I hope this finds you well", no "reach out", no corporate phrases), with ONE easy question or offer at the end.`,
    'Use the placeholders {name} (contact first name), {company}, {country} and {sender} where the e-mail should be personal. Do not invent prices, certificates, years, numbers or claims that are not in the drafts. Do not add a signature.',
    wish ? `What the director wants: ${wish}` : '',
    options.map((o: string, i: number) => `VERSION ${i + 1}:\n${o}`).join('\n\n'),
    'Answer as JSON: subject (short, human), body, why (3 short bullet points as ONE string, what you changed and why).',
  ].filter(Boolean).join('\n\n'), { type: 'OBJECT', properties: { subject: { type: 'STRING' }, body: { type: 'STRING' }, why: { type: 'STRING' } }, required: ['subject', 'body'] });
  if (!j) return res.status(503).json({ error: aiFailureMessage('The AI could not write it just now. Try again in a minute.') });
  res.json({ subject: String(j.subject ?? '').slice(0, 200), body: String(j.body ?? '').slice(0, 4000), why: String(j.why ?? '') });
});

// the model filled with a real customer (or a sample), and the mail safety check on it
router.post('/preview', (req: AuthedRequest, res) => {
  const subject = String(req.body?.subject ?? ''), body = String(req.body?.body ?? '');
  const id = parseInt(String(req.body?.cardId ?? ''), 10);
  const card = id ? cardModel.findById(id) : null;
  const sample = card ?? ({ id: 0, company: 'Example Furniture Ltd', name: 'Maria Garcia', country: 'Spain', language: 'en' } as never);
  const f = fillModel({ subject, body, rules: '' }, sample, req.user!.display_name || req.user!.username);
  res.json({ ...f, problems: mailProblems({ subject: f.subject, body: f.body, kind: 'introduction' }) });
});

export default router;
