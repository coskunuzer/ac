-- Sales intelligence (admin and the people an admin switched "Sales intelligence" on for).
-- Light by design: the SAP sales list is NOT kept line by line. It is kept as a summary (a month per customer per colour for the last ~3 years,
-- a year per customer per colour before that), and the summary of the old years is loaded once from a file that ships with the CRM.
-- After that only the new months are uploaded.

CREATE TABLE IF NOT EXISTS intel_cust (
  code TEXT PRIMARY KEY, name TEXT, region TEXT, city TEXT, rep TEXT, first_date TEXT, last_date TEXT
);
CREATE TABLE IF NOT EXISTS intel_mat (
  code TEXT PRIMARY KEY, descr TEXT, grp TEXT, typ TEXT, fin TEXT, first_date TEXT, last_date TEXT
);
-- period is YYYY-MM for the last ~3 years and YYYY-00 (the whole year) before; thickness and width are 0 in the yearly rows
CREATE TABLE IF NOT EXISTS intel_fact (
  period TEXT NOT NULL, customer TEXT NOT NULL, material TEXT NOT NULL,
  doc_type TEXT NOT NULL,           -- S = sale, R = return
  reason TEXT NOT NULL DEFAULT '',  -- the reason of a return
  thickness REAL NOT NULL DEFAULT 0, width REAL NOT NULL DEFAULT 0,
  eur REAL NOT NULL DEFAULT 0, meters REAL NOT NULL DEFAULT 0, m2 REAL NOT NULL DEFAULT 0, kg REAL NOT NULL DEFAULT 0,
  PRIMARY KEY (period, customer, material, doc_type, reason, thickness, width)
) WITHOUT ROWID;
CREATE INDEX IF NOT EXISTS idx_intel_fact_cust ON intel_fact (customer);
CREATE INDEX IF NOT EXISTS idx_intel_fact_mat ON intel_fact (material);
-- every month, small: revenue by month, channel (0 export, 1 domestic, 2 other; +10 for a TECE group company) and product group
CREATE TABLE IF NOT EXISTS intel_month (
  ym TEXT NOT NULL, ch INTEGER NOT NULL, grp TEXT NOT NULL, eur REAL NOT NULL DEFAULT 0, m2 REAL NOT NULL DEFAULT 0, meters REAL NOT NULL DEFAULT 0,
  PRIMARY KEY (ym, ch, grp)
) WITHOUT ROWID;
-- thickness and width of what was sold (sales only)
CREATE TABLE IF NOT EXISTS intel_spec (
  period TEXT NOT NULL, thickness REAL NOT NULL, width REAL NOT NULL, grp TEXT NOT NULL, eur REAL NOT NULL DEFAULT 0, meters REAL NOT NULL DEFAULT 0,
  PRIMARY KEY (period, thickness, width, grp)
) WITHOUT ROWID;
-- the days a customer was invoiced and for how much (how often each one orders)
CREATE TABLE IF NOT EXISTS intel_events (
  customer TEXT NOT NULL, d TEXT NOT NULL, eur REAL NOT NULL DEFAULT 0, PRIMARY KEY (customer, d)
) WITHOUT ROWID;

-- edge band stock, one row per lot; replaced by every upload
CREATE TABLE IF NOT EXISTS intel_stock (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  grp TEXT, grp_name TEXT, material TEXT NOT NULL, description TEXT,
  thickness REAL, width REAL, roll_length REAL, qty REAL NOT NULL, m2 REAL,
  depot TEXT, customer TEXT, customer_name TEXT, sales_doc TEXT, item TEXT, received TEXT, form TEXT
);
CREATE INDEX IF NOT EXISTS idx_intel_stock_mat ON intel_stock (material);

-- the kartela: our code, the board producer's code, producer, availability, surface; replaced by every upload
CREATE TABLE IF NOT EXISTS intel_kartela (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  list_name TEXT, section TEXT, no INTEGER, code TEXT NOT NULL, match_code TEXT, producer TEXT, availability TEXT, surface TEXT
);
CREATE INDEX IF NOT EXISTS idx_intel_kartela_code ON intel_kartela (code);
CREATE TABLE IF NOT EXISTS intel_surface (code TEXT PRIMARY KEY, name TEXT);

-- the finished analysis, rebuilt after an upload (JSON)
CREATE TABLE IF NOT EXISTS intel_cache (
  key TEXT PRIMARY KEY, body TEXT NOT NULL, built_at TEXT NOT NULL DEFAULT (datetime('now'))
);
-- append-only: who loaded or uploaded what
CREATE TABLE IF NOT EXISTS intel_uploads (
  id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, file_name TEXT, rows INTEGER, added INTEGER, note TEXT, by_user INTEGER, at TEXT NOT NULL DEFAULT (datetime('now'))
);
-- the report sent to the general manager: append-only
CREATE TABLE IF NOT EXISTS intel_reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT, sent_to TEXT NOT NULL, subject TEXT, by_user INTEGER, ok INTEGER NOT NULL DEFAULT 1, note TEXT, at TEXT NOT NULL DEFAULT (datetime('now'))
);
