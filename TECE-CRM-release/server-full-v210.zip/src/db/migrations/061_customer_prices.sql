-- The prices of an OLD customer, learned from the SAP proformas that were made for them: the same product keeps the same price on the next proforma.
-- Only for the customer they were uploaded for. New customers (and everybody without uploaded proformas) are priced by the offer system / price list as always.
CREATE TABLE IF NOT EXISTS customer_price_docs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  card_id INTEGER NOT NULL REFERENCES cards(id) ON DELETE CASCADE,
  proforma_no TEXT NOT NULL,
  doc_date TEXT,
  currency TEXT NOT NULL DEFAULT 'EUR',
  adjust_pct REAL NOT NULL DEFAULT 0,       -- the "General Discount / Increase" of that proforma, in % of the goods
  customer_name TEXT,
  file_name TEXT,
  lines_json TEXT NOT NULL DEFAULT '[]',    -- what was ordered (to start the next order from it)
  created_by INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (card_id, proforma_no)
);
CREATE TABLE IF NOT EXISTS customer_prices (
  card_id INTEGER NOT NULL REFERENCES cards(id) ON DELETE CASCADE,
  sap TEXT NOT NULL,                        -- the SAP code of the product (e.g. 17316.012)
  currency TEXT NOT NULL,
  price_m2 REAL NOT NULL,
  description TEXT,
  doc_id INTEGER,
  doc_date TEXT,
  PRIMARY KEY (card_id, sap, currency)
);
