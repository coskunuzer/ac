import { Router } from 'express';
import { requireAuth, requireAdmin, type AuthedRequest } from '../middleware/auth';
import { DARE_LEVELS, POINT_TYPES, challengeFor, gameFor, gameSettings, markCelebrated, saveGameSettings, takeDare, type Level } from '../services/gamify';

const router = Router();
router.use(requireAuth);

// My points, my level, the three challenges of today, the week ranking, my badges, and the celebration when I was the most active yesterday.
router.get('/me', (req: AuthedRequest, res) => {
  res.json(gameFor(req.user!.id));
});

// The challenge of today: my points against my goal, my best day, yesterday at this hour, the colleague just ahead - and the dare I took.
router.get('/challenge', (req: AuthedRequest, res) => {
  try { res.json(challengeFor(req.user!.id)); } catch (e) { console.error('challenge', e); res.status(500).json({ error: 'Could not work out the challenge' }); }
});
router.post('/dare', (req: AuthedRequest, res) => {
  const level = DARE_LEVELS.find((l) => l === req.body?.level);
  if (!level) return res.status(400).json({ error: 'Choose a dare.' });
  try { res.json(takeDare(req.user!.id, level)); } catch (e) { res.status(400).json({ error: (e as Error).message }); }
});

// The celebration was seen: it does not come again for that day.
router.post('/celebrated', (req: AuthedRequest, res) => {
  const level = (['daily', 'weekly', 'monthly'] as const).find((l) => l === req.body?.level) ?? 'daily';
  markCelebrated(req.user!.id, level as Level, typeof req.body?.key === 'string' ? req.body.key.slice(0, 10) : undefined);
  res.json({ ok: true });
});

// ---- the admin: what each thing is worth, the daily goal, and the message from the management ----
router.get('/settings', requireAdmin, (_req, res) => {
  res.json({ ...gameSettings(), types: POINT_TYPES });
});

router.put('/settings', requireAdmin, (req, res) => {
  const b = req.body ?? {};
  res.json({ ...saveGameSettings({ weights: b.weights, goalDay: b.goalDay, capDay: b.capDay, celebrateMin: b.celebrateMin, message: b.message, messageWeekly: b.messageWeekly, messageMonthly: b.messageMonthly }), types: POINT_TYPES });
});

export default router;
