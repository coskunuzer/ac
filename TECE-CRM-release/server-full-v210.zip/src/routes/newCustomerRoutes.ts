import { Router } from 'express';
import { db } from '../db/connection';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { visibilitySql } from '../services/visibility';

// "New customers for you": the customers that appeared in this person's own list since they last looked (strict visibility, as everywhere).
const router = Router();
router.use(requireAuth);

router.get('/', (req: AuthedRequest, res) => {
  const u = req.user!;
  if (u.role === 'admin' || u.area) return res.json({ count: 0, rows: [], since: null });
  const seen = db.prepare("SELECT at FROM user_seen WHERE user_id = ? AND key = 'new-customers'").get(u.id) as { at: string } | undefined;
  const since = seen?.at ?? new Date(Date.now() - 7 * 86400000).toISOString().slice(0, 19).replace('T', ' ');
  const params: Record<string, string | number> = { since, me: u.id };
  const vis = visibilitySql(u, params);
  const where = `created_at > @since AND uploaded_by != @me ${vis ? `AND ${vis}` : ''}`;
  const count = (db.prepare(`SELECT COUNT(*) AS n FROM cards WHERE ${where}`).get(params) as { n: number }).n;
  const rows = db.prepare(`SELECT id, company, country, city, created_at FROM cards WHERE ${where} ORDER BY id DESC LIMIT 8`).all(params);
  res.json({ count, rows, since });
});

router.post('/seen', (req: AuthedRequest, res) => {
  db.prepare("INSERT INTO user_seen (user_id, key, at) VALUES (?, 'new-customers', datetime('now')) ON CONFLICT(user_id, key) DO UPDATE SET at = excluded.at").run(req.user!.id);
  res.json({ ok: true });
});

export default router;
