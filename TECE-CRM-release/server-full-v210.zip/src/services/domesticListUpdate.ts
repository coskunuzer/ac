import * as XLSX from 'xlsx';
import { db } from '../db/connection';
import { cardModel, type CardRow } from '../models/cardModel';
import { cityModel } from '../models/cityModel';
import { userModel } from '../models/userModel';
import { placeKey, resolveCity } from '../data/turkeyPlaces';
import { companyKey } from './companyKey';
import { matchPerson } from './countryAssignment';
import { addJunkRow, inJunk, moveToJunk } from './junk';
import { refreshOwnerOverride } from './ownership';
import type { ExtractedCardFields, FieldStatusMap } from '../schema/cardSchema';

// The updated domestic customer list (Excel with the sheets Existing, Potential, Removed - No Sales, Field Visits, Sales Score Detail):
//  - Existing: customers that bought in the last 22 months, with their sales score and tier. Found by SAP number (or company name) and
//    updated, or added. Their sales figures and the salesperson come from "Sales Score Detail".
//  - Potential: companies to win. Added or updated; a customer who already buys is never turned back into a lead.
//  - Removed - No Sales: existing customers without a sale. They are taken out of the lists and put in the junk folder (admin).
//  - Field Visits: the notes of the visits, put on the matching customer as visit notes (they do not count as work done today).
// Nothing is written twice: the file can be loaded again.

const clean = (v: unknown) => String(v ?? '').replace(/\s+/g, ' ').trim();
const emailsOf = (raw: string) => [...new Set(raw.split(/[;,|\s]+/).filter((e) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)).map((e) => e.toLowerCase()))];
const serialToDate = (n: unknown) => (typeof n === 'number' && n > 20000 ? new Date(Math.round((n - 25569) * 86400000)).toISOString().slice(0, 10) : null);
const VISIT_DAY = '2026-10-27 08:00:00';

type Row = Record<string, unknown>;

// The sheet without its endless empty rows (the Potential sheet is a million rows long).
function rowsOf(ws: XLSX.WorkSheet | undefined): Row[] {
  if (!ws || !ws['!ref']) return [];
  let last = 0;
  for (const k of Object.keys(ws)) {
    if (k[0] === '!') continue;
    const cell = ws[k] as XLSX.CellObject;
    if (cell && cell.v !== '' && cell.v !== undefined && cell.v !== null) last = Math.max(last, XLSX.utils.decode_cell(k).r);
  }
  const range = XLSX.utils.decode_range(ws['!ref']);
  range.e.r = Math.min(range.e.r, last);
  return XLSX.utils.sheet_to_json<Row>({ ...ws, '!ref': XLSX.utils.encode_range(range) } as XLSX.WorkSheet, { defval: '' });
}
const sheetNamed = (wb: XLSX.WorkBook, part: string) => wb.Sheets[wb.SheetNames.find((n) => n.toLowerCase().includes(part)) ?? ''];

export interface DomesticUpdateReport {
  dryRun: boolean;
  existing: { rows: number; created: number; updated: number };
  potential: { rows: number; created: number; updated: number; keptAsCustomer: number };
  removed: { rows: number; movedToJunk: number; addedToJunk: number; alreadyInJunk: number; skippedBecauseCustomer: number };
  visits: { rows: number; added: number; alreadyThere: number; notMatched: number };
  withPerson: number;
  unknownPlaces: string[];
  notMatched: string[];
}

export function updateDomesticList(opts: { buffer: Buffer; exhibitionId: number; userId: number; dryRun: boolean }): DomesticUpdateReport {
  const wb = XLSX.read(opts.buffer, { type: 'buffer', cellStyles: false, cellDates: false });
  const existingRows = rowsOf(sheetNamed(wb, 'existing'));
  const potentialRows = rowsOf(sheetNamed(wb, 'potential'));
  const removedRows = rowsOf(sheetNamed(wb, 'removed'));
  const visitRows = rowsOf(sheetNamed(wb, 'field'));
  const salesRows = rowsOf(sheetNamed(wb, 'sales score'));
  if (!existingRows.length && !potentialRows.length) throw new Error('This does not look like the domestic list: it needs the sheets "Existing" and "Potential".');

  const report: DomesticUpdateReport = {
    dryRun: opts.dryRun,
    existing: { rows: existingRows.length, created: 0, updated: 0 },
    potential: { rows: potentialRows.length, created: 0, updated: 0, keptAsCustomer: 0 },
    removed: { rows: removedRows.length, movedToJunk: 0, addedToJunk: 0, alreadyInJunk: 0, skippedBecauseCustomer: 0 },
    visits: { rows: visitRows.length, added: 0, alreadyThere: 0, notMatched: 0 },
    withPerson: 0, unknownPlaces: [], notMatched: [],
  };

  const staff = userModel.listActive();
  const sales = new Map<string, Row>();
  for (const r of salesRows) sales.set(clean(r['SAP Number']), r);
  const unknown = new Map<string, number>();
  const ownerCache = new Map<string, string | null>();
  const cityOwner = (city: string | null) => {
    if (!city) return null;
    const k = placeKey(city);
    if (!ownerCache.has(k)) ownerCache.set(k, cityModel.findByCity(city)?.responsible ?? null);
    return ownerCache.get(k)!;
  };

  const bySap = (sap: string): CardRow | undefined =>
    sap ? (db.prepare("SELECT * FROM cards WHERE market = 'domestic' AND (sap = ? OR json_extract(lead_info, '$.sap') = ?)").get(sap, sap) as CardRow | undefined) : undefined;
  const byKey = (name: string, city: string | null): CardRow | undefined => {
    const key = companyKey(name);
    if (!key) return undefined;
    const rows = db.prepare("SELECT * FROM cards WHERE market = 'domestic' AND company_key = ?").all(key) as unknown as CardRow[];
    return rows.find((c) => city && c.city && placeKey(c.city) === placeKey(city)) ?? rows[0];
  };
  const originalNames = new Map<string, number>();
  // (a check run: what would be created, so the visits that belong to those are not counted as lost)
  const planned = new Set<string>();

  const FOUND: FieldStatusMap = { name: 'found', company: 'found', address: 'found', country: 'found', tel: 'found', email: 'found', position: 'found', interestedIn: 'found', workArea: 'found', date: 'found', person: 'found', rate: 'found', notes: 'found' };

  const leadInfoOf = (r: Row, sap: string): Record<string, unknown> => {
    const s = sales.get(sap);
    return {
      sap: sap || null,
      tier: clean(r.Tier) || null,
      score: Number(r.Score) || null,
      businessType: clean(r['Business Type']) || null,
      salesAngle: clean(r['Sales Angle']) || null,
      suppliers: clean(r['Known Suppliers']).split('|').map((x) => x.trim()).filter(Boolean),
      tradeValue: Number(r['Trade Value (USD)']) || null,
      sources: clean(r['Data Sources']).split('|').map((x) => x.trim()).filter(Boolean),
      webCheck: clean(r['Web Check']) || null,
      source: 'domestic list 2026-10',
      ...(s ? {
        sales: {
          netEur: Number(s['Net Satış € (Oca25–Eki26)']) || 0, last12: Number(s['Son 12 Ay Net €']) || 0, returns: Number(s['İade €']) || 0,
          invoices: Number(s['Fatura Sayısı']) || 0, activeMonths: Number(s['Aktif Ay']) || 0, firstInvoice: serialToDate(s['İlk Fatura']), lastInvoice: serialToDate(s['Son Fatura']),
          daysSinceLast: Number(s['Son Faturadan Gün']) || 0, salesperson: clean(s.Plasiyer) || null, region: clean(s['Bölge']) || null,
        },
      } : {}),
    };
  };

  const upsert = (r: Row, kind: 'existing' | 'potential') => {
    const company = clean(r.Company);
    if (!company) return;
    const sap = clean(r['SAP Number']);
    const rawCity = clean(r.City);
    const place = resolveCity(rawCity);
    if (rawCity && !place.known) unknown.set(rawCity, (unknown.get(rawCity) ?? 0) + 1);
    const city = place.city;
    const orig = clean(r['Original Company Name']);
    const card = bySap(sap) ?? byKey(company, city) ?? (orig ? byKey(orig, city) : undefined);
    const emails = emailsOf(clean(r.Email));
    const phone = clean(r.Phone);
    const website = clean(r.Website);
    const info = leadInfoOf(r, sap);
    const sp = clean(sales.get(sap)?.Plasiyer);
    const matched = sp ? matchPerson(sp, staff).name : null;
    const person = matched ?? cityOwner(city);

    if (card) {
      const rep = kind === 'existing' ? report.existing : report.potential;
      rep.updated += 1;
      if (kind === 'potential' && card.stage === 'customer') report.potential.keptAsCustomer += 1;
      originalNames.set(companyKey(orig || company) ?? '', card.id);
      if (opts.dryRun) return;
      const stage = kind === 'existing' ? 'customer' : card.stage;
      db.prepare(
        `UPDATE cards SET sap = COALESCE(NULLIF(?, ''), sap), stage = ?, lead_info = ?, tel = COALESCE(NULLIF(TRIM(tel), ''), ?), email = COALESCE(NULLIF(TRIM(email), ''), ?), website = COALESCE(NULLIF(TRIM(website), ''), ?),
           person = COALESCE(NULLIF(TRIM(person), ''), ?), city = COALESCE(city, ?), contact_group = CASE WHEN ? = 'existing' THEN 'existing' ELSE contact_group END, updated_at = datetime('now') WHERE id = ?`
      ).run(sap, stage, JSON.stringify(info), phone || null, emails.join(', ') || null, website || null, person, city, kind, card.id);
      refreshOwnerOverride(card.id);
      if (person) report.withPerson += 1;
      return;
    }
    (kind === 'existing' ? report.existing : report.potential).created += 1;
    if (person) report.withPerson += 1;
    planned.add(companyKey(company) ?? '');
    if (orig) planned.add(companyKey(orig) ?? '');
    if (opts.dryRun) return;
    const fields: ExtractedCardFields = {
      name: clean(r['Contact Person']) || null, company, address: null, country: 'Turkey', tel: phone || null, email: emails.join(', ') || null, position: null,
      interestedIn: null, workArea: clean(r['Business Type']) || null, date: null, person, rate: null, notes: null,
    };
    const created = cardModel.createFromExtraction({
      exhibitionId: opts.exhibitionId, uploadedBy: opts.userId, imagePath: '', fields, fieldStatus: FOUND, extractionModel: 'domestic-list', status: 'confirmed',
      badgeId: `dom:${sap || companyKey(company) || company}|${city ? placeKey(city) : ''}`, stage: kind === 'existing' ? 'customer' : 'lead', website: website || null,
      market: 'domestic', city, leadInfo: info, contactGroup: kind === 'existing' ? 'existing' : null, sap: sap || null,
    });
    originalNames.set(companyKey(orig || company) ?? '', created.id);
    refreshOwnerOverride(created.id);
  };

  const existingSaps = new Set(existingRows.map((r) => clean(r['SAP Number'])).filter(Boolean));
  if (!opts.dryRun) db.exec('BEGIN');
  try {
    for (const r of existingRows) upsert(r, 'existing');
    for (const r of potentialRows) upsert(r, 'potential');

    // customers without a sale go to the junk folder
    for (const r of removedRows) {
      const sap = clean(r['SAP Number']);
      const company = clean(r.Company);
      if (!company) continue;
      if (sap && existingSaps.has(sap)) { report.removed.skippedBecauseCustomer += 1; continue; }
      if (inJunk(sap || null, company)) { report.removed.alreadyInJunk += 1; continue; }
      // by SAP number; by name only when that is an existing customer (a lead of the Potential sheet with a similar name is not this customer)
      const byName = byKey(company, resolveCity(clean(r.City)).city);
      const card = bySap(sap) ?? (byName && byName.stage === 'customer' ? byName : undefined);
      const reason = clean(r['Removal Reason']) || 'No sale';
      if (card) {
        report.removed.movedToJunk += 1;
        if (!opts.dryRun) moveToJunk(card, reason, opts.userId, true);
      } else {
        report.removed.addedToJunk += 1;
        if (!opts.dryRun) addJunkRow({ company, city: clean(r.City) || null, sap: sap || null, reason, data: { email: clean(r.Email), phone: clean(r.Phone), website: clean(r.Website), reason, row: r } }, opts.userId);
      }
    }

    // the notes of the field visits
    for (const r of visitRows) {
      const company = clean(r['Firma (ziyaret notu)']);
      const note = clean(r['Ziyaret Notu']);
      if (!company || !note) continue;
      const matchedName = clean(r['Eşleşen Kayıt']);
      const city = resolveCity(clean(r['İl / İlçe'])).city;
      const key = companyKey(company) ?? '';
      const found = (originalNames.has(key) ? cardModel.findById(originalNames.get(key)!) : undefined) ?? byKey(company, city) ?? (matchedName ? byKey(matchedName, city) : undefined);
      if (!found && opts.dryRun && planned.has(key)) { report.visits.added += 1; continue; }
      if (!found) {
        report.visits.notMatched += 1;
        if (report.notMatched.length < 15) report.notMatched.push(company);
        continue;
      }
      const text = `[${clean(r['Ziyaret Sayfası'])}${clean(r['İl / İlçe']) ? ` - ${clean(r['İl / İlçe'])}` : ''}] ${note}`.slice(0, 2000);
      const there = db.prepare("SELECT 1 FROM activities WHERE card_id = ? AND type = 'visit' AND text = ?").get(found.id, text);
      if (there) { report.visits.alreadyThere += 1; continue; }
      report.visits.added += 1;
      if (!opts.dryRun) db.prepare("INSERT INTO activities (user_id, card_id, type, text, photos, created_at, imported) VALUES (?, ?, 'visit', ?, '[]', ?, 1)").run(opts.userId, found.id, text, VISIT_DAY);
    }
    if (!opts.dryRun) db.exec('COMMIT');
  } catch (err) {
    if (!opts.dryRun) db.exec('ROLLBACK');
    throw err;
  }
  report.unknownPlaces = [...unknown.entries()].sort((a, b) => b[1] - a[1]).slice(0, 15).map(([c, n]) => `${c} (${n})`);
  return report;
}
