-- The redesign: one ranked queue (Today), meetings as records, follow-up state.

-- What a person did with a row of the queue: snoozed it, said it is not theirs, or finished it.
-- The current state is one row per person and row key; every action is also written to queue_log (append-only, never changed).
CREATE TABLE IF NOT EXISTS queue_state (
  user_id INTEGER NOT NULL,
  key TEXT NOT NULL,                 -- c:<card id> or s:<sap number>
  kind TEXT NOT NULL CHECK (kind IN ('snooze', 'not_mine', 'done')),
  until TEXT,                        -- snooze: the day it comes back (YYYY-MM-DD)
  label TEXT,                        -- the customer name, so a list of snoozed rows can be shown
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, key)
);

CREATE TABLE IF NOT EXISTS queue_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  key TEXT NOT NULL,
  action TEXT NOT NULL,              -- snooze | not_mine | done | undo
  until TEXT,
  label TEXT,
  at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_queue_log_user ON queue_log (user_id, at);

-- A meeting is a record: a date, the guests and a link, not a line of note text.
CREATE TABLE IF NOT EXISTS meetings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  card_id INTEGER REFERENCES cards(id) ON DELETE SET NULL,
  user_id INTEGER NOT NULL,          -- who keeps the meeting
  title TEXT NOT NULL,
  starts_at TEXT NOT NULL,           -- UTC, 'YYYY-MM-DD HH:MM'
  ends_at TEXT,
  tz TEXT,                           -- the time zone the guest sees (Europe/Berlin): shown next to the Istanbul time
  guests TEXT,                       -- JSON: [{name, email}]
  link TEXT,                         -- video call link
  notes TEXT,
  done_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_meetings_user ON meetings (user_id, starts_at);
CREATE INDEX IF NOT EXISTS idx_meetings_card ON meetings (card_id, starts_at);

-- The daily goal is counted in points (a call is worth a few, a visit more).
INSERT OR IGNORE INTO app_settings (key, value) VALUES ('goal_points_day', '20');
