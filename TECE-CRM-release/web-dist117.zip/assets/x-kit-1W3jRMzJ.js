// Shared pieces of the screens added in web 116 (fairs, fair focus, challenge, budgets, trips).
// Written by hand against the built app: React, the API client, the router and the translator come from the existing chunks.
import { l as toESM, n as ApiError, o as reactModule, r as api } from "./jsx-runtime-4t2dS8Ja.js";
import { c as useLocation, d as useSearchParams, l as useNavigate, n as Link, u as useParams } from "./chunk-BV7QT456-vB6tpXuA.js";
import { n as useAuth } from "./AuthContext-GcOxra5t.js";
import { r as useTOrig, i as curLoc } from "./LanguageContext-xagkSN7f.js";
import { b as Icon, n as fmtDate, u as logActivity } from "./index-YGSTWzBt.js";

const React = toESM(reactModule(), 1);
const h = React.createElement;
const { useState, useEffect, useMemo, useRef, useCallback, Fragment } = React;

const cx = (...a) => a.filter(Boolean).join(" ");
// the translator of the screen that rendered last: server messages (English) go through it, so a Turkish user reads them in Turkish
let lastT = null;
const useT = () => { const t = useTOrig(); lastT = t; return t; };
const errText = (e, fallback) => (e instanceof ApiError && e.message ? (lastT ? lastT(e.message) : e.message) : fallback);
// numbers, percentages and dates in the language of the person ("tr-TR": 4.345 · %87 · 3 Kas; "en-GB": 4,345 · 87% · 3 Nov)
const loc = () => { try { return curLoc() || "en-GB"; } catch { return "en-GB"; } };
const isTr = () => loc().startsWith("tr");
const num = (v, d = 0) => (v == null || !Number.isFinite(Number(v)) ? "–" : Number(v).toLocaleString(loc(), { minimumFractionDigits: d, maximumFractionDigits: d }));
const pctTxt = (n) => (n == null || n === "–" ? "–" : isTr() ? "%" + n : n + "%");
const eur = (v, opts) => {
  if (v == null || !Number.isFinite(v)) return "–";
  const a = Math.abs(v);
  const s = opts && opts.short && a >= 10000 ? (a >= 1e6 ? (a / 1e6).toLocaleString(loc(), { maximumFractionDigits: 2 }) + "M" : Math.round(a / 1000) + "k") : Math.round(a).toLocaleString(loc());
  return (v < 0 ? "-" : "") + "€" + s;
};
const pct = (a, b) => (b > 0 ? Math.round((a / b) * 100) : 0);
const todayIso = () => new Date().toLocaleDateString("en-CA", { timeZone: "Europe/Istanbul" });
const dayDiff = (a, b) => Math.round((Date.parse(b + "T12:00:00Z") - Date.parse(a + "T12:00:00Z")) / 864e5);
const shortDate = (iso) => (iso ? new Intl.DateTimeFormat(loc(), { day: "numeric", month: "short", timeZone: "UTC" }).format(new Date(iso + "T12:00:00Z")) : "");
const dateRange = (a, b) => {
  if (!a) return "";
  if (!b || b === a) return shortDate(a) + " " + a.slice(0, 4);
  return a.slice(0, 7) === b.slice(0, 7) ? parseInt(a.slice(8), 10) + "–" + shortDate(b) + " " + b.slice(0, 4) : shortDate(a) + " – " + shortDate(b) + " " + b.slice(0, 4);
};
// "3 days ago", from a UTC timestamp of the database ("2026-11-20 15:44:00")
const ago = (stamp, t) => {
  if (!stamp) return "";
  const ms = Date.now() - Date.parse(stamp.replace(" ", "T") + (/Z$/.test(stamp) ? "" : "Z"));
  const d = Math.floor(ms / 864e5);
  if (d <= 0) return t("today");
  if (d === 1) return t("yesterday");
  if (d < 60) return t("{n} days ago", { n: d });
  return t("{n} months ago", { n: Math.round(d / 30) });
};

// a ring that fills (the share of something that is done)
function Ring({ value, max, size = 64, stroke = 6, tone, children, label }) {
  const p = max > 0 ? Math.max(0, Math.min(1, value / max)) : 0;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  return h(
    "span",
    { className: cx("xk-ring", tone && "xk-ring--" + tone), style: { width: size, height: size }, role: "img", "aria-label": label || pctTxt(Math.round(p * 100)) },
    h(
      "svg",
      { viewBox: `0 0 ${size} ${size}`, width: size, height: size },
      h("circle", { cx: size / 2, cy: size / 2, r, className: "xk-ring-bg", strokeWidth: stroke }),
      h("circle", { cx: size / 2, cy: size / 2, r, className: "xk-ring-fg", strokeWidth: stroke, strokeDasharray: `${c * p} ${c}`, transform: `rotate(-90 ${size / 2} ${size / 2})` }),
    ),
    h("b", null, children != null ? children : pctTxt(Math.round(p * 100))),
  );
}

// a thin bar: how far, with an optional second mark
function Bar({ value, max, tone, mark, label }) {
  const p = max > 0 ? Math.max(0, Math.min(100, (value / max) * 100)) : 0;
  return h(
    "span",
    { className: cx("xk-bar", tone && "xk-bar--" + tone), role: "progressbar", "aria-valuemin": 0, "aria-valuemax": 100, "aria-valuenow": Math.round(p), "aria-label": label },
    h("span", { className: "xk-bar-fill", style: { width: p + "%" } }),
    mark != null && max > 0 ? h("span", { className: "xk-bar-mark", style: { left: Math.max(0, Math.min(100, (mark / max) * 100)) + "%" } }) : null,
  );
}

const Chip = ({ tone, icon, children, title }) => h("span", { className: cx("xk-chip", tone && "xk-chip--" + tone), title }, icon ? h(Icon, { n: icon, size: 16 }) : null, children);
const Stat = ({ n, label, tone, sub }) => h("div", { className: cx("xk-stat", tone && "xk-stat--" + tone) }, h("b", null, n), h("span", null, label), sub ? h("small", null, sub) : null);
const Skel = ({ height = 80 }) => h("span", { className: "tx-skel", style: { height, display: "block" } });
const Empty = ({ icon = "info", title, children }) => h("div", { className: "xk-empty" }, h(Icon, { n: icon, size: 32 }), h("b", null, title), children ? h("p", null, children) : null);

// values the server wrote in English style ("€7.1M", "€4,345", "-22% / -40%") shown in the person's style
const locVars = (v) => {
  if (!v || !isTr()) return v || {};
  const o = {};
  for (const k in v) {
    const x = v[k];
    o[k] = typeof x !== "string" ? x : x
      .replace(/€(\d+)\.(\d)([Mk])/g, "€$1,$2$3")
      .replace(/€(\d{1,3}(?:,\d{3})+)\b/g, (m, n) => "€" + n.replace(/,/g, "."))
      .replace(/([+\-−]?)(\d+(?:[.,]\d+)?)%/g, (m, sg, n) => sg + "%" + n.replace(".", ","));
  }
  return o;
};
// a Turkish text built from a template "%{g}" with a negative number reads "%-24": the sign goes before the % sign ("-%24")
const trPct = (s) => (typeof s === "string" && isTr() ? s.replace(/%([-−])(?=\d)/g, "$1%") : s);
// one colour rule for the price index everywhere: under 90 = low (red), 105 and up = high (green), between = neutral
const idxTone = (i) => (i == null ? "" : i < 90 ? "bad" : i >= 105 ? "good" : "");
// the translator with a context: "team|Overdue" is tried first (a word the old dictionary already has with another meaning), then "Overdue"
function useTx(ctx) {
  const t = useT();
  return useMemo(() => (k, v) => {
    const ck = ctx + "|" + k;
    const r = t(ck);
    if (typeof r === "string" && r !== ck) return v ? r.replace(/\{(\w+)\}/g, (m, n) => (n in v ? String(v[n]) : m)) : r;
    return t(k, v);
  }, [t]);
}

// load something from the API: [data, error, reload, setData]
function useApi(path, deps = []) {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [n, setN] = useState(0);
  useEffect(() => {
    if (!path) return undefined;
    let alive = true;
    api
      .get(path)
      .then((d) => {
        if (alive) {
          setData(d);
          setError(null);
        }
      })
      .catch((e) => alive && setError(errText(e, "Could not load")));
    return () => {
      alive = false;
    };
  }, [path, n, ...deps]);
  const reload = useCallback(() => setN((x) => x + 1), []);
  return [data, error, reload, setData];
}

// a small message at the bottom of the screen that goes away by itself
function toast(text, tone, action) {
  let box = document.getElementById("xk-toasts");
  if (!box) {
    box = document.createElement("div");
    box.id = "xk-toasts";
    box.setAttribute("role", "status");
    box.setAttribute("aria-live", "polite");
    document.body.appendChild(box);
  }
  const el = document.createElement("div");
  el.className = "xk-toast" + (tone ? " xk-toast--" + tone : "");
  el.textContent = text;
  // an optional button in the message ("Undo"): { label, run }
  if (action && action.label) {
    const b = document.createElement("button");
    b.type = "button";
    b.textContent = action.label;
    b.onclick = () => { el.remove(); action.run(); };
    el.appendChild(b);
  }
  box.appendChild(el);
  const stay = action ? 6000 : 2600;
  setTimeout(() => el.classList.add("out"), stay);
  setTimeout(() => el.remove(), stay + 500);
}

// a burst of confetti from a point (nothing when the person asked for less motion)
function burst(x, y, n = 26) {
  if (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const colors = ["#8b1931", "#36589d", "#b17834", "#1d6b4f", "#c8a27a"];
  for (let i = 0; i < n; i += 1) {
    const p = document.createElement("i");
    p.className = "xk-confetti";
    const a = Math.random() * Math.PI * 2;
    const d = 60 + Math.random() * 120;
    p.style.cssText = `left:${x}px;top:${y}px;background:${colors[i % colors.length]};--dx:${Math.cos(a) * d}px;--dy:${Math.sin(a) * d - 60}px;--rot:${Math.random() * 720 - 360}deg`;
    document.body.appendChild(p);
    setTimeout(() => p.remove(), 900);
  }
}

export { trPct, idxTone, loc, isTr, num, pctTxt, useTx, locVars, React, h, Fragment, useState, useEffect, useMemo, useRef, useCallback, api, ApiError, useLocation, useSearchParams, useNavigate, useParams, Link, useAuth, useT, Icon, fmtDate, logActivity, cx, errText, eur, pct, todayIso, dayDiff, shortDate, dateRange, ago, Ring, Bar, Chip, Stat, Skel, Empty, useApi, toast, burst };
