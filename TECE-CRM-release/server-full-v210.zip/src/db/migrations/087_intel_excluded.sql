-- SAP accounts that are not customers (a supplier that returns material, a mirror account...). An admin marks them in Sales intelligence;
-- they are left out of every sales number: the analysis, the GM report, the targets and the sales reports. Nothing is deleted: "Put back" undoes it.
CREATE TABLE IF NOT EXISTS intel_excluded (
  code TEXT PRIMARY KEY,
  reason TEXT NOT NULL DEFAULT '',
  by_user INTEGER,
  at TEXT NOT NULL DEFAULT (datetime('now'))
);
