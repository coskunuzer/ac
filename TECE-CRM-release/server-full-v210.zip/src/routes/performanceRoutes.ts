import { Router, type Response } from 'express';
import { salesReport } from '../services/salesReport';
import { renderSalesReportPdf } from '../services/salesReportPdf';
import multer from 'multer';
import ExcelJS from 'exceljs';
import { userModel } from '../models/userModel';
import { blockedReason } from '../services/aiGate';
import { gatherBrief, renderBriefPdf, sendBriefs } from '../services/dailyBrief';
import { companyKey } from '../services/companyKey';
import { healthOrdersMode } from '../services/pipeline';
import { missingContacts } from '../services/perfAnalytics';
import { createInCrm, missingInCrm, removeCustomer, restoreExcluded } from '../services/perfCrm';
import { db } from '../db/connection';
import { requireAuth, requireAdmin, type AuthedRequest } from '../middleware/auth';
import { addSwift, cancelSwift, findSwift, invoiceKey, waitingOf } from '../services/perfSwift';
import { openItemsOf } from '../services/perfAnalytics';
import { activeSnoozes, addAsk, clearSnooze, snooze } from '../services/shipDispatch';
import { cardModel } from '../models/cardModel';
import { settingsModel } from '../models/settingsModel';
import { useAi } from '../services/aiBudget';
import { aiFailureMessage } from '../services/aiGate';
import { buildSignature, styleFor } from '../services/signature';
import { sendThankYouEmail } from '../services/thankYouEmail';
import { splitEmails } from '../services/emailAddresses';
import { KINDS, ingest, resolveAliases, type UploadKind } from '../services/perfIngest';
import { HOLD_LIMIT, accountOfSap, accountsFor, allAccounts, allAccountSets, asksFor, bankTolerancePct, bankYearPct, canonicalReps, linkMap, overview, riskSettings, setsFor, teamSummary, termsDays, unresolvedSheets, usdPerEur, yearsOf, type Account } from '../services/perfAnalytics';
import { assessRisk, hasFreshRiskAi, riskInvoices, ruleRiskAnswer, savedRiskAi } from '../services/riskAi';
import { RULE_ADVICE } from '../services/paymentRisk';
import { forwardToStaff } from '../services/forwardMail';
import { bankTolerance, ledgerFor, setBankTolerance } from '../services/ledgerMatch';
import { ledgerSummaryHtml, renderLedgerPdf } from '../services/ledgerStatement';
import { audit } from '../services/audit';
import { pricingAnalysis } from '../services/pricingAnalysis';
import { buyingIntel } from '../services/buyingIntel';
import { buyingPdf, pricingPdf } from '../services/perfPdfs';
import { radar, clearRadarCache } from '../services/radar';
import { recipientsFor } from '../services/contactRoles';
import { lastSent, lastSentMap } from '../services/lastSent';
import { activityModel } from '../models/activityModel';
import { LANGS, OPERATIONS_EMAIL, diagnose, savedSuggestion, suggest, dispatchDraft, dispatchTableHtml, langOf, reactivationDraft, renderStatementPdf, statementDraft, statementTableHtml } from '../services/perfActions';

// The Performance page. Everybody who logs in sees their own customers (see scopeOf); only an admin uploads the SAP files, matches the
// ledger tabs, lifts a debt hold and changes the settings.

const router = Router();
router.use(requireAuth);

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 80 * 1024 * 1024, files: 1 } });
const viewerOf = (req: AuthedRequest) => ({ id: req.user!.id, role: req.user!.role, display_name: req.user!.display_name });
const isAdmin = (req: AuthedRequest) => req.user!.role === 'admin';
const fail = (res: Response, err: unknown, code = 500) => res.status(code).json({ error: (err as Error).message || 'Something went wrong' });

// ---- the page --------------------------------------------------------------------------------------------------------------------
// ---- the sales report: by country, team and employee, month / quarter / year; and the PDF of it -----------------------------------------
const reportOpts = (req: AuthedRequest) => ({
  year: parseInt(String(req.query.year ?? ''), 10) || undefined,
  period: (String(req.query.period ?? 'month') as 'month' | 'quarter' | 'year'),
  rep: typeof req.query.rep === 'string' && req.query.rep ? req.query.rep : null,
  cur: typeof req.query.cur === 'string' ? req.query.cur : null,
});
router.get('/sales-report', (req: AuthedRequest, res) => {
  try { res.json(salesReport(viewerOf(req), reportOpts(req))); } catch (err) { console.error('Sales report failed:', err); fail(res, err); }
});
router.get('/sales-report.pdf', async (req: AuthedRequest, res) => {
  try {
    const rep = salesReport(viewerOf(req), reportOpts(req));
    const lang = req.query.lang === 'en' ? 'en' : req.query.lang === 'tr' ? 'tr' : req.user!.ui_language === 'en' ? 'en' : 'tr';
    const pdf = await renderSalesReportPdf(rep, lang, rep.rep ?? (isAdmin(req) ? (lang === 'tr' ? 'Tüm ekip' : 'Whole team') : (req.user!.display_name || req.user!.username)));
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="TECE-sales-report-${rep.year}-${rep.period}.pdf"`);
    res.send(pdf);
  } catch (err) { console.error('Sales report PDF failed:', err); fail(res, err); }
});

// what the customers who keep their own prices pay against our standard price list, and what they buy
// how often each customer orders, who is late, whose volume is falling, what they could buy
// short per-viewer cache: the Home page asks for this on every load and the numbers only move when a report is uploaded
const heavyCache = new Map<string, { at: number; value: unknown }>();
const HEAVY_TTL_MS = 60_000;
function cached<T>(key: string, compute: () => T): T {
  const hit = heavyCache.get(key);
  if (hit && Date.now() - hit.at < HEAVY_TTL_MS) return hit.value as T;
  const value = compute();
  heavyCache.set(key, { at: Date.now(), value });
  if (heavyCache.size > 200) heavyCache.clear();
  return value;
}

router.get('/buying', (req: AuthedRequest, res) => {
  try { res.json(cached(`buying:${req.user!.id}:${req.user!.role}`, () => buyingIntel(req.user!))); } catch (err) { console.error('Buying intelligence failed:', err); fail(res, err); }
});

router.get('/pricing', (req: AuthedRequest, res) => {
  try { res.json(cached(`pricing:${req.user!.id}:${req.user!.role}`, () => pricingAnalysis(viewerOf(req)))); } catch (err) { console.error('Pricing analysis failed:', err); fail(res, err); }
});

// the same two analyses as printable PDFs (the filters of the screen are in the query)
const sendPdf = (res: Response, pdf: Buffer, name: string) => { res.setHeader('Content-Type', 'application/pdf'); res.setHeader('Content-Disposition', `inline; filename="${name}"`); res.send(pdf); };
router.get('/buying/pdf', async (req: AuthedRequest, res) => {
  try { sendPdf(res, await buyingPdf(req.user!, req.query), 'TECE-buying-rhythm.pdf'); } catch (err) { console.error('Buying PDF failed:', err); fail(res, err); }
});
router.get('/pricing/pdf', async (req: AuthedRequest, res) => {
  try { sendPdf(res, await pricingPdf(viewerOf(req), req.query), 'TECE-pricing.pdf'); } catch (err) { console.error('Pricing PDF failed:', err); fail(res, err); }
});

// "What changed since you were last here": the SAP files an admin uploaded lately, and where that leaves this person (shown as a pop-up when they come back)
const UPLOAD_LABEL: Record<string, string> = { ledger: 'Customer accounts (ledger)', backlog: 'Production backlog', blockers: 'Orders waiting for confirmation or advance payment', dispatch: 'Dispatch queue', sap: 'SAP customer list' };
router.get('/updates', (req: AuthedRequest, res) => {
  try {
    const raw = String(req.query.since ?? '');
    const since = /^\d{4}-\d{2}-\d{2}/.test(raw) ? raw.slice(0, 19).replace('T', ' ') : new Date(Date.now() - 3 * 86_400_000).toISOString().slice(0, 19).replace('T', ' ');
    const rows = db.prepare('SELECT id, kind, file_name, rows, added, note, by_user, at FROM perf_uploads WHERE at > ? ORDER BY id DESC LIMIT 20').all(since) as { id: number; kind: string; file_name: string | null; rows: number | null; added: number | null; note: string | null; by_user: number | null; at: string }[];
    // one line for each kind of file: the newest
    const seen = new Set<string>();
    const uploads = rows.filter((r) => (seen.has(r.kind) ? false : (seen.add(r.kind), true))).map((r) => ({ id: r.id, kind: r.kind, label: UPLOAD_LABEL[r.kind] ?? r.kind, file: r.file_name, rows: r.rows ?? 0, added: r.added ?? 0, note: r.note, by: r.by_user ? userModel.findById(r.by_user)?.display_name ?? null : null, at: r.at }));
    let snapshot: { payments: number; overdueByCurrency: Record<string, number>; late: number; orders: number } | null = null;
    if (uploads.length) {
      const r = radar(req.user!);
      const by: Record<string, number> = {};
      for (const p of r.payments) by[p.currency] = (by[p.currency] ?? 0) + p.overdue;
      snapshot = { payments: r.payments.length, overdueByCurrency: by, late: r.important.length, orders: r.newOrders.length };
    }
    res.json({ now: new Date().toISOString().slice(0, 19).replace('T', ' '), uploads, snapshot });
  } catch (err) { console.error('Updates failed:', err); fail(res, err); }
});

router.get('/overview', (req: AuthedRequest, res) => {
  try {
    const rep = typeof req.query.rep === 'string' && req.query.rep ? req.query.rep : null;
    const hasData = (db.prepare('SELECT COUNT(*) AS n FROM customer_financial_summary').get() as { n: number }).n > 0 || (db.prepare('SELECT COUNT(*) AS n FROM sap_customers').get() as { n: number }).n > 0;
    const cur = typeof req.query.cur === 'string' && req.query.cur ? req.query.cur : null;
    res.json({ ...overview(viewerOf(req), rep, cur), hasData, isAdmin: isAdmin(req), settings: { bankTolPct: bankTolerancePct(), bankYearPct: bankYearPct(), termsDays: termsDays(), usdPerEur: usdPerEur() }, limits: { hold: HOLD_LIMIT } });
  } catch (err) {
    console.error('Performance overview failed:', err);
    fail(res, err);
  }
});

// ---- the people: one line per sales person (a manager sees the people who report to them, an admin everybody)
router.get('/team', (req: AuthedRequest, res) => {
  try { res.json({ people: req.user!.role !== 'admin' && req.headers['x-view-mode'] !== 'manager' ? [] : teamSummary(viewerOf(req)) }); } catch (err) { console.error('Performance team failed:', err); fail(res, err); }
});

// ---- the important customers that have no e-mail or no phone, under each sales person
router.get('/missing-contacts', (req: AuthedRequest, res) => {
  try { res.json({ groups: missingContacts(viewerOf(req)) }); } catch (err) { console.error('Missing contacts failed:', err); fail(res, err); }
});

// ---- the admin hub: the files, the tabs that are not matched --------------------------------------------------------------------
router.get('/hub', requireAdmin, (_req, res) => {
  const last = (db.prepare('SELECT kind, file_name, rows, added, note, at FROM perf_uploads WHERE id IN (SELECT MAX(id) FROM perf_uploads GROUP BY kind)').all() as { kind: string; file_name: string; rows: number; added: number; note: string; at: string }[]);
  const counts = {
    ledger: (db.prepare('SELECT COUNT(*) AS n FROM ledger_transactions').get() as { n: number }).n,
    sap: (db.prepare('SELECT COUNT(*) AS n FROM sap_customers').get() as { n: number }).n,
    backlog: (db.prepare('SELECT COUNT(*) AS n FROM export_production_backlog').get() as { n: number }).n,
    blockers: (db.prepare('SELECT COUNT(*) AS n FROM export_pipeline_blockers').get() as { n: number }).n,
    dispatch: (db.prepare('SELECT COUNT(*) AS n FROM export_dispatch_queue').get() as { n: number }).n,
  };
  const customers = db.prepare("SELECT sap_no, name, country FROM sap_customers UNION SELECT TRIM(sap) AS sap_no, COALESCE(NULLIF(company, ''), name) AS name, COALESCE(country, '') AS country FROM cards WHERE TRIM(COALESCE(sap, '')) != '' AND TRIM(sap) NOT IN (SELECT sap_no FROM sap_customers) ORDER BY name").all();
  res.json({ last, counts, unresolved: unresolvedSheets(), customers, settings: { bankTolPct: bankTolerancePct(), bankYearPct: bankYearPct(), termsDays: termsDays(), usdPerEur: usdPerEur(), healthOrders: healthOrdersMode(), ...riskNumbers() }, brief: { enabled: settingsModel.get('daily_brief') !== '0', time: settingsModel.get('daily_brief_time') ?? '08:30' } });
});

router.post('/upload/:kind', requireAdmin, upload.single('file'), (req: AuthedRequest, res) => {
  const kind = String(req.params.kind) as UploadKind;
  if (!KINDS.includes(kind)) return fail(res, new Error('Unknown file kind'), 400);
  if (!req.file) return fail(res, new Error('Choose a file first'), 400);
  try {
    res.json(ingest(kind, req.file.buffer, Buffer.from(req.file.originalname, 'latin1').toString('utf8'), req.user!.id));
  } catch (err) {
    console.error(`Performance upload (${kind}) failed:`, err);
    fail(res, err, 400);
  }
});

router.post('/alias', requireAdmin, (req: AuthedRequest, res) => {
  const sheet = String(req.body?.sheet ?? '');
  const sap = String(req.body?.sap ?? '').trim();
  if (!db.prepare('SELECT 1 FROM customer_financial_summary WHERE sheet_name = ?').get(sheet)) return fail(res, new Error('Unknown ledger tab'), 404);
  if (!sap) {
    db.prepare('DELETE FROM customer_aliases WHERE sheet_name = ?').run(sheet);
    return res.json({ ok: true });
  }
  // a SAP number can be typed: a new customer is often not in the SAP list yet (the page then uses the name of the CRM record or of the tab)
  if (!/^\d{6,}$/.test(sap)) return fail(res, new Error('Choose a customer from the list or type its SAP number.'), 400);
  const card = db.prepare('SELECT id FROM cards WHERE TRIM(sap) = ? LIMIT 1').get(sap) as { id: number } | undefined;
  db.prepare("INSERT INTO customer_aliases (sheet_name, sap_no, card_id, is_manually_verified, how) VALUES (?, ?, ?, 1, 'chosen by an admin') ON CONFLICT(sheet_name) DO UPDATE SET sap_no = excluded.sap_no, card_id = excluded.card_id, is_manually_verified = 1, how = excluded.how").run(sheet, sap, card?.id ?? null);
  res.json({ ok: true, unresolved: unresolvedSheets().length });
});

router.post('/rematch', requireAdmin, (_req, res) => res.json(resolveAliases()));

router.put('/settings', requireAdmin, (req: AuthedRequest, res) => {
  const tol = parseFloat(String(req.body?.bankTolPct ?? ''));
  const yp = parseFloat(String(req.body?.bankYearPct ?? ''));
  if (['off', 'note', 'soften'].includes(String(req.body?.healthOrders))) settingsModel.set('health_orders_mode', String(req.body.healthOrders));
  const rate = parseFloat(String(req.body?.usdPerEur ?? ''));
  if (Number.isFinite(rate) && rate > 0.5 && rate < 2) settingsModel.set('perf_usd_per_eur', String(rate));
  if (Number.isFinite(yp) && yp >= 0 && yp <= 5) settingsModel.set('perf_bank_year_pct', String(yp));
  const terms = parseInt(String(req.body?.termsDays ?? ''), 10);
  if (Number.isFinite(tol) && tol >= 0 && tol <= 20) settingsModel.set('perf_bank_tol_pct', String(tol));
  if (Number.isFinite(terms) && terms >= 0 && terms <= 365) settingsModel.set('perf_terms_days', String(terms));
  const grace = parseInt(String(req.body?.riskGraceDays ?? ''), 10);
  const bd = parseInt(String(req.body?.riskBlackDays ?? ''), 10);
  const ba = parseFloat(String(req.body?.riskBlackAmount ?? ''));
  if (Number.isFinite(grace) && grace >= 0 && grace <= 60) settingsModel.set('risk_grace_days', String(grace));
  if (Number.isFinite(bd) && bd >= 30 && bd <= 365) settingsModel.set('risk_black_days', String(bd));
  if (Number.isFinite(ba) && ba >= 0 && ba <= 10_000_000) settingsModel.set('risk_black_amount', String(ba));
  res.json({ bankTolPct: bankTolerancePct(), bankYearPct: bankYearPct(), termsDays: termsDays(), usdPerEur: usdPerEur(), healthOrders: healthOrdersMode(), ...riskNumbers() });
});

const riskNumbers = () => { const r = riskSettings(); return { riskGraceDays: r.graceDays, riskBlackDays: r.blackDays, riskBlackAmount: r.blackAmount }; };

// ---- targets, hiding, the debt hold ---------------------------------------------------------------------------------------------
router.put('/target', requireAdmin, (req: AuthedRequest, res) => {
  const sap = String(req.body?.sap ?? '');
  const a = accountOfSap(viewerOf(req), sap);
  if (!a) return fail(res, new Error('You do not have access to this customer'), 403);
  const year = Number(req.body?.year) || new Date().getFullYear();
  const raw = String(req.body?.target ?? '').replace(/[^\d.]/g, '');
  const value = raw === '' ? null : parseFloat(raw);
  if (value === null || value === 0) db.prepare('DELETE FROM export_targets WHERE sap_no = ? AND year = ?').run(sap, year);
  else if (Number.isFinite(value) && value > 0) db.prepare("INSERT INTO export_targets (sap_no, year, target_eur, set_by) VALUES (?, ?, ?, ?) ON CONFLICT(sap_no, year) DO UPDATE SET target_eur = excluded.target_eur, set_by = excluded.set_by, updated_at = datetime('now')").run(sap, year, value, req.user!.id);
  else return fail(res, new Error('Enter a number'), 400);
  res.json({ ok: true, target: value });
});

router.post('/hide', (req: AuthedRequest, res) => {
  const sap = String(req.body?.sap ?? '');
  const a = accountOfSap(viewerOf(req), sap);
  if (!a) return fail(res, new Error('You do not have access to this customer'), 403);
  // an account that owes 10,000 or more and has been silent for a year can never be hidden
  if (a.rule === 'hold') return res.status(403).json({ error: `This account owes €${Math.round(a.balance).toLocaleString('en-US')} and has not shipped for 12 months. It cannot be hidden.` });
  if (req.body?.hide === false) db.prepare('DELETE FROM perf_hidden WHERE sap_no = ? AND user_id = ?').run(sap, req.user!.id);
  else db.prepare('INSERT OR IGNORE INTO perf_hidden (sap_no, user_id) VALUES (?, ?)').run(sap, req.user!.id);
  res.json({ ok: true });
});

router.post('/override', requireAdmin, (req: AuthedRequest, res) => {
  const sap = String(req.body?.sap ?? '');
  if (req.body?.on === false) db.prepare('DELETE FROM perf_hold_override WHERE sap_no = ?').run(sap);
  else db.prepare("INSERT INTO perf_hold_override (sap_no, by_user, note) VALUES (?, ?, ?) ON CONFLICT(sap_no) DO UPDATE SET by_user = excluded.by_user, note = excluded.note, at = datetime('now')").run(sap, req.user!.id, String(req.body?.note ?? '').slice(0, 300));
  res.json({ ok: true });
});

// ---- one customer (the customer page) --------------------------------------------------------------------------------------------
router.get('/card/:id', (req: AuthedRequest, res) => {
  const card = cardModel.findById(parseInt(String(req.params.id), 10));
  if (!card) return fail(res, new Error('Not found'), 404);
  const sap = card.sap?.trim();
  if (!sap) return res.json({ account: null });
  const a = accountOfSap(viewerOf(req), sap);
  res.json({ account: a ?? null, years: a ? yearsOf(sap) : {}, isAdmin: isAdmin(req), suggestion: a ? savedSuggestion(sap) : null });
});

// ---- how the customers pay: the payment behaviour and the black accounts --------------------------------------------------------------
const riskRow = (a: Account) => ({
  sap: a.sap, name: a.name, country: a.country, rep: a.rep, cardId: a.cardId, currency: a.currency, balance: a.balance, overdue: a.overdue, oldestOver: a.oldestOver, terms: a.terms,
  level: a.risk.level, auto: a.risk.auto, manual: a.risk.manual, manualReason: a.risk.manualReason, score: a.risk.score, avgLate: a.risk.avgLate, onTimePct: a.risk.onTimePct, paidN: a.risk.paidN, lateN: a.risk.lateN, trend: a.risk.trend,
  aiLevel: savedRiskAi(a.sap)?.level ?? null, ytd: a.ytd, readyValue: a.readyValue, waitingValue: a.waitingValue, backlogValue: a.backlogValue,
});

router.get('/risk', (req: AuthedRequest, res) => {
  try {
    const rep = typeof req.query.rep === 'string' && req.query.rep ? req.query.rep : null;
    const list = setsFor(viewerOf(req), rep).live.filter((a) => a.hasLedger && (a.balance > 0.5 || a.overdue > 0 || a.risk.paidN > 0)).map(riskRow);
    res.json({ rows: list, settings: riskNumbers() });
  } catch (err) { console.error('Risk list failed:', err); fail(res, err); }
});

router.get('/risk/:sap', (req: AuthedRequest, res) => {
  const a = accountOfSap(viewerOf(req), String(req.params.sap));
  if (!a) return fail(res, new Error('You do not have access to this customer'), 403);
  res.json({ row: riskRow(a), reasons: a.risk.reasons, invoices: riskInvoices(a.sap), ai: savedRiskAi(a.sap), advice: RULE_ADVICE[a.risk.level], isAdmin: isAdmin(req), settings: riskNumbers() });
});

router.post('/risk/:sap/assess', async (req: AuthedRequest, res) => {
  const a = accountOfSap(viewerOf(req), String(req.params.sap));
  if (!a) return fail(res, new Error('You do not have access to this customer'), 403);
  const cached = !req.body?.force && hasFreshRiskAi(a);
  if (!cached && !useAi(req.user!, res)) return;
  try {
    const ai = await assessRisk(a, !!req.body?.force);
    res.json({ ai, note: ai.ai ? null : aiFailureMessage('The AI did not answer, so this is the answer of the rules.') });
  } catch (err) { res.json({ ai: ruleRiskAnswer(a), note: aiFailureMessage((err as Error).message) }); }
});

// an admin makes a customer black by hand, clears it, or goes back to the automatic level
router.put('/risk/:sap', requireAdmin, (req: AuthedRequest, res) => {
  const a = accountOfSap(viewerOf(req), String(req.params.sap));
  if (!a) return fail(res, new Error('Customer not found'), 404);
  const mode = String(req.body?.mode ?? '');
  if (mode === 'auto') db.prepare('DELETE FROM perf_risk WHERE sap_no = ?').run(a.sap);
  else if (mode === 'black' || mode === 'clear') db.prepare("INSERT INTO perf_risk (sap_no, mode, reason, by_user) VALUES (?, ?, ?, ?) ON CONFLICT(sap_no) DO UPDATE SET mode = excluded.mode, reason = excluded.reason, by_user = excluded.by_user, at = datetime('now')").run(a.sap, mode, String(req.body?.reason ?? '').trim().slice(0, 300), req.user!.id);
  else return fail(res, new Error('Choose black, clear or auto'), 400);
  const now = accountOfSap(viewerOf(req), a.sap);
  res.json({ row: now ? riskRow(now) : null });
});

// an admin asks the AI about every customer that is not "good" (a background job; it stops when the AI stops)
const riskJob = { running: false, total: 0, done: 0, failed: 0, stopped: '' };
router.post('/risk-assess-all', requireAdmin, (req: AuthedRequest, res) => {
  if (riskJob.running) return res.json(riskJob);
  const blocked = blockedReason();
  if (blocked) return fail(res, new Error(blocked), 503);
  const todo = allAccounts(req.user!.id).filter((a) => a.hasLedger && a.risk.level !== 'good' && !hasFreshRiskAi(a));
  Object.assign(riskJob, { running: true, total: todo.length, done: 0, failed: 0, stopped: '' });
  void (async () => {
    for (const a of todo) {
      const b = blockedReason();
      if (b) { riskJob.stopped = b; break; }
      try { const r = await assessRisk(a, true); if (!r.ai) { riskJob.failed += 1; if (riskJob.failed >= 3) { riskJob.stopped = 'The AI did not answer three times in a row.'; break; } } else riskJob.failed = 0; } catch { riskJob.failed += 1; }
      riskJob.done += 1;
    }
    riskJob.running = false;
  })();
  res.json(riskJob);
});
router.get('/risk-assess-all/status', requireAdmin, (_req, res) => res.json({ ...riskJob, saved: (db.prepare('SELECT COUNT(*) AS n FROM perf_risk_ai').get() as { n: number }).n }));

// ---- the AI texts ----------------------------------------------------------------------------------------------------------------
router.post('/diagnostic/:sap', async (req: AuthedRequest, res) => {
  const a = accountOfSap(viewerOf(req), String(req.params.sap));
  if (!a) return fail(res, new Error('You do not have access to this customer'), 403);
  if (a.rule !== 'diagnostic') return fail(res, new Error('This customer does not match the rule'), 400);
  const cached = !req.body?.force && a.diagnostic;
  if (!cached && !useAi(req.user!, res)) return;
  try {
    res.json({ text: await diagnose(a, yearsOf(a.sap), !!req.body?.force) });
  } catch (err) {
    fail(res, new Error(aiFailureMessage((err as Error).message)), 502);
  }
});

router.post('/reactivation/:sap', async (req: AuthedRequest, res) => {
  const a = accountOfSap(viewerOf(req), String(req.params.sap));
  if (!a) return fail(res, new Error('You do not have access to this customer'), 403);
  if (!useAi(req.user!, res)) return;
  const card = a.cardId ? cardModel.findById(a.cardId) : undefined;
  const lang = langOf(String(req.body?.lang || card?.language || ''));
  const contact = (card ? [card.name, card.last_name].filter(Boolean).join(' ') : '') || '';
  try {
    res.json({ ...(await reactivationDraft(a, contact, lang, req.user!.display_name || req.user!.username)), cardId: a.cardId, lang });
  } catch (err) {
    fail(res, new Error(aiFailureMessage((err as Error).message)), 502);
  }
});

// ---- the statement of account ----------------------------------------------------------------------------------------------------
interface StatementCtx { a: Account; lang: ReturnType<typeof langOf>; to: string; contact: string; basis: string; people: number }
function statementCtxFor(viewer: ReturnType<typeof viewerOf>, sap: string, langHint: string): StatementCtx | null {
  const a = accountOfSap(viewer, sap);
  if (!a) return null;
  const card = a.cardId ? cardModel.findById(a.cardId) : undefined;
  const sapRow = db.prepare('SELECT email, contact FROM sap_customers WHERE sap_no = ?').get(a.sap) as { email: string; contact: string } | undefined;
  const lang = langOf(langHint || card?.language || '');
  const rec = card ? recipientsFor(card, 'finance') : null;
  const contact = rec?.names[0] || (card ? [card.name, card.last_name].filter(Boolean).join(' ') : '') || sapRow?.contact || '';
  const to = rec?.emails.join(', ') || sapRow?.email || '';
  return { a, lang, to, contact, basis: rec && rec.emails.length ? rec.basis : 'sap-list', people: rec?.people ?? 0 };
}
function statementContext(req: AuthedRequest, res: Response): StatementCtx | null {
  const c = statementCtxFor(viewerOf(req), String(req.params.sap), String(req.query.lang || req.body?.lang || ''));
  if (!c) { fail(res, new Error('You do not have access to this customer'), 403); return null; }
  return c;
}

// the period of a statement: nothing = from the beginning; "year" = 1 January; "12m" = twelve months; or a date
function fromOf(v: unknown): string | null {
  const x = String(v ?? '').trim();
  const now = new Date();
  if (x === 'year') return `${now.getFullYear()}-01-01`;
  if (x === '12m') { now.setMonth(now.getMonth() - 12); return now.toISOString().slice(0, 10); }
  return /^\d{4}-\d{2}-\d{2}$/.test(x) ? x : null;
}

// the whole account with every invoice paired to its payment(s)
router.get('/ledger/:sap', (req: AuthedRequest, res) => {
  const c = statementContext(req, res);
  if (!c) return;
  const led = ledgerFor(c.a.sap, fromOf(req.query.from));
  res.json(led ? { ...led, name: c.a.name } : { sap: c.a.sap, name: c.a.name, rows: [], summary: null, currency: c.a.currency, tolerance: bankTolerance() });
});
router.post('/ledger/:sap/pin', (req: AuthedRequest, res) => {
  const c = statementContext(req, res);
  if (!c) return;
  const inv = parseInt(String(req.body?.invoice), 10); const pay = parseInt(String(req.body?.payment), 10);
  if (!Number.isInteger(inv) || !Number.isInteger(pay)) return fail(res, new Error('Choose the invoice and the payment.'), 400);
  if (req.body?.remove === true) db.prepare('DELETE FROM ledger_pins WHERE sap = ? AND invoice_tx = ? AND payment_tx = ?').run(c.a.sap, inv, pay);
  else db.prepare('INSERT OR IGNORE INTO ledger_pins (sap, invoice_tx, payment_tx, by_user) VALUES (?, ?, ?, ?)').run(c.a.sap, inv, pay, req.user!.id);
  audit(req.user!, c.a.cardId ?? null, 'change', 'ledger pair', req.body?.remove === true ? `${inv} ↔ ${pay}` : null, req.body?.remove === true ? null : `${inv} ↔ ${pay}`, c.a.name);
  res.json(ledgerFor(c.a.sap, fromOf(req.body?.from)));
});
router.get('/ledger-settings', (_req, res) => res.json({ tolerance: bankTolerance() }));
router.put('/ledger-settings', requireAdmin, (req, res) => res.json({ tolerance: setBankTolerance(Number(req.body?.tolerance)) }));
router.get('/ledger/:sap/pdf', async (req: AuthedRequest, res) => {
  const c = statementContext(req, res);
  if (!c) return;
  try {
    const pdf = await renderLedgerPdf({ name: c.a.name, sap: c.a.sap, country: c.a.country, lang: c.lang, from: fromOf(req.query.from) });
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="TECE-Account-${c.a.sap}.pdf"`);
    res.send(pdf);
  } catch (err) { console.error('Ledger PDF failed:', err); fail(res, err); }
});

router.get('/statement/:sap/draft', (req: AuthedRequest, res) => {
  const c = statementContext(req, res);
  if (!c) return;
  res.json({ ...statementDraft({ name: c.a.name, sap: c.a.sap, contact: c.contact, lang: c.lang }), to: c.to, basis: c.basis, people: c.people, toName: c.contact, lastSent: lastSent('statement', { sap: c.a.sap, cardId: c.a.cardId }), lang: c.lang, langs: LANGS, tableHtml: req.query.full === '1' ? ledgerSummaryHtml({ sap: c.a.sap, lang: c.lang, from: fromOf(req.query.from) }) : statementTableHtml(c.a.sap, c.lang) });
});

router.get('/statement/:sap/pdf', async (req: AuthedRequest, res) => {
  const c = statementContext(req, res);
  if (!c) return;
  try {
    const pdf = await renderStatementPdf({ name: c.a.name, sap: c.a.sap, country: c.a.country, lang: c.lang });
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="TECE-Statement-${c.a.sap}.pdf"`);
    res.send(pdf);
  } catch (err) {
    console.error('Statement PDF failed:', err);
    fail(res, err);
  }
});

router.post('/statement/:sap/send', async (req: AuthedRequest, res) => {
  const c = statementContext(req, res);
  if (!c) return;
  const to = splitEmails(String(req.body?.to ?? ''));
  const subject = String(req.body?.subject ?? '').trim();
  const body = String(req.body?.body ?? '').trim();
  if (!to.length) return fail(res, new Error('Add at least one valid e-mail address under To.'), 400);
  if (!subject || !body) return fail(res, new Error('subject and body are required'), 400);
  const test = req.body?.test === true || settingsModel.get('test_mode') === '1';
  try {
    // the whole account with the matched payments for a period (full), or only the open items (the usual statement)
    const full = req.body?.full === true; const from = fromOf(req.body?.from);
    const pdf = full ? await renderLedgerPdf({ name: c.a.name, sap: c.a.sap, country: c.a.country, lang: c.lang, from }) : await renderStatementPdf({ name: c.a.name, sap: c.a.sap, country: c.a.country, lang: c.lang });
    await sendThankYouEmail({
      to: to.join(', '), cc: req.user!.email || null, subject, body, extraHtml: full ? ledgerSummaryHtml({ sap: c.a.sap, lang: c.lang, from }) : statementTableHtml(c.a.sap, c.lang), replyTo: req.user!.email,
      attachments: [{ filename: `TECE-${full ? 'Account' : 'Statement'}-${c.a.sap}.pdf`, content: pdf, contentType: 'application/pdf' }],
      signature: buildSignature(req.user, styleFor(req.user)), testTo: test ? settingsModel.get('test_email') || req.user!.email : null,
      record: { cardId: c.a.cardId, userId: req.user!.id, kind: 'statement', sap: c.a.sap },
    });
    if (!test) { noteStatement(req.user!.id, c, to.join(', ')); }
    res.json({ ok: true, test });
  } catch (err) {
    console.error('Send statement failed:', err);
    res.status(502).json({ error: 'Failed to send email', message: (err as Error).message });
  }
});

const noteStatement = (userId: number, c: StatementCtx, to: string): void => {
  clearRadarCache();
  if (c.a.cardId) { try { activityModel.add({ userId, cardId: c.a.cardId, type: 'email', text: `Balance statement sent to ${to}` }); } catch { /* the history is only a help */ } }
};

// every statement that went out lately, by SAP number and by customer record (for the "sent 2 days ago" notes on the receivables table and the customer page)
// ---- SWIFT received: a payment that is on its way (see services/perfSwift.ts) -------------------------------------------------------
function accountFor(req: AuthedRequest, sap: string) { const sets = allAccountSets(req.user!.id); return sets.live.concat(sets.dead).find((a) => a.sap === sap) ?? null; }
router.get('/swift/:sap', (req: AuthedRequest, res) => {
  const acc = accountFor(req, String(req.params.sap));
  if (!acc) return res.status(404).json({ error: 'Customer not found' });
  const open = openItemsOf(acc.sap, req.user!.id).filter((i) => i.amount > 0.5).sort((a, b) => a.date.localeCompare(b.date));
  res.json({ sap: acc.sap, name: acc.name, currency: acc.currency, balance: acc.balance, overdue: acc.overdue,
    invoices: open.map((i) => ({ key: invoiceKey(i), date: i.date, description: i.description || 'Carried over', amount: i.amount, daysOver: i.daysOver })),
    waiting: waitingOf(acc.sap) });
});
router.post('/swift', (req: AuthedRequest, res) => {
  const b = req.body ?? {};
  const acc = accountFor(req, String(b.sap ?? ''));
  const amount = Number(b.amount);
  const date = /^\d{4}-\d{2}-\d{2}$/.test(String(b.date ?? '')) ? String(b.date) : new Date().toISOString().slice(0, 10);
  if (!acc) return res.status(404).json({ error: 'Customer not found' });
  if (!Number.isFinite(amount) || amount <= 0) return res.status(400).json({ error: 'Type the amount of the SWIFT.' });
  const invoices = (Array.isArray(b.invoices) ? b.invoices : []).map(String);
  const open = openItemsOf(acc.sap, req.user!.id).filter((i) => i.amount > 0.5);
  if (open.length > 3 && !invoices.length) return res.status(400).json({ error: 'There are several open invoices: choose the invoice(s) this payment is for.' });
  const id = addSwift({ sap: acc.sap, amount, currency: acc.currency, date, invoices, note: String(b.note ?? '').trim().slice(0, 300) || null, userId: req.user!.id });
  if (acc.cardId) activityModel.add({ userId: req.user!.id, cardId: acc.cardId, type: 'note', text: `SWIFT received: ${amount.toLocaleString('en-US')} ${acc.currency} (${date}). The money is on its way; it is not counted as overdue until the ledger shows it.`, imported: true });
  clearRadarCache();
  res.status(201).json({ id });
});
router.post('/swift/:id/cancel', (req: AuthedRequest, res) => {
  const row = findSwift(parseInt(String(req.params.id), 10));
  if (!row) return res.status(404).json({ error: 'Not found' });
  if (!accountFor(req, row.sap)) return res.status(403).json({ error: 'No access' });
  cancelSwift(row.id);
  clearRadarCache();
  res.json({ ok: true });
});

router.get('/statements/sent', (_req, res) => res.json({ map: Object.fromEntries(lastSentMap('statement')) }));

// ---- several statements at once: the list to check first, then one send for all the ticked customers ----------------------------
router.post('/statements/preview', (req: AuthedRequest, res) => {
  const saps = (Array.isArray(req.body?.saps) ? req.body.saps : []).map((x: unknown) => String(x).trim()).filter(Boolean).slice(0, 60);
  const sent = lastSentMap('statement');
  const rows = saps.map((sap: string) => {
    const c = statementCtxFor(viewerOf(req), sap, '');
    if (!c) return { sap, name: sap, ok: false, reason: 'no access' };
    const prev = sent.get(`sap:${c.a.sap}`) ?? (c.a.cardId ? sent.get(`card:${c.a.cardId}`) : undefined) ?? null;
    return { sap: c.a.sap, name: c.a.name, currency: c.a.currency, overdue: Math.round(c.a.overdue), balance: Math.round(c.a.balance), to: c.to, toName: c.contact, basis: c.basis, people: c.people, lang: c.lang, ok: !!c.to, reason: c.to ? '' : 'no e-mail', lastSent: prev };
  });
  res.json({ rows, test: settingsModel.get('test_mode') === '1' });
});

router.post('/statements/send-many', async (req: AuthedRequest, res) => {
  const saps = [...new Set((Array.isArray(req.body?.saps) ? req.body.saps : []).map((x: unknown) => String(x).trim()).filter(Boolean))].slice(0, 40) as string[];
  if (!saps.length) return fail(res, new Error('Tick at least one customer.'), 400);
  const test = req.body?.test === true || settingsModel.get('test_mode') === '1';
  const results: { sap: string; name: string; ok: boolean; to?: string; error?: string }[] = [];
  for (const sap of saps) {
    const c = statementCtxFor(viewerOf(req), sap, '');
    if (!c) { results.push({ sap, name: sap, ok: false, error: 'no access' }); continue; }
    if (!c.to) { results.push({ sap, name: c.a.name, ok: false, error: 'no e-mail address' }); continue; }
    try {
      const d = statementDraft({ name: c.a.name, sap: c.a.sap, contact: c.contact, lang: c.lang });
      const pdf = await renderStatementPdf({ name: c.a.name, sap: c.a.sap, country: c.a.country, lang: c.lang });
      await sendThankYouEmail({
        to: c.to, cc: req.user!.email || null, subject: d.subject, body: d.body, extraHtml: statementTableHtml(c.a.sap, c.lang), replyTo: req.user!.email,
        attachments: [{ filename: `TECE-Statement-${c.a.sap}.pdf`, content: pdf, contentType: 'application/pdf' }],
        signature: buildSignature(req.user, styleFor(req.user)), testTo: test ? settingsModel.get('test_email') || req.user!.email : null,
        record: { cardId: c.a.cardId, userId: req.user!.id, kind: 'statement', sap: c.a.sap },
      });
      if (!test) noteStatement(req.user!.id, c, c.to);
      results.push({ sap, name: c.a.name, ok: true, to: c.to });
    } catch (err) { console.error('Send statement failed:', sap, err); results.push({ sap, name: c.a.name, ok: false, error: (err as Error).message.slice(0, 160) }); }
    await new Promise((r) => setTimeout(r, 400)); // one by one, a short pause: a mail server does not like a burst
  }
  res.json({ test, sent: results.filter((r) => r.ok).length, failed: results.filter((r) => !r.ok).length, results });
});

// the same statement, forwarded to a colleague (internal, in Turkish; nothing goes to the customer)
router.post('/statement/:sap/forward', async (req: AuthedRequest, res) => {
  const c = statementContext(req, res);
  if (!c) return;
  try {
    // the whole ledger (with the matched payments, for the chosen period) or only the open items, like the customer version
    const full = req.body?.full === true; const from = fromOf(req.body?.from);
    const pdf = full ? await renderLedgerPdf({ name: c.a.name, sap: c.a.sap, country: c.a.country, lang: c.lang, from }) : await renderStatementPdf({ name: c.a.name, sap: c.a.sap, country: c.a.country, lang: c.lang });
    const r = await forwardToStaff({
      sender: req.user!, staffId: Number(req.body?.userId), note: String(req.body?.note ?? ''), what: `${full ? 'Cari hesap' : 'Hesap ekstresi'}: ${c.a.name} (SAP ${c.a.sap})`,
      attachments: [{ filename: `TECE-${full ? 'Account' : 'Statement'}-${c.a.sap}.pdf`, content: pdf, contentType: 'application/pdf' }], extraHtml: full ? ledgerSummaryHtml({ sap: c.a.sap, lang: c.lang, from }) : statementTableHtml(c.a.sap, c.lang),
    });
    res.json({ ok: true, ...r });
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

// ---- the dispatch request --------------------------------------------------------------------------------------------------------
function dispatchRow(req: AuthedRequest, res: Response, sap: string) {
  const full = overview(viewerOf(req), null, null).dispatch.find((d) => d.sap === sap);
  if (!full) { fail(res, new Error('This shipment is not in your list'), 404); return null; }
  return full;
}

router.get('/dispatch/:sap/draft', (req: AuthedRequest, res) => {
  const r = dispatchRow(req, res, String(req.params.sap));
  if (!r) return;
  res.json({ ...dispatchDraft(r), tableHtml: dispatchTableHtml(r), to: settingsModel.get('perf_dispatch_to') || OPERATIONS_EMAIL, risk: r.risk, riskReasons: r.riskReasons, overdue: r.account?.overdue ?? 0, riskCurrency: r.account?.currency ?? r.currency });
});

router.post('/dispatch/:sap/send', async (req: AuthedRequest, res) => {
  const r = dispatchRow(req, res, String(req.params.sap));
  if (!r) return;
  const to = splitEmails(String(req.body?.to ?? ''));
  const subject = String(req.body?.subject ?? '').trim();
  const body = String(req.body?.body ?? '').trim();
  if (!to.length || !subject || !body) return fail(res, new Error('To, subject and text are required'), 400);
  if (r.risk === 'black' && req.body?.riskChecked !== true) return fail(res, new Error('BLACK ACCOUNT: this customer pays very late. Tick that you checked with finance before you send the dispatch request.'), 409);
  const test = req.body?.test === true || settingsModel.get('test_mode') === '1';
  try {
    await sendThankYouEmail({
      to: to.join(', '), cc: req.user!.email || null, subject, body, extraHtml: dispatchTableHtml(r), replyTo: req.user!.email,
      signature: buildSignature(req.user, styleFor(req.user)), testTo: test ? settingsModel.get('test_email') || req.user!.email : null,
    });
    if (!test) { try { addAsk({ sap: r.sap, sdNos: r.sds, note: body.replace(/\s+/g, ' ').slice(0, 240), userId: req.user!.id }); } catch (e) { console.error('The ask for Operations was not saved:', e); } }
    res.json({ ok: true, test });
  } catch (err) {
    console.error('Send dispatch request failed:', err);
    res.status(502).json({ error: 'Failed to send email', message: (err as Error).message });
  }
});

// Silence a back order (one SD document or everything of the customer) the customer does not want for a while: it leaves the ready lists until the date.
router.post('/dispatch/:sap/snooze', (req: AuthedRequest, res) => {
  const r = dispatchRow(req, res, String(req.params.sap));
  if (!r) return;
  const sdNo = String(req.body?.sdNo ?? '').trim() || null;
  if (sdNo && !r.sds.includes(sdNo)) return fail(res, new Error('That SD document is not in this customer\'s list'), 404);
  const until = String(req.body?.until ?? '').trim() || null;
  if (until && !/^\d{4}-\d{2}-\d{2}$/.test(until)) return fail(res, new Error('The date is not valid'), 400);
  const id = snooze({ sap: r.sap, sdNo, until, reason: String(req.body?.reason ?? ''), userId: req.user!.id });
  const cardIdOf = accountOfSap(viewerOf(req), r.sap)?.cardId ?? null;
  if (cardIdOf) activityModel.add({ userId: req.user!.id, cardId: cardIdOf, type: 'note', text: `Ready-to-ship order silenced${sdNo ? ` (${sdNo})` : ''}${until ? ` until ${until}` : ''}${req.body?.reason ? `: ${String(req.body.reason).slice(0, 120)}` : ''}`, imported: true });
  res.status(201).json({ id });
});
router.get('/dispatch/snoozed', (req: AuthedRequest, res) => {
  const mine = new Set(accountsFor(viewerOf(req)).map((a) => a.sap));
  res.json(activeSnoozes().filter((x) => req.user!.role === 'admin' || mine.has(x.sap)));
});
router.post('/dispatch/snooze/:id/clear', (req: AuthedRequest, res) => {
  const id = parseInt(String(req.params.id), 10);
  const row = activeSnoozes().find((x) => x.id === id);
  if (!row) return fail(res, new Error('Not found'), 404);
  const mine = new Set(accountsFor(viewerOf(req)).map((a) => a.sap));
  if (req.user!.role !== 'admin' && !mine.has(row.sap)) return fail(res, new Error('You do not have access to this customer'), 403);
  clearSnooze(id);
  res.json({ ok: true });
});

// Sales asks Operations to organise the transport of what is ready (without the long dispatch e-mail): a line in the Operations screen and a short e-mail.
router.post('/dispatch/:sap/ask', async (req: AuthedRequest, res) => {
  const r = dispatchRow(req, res, String(req.params.sap));
  if (!r) return;
  const note = String(req.body?.note ?? '').trim().slice(0, 400) || null;
  addAsk({ sap: r.sap, sdNos: r.sds, note, userId: req.user!.id });
  const test = settingsModel.get('test_mode') === '1';
  try {
    await sendThankYouEmail({
      to: settingsModel.get('ship_ask_to') || 'operasyon@tece.com.tr', cc: req.user!.email || null, subject: `Nakliye talebi: ${r.customer} (${r.country})`,
      body: `Merhaba,\n\n${r.customer} için sevke hazır sipariş var; nakliyenin organize edilmesini rica ediyorum.${note ? `\n\nNot: ${note}` : ''}\n\nCRM'de Nakliye bölümündeki "Sevke hazır" listesinden de görebilirsiniz.`,
      extraHtml: dispatchTableHtml(r), replyTo: req.user!.email, signature: buildSignature(req.user, styleFor(req.user)), testTo: test ? settingsModel.get('test_email') || req.user!.email : null,
    });
  } catch (err) { console.error('The ask e-mail failed (the ask itself is saved):', err); }
  res.json({ ok: true });
});

// (kept for the customer picker of the page: the accounts a person may open)
router.get('/accounts', (req: AuthedRequest, res) => res.json(accountsFor(viewerOf(req)).map((a) => ({ sap: a.sap, name: a.name, country: a.country }))));

// ---- the four things to ask for (the Mission board) -----------------------------------------------------------------------------
router.get('/asks', (req: AuthedRequest, res) => {
  try { res.json(asksFor(viewerOf(req), req.query.full === "1")); } catch (err) { console.error('Performance asks failed:', err); fail(res, err); }
});

// ---- the full AI suggestion for a customer ---------------------------------------------------------------------------------------
router.get('/suggestion/:sap', (req: AuthedRequest, res) => {
  const a = accountOfSap(viewerOf(req), String(req.params.sap));
  if (!a) return fail(res, new Error('You do not have access to this customer'), 403);
  res.json({ suggestion: savedSuggestion(a.sap) });
});

router.post('/suggestion/:sap', async (req: AuthedRequest, res) => {
  const a = accountOfSap(viewerOf(req), String(req.params.sap));
  if (!a) return fail(res, new Error('You do not have access to this customer'), 403);
  if (!useAi(req.user!, res)) return;
  try { res.json({ suggestion: await suggest(a) }); } catch (err) { fail(res, new Error(aiFailureMessage((err as Error).message)), 502); }
});

// an admin asks for the suggestions of every customer that is alive (a background job; it stops when the AI stops)
const job = { running: false, total: 0, done: 0, failed: 0, stopped: '' };
router.post('/suggestions/run', requireAdmin, (req: AuthedRequest, res) => {
  if (job.running) return res.json(job);
  const blocked = blockedReason();
  if (blocked) return fail(res, new Error(blocked), 503);
  const fresh = new Set((db.prepare("SELECT sap_no FROM perf_suggestions WHERE made_at >= datetime('now', '-14 days')").all() as { sap_no: string }[]).map((r) => r.sap_no));
  const todo = allAccounts(req.user!.id).filter((a) => !a.inactive && a.hasLedger && !fresh.has(a.sap));
  Object.assign(job, { running: true, total: todo.length, done: 0, failed: 0, stopped: '' });
  void (async () => {
    for (const a of todo) {
      const b = blockedReason();
      if (b) { job.stopped = b; break; }
      try { const r = await suggest(a); if (!r.ai) { job.failed += 1; if (job.failed >= 3) { job.stopped = 'The AI did not answer three times in a row.'; break; } } else job.failed = 0; } catch { job.failed += 1; }
      job.done += 1;
    }
    job.running = false;
  })();
  res.json(job);
});
router.get('/suggestions/status', requireAdmin, (_req, res) => res.json({ ...job, saved: (db.prepare('SELECT COUNT(*) AS n FROM perf_suggestions').get() as { n: number }).n }));

// ---- who looks after whom: download, correct, upload -----------------------------------------------------------------------------
const COLS = ['Card ID', 'SAP no', 'Company', 'Country', 'Sales person', 'Counts as (SAP no)', 'Payment terms (days)', 'E-mail', 'Phone', 'Where it comes from'] as const;

// one SAP customer counts as another: its sales, balance and orders are those of the parent
function setLink(sap: string, parentText: string, userId: number): string | null {
  const parent = parentText.replace(/\D/g, '');
  if (!parent) { db.prepare('DELETE FROM perf_links WHERE sap_no = ?').run(sap); return null; }
  if (parent === sap) return 'A customer cannot count as itself.';
  if (!db.prepare('SELECT 1 FROM sap_customers WHERE sap_no = ?').get(parent)) return `There is no SAP customer ${parent}.`;
  const real = linkMap().get(parent) ?? parent;
  if (real === sap) return 'That would make a circle.';
  db.prepare('INSERT INTO perf_links (sap_no, parent_sap, by_user) VALUES (?, ?, ?) ON CONFLICT(sap_no) DO UPDATE SET parent_sap = excluded.parent_sap, by_user = excluded.by_user, at = datetime(\'now\')').run(sap, real, userId);
  db.prepare('UPDATE perf_links SET parent_sap = ? WHERE parent_sap = ?').run(real, sap); // the ones that counted as this one now count as the parent
  return null;
}

router.get('/assignments.xlsx', requireAdmin, async (req: AuthedRequest, res) => {
  try {
    const accounts = new Map(allAccounts(req.user!.id).map((a) => [a.sap, a]));
    const wb = new ExcelJS.Workbook();
    const ws = wb.addWorksheet('Customers');
    ws.addRow([...COLS]);
    ws.getRow(1).font = { bold: true };
    ws.columns = [{ width: 10 }, { width: 14 }, { width: 44 }, { width: 18 }, { width: 24 }, { width: 18 }, { width: 20 }, { width: 34 }, { width: 18 }, { width: 28 }];
    const links = linkMap();
    const termsOf = new Map((db.prepare('SELECT sap_no, days FROM perf_terms').all() as { sap_no: string; days: number }[]).map((r) => [r.sap_no, r.days]));
    const termsFor = (sap: string) => (sap ? termsOf.get(sap) ?? termsDays() : '');
    const seen = new Set<string>();
    const cards = db.prepare("SELECT id, sap, name, last_name, company, country, person, email, COALESCE(NULLIF(mobile, ''), tel) AS phone FROM cards WHERE (stage = 'customer' OR TRIM(COALESCE(sap, '')) != '') ORDER BY company").all() as { id: number; sap: string | null; name: string | null; last_name: string | null; company: string | null; country: string | null; person: string | null; email: string | null; phone: string | null }[];
    for (const c of cards) {
      const sap = c.sap?.trim() ?? '';
      const a = sap ? accounts.get(sap) : undefined;
      if (sap) seen.add(sap);
      ws.addRow([c.id, sap, c.company || [c.name, c.last_name].filter(Boolean).join(' '), c.country ?? '', a?.rep || c.person || '', links.get(sap) ?? '', termsFor(sap), c.email ?? '', c.phone ?? '', a ? 'CRM customer + SAP' : 'CRM customer']);
    }
    for (const a of accounts.values()) if (!seen.has(a.sap)) ws.addRow(['', a.sap, a.name, a.country, a.rep, '', termsFor(a.sap), '', '', 'SAP customer (no CRM record)']);
    const sapNames = new Map((db.prepare('SELECT sap_no, name, country, email, phone FROM sap_customers').all() as { sap_no: string; name: string; country: string; email: string; phone: string }[]).map((r) => [r.sap_no, r]));
    for (const [child, parent] of links) if (!seen.has(child) && !accounts.has(child)) { const r = sapNames.get(child); ws.addRow(['', child, r?.name ?? child, r?.country ?? '', '', parent, '', r?.email ?? '', r?.phone ?? '', 'SAP customer that counts as another']); }
    const people = wb.addWorksheet('Sales people');
    people.addRow(['Allowed names for the "Sales person" column']);
    people.getRow(1).font = { bold: true };
    for (const u of userModel.listAll().filter((x) => !x.is_assistant && !x.assists_id && x.is_active)) people.addRow([u.display_name || u.username]);
    people.getColumn(1).width = 40;
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename="TECE-customer-assignments.xlsx"');
    await wb.xlsx.write(res);
    res.end();
  } catch (err) { console.error('Assignments download failed:', err); if (!res.headersSent) fail(res, err); }
});

router.post('/assignments', requireAdmin, upload.single('file'), async (req: AuthedRequest, res) => {
  if (!req.file) return fail(res, new Error('Choose the file first'), 400);
  try {
    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(req.file.buffer as unknown as ExcelJS.Buffer);
    const ws = wb.getWorksheet('Customers') ?? wb.worksheets[0];
    const head = (ws.getRow(1).values as unknown[]).map((v) => String(v ?? '').trim());
    const at = (name: string) => head.indexOf(name);
    if (at('Sales person') < 0 || at('SAP no') < 0 || at('Card ID') < 0) return fail(res, new Error('This is not the assignment file: the columns Card ID, SAP no and Sales person are needed.'), 400);
    const canon = canonicalReps();
    const users = new Set(userModel.listAll().filter((x) => !x.is_assistant && !x.assists_id && x.is_active).map((u) => u.display_name || u.username));
    const sets = allAccountSets(req.user!.id);
    const accounts = new Map([...sets.live, ...sets.dead].map((a) => [a.sap, a]));
    const cell = (row: ExcelJS.Row, name: string) => { const v = row.getCell(at(name)).value; return String(typeof v === 'object' && v !== null && 'text' in v ? (v as { text: string }).text : v ?? '').trim(); };
    const report = { rows: 0, people: 0, sapChanged: 0, overrides: 0, details: 0, links: 0, skipped: [] as string[] };
    db.exec('BEGIN');
    try {
      ws.eachRow((row, n) => {
        if (n === 1) return;
        const id = parseInt(cell(row, 'Card ID'), 10);
        const sap = cell(row, 'SAP no').replace(/\D/g, '');
        const raw = cell(row, 'Sales person');
        if (!id && !sap) return;
        report.rows += 1;
        const rep = raw ? canon(raw) : '';
        const company = at('Company') > 0 ? cell(row, 'Company') : '';
        const country = at('Country') > 0 ? cell(row, 'Country') : '';
        const email = at('E-mail') > 0 ? cell(row, 'E-mail') : '';
        const phone = at('Phone') > 0 ? cell(row, 'Phone') : '';
        const counts = at('Counts as (SAP no)') > 0 ? cell(row, 'Counts as (SAP no)') : '';
        const termsTxt = at('Payment terms (days)') > 0 ? cell(row, 'Payment terms (days)') : '';
        if (sap && termsTxt !== '' && /^\d{1,3}$/.test(termsTxt) && Number(termsTxt) <= 365) {
          const have = (db.prepare('SELECT days FROM perf_terms WHERE sap_no = ?').get(sap) as { days: number } | undefined)?.days ?? termsDays();
          if (Number(termsTxt) !== have) {
            db.prepare("INSERT INTO perf_terms (sap_no, days) VALUES (?, ?) ON CONFLICT(sap_no) DO UPDATE SET days = excluded.days, at = datetime('now')").run(sap, Number(termsTxt));
            report.details += 1;
          }
        }
        if (raw && !users.has(rep)) { report.skipped.push(`Row ${n}: "${raw}" is not a sales person of the app`); return; }
        if (id) {
          const card = db.prepare('SELECT id, sap, person FROM cards WHERE id = ?').get(id) as { id: number; sap: string | null; person: string | null } | undefined;
          if (!card) { report.skipped.push(`Row ${n}: there is no customer with Card ID ${id}`); return; }
          if (rep && (card.person ?? '').trim() !== rep) { db.prepare("UPDATE cards SET person = ?, updated_at = datetime('now') WHERE id = ?").run(rep, id); report.people += 1; }
          const cur = db.prepare('SELECT company, country, email, tel, mobile FROM cards WHERE id = ?').get(id) as { company: string | null; country: string | null; email: string | null; tel: string | null; mobile: string | null };
          let touched = false;
          if (company && company !== (cur.company ?? '')) { db.prepare('UPDATE cards SET company = ?, company_key = ? WHERE id = ?').run(company, companyKey(company), id); touched = true; }
          if (country && country !== (cur.country ?? '')) { db.prepare('UPDATE cards SET country = ? WHERE id = ?').run(country, id); touched = true; }
          if (email !== (cur.email ?? '') && (email || cur.email)) { db.prepare('UPDATE cards SET email = ? WHERE id = ?').run(email || null, id); touched = true; }
          if (phone && phone !== (cur.mobile || cur.tel || '')) { db.prepare('UPDATE cards SET tel = ? WHERE id = ?').run(phone, id); touched = true; }
          if (touched) { db.prepare("UPDATE cards SET updated_at = datetime('now') WHERE id = ?").run(id); report.details += 1; }
          if (sap !== (card.sap ?? '').replace(/\D/g, '')) { db.prepare("UPDATE cards SET sap = ?, updated_at = datetime('now') WHERE id = ?").run(sap || null, id); report.sapChanged += 1; }
        }
        if (sap && !id && company && accounts.has(sap) && company !== accounts.get(sap)?.name) {
          db.prepare('INSERT INTO perf_name_override (sap_no, name) VALUES (?, ?) ON CONFLICT(sap_no) DO UPDATE SET name = excluded.name').run(sap, company);
          report.details += 1;
        }
        if (sap && at('Counts as (SAP no)') > 0 && counts.replace(/\D/g, '') !== (linkMap().get(sap) ?? '')) {
          const err = setLink(sap, counts, req.user!.id);
          if (err) report.skipped.push(`Row ${n}: ${err}`); else report.links += 1;
        }
        if (sap && rep && accounts.has(sap) && accounts.get(sap)?.rep !== rep) {
          db.prepare('INSERT INTO perf_rep_override (sap_no, rep, by_user) VALUES (?, ?, ?) ON CONFLICT(sap_no) DO UPDATE SET rep = excluded.rep, by_user = excluded.by_user, at = datetime(\'now\')').run(sap, rep, req.user!.id);
          report.overrides += 1;
        }
      });
      db.exec('COMMIT');
    } catch (err) { db.exec('ROLLBACK'); throw err; }
    res.json(report);
  } catch (err) { console.error('Assignments upload failed:', err); fail(res, err, 400); }
});


// ---- the morning brief ------------------------------------------------------------------------------------------------------------
router.get('/daily-brief.pdf', async (req: AuthedRequest, res) => {
  try {
    const d = await gatherBrief(viewerOf(req), req.query.ai !== '0');
    const pdf = await renderBriefPdf(d);
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'inline; filename="TECE-daily-brief.pdf"');
    res.send(pdf);
  } catch (err) { console.error('Daily brief PDF failed:', err); fail(res, err); }
});

router.put('/daily-brief/settings', requireAdmin, (req: AuthedRequest, res) => {
  if (typeof req.body?.enabled === 'boolean') settingsModel.set('daily_brief', req.body.enabled ? '1' : '0');
  if (typeof req.body?.time === 'string' && /^\d{2}:\d{2}$/.test(req.body.time)) settingsModel.set('daily_brief_time', req.body.time);
  res.json({ enabled: settingsModel.get('daily_brief') !== '0', time: settingsModel.get('daily_brief_time') ?? '08:30' });
});

// send now: only to me (a test), or to everybody
router.post('/daily-brief/send', requireAdmin, async (req: AuthedRequest, res) => {
  try { res.json(await sendBriefs(req.body?.all === true ? undefined : [req.user!.id], req.body?.all !== true)); } catch (err) { fail(res, err); }
});

// ---- the customers: owner, name, remove; the ones missing in the CRM ------------------------------------------------------------------
router.get('/customers', requireAdmin, (req: AuthedRequest, res) => {
  const sets = allAccountSets(req.user!.id);
  const withCard = new Set((db.prepare("SELECT TRIM(sap) AS s FROM cards WHERE sap IS NOT NULL AND TRIM(sap) != ''").all() as { s: string }[]).map((r) => r.s));
  const L = linkMap();
  const names = new Map((db.prepare('SELECT sap_no, name, country FROM sap_customers').all() as { sap_no: string; name: string; country: string }[]).map((r) => [r.sap_no, r]));
  const rows = [
    ...[...sets.live, ...sets.dead].map((a) => ({ sap: a.sap, name: a.name, country: a.country, rep: a.rep, inCrm: withCard.has(a.sap), dead: sets.dead.includes(a), linkedTo: '', terms: a.terms })),
    ...[...L].map(([child, parent]) => ({ sap: child, name: names.get(child)?.name ?? child, country: names.get(child)?.country ?? '', rep: '', inCrm: withCard.has(child), dead: false, linkedTo: parent, terms: null as number | null })),
  ].sort((a, b) => a.name.localeCompare(b.name));
  const people = userModel.listAll().filter((u) => !u.is_assistant && !u.assists_id && u.is_active).map((u) => u.display_name || u.username);
  const removed = db.prepare('SELECT e.sap_no AS sap, COALESCE(s.name, e.sap_no) AS name FROM perf_excluded e LEFT JOIN sap_customers s ON s.sap_no = e.sap_no ORDER BY name').all();
  res.json({ customers: rows, people, removed });
});

// the owner (any user, an admin too) and / or a corrected name ("TECE DEKOR Ltd" is Canplast) of one SAP customer
router.put('/customer/:sap', requireAdmin, (req: AuthedRequest, res) => {
  const sap = String(req.params.sap);
  const people = userModel.listAll().filter((u) => !u.is_assistant && !u.assists_id && u.is_active).map((u) => u.display_name || u.username);
  if (typeof req.body?.rep === 'string') {
    const rep = req.body.rep.trim();
    if (rep && !people.includes(rep)) return fail(res, new Error('That is not a sales person of the app'), 400);
    if (rep) {
      db.prepare("INSERT INTO perf_rep_override (sap_no, rep, by_user) VALUES (?, ?, ?) ON CONFLICT(sap_no) DO UPDATE SET rep = excluded.rep, by_user = excluded.by_user, at = datetime('now')").run(sap, rep, req.user!.id);
      db.prepare("UPDATE cards SET person = ?, updated_at = datetime('now') WHERE TRIM(sap) = ?").run(rep, sap);
    } else db.prepare('DELETE FROM perf_rep_override WHERE sap_no = ?').run(sap);
  }
  if (req.body?.terms !== undefined) {
    const d = String(req.body.terms).trim();
    if (d === '') db.prepare('DELETE FROM perf_terms WHERE sap_no = ?').run(sap);
    else if (/^\d{1,3}$/.test(d) && Number(d) <= 365) db.prepare("INSERT INTO perf_terms (sap_no, days) VALUES (?, ?) ON CONFLICT(sap_no) DO UPDATE SET days = excluded.days, at = datetime('now')").run(sap, Number(d));
    else return fail(res, new Error('Payment terms are a number of days (0 to 365).'), 400);
  }
  if (typeof req.body?.linkTo === 'string') {
    const err = setLink(sap, req.body.linkTo.trim(), req.user!.id);
    if (err) return fail(res, new Error(err), 400);
  }
  if (typeof req.body?.name === 'string') {
    const name = req.body.name.trim().slice(0, 160);
    if (name) db.prepare('INSERT INTO perf_name_override (sap_no, name) VALUES (?, ?) ON CONFLICT(sap_no) DO UPDATE SET name = excluded.name').run(sap, name);
    else db.prepare('DELETE FROM perf_name_override WHERE sap_no = ?').run(sap);
  }
  res.json({ ok: true });
});

router.delete('/customer/:sap', requireAdmin, (req: AuthedRequest, res) => {
  try { res.json(removeCustomer(String(req.params.sap), req.user!.id)); } catch (err) { fail(res, err); }
});
router.post('/customer/:sap/restore', requireAdmin, (req: AuthedRequest, res) => { restoreExcluded(String(req.params.sap)); res.json({ ok: true }); });

router.get('/crm-missing', requireAdmin, (req: AuthedRequest, res) => res.json({ missing: missingInCrm(req.user!.id) }));
router.post('/crm-create', requireAdmin, (req: AuthedRequest, res) => {
  const saps = req.body?.all === true ? 'all' : Array.isArray(req.body?.saps) ? (req.body.saps as unknown[]).map(String) : [];
  if (saps !== 'all' && !saps.length) return fail(res, new Error('Choose at least one customer'), 400);
  try { res.json(createInCrm(saps, req.user!.id)); } catch (err) { fail(res, err); }
});

export default router;
