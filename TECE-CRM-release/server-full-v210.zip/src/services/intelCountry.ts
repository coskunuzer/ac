import { db } from '../db/connection';
import { canonicalCountry, countryModel } from '../models/countryModel';
import { ISO2 } from '../data/isoNames';

// Which country is a SAP account in? The sales list only has a sales region ("Avrupa", "Asya") and a city, so the country comes from, in this order:
//  1. the CRM customer card that carries the SAP number (the CRM is the truth),
//  2. the SAP customer master (the Sales intelligence "customer list" upload: a two-letter country code for every account),
//  3. the SAP customer list of the Performance page,
//  4. the channel: an account that starts with 1201 is a domestic (Turkey) account.
export type CtrySrc = 'card' | 'master' | 'sap' | 'channel' | 'none';
export interface CtryInfo { country: string; continent: string; src: CtrySrc }

const byName = new Map<string, string>(Object.values(ISO2).map((v) => [v.name, v.continent]));
export function continentOf(country: string): string {
  if (!country) return '';
  const a = countryModel.findByCountry(country)?.continent;
  if (a) return a === 'Americas' ? americas(country) : a;
  return byName.get(country) ?? '';
}
// the CRM list says "Americas"; the reports split it in North and South America like the SAP regions do
function americas(country: string): string { const c = byName.get(country); return c && /America/.test(c) ? c : 'Americas'; }

export function countryMap(): Map<string, CtryInfo> {
  const out = new Map<string, CtryInfo>();
  const put = (code: string, country: string, src: CtrySrc) => {
    const c = canonicalCountry(country) as string;
    if (!c || out.has(code)) return;
    out.set(code, { country: c, continent: continentOf(c), src });
  };
  const codes = (db.prepare('SELECT code FROM intel_cust').all() as { code: string }[]).map((r) => r.code);
  const cards = db.prepare("SELECT sap, country, market FROM cards WHERE sap IS NOT NULL AND TRIM(sap) <> '' ORDER BY (country IS NULL OR TRIM(country) = '') ASC, id").all() as { sap: string; country: string | null; market: string | null }[];
  const cardBy = new Map<string, { country: string | null; market: string | null }>();
  for (const c of cards) if (!cardBy.has(c.sap.trim())) cardBy.set(c.sap.trim(), c);
  const master = new Map((db.prepare("SELECT code, country FROM intel_master WHERE country <> ''").all() as { code: string; country: string }[]).map((r) => [r.code, r.country]));
  const sap = new Map((db.prepare("SELECT sap_no, country FROM sap_customers WHERE country IS NOT NULL AND TRIM(country) <> ''").all() as { sap_no: string; country: string }[]).map((r) => [r.sap_no, r.country]));
  for (const code of codes) {
    const card = cardBy.get(code);
    if (card?.market === 'domestic') { put(code, 'Turkey', 'card'); continue; }
    if (card?.country?.trim()) put(code, card.country, 'card');
    if (!out.has(code) && master.has(code)) put(code, master.get(code)!, 'master');
    if (!out.has(code) && sap.has(code)) put(code, sap.get(code)!, 'sap');
    if (!out.has(code) && code.startsWith('1201')) put(code, 'Turkey', 'channel');
    if (!out.has(code)) out.set(code, { country: '', continent: '', src: 'none' });
  }
  return out;
}
