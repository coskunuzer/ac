import { db } from '../db/connection';
import { memoTables } from '../db/dataVersion';
import { PROVINCES, placeKey, resolveCity } from '../data/turkeyPlaces';

export interface CityAssignment {
  key: string;
  city: string;
  responsible: string | null;
  assistant: string | null;
  updated_at: string;
}

const cityKeyKept = new Map<string, string>();
export const cityKey = (name: string): string => {
  const hit = cityKeyKept.get(name);
  if (hit !== undefined) return hit;
  const key = placeKey(resolveCity(name).city ?? name);
  if (cityKeyKept.size > 5000) cityKeyKept.clear();
  cityKeyKept.set(name, key);
  return key;
};
const keptCities = memoTables(['city_assignments'], () => {
  const rows = db.prepare('SELECT * FROM city_assignments ORDER BY city COLLATE NOCASE').all() as unknown as CityAssignment[];
  return { rows, byKey: new Map(rows.map((r) => [r.key, r])) };
});

// Who looks after each city of the domestic team. Every province is listed (empty until somebody is chosen);
// a place that is not a province (a district that could not be placed) can be added too.
export const cityModel = {
  listAll(): CityAssignment[] {
    return keptCities().rows.map((r) => ({ ...r }));
  },

  findByCity(name: string | null | undefined): CityAssignment | undefined {
    if (!name || !name.trim()) return undefined;
    const r = keptCities().byKey.get(cityKey(name));
    return r ? { ...r } : undefined;
  },

  upsert(input: { city: string; responsible: string | null; assistant: string | null }): void {
    const city = resolveCity(input.city).city;
    if (!city) return;
    db.prepare(
      `INSERT INTO city_assignments (key, city, responsible, assistant, updated_at)
       VALUES (@key, @city, @responsible, @assistant, datetime('now'))
       ON CONFLICT(key) DO UPDATE SET city = excluded.city, responsible = excluded.responsible, assistant = excluded.assistant, updated_at = datetime('now')`
    ).run({ key: placeKey(city), city, responsible: input.responsible, assistant: input.assistant });
  },

  upsertMany(rows: { city: string; responsible: string | null; assistant: string | null }[]): void {
    db.exec('BEGIN');
    try {
      for (const r of rows) this.upsert(r);
      db.exec('COMMIT');
    } catch (err) {
      db.exec('ROLLBACK');
      throw err;
    }
  },

  // The list shown to the admin: all provinces, then any other place that has customers or a person.
  withCustomerCounts(): { city: string; responsible: string | null; assistant: string | null; customers: number }[] {
    const have = new Map(this.listAll().map((a) => [a.key, a]));
    const counts = new Map<string, { city: string; n: number }>();
    for (const r of db.prepare("SELECT city, COUNT(*) AS n FROM cards WHERE market = 'domestic' AND city IS NOT NULL AND city != '' GROUP BY city").all() as { city: string; n: number }[]) {
      const k = placeKey(r.city);
      counts.set(k, { city: counts.get(k)?.city ?? r.city, n: (counts.get(k)?.n ?? 0) + r.n });
    }
    const out: { city: string; responsible: string | null; assistant: string | null; customers: number }[] = [];
    const seen = new Set<string>();
    for (const p of PROVINCES) {
      const k = placeKey(p);
      seen.add(k);
      out.push({ city: p, responsible: have.get(k)?.responsible ?? null, assistant: have.get(k)?.assistant ?? null, customers: counts.get(k)?.n ?? 0 });
    }
    for (const [k, c] of counts) if (!seen.has(k)) { seen.add(k); out.push({ city: c.city, responsible: have.get(k)?.responsible ?? null, assistant: have.get(k)?.assistant ?? null, customers: c.n }); }
    for (const [k, a] of have) if (!seen.has(k)) out.push({ city: a.city, responsible: a.responsible, assistant: a.assistant, customers: 0 });
    return out;
  },
};
