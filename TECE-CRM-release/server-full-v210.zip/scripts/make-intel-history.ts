// Makes server/assets/intel/history.json.gz: the summary of the old years of the SAP sales list (ZSD0005), shipped with the CRM.
// Run on a computer that has the yearly Excel files:
//   npx tsx scripts/make-intel-history.ts <through YYYY-MM-DD> <file1.xlsx> <file2.xlsx> ...
// Only complete months up to <through> are kept; the admin uploads the sales list from the 1st of the next month on.
import fs from 'fs';
import path from 'path';
import zlib from 'zlib';
import { parseInChild } from '../src/services/intelParse';
import { aggregateRows, horizonFor } from '../src/services/intelAggregate';

async function main() {
  const [through, ...files] = process.argv.slice(2);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(through ?? '') || !files.length) { console.error('Usage: tsx scripts/make-intel-history.ts <through YYYY-MM-DD> <files...>'); process.exit(1); }
  const all: unknown[][] = []; let skipped = 0;
  for (const f of files) {
    const t = Date.now();
    const out = await parseInChild('sales', fs.readFileSync(f));
    if (out.error) throw new Error(`${f}: ${out.error}`);
    const keep = out.rows.filter((r) => String(r[3]) <= through);
    all.push(...keep); skipped += out.skipped ?? 0;
    console.log(path.basename(f), out.rows.length, 'lines,', keep.length, 'kept,', Math.round((Date.now() - t) / 1000), 's');
  }
  // the same invoice line can only be there once
  const seen = new Set<string>(); const rows = all.filter((r) => { const k = `${r[0]}|${r[1]}|${r[2]}`; if (seen.has(k)) return false; seen.add(k); return true; });
  const agg = aggregateRows(rows, horizonFor(through));
  agg.through = through;
  const out = path.resolve(__dirname, '../assets/intel/history.json.gz');
  fs.mkdirSync(path.dirname(out), { recursive: true });
  fs.writeFileSync(out, zlib.gzipSync(JSON.stringify(agg), { level: 9 }));
  console.log(`lines ${rows.length} (${skipped} mirror invoices left out) -> summary rows: fact ${agg.fact.length}, month ${agg.month.length}, spec ${agg.spec.length}, events ${agg.events.length}, customers ${agg.cust.length}, materials ${agg.mat.length}`);
  console.log('written', out, (fs.statSync(out).size / 1e6).toFixed(2), 'MB');
}
main().catch((e) => { console.error(e); process.exit(1); });
