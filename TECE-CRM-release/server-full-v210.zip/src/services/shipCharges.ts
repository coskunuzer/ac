import { db } from '../db/connection';

// What the forwarder is asked to put into the price. An admin keeps the list; a person ticks the ones that apply to this request.
export interface Charge { id: number; nameTr: string; nameEn: string; defaultOn: boolean; active: boolean }
interface Row { id: number; name_tr: string; name_en: string; default_on: number; active: number }

const SEED: [string, string, number][] = [
  ['Çıkış limanı masrafları (THC, terminal, liman)', 'Loading port charges (THC, terminal, port)', 1],
  ['Fabrikadan (Bursa) çıkış limanına iç taşıma', 'Inland transport from our factory (Bursa) to the port of loading', 1],
  ['İhracat gümrükleme (T1/EX1)', 'Export customs clearance (T1/EX1)', 1],
  ['YDG', 'YDG', 1],
  ['FOB masrafları', 'FOB charges', 1],
  ['Varış limanı masrafları (THC, terminal)', 'Destination port charges (THC, terminal)', 0],
  ['Varış limanından kapıya teslim taşıma', 'Delivery from the destination port to the door', 0],
  ['Navlun sigortası', 'Freight insurance', 0],
];

export function listCharges(): Charge[] {
  if ((db.prepare('SELECT COUNT(*) AS n FROM ship_charges').get() as { n: number }).n === 0) {
    const ins = db.prepare('INSERT INTO ship_charges (name_tr, name_en, default_on, sort) VALUES (?, ?, ?, ?)');
    SEED.forEach((s, i) => ins.run(s[0], s[1], s[2], i));
  }
  return (db.prepare('SELECT * FROM ship_charges ORDER BY sort, id').all() as unknown as Row[]).map((r) => ({ id: r.id, nameTr: r.name_tr, nameEn: r.name_en, defaultOn: !!r.default_on, active: !!r.active }));
}

// the admin's list: rows with an id are updated, rows without one are added, rows left out are switched off (nothing is deleted: old requests keep their words)
export function saveCharges(list: { id?: number | null; nameTr: string; nameEn?: string; defaultOn?: boolean; active?: boolean }[]): Charge[] {
  const seen = new Set<number>();
  list.forEach((c, i) => {
    const tr = String(c.nameTr ?? '').trim().slice(0, 140);
    if (!tr) return;
    const en = String(c.nameEn ?? '').trim().slice(0, 140) || tr;
    if (c.id && db.prepare('SELECT 1 FROM ship_charges WHERE id = ?').get(c.id)) {
      db.prepare('UPDATE ship_charges SET name_tr = ?, name_en = ?, default_on = ?, active = ?, sort = ? WHERE id = ?').run(tr, en, c.defaultOn ? 1 : 0, c.active === false ? 0 : 1, i, c.id);
      seen.add(c.id);
    } else seen.add(Number(db.prepare('INSERT INTO ship_charges (name_tr, name_en, default_on, active, sort) VALUES (?, ?, ?, ?, ?)').run(tr, en, c.defaultOn ? 1 : 0, c.active === false ? 0 : 1, i).lastInsertRowid));
  });
  for (const r of db.prepare('SELECT id FROM ship_charges').all() as { id: number }[]) if (!seen.has(r.id)) db.prepare('UPDATE ship_charges SET active = 0 WHERE id = ?').run(r.id);
  return listCharges();
}

// the lines of the e-mail: the Turkish names are what a request stores; an English firm gets the English words
export function chargeLines(namesTr: string[], en: boolean): string {
  if (!namesTr.length) return '';
  const all = listCharges();
  const names = namesTr.map((n) => (en ? all.find((c) => c.nameTr === n)?.nameEn ?? n : n));
  return (en ? 'Please include the following in your price (all-in):\n' : 'Fiyatınıza aşağıdaki kalemlerin dahil olmasını rica ederiz (all-in):\n') + names.map((n) => `- ${n}`).join('\n');
}
