-- Price performance (the Performance page): the lifetime value of every customer is read straight from this index instead of the whole
-- Sales intelligence summary (40 ms -> 5 ms on 74,000 rows). Nothing in the data changes; the index can be dropped without any effect other than speed.
CREATE INDEX IF NOT EXISTS idx_intel_fact_cust_eur ON intel_fact (customer, eur);
