import { db } from '../db/connection';
import { env } from '../config/env';
import { cardModel, type CardRow } from '../models/cardModel';
import { settingsModel } from '../models/settingsModel';
import { visibilitySql, type Viewer } from './visibility';

// How worth it is it to contact this customer: 0 (not worth the time) to 10 (call them today).
//  - Every customer first gets a quick estimate from what the database and the form say ("rules"): instant, free, so the list can be sorted at once.
//  - Gemini then rates them properly, 20 companies per question, and replaces the estimate ("ai").
// The person's own rating (the 1-10 on the form) is separate and stays as they gave it.

interface Lead {
  tier?: string | null;
  score?: number | null;
  businessType?: string | null;
  salesAngle?: string | null;
  suppliers?: string[];
  tradeValue?: number | null;
}

const FREE_MAIL = /@(gmail|hotmail|outlook|yahoo|live|icloud|yandex|mail|aol|gmx|protonmail|msn)\./i;
const DECIDER = /owner|founder|ceo|president|director|general manager|managing|purchas|procure|buyer|satin ?alma|müdür|mudur|sahibi|genel|import|export/i;

function parse<T>(json: string | null | undefined): T | null {
  try {
    return json ? (JSON.parse(json) as T) : null;
  } catch {
    return null;
  }
}

export function ruleRate(card: CardRow): { rate: number; reason: string } {
  const lead = parse<Lead>(card.lead_info);
  const insight = parse<{ sendOffer?: boolean; products?: string[]; decisionMaker?: boolean | null }>(card.ai_insight);
  let s = 2;
  const why: string[] = [];
  if (lead?.tier) {
    const t = lead.tier.trim().charAt(0).toUpperCase();
    const pts = t === 'A' ? 3.5 : t === 'B' ? 2.5 : t === 'C' ? 1.5 : t === 'D' ? 0.5 : 0;
    s += pts;
    if (pts) why.push(`tier ${t}`);
  }
  if (lead?.score && lead.score > 0) {
    s += Math.min(2.5, (lead.score > 10 ? lead.score / 100 : lead.score / 10) * 2.5);
  }
  if (lead?.tradeValue && lead.tradeValue > 10000) {
    const pts = Math.min(2, Math.log10(lead.tradeValue / 10000) * 0.8);
    s += pts;
    if (pts >= 1) why.push('large trade volume');
  }
  const email = (card.email ?? '').trim();
  if (email) {
    s += FREE_MAIL.test(email) ? 0.6 : 1.1;
    why.push(FREE_MAIL.test(email) ? 'e-mail (free mail)' : 'company e-mail');
  }
  if (card.website) s += 0.5;
  if (DECIDER.test(card.position ?? '') || insight?.decisionMaker) {
    s += 0.7;
    why.push('decision maker');
  }
  if (insight?.sendOffer) {
    s += 1.5;
    why.push('asked for an offer');
  }
  if (insight?.products?.length) s += 0.7;
  if ((card.notes ?? '').trim().length > 20) s += 0.4;
  if (card.stage === 'customer') {
    s += 1;
    why.push('already a customer');
  }
  // a person met them and gave a rating: it counts as much as the estimate
  if (card.rate !== null && card.rate !== undefined && !card.rate_auto) {
    s = s * 0.5 + card.rate * 0.5;
    why.push(`you rated ${card.rate}`);
  }
  if (card.stage === 'lost') s = Math.min(s, 2);
  // only a first guess from what the database says: kept low (it never reaches the top of the scale)
  const rate = Math.max(0, Math.min(6, Math.round(s * 0.55)));
  return { rate, reason: `Estimate: ${why.slice(0, 4).join(', ') || 'little is known yet'}` };
}

// The quick estimates were too generous: once, they are worked out again on the stricter scale (real AI ratings are left alone).
export function rescaleRuleRatings(): number {
  if (settingsModel.get('rules_rescaled_v2') === '1') return 0;
  const rows = db.prepare("SELECT * FROM cards WHERE ai_rate_source = 'rules'").all() as unknown as CardRow[];
  db.exec('BEGIN');
  try {
    for (const r of rows) {
      const x = ruleRate(r);
      cardModel.setAiRate(r.id, x.rate, x.reason, 'rules');
    }
    db.exec('COMMIT');
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
  settingsModel.set('rules_rescaled_v2', '1');
  return rows.length;
}

// Quick estimate for everybody who has no rating yet. Returns how many were rated.
export function rateMissingWithRules(): number {
  const rows = db.prepare('SELECT * FROM cards WHERE ai_rate IS NULL').all() as unknown as CardRow[];
  if (!rows.length) return 0;
  db.exec('BEGIN');
  try {
    for (const r of rows) {
      const x = ruleRate(r);
      cardModel.setAiRate(r.id, x.rate, x.reason, 'rules');
    }
    db.exec('COMMIT');
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
  return rows.length;
}

// ---- Gemini ------------------------------------------------------------------------------------

const GEMINI_URL = 'https://generativelanguage.googleapis.com/v1beta/models';
const MODEL = 'gemini-3.6-flash';
const BATCH = 20;

// The scale is strict on purpose: ratings are not handed out. Most companies are small, so most ratings are low.
export const RATING_SCALE = `How to rate (0-10). Be strict, never generous - most companies get a low number:
- 0: nothing about the company can be found on the web (it probably does not exist), or it is not a customer at all: a competitor, a supplier of ours, a private person, an unrelated business.
- 1: a very small workshop - about 5 workers - or a weak fit.
- 2: a small workshop or factory - about 20 workers.
- 3-4: a medium factory (50-100 workers) or a small distributor.
- 5-6: a large factory, or a distributor that clearly buys edgebanding regularly.
- 7: a big manufacturer or a strong distributor with steady, large purchases.
- 8: the perfect customer: one that buys about one truck of edgebanding a month, and is reachable.
- 9-10: almost never. Only a buyer of several trucks a month that we are already working with.
Weigh the size (workers, trade volume), what they make and buy, how well it fits edgebanding for furniture panels, and whether they can be reached. If little is known, the number is low (1-3), not average.`;

const RUBRIC = `You rate customers of TECE, a Turkish manufacturer of edgebanding (PVC, ABS, PP, melamine and veneer edge tape for furniture panels, plus accessories), for its sales team.
For each company give an integer "rate" from 0 to 10 for how worthwhile it is to contact them and a short "reason" (at most 14 words, English).

${RATING_SCALE}

Also weigh our own notes, the interest they showed, the rating our salesperson gave (if any: it comes from meeting them, trust it), and whether we are already working with them (stage, offers sent). Never invent facts.`;

const SCHEMA = {
  type: 'ARRAY',
  items: {
    type: 'OBJECT',
    properties: { id: { type: 'INTEGER' }, rate: { type: 'INTEGER' }, reason: { type: 'STRING' } },
    required: ['id', 'rate', 'reason'],
  },
};

function compact(card: CardRow, counts: { activities: number; offers: number }) {
  const lead = parse<Lead>(card.lead_info);
  const insight = parse<{ summary?: string | null; companyType?: string | null; sendOffer?: boolean }>(card.ai_insight);
  const cut = (s: string | null | undefined, n: number) => (s ? s.replace(/\s+/g, ' ').trim().slice(0, n) : undefined);
  return {
    id: card.id,
    company: cut(card.company, 80),
    country: card.market === 'domestic' ? `Turkey (${card.city ?? 'city unknown'})` : card.country ?? undefined,
    contact: cut([card.name, card.position].filter(Boolean).join(', '), 70),
    email: card.email ? (FREE_MAIL.test(card.email) ? 'free mail' : 'company domain') : 'none',
    website: card.website ? 'yes' : 'no',
    businessType: cut(lead?.businessType ?? insight?.companyType, 60),
    tier: lead?.tier ?? undefined,
    databaseScore: lead?.score ?? undefined,
    tradeValueUsd: lead?.tradeValue ?? undefined,
    suppliers: lead?.suppliers?.slice(0, 3),
    salesAngle: cut(lead?.salesAngle, 90),
    workArea: cut(card.work_area, 80),
    interested: cut(card.interested_in, 80),
    notes: cut(card.notes ?? insight?.summary, 160),
    salespersonRating: card.rate_auto ? undefined : card.rate ?? undefined,
    stage: card.stage ?? 'met at a fair',
    activities: counts.activities || undefined,
    offersSent: counts.offers || undefined,
  };
}

async function askGemini(cards: CardRow[]): Promise<Map<number, { rate: number; reason: string }>> {
  const out = new Map<number, { rate: number; reason: string }>();
  if (!env.geminiApiKey || !cards.length) return out;
  const ids = cards.map((c) => c.id).join(',');
  const act = new Map((db.prepare(`SELECT card_id, COUNT(*) AS n FROM activities WHERE card_id IN (${ids}) GROUP BY card_id`).all() as { card_id: number; n: number }[]).map((r) => [r.card_id, r.n]));
  const off = new Map((db.prepare(`SELECT card_id, COUNT(*) AS n FROM offers_sent WHERE card_id IN (${ids}) AND kind = 'offer' GROUP BY card_id`).all() as { card_id: number; n: number }[]).map((r) => [r.card_id, r.n]));
  const prompt = `${RUBRIC}\n\nCompanies (JSON):\n${JSON.stringify(cards.map((c) => compact(c, { activities: act.get(c.id) ?? 0, offers: off.get(c.id) ?? 0 })))}`;
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      const res = await fetch(`${GEMINI_URL}/${MODEL}:generateContent`, {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-goog-api-key': env.geminiApiKey },
        body: JSON.stringify({
          contents: [{ role: 'user', parts: [{ text: prompt }] }],
          generationConfig: { responseMimeType: 'application/json', responseSchema: SCHEMA, temperature: 0.2 },
        }),
        signal: AbortSignal.timeout(60000),
      });
      if (!res.ok) {
        if (res.status === 429 || res.status >= 500) {
          await new Promise((r) => setTimeout(r, 2000 * (attempt + 1)));
          continue;
        }
        return out;
      }
      const data = (await res.json()) as { candidates?: { content?: { parts?: { text?: string; thought?: boolean }[] } }[] };
      const parts = data.candidates?.[0]?.content?.parts?.filter((p) => !p.thought && p.text) ?? [];
      const text = parts[parts.length - 1]?.text;
      if (!text) return out;
      const list = JSON.parse(text) as { id?: number; rate?: number; reason?: string }[];
      const wanted = new Set(cards.map((c) => c.id));
      for (const r of Array.isArray(list) ? list : []) {
        if (typeof r.id === 'number' && wanted.has(r.id) && typeof r.rate === 'number') out.set(r.id, { rate: Math.max(0, Math.min(10, Math.round(r.rate))), reason: String(r.reason ?? '').slice(0, 160) });
      }
      return out;
    } catch {
      await new Promise((r) => setTimeout(r, 1500));
    }
  }
  return out;
}

// Rates these customers now (the AI when it can be reached, otherwise the estimate). Returns how many got the AI's rating.
export async function rateCards(ids: number[]): Promise<{ ai: number; rules: number }> {
  let ai = 0;
  let rules = 0;
  for (let i = 0; i < ids.length; i += BATCH) {
    const cards = ids.slice(i, i + BATCH).map((id) => cardModel.findById(id)).filter((c): c is CardRow => !!c);
    const answers = await askGemini(cards);
    for (const c of cards) {
      const a = answers.get(c.id);
      if (a) {
        cardModel.setAiRate(c.id, a.rate, a.reason, 'ai');
        ai += 1;
      } else if (c.ai_rate === null || c.ai_rate_source !== 'ai') {
        const x = ruleRate(c);
        cardModel.setAiRate(c.id, x.rate, x.reason, 'rules');
        rules += 1;
      }
    }
  }
  return { ai, rules };
}

// A customer that was just added or changed: rated in the background, never in the way.
// The quick estimate from the rules (no AI, no cost): every new customer gets this at once.
export function rateOneWithRules(id: number): void {
  const card = cardModel.findById(id);
  if (!card) return;
  const x = ruleRate(card);
  cardModel.setAiRate(id, x.rate, x.reason, 'rules');
}

export function rateInBackground(id: number): void {
  void rateCards([id]).catch((err) => console.error('AI rating failed:', err));
}

// ---- the long job: rate everybody (or everybody this person may see) -----------------------------------

export interface RatingJob {
  running: boolean;
  total: number;
  done: number;
  ai: number;
  rules: number;
  startedAt: string | null;
  finishedAt: string | null;
  scope: 'all' | 'mine';
  hasKey: boolean;
}

let job: RatingJob = { running: false, total: 0, done: 0, ai: 0, rules: 0, startedAt: null, finishedAt: null, scope: 'all', hasKey: !!env.geminiApiKey };

export function ratingStatus(): RatingJob & { rated: number; aiRated: number; cards: number } {
  const c = db.prepare("SELECT COUNT(*) AS n, SUM(CASE WHEN ai_rate IS NOT NULL THEN 1 ELSE 0 END) AS rated, SUM(CASE WHEN ai_rate_source = 'ai' THEN 1 ELSE 0 END) AS ai FROM cards").get() as { n: number; rated: number | null; ai: number | null };
  return { ...job, hasKey: !!env.geminiApiKey, cards: c.n, rated: c.rated ?? 0, aiRated: c.ai ?? 0 };
}

// Starts the job (one at a time). Customers that the AI has not rated yet, the ones that matter most first:
// people we have met or worked with, then the best leads of the database.
export function startRating(scope: 'all' | 'mine', viewer?: Viewer): RatingJob {
  if (job.running) return job;
  rateMissingWithRules();
  const params: Record<string, string | number> = {};
  const vis = scope === 'mine' && viewer ? visibilitySql(viewer, params) : null;
  const cap = scope === 'mine' ? 400 : 1_000_000;
  const ids = (db
    .prepare(
      `SELECT id FROM cards WHERE (ai_rate_source IS NULL OR ai_rate_source != 'ai')${vis ? ` AND ${vis}` : ''}
       ORDER BY CASE WHEN stage = 'lead' THEN 1 ELSE 0 END, COALESCE(rate, 0) DESC, COALESCE(json_extract(lead_info, '$.score'), 0) DESC, id LIMIT ${cap}`
    )
    .all(params) as { id: number }[]).map((r) => r.id);
  job = { running: ids.length > 0 && !!env.geminiApiKey, total: ids.length, done: 0, ai: 0, rules: 0, startedAt: new Date().toISOString(), finishedAt: ids.length && env.geminiApiKey ? null : new Date().toISOString(), scope, hasKey: !!env.geminiApiKey };
  if (!job.running) return job;
  const queue = ids;
  const worker = async () => {
    while (queue.length) {
      const chunk = queue.splice(0, BATCH);
      try {
        const r = await rateCards(chunk);
        job.ai += r.ai;
        job.rules += r.rules;
      } catch (err) {
        console.error('Rating batch failed:', err);
      }
      job.done += chunk.length;
    }
  };
  void Promise.all([worker(), worker(), worker()]).finally(() => {
    job.running = false;
    job.finishedAt = new Date().toISOString();
  });
  return job;
}
