import { AsyncLocalStorage } from 'async_hooks';
import { db } from '../db/connection';
import { aiHooks, env } from '../config/env';
import { settingsModel } from '../models/settingsModel';

// Everything that goes to the AI (Gemini) passes through here: it is counted in tokens, an admin can switch the AI off or give it a daily /
// monthly limit, and when Google refuses (out of budget, key refused) the whole app can say so. The services keep calling fetch() as they
// did; the gate sits in front of that one address.

const HOST = 'generativelanguage.googleapis.com';

interface AiCtx { userId?: number | null; cardId?: number | null; purpose?: string }
const als = new AsyncLocalStorage<AiCtx>();

export const aiContext = {
  // runs `fn` so that every AI call made inside it is attributed to this person / customer / purpose
  run<T>(ctx: AiCtx, fn: () => T): T { return als.run({ ...(als.getStore() ?? {}), ...ctx }, fn); },
  get(): AiCtx { return als.getStore() ?? {}; },
};

// ---- settings ---------------------------------------------------------------------------------------------------------------------
export const DEFAULT_DAY_LIMIT = 3_000_000;
const num = (key: string, fallback: number): number => {
  const n = Number(settingsModel.get(key));
  return settingsModel.get(key) !== null && Number.isFinite(n) && n >= 0 ? n : fallback;
};

export interface AiSettings { enabled: boolean; dayLimit: number; monthLimit: number; priceIn: number; priceOut: number; provider: 'deepseek'; deepseekModel: string }
export const aiSettings = (): AiSettings => ({
  enabled: settingsModel.get('ai_enabled') !== '0',
  dayLimit: num('ai_token_limit_day', DEFAULT_DAY_LIMIT),
  monthLimit: num('ai_token_limit_month', 0),
  priceIn: num('ai_price_in', 0),
  priceOut: num('ai_price_out', 0),
  // DeepSeek is the only AI (Gemini is not used any more). 'deepseek-flash' is the name DeepSeek keeps for its newest Flash model (now V4.1-Flash-1017).
  provider: 'deepseek',
  deepseekModel: settingsModel.get('ai_deepseek_model') || 'deepseek-flash',
});

const deepseekKey = (): string => settingsModel.get('ai_deepseek_key') || process.env.DEEPSEEK_API_KEY || '';
// Is there a key? (the services are told "the AI is there" by a marker; the real key is used only inside this file)
export const aiKeyPresent = (): boolean => !!deepseekKey();
aiHooks.active = () => (deepseekKey() ? 'deepseek' : '');
export const keyInfo = () => ({ hasDeepseekKey: !!deepseekKey() });

export function setAiSettings(patch: Partial<AiSettings> & { deepseekKey?: string }): AiSettings {
  if (typeof patch.deepseekModel === 'string' && /^[\w.-]{2,60}$/.test(patch.deepseekModel.trim())) settingsModel.set('ai_deepseek_model', patch.deepseekModel.trim());
  if (typeof patch.deepseekKey === 'string' && patch.deepseekKey.trim()) settingsModel.set('ai_deepseek_key', patch.deepseekKey.trim() === 'CLEAR' ? '' : patch.deepseekKey.trim());
  if (patch.enabled !== undefined) settingsModel.set('ai_enabled', patch.enabled ? '1' : '0');
  const put = (key: string, v: number | undefined, max: number) => {
    if (v === undefined || !Number.isFinite(v)) return;
    settingsModel.set(key, String(Math.max(0, Math.min(max, Math.round(v * 1000) / 1000))));
  };
  put('ai_token_limit_day', patch.dayLimit, 1e12);
  put('ai_token_limit_month', patch.monthLimit, 1e13);
  put('ai_price_in', patch.priceIn, 1000);
  put('ai_price_out', patch.priceOut, 1000);
  // switching it on again forgets an old complaint of Google
  if (patch.enabled) settingsModel.set('ai_problem', '');
  return aiSettings();
}

// ---- usage ---------------------------------------------------------------------------------------------------------------------------
// Istanbul days: the table keeps UTC, and Istanbul is UTC+3.
const START_TODAY = "datetime(date(datetime('now', '+3 hours')), '-3 hours')";
const START_MONTH = "datetime(strftime('%Y-%m-01', datetime('now', '+3 hours')), '-3 hours')";
const START_7 = "datetime('now', '-7 days')";
const START_30 = "datetime('now', '-30 days')";

export interface Usage { calls: number; failed: number; prompt: number; output: number; total: number }

export function usageSince(startExpr: string | null): Usage {
  const r = db
    .prepare(
      `SELECT COUNT(*) AS calls, COALESCE(SUM(CASE WHEN ok = 0 THEN 1 ELSE 0 END), 0) AS failed,
              COALESCE(SUM(prompt_tokens), 0) AS prompt, COALESCE(SUM(output_tokens + thought_tokens), 0) AS output, COALESCE(SUM(total_tokens), 0) AS total
       FROM ai_calls ${startExpr ? `WHERE created_at >= ${startExpr}` : ''}`
    )
    .get() as unknown as Usage;
  return r;
}
export const usageToday = () => usageSince(START_TODAY);
export const usageMonth = () => usageSince(START_MONTH);

const fmt = (n: number) => new Intl.NumberFormat('en-GB').format(n);

// Why the AI may not be used right now (switched off, or a limit is reached); null when it may.
export function blockedReason(): string | null {
  const s = aiSettings();
  if (!s.enabled) return 'The AI is switched off. An admin stopped it (Admin > AI usage).';
  if (s.dayLimit > 0 && usageToday().total >= s.dayLimit) return `The AI has used its limit for today (${fmt(s.dayLimit)} tokens). It starts again tomorrow, or an admin can raise the limit (Admin > AI usage).`;
  if (s.monthLimit > 0 && usageMonth().total >= s.monthLimit) return `The AI has used its limit for this month (${fmt(s.monthLimit)} tokens). An admin can raise the limit (Admin > AI usage).`;
  return null;
}

// ---- what Google last complained about --------------------------------------------------------------------------------------
export interface AiProblem { kind: 'budget' | 'quota' | 'key'; message: string; at: string }

const PROBLEM_TEXT: Record<AiProblem['kind'], string> = {
  budget: 'The AI is out of budget: the provider refused the request because the account has no credit left. An admin must top up the account of the chosen AI (Admin > AI usage). Meanwhile customers are rated with the simple rules.',
  quota: 'The AI is over its request limit at the provider for the moment. It works again later; meanwhile customers are rated with the simple rules.',
  key: 'The AI provider does not accept the key. An admin must check it (Admin > AI usage).',
};

function classify(status: number, message: string): AiProblem['kind'] | null {
  if (status === 402 || /billing|credit|prepa|spend|budget|payment|exceeded your current quota/i.test(message)) return 'budget';
  if (status === 401 || status === 403 || /api key|permission[_ ]denied|unauthenticated/i.test(message)) return 'key';
  if (status === 429 || /resource[_ ]exhausted|quota|rate limit/i.test(message)) return 'quota';
  return null;
}

function rememberProblem(status: number, message: string): void {
  const kind = classify(status, message);
  if (!kind) return;
  settingsModel.set('ai_problem', JSON.stringify({ kind, message: message.slice(0, 300), at: new Date().toISOString() }));
}
const clearProblem = () => { if (settingsModel.get('ai_problem')) settingsModel.set('ai_problem', ''); };

export function currentProblem(): (AiProblem & { text: string }) | null {
  try {
    const raw = settingsModel.get('ai_problem');
    if (!raw) return null;
    const p = JSON.parse(raw) as AiProblem;
    // an old complaint (more than 12 hours) is not shown any more; the next failed question brings it back
    if (Date.now() - Date.parse(p.at) > 12 * 3600 * 1000) return null;
    return { ...p, text: PROBLEM_TEXT[p.kind] };
  } catch {
    return null;
  }
}

// The sentence to tell a person when an AI action did not work: why (out of budget, stopped, limit reached), else the usual text.
export const aiFailureMessage = (fallback: string): string => blockedReason() ?? currentProblem()?.text ?? fallback;

// What every signed-in person may see: whether the AI works, and if not, why.
export function aiPublicStatus(): { hasKey: boolean; enabled: boolean; blocked: string | null; problem: { kind: string; text: string; at: string } | null } {
  const p = currentProblem();
  return { hasKey: aiKeyPresent(), enabled: aiSettings().enabled, blocked: blockedReason(), problem: p ? { kind: p.kind, text: p.text, at: p.at } : null };
}

// ---- the gate ---------------------------------------------------------------------------------------------------------------------
interface Described { model: string; purpose: string; label: string }

function describe(url: string, body: unknown): Described {
  const model = /models\/([^:/?]+)/.exec(url)?.[1] ?? 'gemini';
  const ctx = aiContext.get();
  let purpose = ctx.purpose ?? 'Text question';
  let label = '';
  try {
    const j = typeof body === 'string' ? JSON.parse(body) : null;
    const parts: { text?: string; inlineData?: unknown; inline_data?: unknown; fileData?: unknown }[] = (j?.contents ?? []).flatMap((c: { parts?: unknown[] }) => c.parts ?? []);
    const text: string = j?.systemInstruction?.parts?.[0]?.text ?? parts.find((p) => p.text)?.text ?? '';
    label = text.replace(/\s+/g, ' ').trim().slice(0, 100);
    if (!ctx.purpose) {
      if (parts.some((p) => p.inlineData || p.inline_data || p.fileData)) purpose = 'Reading a form or card photo';
      else if (Array.isArray(j?.tools) && j.tools.some((t: Record<string, unknown>) => t.google_search || t.googleSearch)) purpose = 'Web search (company check)';
      else if (/translat/i.test(text)) purpose = 'Translation';
      else if (/\brat(e|ing)\b/i.test(text)) purpose = 'Rating';
      else if (/facts?|quote/i.test(text) && /edgebanding/i.test(text)) purpose = 'Reading a web site (company score)';
    }
  } catch {
    // an unreadable body is still counted
  }
  return { model, purpose, label };
}

interface UsageMeta { promptTokenCount?: number; candidatesTokenCount?: number; thoughtsTokenCount?: number; toolUsePromptTokenCount?: number; totalTokenCount?: number }

function record(d: Described, r: { status: number; ok: boolean; prompt?: number; output?: number; thought?: number; total?: number; error?: string | null }): void {
  const ctx = aiContext.get();
  try {
    db.prepare(
      'INSERT INTO ai_calls (user_id, card_id, model, purpose, label, prompt_tokens, output_tokens, thought_tokens, total_tokens, status, ok, error) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    ).run(ctx.userId ?? null, ctx.cardId ?? null, d.model, d.purpose, d.label, r.prompt ?? 0, r.output ?? 0, r.thought ?? 0, r.total ?? 0, r.status, r.ok ? 1 : 0, r.error ? r.error.slice(0, 300) : null);
  } catch (err) {
    console.error('Could not record an AI call', err);
  }
}

// ---- the provider -------------------------------------------------------------------------------------------------------------------
// The services all speak Gemini's request format. With DeepSeek chosen, the request is translated to DeepSeek's (OpenAI-style) chat format here and the
// answer is translated back, so no service has to know which AI is behind it. What DeepSeek cannot do (a Google web search) goes to Gemini when
// a Gemini key is set; otherwise it fails like any other AI failure (nothing is marked, nothing is guessed).
const failure = (status: number, message: string) =>
  new Response(JSON.stringify({ error: { code: status, status: 'AI_UNAVAILABLE', message } }), { status, headers: { 'content-type': 'application/json' } });

interface GPart { text?: string; inlineData?: { mimeType?: string; data?: string }; inline_data?: { mime_type?: string; data?: string } }

// {"items": [...]} -> [...] (also when the AI used another single key, or already answered with a list)
function unwrapList(text: string): string {
  try {
    const j = JSON.parse(text.replace(/^```(?:json)?\s*|\s*```$/g, ''));
    if (Array.isArray(j)) return JSON.stringify(j);
    if (j && typeof j === 'object') {
      if (Array.isArray((j as { items?: unknown }).items)) return JSON.stringify((j as { items: unknown[] }).items);
      const arrays = Object.values(j).filter(Array.isArray);
      if (arrays.length === 1) return JSON.stringify(arrays[0]);
    }
  } catch { /* leave it as it is */ }
  return text;
}

const DEEPSEEK = (): string => process.env.DEEPSEEK_BASE_URL || 'https://api.deepseek.com';

// DeepSeek's own web tools (Search and Fetch API, billed by DeepSeek per request): the AI is given them as two functions and may call them a few times.
async function deepseekTool(key: string, name: string, args: Record<string, unknown>): Promise<string> {
  try {
    if (name === 'web_search') {
      const q = String(args.query ?? '').slice(0, 128);
      const res = await fetch(`${DEEPSEEK()}/v1/tools/search`, { method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${key}` }, body: JSON.stringify({ query: q, count: 5, need_content: false }), signal: AbortSignal.timeout(30000) });
      const data = (await res.json().catch(() => ({}))) as { results?: { title?: string; url?: string; snippet?: string; summary?: string; date?: string | null }[]; error?: { message?: string } };
      if (!res.ok) return `The search failed (${res.status}): ${data.error?.message ?? ''}`;
      return JSON.stringify((data.results ?? []).map((r) => ({ title: r.title, url: r.url, summary: (r.summary || r.snippet || '').slice(0, 240), date: r.date })));
    }
    if (name === 'fetch_page') {
      const res = await fetch(`${DEEPSEEK()}/v1/tools/fetch`, { method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${key}` }, body: JSON.stringify({ url: String(args.url ?? '').slice(0, 2000) }), signal: AbortSignal.timeout(45000) });
      const data = (await res.json().catch(() => ({}))) as { title?: string; content?: string; error?: { message?: string } };
      if (!res.ok) return `The page could not be fetched (${res.status}): ${data.error?.message ?? ''}`;
      return `${data.title ?? ''}\n${(data.content ?? '').slice(0, 12000)}`;
    }
  } catch (err) {
    return `The tool failed: ${err instanceof Error ? err.message : String(err)}`;
  }
  return 'Unknown tool.';
}

const WEB_TOOLS = [
  { type: 'function', function: { name: 'web_search', description: 'Search the web. Returns titles, urls and short summaries. Operators: site:, "phrase", -term.', parameters: { type: 'object', properties: { query: { type: 'string', description: 'at most 128 characters' } }, required: ['query'] } } },
];

async function sendToProvider(original: typeof fetch, _input: Parameters<typeof fetch>[0], init: Parameters<typeof fetch>[1], d: Described): Promise<Response> {
  const s = aiSettings();
  const key = deepseekKey();
  if (!key) return failure(401, 'No DeepSeek key is set (Admin > AI usage).');

  let body: Record<string, unknown> = {};
  try { body = typeof init?.body === 'string' ? JSON.parse(init.body) : {}; } catch { /* sent as it is */ }
  const tools = body.tools as Record<string, unknown>[] | undefined;
  const wantsSearch = Array.isArray(tools) && tools.some((t) => t.google_search || t.googleSearch);

  const messages: { role: string; content?: unknown; tool_calls?: unknown; tool_call_id?: string }[] = [];
  const sys = (body.systemInstruction as { parts?: GPart[] } | undefined)?.parts?.map((p) => p.text ?? '').join('\n');
  if (sys) messages.push({ role: 'system', content: sys });
  for (const c of (body.contents as { role?: string; parts?: GPart[] }[] | undefined) ?? []) {
    const parts = c.parts ?? [];
    const media = parts.filter((p) => p.inlineData || p.inline_data);
    // DeepSeek reads pictures; it cannot hear
    if (media.some((p) => /^audio\//i.test(p.inlineData?.mimeType ?? p.inline_data?.mime_type ?? ''))) return failure(400, 'DeepSeek cannot listen to sound: a voice note is written down in the browser.');
    const text = parts.map((p) => p.text ?? '').filter(Boolean).join('\n');
    const role = c.role === 'model' ? 'assistant' : 'user';
    messages.push({
      role,
      content: media.length
        ? [{ type: 'text', text }, ...media.map((p) => ({ type: 'image_url', image_url: { url: `data:${p.inlineData?.mimeType ?? p.inline_data?.mime_type ?? 'image/jpeg'};base64,${p.inlineData?.data ?? p.inline_data?.data ?? ''}` } }))]
        : text,
    });
  }
  const gen = (body.generationConfig ?? {}) as { responseMimeType?: string; responseSchema?: unknown; temperature?: number; maxOutputTokens?: number };
  const wantsJson = gen.responseMimeType === 'application/json';
  const wantsList = wantsJson && (gen.responseSchema as { type?: string } | undefined)?.type === 'ARRAY';
  if (wantsJson && gen.responseSchema) {
    const last = messages[messages.length - 1];
    const hint = wantsList
      ? `\n\nReply with one JSON object only (no other text): {"items": [ ... ]} where "items" is a list that follows this schema: ${JSON.stringify(gen.responseSchema)}. An empty list is {"items": []}.`
      : `\n\nReply with one JSON object only (no other text) that follows this schema: ${JSON.stringify(gen.responseSchema)}`;
    if (typeof last.content === 'string') last.content += hint;
    else (last.content as { type: string; text?: string }[])[0].text += hint;
  }
  d.model = s.deepseekModel + (wantsSearch ? ' (search)' : '');

  const total = { prompt: 0, completion: 0 };
  let finish: string | undefined;
  let answer = '';
  // with the web tools the AI may search and read pages (at most 5 rounds); without them it is one question
  for (let round = 0; round < (wantsSearch ? 4 : 1); round += 1) {
    const useTools = wantsSearch && round < 2; // two searches at most: every round sends the whole talk again
    const payload = {
      model: s.deepseekModel,
      messages,
      ...(useTools ? { tools: WEB_TOOLS } : {}),
      // JSON mode and tool calls do not go together: JSON is asked for in the last round
      ...(wantsJson && !useTools ? { response_format: { type: 'json_object' } } : {}),
      ...(typeof gen.temperature === 'number' ? { temperature: gen.temperature } : {}),
      ...(gen.maxOutputTokens ? { max_tokens: gen.maxOutputTokens } : {}),
    };
    const res = await original(`${DEEPSEEK()}/chat/completions`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${key}` },
      body: JSON.stringify(payload),
      signal: init?.signal,
    });
    let data: { choices?: { message?: { content?: string; tool_calls?: { id: string; function: { name: string; arguments: string } }[] }; finish_reason?: string }[]; usage?: { prompt_tokens?: number; completion_tokens?: number }; error?: { message?: string } } = {};
    try { data = (await res.json()) as typeof data; } catch { /* no JSON */ }
    if (!res.ok) return failure(res.status, data.error?.message ?? `DeepSeek answered ${res.status}`);
    total.prompt += data.usage?.prompt_tokens ?? 0;
    total.completion += data.usage?.completion_tokens ?? 0;
    const msg = data.choices?.[0]?.message;
    finish = data.choices?.[0]?.finish_reason;
    if (useTools && msg?.tool_calls?.length) {
      messages.push({ role: 'assistant', content: msg.content ?? '', tool_calls: msg.tool_calls });
      for (const call of msg.tool_calls) {
        let args: Record<string, unknown> = {};
        try { args = JSON.parse(call.function.arguments || '{}'); } catch { /* empty */ }
        messages.push({ role: 'tool', tool_call_id: call.id, content: await deepseekTool(key, call.function.name, args) });
      }
      continue;
    }
    answer = msg?.content ?? '';
    if (wantsList) answer = unwrapList(answer);
    // JSON was wanted but the search rounds were free text: one more round asks for the JSON now
    if (wantsJson && useTools) {
      messages.push({ role: 'assistant', content: answer });
      messages.push({ role: 'user', content: 'Now give the final answer as one JSON value only, following the schema above.' });
      continue;
    }
    break;
  }
  return new Response(
    JSON.stringify({
      candidates: [{ content: { parts: [{ text: answer }] }, finishReason: finish === 'length' ? 'MAX_TOKENS' : 'STOP' }],
      usageMetadata: { promptTokenCount: total.prompt, candidatesTokenCount: total.completion, totalTokenCount: total.prompt + total.completion },
    }),
    { status: 200, headers: { 'content-type': 'application/json' } }
  );
}

let installed = false;
export function installAiGate(): void {
  if (installed) return;
  installed = true;
  const original = globalThis.fetch.bind(globalThis);
  globalThis.fetch = (async (input: Parameters<typeof fetch>[0], init?: Parameters<typeof fetch>[1]) => {
    const url = typeof input === 'string' ? input : input instanceof URL ? input.href : (input as Request).url;
    // (GEMINI_BASE_URL points the services at a stand-in of Google when testing)
    const base = process.env.GEMINI_BASE_URL;
    if (!url.includes(HOST) && !(base && url.startsWith(base))) return original(input, init);

    const d = describe(url, init?.body);
    const reason = blockedReason();
    if (reason) {
      // 403, not 429/5xx: the services retry those, and there is nothing to wait for
      record(d, { status: 403, ok: false, error: `blocked: ${reason}` });
      return new Response(JSON.stringify({ error: { code: 403, status: 'AI_STOPPED', message: reason } }), { status: 403, headers: { 'content-type': 'application/json' } });
    }

    let res: Response;
    try {
      res = await sendToProvider(original, input, init, d);
    } catch (err) {
      record(d, { status: 0, ok: false, error: err instanceof Error ? err.message : String(err) });
      throw err;
    }
    // read the answer from a copy, so the service still gets its own
    void (res.clone().json() as Promise<{ usageMetadata?: UsageMeta; error?: { message?: string } }>).then(
      (data) => {
        if (res.ok) {
          const u = data.usageMetadata ?? {};
          const prompt = (u.promptTokenCount ?? 0) + (u.toolUsePromptTokenCount ?? 0);
          const output = u.candidatesTokenCount ?? 0;
          const thought = u.thoughtsTokenCount ?? 0;
          record(d, { status: res.status, ok: true, prompt, output, thought, total: u.totalTokenCount ?? prompt + output + thought });
          clearProblem();
        } else {
          const message = data.error?.message ?? `HTTP ${res.status}`;
          record(d, { status: res.status, ok: false, error: message });
          if ((data as { error?: { status?: string } }).error?.status !== 'AI_UNAVAILABLE') rememberProblem(res.status, message);
        }
      },
      () => record(d, { status: res.status, ok: res.ok })
    );
    return res;
  }) as typeof fetch;
}

// ---- reports for the admin page ------------------------------------------------------------------------------------------------
export function costOf(u: Pick<Usage, 'prompt' | 'output'>, s: AiSettings): number | null {
  if (!s.priceIn && !s.priceOut) return null;
  return (u.prompt * s.priceIn + u.output * s.priceOut) / 1_000_000;
}

export function aiReport() {
  const s = aiSettings();
  const periods = { today: usageSince(START_TODAY), week: usageSince(START_7), month: usageSince(START_MONTH), all: usageSince(null) };
  const cost = Object.fromEntries(Object.entries(periods).map(([k, u]) => [k, costOf(u, s)]));
  const byPurpose = db
    .prepare(
      `SELECT COALESCE(purpose, 'Other') AS purpose, COUNT(*) AS calls, COALESCE(SUM(prompt_tokens), 0) AS prompt, COALESCE(SUM(output_tokens + thought_tokens), 0) AS output, COALESCE(SUM(total_tokens), 0) AS total
       FROM ai_calls WHERE created_at >= ${START_30} GROUP BY purpose ORDER BY total DESC`
    )
    .all();
  const byUser = db
    .prepare(
      `SELECT COALESCE(NULLIF(u.display_name, ''), u.username, 'The system') AS name, COUNT(*) AS calls, COALESCE(SUM(a.total_tokens), 0) AS total
       FROM ai_calls a LEFT JOIN users u ON u.id = a.user_id WHERE a.created_at >= ${START_30} GROUP BY a.user_id ORDER BY total DESC LIMIT 12`
    )
    .all();
  const byDay = db
    .prepare(
      `SELECT date(datetime(created_at, '+3 hours')) AS day, COUNT(*) AS calls, COALESCE(SUM(total_tokens), 0) AS total
       FROM ai_calls WHERE created_at >= ${START_30} GROUP BY day ORDER BY day`
    )
    .all();
  const recent = db
    .prepare(
      `SELECT a.id, a.created_at AS at, a.purpose, a.label, a.model, a.total_tokens AS tokens, a.ok, a.error, COALESCE(NULLIF(u.display_name, ''), u.username) AS user, c.company AS company
       FROM ai_calls a LEFT JOIN users u ON u.id = a.user_id LEFT JOIN cards c ON c.id = a.card_id ORDER BY a.id DESC LIMIT 40`
    )
    .all();
  return { settings: s, keys: keyInfo(), hasKey: aiKeyPresent(), blocked: blockedReason(), problem: currentProblem(), periods, cost, byPurpose, byUser, byDay, recent };
}
