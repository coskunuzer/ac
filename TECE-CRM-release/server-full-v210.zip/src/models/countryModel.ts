import { db } from '../db/connection';
import { memoTables } from '../db/dataVersion';
import { COUNTRY_NAMES } from '../data/countries';

export interface CountryAssignment {
  key: string;
  country: string;
  continent: string | null;
  responsible: string | null;
  assistant: string | null;
  updated_at: string;
}

// Spellings that differ between the country list and the app's own country
// names (or that visitors write differently) - all folded onto one key.
const ALIASES: Record<string, string> = {
  'czech republic': 'czechia',
  macedonia: 'north macedonia',
  kosova: 'kosovo',
  'cape verde': 'cabo verde',
  'east timor': 'timor-leste',
  'timor leste': 'timor-leste',
  usa: 'united states',
  'united states of america': 'united states',
  uk: 'united kingdom',
  'great britain': 'united kingdom',
  uae: 'united arab emirates',
  turkiye: 'turkey',
  "cote d'ivoire": 'ivory coast',
  'cote divoire': 'ivory coast',
  'democratic republic of the congo': 'dr congo',
  drc: 'dr congo',
  swaziland: 'eswatini',
  burma: 'myanmar',
  dominican: 'dominican republic',
  'korea republic of': 'south korea',
  'korea south': 'south korea',
  'russian federation': 'russia',
  'viet nam': 'vietnam',
  'czech rep': 'czechia',
  czech: 'czechia',
  korea: 'south korea',
  'the netherlands': 'netherlands',
  hollanda: 'netherlands',
  macao: 'macau',
  equator: 'ecuador',
  almanya: 'germany',
  kanada: 'canada',
  slovakya: 'slovakia',
  irlanda: 'ireland',
  nijerya: 'nigeria',
  bosnia: 'bosnia and herzegovina',
  dubai: 'united arab emirates',
  shanghai: 'china',
  'birlesik devletler': 'united states',
};

const keyKept = new Map<string, string>();
export function countryKey(name: string): string {
  const hit = keyKept.get(name);
  if (hit !== undefined) return hit;
  const key = countryKeyRaw(name);
  if (keyKept.size > 5000) keyKept.clear();
  keyKept.set(name, key);
  return key;
}
function countryKeyRaw(name: string): string {
  const base = name
    .normalize('NFD')
    .replace(/\p{Diacritic}/gu, '')
    .replace(/ı/g, 'i')
    .toLowerCase()
    .replace(/&/g, ' and ')
    .replace(/\s+/g, ' ')
    .trim();
  return ALIASES[base] ?? base;
}

// One spelling for a country: "USA", "United States of America" and "United States" are the same place, kept as the name of the list
// (so a filter or a total never shows the same country twice).
const CANONICAL = new Map(COUNTRY_NAMES.map((n) => [countryKey(n), n]));
export function canonicalCountry<T extends string | null | undefined>(name: T): T | string {
  if (!name || !name.trim()) return name;
  return CANONICAL.get(countryKey(name)) ?? name.trim();
}

export interface CountryRowInput {
  country: string;
  continent?: string | null;
  responsible: string | null;
  assistant: string | null;
}

// The country list is asked for every customer of a list (who may see it, who looks after it): it is read once and kept until the table changes.
const keptCountries = memoTables(['country_assignments'], () => {
  const rows = db.prepare('SELECT * FROM country_assignments ORDER BY country').all() as unknown as CountryAssignment[];
  return { rows, byKey: new Map(rows.map((r) => [r.key, r])) };
});

export const countryModel = {
  listAll(): CountryAssignment[] {
    return keptCountries().rows.map((r) => ({ ...r }));
  },

  findByCountry(name: string | null | undefined): CountryAssignment | undefined {
    if (!name || !name.trim()) return undefined;
    const r = keptCountries().byKey.get(countryKey(name));
    return r ? { ...r } : undefined;
  },

  upsert(input: CountryRowInput): void {
    db.prepare(
      `INSERT INTO country_assignments (key, country, continent, responsible, assistant, updated_at)
       VALUES (@key, @country, @continent, @responsible, @assistant, datetime('now'))
       ON CONFLICT(key) DO UPDATE SET
         country = excluded.country,
         continent = COALESCE(excluded.continent, country_assignments.continent),
         responsible = excluded.responsible,
         assistant = excluded.assistant,
         updated_at = datetime('now')`
    ).run({
      key: countryKey(input.country),
      country: input.country,
      continent: input.continent ?? null,
      responsible: input.responsible,
      assistant: input.assistant,
    });
  },

  // Several rows at once, all or nothing.
  upsertMany(rows: CountryRowInput[]): void {
    db.exec('BEGIN');
    try {
      for (const r of rows) this.upsert(r);
      db.exec('COMMIT');
    } catch (err) {
      db.exec('ROLLBACK');
      throw err;
    }
  },
};
