// The trip planner, round 2: whose trip it is (a manager looks at the trip of somebody below them, read-only), where the person has really
// been (visited / planned), the notes written on each customer from the trip (saved on the customer, tagged with the trip), and the map that
// opens large. Mounted inside the original TripPage by patch/js/80-trip.js; the page keeps its own state, this module keeps the visits.
import { h, Fragment, useState, useEffect, useRef, api, useT, Icon, cx, errText, todayIso, shortDate, Ring, Chip, toast } from "./x-kit-1W3jRMzJ.js";
import { t as Modal } from "./Modal-GWEoppxZ.js";

// ---- one small shared store: the visits and notes of the open trip (the summary, each customer and the note window read it) ----
const store = { tripId: null, data: null, editing: null, subs: new Set() };
const emit = () => store.subs.forEach((f) => f());
function useStore() {
  const [, force] = useState(0);
  useEffect(() => {
    const f = () => force((x) => x + 1);
    store.subs.add(f);
    return () => store.subs.delete(f);
  }, []);
  return store;
}
async function loadVisits(tripId) {
  try {
    const d = await api.get(`/trips/${tripId}/visits`);
    if (store.tripId === tripId) { store.data = d; emit(); }
  } catch { /* the planner works without it */ }
}

const TYPES = [
  ["note", "Note", "edit-note"],
  ["visit", "Visit", "handshake"],
  ["meeting", "Meeting", "groups"],
];
const typeLabel = (k) => (TYPES.find((x) => x[0] === k) || TYPES[0])[1];
const typeIcon = (k) => (TYPES.find((x) => x[0] === k) || TYPES[0])[2];
const dayOf = (stamp) => (stamp ? shortDate(new Date(stamp.replace(" ", "T") + "Z").toLocaleDateString("en-CA", { timeZone: "Europe/Istanbul" })) : "");
const started = (trip) => !!trip && !!trip.startDate && trip.startDate <= todayIso();
const firstName = (n) => (n || "").split(/\s+/)[0] || n || "";

// ---- above the three columns: whose trip, and where they have been ----
export function TripTop({ trip, stops }) {
  const t = useT();
  const s = useStore();
  const key = (stops || []).map((x) => x.cardId).sort((a, b) => a - b).join(",");
  useEffect(() => {
    if (store.tripId !== trip.id) { store.tripId = trip.id; store.data = null; store.editing = null; }
    const id = setTimeout(() => loadVisits(trip.id), 200);
    return () => clearTimeout(id);
  }, [trip.id, key]);
  useEffect(() => () => { store.tripId = null; store.data = null; store.editing = null; }, []);
  const readOnly = trip.canEdit === false;
  const other = trip.mine === false && trip.ownerName;
  const sum = s.data && s.tripId === trip.id ? s.data.summary : null;
  const visitedNames = sum ? (stops || []).filter((x) => s.data.cards[x.cardId] && s.data.cards[x.cardId].visited).map((x) => x.company || x.name || "") : [];
  const showSum = !!sum && sum.planned > 0 && (readOnly || other || started(trip) || sum.visited > 0 || sum.notes > 0);
  const who = other ? firstName(trip.ownerName) : null;
  return h(Fragment, null,
    other
      ? h("div", { className: cx("xtp-owner", readOnly && "xtp-owner--ro"), role: "note" },
          h(Icon, { n: readOnly ? "visibility" : "person", size: 20 }),
          h("div", null,
            h("b", null, t("{name}'s trip", { name: trip.ownerName })),
            h("span", null, readOnly ? t("You can look at it as their manager. Only {name} can change it.", { name: who }) : t("You are an admin: your changes are saved on their trip.")),
          ),
        )
      : null,
    trip.hiddenStops > 0
      ? h("div", { className: "xtp-owner xtp-hidden", role: "note" },
          h(Icon, { n: "lock", size: 20 }),
          h("div", null,
            h("b", null, trip.hiddenStops === 1 ? t("1 customer on this trip is not shown") : t("{n} customers on this trip are not shown", { n: trip.hiddenStops })),
            h("span", null, t("They are looked after by somebody else (or by your team: switch to Manager mode). They stay on the trip and your changes here do not remove them.")),
          ),
        )
      : null,
    showSum
      ? h("section", { className: "xtp-been", "aria-label": t("Where the trip has been") },
          h(Ring, { value: sum.visited, max: sum.planned, size: 64, tone: sum.visited >= sum.planned ? "good" : undefined, label: t("{a} of {b} visited", { a: sum.visited, b: sum.planned }) }, sum.visited + "/" + sum.planned),
          h("div", { className: "xtp-been-main" },
            h("b", null, who ? t("Where {name} has been", { name: who }) : t("Where you have been")),
            h("div", { className: "xtp-been-nums" },
              h("span", null, h("b", null, sum.visited), t("of {n} customers visited", { n: sum.planned })),
              h("span", null, h("b", null, sum.countriesVisited.length), t("of {n} countries", { n: sum.countries.length })),
              sum.days ? h("span", null, h("b", null, sum.daysVisited), t("of {n} days with a visit", { n: sum.days })) : null,
              h("span", null, h("b", null, sum.notes), sum.notes === 1 ? t("note from the trip") : t("notes from the trip")),
            ),
            visitedNames.length
              ? h("div", { className: "xtp-been-list" }, visitedNames.slice(0, 10).map((n, i) => h("span", { key: i }, h(Icon, { n: "check", size: 16 }), n)), visitedNames.length > 10 ? h("span", { className: "xtp-more" }, "+" + (visitedNames.length - 10)) : null)
              : h("p", { className: "xtp-muted" }, t("No visit, meeting or note on these customers during the trip yet.")),
          ),
        )
      : null,
    s.editing ? h(NoteWindow, { trip, edit: s.editing, onClose: () => { store.editing = null; emit(); } }) : null,
  );
}

// ---- under each customer of a day: visited or not, the notes from the trip, and "Note" ----
export function TripStopNotes({ tripId, cardId, canEdit, name, trip }) {
  const t = useT();
  const s = useStore();
  const [open, setOpen] = useState(false);
  const info = s.data && s.tripId === tripId ? s.data.cards[cardId] : null;
  const notes = info ? info.notes : [];
  const stop = (e) => e.stopPropagation();
  const last = notes[notes.length - 1];
  const shown = open ? notes.slice().reverse() : last ? [last] : [];
  if (!info && !canEdit) return null;
  return h("div", { className: "xtp-stopbar", onClick: stop },
    h("div", { className: "xtp-stopbar-row" },
      info && info.visited
        ? h(Chip, { tone: "good", icon: "check-circle", title: info.how ? t(typeLabel(info.how)) : undefined }, t("Visited"), info.at ? " · " + dayOf(info.at) : "")
        : started(trip) ? h(Chip, null, t("Not visited yet")) : null,
      notes.length > 1 ? h("button", { type: "button", className: "xtp-link", onClick: () => setOpen(!open), "aria-expanded": open }, open ? t("Show less") : t("{n} notes", { n: notes.length })) : null,
      canEdit ? h("button", { type: "button", className: "tc-btn tc-btn--sm tc-btn--ghost xtp-note-btn", onClick: () => { store.editing = { cardId, name }; emit(); }, "aria-label": t("Write a note on {name}", { name: name || "" }) }, h(Icon, { n: "edit-note", size: 16 }), t("Note")) : null,
    ),
    shown.map((n) =>
      h("p", { key: n.id, className: "xtp-note", "data-kind": n.type },
        h("span", { className: "xtp-note-kind" }, h(Icon, { n: typeIcon(n.type), size: 16 }), t(typeLabel(n.type))),
        h("small", null, dayOf(n.at), n.userName ? " · " + n.userName : ""),
        h("span", { className: "xtp-note-text" }, n.text),
      ),
    ),
  );
}

// the window to write a note, a visit or a meeting on one customer of the trip
function NoteWindow({ trip, edit, onClose }) {
  const t = useT();
  const s = useStore();
  const [type, setType] = useState(started(trip) ? "visit" : "note");
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState(null);
  const sending = useRef(false); // a double press saves the note once
  const info = s.data ? s.data.cards[edit.cardId] : null;
  async function save(e) {
    e.preventDefault();
    if (sending.current) return;
    if (!text.trim()) { setErr(t("Write something first.")); return; }
    sending.current = true;
    setBusy(true);
    setErr(null);
    try {
      const d = await api.post(`/trips/${trip.id}/notes`, { cardId: edit.cardId, type, text: text.trim() });
      if (store.tripId === trip.id) store.data = d;
      toast(t("Saved on the customer, with the trip as its tag."), "good");
      onClose();
      emit();
    } catch (e2) {
      setErr(errText(e2, t("Could not save")));
      setBusy(false);
      sending.current = false;
    }
  }
  return h(Modal, { title: t("Note on {name}", { name: edit.name || "" }), onClose, dirty: !!text.trim(), size: "md" },
    h("form", { className: "xtp-form", onSubmit: save },
      h("p", { className: "xtp-muted" }, h(Icon, { n: "luggage", size: 16 }), t("Saved on the customer's page with the tag “Trip: {title}”.", { title: trip.title })),
      h("div", { className: "xtp-seg", role: "radiogroup", "aria-label": t("What was it?") },
        TYPES.map(([k, label, ic]) => h("button", { key: k, type: "button", role: "radio", "aria-checked": type === k, className: cx("xtp-seg-btn", type === k && "is-on"), onClick: () => setType(k) }, h(Icon, { n: ic, size: 16 }), t(label))),
      ),
      h("textarea", { className: "xtp-text", rows: 5, value: text, onChange: (e) => setText(e.target.value), placeholder: type === "note" ? t("What should be remembered about this customer?") : t("Who did you meet, what did they say, what comes next?"), "aria-label": t("Note") }),
      err ? h("p", { className: "tx-err", role: "alert" }, err) : null,
      h("div", { className: "xtp-form-foot" },
        h("button", { type: "button", className: "tc-btn tc-btn--md tc-btn--ghost", onClick: onClose }, t("Cancel")),
        h("button", { type: "submit", className: "tc-btn tc-btn--md", disabled: busy || !text.trim() }, busy ? t("Saving ...") : t("Save the note")),
      ),
      info && info.notes.length
        ? h("div", { className: "xtp-prev" }, h("b", null, t("Written from this trip")), info.notes.slice().reverse().map((n) => h("p", { key: n.id, className: "xtp-note", "data-kind": n.type }, h("span", { className: "xtp-note-kind" }, h(Icon, { n: typeIcon(n.type), size: 16 }), t(typeLabel(n.type))), h("small", null, dayOf(n.at), n.userName ? " · " + n.userName : ""), h("span", { className: "xtp-note-text" }, n.text))))
        : null,
    ),
  );
}

// ---- the map: small beside the days, "Expand" opens it large over the page (Leaflet is told the new size) ----
export function MapTools() {
  const t = useT();
  const ref = useRef(null);
  const [big, setBig] = useState(false);
  useEffect(() => {
    const col = ref.current && ref.current.closest(".trip-mapcol");
    if (!col) return undefined;
    col.classList.toggle("is-big", big);
    document.body.classList.toggle("xtp-noscroll", big);
    // the map watches its own size; a resize event as well, for the tiles that were not drawn yet
    const k = [60, 260].map((ms) => setTimeout(() => window.dispatchEvent(new Event("resize")), ms));
    const esc = (e) => { if (e.key === "Escape") setBig(false); };
    if (big) document.addEventListener("keydown", esc);
    return () => { k.forEach(clearTimeout); document.removeEventListener("keydown", esc); };
  }, [big]);
  useEffect(() => () => document.body.classList.remove("xtp-noscroll"), []);
  return h("button", { ref, type: "button", className: "tc-btn tc-btn--sm tc-btn--secondary xtp-mapbtn", onClick: () => setBig(!big), "aria-pressed": big },
    h(Icon, { n: big ? "close" : "map", size: 16 }), big ? t("Shrink") : t("Expand"));
}
