import { db } from '../db/connection';
import { countryKey } from '../models/countryModel';
import { cityKey } from '../models/cityModel';
import { cardModel } from '../models/cardModel';
import { accessOf, visibilityFor, type Viewer } from './visibility';
import { peekSearch, type PeekDoc, type PeekHit } from './smartSearch';
import { companyKey } from './companyKey';
import { todoModel, todayIstanbul } from './todos';

// A look (view only) at the customers of my own countries that carry another person's name - so a salesperson exploring a country sees that a
// company is already somebody's customer, and does not record it again under a slightly different name. The normal rule (services/visibility.ts)
// is not changed: the customer page and everything that writes still say no. This is a separate, limited, read-only summary.
//
// Who may look: the countries a person is responsible for (country_assignments) plus the countries/markets an admin granted them, the cities for
// a domestic person - the same market rule as visibility.ts (an export person never looks at a domestic customer and the other way round).
// What is shown: the company, its place, its web site, where it stands (lead / prospect / existing customer), who looks after it, when it was last
// contacted (the date only), its orders and sales and the number of open offers. Never its e-mails, phones, address, contact people, notes,
// prices, files or the texts of its history - those belong to the colleague who looks after it.

type Card = PeekDoc;

// 'full': the viewer sees it normally; 'peek': only this summary; null: nothing
export function peekRule(viewer: Viewer): (c: Card) => 'full' | 'peek' | null {
  if (viewer.role === 'admin') return () => 'full';
  const visible = visibilityFor(viewer);
  const a = accessOf(viewer);
  return (c) => {
    if (visible({ uploaded_by: c.uploaded_by ?? 0, person: c.person, country: c.country, status: c.status as never, market: c.market, city: c.city, owner_override: c.owner_override })) return 'full';
    if (c.status === 'needs_review') return null; // a scan somebody has not confirmed yet is theirs
    const market = c.market === 'domestic' ? 'domestic' : 'export';
    if (a.markets.has(market)) return 'peek';
    if (market === 'domestic') return c.city && a.cities.has(cityKey(c.city)) ? 'peek' : null;
    return c.country && a.countries.has(countryKey(c.country)) ? 'peek' : null;
  };
}

// the view-only part of a search: what I may only look at
export function peekHits(viewer: Viewer, q: string, limit: number, opts: { minScore?: number; country?: string } = {}): PeekHit[] {
  if (viewer.role === 'admin') return [];
  const a = accessOf(viewer);
  if (!a.markets.size && !a.countries.size && !a.cities.size) return []; // no country, city or market: nothing to look at
  const rule = peekRule(viewer);
  const ck = opts.country ? countryKey(opts.country) : null;
  return peekSearch(q, limit, (d) => rule(d) === 'peek', { minScore: opts.minScore, inCountry: ck ? (c) => !!c && countryKey(c) === ck : undefined });
}

// what: a short readable line (the "Changes" list of the customer shows it to the person who looks after it); note: the detail.
// The same look by the same person within 30 minutes is written once, so the change history of a customer is not filled with looks.
export function logPeek(actor: { id: number; display_name?: string | null; username?: string | null }, cardId: number | null, note: string, what = 'Looked at it (view only)'): void {
  try {
    const n = note.slice(0, 300);
    const seen = db.prepare("SELECT 1 FROM audit_log WHERE action = 'peek' AND user_id = ? AND card_id IS ? AND note = ? AND at >= datetime('now', '-30 minutes') LIMIT 1").get(actor.id, cardId, n);
    if (seen) return;
    db.prepare("INSERT INTO audit_log (user_id, user_name, card_id, action, field, old_value, new_value, note) VALUES (?, ?, ?, 'peek', NULL, NULL, ?, ?)")
      .run(actor.id, actor.display_name || actor.username || null, cardId, what, n);
  } catch (err) { console.error('Peek log failed:', err); }
}

const year = () => Number(todayIstanbul().slice(0, 4));
const one = <T>(sql: string, ...p: (string | number)[]): T | undefined => { try { return db.prepare(sql).get(...p) as T | undefined; } catch { return undefined; } };

export interface PeekSummary {
  id: number; viewOnly: true; company: string | null; country: string | null; city: string | null; website: string | null;
  status: 'existing' | 'prospect' | 'lead' | 'lost'; stage: string | null; sap: string | null;
  owner: string | null; ownerIsUser: boolean; lastContact: string | null; contacts12m: number;
  orders: { count: number | null; first: string | null; last: string | null; lifetimeEur: number | null; thisYearEur: number | null; lastYearEur: number | null; activity: string | null; year: number; money: boolean };
  openOffers: number; offersSent: number; lastOffer: string | null;
}

export function peekSummary(cardId: number, viewer: Viewer, showMoney = true): { kind: 'none' } | { kind: 'full' } | { kind: 'peek'; data: PeekSummary } {
  const c = cardModel.findById(cardId);
  if (!c) return { kind: 'none' };
  const r = peekRule(viewer)(c as unknown as Card);
  if (r === 'full') return { kind: 'full' };
  if (r !== 'peek') return { kind: 'none' };
  const sap = (c.sap ?? '').trim() || null;
  const y = year();
  const sc = sap ? one<{ orders: number | null; first_order: string | null; last_order: string | null; net_eur: number | null; status_key: string | null }>('SELECT orders, first_order, last_order, net_eur, status_key FROM sap_customers WHERE sap_no = ?', sap) : undefined;
  // the sales of the performance pages (SAP sales lines, a year = 'YYYY-MM' months or one 'YYYY-00' line for the older years)
  const sales = (yy: number) => (sap ? one<{ eur: number | null }>("SELECT SUM(eur) eur FROM intel_fact WHERE customer = ? AND substr(period, 1, 4) = ?", sap, String(yy))?.eur ?? null : null);
  const last = one<{ at: string | null }>("SELECT MAX(created_at) at FROM activities WHERE card_id = ? AND type IN ('note','call','visit','meeting','email','whatsapp','sample','offer','documents')", c.id)?.at ?? null;
  const n12 = one<{ n: number }>("SELECT COUNT(*) n FROM activities WHERE card_id = ? AND created_at >= datetime('now', '-12 months')", c.id)?.n ?? 0;
  const open = one<{ n: number }>("SELECT COUNT(*) n FROM opportunities WHERE card_id = ? AND status = 'open'", c.id)?.n ?? 0;
  const sent = one<{ n: number; at: string | null }>('SELECT COUNT(*) n, MAX(sent_at) at FROM offers_sent WHERE card_id = ?', c.id) ?? { n: 0, at: null };
  const owner = (c.person ?? '').trim() || null;
  const ownerIsUser = !!owner && !!one<{ id: number }>('SELECT id FROM users WHERE display_name = ? AND is_active = 1', owner);
  const existing = c.stage === 'customer' || !!sap || (sc?.orders ?? 0) > 0;
  const status = existing ? 'existing' : c.stage === 'lost' ? 'lost' : c.stage && c.stage !== 'lead' ? 'prospect' : 'lead';
  // the money figures follow the 'Sales figures' switch of the person (Permissions page), like the performance pages
  const thisYear = showMoney ? sales(y) : null; const lastYear = showMoney ? sales(y - 1) : null;
  return {
    kind: 'peek',
    data: {
      id: c.id, viewOnly: true, company: c.company || c.name, country: c.country, city: c.city, website: c.website ?? null,
      status, stage: c.stage ?? null, sap, owner, ownerIsUser, lastContact: last ? last.slice(0, 10) : null, contacts12m: n12,
      orders: { count: sc?.orders ?? null, first: sc?.first_order ?? null, last: sc?.last_order ?? null, lifetimeEur: showMoney ? sc?.net_eur ?? null : null, thisYearEur: thisYear, lastYearEur: lastYear, activity: sc?.status_key ?? null, year: y, money: showMoney },
      openOffers: open, offersSent: sent.n, lastOffer: sent.at ? sent.at.slice(0, 10) : null,
    },
  };
}

// before a new customer is saved: the customers of my countries with the same company, e-mail or phone that I may only look at
export function peekCheck(viewer: Viewer, input: { company?: string; email?: string; phone?: string }): PeekHit[] {
  if (viewer.role === 'admin') return [];
  const rule = peekRule(viewer);
  const out = new Map<number, PeekHit>();
  const add = (id: number, why: string) => {
    if (out.has(id) || out.size >= 5) return;
    const c = cardModel.findById(id);
    if (!c || rule(c as unknown as Card) !== 'peek') return;
    out.set(id, { id, company: c.company || c.name, country: c.country, city: c.city, stage: c.stage ?? null, existing: c.stage === 'customer' || !!(c.sap ?? '').trim(), owner: (c.person ?? '').trim() || null, score: 1000, why });
  };
  const company = (input.company ?? '').trim();
  if (company.length >= 3) {
    for (const r of db.prepare('SELECT id FROM cards WHERE company_key = ? LIMIT 20').all(companyKey(company)) as { id: number }[]) add(r.id, 'Company');
    for (const h of peekHits(viewer, company, 5, { minScore: 680 })) if (!out.has(h.id) && out.size < 5) out.set(h.id, { ...h, why: 'Company' });
  }
  const email = (input.email ?? '').trim().toLowerCase().split(/[,;\s]+/)[0] ?? '';
  if (email.includes('@') && email.length >= 6) {
    for (const r of db.prepare('SELECT id FROM cards WHERE LOWER(email) = ? UNION SELECT card_id FROM card_contacts WHERE LOWER(email) = ? LIMIT 20').all(email, email) as { id: number }[]) add(r.id, 'E-mail');
  }
  const phone = (input.phone ?? '').replace(/\D/g, '').slice(-9);
  if (phone.length >= 7) {
    for (const h of peekHits(viewer, phone, 5, { minScore: 700 })) if (!out.has(h.id) && out.size < 5) out.set(h.id, { ...h, why: 'Phone' });
  }
  return [...out.values()];
}

// "Ask <Name>": a to-do in the list of the colleague who looks after the customer (or of the admins, when nobody does)
export function askOwner(cardId: number, viewer: Viewer, actorName: string, message: string): { to: string[] } | null {
  const s = peekSummary(cardId, viewer);
  if (s.kind !== 'peek') return null;
  const d = s.data;
  const users = d.owner && d.ownerIsUser
    ? (db.prepare('SELECT id, display_name FROM users WHERE display_name = ? AND is_active = 1').all(d.owner) as { id: number; display_name: string }[])
    : (db.prepare("SELECT id, display_name FROM users WHERE role = 'admin' AND is_active = 1").all() as { id: number; display_name: string }[]);
  const text = `${actorName} asks about ${d.company ?? `#${d.id}`}${message ? `: ${message}` : ' (looked at it in their country)'}`.slice(0, 300);
  for (const u of users) todoModel.add({ userId: u.id, cardId: d.id, text, dueDate: todayIstanbul() });
  return { to: users.map((u) => u.display_name) };
}
