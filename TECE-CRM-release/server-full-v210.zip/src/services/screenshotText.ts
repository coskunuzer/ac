import sharp from 'sharp';
import { askJsonParts } from './noteAssist';

// A screenshot pasted into a chat box (the assistant, a customer's e-mail) is read once into plain text, and the rest of the work uses the text. One small vision call for
// all the pictures together, so it stays cheap.
export interface Shot { data: Buffer; mime: string }

export async function screenshotText(images: Shot[], hint: string): Promise<string | null> {
  const shots = await Promise.all(images.slice(0, 4).map(async (i) => {
    try { return { data: await sharp(i.data).rotate().resize({ width: 1800, height: 2600, fit: 'inside', withoutEnlargement: true }).jpeg({ quality: 82 }).toBuffer(), mime: 'image/jpeg' }; }
    catch { return null; }
  }));
  const ok = shots.filter((s) => s !== null) as { data: Buffer; mime: string }[];
  if (!ok.length) return null;
  const j = await askJsonParts([
    { text: `Copy all the text that is readable in these screenshots, in the order it appears, exactly as written (do not translate, do not summarise). Keep names, numbers, prices and dates. If it is a table, write one line per row with the cells separated by " | ". ${hint}\nAnswer as JSON: text.` },
    ...ok.map((i) => ({ inlineData: { mimeType: i.mime, data: i.data.toString('base64') } })),
  ], { type: 'OBJECT', properties: { text: { type: 'STRING' } }, required: ['text'] }, 0);
  const text = String(j?.text ?? '').trim();
  return text ? text.slice(0, 9000) : null;
}
