import { db } from '../db/connection';
import { visibilitySql, type Viewer } from './visibility';

// The budget of one trip or one fair: what is planned per kind of cost, what was spent (the expenses of the marketing budget that carry the
// trip or the fair), and what that means per customer visited / per person met.
export type EventKind = 'trip' | 'exhibition';
export interface EventCategory { key: string; label: string; grp: string; item: string }

// each kind of cost books on a line of the marketing budget sheet, so the report of the marketing budget stays complete without typing anything twice
const VISITS = 'Müşterilere Özel Çalışmalar';
const FAIRS = 'Fuarlar Giderleri';
export const EVENT_CATEGORIES: Record<EventKind, EventCategory[]> = {
  trip: [
    { key: 'flights', label: 'Flights', grp: VISITS, item: 'Müşteri Ziyaretleri' },
    { key: 'hotel', label: 'Hotel', grp: VISITS, item: 'Müşteri Ziyaretleri' },
    { key: 'transport', label: 'Car, taxi, train', grp: VISITS, item: 'Müşteri Ziyaretleri' },
    { key: 'meals', label: 'Meals', grp: VISITS, item: 'Müşteri Ziyaretleri' },
    { key: 'hosting', label: 'Customer dinners and gifts', grp: VISITS, item: 'Konuk Ağırlama' },
    { key: 'visa', label: 'Visa and insurance', grp: VISITS, item: 'Müşteri Ziyaretleri' },
    { key: 'other', label: 'Other', grp: VISITS, item: 'Müşteri Ziyaretleri' },
  ],
  exhibition: [
    { key: 'stand', label: 'Stand rent and sponsorship', grp: FAIRS, item: 'Stant ve Sponsorluk Bedeli' },
    { key: 'build', label: 'Stand design and build', grp: FAIRS, item: 'Fuar Stant Giderleri (tasarım ve üretim / stant giydirmeleri)' },
    { key: 'logistics', label: 'Logistics', grp: FAIRS, item: 'Lojistik Giderler' },
    { key: 'travel', label: 'Flights and hotel of the team', grp: FAIRS, item: 'Fuar Ekibi İaşe Giderleri' },
    { key: 'meals', label: 'Meals of the team', grp: FAIRS, item: 'Fuar Ekibi İaşe Giderleri' },
    { key: 'promo', label: 'Samples, catalogues, gifts', grp: FAIRS, item: 'Promosyon & İkram' },
    { key: 'fees', label: 'Customs and official fees', grp: FAIRS, item: 'Fuar Diğer Giderler (gümrük, resmi prosedür vs)' },
    { key: 'other', label: 'Other', grp: FAIRS, item: 'Diğer' },
  ],
};
// the kind of document a cost is proven with (what Turquality asks for, per trip / fair)
export const DOC_TYPES = ['invoice', 'payment', 'ticket', 'hotel', 'other'] as const;
export type DocType = (typeof DOC_TYPES)[number];
export const DOC_LABEL: Record<DocType, string> = { invoice: 'Invoice', payment: 'Payment proof', ticket: 'Boarding pass / ticket', hotel: 'Hotel bill', other: 'Other document' };
export const docTypeOf = (v: unknown): DocType | null => (DOC_TYPES as readonly string[]).includes(String(v)) ? (v as DocType) : null;
export const isEventKind = (v: unknown): v is EventKind => v === 'trip' || v === 'exhibition';
export const categoryOf = (kind: EventKind, key: string): EventCategory | undefined => EVENT_CATEGORIES[kind].find((c) => c.key === key);

// an expense typed in the old way (no kind of cost): its budget line says which kind it most likely is
function guessCategory(kind: EventKind, grp: string, item: string, description: string | null): string {
  const text = `${item} ${description ?? ''}`.toLocaleLowerCase('tr');
  if (kind === 'trip') {
    if (/uçak|flight|bilet|airline|thy|pegasus/.test(text)) return 'flights';
    if (/otel|hotel|konaklama/.test(text)) return 'hotel';
    if (/taksi|taxi|araç|car|rent|tren|train|otopark|yakıt|fuel/.test(text)) return 'transport';
    if (/yemek|meal|restaurant|lokanta|dinner|lunch/.test(text)) return item === 'Konuk Ağırlama' ? 'hosting' : 'meals';
    if (/vize|visa|sigorta|insurance/.test(text)) return 'visa';
    return item === 'Konuk Ağırlama' ? 'hosting' : 'other';
  }
  const exact = EVENT_CATEGORIES.exhibition.find((c) => c.grp === grp && c.item === item);
  if (exact && exact.key !== 'travel' && exact.key !== 'other') return exact.key;
  if (/yemek|meal|restaurant|dinner|lunch/.test(text)) return 'meals';
  if (exact) return exact.key;
  // an old line name that is not on the sheet (Stand Kirası, Konaklama ...): the words tell the kind
  if (/stand kira|stant kira|kira|rent|sponsor/.test(text)) return 'stand';
  if (/yapım|yapim|tasarım|construction|build|design|giydirme/.test(text)) return 'build';
  if (/lojistik|nakliye|kargo|logistic|shipping|transport/.test(text)) return 'logistics';
  if (/uçak|flight|bilet|otel|hotel|konaklama|taksi|taxi/.test(text)) return 'travel';
  if (/numune|katalog|promosyon|ikram|hediye|sample|catalog|gift/.test(text)) return 'promo';
  if (/gümrük|customs|harç|resmi|fee/.test(text)) return 'fees';
  return 'other';
}
// the kind of cost a row shows: the one it was typed with, else the guess from its budget line
export const rowCategory = (kind: EventKind, r: { event_category: string | null; grp: string; item: string; description: string | null }): string =>
  r.event_category && EVENT_CATEGORIES[kind].some((c) => c.key === r.event_category) ? r.event_category : guessCategory(kind, r.grp, r.item, r.description);

const r2 = (v: number) => Math.round(v * 100) / 100;
interface ExpRow { id: number; spent_on: string; grp: string; item: string; supplier: string | null; description: string | null; currency: string; amount: number; amount_try: number; amount_eur: number; event_category: string | null; file_path: string | null; file_name: string | null; entered_name: string | null; invoice_no: string | null; entered_by: number; doc_type: string | null; turquality: number | null; rate: number | null }

export interface EventBudget {
  kind: EventKind; id: number; title: string; from: string | null; to: string | null;
  categories: { key: string; label: string; planned: number; spent: number; note: string | null }[];
  planned: number; spent: number; spentTry: number; left: number; pct: number | null; over: boolean;
  rows: { id: number; date: string; category: string; supplier: string | null; description: string | null; invoiceNo: string | null; currency: string; amount: number; eur: number; try: number; hasFile: boolean; by: string | null;
    byId: number; rate: number | null; docType: DocType; turquality: boolean; fileName: string | null; files: { id: number; docType: DocType; name: string | null }[] }[];
  // what the money bought
  units: { label: string; n: number; each: number | null }[];
}

export function eventTitle(kind: EventKind, id: number): { title: string; from: string | null; to: string | null; ownerId: number | null } | null {
  if (kind === 'trip') {
    const t = db.prepare('SELECT title, start_date, end_date, user_id FROM trips WHERE id = ?').get(id) as { title: string; start_date: string | null; end_date: string | null; user_id: number } | undefined;
    return t ? { title: t.title, from: t.start_date, to: t.end_date, ownerId: t.user_id } : null;
  }
  const e = db.prepare('SELECT name, start_date, end_date FROM exhibitions WHERE id = ?').get(id) as { name: string; start_date: string | null; end_date: string | null } | undefined;
  return e ? { title: e.name, from: e.start_date, to: e.end_date, ownerId: null } : null;
}

export function eventBudget(kind: EventKind, id: number, viewer?: Viewer): EventBudget | null {
  const head = eventTitle(kind, id);
  if (!head) return null;
  const plan = db.prepare('SELECT category, planned_eur, note FROM event_budgets WHERE kind = ? AND ref_id = ?').all(kind, id) as unknown as { category: string; planned_eur: number; note: string | null }[];
  const col = kind === 'trip' ? 'trip_id' : 'exhibition_id';
  const exp = db.prepare(`SELECT e.id, e.spent_on, e.grp, e.item, e.supplier, e.description, e.currency, e.amount, e.amount_try, e.amount_eur, e.event_category, e.file_path, e.file_name, e.invoice_no, e.entered_by, e.doc_type, e.turquality, e.rate, u.display_name AS entered_name
    FROM budget_expenses e LEFT JOIN users u ON u.id = e.entered_by WHERE e.${col} = ? ORDER BY e.spent_on, e.id`).all(id) as unknown as ExpRow[];
  const extra = new Map<number, { id: number; docType: DocType; name: string | null }[]>();
  if (exp.length) {
    for (const f of db.prepare(`SELECT id, expense_id, doc_type, file_name FROM budget_expense_files WHERE expense_id IN (${exp.map(() => '?').join(',')}) ORDER BY id`).all(...exp.map((r) => r.id)) as unknown as { id: number; expense_id: number; doc_type: string; file_name: string | null }[]) {
      const l = extra.get(f.expense_id) ?? []; l.push({ id: f.id, docType: docTypeOf(f.doc_type) ?? 'other', name: f.file_name }); extra.set(f.expense_id, l);
    }
  }
  const cats = EVENT_CATEGORIES[kind];
  const catOf = (r: ExpRow) => rowCategory(kind, r);
  const spentBy = new Map<string, number>();
  for (const r of exp) { const k = catOf(r); spentBy.set(k, (spentBy.get(k) ?? 0) + r.amount_eur); }
  const categories = cats.map((c) => { const p = plan.find((x) => x.category === c.key); return { key: c.key, label: c.label, planned: r2(p?.planned_eur ?? 0), spent: r2(spentBy.get(c.key) ?? 0), note: p?.note ?? null }; });
  const planned = r2(categories.reduce((s, c) => s + c.planned, 0));
  const spent = r2(exp.reduce((s, r) => s + r.amount_eur, 0));
  const units: EventBudget['units'] = [];
  const per = (n: number) => (n > 0 && spent > 0 ? r2(spent / n) : null);
  if (kind === 'trip') {
    // the customers of the trip the person looking sees (the same count as the trip page)
    const p: Record<string, string | number> = { trip: id };
    const vis = viewer ? visibilitySql(viewer, p) : null;
    const n = (db.prepare(`SELECT COUNT(DISTINCT ts.card_id) AS n FROM trip_stops ts JOIN cards ON cards.id = ts.card_id WHERE ts.trip_id = @trip${vis ? ` AND ${vis}` : ''}`).get(p) as { n: number }).n;
    units.push({ label: 'customers on the trip', n, each: per(n) });
  } else {
    const n = (sql: string) => (db.prepare(sql).get(id) as { n: number }).n;
    const met = n('SELECT COUNT(*) AS n FROM cards WHERE exhibition_id = ?');
    const offers = n("SELECT COUNT(DISTINCT c.id) AS n FROM cards c JOIN offers_sent o ON o.card_id = c.id AND o.kind = 'offer' WHERE c.exhibition_id = ?");
    // won = a customer now that was not buying before the fair started (first invoice on or after the start)
    const won = (db.prepare(`SELECT COUNT(*) AS n FROM cards c JOIN exhibitions e ON e.id = c.exhibition_id LEFT JOIN intel_cust ic ON ic.code = c.sap
      WHERE c.exhibition_id = ? AND (c.stage = 'customer' OR COALESCE(c.sap, '') != '') AND NOT (ic.first_date IS NOT NULL AND e.start_date IS NOT NULL AND ic.first_date < e.start_date)`).get(id) as { n: number }).n;
    units.push({ label: 'people met', n: met, each: per(met) }, { label: 'offers sent', n: offers, each: per(offers) }, { label: 'customers won', n: won, each: per(won) });
  }
  return {
    kind, id, title: head.title, from: head.from, to: head.to, categories, planned, spent, spentTry: r2(exp.reduce((s, r) => s + r.amount_try, 0)), left: r2(planned - spent),
    pct: planned > 0 ? Math.round((spent / planned) * 100) : null, over: planned > 0 && spent > planned,
    rows: exp.map((r) => ({ id: r.id, date: r.spent_on, category: catOf(r), supplier: r.supplier, description: r.description, invoiceNo: r.invoice_no, currency: r.currency, amount: r.amount, eur: r.amount_eur, try: r.amount_try, hasFile: !!r.file_path, by: r.entered_name,
      byId: r.entered_by, rate: r.rate, docType: docTypeOf(r.doc_type) ?? 'invoice', turquality: r.turquality !== 0, fileName: r.file_path ? r.file_name : null, files: extra.get(r.id) ?? [] })),
    units,
  };
}

export function savePlan(kind: EventKind, id: number, by: number, lines: { category: string; planned: number; note?: string | null }[]): void {
  const up = db.prepare(`INSERT INTO event_budgets (kind, ref_id, category, planned_eur, note, updated_by, updated_at) VALUES (?, ?, ?, ?, ?, ?, datetime('now'))
    ON CONFLICT(kind, ref_id, category) DO UPDATE SET planned_eur = excluded.planned_eur, note = excluded.note, updated_by = excluded.updated_by, updated_at = excluded.updated_at`);
  const del = db.prepare('DELETE FROM event_budgets WHERE kind = ? AND ref_id = ? AND category = ?');
  db.exec('BEGIN');
  try {
    for (const l of lines) {
      if (!categoryOf(kind, l.category)) continue;
      const v = Number(l.planned);
      const note = typeof l.note === 'string' && l.note.trim() ? l.note.trim().slice(0, 200) : null;
      if (!Number.isFinite(v) || v <= 0) { if (note) up.run(kind, id, l.category, 0, note, by); else del.run(kind, id, l.category); } else up.run(kind, id, l.category, r2(Math.min(v, 100_000_000)), note, by);
    }
    db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); throw e; }
}

// planned and spent of many trips / fairs at once (the lists)
export function eventTotals(kind: EventKind, ids: number[]): Map<number, { planned: number; spent: number }> {
  const out = new Map<number, { planned: number; spent: number }>();
  if (!ids.length) return out;
  const marks = ids.map(() => '?').join(',');
  const col = kind === 'trip' ? 'trip_id' : 'exhibition_id';
  for (const id of ids) out.set(id, { planned: 0, spent: 0 });
  for (const r of db.prepare(`SELECT ref_id AS id, SUM(planned_eur) AS v FROM event_budgets WHERE kind = ? AND ref_id IN (${marks}) GROUP BY ref_id`).all(kind, ...ids) as unknown as { id: number; v: number }[]) out.get(r.id)!.planned = r2(r.v);
  for (const r of db.prepare(`SELECT ${col} AS id, SUM(amount_eur) AS v FROM budget_expenses WHERE ${col} IN (${marks}) GROUP BY ${col}`).all(...ids) as unknown as { id: number; v: number }[]) out.get(r.id)!.spent = r2(r.v);
  return out;
}
