import { Router } from 'express';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { cardModel } from '../models/cardModel';
import { canSeeCard } from '../services/visibility';
import { PLAYS, winbackDraft, winbackList, type Play } from '../services/winback';

// Win-back: who to bring back, why, and the text to do it with. Everybody sees their own customers (an admin sees all).
const router = Router();
router.use(requireAuth);
const viewerOf = (req: AuthedRequest) => ({ id: req.user!.id, role: req.user!.role, display_name: req.user!.display_name });

router.get('/', (req: AuthedRequest, res) => {
  const rows = winbackList(viewerOf(req));
  const byPlay: Record<string, number> = {};
  for (const r of rows) byPlay[r.play] = (byPlay[r.play] ?? 0) + 1;
  res.json({ rows, plays: PLAYS, summary: { total: rows.length, accounts: rows.filter((r) => r.kind === 'account').length, leads: rows.filter((r) => r.kind === 'lead').length, collect: rows.filter((r) => r.owes).length, byPlay } });
});

router.post('/draft', async (req: AuthedRequest, res) => {
  const card = cardModel.findById(parseInt(String(req.body?.cardId), 10));
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canSeeCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  const play = String(req.body?.play) as Play;
  if (!(play in PLAYS)) return res.status(400).json({ error: 'Unknown play.' });
  res.json({ ...(await winbackDraft(card, play, req.user!.display_name || req.user!.username)), to: card.email ? [card.email] : [], me: req.user!.email });
});

export default router;
