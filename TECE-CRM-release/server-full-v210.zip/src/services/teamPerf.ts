import { db } from '../db/connection';
import { memoTables, memoTablesMark, memoTablesStale } from '../db/dataVersion';
import { userModel, type PublicUser } from '../models/userModel';
import { countryKey } from '../models/countryModel';
import { hasMenu, type Perms } from './permissions';
import { viewMode } from './viewMode';
import { linkMap } from './perfAnalytics';
import { cardsMark, pricePerfBase, summarise, usersMark, LIMITS, type Base, type CustRow } from './pricePerf';
import { monthTarget, normName, repSeries } from './salesTargets';
import { shiftYm, windows12 } from './priceIndex';
import { visibilityFor, type Viewer } from './visibility';
import { peekRule } from './peek';

// The team analysis of the Performance page (owner, 21 Nov): "My team" (a manager: each person below him and the team total) and "My performance"
// (every salesperson, the manager for himself), and the facts of the coaching report (services/coaching.ts).
//
// Sales, customers and prices come from the Price performance base (services/pricePerf.ts: the same customers, the same status rules and the
// owner's price index of services/priceIndex.ts), the target from services/salesTargets.ts (the months of the same 12-month window), the activity
// from the CRM (activities, meetings, offers sent, follow-ups). Sales windows end at the data cut (the last invoice day of the sales list);
// activity windows end today (they are written live).
//
// Who sees whom (routes/teamRoutes2.ts asks access()): an admin everybody; a manager in Manager mode himself and everybody below him
// (in Salesperson mode only himself); everybody else only himself; an assistant works as the person she assists, never in Manager mode.
// A person with a permissions row needs the Performance menu; money (sales, targets, prices) needs the money switch "ledger" as well -
// without it the activity, the customer counts and the follow-ups still show (they hold no money), sales and prices are left out.

export const TOUCH = "('note', 'call', 'visit', 'meeting', 'sample', 'thank_you', 'offer', 'documents', 'email', 'whatsapp')";
const r1 = (v: number) => Math.round(v * 10) / 10;
const pctCh = (a: number, b: number): number | null => (b > 0 ? r1(((a - b) / b) * 100) : null);
const today = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });
const dayShift = (d: string, n: number) => new Date(Date.parse(`${d}T12:00:00Z`) + n * 864e5).toISOString().slice(0, 10);

export interface Person { id: number; name: string; self: boolean; email: string | null; lang: string | null }
export interface Access { ok: boolean; error?: string; money: boolean; canTeam: boolean; people: Person[]; me: Person | null }
type U = PublicUser & { perms?: Perms | null };

const nameOf = (x: { display_name: string | null; username: string }) => x.display_name || x.username;
const asPerson = (x: PublicUser, self: boolean): Person => ({ id: x.id, name: nameOf(x), self, email: x.email ?? null, lang: x.ui_language ?? null });

// who this viewer may look at (the same rules as the other Performance routes)
export function access(u: U, actor?: PublicUser | null): Access {
  const perms = u.perms ?? null;
  const no = (error: string): Access => ({ ok: false, error, money: false, canTeam: false, people: [], me: null });
  if (!hasMenu(u as never, 'perf')) return no('This page is not switched on for you.');
  if (u.role !== 'admin' && !perms && u.can_ship && !actor) return no('This page is not switched on for you.');
  const money = u.role === 'admin' || !perms || perms.money.includes('ledger');
  const users = userModel.listAll().filter((x) => x.is_active && !x.is_assistant && !x.assists_id);
  let people: Person[];
  if (u.role === 'admin') {
    // everybody who sells: has customers in the sales list or customers in the CRM (not the admin login, not Operations)
    const base = pricePerfBase();
    const reps = new Set([...base.custs.values()].filter((c) => c.lifetime > 0).map((c) => c.rep));
    const cardPeople = cardPersons();
    people = users.filter((x) => x.id !== u.id && (reps.has(nameOf(x)) || cardPeople.has(nameOf(x)))).map((x) => asPerson(x, false));
  } else {
    const below = new Set(viewMode.team(u.id).ids);
    people = [asPerson(u, true), ...users.filter((x) => below.has(x.id)).map((x) => asPerson(x, false))];
  }
  const canTeam = u.role === 'admin' || people.length > 1;
  return { ok: true, money, canTeam, people, me: people.find((p) => p.self) ?? null };
}
const cardPersons = memoTables(['cards'], () => new Set((db.prepare("SELECT DISTINCT person p FROM cards WHERE person IS NOT NULL AND TRIM(person) <> ''").all() as { p: string }[]).map((r) => r.p)));

// ---- the numbers that do not change with every request ------------------------------------------------------------------------------
// monthly net sales per rep over the last 12-month window (from the same customers as Price performance)
const salesMonthsKept = new WeakMap<Base, { months: string[]; byRep: Map<string, number[]> }>();
function salesMonths(base: Base) {
  let o = salesMonthsKept.get(base);
  if (o) return o;
  const w = windows12(1)[0] ?? (base.cutYm ? { from: shiftYm(base.cutYm, -11), to: base.cutYm } : null);
  const months: string[] = []; if (w) for (let m = w.from; m <= w.to; m = shiftYm(m, 1)) months.push(m);
  const byRep = new Map<string, number[]>();
  if (w) {
    const L = linkMap();
    for (const r of db.prepare("SELECT customer c, period p, SUM(eur) e FROM intel_fact WHERE period >= ? AND period <= ? AND period NOT LIKE '%-00' GROUP BY 1, 2").all(w.from, w.to) as { c: string; p: string; e: number }[]) {
      const cu = base.custs.get(L.get(r.c) ?? r.c); if (!cu) continue;
      const i = months.indexOf(r.p); if (i < 0) continue;
      const a = byRep.get(cu.rep) ?? byRep.set(cu.rep, months.map(() => 0)).get(cu.rep)!; a[i] += r.e;
    }
  }
  o = { months, byRep }; salesMonthsKept.set(base, o); return o;
}
// customers and users are written all day: only the columns the series reads count (SAP number, person, country of a customer; the users' names)
const series = memoTablesMark(['intel_fact', 'intel_cust', 'intel_excluded', 'country_assignments', 'intel_master', 'sap_customers'], () => cardsMark() + '|' + usersMark(), () => repSeries('all'));
// the target of the 12 months of the window (each month's target, or its share of the year's)
// the month of the data cut counts only for the days that are in the sales (to 19 Nov = 19/30 of November's target)
function target12(userId: number, name: string, months: string[], cut?: string | null): number | null {
  const s = series().byRep.get(normName(name)) ?? new Map<string, number>();
  let sum = 0, any = false;
  const cutYm = cut && /^\d{4}-\d{2}-\d{2}/.test(cut) ? cut.slice(0, 7) : null;
  const share = cutYm ? Math.min(1, +cut!.slice(8, 10) / new Date(Date.UTC(+cutYm.slice(0, 4), +cutYm.slice(5, 7), 0)).getUTCDate()) : 1;
  for (const ym of months) { const t = monthTarget(ym, userId, s); if (t.amount != null) { sum += ym === cutYm ? t.amount * share : t.amount; any = true; } }
  return any ? Math.round(sum) : null;
}

// activity per user: this 12 months, the 12 before, and per calendar month (the last 12)
interface Act { calls: number; visits: number; meetings: number; notes: number; emails: number; offers: number; done: number; overdue: number; open: number }
const ACT_KEYS: (keyof Act)[] = ['calls', 'visits', 'meetings', 'notes', 'emails', 'offers', 'done', 'overdue', 'open'];
const zAct = (): Act => ({ calls: 0, visits: 0, meetings: 0, notes: 0, emails: 0, offers: 0, done: 0, overdue: 0, open: 0 });
interface ActAll { day: string; months: string[]; cur: Map<number, Act>; prev: Map<number, Act>; monthly: Map<number, Record<string, number[]>>; first: Map<string, { n: number; days: number; waiting: number }> }
const actOf = (day: string): ActAll => {
  const a0 = dayShift(day, -364), p0 = dayShift(day, -729);
  const ym = day.slice(0, 7); const months: string[] = []; for (let i = 11; i >= 0; i--) months.push(shiftYm(ym, -i));
  const cur = new Map<number, Act>(), prev = new Map<number, Act>(), monthly = new Map<number, Record<string, number[]>>();
  const get = (m: Map<number, Act>, id: number) => m.get(id) ?? m.set(id, zAct()).get(id)!;
  const mon = (id: number, k: string, mth: string, n: number) => { const i = months.indexOf(mth); if (i < 0) return; const o = monthly.get(id) ?? monthly.set(id, {}).get(id)!; (o[k] ??= months.map(() => 0))[i] += n; };
  const KIND: Record<string, keyof Act> = { call: 'calls', visit: 'visits', meeting: 'meetings', note: 'notes', email: 'emails', whatsapp: 'calls' };
  const add = (id: number, k: keyof Act, d: string, mth: string, n: number) => { if (d >= a0) get(cur, id)[k] += n; else if (d >= p0) get(prev, id)[k] += n; mon(id, k, mth, n); };
  for (const r of db.prepare(`SELECT user_id u, type t, substr(created_at, 1, 10) d, substr(created_at, 1, 7) m, COUNT(*) n FROM activities WHERE imported = 0 AND created_at >= ? GROUP BY 1, 2, 3`).all(p0) as { u: number; t: string; d: string; m: string; n: number }[]) {
    const k = KIND[r.t]; if (k) add(r.u, k, r.d, r.m, r.n);
  }
  for (const r of db.prepare('SELECT user_id u, substr(starts_at, 1, 10) d, substr(starts_at, 1, 7) m, COUNT(*) n FROM meetings WHERE starts_at >= ? AND starts_at <= ? GROUP BY 1, 3').all(p0, `${day} 23:59`) as { u: number; d: string; m: string; n: number }[]) add(r.u, 'meetings', r.d, r.m, r.n);
  for (const r of db.prepare('SELECT created_by u, substr(sent_at, 1, 10) d, substr(sent_at, 1, 7) m, COUNT(*) n FROM offers_sent WHERE sent_at >= ? AND created_by IS NOT NULL AND kind = \'offer\' GROUP BY 1, 3').all(p0) as { u: number; d: string; m: string; n: number }[]) add(r.u, 'offers', r.d, r.m, r.n);
  for (const r of db.prepare('SELECT user_id u, substr(done_at, 1, 10) d, substr(done_at, 1, 7) m, COUNT(*) n FROM todos WHERE done_at >= ? GROUP BY 1, 3').all(p0) as { u: number; d: string; m: string; n: number }[]) add(r.u, 'done', r.d, r.m, r.n);
  for (const r of db.prepare('SELECT user_id u, SUM(due_date < ?) o, COUNT(*) n FROM todos WHERE done_at IS NULL GROUP BY 1').all(day) as { u: number; o: number; n: number }[]) { const a = get(cur, r.u); a.overdue = r.o; a.open = r.n; }
  // how fast a new lead or fair visitor of this person is contacted: days from the card to the first contact (by anybody), cards of the last 12 months
  const first = new Map<string, { n: number; days: number; waiting: number }>();
  for (const r of db.prepare(`SELECT c.person p, substr(c.created_at, 1, 10) c, (SELECT substr(MIN(a.created_at), 1, 10) FROM activities a WHERE a.card_id = c.id AND a.imported = 0 AND a.type IN ${TOUCH}) f
      FROM cards c WHERE c.created_at >= ? AND c.person IS NOT NULL AND COALESCE(c.sap, '') = '' AND COALESCE(c.exit_status, '') = ''
        AND NOT EXISTS (SELECT 1 FROM exhibitions e WHERE e.id = c.exhibition_id AND e.is_default = 1)`).all(a0) as { p: string; c: string; f: string | null }[]) {
    const o = first.get(r.p) ?? first.set(r.p, { n: 0, days: 0, waiting: 0 }).get(r.p)!;
    if (r.f) { o.n += 1; o.days += Math.max(0, Math.round((Date.parse(`${r.f}T12:00:00Z`) - Date.parse(`${r.c}T12:00:00Z`)) / 864e5)); } else o.waiting += 1;
  }
  return { day, months, cur, prev, monthly, first };
};
// every call, note, to-do or offer of anybody is a write here: the counts may be up to 90 seconds behind, and are made again at most once in that time
const activity = memoTablesStale(['activities', 'meetings', 'offers_sent', 'todos', 'cards'], () => actOf(today()), 90_000, () => today());

// ---- one person (or the team: several names together) -----------------------------------------------------------------------------
export interface Row {
  id: number | null; name: string; self: boolean; people?: number;
  sales: { v: number; prev: number; growth: number | null; target: number | null; targetPct: number | null; spark: number[] } | null;
  customers: { total: number; buying: number; active: number; new: number; slowing: number; passive: number; lost: number; retention: number | null; kept: number; of: number };
  act: Act & { prev: Act; firstDays: number | null; firstN: number; waiting: number; spark: Record<string, number[]> };
  price: { index: number | null; prev: number | null; change: number | null; trend: { from: string; to: string; index: number | null }[]; leaks: number; falls: number } | null;
}
export interface Ctx { base: Base; money: boolean; sm: ReturnType<typeof salesMonths>; act: ActAll }
export const context = (money: boolean): Ctx => { const base = pricePerfBase(); return { base, money, sm: salesMonths(base), act: activity() }; };

export function rowFor(ctx: Ctx, people: Person[], label?: string): Row & { _rows: CustRow[] } {
  const names = new Set(people.map((p) => p.name));
  const v = summarise(ctx.base, names, '12m');
  const s = v.summary;
  const A = zAct(), P = zAct(); const spark: Record<string, number[]> = {};
  let fN = 0, fD = 0, wait = 0;
  for (const p of people) {
    const c = ctx.act.cur.get(p.id), pr = ctx.act.prev.get(p.id), m = ctx.act.monthly.get(p.id) ?? {};
    for (const k of ACT_KEYS) { A[k] += c?.[k] ?? 0; P[k] += pr?.[k] ?? 0; }
    for (const k of ['calls', 'visits', 'meetings', 'notes', 'offers', 'done']) { const src = m[k] ?? ctx.act.months.map(() => 0); spark[k] = (spark[k] ?? ctx.act.months.map(() => 0)).map((x, i) => x + src[i]); }
    const f = ctx.act.first.get(p.name); if (f) { fN += f.n; fD += f.days; wait += f.waiting; }
  }
  let sales: Row['sales'] = null, price: Row['price'] = null;
  if (ctx.money) {
    const sp = ctx.sm.months.map(() => 0);
    for (const n of names) { const a = ctx.sm.byRep.get(n); if (a) a.forEach((x, i) => { sp[i] += x; }); }
    let target: number | null = null;
    for (const p of people) { const t = target12(p.id, p.name, ctx.sm.months, ctx.base.cut); if (t != null) target = (target ?? 0) + t; }
    sales = { v: Math.round(s.rev12), prev: Math.round(s.rev12Prev), growth: s.rev12Growth, target, targetPct: target ? r1((s.rev12 / target) * 100) : null, spark: sp.map((x) => Math.round(x)) };
    price = { index: s.index, prev: s.indexPrev, change: s.change, trend: s.trend, leaks: s.leaks, falls: s.falls };
  }
  const one = people.length === 1 ? people[0] : null;
  return {
    id: one ? one.id : null, name: label ?? one?.name ?? '', self: !!one?.self, people: people.length,
    sales,
    customers: { total: s.customers, buying: s.buying, active: s.status.active, new: s.status.new, slowing: s.status.slowing, passive: s.status.passive, lost: s.status.lost, retention: s.retention.pct, kept: s.retention.kept, of: s.retention.of },
    act: { ...A, prev: P, firstDays: fN ? r1(fD / fN) : null, firstN: fN, waiting: wait, spark },
    price,
    _rows: v.rows,
  };
}
const strip = <T extends { _rows?: unknown }>(r: T): Omit<T, '_rows'> => { const { _rows, ...rest } = r; void _rows; return rest; };

export function teamView(acc: Access, viewer?: Viewer & { perms?: Perms | null }) {
  const ctx = context(acc.money);
  const full = acc.people.map((p) => ({ p, r: rowFor(ctx, [p]) }));
  const plain = full.map((x) => strip(x.r));
  const total = strip(rowFor(ctx, acc.people, 'Team total'));
  // the verdict of each person, made exactly as on his scorecard (compared with his own peers, not with everybody this viewer sees),
  // so the team tab and the scorecard always give the same status and reasons; the options only for the people below the viewer
  const rows = full.map(({ p, r }, i) => ({ ...plain[i], verdict: viewer ? personVerdict(acc, viewer, p, ctx, r) : null }));
  return { asOf: ctx.base.cut, today: ctx.act.day, money: acc.money, months: { sales: ctx.sm.months, act: ctx.act.months }, window: windows12(1)[0] ?? null, rows, total, limits: LIMITS };
}

// the team average of every number (without anybody's own figures): what a salesperson compares himself with
function averageOf(t: Row, n: number) {
  const d = (v: number | null | undefined) => (v == null ? null : r1(v / Math.max(1, n)));
  return {
    people: n,
    sales: t.sales ? { v: d(t.sales.v), prev: d(t.sales.prev), growth: t.sales.growth, targetPct: t.sales.targetPct } : null,
    customers: { total: d(t.customers.total), active: d(t.customers.active), new: d(t.customers.new), slowing: d(t.customers.slowing), lost: d(t.customers.lost), retention: t.customers.retention },
    act: { calls: d(t.act.calls), visits: d(t.act.visits), meetings: d(t.act.meetings), notes: d(t.act.notes), offers: d(t.act.offers), done: d(t.act.done), overdue: d(t.act.overdue), firstDays: t.act.firstDays },
    price: t.price ? { index: t.price.index, change: t.price.change } : null,
  };
}

// ---- the named lists (only customers this viewer may open; the others are counted) -------------------------------------------------
interface CardLite { id: number; company: string; person: string | null; country: string | null; stage: string | null; score: number | null; market: string; city: string | null; status: string; uploaded_by: number; owner_override: number; sap: string | null; last: string | null; ex: number; exDefault: number; exStart: string | null; created: string }
// the last contact of every customer: written with every note, so it may be up to a minute behind
const lastKept = memoTablesStale(['activities'], () => new Map((db.prepare('SELECT card_id id, MAX(created_at) m FROM activities WHERE imported = 0 AND card_id IS NOT NULL GROUP BY card_id').all() as { id: number; m: string }[]).map((r) => [r.id, r.m])), 60_000);
const cardsCore = memoTables(['cards', 'exhibitions'], () => db.prepare(`SELECT c.id, COALESCE(NULLIF(c.company, ''), c.name, '') company, c.person, c.country, c.stage, COALESCE(c.rate, c.ai_rate) score,
      c.market, c.city, c.status, c.uploaded_by, c.owner_override, c.sap, c.exhibition_id ex, COALESCE(e.is_default, 1) exDefault, e.start_date exStart, substr(c.created_at, 1, 10) created
    FROM cards c LEFT JOIN exhibitions e ON e.id = c.exhibition_id WHERE c.exit_status IS NULL OR c.exit_status = ''`).all() as unknown as CardLite[]);
let cardsHeld: { core: CardLite[]; last: Map<number, string>; v: { byCountry: Map<string, CardLite[]>; byPerson: Map<string, CardLite[]> } } | null = null;
const cardsKept = () => {
  const core = cardsCore(), last = lastKept();
  if (cardsHeld && cardsHeld.core === core && cardsHeld.last === last) return cardsHeld.v;
  const rows = core.map((r) => ({ ...r, last: last.get(r.id) ?? null }));
  const byCountry = new Map<string, CardLite[]>(); const byPerson = new Map<string, CardLite[]>();
  for (const r of rows) {
    if (r.market !== 'domestic' && r.country) { const k = countryKey(r.country); (byCountry.get(k) ?? byCountry.set(k, []).get(k)!).push(r); }
    if (r.person) (byPerson.get(r.person) ?? byPerson.set(r.person, []).get(r.person)!).push(r);
  }
  cardsHeld = { core, last, v: { byCountry, byPerson } };
  return cardsHeld.v;
};
const countriesOf = memoTables(['country_assignments'], () => {
  const m = new Map<string, string[]>();
  for (const r of db.prepare("SELECT country, responsible FROM country_assignments WHERE responsible IS NOT NULL AND TRIM(responsible) <> ''").all() as { country: string; responsible: string }[]) (m.get(r.responsible) ?? m.set(r.responsible, []).get(r.responsible)!).push(r.country);
  for (const a of m.values()) a.sort();
  return m;
});
export const responsibleCountries = (name: string): string[] => countriesOf().get(name) ?? [];

const lite = (c: CardLite) => ({ uploaded_by: c.uploaded_by, person: c.person, country: c.country, status: c.status as never, market: c.market, city: c.city, owner_override: c.owner_override });
export interface Named { id: number | null; name: string | null; country?: string | null; link: string | null; [k: string]: unknown }

export function detailsFor(viewer: Viewer, subject: Person, rows: CustRow[], money: boolean) {
  const see = visibilityFor(viewer);
  const day = today();
  const yearAgo = `${dayShift(day, -365)} 00:00`;
  const C = cardsKept();
  const cardLink = (id: number | null) => (id ? `/cards/${id}/review?tab=details` : null);
  const cardById = new Map<number, CardLite>(); for (const c of C.byPerson.get(subject.name) ?? []) cardById.set(c.id, c);
  const openable = (id: number | null) => { if (!id) return false; const c = cardById.get(id); return c ? see(lite(c)) : viewer.role === 'admin'; };
  const cust = (r: CustRow, extra: Record<string, unknown>): Named => ({ id: openable(r.cardId) ? r.cardId : null, name: openable(r.cardId) || viewer.role === 'admin' ? r.name : null, country: r.country, link: openable(r.cardId) ? cardLink(r.cardId) : null, ...extra });
  const slowing = rows.filter((r) => r.status === 'slowing').map((r) => ({ r, drop: r.revPrev - r.rev })).sort((a, b) => b.drop - a.drop).slice(0, 10)
    .map(({ r }) => cust(r, money ? { rev: Math.round(r.rev), revPrev: Math.round(r.revPrev), growth: r.growth, last: r.last } : { growth: r.growth, last: r.last }));
  const cutDate = pricePerfBase().cut ?? day;
  const lostSince = dayShift(cutDate, -548);
  const lost = rows.filter((r) => r.status === 'lost' && r.last && r.last >= lostSince).sort((a, b) => b.lifetime - a.lifetime).slice(0, 10)
    .map((r) => cust(r, money ? { lifetime: Math.round(r.lifetime), last: r.last } : { last: r.last }));
  const discounted = money ? rows.filter((r) => r.flags.includes('leak')).sort((a, b) => b.rev - a.rev).slice(0, 10)
    .map((r) => cust(r, { index: r.index, rev: Math.round(r.rev), group: r.groups[0] ? { grp: r.groups[0].grp, unit: r.groups[0].unit, price: r.groups[0].price, avg: r.groups[0].avg } : null })) : [];
  // follow-ups that are late
  const overdue = (db.prepare(`SELECT t.id, t.text, t.due_date due, t.card_id cardId, COALESCE(NULLIF(c.company, ''), c.name) company, c.person, c.country, c.status, c.market, c.city, c.uploaded_by, c.owner_override
      FROM todos t LEFT JOIN cards c ON c.id = t.card_id WHERE t.user_id = ? AND t.done_at IS NULL AND t.due_date < ? ORDER BY t.due_date LIMIT 40`).all(subject.id, day) as Record<string, unknown>[])
    .map((t) => { const ok = t.cardId ? see(t as never) : false; return { id: ok ? (t.cardId as number) : null, name: ok ? (t.company as string) : null, todo: ok || !t.cardId ? String(t.text).slice(0, 120) : null, due: t.due as string, days: Math.round((Date.parse(`${day}T12:00:00Z`) - Date.parse(`${t.due}T12:00:00Z`)) / 864e5), link: ok ? cardLink(t.cardId as number) : null }; });
  // fair visitors of this person, hot (score 7+), nobody wrote to them yet
  const fairWaiting = (C.byPerson.get(subject.name) ?? []).filter((c) => !c.exDefault && c.exStart && c.exStart <= day && (c.score ?? 0) >= 7 && !c.last && !c.sap).sort((a, b) => (b.score ?? 0) - (a.score ?? 0) || b.created.localeCompare(a.created))
    .map((c) => ({ id: see(lite(c)) ? c.id : null, name: see(lite(c)) ? c.company : null, country: c.country, score: c.score, fair: c.ex, link: `/fairs/${c.ex}/focus` }));
  // the countries this person is responsible for: leads and customers nobody contacted for a year, and companies looked after by others (view only)
  const rule = peekRule(viewer);
  const countries = responsibleCountries(subject.name).map((country) => {
    const list = C.byCountry.get(countryKey(country)) ?? [];
    const free = list.filter((c) => (!c.person || c.person === subject.name) && (!c.last || c.last < yearAgo));
    const others = list.filter((c) => c.person && c.person !== subject.name);
    const best = (a: CardLite[]) => a.sort((x, y) => Number(!!y.sap) - Number(!!x.sap) || (y.score ?? 0) - (x.score ?? 0) || x.id - y.id);
    return {
      country, cards: list.length,
      untouched: free.length, untouchedCustomers: free.filter((c) => c.sap || c.stage === 'customer').length,
      untouchedTop: best(free).slice(0, 6).map((c) => ({ id: see(lite(c)) ? c.id : null, name: see(lite(c)) ? c.company : null, stage: c.stage, customer: !!c.sap || c.stage === 'customer', last: c.last ? c.last.slice(0, 10) : null, link: see(lite(c)) ? cardLink(c.id) : null })),
      viewOnly: others.length,
      // names only of the companies THIS viewer may look at (view only or more): never a name the reader may not see
      viewOnlyTop: best(others).slice(0, 6).map((c) => { const r = rule(c as never); return { id: r ? c.id : null, name: r ? c.company : null, owner: r ? c.person : null, customer: !!c.sap || c.stage === 'customer', peek: r === 'peek', link: r === 'full' ? cardLink(c.id) : null }; }),
      sprint: `/sprint?country=${encodeURIComponent(country)}`,
    };
  }).sort((a, b) => b.untouched - a.untouched);
  const overdueCount = (db.prepare('SELECT COUNT(*) n FROM todos WHERE user_id = ? AND done_at IS NULL AND due_date < ?').get(subject.id, day) as { n: number }).n;
  // new leads and fair visitors of the last 12 months nobody contacted yet (not the imported customer base, not the closed ones), oldest first
  const fresh = (C.byPerson.get(subject.name) ?? []).filter((c) => !c.sap && !c.exDefault && !c.last && c.created >= dayShift(day, -364)).sort((a, b) => a.created.localeCompare(b.created) || a.id - b.id);
  const newLeads = fresh.slice(0, 12).map((c) => ({ id: see(lite(c)) ? c.id : null, name: see(lite(c)) ? c.company : null, country: c.country, created: c.created, link: see(lite(c)) ? cardLink(c.id) : null }));
  const counts = { slowing: rows.filter((r) => r.status === 'slowing').length, lost: rows.filter((r) => r.status === 'lost' && r.last && r.last >= lostSince).length, discounted: money ? rows.filter((r) => r.flags.includes('leak')).length : 0 };
  return { counts, slowing, lost, discounted, overdue: overdue.slice(0, 12), overdueCount, fairWaiting: fairWaiting.slice(0, 12), fairWaitingCount: fairWaiting.length, newLeads, newLeadsCount: fresh.length, countries };
}

// 3-6 next actions, by rules, with named customers
export interface NextAction { kind: string; title: string; why: string; n: number; items: { id: number | null; name: string | null; link: string | null; note?: string }[]; link: string | null }
export function nextActions(d: ReturnType<typeof detailsFor>, money: boolean): NextAction[] {
  const out: (NextAction & { w: number })[] = [];
  const items = (a: Named[], note: (x: Named) => string | undefined) => a.slice(0, 3).map((x) => ({ id: x.id, name: x.name, link: x.link, note: note(x) }));
  if (d.overdueCount) out.push({ w: 90 + Math.min(d.overdueCount, 30), kind: 'overdue', title: 'Clear your overdue follow-ups', why: 'Promised follow-ups that are late', n: d.overdueCount, items: d.overdue.slice(0, 3).map((t) => ({ id: t.id, name: t.name, link: t.link, note: t.todo ?? undefined })), link: d.overdue[0]?.link ?? null });
  if (d.fairWaitingCount) out.push({ w: 85 + Math.min(d.fairWaitingCount, 20), kind: 'fair', title: 'Write to the hot fair visitors who are still waiting', why: 'Score 7 or more, nobody contacted them yet', n: d.fairWaitingCount, items: d.fairWaiting.slice(0, 3).map((c) => ({ id: c.id, name: c.name, link: c.link })), link: d.fairWaiting[0]?.link ?? null });
  if (d.newLeadsCount) out.push({ w: 75 + Math.min(d.newLeadsCount, 20) / 2, kind: 'first', title: 'Make the first contact with your new leads', why: 'New in the last 12 months, nobody contacted them yet (oldest first)', n: d.newLeadsCount, items: d.newLeads.slice(0, 3).map((c) => ({ id: c.id, name: c.name, link: c.link, note: c.created })), link: d.newLeads[0]?.link ?? null });
  if (d.slowing.length) out.push({ w: 80, kind: 'slowing', title: 'Call the customers who are slowing down', why: 'Bought lately, but the last 12 months are under 75% of the 12 months before', n: d.counts.slowing, items: items(d.slowing, () => undefined), link: d.slowing[0]?.link ?? null });
  if (money && d.discounted.length) out.push({ w: 70, kind: 'price', title: 'Review the prices of customers well below average', why: `Price index under ${LIMITS.leakIndex} (100 = average of all customers, same products, same 12 months)`, n: d.counts.discounted, items: items(d.discounted, () => undefined), link: d.discounted[0]?.link ?? null });
  if (d.lost.length) out.push({ w: 60, kind: 'lost', title: 'Win back the customers lost in the last months', why: 'Nothing bought for more than 12 months', n: d.counts.lost, items: items(d.lost, () => undefined), link: d.lost[0]?.link ?? null });
  const c = d.countries.find((x) => x.untouched > 0);
  if (c) out.push({ w: 50 + Math.min(c.untouched, 30) / 3, kind: 'explore', title: 'Explore the untouched potential in your countries', why: 'Leads and customers nobody contacted for a year', n: d.countries.reduce((s, x) => s + x.untouched, 0), items: d.countries.filter((x) => x.untouched > 0).slice(0, 3).map((x) => ({ id: null, name: x.country, link: x.sprint, note: String(x.untouched) })), link: c.sprint });
  return out.sort((a, b) => b.w - a.w).slice(0, 6).map(({ w, ...a }) => { void w; return a; });
}

// the scorecard of one person: their numbers, the team average (never another person's own numbers), the lists and the next actions
export function scorecard(acc: Access, viewer: Viewer, subject: Person) {
  const ctx = context(acc.money);
  const me = rowFor(ctx, [subject]);
  // the team to compare with: everybody who reports to the same manager (or to this manager), seen as one average
  const peers = peersOf(subject.id);
  // (only with three people or more: with two, the average would give the other person's own numbers away)
  const team = peers.length > 2 ? rowFor(ctx, peers, 'Team') : null;
  const d = detailsFor(viewer, subject, me._rows, acc.money);
  const verdict = personVerdict(acc, viewer, subject, ctx, me);
  return {
    verdict,
    asOf: ctx.base.cut, today: ctx.act.day, money: acc.money, months: { sales: ctx.sm.months, act: ctx.act.months }, window: windows12(1)[0] ?? null,
    person: { id: subject.id, name: subject.name, self: subject.self }, row: strip(me), team: team ? averageOf(team, peers.length) : null,
    groups: acc.money ? summarise(ctx.base, new Set([subject.name]), '12m').groups : [],
    ...d, actions: nextActions(d, acc.money), countriesList: responsibleCountries(subject.name), limits: LIMITS,
  };
}

// the verdict of one person (the scorecard and the team tab): compared with the team of his own manager (peersOf)
function personVerdict(acc: Access, viewer: Viewer, subject: Person, ctx: ReturnType<typeof context>, me: ReturnType<typeof rowFor>): Verdict {
  const peers = peersOf(subject.id);
  const team = peers.length > 2 ? rowFor(ctx, peers, 'Team') : null;
  const d = detailsFor(viewer, subject, me._rows, acc.money);
  const peerRows = peers.filter((p) => p.id !== subject.id).map((p) => strip(rowFor(ctx, [p])));
  return verdictOf({ row: me, rows: me._rows, money: acc.money, teamAct: team ? teamActAvg([strip(me), ...peerRows]) : null, team: team ? strip(team) : null, peers: peerRows, d, viewer: viewer as never, options: !subject.self },
    acc.money ? undefined : () => verdictInputWithMoney(viewer, subject, peers, !subject.self));
}
// the people a person is compared with: the team of his manager (him included), or his own team when he is the manager
export function peersOf(userId: number): Person[] {
  const users = userModel.listAll().filter((x) => x.is_active && !x.is_assistant && !x.assists_id && !(x.can_ship && x.role !== 'admin'));
  const u = users.find((x) => x.id === userId); if (!u) return [];
  const head = u.manager_id ?? (users.some((x) => x.manager_id === u.id) ? u.id : null);
  if (head == null) return [asPerson(u, true)];
  const out: Person[] = []; const seen = new Set<number>();
  const walk = (id: number, d: number) => { if (d > 12 || seen.has(id)) return; seen.add(id); const x = users.find((y) => y.id === id); if (x && x.role !== 'admin') out.push(asPerson(x, x.id === userId)); for (const y of users) if (y.manager_id === id) walk(y.id, d + 1); };
  walk(head, 0);
  return out;
}

// ---- the verdict per person (owner, 21 Nov: "smart review and verdict for each employee and what options we have") ---------------------
// Explicit rules on the facts above, each signal worth 1 or 2 points (money signals only for a viewer with money):
//   target     reached under 70% = 2, under 90% = 1                       growth   sales vs the 12 months before -15% or worse = 2, -5% or worse = 1
//   customers  slowing + lost lately >= 25% of his buying customers = 2, >= 12% = 1
//   price      owner's price index under 85 = 2, under 92 = 1; fell 3 points or more vs the 12 months before = +1 (2 at most)
//   follow-ups overdue >= 50 or >= 40% of the open ones = 2, >= 10 = 1
//   activity   calls + visits + meetings + offers -30% vs the 12 months before = 2, -15% = 1; under 60% of the team average = +1 (2 at most)
// Status: 5 points or more, or two 2-point signals = at risk; 2 points or more = needs attention; else on track.
// The reasons: the 2-3 heaviest signals (on track: the strengths). The options (only for a manager or an admin looking at somebody else):
// coach on the weakest metric, pair with the colleague strongest at it (named, from the same team), reassign / move a country, adjust the
// target, plan a trip to the country with the most untouched companies, a price review - each with its expected effect in numbers.
export interface VPart { t: string; v?: Record<string, string | number>; money?: boolean }
export interface VOption { kind: 'coach' | 'pair' | 'reassign' | 'target' | 'trip' | 'price'; title: VPart; effect: VPart; to: string | null; action?: 'coach'; note?: VPart | null; money?: boolean }
export interface Verdict { status: 'on_track' | 'attention' | 'at_risk'; points: number; reasons: VPart[]; strengths: VPart[]; metric: string | null; options: VOption[] }
type Metric = 'target' | 'growth' | 'customers' | 'price' | 'overdue' | 'activity';
const METRIC_LABEL: Record<Metric, string> = { target: 'the sales target', growth: 'sales growth', customers: 'keeping customers', price: 'pricing', overdue: 'follow-ups', activity: 'activity' };
const eurS = (v: number) => { const a = Math.abs(v); return (v < 0 ? '-' : '') + '€' + (a >= 1e6 ? `${(a / 1e6).toFixed(1)}M` : a >= 10000 ? `${Math.round(a / 1000)}k` : Math.round(a).toLocaleString('en-US')); };
const actSum = (a: { calls: number; visits: number; meetings: number; offers: number }) => a.calls + a.visits + a.meetings + a.offers;
// a metric as one comparable number (higher = better, except overdue)
const metricValue = (r: Row, m: Metric): number | null => {
  switch (m) {
    case 'target': return r.sales?.targetPct ?? null;
    case 'growth': return r.sales?.growth ?? null;
    case 'customers': return r.customers.retention;
    case 'price': return r.price?.index ?? null;
    case 'overdue': return r.act.overdue;
    case 'activity': return actSum(r.act);
  }
};
const metricShow = (m: Metric, v: number | null) => (v == null ? '–' : m === 'target' || m === 'customers' ? `${Math.round(v)}%` : m === 'growth' ? `${v > 0 ? '+' : ''}${Math.round(v)}%` : String(Math.round(v)));

export interface VerdictInput {
  row: Row; rows: CustRow[]; money: boolean; teamAct: number | null; // team average of calls+visits+meetings+offers
  team?: Omit<Row, '_rows'> | null; // the team together (the same 12 months): a person no worse than the team loses a point (the market, not the person)
  peers: Row[]; d: ReturnType<typeof detailsFor>; viewer: Viewer & { perms?: Perms | null }; options: boolean;
}
export function verdictFor(x: VerdictInput): Verdict {
  const { row: r, money, d } = x;
  const sig: { m: Metric; pts: number; why: VPart }[] = [];
  const strengths: VPart[] = [];
  if (money && r.sales) {
    const tp = r.sales.targetPct;
    if (tp != null) {
      if (tp < 90) sig.push({ m: 'target', pts: tp < 70 ? 2 : 1, why: { t: '{p}% of the target reached ({v} of {t})', v: { p: Math.round(tp), v: eurS(r.sales.v), t: eurS(r.sales.target ?? 0) }, money: true } });
      else if (tp >= 100) strengths.push({ t: '{p}% of the target reached', v: { p: Math.round(tp) }, money: true });
    }
    const g = r.sales.growth;
    if (g != null) {
      // when the whole team fell as much (the market, not the person), it is not a reason about this person
      const tg = x.team?.sales?.growth ?? null;
      const likeTeam = tg != null && tg <= -5 && g - tg >= -5;
      const pts = likeTeam ? 0 : g <= -15 ? 2 : 1;
      if (g <= -5) sig.push({ m: 'growth', pts, why: tg != null ? { t: 'sales {g}% vs the 12 months before ({a} → {b}; team {tg}%)', v: { g: Math.round(g), a: eurS(r.sales.prev), b: eurS(r.sales.v), tg: Math.round(tg) }, money: true } : { t: 'sales {g}% vs the 12 months before ({a} → {b})', v: { g: Math.round(g), a: eurS(r.sales.prev), b: eurS(r.sales.v) }, money: true } });
      else if (g >= 10) strengths.push({ t: 'sales +{g}% vs the 12 months before', v: { g: Math.round(g) }, money: true });
    }
  }
  const buying = Math.max(1, r.customers.total);
  const risk = r.customers.slowing + d.counts.lost;
  if (r.customers.total >= 5) {
    const share = risk / buying;
    const T = x.team?.customers; const tShare = T && T.total > 0 ? (T.slowing + T.lost) / T.total : null; const mShare = (r.customers.slowing + r.customers.lost) / buying;
    const likeTeam = tShare != null && mShare - tShare <= 0.03;
    if (share >= 0.12) sig.push({ m: 'customers', pts: likeTeam ? 0 : share >= 0.25 ? 2 : 1, why: { t: '{s} customers slowing and {l} lost lately (of {n})', v: { s: r.customers.slowing, l: d.counts.lost, n: r.customers.total } } });
    else if (r.customers.retention != null && r.customers.retention >= 85) strengths.push({ t: '{p}% of last year’s customers bought again', v: { p: Math.round(r.customers.retention) } });
  }
  if (money && r.price && r.price.index != null) {
    let pts = r.price.index < 85 ? 2 : r.price.index < 92 ? 1 : 0;
    if (r.price.change != null && r.price.change <= -3) pts = Math.min(2, pts + 1);
    if (pts) sig.push({ m: 'price', pts, why: r.price.change != null ? { t: 'price index {i} ({c} points vs the 12 months before)', v: { i: Math.round(r.price.index), c: (r.price.change > 0 ? '+' : '') + Math.round(r.price.change * 10) / 10 }, money: true } : { t: 'price index {i}', v: { i: Math.round(r.price.index) }, money: true } });
    else if (r.price.index > 100.5) strengths.push({ t: 'price index {i}: above the company average', v: { i: Math.round(r.price.index) }, money: true });
  }
  const od = r.act.overdue, open = r.act.open;
  {
    const TA = x.team?.act; const tR = TA && TA.open > 0 ? TA.overdue / TA.open : null; const mR = open > 0 ? od / open : 0;
    const likeTeam = tR != null && mR - tR <= 0.05;
    if (od >= 10 || (open > 0 && mR >= 0.4 && od >= 3)) sig.push({ m: 'overdue', pts: likeTeam ? 0 : od >= 50 || mR >= 0.4 ? 2 : 1, why: tR != null ? { t: '{n} follow-ups overdue ({p}% of the open ones; team {tp}%)', v: { n: od, p: Math.round(mR * 100), tp: Math.round(tR * 100) } } : { t: '{n} follow-ups overdue ({p}% of the open ones)', v: { n: od, p: Math.round(mR * 100) } } });
  }
  const a = actSum(r.act), ap = actSum(r.act.prev);
  {
    // the change only when the person's own CRM history reaches back over the whole previous 12 months (else +900% from a half-empty year)
    const first = r.id != null ? (db.prepare('SELECT MIN(created_at) AS f FROM activities WHERE user_id = ? AND imported = 0').get(r.id) as { f: string | null } | undefined)?.f ?? null : null;
    const covered = !!first && first.slice(0, 10) <= new Date(Date.now() - 729 * 86_400_000).toISOString().slice(0, 10);
    let pts = 0; const ch = ap > 0 && covered ? ((a - ap) / ap) * 100 : null;
    if (ch != null && ch <= -15) pts = ch <= -30 ? 2 : 1;
    const byChange = pts > 0;
    if (x.teamAct && a < 0.6 * x.teamAct) pts = Math.min(2, pts + 1);
    if (pts) sig.push({ m: 'activity', pts, why: byChange && ch != null ? { t: '{n} calls, visits, meetings and offers in 12 months ({c}% vs the 12 months before)', v: { n: a, c: Math.round(ch) } } : { t: '{n} calls, visits, meetings and offers in 12 months (team average {t})', v: { n: a, t: Math.round(x.teamAct ?? 0) } } });
    else if (ch != null && ch >= 10) strengths.push({ t: 'activity +{c}% vs the 12 months before', v: { c: Math.round(ch) } });
  }
  const points = sig.reduce((s, z) => s + z.pts, 0);
  for (let i = sig.length - 1; i >= 0; i -= 1) if (sig[i].pts <= 0) sig.splice(i, 1);
  const twos = sig.filter((z) => z.pts >= 2).length;
  const status: Verdict['status'] = points >= 5 || twos >= 2 ? 'at_risk' : points >= 2 ? 'attention' : 'on_track';
  const order = [...sig].sort((p, q) => q.pts - p.pts);
  const reasons = order.slice(0, 3).map((z) => z.why);
  const metric = order[0]?.m ?? null;
  const options: VOption[] = [];
  if (x.options) {
    const first = r.name.split(' ')[0];
    const slowGap = x.rows.filter((c) => c.status === 'slowing').reduce((s, c) => s + Math.max(0, c.revPrev - c.rev), 0);
    const disc = x.rows.filter((c) => c.flags.includes('leak') && c.index != null);
    const priceGap = disc.reduce((s, c) => s + c.rev * (100 - (c.index as number)) / 100, 0);
    // coach on the weakest metric where somebody on the team does better (never coach the team's best at it)
    const bestAt = (m: Metric) => {
      const mine = metricValue(r, m); if (mine == null) return false;
      const others = x.peers.filter((p) => p.id !== r.id && !p.self).map((p) => metricValue(p, m)).filter((v): v is number => v != null);
      return others.length > 0 && (m === 'overdue' ? mine <= Math.min(...others) : mine >= Math.max(...others));
    };
    const metric = order.find((z) => !bestAt(z.m))?.m ?? null;
    if (metric) {
      const effect: VPart = metric === 'target' || metric === 'growth'
        ? (money && r.sales && r.sales.prev > r.sales.v ? { t: 'back to last year’s level = {v} more sales a year', v: { v: eurS(r.sales.prev - r.sales.v) }, money: true } : { t: 'a 30-day plan with named customers and countries' })
        : metric === 'customers' ? (money && slowGap > 0 ? { t: 'winning back a third of what slowing customers stopped buying ≈ {v} a year', v: { v: eurS(slowGap / 3) }, money: true } : { t: '{n} slowing customers get a call plan', v: { n: r.customers.slowing } })
        : metric === 'price' ? { t: 'closing half the price gap ≈ {v} a year', v: { v: eurS(priceGap / 2) }, money: true }
        : metric === 'overdue' ? { t: '{n} customers stop waiting for the promised answer', v: { n: od } }
        : { t: 'back to the team average = {n} more contacts a year', v: { n: Math.max(0, Math.round((x.teamAct ?? ap) - a)) } };
      options.push({ kind: 'coach', title: { t: 'Coach {name} on {m}', v: { name: first, m: METRIC_LABEL[metric] } }, effect, to: null, action: 'coach' });
      // pair with the colleague strongest at it
      const low = metric === 'overdue';
      const cands = x.peers.filter((p) => p.id != null && p.id !== r.id && p.id !== x.viewer.id && !p.self && metricValue(p, metric) != null && (metric !== 'target' && metric !== 'growth' && metric !== 'price' && metric !== 'customers' ? true : p.customers.total > 0));
      const best = cands.sort((p, q) => (low ? (metricValue(p, metric)! - metricValue(q, metric)!) : (metricValue(q, metric)! - metricValue(p, metric)!)))[0];
      const mine = metricValue(r, metric);
      const GAP: Record<Metric, number> = { target: 10, growth: 5, customers: 5, price: 3, overdue: 0, activity: 0 };
      const bv = best ? metricValue(best, metric)! : null;
      const clear = bv != null && mine != null && (metric === 'overdue' ? bv <= mine * 0.8 : metric === 'activity' ? bv >= mine * 1.2 : bv - mine >= GAP[metric]);
      if (best && mine != null && clear) {
        const moneyMetric = metric === 'target' || metric === 'growth' || metric === 'price';
        options.push({ kind: 'pair', title: { t: 'Pair {name} with {other}', v: { name: first, other: best.name } }, effect: { t: '{other} is the strongest at {m}: {a} vs {b}', v: { other: best.name.split(' ')[0], m: METRIC_LABEL[metric], a: metricShow(metric, metricValue(best, metric)), b: metricShow(metric, mine) }, money: moneyMetric }, to: null, money: moneyMetric });
      }
    }
    const isAdmin = x.viewer.role === 'admin';
    const top = [...d.countries].sort((p, q) => q.untouched - p.untouched)[0];
    // reassign customers / move a country: when he cannot reach his countries (much untouched, many late follow-ups)
    const untouched = d.countries.reduce((s, c) => s + c.untouched, 0);
    if (top && untouched >= 40 && (od >= 10 || d.countries.length >= 6)) {
      options.push({ kind: 'reassign', title: { t: 'Move {c} or reassign its customers', v: { c: top.country } }, effect: { t: '{n} companies there nobody contacted for a year get an owner with time for them', v: { n: top.untouched } }, to: isAdmin ? '/admin/countries' : null, note: isAdmin ? null : { t: 'The admin does it on Admin > Countries' } });
    }
    // adjust the target
    if (money && r.sales && r.sales.targetPct != null && (r.sales.targetPct < 70 || r.sales.targetPct > 130)) {
      options.push({ kind: 'target', title: { t: r.sales.targetPct < 70 ? 'Lower the target' : 'Raise the target' }, effect: { t: 'target {t}, sales of the last 12 months {v}: a target near what he can reach keeps it motivating', v: { t: eurS(r.sales.target ?? 0), v: eurS(r.sales.v) }, money: true }, to: isAdmin || hasMenu(x.viewer as never, 'targets') ? '/targets' : null, money: true });
    }
    // a trip to the country with the most untouched companies
    if (top && top.untouched >= 15) {
      options.push({ kind: 'trip', title: { t: 'Plan a trip to {c}', v: { c: top.country } }, effect: { t: '{n} companies in {c} nobody contacted for a year, {v} looked after by colleagues', v: { n: top.untouched, c: top.country, v: top.viewOnly } }, to: '/trips' });
    }
    // a price review
    if (money && (disc.length >= 5 || (r.price?.index != null && r.price.index < 92))) {
      options.push({ kind: 'price', title: { t: 'Price review with {name}', v: { name: first } }, effect: { t: '{n} customers under index 90; closing half the gap ≈ {v} a year', v: { n: disc.length, v: eurS(priceGap / 2) }, money: true }, to: '/performance?tab=pprice', money: true });
    }
  }
  return { status, points, reasons, strengths: strengths.slice(0, 3), metric, options };
}
// the average of calls+visits+meetings+offers in a team (every person counted)
export const teamActAvg = (rows: Row[]): number | null => (rows.length ? rows.reduce((s, r) => s + actSum(r.act), 0) / rows.length : null);

// The status always counts every signal, also for a viewer without the money switch: he gets the same status as a viewer with money,
// only the reasons, strengths and options that carry euros (or sales and price figures) are left out, and an option's euro effect is blanked.
export function verdictOf(x: VerdictInput, withMoney?: () => VerdictInput): Verdict {
  if (x.money || !withMoney) return verdictFor(x);
  return verdictNoMoney(verdictFor(withMoney()));
}
export function verdictNoMoney(v: Verdict): Verdict {
  const keep = <T extends { money?: boolean }>(l: T[]): T[] => l.filter((z) => !z.money);
  return { ...v, reasons: keep(v.reasons), strengths: keep(v.strengths), options: keep(v.options).map((o) => (o.effect.money ? { ...o, effect: { t: '' } } : o)) };
}
// the verdict input of one person worked out with money (for verdictOf): his row, the team of his peers, the peers' own rows
export function verdictInputWithMoney(viewer: Viewer, subject: Person, peers: Person[], options: boolean): VerdictInput {
  const c = context(true);
  const me = rowFor(c, [subject]);
  const team = peers.length > 2 ? rowFor(c, peers, 'Team') : null;
  const peerRows = peers.filter((p) => p.id !== subject.id).map((p) => strip(rowFor(c, [p])));
  return { row: me, rows: me._rows, money: true, teamAct: team ? teamActAvg([strip(me), ...peerRows]) : null, team: team ? strip(team) : null, peers: peerRows, d: detailsFor(viewer, subject, me._rows, true), viewer: viewer as never, options };
}
