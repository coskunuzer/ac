// Price performance: the tab of the Performance page that shows, for each sales person, their customers' status, success and value, and the
// price they sell at - against the same customer last year, against the company average for the same products, and against the price list.
// One call per view: GET /api/price-perf?user=<id>|team&period=12m|ytd|ly (the server decides who may see whom).
import { h, Fragment, useState, useEffect, useMemo, useRef, api, Link, useNavigate, useT, Icon, cx, errText, eur, Skel, Empty, loc, pctTxt, useTx } from "./x-kit-1W3jRMzJ.js";
const dmy = (iso) => (iso && /^\d{4}-\d{2}-\d{2}/.test(iso) ? new Intl.DateTimeFormat(loc(), { day: "2-digit", month: "2-digit", year: "numeric", timeZone: "UTC" }).format(new Date(iso.slice(0, 10) + "T12:00:00Z")) : iso || "–");

const STATUS = ["active", "new", "slowing", "passive", "lost"];
const STATUS_LABEL = { active: "Active", new: "New", slowing: "Slowing", passive: "Passive", lost: "Lost" };
const STATUS_HINT = {
  active: "Bought in the last 6 months, steady or growing",
  new: "First purchase in the last 12 months",
  slowing: "Bought lately, but the last 12 months are under 75% of the 12 months before",
  passive: "Nothing bought for 6 to 12 months",
  lost: "Nothing bought for more than 12 months",
};
const PERIODS = [["12m", "Last 12 months"], ["ytd", "This year"], ["ly", "Last year"]];
const GROUP_LABEL = { Melamin: "Melamine", "Metal - Ayna": "Metal / mirror", "PVC - Tapa": "PVC caps", "Ahşap": "Wood" };

const num = (v, d = 0) => (v == null || !Number.isFinite(v) ? "–" : Number(v).toLocaleString(loc(), { minimumFractionDigits: d, maximumFractionDigits: d }));
const signed = (v, d = 1) => (v == null ? "–" : (v > 0 ? "+" : v < 0 ? "−" : "") + pctTxt(num(Math.abs(v), d)));
const kgText = (v) => (v == null ? "–" : v >= 100000 ? num(v / 1000, 0) + " t" : num(v) + " kg");
const priceText = (v) => (v == null ? "–" : "€" + num(v, 2));
const ptsText = (v) => (v == null ? "–" : (v > 0 ? "+" : v < 0 ? "−" : "") + num(Math.abs(v), 1));
const unitText = (u) => (u === "m2" ? "m²" : "kg");
const tone = (v, good = 0) => (v == null ? "" : v > good ? "up" : v < good ? "down" : "");
const custUrl = (c) => (c.cardId ? `/cards/${c.cardId}/review?tab=details` : null);

export function PricePerf() {
  const t = useTx("pp");
  const [user, setUser] = useState("");
  const [period, setPeriod] = useState("12m");
  const [data, setData] = useState(null);
  const [err, setErr] = useState(null);
  const [busy, setBusy] = useState(false);
  const [filter, setFilter] = useState("");
  useEffect(() => {
    let alive = true;
    setBusy(true);
    const q = new URLSearchParams();
    if (user) q.set("user", user);
    q.set("period", period);
    api
      .get(`/price-perf?${q}`)
      .then((d) => { if (alive) { setData(d); setErr(null); setBusy(false); } })
      .catch((e) => { if (alive) { setErr(errText(e, t("Could not open it"))); setBusy(false); } });
    return () => { alive = false; };
  }, [user, period]);

  if (err && !data) return h("div", { className: "pp" }, h(Empty, { icon: "info", title: t("Price performance") }, t(err)));
  if (!data) return h("div", { className: "pp" }, h("div", { className: "pp-tiles" }, [1, 2, 3, 4, 5, 6].map((i) => h(Skel, { key: i, height: 92 }))), h(Skel, { height: 300 }));
  if (!data.hasData)
    return h("div", { className: "pp" }, h(Empty, { icon: "info", title: t("No sales list yet") }, t("Price performance is worked out from the SAP sales list (Sales intelligence). It shows here once an admin has uploaded it.")));

  const s = data.summary;
  const sel = String(data.user);
  const who = sel === "team" ? t("The whole team") : (data.people.find((p) => String(p.id) === sel) || {}).name || "";
  const perLabel = t((PERIODS.find((p) => p[0] === data.period) || PERIODS[0])[1]);
  const vsLabel = data.period === "ly" ? t("vs the year before") : t("vs a year earlier");
  return h(
    "div",
    { className: cx("pp", busy && "pp--busy") },
    // ---- who and when
    h(
      "div",
      { className: "pp-bar" },
      h("div", { className: "pp-who" }, h("h2", null, who), h("p", null, t("Customers, success and price"), " · ", perLabel, " · ", t("data as of"), " ", data.asOf)),
      h(
        "div",
        { className: "pp-controls" },
        data.canTeam &&
          h(
            "label",
            { className: "pp-select" },
            h("span", null, t("Person")),
            h(
              "select",
              { value: sel, onChange: (e) => { setUser(e.target.value); setFilter(""); }, "aria-label": t("Person") },
              h("option", { value: "team" }, t("The whole team")),
              data.people.map((p) => h("option", { key: p.id, value: String(p.id) }, p.name + (p.self ? " (" + t("you") + ")" : ""))),
            ),
          ),
        h(
          "div",
          { className: "theme-switch pp-period", role: "group", "aria-label": t("Period") },
          PERIODS.map(([k, l]) => h("button", { key: k, type: "button", "aria-pressed": data.period === k, onClick: () => setPeriod(k) }, t(l))),
        ),
      ),
    ),
    // ---- the tiles
    h(
      "div",
      { className: "pp-tiles" },
      h(Tile, { label: t("Customers buying"), value: num(s.buying), sub: t("of {n} with purchases", { n: num(s.customers) }) }),
      h(Tile, { label: t("New this year"), value: num(s.newThisYear), sub: s.conversion.offered ? t("{a} of {b} offered became customers", { a: s.conversion.won, b: s.conversion.offered }) : t("first purchase this year") }),
      h(Tile, { label: t("Revenue") + " · " + perLabel, value: eur(s.rev, { short: true }), delta: s.growth, deltaLabel: vsLabel }),
      h(Tile, { label: t("Average price"), value: s.ppk != null ? priceText(s.ppk) + "/kg" : s.ppm2 != null ? priceText(s.ppm2) + "/m²" : "–", sub: s.ppk != null && s.ppm2 != null ? t("PVC, ABS, PP per kg · melamine, veneer {p}/m²", { p: priceText(s.ppm2) }) : t("PVC, ABS, PP per kg · melamine, veneer per m²") }),
      h(Tile, { label: t("Price index"), value: s.index == null ? "–" : num(s.index, 0), sub: t("100 = average of all customers, same product group, same 12 months"), mark: s.index, hero: true, delta: s.change, deltaPts: true, deltaLabel: t("points vs the 12 months before"), trend: s.trend }),
      h(Tile, {
        label: t("Price realisation"),
        value: s.realisation == null ? "–" : pctTxt(num(s.realisation, 0)),
        sub: s.realisation == null ? (data.list.active ? t("no list price for these products") : t("no active price list")) : t("of the list price"),
      }),
    ),
    h(
      "div",
      { className: "pp-minis" },
      h(Mini, { label: t("Retention"), value: s.retention.pct == null ? "–" : pctTxt(num(s.retention.pct, 0)), sub: t("{a} of {b} customers kept", { a: s.retention.kept, b: s.retention.of }) }),
      h(Mini, { label: t("Offers to first orders"), value: s.conversion.pct == null ? "–" : pctTxt(num(s.conversion.pct, 1)), sub: t("{a} of {b} offered", { a: s.conversion.won, b: s.conversion.offered }) }),
      h(Mini, { label: t("Revenue, last 12 months"), value: eur(s.rev12, { short: true }), sub: signed(s.rev12Growth) + " " + t("vs the 12 months before") }),
      h(Mini, { label: t("Lifetime value"), value: eur(s.lifetime, { short: true }), sub: kgText(s.kg) + " " + perLabel.toLowerCase() }),
      h(Mini, { label: t("Priced well below average"), value: num(s.leaks), sub: t("index under {n}", { n: data.limits.leakIndex }), warn: s.leaks > 0, onClick: s.leaks ? () => setFilter("leak") : null }),
      h(Mini, { label: t("Price fell, volume did not grow"), value: num(s.falls), sub: t("index down {n} points or more", { n: Math.abs(data.limits.fallPts) }), warn: s.falls > 0, onClick: s.falls ? () => setFilter("fall") : null }),
    ),
    // ---- status
    h(StatusBar, { status: s.status, total: s.customers, filter, setFilter }),
    // ---- the chart and the groups
    h(
      "div",
      { className: "pp-grid" },
      h(Scatter, { rows: data.customers, perLabel }),
      h(Groups, { groups: data.groups }),
    ),
    data.canTeam && data.team.length > 0 && h(Team, { team: data.team, sel, onPick: (id) => { setUser(String(id)); setFilter(""); } }),
    h(Customers, { rows: data.customers, filter, setFilter, perLabel, showRep: sel === "team", list: data.list }),
    h(
      "p",
      { className: "pp-foot" },
      t("How the price is judged: EUR per kg for PVC, ABS and PP, EUR per m² for melamine and veneer. The benchmark (100) is the average price of all customers in the same product group in the same 12 months; every period has its own average, years are never mixed. Several groups are weighted by revenue. A group needs at least {q} kg or m² and €{e} in the period to count; below that the price is not judged. Prices use sales only (returns left out); revenue is net of returns.", { q: data.limits.minQty, e: data.limits.minEur }),
    ),
  );
}

function Tile({ label, value, sub, delta, deltaLabel, deltaPts, mark, hero, trend }) {
  const t = useTx("pp");
  return h(
    "div",
    { className: cx("pp-tile", hero && "pp-tile--hero") },
    h("span", { className: "pp-tile-label" }, label),
    h("b", { className: "pp-tile-value" }, value),
    delta !== undefined && h("span", { className: cx("pp-delta", "pp-delta--" + (tone(delta) || "flat")) }, delta == null ? "–" : h(Fragment, null, h("i", { "aria-hidden": true }, delta > 0 ? "▲" : delta < 0 ? "▼" : "•"), deltaPts ? ptsText(delta) : signed(delta)), deltaLabel ? h("small", null, " ", deltaLabel) : null),
    mark != null && h(IndexMeter, { value: mark }),
    trend && trend.length > 1 && h("span", { className: "pp-trend", title: t("Price index per 12-month window") }, trend.map((w, i) => h(Fragment, { key: w.from }, i > 0 && h("i", { "aria-hidden": true }, "→"), h("span", { title: w.from + " – " + w.to }, w.index == null ? "–" : num(w.index, 0))))),
    sub && h("small", { className: "pp-tile-sub" }, sub),
  );
}

// where an index sits between 70 and 130, with the company average (100) marked
function IndexMeter({ value }) {
  const p = Math.max(0, Math.min(100, ((value - 70) / 60) * 100));
  return h("span", { className: "pp-meter", role: "img", "aria-label": "index " + Math.round(value) }, h("span", { className: "pp-meter-mid" }), h("span", { className: cx("pp-meter-dot", value < 90 ? "is-low" : value > 105 ? "is-high" : "") , style: { left: p + "%" } }));
}

function Mini({ label, value, sub, warn, onClick }) {
  const body = [h("b", { key: "v" }, value), h("span", { key: "l" }, label), sub ? h("small", { key: "s" }, sub) : null];
  return onClick ? h("button", { type: "button", className: cx("pp-mini", warn && "pp-mini--warn"), onClick }, body) : h("div", { className: cx("pp-mini", warn && "pp-mini--warn") }, body);
}

function StatusBar({ status, total, filter, setFilter }) {
  const t = useTx("pp");
  const n = total || 1;
  return h(
    "section",
    { className: "pp-card pp-status" },
    h("div", { className: "pp-card-head" }, h("h3", null, t("Customer status")), h("small", null, t("{n} customers with purchases", { n: num(total) }))),
    h(
      "div",
      { className: "pp-seg", role: "img", "aria-label": STATUS.map((k) => `${t(STATUS_LABEL[k])} ${status[k]}`).join(", ") },
      STATUS.filter((k) => status[k] > 0).map((k) => h("span", { key: k, className: "pp-seg-part pp-st--" + k, style: { flexGrow: status[k] }, title: `${t(STATUS_LABEL[k])}: ${status[k]} (${Math.round((status[k] / n) * 100)}%)` })),
    ),
    h(
      "div",
      { className: "pp-legend" },
      STATUS.map((k) =>
        h(
          "button",
          { key: k, type: "button", className: cx("pp-leg", filter === k && "is-on"), "aria-pressed": filter === k, onClick: () => setFilter(filter === k ? "" : k), title: t(STATUS_HINT[k]) },
          h("i", { className: "pp-st--" + k, "aria-hidden": true }),
          h("span", null, t(STATUS_LABEL[k])),
          h("b", null, num(status[k])),
          h("small", null, pctTxt(Math.round((status[k] / n) * 100))),
        ),
      ),
    ),
  );
}

// revenue (log scale) against the price index; four quadrants split by the median revenue and the company average
function Scatter({ rows, perLabel }) {
  const t = useTx("pp");
  const nav = useNavigate();
  const wrap = useRef(null);
  const [w, setW] = useState(640);
  const [hover, setHover] = useState(null);
  useEffect(() => {
    const el = wrap.current;
    if (!el) return undefined;
    const ro = new ResizeObserver(() => setW(Math.max(280, el.clientWidth)));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  const pts = useMemo(() => rows.filter((r) => r.rev > 0 && r.index != null && r.sure), [rows]);
  const hidden = rows.filter((r) => r.rev > 0 && !(r.index != null && r.sure)).length;
  if (pts.length < 2) return h("section", { className: "pp-card pp-chart" }, h("div", { className: "pp-card-head" }, h("h3", null, t("Size and price"))), h(Empty, { icon: "info", title: t("Not enough customers bought in this period") }));
  const H = w < 480 ? 300 : 340;
  const m = { l: 40, r: 12, t: 12, b: 34 };
  const revs = pts.map((p) => p.rev).sort((a, b) => a - b);
  const med = revs[Math.floor(revs.length / 2)];
  const lx0 = Math.log10(Math.max(1, revs[0] * 0.8)), lx1 = Math.log10(revs[revs.length - 1] * 1.25);
  const idx = pts.map((p) => p.index);
  const y0 = Math.min(80, Math.floor((Math.min(...idx) - 4) / 10) * 10), y1 = Math.max(120, Math.ceil((Math.max(...idx) + 4) / 10) * 10);
  const X = (v) => m.l + ((Math.log10(Math.max(1, v)) - lx0) / (lx1 - lx0)) * (w - m.l - m.r);
  const Y = (v) => m.t + (1 - (Math.min(y1, Math.max(y0, v)) - y0) / (y1 - y0)) * (H - m.t - m.b);
  const xTicks = [];
  for (let e = Math.ceil(lx0); e <= Math.floor(lx1); e += 1) xTicks.push(10 ** e);
  const yTicks = [];
  for (let v = y0; v <= y1; v += y1 - y0 > 60 ? 20 : 10) yTicks.push(v);
  const mx = X(med), my = Y(100);
  const q = [
    [t("big & well priced"), w - m.r - 6, m.t + 14, "end"],
    [t("small & well priced"), m.l + 6, m.t + 14, "start"],
    [t("big but discounted"), w - m.r - 6, H - m.b - 8, "end"],
    [t("small & cheap"), m.l + 6, H - m.b - 8, "start"],
  ];
  const hp = hover != null ? pts[hover] : null;
  return h(
    "section",
    { className: "pp-card pp-chart" },
    h("div", { className: "pp-card-head" }, h("h3", null, t("Size and price")), h("small", null, t("each dot is a customer · across: revenue, {p} · up: price index", { p: perLabel.toLowerCase() }))),
    h(
      "div",
      { className: "pp-plot", ref: wrap, onMouseLeave: () => setHover(null) },
      h(
        "svg",
        { width: w, height: H, viewBox: `0 0 ${w} ${H}`, role: "img", "aria-label": t("Customers by revenue and price index") },
        h("rect", { x: mx, y: m.t, width: Math.max(0, w - m.r - mx), height: Math.max(0, my - m.t), className: "pp-q-good" }),
        h("rect", { x: mx, y: my, width: Math.max(0, w - m.r - mx), height: Math.max(0, H - m.b - my), className: "pp-q-warn" }),
        yTicks.map((v) => h("g", { key: "y" + v }, h("line", { x1: m.l, x2: w - m.r, y1: Y(v), y2: Y(v), className: "pp-grid-line" }), h("text", { x: m.l - 6, y: Y(v) + 4, textAnchor: "end", className: "pp-axis" }, v))),
        xTicks.map((v) => h("g", { key: "x" + v }, h("line", { x1: X(v), x2: X(v), y1: m.t, y2: H - m.b, className: "pp-grid-line" }), h("text", { x: X(v), y: H - m.b + 16, textAnchor: "middle", className: "pp-axis" }, eur(v, { short: true })))),
        h("line", { x1: m.l, x2: w - m.r, y1: my, y2: my, className: "pp-ref" }),
        h("line", { x1: mx, x2: mx, y1: m.t, y2: H - m.b, className: "pp-ref" }),
        pts.map((p, i) => h("circle", { key: p.sap, cx: X(p.rev), cy: Y(p.index), r: hover === i ? 7 : 5, className: cx("pp-dot", hover === i && "is-on", p.flags.includes("leak") && "is-leak") })),
        h("text", { x: m.l + 6, y: my - 5, textAnchor: "start", className: "pp-axis pp-axis--ref" }, t("company average") + " = 100"),
        q.map(([l, x, y, a]) => h("text", { key: l, x, y, textAnchor: a, className: "pp-quad" }, l)),
        // the hit targets: bigger than the dots
        pts.map((p, i) =>
          h("circle", {
            key: "h" + p.sap, cx: X(p.rev), cy: Y(p.index), r: 12, className: "pp-hit", tabIndex: 0, role: "button", "aria-label": `${p.name}: ${eur(p.rev)}, index ${num(p.index, 0)}`,
            onMouseEnter: () => setHover(i), onFocus: () => setHover(i), onBlur: () => setHover(null),
            onClick: () => { const u = custUrl(p); if (u) nav(u); },
            onKeyDown: (e) => { if (e.key === "Enter") { const u = custUrl(p); if (u) nav(u); } },
          }),
        ),
        h("text", { x: w - m.r, y: H - 4, textAnchor: "end", className: "pp-axis" }, t("revenue") + " →"),
      ),
      hp &&
        h(
          "div",
          { className: "pp-tip", style: { left: Math.min(w - 210, Math.max(0, X(hp.rev) - 100)), top: Math.max(0, Y(hp.index) - 104) } },
          h("b", null, hp.name),
          h("span", null, h(StatusPill, { s: hp.status }), " ", hp.country),
          h("span", null, t("Revenue"), " ", h("b", null, eur(hp.rev)), " · ", t("index"), " ", h("b", null, num(hp.index, 0))),
          h("span", null, hp.ppk != null ? priceText(hp.ppk) + "/kg" : priceText(hp.ppm2) + "/m²", " · ", t("index trend"), " ", ptsText(hp.change)),
        ),
    ),
    h("p", { className: "pp-legend-line" }, h("i", { className: "pp-key-dot" }), t("customer"), h("i", { className: "pp-key-dot is-leak" }), t("priced well below average"), h("span", null, " · ", t("middle line: half of the customers buy more than {a}", { a: eur(med, { short: true }) })), hidden > 0 ? h("span", null, " · ", t("{n} with too little volume to judge are not shown", { n: hidden })) : null),
  );
}

function Groups({ groups }) {
  const t = useTx("pp");
  return h(
    "section",
    { className: "pp-card pp-groups" },
    h("div", { className: "pp-card-head" }, h("h3", null, t("By product group")), h("small", null, t("price against the average of all customers"))),
    groups.length === 0
      ? h("p", { className: "pp-muted" }, t("Nothing sold in this period."))
      : h(
          "ul",
          null,
          groups.map((g) => {
            const p = g.index == null ? 50 : Math.max(0, Math.min(100, ((g.index - 70) / 60) * 100));
            return h(
              "li",
              { key: g.grp },
              h("div", { className: "pp-g-top" }, h("b", null, g.unit ? t(GROUP_LABEL[g.grp] || g.grp) : t("Other products")), g.unit ? h("span", null, priceText(g.price), "/", unitText(g.unit)) : null, g.unit ? h("small", null, t("avg"), " ", priceText(g.avg)) : h("small", null, t("no price benchmark"))),
              g.unit && h("div", { className: "pp-g-meter", title: g.index == null ? t("Too little volume to judge the price") : null }, h("span", { className: "pp-meter" }, h("span", { className: "pp-meter-mid" }), g.index != null && h("span", { className: cx("pp-meter-dot", g.index < 90 ? "is-low" : g.index > 105 ? "is-high" : ""), style: { left: p + "%" } })), h("b", null, g.index == null ? "–" : num(g.index, 0))),
              h("small", { className: "pp-g-sub" }, eur(g.eur, { short: true }), g.unit ? h(Fragment, null, " · ", g.unit === "kg" ? kgText(g.qty) : num(g.qty) + " m²", " · ", t("index trend"), " ", h("span", { className: "pp-ch pp-ch--" + (tone(g.change) || "flat") }, ptsText(g.change))) : null),
            );
          }),
        ),
  );
}

function Team({ team, sel, onPick }) {
  const t = useTx("pp");
  const [sort, setSort] = useSort("rev", -1);
  const rows = sortRows(team, sort);
  const tot = team.reduce((a, r) => a + r.rev, 0);
  const cols = [["name", "Person"], ["customers", "Customers"], ["rev", "Revenue"], ["growth", "Growth"], ["ppk", "€/kg"], ["index", "Price index"], ["change", "Index trend"], ["realisation", "Realisation"], ["leaks", "Below average"]];
  return h(
    "section",
    { className: "pp-card" },
    h("div", { className: "pp-card-head" }, h("h3", null, t("The team side by side")), h("small", null, t("press a person to see their customers"))),
    h(
      "div",
      { className: "pp-scroll" },
      h(
        "table",
        { className: "pp-table" },
        h("thead", null, h("tr", null, cols.map(([k, l]) => h(Th, { key: k, k, label: t(l), sort, setSort, num: k !== "name" })))),
        h(
          "tbody",
          null,
          rows.map((r) =>
            h(
              "tr",
              { key: r.id, className: cx(String(r.id) === sel && "is-sel") },
              h("td", null, h("button", { type: "button", className: "pp-link", onClick: () => onPick(r.id) }, r.name)),
              h("td", { className: "num" }, num(r.customers), h("small", null, " · ", num(r.buying), " ", t("buying"))),
              h("td", { className: "num" }, eur(r.rev, { short: true }), h("small", null, " ", tot > 0 ? pctTxt(Math.round((r.rev / tot) * 100)) : "")),
              h("td", { className: "num" }, h("span", { className: "pp-ch pp-ch--" + (tone(r.growth) || "flat") }, signed(r.growth))),
              h("td", { className: "num" }, priceText(r.ppk)),
              h("td", { className: "num" }, h(IndexPill, { v: r.index })),
              h("td", { className: "num" }, h("span", { className: "pp-ch pp-ch--" + (tone(r.change) || "flat") }, ptsText(r.change))),
              h("td", { className: "num" }, r.realisation == null ? "–" : pctTxt(num(r.realisation, 0))),
              h("td", { className: "num" }, num(r.leaks)),
            ),
          ),
        ),
      ),
    ),
  );
}

function useSort(k, d) { return useState({ k, d }); }
function sortRows(rows, sort) {
  const v = (r) => { const x = r[sort.k]; return x == null ? null : x; };
  return [...rows].sort((a, b) => {
    const x = v(a), y = v(b);
    if (x === y) return 0;
    if (x == null) return 1;
    if (y == null) return -1;
    if (typeof x === "string") return x.localeCompare(y) * sort.d;
    return (x - y) * sort.d;
  });
}
function Th({ k, label, sort, setSort, num: isNum, title }) {
  const on = sort.k === k;
  return h(
    "th",
    { className: cx(isNum && "num"), "aria-sort": on ? (sort.d > 0 ? "ascending" : "descending") : "none", title },
    h("button", { type: "button", onClick: () => setSort(on ? { k, d: -sort.d } : { k, d: isNum ? -1 : 1 }) }, label, h("i", { "aria-hidden": true }, on ? (sort.d > 0 ? "▲" : "▼") : "")),
  );
}
const StatusPill = ({ s }) => { const t = useTx("pp"); return h("span", { className: "pp-pill pp-pill--" + s, title: t(STATUS_HINT[s]) }, t(STATUS_LABEL[s])); };
const IndexPill = ({ v, unsure }) => { const t = useTx("pp"); return v == null ? h("span", { className: "pp-muted", title: t("Too little volume to judge the price") }, "–") : unsure ? h("span", { className: "pp-idx is-unsure", title: t("Low volume: shown, not judged") }, num(v, 0), "?") : h("span", { className: cx("pp-idx", v < 90 ? "is-low" : v >= 105 ? "is-high" : "") }, num(v, 0)); };

function Customers({ rows, filter, setFilter, perLabel, showRep, list }) {
  const t = useTx("pp");
  const [sort, setSort] = useSort("rev12", -1);
  const [q, setQ] = useState("");
  const [all, setAll] = useState(false);
  const shown = useMemo(() => {
    const f = q.trim().toLowerCase();
    return sortRows(
      rows.filter((r) => (!filter || r.status === filter || r.flags.includes(filter)) && (!f || r.name.toLowerCase().includes(f) || (r.country || "").toLowerCase().includes(f) || r.sap.includes(f))),
      sort,
    );
  }, [rows, filter, q, sort]);
  const page = all ? shown : shown.slice(0, 60);
  const FILTERS = [["", "All"], ["leak", "Priced well below average"], ["fall", "Price fell"], ...STATUS.map((k) => [k, STATUS_LABEL[k]])];
  const cols = [
    ["name", "Customer", false], ["status", "Status", false], ["rev12", "Revenue 12 months", true], ["growth", "Change", true], ["kg", "kg", true],
    ["ppk", "Price", true], ["index", "Index", true], ["change", "Index trend", true], ["realisation", "Realisation", true], ["last", "Last purchase", true],
  ].filter((c) => c[0] !== "realisation" || list.active);
  return h(
    "section",
    { className: "pp-card pp-custs" },
    h("div", { className: "pp-card-head" }, h("h3", null, t("Customers")), h("small", null, t("{n} shown", { n: num(shown.length) }), " · ", t("change, kg, prices: {p}", { p: perLabel.toLowerCase() }))),
    h(
      "div",
      { className: "pp-filters" },
      h(
        "label",
        { className: "pp-sortsel" },
        h("span", null, t("Sort by")),
        h("select", { value: sort.k, onChange: (e) => { const k = e.target.value; setSort({ k, d: k === "name" ? 1 : -1 }); } }, cols.map(([k, l]) => h("option", { key: k, value: k }, t(l)))),
      ),
      h("input", { type: "search", className: "pp-search", value: q, onChange: (e) => setQ(e.target.value), placeholder: t("Find a customer"), "aria-label": t("Find a customer") }),
      h("div", { className: "pp-chips" }, FILTERS.map(([k, l]) => h("button", { key: k || "all", type: "button", className: cx("pp-chip", filter === k && "is-on"), "aria-pressed": filter === k, onClick: () => setFilter(k) }, t(l)))),
    ),
    shown.length === 0
      ? h(Empty, { icon: "search", title: t("No customer fits") })
      : h(
          "div",
          { className: "pp-scroll" },
          h(
            "table",
            { className: "pp-table pp-table--custs" },
            h("thead", null, h("tr", null, cols.map(([k, l, n]) => h(Th, { key: k, k, label: t(l), sort, setSort, num: n })))),
            h(
              "tbody",
              null,
              page.map((r) => {
                const url = custUrl(r);
                return h(
                  "tr",
                  { key: r.sap },
                  h(
                    "td",
                    { className: "pp-name" },
                    url ? h(Link, { to: url }, r.name) : h("span", null, r.name),
                    h("small", null, [r.country, showRep ? r.rep : null, r.sap].filter(Boolean).join(" · ")),
                    r.flags.length > 0 && h("span", { className: "pp-flags" }, r.flags.map((f) => h("span", { key: f, className: "pp-flag" }, h(Icon, { n: "warning", size: 12 }), f === "leak" ? t("well below average") : t("price fell, volume flat")))),
                  ),
                  h("td", { className: "pp-st", "data-l": t("Status") }, h(StatusPill, { s: r.status })),
                  h("td", { className: "num", "data-l": t("Revenue 12 months") }, eur(r.rev12), r.share != null && r.share >= 1 ? h("small", null, t("{p} of total", { p: pctTxt(num(r.share, 0)) })) : null),
                  h("td", { className: "num", "data-l": t("Change") }, h("span", { className: "pp-ch pp-ch--" + (tone(r.growth) || "flat") }, r.revPrev > 0 ? signed(r.growth) : r.rev > 0 ? t("new") : "–")),
                  h("td", { className: "num", "data-l": t("kg") }, num(r.kg)),
                  h("td", { className: "num", "data-l": t("Price") }, r.ppk != null ? priceText(r.ppk) + "/kg" : r.ppm2 == null ? "–" : null, r.ppm2 != null ? h("small", null, priceText(r.ppm2) + "/m²") : null),
                  h("td", { className: "num", "data-l": t("Index") }, h(IndexPill, { v: r.index, unsure: r.index != null && !r.sure })),
                  h("td", { className: "num", "data-l": t("Index trend"), title: r.indexPrev != null && r.index != null ? num(r.indexPrev, 0) + " → " + num(r.index, 0) : null }, h("span", { className: "pp-ch pp-ch--" + (tone(r.change) || "flat") }, ptsText(r.change))),
                  list.active ? h("td", { className: "num", "data-l": t("Realisation") }, r.realisation == null ? h("span", { className: "pp-muted", title: t("no list price for these products") }, "–") : pctTxt(num(r.realisation, 0))) : null,
                  h("td", { className: "num", "data-l": t("Last purchase") }, dmy(r.last)),
                );
              }),
            ),
          ),
        ),
    shown.length > page.length && h("div", { className: "pp-more" }, h("button", { type: "button", className: "btn btn-secondary btn-sm", onClick: () => setAll(true) }, t("Show all {n}", { n: num(shown.length) }))),
  );
}
