import { db } from '../db/connection';

// Time in the app: the open page reports every 30 seconds while the person is there and active (mouse, keys, touch in the last
// two minutes, page in front). The server counts what it can believe: never more than the time since the last report, so two
// open tabs do not count double.
const lastPing = new Map<number, number>();

export const dayOf = (d = new Date()) => d.toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });

export function ping(userId: number, seconds: number): void {
  const now = Date.now();
  const since = lastPing.get(userId);
  lastPing.set(userId, now);
  const gap = since === undefined ? seconds : Math.round((now - since) / 1000) + 2;
  const add = Math.max(0, Math.min(Math.round(seconds), 60, gap));
  if (add <= 0) return;
  db.prepare('INSERT INTO app_time (user_id, day, seconds) VALUES (?, ?, ?) ON CONFLICT(user_id, day) DO UPDATE SET seconds = seconds + excluded.seconds').run(userId, dayOf(), add);
}

// Seconds per person between two days (both included, "YYYY-MM-DD").
export function secondsBetween(userIds: number[], fromDay: string, toDay: string): Map<number, number> {
  const out = new Map<number, number>();
  if (!userIds.length) return out;
  const rows = db
    .prepare(`SELECT user_id, SUM(seconds) AS s FROM app_time WHERE user_id IN (${userIds.map(() => '?').join(',')}) AND day >= ? AND day <= ? GROUP BY user_id`)
    .all(...userIds, fromDay, toDay) as { user_id: number; s: number }[];
  for (const r of rows) out.set(r.user_id, r.s);
  return out;
}

export function secondsPerDay(userId: number, fromDay: string, toDay: string): { day: string; seconds: number }[] {
  return db.prepare('SELECT day, seconds FROM app_time WHERE user_id = ? AND day >= ? AND day <= ? ORDER BY day').all(userId, fromDay, toDay) as { day: string; seconds: number }[];
}

export const shiftDay = (d: string, by: number) => {
  const x = new Date(`${d}T12:00:00Z`);
  x.setUTCDate(x.getUTCDate() + by);
  return x.toISOString().slice(0, 10);
};
