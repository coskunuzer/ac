import { db } from '../db/connection';
import { cardModel, type CardRow } from '../models/cardModel';
import { cityModel } from '../models/cityModel';
import { countryModel } from '../models/countryModel';
import { settingsModel } from '../models/settingsModel';

// Who usually looks after a customer: the person of its city (domestic) or of its country (export).
export function usualOwner(card: Pick<CardRow, 'market' | 'country' | 'city'>): string | null {
  const who = card.market === 'domestic' ? cityModel.findByCity(card.city)?.responsible : countryModel.findByCountry(card.country)?.responsible;
  return who?.trim() || null;
}

// A customer given to somebody else than the usual person of its country is theirs alone: the person of the country
// no longer sees it (services/visibility.ts). Run after the person or the country of a customer changed, and after a merge.
export function refreshOwnerOverride(cardId: number): void {
  const card = cardModel.findById(cardId);
  if (!card) return;
  const person = (card.person ?? '').trim();
  const usual = usualOwner(card);
  const override = person && usual && person !== usual ? 1 : 0;
  if ((card.owner_override ?? 0) !== override) db.prepare('UPDATE cards SET owner_override = ? WHERE id = ?').run(override, cardId);
}

// Once, for the customers that exist already.
export function backfillOwnerOverrides(): number {
  if (settingsModel.get('owner_override_backfilled') === '1') return 0;
  const rows = db.prepare("SELECT id, person, market, country, city FROM cards WHERE person IS NOT NULL AND TRIM(person) != ''").all() as unknown as Pick<CardRow, 'id' | 'person' | 'market' | 'country' | 'city'>[];
  const owners = new Map<string, string | null>();
  const set = db.prepare('UPDATE cards SET owner_override = 1 WHERE id = ?');
  let n = 0;
  db.exec('BEGIN');
  try {
    for (const c of rows) {
      const key = `${c.market === 'domestic' ? 'd' : 'e'}|${c.market === 'domestic' ? c.city : c.country}`;
      if (!owners.has(key)) owners.set(key, usualOwner(c));
      const usual = owners.get(key);
      if (usual && (c.person ?? '').trim() !== usual) { set.run(c.id); n += 1; }
    }
    db.exec('COMMIT');
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
  settingsModel.set('owner_override_backfilled', '1');
  return n;
}
