import fs from 'fs';
import path from 'path';
import type PDFDocument from 'pdfkit';
import { formatCell, type FormatOptions } from './numfmt';
import type { CellRange, Evaluator, SheetData } from './workbook';
import type { OfferContext, OfferParams } from './index';
import { label, LOCALE } from '../offerI18n';

type Doc = InstanceType<typeof PDFDocument>;

// The offer in the TECE design system (Kurumsal Kimlik 1.8) - the same look as the app: Montserrat; TECE
// navy, red and graphite; a graphite header with the white logo; headlines with the red underline under the
// key word; square cards with a thin border; steel-grey column heads over a dark rule; outlined pills; no
// shadows, no gradients. The *content and order* are the price workbook's own - the same pages, rows, columns
// and notes. Each product is ONE page: the type shrinks a little, down to a readable minimum, until it fits, and
// every width is a column of that page.

const ASSETS = path.resolve(__dirname, '../../../assets');
const FONT_DIR = path.join(ASSETS, 'fonts');
const RED = '#8B1931';
const NAVY = '#17243E';
const GRAPHITE = '#252525';
const STEEL = '#5E6676';
const SMOKE = '#E3E6EC';
const MIST = '#F3F4F7';
const INK = '#252525';

const PAGE = { w: 595.28, h: 841.89 };
const L = 40;
const CW = PAGE.w - 2 * L;
const BAND = 64; // the navy header
const BOTTOM = PAGE.h - 52; // above the footer
const MIN_SCALE = 0.6;

export function registerDesignFonts(doc: Doc) {
  doc.registerFont('TD-300', path.join(FONT_DIR, 'Montserrat-400.ttf'));
  doc.registerFont('TD-400', path.join(FONT_DIR, 'Montserrat-400.ttf'));
  doc.registerFont('TD-500', path.join(FONT_DIR, 'Montserrat-500.ttf'));
  doc.registerFont('TD-600', path.join(FONT_DIR, 'Montserrat-600.ttf'));
  doc.registerFont('TD-700', path.join(FONT_DIR, 'Montserrat-700.ttf'));
}

// The logo is vector: its paths are drawn straight into the PDF (sharp at any size).
const logoCache = new Map<string, { w: number; h: number; paths: { d: string; fill: string }[] }>();
function loadLogo(file: string) {
  if (logoCache.has(file)) return logoCache.get(file)!;
  const svg = fs.readFileSync(path.join(ASSETS, 'brand', file), 'utf8');
  const vb = /viewBox="0 0 ([\d.]+) ([\d.]+)"/.exec(svg);
  const paths = [...svg.matchAll(/<path[^>]*?fill="(#[0-9A-Fa-f]{6})"[^>]*?d="([^"]+)"/g)].map((m) => ({ fill: m[1], d: m[2] }));
  const logo = { w: vb ? parseFloat(vb[1]) : 1, h: vb ? parseFloat(vb[2]) : 1, paths };
  logoCache.set(file, logo);
  return logo;
}
export function drawLogo(doc: Doc, file: string, x: number, y: number, width: number): number {
  const logo = loadLogo(file);
  const scale = width / logo.w;
  doc.save();
  doc.translate(x, y);
  doc.scale(scale);
  for (const p of logo.paths) doc.path(p.d).fill(p.fill);
  doc.restore();
  return logo.h * scale;
}

interface Layout {
  tab: string;
  titleAddr: string;
  headerRow: number;
  firstRow: number;
  lastRow: number;
  columns: { id: string; index: number; hidden?: boolean }[];
  dataRows: number[];
  hiddenRows: Set<number>;
}

export interface DesignedJob {
  doc: Doc;
  sheet: SheetData;
  layout: Layout;
  wantRows: Set<number>; // 0-based rows the offer includes
  wantCols: Set<number>; // 0-based columns the offer includes
  area: CellRange;
  // one evaluator per group of widths (a tab has three width columns, Melamine two), with the widths of each group
  evGroups: Evaluator[];
  groupWidths: number[][];
  widthCols: { index: number; slot: number }[];
  format: FormatOptions;
  ctx: OfferContext;
  params: OfferParams;
  letterhead: { header: Buffer | null; footer: Buffer | null };
}

const clean = (s: string) => s.replace(/\s+/g, ' ').trim();
const lines = (v: unknown) => String(v ?? '').replace(/\r/g, '').split('\n').map((s) => s.trim()).filter(Boolean);

interface Col {
  head: string;
  cells: string[]; // one per data row
  nums: boolean[];
  num: boolean;
  pill: boolean; // the thickness: drawn as an outlined pill
}

interface Item {
  kind: 'row' | 'gap' | 'group';
  name: string;
  sub: string;
}

interface Section {
  title: string;
  items: string[];
}

export function drawDesignedSheet(job: DesignedJob): void {
  const { doc, sheet, layout, format, ctx, params } = job;
  registerDesignFonts(doc);
  const tab = layout.tab;
  const ev0 = job.evGroups[0];
  // the language of this offer: the fixed words come from offerI18n, the texts of the workbook through ctx.tr (the AI, remembered)
  const lang = ctx.lang ?? 'en';
  const loc = (LOCALE as Record<string, string>)[lang] ?? 'en-GB';
  const T = (s: string): string => (ctx.tr && s ? ctx.tr(s) : s);
  const lab = (k: Parameters<typeof label>[1]) => label(lang, k);

  // ---- what goes on the page -------------------------------------------------------------
  const sd = sheet;
  const cellText = (ev: Evaluator, addr: string): string => {
    const raw = sd.cells.get(addr);
    const v = ev.value(tab, addr);
    if (v === null || v === undefined || v === '') return '';
    return typeof v === 'number' || typeof v === 'boolean' ? formatCell(v, raw?.z, format) : String(v).replace(/\r/g, '').trim();
  };

  const rawTitle = clean(String(ev0.value(tab, layout.titleAddr) ?? ''));
  const [titleMain, ...titleRest] = rawTitle.split('||').map((s) => clean(s.replace(/\|\s*$/, '')));
  const subtitle = T(titleRest.filter(Boolean).join(' · '));
  // "Offer for PVC Edgebanding": the first words are quiet, the product is the headline (with the red underline)
  const titleMatch = /^(offer for|offer)\s+(.*)$/i.exec(titleMain || tab);
  const titleLead = titleMatch ? `${titleMatch[1]} ` : '';
  const titleKey = titleMatch ? titleMatch[2] : titleMain || tab;

  // the rows this offer includes (the Excel's hidden rows too, when they were asked for)
  const items: Item[] = [];
  const dataRowNumbers: number[] = [];
  let pendingGap = false;
  let pendingGroup = '';
  for (let r = layout.firstRow; r <= layout.lastRow; r++) {
    if (layout.dataRows.includes(r)) {
      if (!job.wantRows.has(r)) continue;
      if (pendingGroup) items.push({ kind: 'group', name: T(pendingGroup), sub: '' });
      else if (pendingGap && items.length) items.push({ kind: 'gap', name: '', sub: '' });
      pendingGap = false;
      pendingGroup = '';
      const nameLines = lines(ev0.value(tab, `B${r + 1}`));
      const first = (nameLines[0] ?? '').split(/\s*\|\s*/);
      items.push({ kind: 'row', name: T(first[0] ?? ''), sub: T([...first.slice(1), ...nameLines.slice(1)].join(' · ')) });
      dataRowNumbers.push(r);
    } else if (!layout.hiddenRows.has(r) && (sd.rowHeightPt.get(r) ?? 15) > 0.5 && !sd.hiddenRows.has(r)) {
      const b = clean(String(ev0.value(tab, `B${r + 1}`) ?? ''));
      if (b && !b.startsWith('>>')) pendingGroup = b;
      else pendingGap = true;
    }
  }

  // the columns: the sheet's own, in its order; the width columns become one column for every width
  const allWidths = job.groupWidths.flat();
  const per = job.groupWidths.length ? Math.max(...job.groupWidths.map((g) => g.length)) : 3;
  const widthIndexes = new Set(job.widthCols.map((w) => w.index));
  const cols: Col[] = [];
  const build = (ev: Evaluator, id: string): Col => {
    const vals = dataRowNumbers.map((r) => ev.value(tab, `${id}${r + 1}`));
    const head = T(clean(cellText(ev, `${id}${layout.headerRow + 1}`)));
    return {
      head,
      cells: dataRowNumbers.map((r) => T(cellText(ev, `${id}${r + 1}`))),
      nums: vals.map((v) => typeof v === 'number'),
      num: false,
      pill: /^thickness$/i.test(head), // the thickness: bold, to the right
    };
  };
  let widthsDone = false;
  for (const c of layout.columns) {
    if (!job.wantCols.has(c.index)) continue;
    if (widthIndexes.has(c.index)) {
      if (widthsDone) continue;
      widthsDone = true;
      allWidths.forEach((_, k) => {
        const group = Math.floor(k / per);
        const slot = k % per;
        const wc = job.widthCols.find((w) => w.slot === slot);
        if (!wc || !job.evGroups[group]) return;
        const id = layout.columns.find((x) => x.index === wc.index)!.id;
        cols.push(build(job.evGroups[group], id));
      });
      continue;
    }
    cols.push(build(ev0, c.id));
  }
  // a column with nothing in it on this page is left out; numbers decide the alignment
  const shown = cols.filter((c) => c.cells.some(Boolean));
  for (const c of shown) {
    const filled = c.cells.filter(Boolean).length;
    c.num = !c.pill && filled > 0 && c.nums.filter((n, i) => n && c.cells[i]).length * 2 >= filled;
  }

  // notes under the table (the worksheet's own wording; the terms come from the offer itself)
  const widthList = allWidths.length <= 1 ? `${allWidths[0] ?? ''}` : `${allWidths.slice(0, -1).join(', ')} and ${allWidths[allWidths.length - 1]}`;
  const sections: Section[] = [];
  let current: Section | null = null;
  const endRow = Math.min(job.area.r2, sd.maxRow - 1);
  for (let r = layout.lastRow + 1; r <= endRow; r++) {
    const b = cellText(ev0, `B${r + 1}`);
    if (!b) continue;
    if (b.startsWith('>>')) {
      const title = b.replace(/^>>\s*/, '').replace(/:\s*$/, '');
      if (/^terms/i.test(title)) {
        current = null;
      } else {
        current = { title: T(title), items: [] };
        sections.push(current);
      }
      continue;
    }
    if (!current) continue;
    // "The width is 0mm" in the worksheet is a template slip: name the real widths
    current.items.push(T(b.replace(/The width is\s*\d+(?:[.,]\d+)?\s*mm\.?\s*It is possible to have different width\.?/i, `The widths are ${widthList} mm. It is possible to have different widths.`)));
  }
  const terms = ([
    [lab('delivery'), T(params.deliveryTerm)],
    [lab('payment'), T(params.paymentTerm)],
    [lab('dispatch'), T(params.dispatchTime)],
  ] as [string, string][]).filter(([, v]) => !!v);
  const noteLines = (sec: Section) => sec.items.flatMap((i) => i.split('\n')).map((s) => s.trim()).filter(Boolean);

  const longDate = ctx.date.toLocaleDateString(loc, { day: 'numeric', month: 'long', year: 'numeric' });
  const customer = [clean(ctx.company ?? ''), ...lines(ctx.address), clean(ctx.country ?? ''), ctx.tel ? `Tel: ${ctx.tel}` : '', ctx.email ?? ''].filter(Boolean);
  const offerLines: [string, string][] = [
    [lab('date'), longDate],
    [lab('preparedBy'), ctx.preparedBy],
    [lab('currency'), params.currency === 'USD' ? lab('usd') : lab('eur')],
  ];

  // ---- one pass that either measures or draws, at a given scale ---------------------------------
  let y = 0;
  const startY = BAND + 30;

  const pageFurniture = () => {
    doc.addPage({ size: [PAGE.w, PAGE.h], margin: 0 });
    // the header: TECE navy with the white logo and slogan, the red rule, what this is and when
    doc.rect(0, 0, PAGE.w, BAND).fill(NAVY);
    drawLogo(doc, 'TECE_SloganliLogo_Beyaz_RGB.svg', L, (BAND - 260 * (522 / 5990)) / 2, 260);
    // our mark instead of the title: since 1987
    doc.font('TD-600').fontSize(7).fillColor('#FFFFFF').fillOpacity(0.75).text('SINCE', L, 17, { width: CW, align: 'right', characterSpacing: 2.6, lineBreak: false });
    doc.fillOpacity(1).font('TD-700').fontSize(24).fillColor('#FFFFFF').text('1987', L, 26, { width: CW, align: 'right', characterSpacing: 1.6, lineBreak: false });
    doc.rect(0, BAND, PAGE.w, 3).fill(RED);
    // the footer: a navy strip with the company on the left and how to reach it on the right
    const fh = 38;
    const fy = PAGE.h - fh;
    doc.rect(0, fy, PAGE.w, fh).fill(NAVY);
    doc.rect(0, fy, PAGE.w, 2).fill(RED);
    doc.font('TD-700').fontSize(6.6).fillColor('#FFFFFF').text('TECE DEKOR A.S.  ·  THE EDGEBANDING COMPANY', L, fy + 11, { width: CW * 0.58, characterSpacing: 0.6, lineBreak: false });
    doc.font('TD-400').fontSize(6.2).fillColor('#FFFFFF').fillOpacity(0.7).text('Işıktepe OSB, 75. Yıl Bulvarı No:14, Nilüfer / Bursa 16140 Türkiye', L, fy + 22, { width: CW * 0.62, lineBreak: false });
    doc.fillOpacity(1).font('TD-600').fontSize(6.8).fillColor('#FFFFFF').text('+90 224 242 21 00', L, fy + 11, { width: CW, align: 'right', lineBreak: false });
    doc.font('TD-400').fontSize(6.4).fillColor('#FFFFFF').fillOpacity(0.7).text('info@tece.com.tr  ·  tece.com.tr', L, fy + 22, { width: CW, align: 'right', lineBreak: false });
    doc.fillOpacity(1);
  };
  const newPage = () => {
    pageFurniture();
    y = startY;
  };

  function pass(s: number, draw: boolean, stacked: boolean): number {
    const f = (n: number) => n * s;
    const PAD = 6;
    const measureH = (font: string, size: number, text: string, width: number, extra: Record<string, unknown> = {}) => {
      doc.font(font).fontSize(size);
      return doc.heightOfString(text, { width, ...extra });
    };
    if (draw) newPage();
    else y = startY;
    const yStart = y;

    // the headline: "Offer for PVC Edgebanding" in bold with a short red bar under it
    const titleSize = Math.max(16, f(21));
    const titleFull = T(`${titleLead}${titleKey}`);
    const titleH = measureH('TD-700', titleSize, titleFull, CW);
    if (draw) {
      doc.font('TD-700').fontSize(titleSize).fillColor(NAVY).text(titleFull, L, y, { width: CW });
      doc.rect(L, y + titleH + 4, 32, 3).fill(RED);
    }
    y += titleH + 4 + 3 + f(10);
    if (subtitle) {
      if (draw) doc.font('TD-400').fontSize(f(8.2)).fillColor(STEEL).text(subtitle, L, y, { width: CW });
      y += measureH('TD-400', f(8.2), subtitle, CW) + f(4);
    }
    y += f(4);

    // two cards: who it is for, what it is (tinted, with a navy bar)
    const gap = 12;
    const leftW = CW * 0.56;
    const rightW = CW - leftW - gap;
    let leftH = f(26);
    if (ctx.name) leftH += measureH('TD-700', f(9.6), ctx.name, leftW - 32) + 2;
    for (const l of customer) leftH += measureH('TD-400', f(8.2), l, leftW - 32) + 1.4;
    leftH += f(12);
    const rightH = f(26) + offerLines.length * f(16) + f(10);
    const boxH = Math.max(leftH, rightH);
    if (draw) {
      doc.rect(L, y, leftW, boxH).fill(MIST);
      doc.rect(L + leftW + gap, y, rightW, boxH).fill(MIST);
      doc.rect(L, y, 3, boxH).fill(NAVY);
      doc.rect(L + leftW + gap, y, 3, boxH).fill(NAVY);
      doc.font('TD-600').fontSize(f(6.4)).fillColor(STEEL).text(lab('customer'), L + 16, y + f(11), { width: leftW - 32, characterSpacing: 1 });
      let cy = y + f(25);
      if (ctx.name) {
        doc.font('TD-700').fontSize(f(9.6)).fillColor(NAVY).text(ctx.name, L + 16, cy, { width: leftW - 32 });
        cy = doc.y + 2;
      }
      for (const l of customer) {
        doc.font('TD-400').fontSize(f(8.2)).fillColor(INK).text(l, L + 16, cy, { width: leftW - 32 });
        cy = doc.y + 1.4;
      }
      const rx = L + leftW + gap + 16;
      doc.font('TD-600').fontSize(f(6.4)).fillColor(STEEL).text(lab('offer'), rx, y + f(11), { width: rightW - 32, characterSpacing: 1 });
      offerLines.forEach(([k, v], i) => {
        const ly = y + f(25) + i * f(16);
        doc.font('TD-500').fontSize(f(6.2)).fillColor(STEEL).text(k.toLocaleUpperCase(loc), rx, ly + 1.6, { width: 74, characterSpacing: 0.5, lineBreak: false });
        doc.font('TD-500').fontSize(f(8.2)).fillColor(NAVY).text(v, rx + 78, ly, { width: rightW - 32 - 78 });
      });
    }
    y += boxH + f(18);

    // the table: column widths first
    const weights = [3.1, ...shown.map((c) => (c.pill ? 1.3 : c.num ? 1.1 : 1.9))];
    const total = weights.reduce((a, w) => a + w, 0);
    const colW = weights.map((w) => (CW * w) / total);
    shown.forEach((c, i) => {
      doc.font('TD-600').fontSize(f(6.2));
      const longest = Math.max(...c.head.toLocaleUpperCase(loc).split(' ').map((word) => doc.widthOfString(word, { characterSpacing: 0.5 })), 0) + 2 * PAD + 2;
      doc.font('TD-600').fontSize(f(8.4));
      const widest = c.num || c.pill ? Math.max(0, ...c.cells.map((t) => doc.widthOfString(t))) + 2 * PAD + 3 : 0;
      const need = Math.max(longest, widest);
      if (colW[i + 1] < need) {
        colW[i + 1] = need;
      }
    });
    // the product name takes what is left (it can wrap); a price never does
    colW[0] = Math.max(72, CW - colW.slice(1).reduce((a, w) => a + w, 0));
    const fit = CW / colW.reduce((a, w) => a + w, 0);
    for (let i = 0; i < colW.length; i++) colW[i] *= fit;
    const colX = colW.map((_, i) => L + colW.slice(0, i).reduce((a, w) => a + w, 0));

    // column heads: white capitals on a navy band
    const labels = [lab('product'), ...shown.map((c) => c.head.toLocaleUpperCase(loc))];
    doc.font('TD-700').fontSize(f(6.4));
    const headH = Math.max(...labels.map((t, i) => doc.heightOfString(t, { width: colW[i] - 2 * PAD, characterSpacing: 0.5 }))) + f(14);
    const drawHead = () => {
      doc.rect(L, y, CW, headH).fill(NAVY);
      labels.forEach((t, i) => {
        const right = i > 0 && (shown[i - 1].num || shown[i - 1].pill);
        doc.font('TD-700').fontSize(f(6.4)).fillColor('#FFFFFF').text(t, colX[i] + PAD, y + f(7), { width: colW[i] - 2 * PAD, align: right ? 'right' : 'left', characterSpacing: 0.5 });
      });
    };
    if (draw) drawHead();
    y += headH;

    let rowNo = 0;
    for (const item of items) {
      if (item.kind === 'gap') {
        // a new block of the same page (the next thickness): a little air
        y += f(5);
        continue;
      }
      if (item.kind === 'group') {
        const gh = measureH('TD-700', f(8), item.name, CW - 2 * PAD) + f(8);
        if (draw && y + gh + 30 > BOTTOM) {
          newPage();
          drawHead();
          y += headH;
        }
        if (draw) {
          doc.rect(L, y, CW, gh).fill(MIST);
          doc.font('TD-700').fontSize(f(8)).fillColor(NAVY).text(item.name, L + PAD, y + f(4), { width: CW - 2 * PAD });
        }
        y += gh;
        continue;
      }
      // the code under the name ("PVC SC"); only on a crowded page does it move up beside the name
      const nameW = colW[0] - 2 * PAD;
      doc.font('TD-700').fontSize(f(8.6));
      const nameWidth = doc.widthOfString(item.name);
      doc.font('TD-400').fontSize(f(6.6));
      const subWidth = item.sub ? doc.widthOfString(item.sub) : 0;
      const inline = !stacked && !!item.sub && nameWidth + 8 + subWidth <= nameW;
      const nameH = measureH('TD-700', f(8.6), item.name, nameW);
      const subH = item.sub && !inline ? measureH('TD-400', f(6.6), item.sub, nameW) : 0;
      const padV = stacked ? f(11) : f(9.5);
      let h = nameH + subH + padV;
      shown.forEach((c, i) => {
        const cell = c.cells[rowNo] || ' ';
        h = Math.max(h, measureH('TD-600', f(8.4), cell, colW[i + 1] - 2 * PAD) + padV);
      });
      if (draw && y + h > BOTTOM) {
        newPage();
        drawHead();
        y += headH;
      }
      if (draw) {
        if (rowNo % 2 === 1) doc.rect(L, y, CW, h).fill(MIST);
        const ty = y + padV / 2;
        doc.font('TD-700').fontSize(f(8.6)).fillColor(NAVY).text(item.name, colX[0] + PAD, ty, { width: nameW, lineBreak: !inline });
        if (item.sub) {
          if (inline) doc.font('TD-400').fontSize(f(6.6)).fillColor(STEEL).text(item.sub, colX[0] + PAD + nameWidth + 8, ty + f(1.4), { width: nameW - nameWidth - 8, lineBreak: false });
          else doc.font('TD-400').fontSize(f(6.6)).fillColor(STEEL).text(item.sub, colX[0] + PAD, ty + nameH + 0.5, { width: nameW });
        }
        shown.forEach((c, i) => {
          const cell = c.cells[rowNo] ?? '';
          if (!cell) return;
          const right = c.num || c.pill;
          doc.font('TD-600').fontSize(f(8.4)).fillColor(NAVY).text(cell, colX[i + 1] + PAD, ty, { width: colW[i + 1] - 2 * PAD, align: right ? 'right' : 'left' });
        });
      }
      y += h;
      rowNo += 1;
    }
    y += f(16);

    // headings like the app's: the first word bold with the red underline
    const heading = (title: string) => {
      const [first, ...rest] = title.split(' ');
      if (draw && y + 44 > BOTTOM) newPage();
      doc.font('TD-700').fontSize(f(9));
      const fw = doc.widthOfString(first);
      if (draw) {
        doc.font('TD-700').fontSize(f(9)).fillColor(NAVY).text(first, L, y, { lineBreak: false });
        if (rest.length) doc.font('TD-300').fontSize(f(9)).fillColor(NAVY).text(` ${rest.join(' ')}`, L + fw, y, { lineBreak: false });
        doc.rect(L, y + f(9) * 1.32, fw, 2).fill(RED);
      }
      y += f(9) * 1.32 + 2 + f(7);
    };
    if (terms.length) {
      heading(lab('terms'));
      // three small tiles side by side
      const tileW = (CW - 2 * 10) / Math.max(1, terms.length);
      const tileH = Math.max(...terms.map(([, v]) => measureH('TD-600', f(7.8), v, tileW - 24))) + f(23);
      if (draw) {
        terms.forEach(([k, v], i) => {
          const x = L + i * (tileW + 10);
          doc.rect(x, y, tileW, tileH).lineWidth(0.7).strokeColor(SMOKE).stroke();
          doc.font('TD-600').fontSize(f(6.2)).fillColor(STEEL).text(k.toLocaleUpperCase(loc), x + 12, y + f(8), { width: tileW - 24, characterSpacing: 0.8, lineBreak: false });
          doc.font('TD-600').fontSize(f(7.8)).fillColor(NAVY).text(v, x + 12, y + f(18.5), { width: tileW - 24 });
        });
      }
      y += tileH + f(14);
    }
    for (const sec of sections) {
      const ls = noteLines(sec);
      if (!ls.length) continue;
      heading(sec.title);
      for (const raw of ls) {
        const bullet = /^\*\s*/.test(raw);
        const body = raw.replace(/^\*\s*/, '');
        const x = L + (bullet ? 12 : 0);
        const w = CW - (x - L);
        const h = measureH('TD-400', f(7.5), body, w);
        if (draw && y + h > BOTTOM) newPage();
        if (draw) {
          if (bullet) doc.circle(L + 4, y + f(3.8), 1.4).fill(RED);
          if (/^https?:\/\//i.test(body)) doc.font('TD-500').fontSize(f(7.5)).fillColor(RED).text(body, x, y, { width: w, link: body, underline: true });
          else doc.font('TD-400').fontSize(f(7.5)).fillColor(INK).text(body, x, y, { width: w });
        }
        y += h + f(2.6);
      }
      y += f(8);
    }
    return y - yStart;
  }

  const avail = BOTTOM - startY;
  // the largest scale at which the whole page fits on one sheet. Roomy first (the code under each product name, at a readable
  // size); if that does not fit, the compact layout (code beside the name) down to the minimum; below that it runs on to a second sheet.
  let stacked = true;
  let scale = 1;
  while (scale > 0.8 && pass(scale, false, true) > avail) scale = Math.round((scale - 0.03) * 100) / 100;
  if (pass(scale, false, true) > avail) {
    stacked = false;
    scale = 1;
    while (scale > MIN_SCALE && pass(scale, false, false) > avail) scale = Math.round((scale - 0.03) * 100) / 100;
  }
  pass(scale, true, stacked);
}
