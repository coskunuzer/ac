import { buyingIntel } from './buyingIntel';
import { pricingAnalysis } from './pricingAnalysis';
import { renderTablePdf, type PdfSection } from './tablePdf';
import type { Viewer } from './visibility';

// The Buying rhythm and the Pricing analysis as printable PDFs. The filters of the screen come in the query, so the PDF shows what the person sees.
type Lang = 'en' | 'tr';
const W: Record<Lang, Record<string, string>> = {
  en: { buying: 'Buying rhythm', pricing: 'Pricing against the standard', customer: 'Customer', country: 'Country', person: 'Responsible', status: 'Status', usual: 'Usual every (days)', last: 'Last order', late: 'Days late', l12: 'Last 12 months', change: 'Change', Late: 'Late', Due: 'Due now', OK: 'On rhythm', Quiet: 'Quiet for long', New: 'Too few orders', asOf: 'As of', followed: 'customers followed', laterThan: 'later than usual', attention: 'Customers that need attention', all: 'All customers', procs: 'Proformas', m2: 'm²', pays: 'Pays vs standard', adj: 'With their usual +/-', gap: 'Difference in money', ytd: 'Sales this year', prev: 'Last year', lastDoc: 'Last proforma', product: 'Product', style: 'Surface', their: 'Their price/m²', std: 'Standard/m²', diff: 'Difference', Plain: 'Plain', Woodgrain: 'Woodgrain', note: "The standard price is today's price list for the same product, thickness and width.", none: 'Nothing to show.', customers: 'customers' },
  tr: { buying: 'Sipariş ritmi', pricing: 'Standart fiyata göre fiyatlama', customer: 'Müşteri', country: 'Ülke', person: 'Sorumlu', status: 'Durum', usual: 'Genelde her (gün)', last: 'Son sipariş', late: 'Geciken gün', l12: 'Son 12 ay', change: 'Değişim', Late: 'Gecikmiş', Due: 'Vakti geldi', OK: 'Ritminde', Quiet: 'Uzun süredir sessiz', New: 'Sipariş az', asOf: 'Tarih', followed: 'müşteri izleniyor', laterThan: 'her zamankinden geç', attention: 'İlgi bekleyen müşteriler', all: 'Tüm müşteriler', procs: 'Proforma', m2: 'm²', pays: 'Standarda göre', adj: 'Her zamanki +/- ile', gap: 'Parasal fark', ytd: 'Bu yıl satış', prev: 'Geçen yıl', lastDoc: 'Son proforma', product: 'Ürün', style: 'Yüzey', their: 'Onların fiyatı/m²', std: 'Standart/m²', diff: 'Fark', Plain: 'Düz', Woodgrain: 'Ahşap desen', note: 'Standart fiyat, aynı ürün, kalınlık ve genişlik için bugünkü fiyat listesidir.', none: 'Gösterilecek bir şey yok.', customers: 'müşteri' },
};
const dmy = (v: string | null) => (v ? `${v.slice(8, 10)}.${v.slice(5, 7)}.${v.slice(0, 4)}` : '');
const money = (n: number, c: string) => `${n < 0 ? '-' : ''}${c === 'USD' ? '$' : '€'}${Math.abs(Math.round(n)).toLocaleString('en-US')}`;
const pct = (n: number | null) => (n === null ? '—' : `${n > 0 ? '+' : ''}${n.toLocaleString('en-US', { maximumFractionDigits: 1 })} %`);
const today = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });
const langOf = (v: unknown): Lang => (v === 'tr' ? 'tr' : 'en');
type Tone = 'bad' | 'good' | 'warn';
const priceTone = (n: number | null): Tone | undefined => (n === null ? undefined : n <= -15 ? 'bad' : n <= -5 ? 'warn' : n >= 3 ? 'good' : undefined);

export async function buyingPdf(viewer: Viewer, query: { lang?: unknown; q?: unknown; only?: unknown }): Promise<Buffer> {
  const w = W[langOf(query.lang)];
  const d = buyingIntel(viewer);
  const q = String(query.q ?? '').trim().toLowerCase();
  const all = query.only === 'all';
  // the most overdue first, then the others by how urgent they are
  const ORDER: Record<string, number> = { late: 0, due: 1, quiet: 2, ok: 3, new: 4 };
  const rows = d.rows.filter((r) => (all || r.status === 'late' || r.flags.length > 0) && (!q || `${r.customer} ${r.country} ${r.rep}`.toLowerCase().includes(q)))
    .sort((x, y) => (ORDER[x.status] ?? 9) - (ORDER[y.status] ?? 9) || (y.daysLate ?? 0) - (x.daysLate ?? 0) || x.customer.localeCompare(y.customer));
  const st: Record<string, string> = { late: w.Late, due: w.Due, ok: w.OK, quiet: w.Quiet, new: w.New };
  return renderTablePdf({
    title: w.buying, subtitle: all ? w.all : w.attention, facts: [`${w.asOf}: ${dmy(d.asOf)}`, `${d.rows.length} ${w.followed}`, `${d.lateCount} ${w.laterThan}`],
    sections: [{
      columns: [{ label: w.customer, w: 26 }, { label: w.country, w: 11 }, { label: w.person, w: 12 }, { label: w.status, w: 13 }, { label: w.usual, w: 9, right: true }, { label: w.last, w: 10 }, { label: w.late, w: 8, right: true }, { label: w.l12, w: 11, right: true }, { label: w.change, w: 8, right: true }],
      rows: rows.map((r) => [
        r.customer, r.country, r.rep,
        { text: st[r.status] ?? r.status, tone: r.status === 'late' ? 'bad' as Tone : r.status === 'ok' ? 'good' as Tone : undefined },
        r.medianDays === null ? '—' : String(r.medianDays), dmy(r.lastOrder),
        r.daysLate !== null && r.daysLate > 0 ? { text: String(r.daysLate), tone: 'bad' as Tone } : '—',
        money(r.last12, r.currency),
        r.trendPct === null ? '—' : { text: pct(r.trendPct), tone: r.trendPct <= -25 ? 'bad' as Tone : r.trendPct >= 10 ? 'good' as Tone : undefined },
      ]),
      empty: w.none,
    }],
  });
}

export async function pricingPdf(viewer: { id: number; role: string; display_name: string | null; market?: string }, query: { lang?: unknown; q?: unknown; only?: unknown; card?: unknown }): Promise<Buffer> {
  const w = W[langOf(query.lang)];
  const d = pricingAnalysis(viewer);
  const q = String(query.q ?? '').trim().toLowerCase();
  const only = query.only === 'below' || query.only === 'above' ? String(query.only) : 'all';
  const card = Number(query.card) || 0;
  const rows = d.rows.filter((r) => (!card || r.cardId === card) && (!q || `${r.customer} ${r.country} ${r.rep}`.toLowerCase().includes(q)) && (only === 'all' || (only === 'below' ? (r.indexPct ?? 0) <= -5 : (r.indexPct ?? 0) >= 3)));
  const sections: PdfSection[] = [{
    note: w.note,
    columns: [{ label: w.customer, w: 24 }, { label: w.country, w: 10 }, { label: w.procs, w: 7, right: true }, { label: w.m2, w: 8, right: true }, { label: w.pays, w: 9, right: true }, { label: w.adj, w: 10, right: true }, { label: w.gap, w: 11, right: true }, { label: w.ytd, w: 11, right: true }, { label: w.prev, w: 11, right: true }, { label: w.lastDoc, w: 10 }],
    rows: rows.map((r) => [r.customer, r.country, String(r.docs), Math.round(r.m2).toLocaleString('en-US'), { text: pct(r.indexPct), tone: priceTone(r.indexPct) }, pct(r.effectivePct), money(r.gap, r.currency), r.ytd === null ? '—' : money(r.ytd, r.currency), r.prevYear === null ? '—' : money(r.prevYear, r.currency), dmy(r.lastDoc)]),
    empty: w.none,
  }];
  // one customer: the simple list by product, plain or woodgrain
  if (card) {
    for (const r of rows) {
      sections.push({
        heading: `${r.customer} (${r.currency})`,
        columns: [{ label: w.product, w: 14 }, { label: w.style, w: 14 }, { label: w.m2, w: 10, right: true }, { label: w.their, w: 14, right: true }, { label: w.std, w: 14, right: true }, { label: w.diff, w: 12, right: true }],
        rows: r.groups.map((g) => [g.product, w[g.style], Math.round(g.m2).toLocaleString('en-US'), g.price === null ? '—' : g.price.toFixed(2), g.standard === null ? '—' : g.standard.toFixed(2), { text: pct(g.diffPct), tone: priceTone(g.diffPct) }]),
        empty: w.none,
      });
    }
  }
  return renderTablePdf({ title: w.pricing, subtitle: card && rows[0] ? rows[0].customer : undefined, facts: [`${w.asOf}: ${dmy(today())}`, `${rows.length} ${w.customers}`], sections });
}
