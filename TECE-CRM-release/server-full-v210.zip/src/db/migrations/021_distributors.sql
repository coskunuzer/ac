-- TECE's distributors by country. A visitor from one of these countries is sent to the distributor
-- (an automatic reply) instead of getting an offer from us.
CREATE TABLE IF NOT EXISTS distributors (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  country TEXT NOT NULL,
  name TEXT NOT NULL,
  phone TEXT,
  email TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_distributors_country ON distributors(country);

INSERT INTO distributors (country, name, phone, email, notes) VALUES
('Venezuela', 'BORDEKOR C.A.', '+58 424 3537497', 'BORDEKOR@outlook.com', 'They carry every color available in the country. Possible to buy tools as well.'),
('Mexico', 'CANPLAST MEXICO S de RL CV', '+52 1 614 239 5479', 'daliahernandez@canplast.com.mx', 'They carry every color available in the country. #1 in Mexico. Possible to buy tools as well.'),
('United States', 'EDGEBANDING AND MORE LLC', '+1 786 537 7901', 'mdelgado@edgebandingandmore.com', 'They carry every color available in the Kronospan range, as well as popular colors.'),
('United Kingdom', 'Edging Supplies Ltd', '+44 7384 810106', 'derrick@edgingsuppliesltd.co.uk', 'They carry every color available in the Egger and Kronospan range, as well as popular colors. They can slit to any size required.'),
('United Arab Emirates', 'KHOMOSI TRADERS LLC', '+971 55 715 1786', 'yusuf@khomositraders.com', 'They carry every color in preglued melamine. For PVC, please check and confirm.'),
('Israel', 'M.R. YASMIN (1997) LTD.', '+972 505702934', 'purchase@mr-yasmin.co.il', 'They carry every color available in the country. Any size is possible. #1 in Israel and Palestine.'),
('Palestine', 'M.R. YASMIN (1997) LTD.', '+972 505702934', 'purchase@mr-yasmin.co.il', 'They carry every color available in the country. Any size is possible. #1 in Israel and Palestine.'),
('Colombia', 'MAURICIO BRAVO Q (Madercantos)', '+57 312 3978315', 'administrativo@madercantos.com', 'They carry every color available in the country. Other name is Madercantos. Possible to buy tools as well.'),
('Greece', 'MEDO Ltd', '+30 210 990 1952', 'info@medo.gr', 'They carry every color available in the country. Any size is possible. #1 in Greece.'),
('Albania', 'NK FURNITURE', '+355 67 203 0162', 'ernestbegalla@icloud.com', 'Buy preglued melamine, veneer, even PVC in all sizes.'),
('Russia', 'OOO REHAU', '+7 926 519 3454', 'sergej.kisin@rhsolutions.ru', 'They carry every color available in the country. Any size is possible.'),
('North Macedonia', 'REAL COMPANY', '+389 70 219 280', 'realcompanysk@yahoo.com', 'They carry every color available in the country. Any size is possible.'),
('Guatemala', 'San Miguel, S.A.', '+502 3122 0611', 'iarriola@sanmiguelmadera.com', 'They carry every color available in the country. Any size is possible.'),
('Argentina', 'WEISMAL ARG SRL', '+54 9 11 5022-7155', 'juanpablo@weismal.com.ar', 'They carry every color available in the country. Any size is possible. #1 edgebanding source in Argentina.');

-- When the contact's details were e-mailed to the Bulgaria office
ALTER TABLE cards ADD COLUMN bulgaria_sent_at TEXT;
