import { db } from '../db/connection';
import type { OpenItem } from './perfAnalytics';

// "SWIFT received": a payment that is on its way. It is taken off the overdue amount until the ledger shows the money.
export interface SwiftRow { id: number; sap: string; amount: number; currency: string; date: string; invoices: string[]; note: string | null; createdBy: number | null; createdAt: string }
interface Raw { id: number; sap_no: string; amount: number; currency: string; swift_date: string; invoices: string | null; note: string | null; created_by: number | null; created_at: string }
const toRow = (r: Raw): SwiftRow => ({ id: r.id, sap: r.sap_no, amount: r.amount, currency: r.currency, date: r.swift_date, invoices: safe(r.invoices), note: r.note, createdBy: r.created_by, createdAt: r.created_at });
function safe(v: string | null): string[] { try { const a = JSON.parse(v ?? '[]'); return Array.isArray(a) ? a.map(String) : []; } catch { return []; } }

export const invoiceKey = (i: { date: string; description: string }) => `${i.date}|${i.description}`;

// A SWIFT is over when the ledger shows the money: the credits of the customer's sheets since the SWIFT day add up to (nearly) its amount.
// (A few percent short is a bank charge.) Called whenever the waiting ones are read, so it resolves itself after the next ledger upload.
function resolveArrivals(rows: Raw[]): Raw[] {
  if (!rows.length) return rows;
  const sheets = db.prepare('SELECT sheet_name FROM customer_aliases WHERE sap_no = ?');
  const credits = (names: string[], from: string) => {
    if (!names.length) return 0;
    const q = db.prepare(`SELECT COALESCE(SUM(credit), 0) AS s FROM ledger_transactions WHERE sheet_name IN (${names.map(() => '?').join(',')}) AND tx_date >= ? AND credit > 0`).get(...names, from) as { s: number };
    return q.s;
  };
  const done = db.prepare("UPDATE perf_swift SET status = 'arrived', resolved_at = datetime('now') WHERE id = ? AND status = 'waiting'");
  return rows.filter((r) => {
    const names = (sheets.all(r.sap_no) as { sheet_name: string }[]).map((x) => x.sheet_name);
    const from = new Date(Date.parse(`${r.swift_date}T12:00:00Z`) - 86400000).toISOString().slice(0, 10);
    if (credits(names, from) >= r.amount * 0.97) { done.run(r.id); return false; }
    return true;
  });
}

export function waitingBySap(): Map<string, SwiftRow[]> {
  const rows = db.prepare("SELECT * FROM perf_swift WHERE status = 'waiting' ORDER BY swift_date").all() as unknown as Raw[];
  const out = new Map<string, SwiftRow[]>();
  for (const r of resolveArrivals(rows)) (out.get(r.sap_no) ?? out.set(r.sap_no, []).get(r.sap_no)!).push(toRow(r));
  return out;
}
export const waitingOf = (sap: string): SwiftRow[] => waitingBySap().get(sap) ?? [];

// The open invoices after the money on its way is taken off: the chosen invoices first (all of them if the amount covers them), then the oldest.
export function applySwift(items: OpenItem[], rows: SwiftRow[]): OpenItem[] {
  const list = items.map((i) => ({ ...i }));
  for (const r of rows) {
    let left = r.amount;
    const take = (it: OpenItem) => { if (left <= 0 || it.amount <= 0) return; const t = Math.min(it.amount, left); it.amount = Math.round((it.amount - t) * 100) / 100; left -= t; };
    const chosen = new Set(r.invoices);
    if (chosen.size) list.filter((i) => chosen.has(invoiceKey(i))).sort((a, b) => a.date.localeCompare(b.date)).forEach(take);
    list.slice().sort((a, b) => a.date.localeCompare(b.date)).forEach(take);
  }
  return list.filter((i) => i.amount > 0.5);
}

export function addSwift(input: { sap: string; amount: number; currency: string; date: string; invoices: string[]; note: string | null; userId: number }): number {
  const r = db.prepare('INSERT INTO perf_swift (sap_no, amount, currency, swift_date, invoices, note, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)')
    .run(input.sap, Math.round(input.amount * 100) / 100, input.currency, input.date, JSON.stringify(input.invoices.slice(0, 60)), input.note, input.userId);
  return Number(r.lastInsertRowid);
}
export const cancelSwift = (id: number): void => { db.prepare("UPDATE perf_swift SET status = 'cancelled', resolved_at = datetime('now') WHERE id = ? AND status = 'waiting'").run(id); };
export const findSwift = (id: number): SwiftRow | null => { const r = db.prepare('SELECT * FROM perf_swift WHERE id = ?').get(id) as Raw | undefined; return r ? toRow(r) : null; };
