-- The TECE colour database: every SAP material code with its product, its colour category (which decides the price) and whether it is in stock (Express).
CREATE TABLE IF NOT EXISTS color_codes (
  sap TEXT PRIMARY KEY,
  old_no TEXT,
  description TEXT,
  board_code TEXT,
  tece_code TEXT,
  product_group INTEGER,
  product_type TEXT,
  mat_group TEXT,
  category_no INTEGER,
  category TEXT,
  producer TEXT,
  swatch TEXT,
  print_surface TEXT,
  kartela TEXT,
  status TEXT,
  search TEXT
);
CREATE INDEX IF NOT EXISTS idx_color_codes_old ON color_codes (old_no);
CREATE INDEX IF NOT EXISTS idx_color_codes_tece ON color_codes (tece_code);

-- Proformas made for a customer (saved as they were typed, so they can be opened, changed and sent again).
CREATE TABLE IF NOT EXISTS proformas (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  card_id INTEGER NOT NULL REFERENCES cards(id) ON DELETE CASCADE,
  created_by INTEGER,
  title TEXT,
  -- a proforma that is changed after it was sent is saved as a new version (v2, v3 ...); the earlier ones stay
  version INTEGER NOT NULL DEFAULT 1,
  parent_id INTEGER,
  data TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_proformas_card ON proformas (card_id);
