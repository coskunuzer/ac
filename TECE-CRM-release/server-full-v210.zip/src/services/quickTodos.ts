import { db } from '../db/connection';
import { askJson } from './perfActions';
import { visibilitySql, type Viewer } from './visibility';

// A person types (or photographs) simple notes: "make proforma for Mauricio", "send offer for Bordekor", "send birthday card to Omar Garza at Canplast".
// Each line becomes a to-do and is joined to the customer it names, found in the customers this person may see. Nothing is saved until the person confirms the list.
export interface QuickItem { text: string; customerWords: string; personWords: string; cardId: number | null; customer: string | null; candidates: { id: number; label: string }[] }

const SCHEMA = { type: 'OBJECT', properties: { items: { type: 'ARRAY', items: { type: 'OBJECT', properties: { task: { type: 'STRING' }, customer: { type: 'STRING' }, person: { type: 'STRING' } }, required: ['task', 'customer', 'person'] } } }, required: ['items'] };

const norm = (s: string) => String(s ?? '').toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/ı/g, 'i').replace(/[^a-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim();
const STOP = new Set(['for', 'to', 'at', 'the', 'a', 'of', 'and', 'ltd', 'sa', 'as', 'inc', 'llc', 'gmbh', 'co', 'sti', 'san', 'tic', 'ile', 'icin', 've', 'make', 'send', 'call', 'write', 'prepare', 'check', 'visit']);

// the plain rules: one line = one to-do; the customer is what follows "for", "to", "at" (or "için" in Turkish)
function byRules(text: string): { task: string; customer: string; person: string }[] {
  return text.split(/\r?\n|;/).map((l) => l.replace(/^[\s\-*•\d.)]+/, '').trim()).filter((l) => l.length > 2).map((line) => {
    const at = /\b(?:at|@)\s+(.+)$/i.exec(line);
    const forTo = /\b(?:for|to|için|icin)\s+(.+?)(?:\s+(?:at|@)\s+.+)?$/i.exec(line);
    if (at && forTo) return { task: line, customer: at[1].trim(), person: forTo[1].trim() };
    return { task: line, customer: (forTo?.[1] ?? at?.[1] ?? '').trim(), person: '' };
  });
}

function findCards(viewer: Viewer, words: string, limit = 5): { id: number; label: string }[] {
  const tokens = norm(words).split(' ').filter((w) => w.length >= 3 && !STOP.has(w));
  if (!tokens.length) return [];
  const params: Record<string, string | number> = {};
  const vis = visibilitySql(viewer, params);
  const like = tokens.map((_, i) => { params[`t${i}`] = `%${tokens[i]}%`; return `(LOWER(COALESCE(company, '')) LIKE @t${i} OR LOWER(COALESCE(name, '')) LIKE @t${i} OR LOWER(COALESCE(email, '')) LIKE @t${i})`; });
  const rows = db.prepare(`SELECT id, company, name, country, stage FROM cards WHERE (${like.join(' OR ')})${vis ? ` AND ${vis}` : ''} LIMIT 60`).all(params) as unknown as { id: number; company: string | null; name: string | null; country: string | null; stage: string | null }[];
  const score = (r: (typeof rows)[number]) => { const k = norm(`${r.company ?? ''} ${r.name ?? ''}`); return tokens.reduce((a, t) => a + (k.includes(t) ? (k.split(' ').includes(t) ? 3 : 1) : 0), 0) + (r.stage === 'customer' ? 1 : 0); };
  return rows.sort((a, b) => score(b) - score(a)).slice(0, limit).map((r) => ({ id: r.id, label: `${r.company || r.name || `#${r.id}`}${r.country ? ` · ${r.country}` : ''}${r.company && r.name ? ` · ${r.name}` : ''}` }));
}

export async function parseNotes(text: string, viewer: Viewer): Promise<QuickItem[]> {
  const clean = text.trim().slice(0, 4000);
  if (!clean) return [];
  let parsed = byRules(clean);
  try {
    const j = await askJson(`A salesperson of an edgebanding company wrote short notes of things to do. Split them into separate tasks. For each: task = the to-do as a short clear sentence (keep the language of the note); customer = the company name it is about, exactly as written ("" if none); person = the person's name if one is named ("" if none). Never invent anything.\n\n${clean}`, SCHEMA);
    const items = Array.isArray(j?.items) ? (j!.items as { task?: unknown; customer?: unknown; person?: unknown }[]) : [];
    if (items.length) parsed = items.map((i) => ({ task: String(i.task ?? '').trim(), customer: String(i.customer ?? '').trim(), person: String(i.person ?? '').trim() })).filter((i) => i.task);
  } catch { /* the rules' answer stands */ }
  return parsed.slice(0, 40).map((p) => {
    let candidates = findCards(viewer, p.customer);
    if (!candidates.length && p.person) candidates = findCards(viewer, p.person);
    if (!candidates.length) candidates = findCards(viewer, p.task, 3);
    return { text: p.task, customerWords: p.customer, personWords: p.person, cardId: candidates[0]?.id ?? null, customer: candidates[0]?.label ?? null, candidates };
  });
}
