import { db } from '../db/connection';
import { env } from '../config/env';
import { countryKey } from '../models/countryModel';
import type { CardRow } from '../models/cardModel';
import { LANGS, isLang, type Lang } from './translate';

// Which language the offer and the e-mail to a customer are written in. English is the default; Russian, Turkish, Spanish
// and French are chosen when the customer is added: by the country first, and the AI looks at everything else (the company
// name, the person, the e-mail, the notes) and decides - a company in Algeria writes French, one in Israel English.

const BY_COUNTRY: Record<string, Lang> = {};
const put = (lang: Lang, names: string[]) => names.forEach((n) => (BY_COUNTRY[countryKey(n)] = lang));
put('ru', ['Russia', 'Belarus', 'Kazakhstan', 'Kyrgyzstan', 'Tajikistan', 'Uzbekistan']);
put('tr', ['Turkey', 'Northern Cyprus', 'North Cyprus', 'TRNC']);
put('es', ['Spain', 'Mexico', 'Colombia', 'Argentina', 'Chile', 'Peru', 'Venezuela', 'Ecuador', 'Bolivia', 'Paraguay', 'Uruguay', 'Costa Rica', 'Panama', 'Guatemala', 'Honduras', 'El Salvador', 'Nicaragua', 'Cuba', 'Dominican Republic', 'Puerto Rico']);
put('fr', ['France', 'Algeria', 'Morocco', 'Tunisia', 'Senegal', 'Ivory Coast', 'Cameroon', 'Mali', 'Burkina Faso', 'Guinea', 'Benin', 'Togo', 'Gabon', 'Madagascar', 'Haiti', 'Monaco', 'Luxembourg']);

export function languageForCountry(country: string | null | undefined): Lang | null {
  return country ? BY_COUNTRY[countryKey(country)] ?? null : null;
}

const GEMINI_URL = 'https://generativelanguage.googleapis.com/v1beta/models';
const MODEL = 'gemini-3.6-flash';
const SCHEMA = { type: 'OBJECT', properties: { language: { type: 'STRING', enum: Object.keys(LANGS) }, reason: { type: 'STRING' } }, required: ['language', 'reason'] };

export async function detectLanguage(card: Pick<CardRow, 'company' | 'name' | 'position' | 'email' | 'country' | 'city' | 'market' | 'notes' | 'website' | 'work_area'>): Promise<Lang> {
  const byCountry = card.market === 'domestic' ? 'tr' : languageForCountry(card.country);
  if (card.market === 'domestic') return 'tr';
  if (!env.geminiApiKey) return byCountry ?? 'en';
  const prompt = [
    'TECE, a Turkish edgebanding manufacturer, writes its price offer and e-mails to each customer in the language the customer is most comfortable with.',
    `Choose one of: ${Object.entries(LANGS).map(([k, v]) => `${k} (${v})`).join(', ')}. English is the default and the right answer whenever you are not fairly sure, and for every country not clearly using one of the others.`,
    'Use the country, the company name, the contact person\'s name, the e-mail domain and the notes (the notes may be in Turkish: that is our staff, not the customer). A customer in a French-speaking country writes French; in Spain or Latin America Spanish; in Russia, Belarus or Central Asia Russian; in Turkey Turkish. Customers in countries such as Israel, India, the Gulf or most of Europe use English.',
    `Customer: ${JSON.stringify({ company: card.company, contact: card.name, position: card.position, email: card.email, country: card.country, countryRuleSays: byCountry, website: card.website, workArea: card.work_area, notes: (card.notes ?? '').slice(0, 300) })}`,
  ].join('\n');
  try {
    const res = await fetch(`${GEMINI_URL}/${MODEL}:generateContent`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-goog-api-key': env.geminiApiKey },
      body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { responseMimeType: 'application/json', responseSchema: SCHEMA, temperature: 0 } }),
      signal: AbortSignal.timeout(20000),
    });
    if (!res.ok) return byCountry ?? 'en';
    const data = (await res.json()) as { candidates?: { content?: { parts?: { text?: string; thought?: boolean }[] } }[] };
    const parts = data.candidates?.[0]?.content?.parts?.filter((p) => !p.thought && p.text) ?? [];
    const text = parts[parts.length - 1]?.text;
    const lang = text ? (JSON.parse(text) as { language?: string }).language : undefined;
    return isLang(lang) ? lang : byCountry ?? 'en';
  } catch {
    return byCountry ?? 'en';
  }
}

// When a customer is added: the language is worked out in the background and written on the customer (never over a choice somebody made).
export function chooseLanguageInBackground(id: number): void {
  void (async () => {
    const card = db.prepare('SELECT * FROM cards WHERE id = ?').get(id) as unknown as CardRow | undefined;
    if (!card || card.language) return;
    const lang = await detectLanguage(card);
    db.prepare('UPDATE cards SET language = ? WHERE id = ? AND language IS NULL').run(lang, id);
  })().catch((err) => console.error('Choosing the language failed:', err));
}

// A new customer gets the language of its country at once (no AI): English unless the country clearly uses another of the five.
export function setLanguageByRule(id: number): void {
  const card = db.prepare('SELECT * FROM cards WHERE id = ?').get(id) as unknown as CardRow | undefined;
  if (!card || card.language) return;
  const lang = card.market === 'domestic' ? 'tr' : languageForCountry(card.country) ?? 'en';
  db.prepare('UPDATE cards SET language = ? WHERE id = ? AND language IS NULL').run(lang, id);
}

// The language of the offer for this customer (English when nobody has set one).
export function languageOf(card: Pick<CardRow, 'language'>): Lang {
  return isLang(card.language) ? card.language : 'en';
}

// Customers from before languages existed: the country rule decides (no AI call, English stays English).
export function backfillLanguages(): number {
  let n = Number(db.prepare("UPDATE cards SET language = 'tr' WHERE language IS NULL AND market = 'domestic'").run().changes);
  const rows = db.prepare("SELECT DISTINCT country FROM cards WHERE language IS NULL AND country IS NOT NULL AND country != ''").all() as { country: string }[];
  const set = db.prepare('UPDATE cards SET language = ? WHERE language IS NULL AND country = ?');
  for (const r of rows) {
    const lang = languageForCountry(r.country);
    if (lang) n += Number(set.run(lang, r.country).changes);
  }
  return n;
}
