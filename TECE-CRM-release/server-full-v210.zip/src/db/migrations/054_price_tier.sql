-- The domestic customers are fixed to one of the three PVC price lists (A, B or C); the discount is the offer percent of the customer.
ALTER TABLE cards ADD COLUMN price_tier TEXT;
