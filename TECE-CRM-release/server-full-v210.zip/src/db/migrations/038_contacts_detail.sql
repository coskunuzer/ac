-- More about the other people at a company: last name, mobile and the scan of their card/form.
ALTER TABLE card_contacts ADD COLUMN last_name TEXT;
ALTER TABLE card_contacts ADD COLUMN mobile TEXT;
ALTER TABLE card_contacts ADD COLUMN scan_path TEXT;
