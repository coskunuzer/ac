-- Every change of a customer's discount level on the record, kept for the "Price changes" file of
-- the customer (the offers themselves are already in offers_sent).
CREATE TABLE IF NOT EXISTS price_changes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  card_id INTEGER NOT NULL,
  changed_at TEXT NOT NULL DEFAULT (datetime('now')),
  changed_by TEXT,
  old_percent REAL,
  new_percent REAL
);
CREATE INDEX IF NOT EXISTS idx_price_changes_card ON price_changes(card_id);
