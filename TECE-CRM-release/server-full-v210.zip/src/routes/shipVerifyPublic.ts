import fs from 'fs';
import { Router } from 'express';
import { confirmByToken, tokenExists, videoFile, videoInfo } from '../services/shipVerify';

// What a transport firm sees when it clicks the link in the verification e-mail: no login, only the secret code of that e-mail.
const router = Router();
const esc = (s: string) => s.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c] as string));
const page = (title: string, text: string) => `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>${esc(title)}</title>
<style>body{font-family:system-ui,Segoe UI,Arial,sans-serif;background:#f4f5f8;margin:0;display:grid;place-items:center;min-height:100vh}main{background:#fff;max-width:520px;margin:24px;padding:32px;border-radius:12px;border-top:6px solid #8b1931;box-shadow:0 6px 24px rgba(0,0,0,.08)}h1{margin:0 0 12px;font-size:22px;color:#17243e}p{color:#333;line-height:1.5}</style></head><body><main><h1>${esc(title)}</h1><p>${text}</p></main></body></html>`;

// video first (so ":token" does not swallow the word "video")
router.get('/video/:token', (req, res) => {
  if (!tokenExists(String(req.params.token)) || !videoInfo().exists) return res.status(404).send(page('Not found', 'This link is no longer valid.'));
  res.setHeader('Content-Type', 'video/mp4');
  res.setHeader('Content-Disposition', 'inline; filename="TECE-Nakliye-video.mp4"');
  fs.createReadStream(videoFile()).pipe(res);
});

router.get('/:token', (req, res) => {
  const r = confirmByToken(String(req.params.token), 'link');
  if (!r) return res.status(404).send(page('Link not valid', 'This confirmation link is not valid. Please reply to our e-mail with the word CONFIRMED.'));
  const tr = r.lang !== 'en';
  res.send(page(tr ? 'Teşekkürler, onaylandı' : 'Thank you, confirmed',
    tr ? `${esc(r.firm)} için e-posta adresiniz onaylandı. Bundan sonra nakliye taleplerimizi bu adrese göndereceğiz. Talep e-postamıza <b>aynı e-postayı yanıtlayarak</b> fiyatınızı ve şartlarınızı yazmanız yeterlidir.<br><br>TECE Nakliye`
       : `Your e-mail address for ${esc(r.firm)} is confirmed. From now on we will send our freight requests to this address. Please simply <b>reply to the same e-mail</b> with your price and conditions.<br><br>TECE Nakliye`));
});

export default router;
