import sharp from 'sharp';
import { askJsonParts } from './noteAssist';

// A photo of a roll or box usually shows a label (brand, decor name and code, width x thickness, length, origin, barcode). When the person asks, one small vision call reads it,
// so the complaint is filled with what is printed and not with what somebody remembers. It copies what is there and never guesses: an unreadable field stays empty.
export interface LabelInfo {
  found: boolean;
  brand: string; decor: string; code: string;
  widthMm: number | null; thicknessMm: number | null; lengthM: number | null;
  madeIn: string; barcode: string; otherText: string;
  // false when the label is not a TECE label (another brand or a distributor's own label): worth knowing before a complaint is sent to our quality team
  teceLabel: boolean | null;
}

const num = (v: unknown): number | null => { const n = typeof v === 'number' ? v : Number(String(v ?? '').replace(',', '.')); return Number.isFinite(n) && n > 0 ? Math.round(n * 100) / 100 : null; };
const txt = (v: unknown, n = 120): string => String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, n);

export async function readLabel(photo: Buffer): Promise<LabelInfo | null> {
  let jpeg: Buffer;
  try { jpeg = await sharp(photo, { failOn: 'none' }).rotate().resize({ width: 1800, height: 1800, fit: 'inside', withoutEnlargement: true }).jpeg({ quality: 85 }).toBuffer(); } catch { return null; }
  const j = await askJsonParts([
    { text: [
      'This is a photo of a roll or box of edgebanding (PVC, ABS, melamine or veneer edge tape). Read the printed label on it, if there is one.',
      'Copy exactly what is printed. Do NOT guess and do not complete cut-off words: a field you cannot read clearly stays empty (or null for a number).',
      'brand = the company name or logo text on the label. decor = the colour or decor name. code = the product or colour code (digits and letters). widthMm and thicknessMm in millimetres (a label like "22 mm x 1 mm" means width 22, thickness 1). lengthM = the length of the roll in metres. madeIn = the country or origin text. barcode = the digits under the barcode. otherText = any other readable text on the label.',
      'found = false when no label is visible or readable.',
    ].join('\n') },
    { inlineData: { mimeType: 'image/jpeg', data: jpeg.toString('base64') } },
  ], {
    type: 'OBJECT',
    properties: {
      found: { type: 'BOOLEAN' }, brand: { type: 'STRING' }, decor: { type: 'STRING' }, code: { type: 'STRING' }, widthMm: { type: 'NUMBER' }, thicknessMm: { type: 'NUMBER' }, lengthM: { type: 'NUMBER' },
      madeIn: { type: 'STRING' }, barcode: { type: 'STRING' }, otherText: { type: 'STRING' },
    },
    required: ['found'],
  }, 0);
  if (!j) return null;
  const brand = txt(j.brand, 60);
  const other = txt(j.otherText, 300);
  const isTece = /tece/i.test(`${brand} ${other}`);
  return {
    found: j.found === true && !!(brand || txt(j.decor) || txt(j.code) || txt(j.barcode)),
    brand, decor: txt(j.decor, 80), code: txt(j.code, 40), widthMm: num(j.widthMm), thicknessMm: num(j.thicknessMm), lengthM: num(j.lengthM),
    madeIn: txt(j.madeIn, 40), barcode: txt(j.barcode, 40), otherText: other,
    teceLabel: brand || other ? isTece : null,
  };
}
