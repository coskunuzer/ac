import * as XLSX from 'xlsx';
import { db } from '../db/connection';
import { settingsModel } from '../models/settingsModel';

// The TECE colour database (TECE_Color_Database_May2026.xlsx): every SAP material code with what it is (PVC, ABS, PP, melamine), the colour
// category that decides its price, the producer and whether it is in stock (Express). An admin uploads the file; the proforma looks the SAP
// code of each line up here.

export interface ColorCode {
  sap: string;
  oldNo: string | null;
  description: string | null;
  boardCode: string | null;
  teceCode: string | null;
  productGroup: number | null;
  productType: string | null; // PVC, ABS, PP, Melamin, Metal
  categoryNo: number | null; // 1 plain, 2 wood, 3 high gloss plain, 4 high gloss wood, 5 intense plain (the price categories)
  category: string | null;
  producer: string | null;
  swatch: string | null;
  // the surface (column L): T3-BUTE-1 ...
  surface: string | null;
  kartela: string | null;
  status: string | null; // Express, MOQ - 600 KG, MOQ - 200 KG, MOQ Required, Not in Kartela
}

interface Row {
  sap: string; old_no: string | null; description: string | null; board_code: string | null; tece_code: string | null; product_group: number | null;
  product_type: string | null; category_no: number | null; category: string | null; producer: string | null; swatch: string | null; print_surface: string | null; kartela: string | null; status: string | null;
}

const toColor = (r: Row): ColorCode => ({
  sap: r.sap, oldNo: r.old_no, description: r.description, boardCode: r.board_code, teceCode: r.tece_code, productGroup: r.product_group, productType: r.product_type,
  categoryNo: r.category_no, category: r.category, producer: r.producer, swatch: r.swatch, surface: r.print_surface, kartela: r.kartela, status: r.status,
});

const text = (v: unknown): string | null => {
  const s = String(v ?? '').trim();
  return s && s !== '-' && s !== '*' ? s : null;
};
const int = (v: unknown): number | null => {
  const n = parseInt(String(v ?? '').trim(), 10);
  return Number.isFinite(n) ? n : null;
};

const GROUP_OF: Record<string, number> = { PVC: 1, ABS: 7, PP: 9, Melamin: 3 };

export function colorDbStatus(): { count: number; importedAt: string | null; fileName: string | null } {
  const n = (db.prepare('SELECT COUNT(*) AS n FROM color_codes').get() as { n: number }).n;
  return { count: n, importedAt: settingsModel.get('color_db_at'), fileName: settingsModel.get('color_db_file') };
}

// Replaces the colour database with the rows of the uploaded workbook.
// The database is updated from time to time (a new kartela, new codes): upload the new file whenever it changes. The answer says what changed.
export interface ColorImportReport { rows: number; express: number; byProduct: Record<string, number>; added: number; removed: number; changed: number; first: boolean }

export function importColorDatabase(buffer: Buffer, fileName: string): ColorImportReport {
  const before = new Map((db.prepare('SELECT sap, status, category_no FROM color_codes').all() as { sap: string; status: string | null; category_no: number | null }[]).map((r) => [r.sap, r]));
  const wb = XLSX.read(buffer, { type: 'buffer' });
  const sheetName = wb.SheetNames.find((s) => /color/i.test(s)) ?? wb.SheetNames[0];
  const grid = XLSX.utils.sheet_to_json<unknown[]>(wb.Sheets[sheetName], { header: 1, defval: '', raw: false });
  const headIndex = grid.findIndex((r) => r.some((c) => /^sap code$/i.test(String(c).trim())));
  if (headIndex < 0) throw new Error('This does not look like the TECE colour database: there is no "SAP Code" column.');
  const head = grid[headIndex].map((c) => String(c).trim().toLowerCase());
  const col = (...names: string[]) => head.findIndex((h) => names.some((n) => h === n.toLowerCase()));
  const c = {
    sap: col('SAP Code'), old: col('Old Mat. No.'), desc: col('Description'), board: col('Board Code'), tece: col('TECE Code (Desen)'), group: col('Product Group No.'),
    type: col('Product Type'), matDesc: col('Mat. Group Desc.'), catNo: col('Mat. Group 1 No.'), cat: col('Color Category'), producer: col('Producer'),
    swatch: col('Swatch Desc.'), surface: col('Surface Desc.'), kartela: col('Kartela Avail.'), status: col('RANGE STATUS'),
  };
  if (c.sap < 0) throw new Error('The "SAP Code" column was not found.');

  const rows: Row[] = [];
  const byProduct: Record<string, number> = {};
  for (const r of grid.slice(headIndex + 1)) {
    const sap = text(r[c.sap]);
    // the second heading row (Turkish) and empty rows have no code like 40001.042
    if (!sap || !/^\d{4,6}\.\d{2,3}$/.test(sap)) continue;
    const matDesc = String(r[c.matDesc] ?? '');
    const given = text(r[c.type]);
    let product = given && /^(pvc|abs|pp|melamin|metal)/i.test(given) ? given.replace(/ - .*/, '') : null;
    if (!product) product = /pvc/i.test(matDesc) ? 'PVC' : /abs/i.test(matDesc) ? 'ABS' : /melamin/i.test(matDesc) ? 'Melamin' : /\bpp\b/i.test(matDesc) ? 'PP' : null;
    const group = int(r[c.group]) ?? (product ? GROUP_OF[product] ?? null : null);
    rows.push({
      sap, old_no: text(r[c.old]), description: text(r[c.desc]), board_code: text(r[c.board]), tece_code: text(r[c.tece]), product_group: group, product_type: product,
      category_no: int(r[c.catNo]), category: text(r[c.cat]), producer: text(r[c.producer]), swatch: text(r[c.swatch]), print_surface: text(r[c.surface]), kartela: text(r[c.kartela]), status: text(r[c.status]),
    });
    byProduct[product ?? '?'] = (byProduct[product ?? '?'] ?? 0) + 1;
  }
  if (!rows.length) throw new Error('No SAP codes were found in this file.');

  const ins = db.prepare(
    `INSERT OR REPLACE INTO color_codes (sap, old_no, description, board_code, tece_code, product_group, product_type, mat_group, category_no, category, producer, swatch, print_surface, kartela, status, search)
     VALUES (@sap, @old_no, @description, @board_code, @tece_code, @product_group, @product_type, NULL, @category_no, @category, @producer, @swatch, @print_surface, @kartela, @status, @search)`
  );
  db.exec('BEGIN');
  try {
    db.exec('DELETE FROM color_codes');
    for (const r of rows) {
      ins.run({ ...r, search: [r.sap, r.old_no, r.description, r.board_code, r.tece_code, r.producer, r.swatch].filter(Boolean).join(' ').toLowerCase() });
    }
    db.exec('COMMIT');
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
  settingsModel.set('color_db_at', new Date().toISOString());
  settingsModel.set('color_db_file', fileName);
  const now = new Set(rows.map((r) => r.sap));
  return {
    rows: rows.length,
    express: rows.filter((r) => r.status === 'Express').length,
    byProduct,
    added: rows.filter((r) => !before.has(r.sap)).length,
    removed: [...before.keys()].filter((s) => !now.has(s)).length,
    // a code whose stock status or price category is different now
    changed: rows.filter((r) => { const b = before.get(r.sap); return !!b && (b.status !== r.status || b.category_no !== r.category_no); }).length,
    first: before.size === 0,
  };
}

// A SAP code as people write it: 40001.042, 40001042, 40001 042, or only the five digits 40001.
export function normaliseSap(input: string): { full: string | null; prefix: string | null } {
  const s = input.trim();
  const m = /^(\d{4,6})\s*[.\s-]?\s*(\d{2,3})$/.exec(s);
  if (m) return { full: `${m[1]}.${m[2].padStart(3, '0')}`, prefix: null };
  if (/^\d{4,6}$/.test(s)) return { full: null, prefix: s };
  return { full: null, prefix: null };
}

export function colorBySap(input: string): { color: ColorCode | null; candidates: ColorCode[] } {
  const { full, prefix } = normaliseSap(input);
  if (full) {
    // 40001.042 as typed, and the same number with a two-digit suffix (40001.42)
    const r = (db.prepare('SELECT * FROM color_codes WHERE sap = ? OR sap = ?').get(full, full.replace(/\.0/, '.')) as Row | undefined) ?? undefined;
    return { color: r ? toColor(r) : null, candidates: [] };
  }
  if (prefix) {
    const rows = (db.prepare('SELECT * FROM color_codes WHERE sap LIKE ? ORDER BY sap LIMIT 8').all(`${prefix}.%`) as unknown as Row[]).map(toColor);
    return rows.length === 1 ? { color: rows[0], candidates: [] } : { color: null, candidates: rows };
  }
  return { color: null, candidates: [] };
}

// A code the order itself uses for the colour: the old material number (A1000BT), the board code (W1000 ST2) or the TECE decor number.
// (several rows can share an old number: the one in stock - Express - comes first, then the lowest SAP code; the person sees what was chosen)
export function colorByOtherCode(code: string, product?: string | null): ColorCode | null {
  const c = code.trim();
  if (c.length < 3) return null;
  const rows = (db
    .prepare("SELECT * FROM color_codes WHERE LOWER(old_no) = LOWER(@c) OR LOWER(board_code) = LOWER(@c) OR tece_code = @c ORDER BY (status = 'Express') DESC, sap LIMIT 8")
    .all({ c }) as unknown as Row[]).map(toColor);
  const wanted = product ? rows.filter((r) => r.productType === product) : rows;
  return (wanted[0] ?? rows[0]) ?? null;
}

export function searchColors(q: string, limit = 25): ColorCode[] {
  const words = q.toLowerCase().split(/[\s,;]+/).filter((w) => w.length >= 1).slice(0, 6);
  if (!words.length) return [];
  const params: Record<string, string | number> = { limit };
  const where = words.map((w, i) => { params[`w${i}`] = `%${w}%`; return `search LIKE @w${i}`; });
  // Express (in stock) first
  return (db
    .prepare(`SELECT * FROM color_codes WHERE ${where.join(' AND ')} ORDER BY (status = 'Express') DESC, sap LIMIT @limit`)
    .all(params) as unknown as Row[]).map(toColor);
}
