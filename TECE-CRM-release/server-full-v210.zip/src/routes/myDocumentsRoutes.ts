import { Router } from 'express';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { cardModel } from '../models/cardModel';
import { activityModel } from '../models/activityModel';
import { canSeeCard } from '../services/visibility';
import { closeReminder, latestExports, markExport } from '../services/shipExports';

// The sales person's own list: the export documents that Operations does NOT follow ("takip etme") because Sales already has them. One click says they were shared with the customer;
// the line then disappears here and nowhere else needs it.
const router = Router();
router.use(requireAuth);
const FOLLOW_DAYS = 45;

export function mineDocuments(me: NonNullable<AuthedRequest['user']>) { return mine({ user: me } as AuthedRequest); }
function mine(req: AuthedRequest) {
  const me = req.user!;
  const name = (me.display_name || me.username || '').trim().toLowerCase();
  // "ignored" = Operations does not follow it, the documents are with Sales; "none" = nobody has sent them yet (Operations has not taken it either)
  return latestExports(FOLLOW_DAYS, 0).rows.filter((r) => {
    if ((r.docs.state !== 'ignored' && r.docs.state !== 'none') || !r.cardId) return false;
    const card = cardModel.findById(r.cardId);
    if (!card) return false;
    // an admin sees only the customers with their own name; everybody else the customers they may open
    return me.role === 'admin' ? (card.person ?? '').trim().toLowerCase() === name : canSeeCard(me, card);
  });
}

router.get('/', (req: AuthedRequest, res) => {
  res.json({ rows: mine(req).map((r) => ({ key: r.key, cardId: r.cardId, customer: r.customer, country: r.country, invoice: r.invoice, state: r.docs.state, date: r.date, days: r.days, amount: r.amount, currency: r.currency })) });
});

router.post('/shared', (req: AuthedRequest, res) => {
  const key = String(req.body?.key ?? '');
  const row = mine(req).find((r) => r.key === key);
  if (!row) return res.status(404).json({ error: 'This line is not on your list any more.' });
  markExport(key, req.user!.id, { status: 'sent', how: 'manual', note: 'Satış paylaştı', log: { action: 'sales_shared', role: req.user!.role === 'admin' ? 'admin' : 'sales', customer: row.customer, invoice: row.invoice } });
  closeReminder(row);
  if (row.cardId) activityModel.add({ userId: req.user!.id, cardId: row.cardId, type: 'documents', text: `Export documents shared with the customer by sales (invoice ${row.invoice})`, imported: true });
  res.json({ ok: true });
});

export default router;
