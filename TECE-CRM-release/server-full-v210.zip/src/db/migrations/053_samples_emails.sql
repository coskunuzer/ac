-- Every e-mail the CRM sends is kept: who, to whom, what it said, which files (the customer page shows them).
CREATE TABLE IF NOT EXISTS sent_emails (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  card_id INTEGER,
  user_id INTEGER,
  kind TEXT NOT NULL DEFAULT 'email',      -- thank_you, offer, documents, personal, sample_request, sample_tracking, bulgaria, ...
  internal INTEGER NOT NULL DEFAULT 0,     -- 1 = only to TECE addresses (those are written in Turkish)
  to_addr TEXT,
  cc_addr TEXT,
  subject TEXT,
  body TEXT,
  attachments TEXT,                         -- file names, comma separated
  sent_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_sent_emails_card ON sent_emails(card_id, sent_at);

-- The samples sent to a customer: what, with which courier, and the tracking number added after it left.
CREATE TABLE IF NOT EXISTS card_samples (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  card_id INTEGER NOT NULL,
  user_id INTEGER,
  items TEXT NOT NULL,                      -- the description, one line per sample (what the customer is told)
  note TEXT,
  carrier TEXT,
  requested_at TEXT NOT NULL DEFAULT (datetime('now')),
  tracking_no TEXT,
  shipped_at TEXT,
  customer_mail_id INTEGER                  -- the e-mail that told the customer
);
CREATE INDEX IF NOT EXISTS idx_card_samples_card ON card_samples(card_id);
