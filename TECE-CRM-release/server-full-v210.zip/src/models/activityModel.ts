import { db } from '../db/connection';
import { applyNotesToBoards } from '../services/noteInterest';

// Everything people do, in one list: it feeds the notes on a customer and the daily team report.
export type ActivityType =
  | 'note' | 'call' | 'visit' | 'meeting' | 'sample' // written by a person (with photos if they like)
  | 'scan' | 'created' // a new customer
  | 'thank_you' | 'offer' | 'documents' | 'email' | 'bulgaria' // something was sent
  | 'file' // a file was added to the customer
  | 'merged' // another record of the same company was merged into this one
  | 'stage' // the customer moved on in the pipeline
  | 'rated' // a person gave the customer their own rating (counts for the mission board points)
  | 'ai'; // the AI did something for this customer (rated it, checked the company, wrote an insight, found the web site): not anybody's work

export const HUMAN_TYPES: ActivityType[] = ['note', 'call', 'visit', 'meeting', 'sample'];

export interface Activity {
  id: number;
  userId: number;
  userName: string | null;
  cardId: number | null;
  type: ActivityType;
  text: string | null;
  photos: string[];
  at: string; // UTC "YYYY-MM-DD HH:MM:SS"
  company: string | null;
  contact: string | null;
  country: string | null;
  tripId: number | null; // written from a trip (shown as "Trip: <title>")
  tripTitle: string | null;
}

interface Row {
  id: number;
  user_id: number;
  user_name: string | null;
  card_id: number | null;
  type: ActivityType;
  text: string | null;
  photos: string | null;
  created_at: string;
  company: string | null;
  contact: string | null;
  country: string | null;
  trip_id: number | null;
  trip_title: string | null;
}

const SELECT = `SELECT a.id, a.user_id, COALESCE(u.display_name, u.username) AS user_name, a.card_id, a.type, a.text, a.photos, a.created_at,
                       c.company AS company, c.name AS contact, c.country AS country, a.trip_id, tr.title AS trip_title
                FROM activities a
                LEFT JOIN users u ON u.id = a.user_id
                LEFT JOIN cards c ON c.id = a.card_id
                LEFT JOIN trips tr ON tr.id = a.trip_id`;

function toActivity(r: Row): Activity {
  let photos: string[] = [];
  try {
    photos = r.photos ? (JSON.parse(r.photos) as string[]) : [];
  } catch {
    photos = [];
  }
  return { id: r.id, userId: r.user_id, userName: r.user_name, cardId: r.card_id, type: r.type, text: r.text, photos, at: r.created_at, company: r.company, contact: r.contact, country: r.country, tripId: r.trip_id ?? null, tripTitle: r.trip_id ? r.trip_title ?? null : null };
}

export const activityModel = {
  // `imported`: shows in the history of the customer but is not counted as anybody's work (team page, points, goals)
  add(input: { userId: number; cardId?: number | null; type: ActivityType; text?: string | null; photos?: string[]; imported?: boolean; tripId?: number | null }): number {
    const r = db
      .prepare('INSERT INTO activities (user_id, card_id, type, text, photos, imported, trip_id) VALUES (?, ?, ?, ?, ?, ?, ?)')
      .run(input.userId, input.cardId ?? null, input.type, input.text?.trim().slice(0, 4000) || null, input.photos?.length ? JSON.stringify(input.photos) : null, input.imported ? 1 : 0, input.tripId ?? null);
    // a note, call or visit that names a panel producer (Kronospan, Kastamonu ...) adds it to the customer's panel interest
    if (input.cardId && input.text && HUMAN_TYPES.includes(input.type)) { try { applyNotesToBoards(input.cardId, input.text); } catch { /* the note is saved anyway */ } }
    return r.lastInsertRowid as number;
  },

  find(id: number): Activity | undefined {
    const r = db.prepare(`${SELECT} WHERE a.id = ?`).get(id) as Row | undefined;
    return r && toActivity(r);
  },

  forCard(cardId: number, limit = 200): Activity[] {
    return (db.prepare(`${SELECT} WHERE a.card_id = ? ORDER BY a.created_at DESC, a.id DESC LIMIT ?`).all(cardId, limit) as unknown as Row[]).map(toActivity);
  },

  // what these people did between two UTC moments (inclusive start, exclusive end)
  between(userIds: number[], fromUtc: string, toUtc: string): Activity[] {
    if (!userIds.length) return [];
    const ids = userIds.map((n) => Math.trunc(Number(n))).join(',');
    return (db
      .prepare(`${SELECT} WHERE a.user_id IN (${ids}) AND a.imported = 0 AND a.created_at >= ? AND a.created_at < ? ORDER BY a.created_at ASC, a.id ASC`)
      .all(fromUtc, toUtc) as unknown as Row[]).map(toActivity);
  },

  delete(id: number): void {
    db.prepare('DELETE FROM activities WHERE id = ?').run(id);
  },
};
