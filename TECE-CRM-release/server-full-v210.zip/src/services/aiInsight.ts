import { env } from '../config/env';
import { distributorModel } from '../models/distributorModel';
import { PRODUCT_KEYS, INTEREST_PRODUCTS, detectInterest, sanitiseWidths } from './interest';

// What the AI makes of a visitor: it reads the handwritten notes (Turkish, English, ...)
// and decides what has to happen next - thank-you, offer (for which products), a
// discount that was promised, a reminder. It is asked together with reading the form
// (one call), and a plain-words fallback gives the same answer shape when the AI is
// not available, so the rest of the app never has to care where it came from.

export type Timing = 'now' | 'this_week' | 'later';

export interface AiInsight {
  summary: string | null; // the notes in one or two English sentences
  companyActivity: string | null; // what the company does, only when it could be worked out
  products: string[]; // interest keys: pvc, abs, ...
  widths: number[];
  otherInterest: string | null;
  sendThankYou: boolean;
  sendOffer: boolean; // the notes ask for an offer / prices
  offerFor: string | null; // "ABS edgebanding, 22 mm"
  discountPercent: number | null; // -5 = 5 % discount, +10 = 10 % addition
  nextAction: string | null; // a concrete reminder in English
  timing: Timing | null;
  // about the company, without being asked
  companyType: string | null; // "Kitchen manufacturer", "Wood panel distributor" ...
  companyProfile: string | null; // two or three sentences
  website: string | null;
  websiteSummary: string | null; // what the company's own web site says (read automatically)
  decisionMaker: boolean | null; // does their position suggest they decide on purchases
  approach: string | null; // how to approach them, one sentence
  bulgariaFit: boolean; // better served by the Bulgaria office (small quantities / Kronospan decors in Europe)
  bulgariaReason: string | null;
  noOfferReason: string | null; // why an offer is not needed (sent before, too small ...)
  source: 'ai' | 'rules';
}

export const INSIGHT_RULES = `Besides the fields, work out "insight" for the sales team. The handwritten notes are instructions from our own staff to themselves, usually in Turkish (sometimes English or Italian), and they are written in a hurry.
- "summary": the notes in one or two plain English sentences. Null if there are no notes.
- "companyActivity": if the "Work Area" box is empty or says nothing useful, what this company does in a short English phrase (for example "Kitchen furniture manufacturer"), using the company name, the business card and the e-mail domain. Only when you are reasonably sure, otherwise null. Never guess from a gmail/hotmail address.
- "products": which of our products they asked about (pvc, abs, pp, metal, melamine, veneer, screw, machines), from the notes and the "Interested in" box. "Abs teklif" means an ABS offer. Empty list if none is mentioned.
- "widths": edge widths in mm that are mentioned (22, 33, 44 ...). Empty if none.
- "otherInterest": anything else they asked for. Null if nothing.
- "sendThankYou": true unless the notes say not to write to them. "Tesekkur et" / "Tesekkur edelim" means thank them. When in doubt true.
- "sendOffer": true when the notes ask for an offer or prices ("teklif", "fiyat", "offer", "quote", "send prices"). False otherwise.
- "offerFor": when sendOffer is true, what the offer is for in a few English words ("ABS edgebanding"). Null otherwise.
- "discountPercent": a discount or addition that was promised, as a number: "5 indirim" or "-5" is -5, "+10" is 10. Null if none.
- "nextAction": the one concrete thing to do next, in English, only when the notes imply something beyond a thank-you and an offer ("Call back after the fair", "Meet again at the next show", "Waiting for their drawings"). Null otherwise.
- "timing": "now", "this_week" or "later" - how soon the notes want it done. Null if not stated.
- "companyType": what kind of company it is in two to four words ("Kitchen manufacturer", "Panel distributor", "Interior design studio"). Null if you cannot tell.
- "companyProfile": two or three sentences about the company that would help a salesperson before writing to them: what they make or sell, who their customers probably are, anything notable about their market or country. Use the company name, the business card, the e-mail domain, the Work Area and what you know about the company. If you do not know the company, say only what the name and Work Area imply - never invent facts, numbers or names.
- "website": their web address if it is printed on the card or clear from a company e-mail domain (never from gmail/hotmail/yahoo). Null otherwise.
- "decisionMaker": true when their position suggests they decide or strongly influence purchases (owner, CEO, director, purchasing or production manager), false when clearly not (assistant, intern), null when the position is unknown.
- "approach": one sentence on how to approach this customer (what to offer first, what to stress), based on all of the above. Null if there is nothing to base it on.
- "bulgariaFit": TECE Dekor Ltd. in Bulgaria is our hub for Europe. It stocks ONLY the Kronospan decor collection and sells small quantities, about one roll or less, to European customers. true only when the visitor is in Europe AND wants edgebanding in Kronospan decors (the notes or the form mention Kronospan, or a Kronospan decor code / board) AND the quantity is small (a roll or less, a few meters, samples, a small workshop). false for every other decor collection (Egger, Swiss Krono, own colors ...), for large volumes, for customers outside Europe, and whenever Kronospan is not clearly involved.
- "bulgariaReason": one short sentence saying why (or null when bulgariaFit is false).
- "noOfferReason": when no offer should be sent, say why in a few words: "An offer was already sent earlier" (the notes say so), "Too small to quote", "Not interested", "Competitor / not a customer". Null when an offer is fine or when nothing is said. In that case sendOffer must be false.
Never invent. If the notes are empty, say nothing beyond what the form itself shows.`;

// Gemini schema (OpenAPI subset: uppercase types, nullable instead of null unions).
export const INSIGHT_SCHEMA = {
  type: 'OBJECT',
  properties: {
    summary: { type: 'STRING', nullable: true },
    companyActivity: { type: 'STRING', nullable: true },
    products: { type: 'ARRAY', items: { type: 'STRING', enum: INTEREST_PRODUCTS.map((p) => p.key) } },
    widths: { type: 'ARRAY', items: { type: 'INTEGER' } },
    otherInterest: { type: 'STRING', nullable: true },
    sendThankYou: { type: 'BOOLEAN' },
    sendOffer: { type: 'BOOLEAN' },
    offerFor: { type: 'STRING', nullable: true },
    discountPercent: { type: 'NUMBER', nullable: true },
    nextAction: { type: 'STRING', nullable: true },
    timing: { type: 'STRING', nullable: true, enum: ['now', 'this_week', 'later'] },
    companyType: { type: 'STRING', nullable: true },
    companyProfile: { type: 'STRING', nullable: true },
    website: { type: 'STRING', nullable: true },
    decisionMaker: { type: 'BOOLEAN', nullable: true },
    approach: { type: 'STRING', nullable: true },
    bulgariaFit: { type: 'BOOLEAN' },
    bulgariaReason: { type: 'STRING', nullable: true },
    noOfferReason: { type: 'STRING', nullable: true },
  },
  required: ['summary', 'companyActivity', 'products', 'widths', 'otherInterest', 'sendThankYou', 'sendOffer', 'offerFor', 'discountPercent', 'nextAction', 'timing', 'companyType', 'companyProfile', 'website', 'decisionMaker', 'approach', 'bulgariaFit', 'bulgariaReason', 'noOfferReason'],
} as const;

const short = (v: unknown, max: number): string | null => (typeof v === 'string' && v.trim() ? v.replace(/\s+/g, ' ').trim().slice(0, max) : null);

// Whatever came back is checked before it is trusted.
export function normaliseInsight(raw: unknown, source: AiInsight['source'] = 'ai'): AiInsight {
  const r = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>;
  const pct = typeof r.discountPercent === 'number' && Number.isFinite(r.discountPercent) && r.discountPercent !== 0 ? Math.max(-90, Math.min(500, r.discountPercent)) : null;
  const noOffer = short(r.noOfferReason, 120);
  const sendOffer = r.sendOffer === true && !noOffer;
  return {
    summary: short(r.summary, 400),
    companyActivity: short(r.companyActivity, 120),
    products: (Array.isArray(r.products) ? r.products : []).filter((p): p is string => typeof p === 'string' && PRODUCT_KEYS.has(p)),
    widths: sanitiseWidths(r.widths),
    otherInterest: short(r.otherInterest, 200),
    sendThankYou: r.sendThankYou !== false,
    sendOffer,
    offerFor: sendOffer ? short(r.offerFor, 120) : null,
    discountPercent: pct,
    nextAction: short(r.nextAction, 200),
    timing: r.timing === 'now' || r.timing === 'this_week' || r.timing === 'later' ? r.timing : null,
    companyType: short(r.companyType, 80),
    companyProfile: short(r.companyProfile, 700),
    website: short(r.website, 200),
    websiteSummary: short(r.websiteSummary, 400),
    decisionMaker: typeof r.decisionMaker === 'boolean' ? r.decisionMaker : null,
    approach: short(r.approach, 300),
    bulgariaFit: r.bulgariaFit === true,
    bulgariaReason: r.bulgariaFit === true ? short(r.bulgariaReason, 200) : null,
    noOfferReason: short(r.noOfferReason, 120),
    source,
  };
}

export function parseInsight(json: string | null | undefined): AiInsight | null {
  if (!json) return null;
  try {
    return normaliseInsight(JSON.parse(json), (JSON.parse(json) as AiInsight).source === 'rules' ? 'rules' : 'ai');
  } catch {
    return null;
  }
}

const plain = (s: string) =>
  s
    .normalize('NFD')
    .replace(/\p{Diacritic}/gu, '')
    .replace(/ı/g, 'i')
    .toLowerCase();

// Plain-words reading of the notes, for when the AI cannot be asked.
export function ruleInsight(card: { notes?: string | null; interested_in?: string | null; work_area?: string | null; products?: string[]; widths?: number[]; other?: string | null }): AiInsight {
  const notes = card.notes ?? '';
  const text = plain([notes, card.interested_in].filter(Boolean).join(' \n '));
  const noThanks = /thank.{0,6}(not|no)\b|tesekkur etme|yazma\b|do not (write|send|mail)/.test(text);
  const sendOffer = /\bteklif|\bfiyat|\boffer\b|\bquote|\bquotation|\bprice list|\bofferta|\bpreventivo|\bprices\b/.test(text);
  const products = card.products ?? [];
  const names = INTEREST_PRODUCTS.filter((p) => products.includes(p.key)).map((p) => p.label);
  const pct = text.match(/(?:^|\s)([+-]\s?\d{1,2}(?:[.,]\d)?)\s*%/);
  const discount = text.match(/%\s?(\d{1,2})\s*(?:indirim|iskonto|discount)|(\d{1,2})\s*%?\s*(?:indirim|iskonto|discount)/);
  const alreadySent = /teklif (verildi|gonderildi|gonderdik|yollandi)|offer (was |has been )?(already )?sent|already (sent|offered)|zaten (gonderildi|verildi)/.test(text);
  const tooSmall = /cok kucuk|too small|very small|minimum yok|tiny/.test(text);
  // only the Kronospan collection is stocked in Bulgaria
  const bulgaria = /kronospan/.test(text);
  let discountPercent: number | null = null;
  if (pct) discountPercent = parseFloat(pct[1].replace(/\s/g, '').replace(',', '.'));
  else if (discount) discountPercent = -parseFloat(discount[1] ?? discount[2]);
  return normaliseInsight(
    {
      summary: null,
      companyActivity: null,
      products,
      widths: card.widths ?? [],
      otherInterest: card.other ?? null,
      sendThankYou: !noThanks,
      sendOffer: sendOffer && !alreadySent && !tooSmall,
      noOfferReason: alreadySent ? 'An offer was already sent earlier' : tooSmall ? 'Too small to quote' : null,
      bulgariaFit: bulgaria,
      bulgariaReason: bulgaria ? 'The notes mention the Kronospan collection' : null,
      offerFor: sendOffer ? (names.length ? `${names.join(', ')} edgebanding` : null) : null,
      discountPercent,
      nextAction: null,
      timing: null,
    },
    'rules'
  );
}

// ---- asking the AI about a record that is already in the system ------------------

const GEMINI_URL = 'https://generativelanguage.googleapis.com/v1beta/models';
const MODEL = 'gemini-3.6-flash';

export interface InsightInput {
  name: string | null;
  company: string | null;
  country: string | null;
  email: string | null;
  work_area: string | null;
  interested_in: string | null;
  notes: string | null;
  rate: number | null;
}

// Text-only version (badge imports, "ask the AI again"). Falls back to the plain-words reading.
export async function analyseCard(card: InsightInput, known: { products: string[]; widths: number[]; other: string | null }): Promise<AiInsight> {
  // what the words themselves say, together with what is ticked
  const words = detectInterest({ interestedIn: card.interested_in, workArea: card.work_area, notes: card.notes });
  const merged = { products: [...new Set([...known.products, ...words.products])], widths: [...new Set([...known.widths, ...words.widths])], other: known.other || words.other || null };
  const fallback = ruleInsight({ ...card, ...merged });
  if (!env.geminiApiKey) return fallback;
  const prompt = [
    'You help a Turkish edgebanding company (tece) after an exhibition.',
    INSIGHT_RULES.replace('Besides the fields, work out "insight" for the sales team. ', ''),
    `Visitor: ${JSON.stringify({ name: card.name, company: card.company, country: card.country, email: card.email, workArea: card.work_area, interestedIn: card.interested_in, rate: card.rate, notes: card.notes })}`,
  ].join('\n\n');
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      const res = await fetch(`${GEMINI_URL}/${MODEL}:generateContent`, {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-goog-api-key': env.geminiApiKey },
        body: JSON.stringify({
          contents: [{ role: 'user', parts: [{ text: prompt }] }],
          generationConfig: { responseMimeType: 'application/json', responseSchema: INSIGHT_SCHEMA, temperature: 0.2 },
        }),
        signal: AbortSignal.timeout(30000),
      });
      if (!res.ok) {
        if (res.status === 429 || res.status >= 500) {
          await new Promise((r) => setTimeout(r, 1500 * (attempt + 1)));
          continue;
        }
        return fallback;
      }
      const data = (await res.json()) as { candidates?: { content?: { parts?: { text?: string; thought?: boolean }[] } }[] };
      const parts = data.candidates?.[0]?.content?.parts?.filter((p) => !p.thought && p.text) ?? [];
      const text = parts[parts.length - 1]?.text;
      if (!text) return fallback;
      return normaliseInsight(JSON.parse(text), 'ai');
    } catch {
      await new Promise((r) => setTimeout(r, 1000));
    }
  }
  return fallback;
}

// Is an offer wanted for this customer: the tick when somebody has decided, otherwise what the AI read in the notes.
export function offerWanted(card: { send_offer: number | null; ai_insight: string | null; country?: string | null; handling?: string | null }): boolean {
  if (card.send_offer !== null && card.send_offer !== undefined) return card.send_offer === 1;
  // visitors from a country with a distributor are sent to the distributor, not quoted by us
  if (distributorModel.forCard(card)) return false;
  return parseInsight(card.ai_insight)?.sendOffer === true;
}

// Pass to the Bulgaria office (TECE Dekor Ltd): the tick when somebody decided, otherwise the AI's suggestion.
export function bulgariaWanted(card: { bulgaria: number | null; ai_insight: string | null }): boolean {
  if (card.bulgaria !== null && card.bulgaria !== undefined) return card.bulgaria === 1;
  return parseInsight(card.ai_insight)?.bulgariaFit === true;
}

// ---- a sentence for the thank-you e-mail --------------------------------------------

// "We will send you our offer shortly" - only when the notes ask for an offer that has not gone out yet.
export function followUpSentence(insight: AiInsight | null, offerAlreadySent: boolean, wanted: boolean | null = null): string | null {
  // the tick on the record decides; without it, what the AI read
  if (!insight || !(wanted ?? insight.sendOffer) || offerAlreadySent) return null;
  const about = insight.offerFor ? ` for ${insight.offerFor}` : '';
  return `We will send you our offer${about} shortly.`;
}
