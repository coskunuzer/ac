-- What the staff do in the app (clicks, pages, errors, slow answers), so the admin can download it and use it to make the app easier. No typed text is ever kept.
CREATE TABLE IF NOT EXISTS ux_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  session TEXT,
  at TEXT NOT NULL,                  -- ISO time of the event
  kind TEXT NOT NULL,                -- click | view | dead | rage | error | api_error | slow | key
  route TEXT,                        -- the page, with the numbers of records replaced (/cards/:id/review)
  target TEXT,                       -- what was clicked: its label
  extra TEXT                         -- small JSON: tag, area, ms, status ...
);
CREATE INDEX IF NOT EXISTS idx_ux_at ON ux_events (at);
CREATE INDEX IF NOT EXISTS idx_ux_user ON ux_events (user_id, at);
