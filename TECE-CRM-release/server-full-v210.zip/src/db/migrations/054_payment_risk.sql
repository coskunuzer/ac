-- Payment behaviour: the "black account" (a customer that pays late is flagged, the people who send an order or dispatch are warned).
-- An admin can mark a customer black (or clear it) by hand; the automatic level comes from the ledger (services/paymentRisk.ts).
CREATE TABLE IF NOT EXISTS perf_risk (
  sap_no TEXT PRIMARY KEY,
  mode TEXT NOT NULL CHECK (mode IN ('black', 'clear')),
  reason TEXT,
  by_user INTEGER,
  at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- the AI's reading of how a customer pays (kept; asked again only when the figures change or after 30 days)
CREATE TABLE IF NOT EXISTS perf_risk_ai (
  sap_no TEXT PRIMARY KEY,
  body TEXT NOT NULL,
  data_hash TEXT NOT NULL,
  made_at TEXT NOT NULL DEFAULT (datetime('now'))
);
