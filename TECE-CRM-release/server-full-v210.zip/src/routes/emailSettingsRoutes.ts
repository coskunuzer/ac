import { Router } from 'express';
import { requireAuth, requireAdmin, type AuthedRequest } from '../middleware/auth';
import { emailTemplateModel, isTextLanguage, type TemplateKind } from '../models/emailTemplateModel';
import { settingsModel } from '../models/settingsModel';
import { buildSignature, defaultSignatureStyle, isSignatureStyle, SIGNATURE_STYLES, styleFor } from '../services/signature';

const router = Router();
router.use(requireAuth);

const asKind = (v: unknown): TemplateKind | null => (v === 'thank_you' || v === 'offer' ? v : null);

function readTemplate(body: Record<string, unknown> | undefined): { name: string; subject: string; body: string } | { error: string } {
  const name = String(body?.name ?? '').trim().slice(0, 80);
  const subject = String(body?.subject ?? '').trim().slice(0, 200);
  const text = String(body?.body ?? '').replace(/\r\n/g, '\n').trim().slice(0, 6000);
  if (!name) return { error: 'Give this text a name.' };
  if (!subject) return { error: 'The subject cannot be empty.' };
  if (!text) return { error: 'The message cannot be empty.' };
  return { name, subject, body: text };
}

// ---- texts for the thank-you and the offer email -------------------------

router.get('/templates', (_req, res) => {
  res.json(emailTemplateModel.list().map((t) => ({ ...t, translations: Object.fromEntries(emailTemplateModel.translations(t.id).map((x) => [x.lang, { subject: x.subject, body: x.body }])) })));
});

// The same text in another language: the e-mail goes out in the language of the customer (English when there is no translation).
router.put('/templates/:id/translations/:lang', requireAdmin, (req, res) => {
  const id = parseInt(String(req.params.id), 10);
  if (!emailTemplateModel.find(id)) return res.status(404).json({ error: 'Not found' });
  if (!isTextLanguage(req.params.lang)) return res.status(400).json({ error: 'Choose Russian, Turkish, Spanish or French.' });
  const subject = String(req.body?.subject ?? '').trim().slice(0, 200);
  const text = String(req.body?.body ?? '').replace(/\r\n/g, '\n').trim().slice(0, 6000);
  if (!subject || !text) return res.status(400).json({ error: 'Write both the subject and the message.' });
  emailTemplateModel.setTranslation(id, req.params.lang, subject, text);
  res.json({ ok: true });
});

router.delete('/templates/:id/translations/:lang', requireAdmin, (req, res) => {
  const id = parseInt(String(req.params.id), 10);
  if (!emailTemplateModel.find(id)) return res.status(404).json({ error: 'Not found' });
  emailTemplateModel.deleteTranslation(id, String(req.params.lang));
  res.json({ ok: true });
});

router.post('/templates', requireAdmin, (req, res) => {
  const kind = asKind(req.body?.kind);
  if (!kind) return res.status(400).json({ error: 'kind must be "thank_you" or "offer"' });
  const t = readTemplate(req.body);
  if ('error' in t) return res.status(400).json(t);
  res.status(201).json(emailTemplateModel.create({ kind, ...t }));
});

router.put('/templates/:id', requireAdmin, (req, res) => {
  const id = parseInt(String(req.params.id), 10);
  if (!emailTemplateModel.find(id)) return res.status(404).json({ error: 'Not found' });
  const t = readTemplate(req.body);
  if ('error' in t) return res.status(400).json(t);
  res.json(emailTemplateModel.update(id, t));
});

router.post('/templates/:id/default', requireAdmin, (req, res) => {
  const id = parseInt(String(req.params.id), 10);
  if (!emailTemplateModel.find(id)) return res.status(404).json({ error: 'Not found' });
  emailTemplateModel.setDefault(id);
  res.json({ ok: true });
});

router.delete('/templates/:id', requireAdmin, (req, res) => {
  const id = parseInt(String(req.params.id), 10);
  if (!emailTemplateModel.delete(id)) {
    return res.status(400).json({ error: 'There must always be at least one text of each kind.' });
  }
  res.json({ ok: true });
});

// ---- test mode: every e-mail goes to one test address and nothing is recorded as sent -----
router.get('/test-mode', (req: AuthedRequest, res) => {
  res.json({ on: settingsModel.get('test_mode') === '1', email: settingsModel.get('test_email') || req.user?.email || null });
});

router.put('/test-mode', requireAdmin, (req, res) => {
  const email = String(req.body?.email ?? '').trim();
  if (email && !/^[^\s@,;]+@[^\s@,;]+\.[^\s@,;]+$/.test(email)) return res.status(400).json({ error: 'That test address does not look right.' });
  settingsModel.set('test_mode', req.body?.on ? '1' : '0');
  settingsModel.set('test_email', email);
  res.json({ on: !!req.body?.on, email: email || null });
});

// ---- signature layouts ----------------------------------------------------

// Each layout previewed with the signed-in person's own details.
router.get('/signature-styles', (req: AuthedRequest, res) => {
  const company = defaultSignatureStyle();
  res.json({
    companyDefault: company,
    mine: isSignatureStyle(req.user?.signature_style) ? req.user!.signature_style : null,
    effective: styleFor(req.user),
    styles: SIGNATURE_STYLES.map((s) => ({ ...s, preview: buildSignature(req.user, s.id).text })),
  });
});

router.put('/signature-default', requireAdmin, (req, res) => {
  if (!isSignatureStyle(req.body?.style)) return res.status(400).json({ error: 'Unknown signature layout' });
  settingsModel.set('signature_style', req.body.style);
  res.json({ ok: true, companyDefault: req.body.style });
});

export default router;
