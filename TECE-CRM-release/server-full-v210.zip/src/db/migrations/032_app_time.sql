-- How long each person works in the app, per day (the page tells the server every half minute that the person is there and active).
CREATE TABLE IF NOT EXISTS app_time (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  day TEXT NOT NULL,
  seconds INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, day)
);
