import { db } from '../db/connection';
import { env } from '../config/env';
import { cardModel, type CardRow } from '../models/cardModel';
import { logAi, runForCard } from './aiLog';
import { placeOf } from './geo';
import { isoOf } from './phone';

// Where each customer is, so a trip can be planned and shown on a map. In this order (the cheapest first):
//  1. the city of the customer is one of the ~4,500 major cities we have the place of (free, instant);
//  2. the written address (or the city) is looked up in OpenStreetMap (free, one question a second);
//  3. when there is no city and no address at all, the AI searches the web for the company and
//     reports its address - which is then looked up the same way. The AI only reports what it finds; it is never asked for numbers.
// A customer for which nothing was found is marked 'none' and is not searched again unless a person asks.

const NOMINATIM = process.env.NOMINATIM_URL || 'https://nominatim.openstreetmap.org/search';
const UA = 'TECE-CRM trip planner (business address lookup)';
let last = 0;
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export interface Found { lat: number; lon: number; place: string; city?: string }

// OpenStreetMap asks for no more than one question a second.
async function nominatim(q: string, iso: string | null, settlement = false): Promise<Found | null> {
  const wait = 1100 - (Date.now() - last);
  if (wait > 0) await sleep(wait);
  last = Date.now();
  try {
    const url = `${NOMINATIM}?format=jsonv2&limit=1&addressdetails=1&q=${encodeURIComponent(q)}${settlement ? '&featureType=settlement' : ''}${iso ? `&countrycodes=${iso.toLowerCase()}` : ''}`;
    const res = await fetch(url, { headers: { 'user-agent': UA, accept: 'application/json', 'accept-language': 'en' }, signal: AbortSignal.timeout(15000) });
    if (!res.ok) return null;
    const rows = (await res.json()) as { lat?: string; lon?: string; display_name?: string; address?: Record<string, string> }[];
    const r = rows[0];
    const lat = Number(r?.lat); const lon = Number(r?.lon);
    return r && Number.isFinite(lat) && Number.isFinite(lon) ? { lat, lon, place: String(r.display_name ?? q).slice(0, 200), city: r.address?.city || r.address?.town || r.address?.municipality || r.address?.village || r.address?.county || undefined } : null;
  } catch {
    return null;
  }
}

// one place looked up on the map by a person (the customer popup): the same free OpenStreetMap search, one question a second
export const lookupPlace = (q: string, iso: string | null, settlement = false): Promise<Found | null> => nominatim(q, iso, settlement);

const GEMINI_URL = 'https://generativelanguage.googleapis.com/v1beta/models';
const MODEL = 'gemini-3.6-flash';

// The AI is asked where the company is (address and city) with a web search (the same search the other AI checks use); what it reports is then
// looked up on the map, so an answer that does not exist in that country is dropped. undefined = could not be asked; null = it found nothing.
async function askWhere(company: string, country: string): Promise<{ address: string; city: string } | null | undefined> {
  const prompt = `Find where this company is: "${company}" in ${country}. It buys or makes furniture, kitchens, doors, panels or edgebanding. Use a web search and report only what the search results show. Answer with one line only: either PLACE: <street address> | <city> or PLACE: NONE. The city must be in ${country}. If the street address is not known write the city only (PLACE: | <city>). If the results do not clearly show this company, answer NONE. Never invent an address.`;
  for (const tool of [{ google_search: {} }]) {
    try {
      const res = await fetch(`${GEMINI_URL}/${MODEL}:generateContent`, {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-goog-api-key': env.geminiApiKey },
        body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: prompt }] }], tools: [tool], generationConfig: { temperature: 0 } }),
        signal: AbortSignal.timeout(45000),
      });
      if (!res.ok) { if (res.status === 400 || res.status === 404) continue; return undefined; }
      const data = (await res.json()) as { candidates?: { content?: { parts?: { text?: string; thought?: boolean }[] } }[] };
      const text = (data.candidates?.[0]?.content?.parts ?? []).filter((p) => !p.thought && p.text).map((p) => p.text).join(' ');
      const m = /PLACE:\s*([^\n]*)/i.exec(text);
      if (!m || /^\s*none/i.test(m[1])) return null;
      const [address, city] = m[1].includes('|') ? m[1].split('|').map((x) => x.trim()) : ['', m[1].trim()];
      return city ? { address: address.slice(0, 200), city: city.slice(0, 80) } : null;
    } catch {
      return undefined;
    }
  }
  return undefined;
}

// The instant, free part: a customer whose city is one of the major cities gets its place at once (no waiting, no outside service).
// A customer with a written address is refined later by 'Find places' (the address is more exact than the city).
export function quickPlace(cardId: number): void {
  const card = cardModel.findById(cardId);
  if (!card || (card.lat != null && card.lon != null)) return;
  const p = placeOf(card.city, card.country);
  if (p) db.prepare("UPDATE cards SET lat = ?, lon = ?, geo_source = 'city list', geo_place = ? WHERE id = ?").run(p.lat, p.lon, p.name, cardId);
}

type Outcome = 'have' | 'city list' | 'map search' | 'ai' | 'none' | 'no-ai' | 'failed';

// Finds the place of one customer and writes it on the customer. Returns how.
export async function locateCard(card: CardRow, opts: { useAi: boolean; force?: boolean; aiLeft?: { n: number } } = { useAi: true }): Promise<Outcome> {
  if (card.lat != null && card.lon != null && !opts.force && !(card.geo_source === 'city list' && (card.address ?? '').trim())) return 'have';
  if (card.geo_source === 'none' && !opts.force) return 'none';
  const country = (card.country ?? '').trim();
  if (!country) return 'none';
  const iso = isoOf(country);
  const set = db.prepare('UPDATE cards SET lat = ?, lon = ?, geo_source = ?, geo_place = ? WHERE id = ?');

  const listed = placeOf(card.city, country);
  if (listed && !(card.address ?? '').trim()) { set.run(listed.lat, listed.lon, 'city list', listed.name, card.id); return 'city list'; }

  // the written address first (more exact), then the city
  if ((card.address ?? '').trim()) {
    const f = await nominatim([card.address, card.city, country].filter(Boolean).join(', '), iso);
    if (f) {
      set.run(f.lat, f.lon, 'map search', f.place, card.id);
      if (!(card.city ?? '').trim() && f.city) db.prepare('UPDATE cards SET city = ? WHERE id = ?').run(f.city, card.id);
      return 'map search';
    }
  }
  if (listed) { set.run(listed.lat, listed.lon, 'city list', listed.name, card.id); return 'city list'; }
  if ((card.city ?? '').trim()) {
    const f = await nominatim(`${card.city}, ${country}`, iso);
    if (f) { set.run(f.lat, f.lon, 'map search', f.place, card.id); return 'map search'; }
  }

  // nothing written down: the AI looks for the company
  if (opts.useAi && env.geminiApiKey && card.company && (!opts.aiLeft || opts.aiLeft.n > 0)) {
    if (opts.aiLeft) opts.aiLeft.n -= 1;
    const where = await runForCard(card.id, () => askWhere(card.company!, country));
    if (where === undefined) return 'failed'; // the AI could not be asked: not "nothing found"
    if (where) {
      const f = await nominatim([where.address, where.city, country].filter(Boolean).join(', '), iso) ?? (placeOf(where.city, country) ? { lat: placeOf(where.city, country)!.lat, lon: placeOf(where.city, country)!.lon, place: where.city } : await nominatim(`${where.city}, ${country}`, iso));
      if (f) {
        set.run(f.lat, f.lon, 'ai', f.place, card.id);
        // the customer gets the city (and the address) the AI found, only where there was nothing
        if (!(card.city ?? '').trim()) db.prepare('UPDATE cards SET city = ? WHERE id = ?').run(where.city, card.id);
        if (!(card.address ?? '').trim() && where.address) db.prepare('UPDATE cards SET address = ? WHERE id = ?').run(where.address, card.id);
        logAi(card.id, `AI found the place of this company: ${[where.address, where.city].filter(Boolean).join(', ')}`);
        return 'ai';
      }
    }
  } else if (opts.useAi && !env.geminiApiKey) {
    return 'no-ai';
  }
  set.run(null, null, 'none', null, card.id);
  return 'none';
}

// ---- the job for many customers (one at a time because of the one-question-a-second rule) -------------------------------------------
export interface LocateJob { running: boolean; total: number; done: number; located: number; viaAi: number; none: number; failed: number; startedAt: string | null; finishedAt: string | null; hasAi: boolean }
let job: LocateJob = { running: false, total: 0, done: 0, located: 0, viaAi: 0, none: 0, failed: 0, startedAt: null, finishedAt: null, hasAi: !!env.geminiApiKey };
export const locateStatus = (): LocateJob => ({ ...job, hasAi: !!env.geminiApiKey });

export function startLocating(ids: number[], opts: { useAi: boolean; force?: boolean; aiMax?: number }): LocateJob {
  if (job.running) return locateStatus();
  const queue = [...new Set(ids)];
  job = { running: queue.length > 0, total: queue.length, done: 0, located: 0, viaAi: 0, none: 0, failed: 0, startedAt: new Date().toISOString(), finishedAt: queue.length ? null : new Date().toISOString(), hasAi: !!env.geminiApiKey };
  if (!job.running) return locateStatus();
  const aiLeft = { n: opts.aiMax ?? 300 };
  void (async () => {
    while (queue.length) {
      const id = queue.shift()!;
      try {
        const card = cardModel.findById(id);
        if (card) {
          const r = await locateCard(card, { ...opts, aiLeft });
          if (r === 'ai') { job.located += 1; job.viaAi += 1; }
          else if (r === 'city list' || r === 'map search') job.located += 1;
          else if (r === 'none' || r === 'no-ai') job.none += 1;
          else if (r === 'failed') job.failed += 1;
        }
      } catch (err) {
        console.error('Locating a customer failed:', id, err);
        job.failed += 1;
      }
      job.done += 1;
    }
    job.running = false;
    job.finishedAt = new Date().toISOString();
  })();
  return locateStatus();
}
