import { Router } from 'express';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { addExploreMinutes, exploreNext, explorePlaces, exploreToday } from '../services/explore';
import { briefFor } from '../services/exploreBrief';

const router = Router();
router.use(requireAuth);

// Today's country (or city) to explore in the lead list, and the minutes spent so far.
router.get('/today', (req: AuthedRequest, res) => {
  res.json(exploreToday(req.user!));
});

// The countries (cities) this person may sprint in: the ones they are responsible for.
router.get('/places', (req: AuthedRequest, res) => {
  res.json({ countries: explorePlaces(req.user!) });
});

router.post('/minutes', (req: AuthedRequest, res) => {
  const minutes = typeof req.body?.minutes === 'number' ? req.body.minutes : parseFloat(String(req.body?.minutes ?? ''));
  if (!Number.isFinite(minutes) || minutes <= 0) return res.status(400).json({ error: 'minutes must be a positive number' });
  exploreToday(req.user!);
  res.json(addExploreMinutes(req.user!, minutes));
});

// Finished the place of today: the next one (a country not yet done today).
router.post('/next', (req: AuthedRequest, res) => {
  const n = exploreNext(req.user!);
  if (!n) return res.status(404).json({ error: 'No other place is left.' });
  res.json(n);
});

// The briefing about today's place: our numbers there, what could be improved, and a short text about the place (the AI, kept for three weeks).
router.get('/brief', async (req: AuthedRequest, res) => {
  const today = exploreToday(req.user!);
  if (!today) return res.status(404).json({ error: 'No place today.' });
  res.json(await briefFor(req.user!, today.country, today.market, req.user!.ui_language ?? 'en'));
});

export default router;
