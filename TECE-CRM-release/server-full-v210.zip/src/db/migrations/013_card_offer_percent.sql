-- The discount (negative) or addition (positive) agreed with this customer, as a
-- fraction (-0.1 = 10 % discount). Set on the scan page; the offer starts from it.
ALTER TABLE cards ADD COLUMN offer_percent REAL;
