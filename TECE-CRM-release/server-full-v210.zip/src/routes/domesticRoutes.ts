import { Router } from 'express';
import { db } from '../db/connection';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { cardModel } from '../models/cardModel';
import { activityModel } from '../models/activityModel';
import { settingsModel } from '../models/settingsModel';
import { canSeeCard } from '../services/visibility';
import { sendThankYouEmail } from '../services/thankYouEmail';
import { buildSignature, styleFor } from '../services/signature';
import { asTier, priceList, renderDomesticOfferPdf, TIERS } from '../services/domesticPrices';

// The domestic PVC price lists A, B, C: the tier of a customer, the discount on top, the PDF and the e-mail in Turkish.
const router = Router();
router.use(requireAuth);

function cardFor(req: AuthedRequest, res: import('express').Response) {
  const card = cardModel.findById(parseInt(String(req.params.id), 10));
  if (!card) { res.status(404).json({ error: 'Not found' }); return null; }
  if (!canSeeCard(req.user, card)) { res.status(403).json({ error: 'You do not have access to this record' }); return null; }
  return card;
}
const pctOf = (v: unknown, fallback: number) => { const n = Number(String(v ?? '').replace(',', '.')); return Number.isFinite(n) && n > -100 && n < 100 ? n : fallback; };
const tierOf = (card: { price_tier?: string | null }) => asTier(card.price_tier) ?? 'A';

router.get('/:id/domestic-prices', (req: AuthedRequest, res) => {
  const card = cardFor(req, res);
  if (!card) return;
  res.json({ domestic: card.market === 'domestic', tier: asTier((card as { price_tier?: string | null }).price_tier), discount: card.offer_percent ?? 0, tiers: TIERS, date: priceList('A').date });
});

// fix the customer to a list (and keep the usual discount)
router.patch('/:id/price-tier', (req: AuthedRequest, res) => {
  const card = cardFor(req, res);
  if (!card) return;
  const tier = asTier(req.body?.tier);
  if (!tier) return res.status(400).json({ error: 'Choose A, B or C.' });
  db.prepare("UPDATE cards SET price_tier = ?, offer_percent = COALESCE(?, offer_percent), updated_at = datetime('now') WHERE id = ?").run(tier, req.body?.discount === undefined ? null : pctOf(req.body.discount, 0), card.id);
  activityModel.add({ userId: req.user!.id, cardId: card.id, type: 'note', text: `Fiyat listesi: ${tier}${req.body?.discount !== undefined ? `, iskonto/ilave % ${pctOf(req.body.discount, 0)}` : ''}` });
  res.json({ ok: true });
});

router.get('/:id/domestic-offer.pdf', async (req: AuthedRequest, res) => {
  const card = cardFor(req, res);
  if (!card) return;
  const tier = asTier(req.query.tier) ?? tierOf(card as { price_tier?: string | null });
  const pdf = await renderDomesticOfferPdf(tier, pctOf(req.query.discount, card.offer_percent ?? 0), { company: card.company || card.name || '', contact: card.company ? card.name ?? '' : '', preparedBy: req.user!.display_name || req.user!.username });
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', 'inline; filename="TECE-PVC-fiyat-listesi.pdf"');
  res.send(pdf);
});

// the usual Turkish text (the salesperson reads and changes it before it goes)
router.get('/:id/domestic-offer/draft', (req: AuthedRequest, res) => {
  const card = cardFor(req, res);
  if (!card) return;
  const first = card.name?.split(/\s+/)[0] || card.company || '';
  const to = [card.email ?? '', ...(db.prepare('SELECT email FROM card_contacts WHERE card_id = ? AND email IS NOT NULL').all(card.id) as { email: string }[]).map((r) => r.email)].filter(Boolean);
  res.json({
    subject: 'TECE PVC kenar bandı fiyat listesi',
    body: [`Sayın ${first},`, '', 'İlginiz için teşekkür ederiz. PVC kenar bandı fiyat listemizi ekte bilgilerinize sunarız.', 'Fiyatlar Euro cinsindendir ve KDV dahil değildir.', '', 'Başka bir ölçü, renk veya numune için bize yazabilirsiniz.', '', `Saygılarımla,\n${req.user!.display_name || req.user!.username}`].join('\n'),
    to: [...new Set(to)].slice(0, 6), me: req.user!.email,
  });
});

router.post('/:id/domestic-offer/send', async (req: AuthedRequest, res) => {
  const card = cardFor(req, res);
  if (!card) return;
  const tier = asTier(req.body?.tier) ?? tierOf(card as { price_tier?: string | null });
  const pct = pctOf(req.body?.discount, card.offer_percent ?? 0);
  const to = (Array.isArray(req.body?.to) ? req.body.to : []).map(String).filter((a: string) => /@/.test(a));
  const subject = String(req.body?.subject ?? '').trim().slice(0, 200);
  const body = String(req.body?.body ?? '').trim().slice(0, 6000);
  if (!to.length) return res.status(400).json({ error: 'Alıcıyı seçin.' });
  if (!subject || !body) return res.status(400).json({ error: 'E-postanın konusu ve metni gerekli.' });
  const wanted = req.body?.test === true || settingsModel.get('test_mode') === '1';
  const testTo = wanted ? settingsModel.get('test_email') || req.user!.email || '' : null;
  if (testTo === '') return res.status(400).json({ error: 'There is no test address. Add your e-mail under My account.' });
  try {
    const pdf = await renderDomesticOfferPdf(tier, pct, { company: card.company || card.name || '', contact: card.company ? card.name ?? '' : '', preparedBy: req.user!.display_name || req.user!.username });
    await sendThankYouEmail({
      to: to.join(', '), cc: req.user!.email || null, subject, body, replyTo: req.user!.email, signature: buildSignature(req.user, styleFor(req.user)), testTo,
      attachments: [{ filename: 'TECE-PVC-fiyat-listesi.pdf', content: pdf, contentType: 'application/pdf' }],
      record: { cardId: card.id, userId: req.user!.id, kind: 'offer' },
    });
  } catch (err) {
    console.error('Domestic offer failed:', err);
    return res.status(502).json({ error: 'Failed to send email', message: (err as Error).message });
  }
  if (testTo) return res.json({ test: true, sentTo: testTo });
  db.prepare("UPDATE cards SET price_tier = ?, offer_percent = ?, updated_at = datetime('now') WHERE id = ?").run(tier, pct, card.id);
  activityModel.add({ userId: req.user!.id, cardId: card.id, type: 'offer', text: `PVC fiyat listesi (${tier})${pct ? `, % ${pct}` : ''}` });
  res.json({ ok: true });
});

export default router;
