import { Router } from 'express';
import { db } from '../db/connection';
import { requireAdmin, requireAuth, type AuthedRequest } from '../middleware/auth';
import { cardModel } from '../models/cardModel';
import { canSeeCard } from '../services/visibility';
import { useAi } from '../services/aiBudget';
import { aiFailureMessage } from '../services/aiGate';
import { audit } from '../services/audit';
import { cachedApproach, cleanCard, listCompetitors, makeApproach, suppliersOf } from '../services/competitors';

// Competitors: the battle cards (everybody reads, admins write), the edgebanding suppliers of a customer, and the approach for one customer.
const router = Router();
router.use(requireAuth);

const cardOf = (req: AuthedRequest, res: import('express').Response) => {
  const c = cardModel.findById(parseInt(String(req.params.cardId), 10));
  if (!c) { res.status(404).json({ error: 'Customer not found' }); return null; }
  if (!canSeeCard(req.user, c)) { res.status(403).json({ error: 'You do not have access to this record' }); return null; }
  return c;
};

router.get('/', (_req, res) => res.json({ rows: listCompetitors() }));
router.post('/', requireAdmin, (req: AuthedRequest, res) => {
  const name = String(req.body?.name ?? '').trim().slice(0, 80);
  if (!name) return res.status(400).json({ error: 'Write the name.' });
  const kind = ['edge', 'board', 'other'].includes(String(req.body?.kind)) ? String(req.body.kind) : 'edge';
  try { db.prepare('INSERT INTO competitors (name, kind, region, card_json, updated_by) VALUES (?, ?, ?, ?, ?)').run(name, kind, String(req.body?.region ?? '').slice(0, 80) || null, JSON.stringify(cleanCard({})), req.user!.id); } catch { return res.status(400).json({ error: 'That name exists already.' }); }
  res.status(201).json({ rows: listCompetitors() });
});
router.put('/:id', requireAdmin, (req: AuthedRequest, res) => {
  const id = parseInt(String(req.params.id), 10);
  const cur = db.prepare('SELECT * FROM competitors WHERE id = ?').get(id) as { id: number; name: string; kind: string } | undefined;
  if (!cur) return res.status(404).json({ error: 'Not found' });
  const kind = ['edge', 'board', 'other'].includes(String(req.body?.kind)) ? String(req.body.kind) : cur.kind;
  db.prepare("UPDATE competitors SET name = ?, kind = ?, region = ?, card_json = ?, verified = ?, updated_at = datetime('now'), updated_by = ? WHERE id = ?")
    .run(String(req.body?.name ?? cur.name).trim().slice(0, 80) || cur.name, kind, String(req.body?.region ?? '').slice(0, 80) || null, JSON.stringify(cleanCard((req.body?.card ?? {}) as Record<string, unknown>)), req.body?.verified ? 1 : 0, req.user!.id, id);
  audit(req.user, null, 'change', 'Battle card', cur.name, req.body?.verified ? 'confirmed' : 'edited');
  res.json({ rows: listCompetitors() });
});
router.delete('/:id', requireAdmin, (req, res) => { db.prepare('DELETE FROM competitors WHERE id = ?').run(parseInt(String(req.params.id), 10)); res.json({ rows: listCompetitors() }); });

router.get('/card/:cardId', (req: AuthedRequest, res) => { const c = cardOf(req, res); if (c) res.json({ rows: suppliersOf(c.id) }); });
router.post('/card/:cardId', (req: AuthedRequest, res) => {
  const c = cardOf(req, res);
  if (!c) return;
  const compId = parseInt(String(req.body?.competitorId), 10);
  const name = String(req.body?.name ?? '').trim().slice(0, 80);
  if (!Number.isInteger(compId) && !name) return res.status(400).json({ error: 'Choose a supplier or write its name.' });
  const share = Number(req.body?.sharePct);
  db.prepare('INSERT INTO card_suppliers (card_id, competitor_id, name, source, share_pct, note, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)')
    .run(c.id, Number.isInteger(compId) ? compId : null, Number.isInteger(compId) ? null : name, ['told', 'site', 'guess'].includes(String(req.body?.source)) ? String(req.body.source) : 'told', Number.isFinite(share) && share >= 0 && share <= 100 ? Math.round(share) : null, String(req.body?.note ?? '').slice(0, 200) || null, req.user!.id);
  audit(req.user, c.id, 'change', 'Edgebanding supplier', null, name || `#${compId}`);
  res.status(201).json({ rows: suppliersOf(c.id) });
});
router.delete('/card/:cardId/:sid', (req: AuthedRequest, res) => {
  const c = cardOf(req, res);
  if (!c) return;
  db.prepare('DELETE FROM card_suppliers WHERE id = ? AND card_id = ?').run(parseInt(String(req.params.sid), 10), c.id);
  res.json({ rows: suppliersOf(c.id) });
});

router.get('/approach/:cardId', (req: AuthedRequest, res) => { const c = cardOf(req, res); if (c) res.json(cachedApproach(c.id)); });
router.post('/approach/:cardId', async (req: AuthedRequest, res) => {
  const c = cardOf(req, res);
  if (!c) return;
  if (!req.body?.force) { const k = cachedApproach(c.id); if (k.approach && !k.stale) return res.json(k); }
  if (!useAi(req.user!, res)) return;
  const a = await makeApproach(c);
  if (!a) return res.status(503).json({ ai: true, error: aiFailureMessage('The AI could not write the approach just now. Try again.') });
  res.json({ approach: a, stale: false });
});

export default router;
