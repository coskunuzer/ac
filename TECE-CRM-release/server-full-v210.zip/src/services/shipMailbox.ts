import fs from 'fs';
import path from 'path';
import { createHash } from 'crypto';
import { ImapFlow } from 'imapflow';
import { simpleParser } from 'mailparser';
import { db } from '../db/connection';
import { paths } from '../config/env';
import { mailboxPassword, mailboxReady, shipConfig } from './shipMail';
import { processStored } from './shipQuotes';
import { confirmByReply } from './shipVerify';

// Reading the shipping mailbox. Every reply is stored in full (text and attachments) BEFORE the mailbox is told it was read, and before anything else is done with it,
// so a crash or an error loses nothing. A reply is matched to its request by the number in the subject, and to a firm by the address the request was sent to. A reply from
// an address that was not asked is held aside for a person. The mailbox itself is never emptied or changed, except that the message is marked read.

const TOKEN = /#(\d{8}-\d{2,})/;
const norm = (a: string) => a.trim().toLowerCase();
const ALLOWED = /\.(pdf|xlsx?|csv|docx?|jpe?g|png|txt)$/i;
const dir = () => path.join(paths.uploadsDir, '..', 'shipping');

async function attachmentText(name: string, content: Buffer): Promise<string> {
  try {
    if (/\.pdf$/i.test(name)) {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const pdf = require('pdf-parse/lib/pdf-parse.js') as (b: Buffer) => Promise<{ text: string }>;
      return (await pdf(content)).text.replace(/\s+/g, ' ').slice(0, 6000);
    }
    if (/\.(xlsx?|csv)$/i.test(name)) {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const X = require('xlsx') as typeof import('xlsx');
      const wb = X.read(content, { type: 'buffer' });
      return wb.SheetNames.slice(0, 2).map((n) => X.utils.sheet_to_csv(wb.Sheets[n])).join('\n').replace(/[ \t]+/g, ' ').slice(0, 6000);
    }
    if (/\.txt$/i.test(name)) return content.toString('utf8').slice(0, 6000);
  } catch { /* an unreadable attachment is kept as a file; the price then goes to manual review */ }
  return '';
}

// one raw message (from the mailbox, or a .eml): stored, matched, never read twice
export async function ingestRaw(raw: Buffer): Promise<'stored' | 'held' | 'late' | 'duplicate' | 'ignored'> {
  const mail = await simpleParser(raw);
  const subject = mail.subject ?? '';
  const m = TOKEN.exec(subject);
  if (!m) {
    // a reply to a verification e-mail: the code [V-xxxxxxxx] is in its subject
    const from0 = (mail.from?.value?.[0]?.address ?? '').trim().toLowerCase();
    if (from0 && from0 !== norm(shipConfig().user) && confirmByReply(subject, from0)) return 'stored';
    return 'ignored';
  }
  const key = mail.messageId ? mail.messageId.replace(/[<>]/g, '') : `raw-${createHash('sha1').update(raw).digest('hex')}`;
  if (db.prepare('SELECT 1 FROM ship_messages WHERE msg_key = ? OR msg_key = ?').get(key, `<${key}>`)) return 'duplicate';
  const req = db.prepare('SELECT id, status FROM ship_requests WHERE id = ?').get(m[1]) as { id: string; status: string } | undefined;
  if (!req) return 'ignored';
  const sender = norm(mail.from?.value?.[0]?.address ?? '');
  if (!sender || sender === norm(shipConfig().user)) return 'ignored'; // our own sent copy
  const fws = db.prepare('SELECT forwarder_id, emails FROM ship_request_fw WHERE request_id = ?').all(req.id) as { forwarder_id: number; emails: string }[];
  const fw = fws.find((f) => (JSON.parse(f.emails) as string[]).some((e) => norm(e) === sender));
  const files: { name: string; file: string; size: number; text?: string }[] = [];
  const folder = path.join(dir(), req.id, createHash('sha1').update(key).digest('hex').slice(0, 12));
  for (const a of mail.attachments ?? []) {
    const name = (a.filename ?? 'ek').replace(/[^\w.\- ()]+/g, '_').slice(0, 100);
    if (!ALLOWED.test(name) || a.size > 12 * 1024 * 1024) continue;
    fs.mkdirSync(folder, { recursive: true });
    fs.writeFileSync(path.join(folder, name), a.content);
    files.push({ name, file: path.relative(dir(), path.join(folder, name)).replace(/\\/g, '/'), size: a.size, text: await attachmentText(name, a.content) || undefined });
  }
  const status = req.status !== 'open' ? 'late' : fw ? 'stored' : 'held';
  db.prepare("INSERT INTO ship_messages (direction, kind, request_id, forwarder_id, address, subject, body, attachments, msg_key, in_reply_to, status) VALUES ('in', 'reply', ?, ?, ?, ?, ?, ?, ?, ?, ?)")
    .run(req.id, fw?.forwarder_id ?? null, sender, subject.slice(0, 300), (mail.text ?? '').slice(0, 60000), JSON.stringify(files), key, (mail.inReplyTo ?? '').replace(/[<>]/g, '') || null, status);
  return status;
}

// a person approves a held message: it joins the request like a reply of a firm that was asked
export function approveHeld(messageId: number, userId: number): { ok: boolean } {
  const m = db.prepare("SELECT * FROM ship_messages WHERE id = ? AND direction = 'in' AND status = 'held'").get(messageId) as { request_id: string; address: string } | undefined;
  if (!m) return { ok: false };
  const req = db.prepare('SELECT status FROM ship_requests WHERE id = ?').get(m.request_id) as { status: string } | undefined;
  if (!req || req.status !== 'open') { db.prepare("UPDATE ship_messages SET status = 'late' WHERE id = ?").run(messageId); return { ok: false }; }
  // a new row in the request's list of firms (a name made from the address), so the quote has somebody to belong to
  const fwId = -Math.abs(messageId);
  db.prepare('INSERT OR IGNORE INTO ship_request_fw (request_id, forwarder_id, forwarder_name, emails, lang, sent_at) VALUES (?, ?, ?, ?, ?, datetime(\'now\'))').run(m.request_id, fwId, m.address, JSON.stringify([m.address]), 'tr');
  db.prepare("UPDATE ship_messages SET status = 'stored', forwarder_id = ?, user_id = ? WHERE id = ?").run(fwId, userId, messageId);
  return { ok: true };
}
export const dismissMessage = (id: number): void => { db.prepare("UPDATE ship_messages SET status = 'dismissed' WHERE id = ? AND direction = 'in' AND status IN ('held', 'failed', 'review')").run(id); };

let running = false;
export interface PollReport { checked: boolean; fetched: number; held: number; read: number; error?: string }

// one round: the mailbox into the database, then the stored replies into quotes. Without an open request the mailbox is not even opened.
export async function pollMailbox(): Promise<PollReport> {
  const report: PollReport = { checked: false, fetched: 0, held: 0, read: 0 };
  if (running || !mailboxReady()) return report;
  running = true;
  try {
    const open = db.prepare("SELECT MIN(created_at) AS first, COUNT(*) AS n FROM ship_requests WHERE status = 'open' AND imported = 0").get() as { first: string | null; n: number };
    if (open.n > 0) {
      const c = shipConfig();
      const client = new ImapFlow({ host: c.imapHost, port: c.imapPort, secure: c.imapPort === 993, auth: { user: c.user, pass: mailboxPassword() }, logger: false, socketTimeout: 60000 });
      try {
        await client.connect();
        const lock = await client.getMailboxLock('INBOX');
        try {
          const since = new Date(Date.parse(`${(open.first ?? '').replace(' ', 'T')}Z`) - 86400000);
          const uids = new Set<number>();
          for (const word of ['Navlun', 'Freight']) for (const u of (await client.search({ since, subject: word }, { uid: true })) || []) uids.add(u);
          report.checked = true;
          for (const uid of [...uids].sort((a, b) => a - b)) {
            try {
              const msg = await client.fetchOne(String(uid), { source: true }, { uid: true });
              if (!msg || !msg.source) continue;
              const r = await ingestRaw(msg.source);
              if (r === 'stored' || r === 'held' || r === 'late') { report.fetched++; if (r === 'held') report.held++; }
              // only after the message is stored is it marked read
              if (r !== 'ignored') await client.messageFlagsAdd(String(uid), ['\\Seen'], { uid: true }).catch(() => undefined);
            } catch (e) { console.error('Reading one shipping message failed:', uid, e); }
          }
        } finally { lock.release(); }
      } finally { await client.logout().catch(() => undefined); }
    }
    report.read = await processStored();
  } catch (e) {
    report.error = String((e as Error).message ?? e).slice(0, 200);
    console.error('Shipping mailbox poll failed:', e);
  } finally { running = false; }
  return report;
}

export function startShipScheduler(): void {
  const tick = () => { void pollMailbox(); };
  setTimeout(tick, 45_000);
  setInterval(tick, 3 * 60_000).unref();
}
