import { db } from '../db/connection';
import { memoTables } from '../db/dataVersion';
import { countryKey } from './countryModel';
import { settingsModel } from './settingsModel';

export interface Distributor {
  id: number;
  country: string;
  name: string;
  phone: string | null;
  email: string | null;
  notes: string | null;
  created_at: string;
  // for the reports (Turquality, customer list)
  sap: string | null;
  status: 'active' | 'passive';
  status_reason: string | null;
  status_date: string | null;
  region: string | null;
  owner: string | null;
}

export interface DistributorInput {
  country: string;
  name: string;
  phone?: string | null;
  email?: string | null;
  notes?: string | null;
  sap?: string | null;
  status?: string | null;
  status_reason?: string | null;
  status_date?: string | null;
  region?: string | null;
  owner?: string | null;
}

const clip = (v: unknown, max: number) => (typeof v === 'string' && v.trim() ? v.trim().slice(0, max) : null);

// The automatic reply to a visitor from a country that has a distributor. Editable on the
// Distributors page; the placeholders are filled in for each customer.
export const DEFAULT_REFERRAL = {
  subject: 'Thank you for visiting TECE{{at_fair}}',
  body: `{{greeting}}

Thank you for visiting our stand{{at_fair}}. It was a pleasure meeting you{{about_company}}.

In {{country}} our products are available through our official distributor, who can help you with colors, sizes, prices and orders:

{{distributor}}
Phone: {{distributor_phone}}
Email: {{distributor_email}}
{{distributor_notes}}

Please contact them directly and mention that we met at {{fair}}. If there is anything else we can do for you, I will be glad to help.

Best wishes`,
};

// asked once for every customer of a list (does this country have a distributor?): read once, kept until the table changes
const keptDistributors = memoTables(['distributors'], () => {
  const rows = db.prepare('SELECT * FROM distributors ORDER BY country, name').all() as unknown as Distributor[];
  const active = new Map<string, Distributor>();
  for (const d of rows) { if (d.status === 'passive') continue; const k = countryKey(d.country); if (!active.has(k)) active.set(k, d); }
  return { rows, active };
});

export const distributorModel = {
  list(): Distributor[] {
    return keptDistributors().rows.map((d) => ({ ...d }));
  },

  find(id: number): Distributor | undefined {
    return db.prepare('SELECT * FROM distributors WHERE id = ?').get(id) as Distributor | undefined;
  },

  // The distributor that handles THIS customer: none when the customer is kept "direct" (no exclusivity, or TECE works them itself).
  forCard(card: { country?: string | null; handling?: string | null }): Distributor | undefined {
    if (card.handling === 'direct') return undefined;
    return this.forCountry(card.country);
  },

  // The distributor for a country (spellings like "UAE" / "USA" are understood).
  forCountry(country: string | null | undefined): Distributor | undefined {
    if (!country || !country.trim()) return undefined;
    const d = keptDistributors().active.get(countryKey(country)); // a passive distributor is not given to a customer
    return d ? { ...d } : undefined;
  },

  create(input: DistributorInput): Distributor {
    const r = db
      .prepare('INSERT INTO distributors (country, name, phone, email, notes, sap, status, status_reason, status_date, region, owner) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
      .run(clip(input.country, 80)!, clip(input.name, 120)!, clip(input.phone, 60), clip(input.email, 200), clip(input.notes, 600), clip(input.sap, 20), input.status === 'passive' ? 'passive' : 'active', clip(input.status_reason, 200), clip(input.status_date, 10), clip(input.region, 80), clip(input.owner, 80));
    return this.find(r.lastInsertRowid as number)!;
  },

  update(id: number, input: DistributorInput): Distributor | undefined {
    if (!this.find(id)) return undefined;
    db.prepare('UPDATE distributors SET country = ?, name = ?, phone = ?, email = ?, notes = ?, sap = ?, status = ?, status_reason = ?, status_date = ?, region = ?, owner = ? WHERE id = ?').run(
      clip(input.country, 80)!, clip(input.name, 120)!, clip(input.phone, 60), clip(input.email, 200), clip(input.notes, 600), clip(input.sap, 20), input.status === 'passive' ? 'passive' : 'active', clip(input.status_reason, 200), clip(input.status_date, 10), clip(input.region, 80), clip(input.owner, 80), id
    );
    return this.find(id);
  },

  delete(id: number): void {
    db.prepare('DELETE FROM distributors WHERE id = ?').run(id);
  },

  referralText(): { subject: string; body: string } {
    return {
      subject: settingsModel.get('distributor_subject') || DEFAULT_REFERRAL.subject,
      body: settingsModel.get('distributor_body') || DEFAULT_REFERRAL.body,
    };
  },

  setReferralText(subject: string, body: string): void {
    settingsModel.set('distributor_subject', subject);
    settingsModel.set('distributor_body', body);
  },

  resetReferralText(): void {
    db.prepare("DELETE FROM app_settings WHERE key IN ('distributor_subject', 'distributor_body')").run();
  },
};
