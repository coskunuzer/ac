// How a customer pays: worked out from the ledger (when each invoice was really paid against its due date), then turned into one level.
//   good   - pays on time
//   watch  - sometimes late, or a first overdue invoice
//   risk   - often late, or something is well past its due date
//   black  - the "black account": pays so late (or nothing is paid) that a new order or a dispatch needs care
// Pure functions only (no database), so the rules are easy to read and to test. perfAnalytics.ts feeds them.

export type RiskLevel = 'good' | 'watch' | 'risk' | 'black';
export const LEVELS: RiskLevel[] = ['good', 'watch', 'risk', 'black'];

export interface PaidInvoice { date: string; amount: number; paidOn: string }
export interface OpenInvoice { date: string; amount: number; daysOver: number }

export interface RiskSettings { graceDays: number; blackDays: number; blackAmount: number }
export const DEFAULT_RISK: RiskSettings = { graceDays: 7, blackDays: 90, blackAmount: 2000 };

export interface RiskInput {
  settled: PaidInvoice[]; // invoices that are paid (with the date the last money came in)
  open: OpenInvoice[]; // what is still unpaid
  terms: number; // payment time in days
  today: string;
  annual: number; // the bigger of last year's and this year's invoicing
  overdue: number; // money past its due date
  oldestOver: number; // days the oldest unpaid invoice is past its due date
  hold: boolean; // no invoice for 12 months and a big debt
}

export interface RiskStats {
  score: number; // 0 (perfect) to 100
  paidN: number; // invoices paid in the last 24 months
  lateN: number; // of them paid later than the payment time plus the grace
  onTimePct: number | null;
  avgLate: number; // days late, weighted by the amount (last 12 months, open overdue invoices included)
  worstLate: number;
  trend: 'better' | 'worse' | 'steady' | null;
  reasons: string[];
}
export interface RiskProfile extends RiskStats { auto: RiskLevel; level: RiskLevel; manual: 'black' | 'clear' | null; manualReason: string | null }
export interface RiskInvoice { date: string; amount: number; late: number; paid: boolean; paidOn: string | null }

const DAY = 86_400_000;
const days = (from: string, to: string) => Math.round((Date.parse(to) - Date.parse(from)) / DAY);
const monthsBack = (today: string, n: number) => {
  const d = new Date(`${today}T00:00:00Z`);
  d.setUTCMonth(d.getUTCMonth() - n);
  return d.toISOString().slice(0, 10);
};
const r0 = (n: number) => Math.round(n);

export function invoiceLines(input: RiskInput): RiskInvoice[] {
  const paid = input.settled.map((s) => ({ date: s.date, amount: s.amount, late: days(s.date, s.paidOn) - input.terms, paid: true, paidOn: s.paidOn as string | null }));
  const open = input.open.filter((o) => o.daysOver > 0).map((o) => ({ date: o.date, amount: o.amount, late: o.daysOver, paid: false, paidOn: null as string | null }));
  return [...paid, ...open].sort((a, b) => b.date.localeCompare(a.date));
}

export function riskStats(input: RiskInput, cfg: RiskSettings = DEFAULT_RISK): RiskStats {
  const from24 = monthsBack(input.today, 24);
  const from12 = monthsBack(input.today, 12);
  const from6 = monthsBack(input.today, 6);
  const lines = invoiceLines(input).filter((l) => l.date >= from24);
  const paid = lines.filter((l) => l.paid);
  const lateN = paid.filter((l) => l.late > cfg.graceDays).length;
  const onTimePct = paid.length ? ((paid.length - lateN) / paid.length) * 100 : null;
  const weighted = (list: RiskInvoice[]) => {
    const total = list.reduce((s, l) => s + l.amount, 0);
    return total > 0 ? list.reduce((s, l) => s + l.amount * Math.max(0, l.late), 0) / total : 0;
  };
  const last12 = lines.filter((l) => l.date >= from12);
  const avgLate = weighted(last12);
  const worstLate = Math.max(0, ...lines.map((l) => l.late));
  const recent = lines.filter((l) => l.date >= from6);
  const older = lines.filter((l) => l.date < from6 && l.date >= monthsBack(input.today, 18));
  const trend: RiskStats['trend'] = recent.length >= 2 && older.length >= 2 ? (weighted(recent) - weighted(older) > 10 ? 'worse' : weighted(older) - weighted(recent) > 10 ? 'better' : 'steady') : null;

  const delay = Math.min(45, avgLate * 0.75);
  const aged = Math.min(30, input.oldestOver / 3);
  const share = input.overdue > 0 ? (input.annual > 0 ? Math.min(10, (input.overdue / input.annual) * 40) : 10) : 0;
  const freq = onTimePct === null ? 0 : ((100 - onTimePct) / 100) * 15;
  const score = Math.max(0, Math.min(100, r0(delay + aged + share + freq)));

  const reasons: string[] = [];
  if (input.oldestOver > 0) reasons.push(`The oldest unpaid invoice is ${input.oldestOver} days past its due date.`);
  if (paid.length) reasons.push(`${lateN} of ${paid.length} invoices paid in the last 24 months were paid late (${r0(onTimePct ?? 0)}% on time).`);
  if (avgLate >= 3) reasons.push(`On average the money comes ${r0(avgLate)} days after the due date (weighted by the amount, last 12 months).`);
  if (worstLate > cfg.graceDays) reasons.push(`The worst case was ${worstLate} days late.`);
  if (trend === 'worse') reasons.push('Payments have become slower in the last 6 months.');
  if (trend === 'better') reasons.push('Payments have become faster in the last 6 months.');
  if (input.hold) reasons.push('No invoice for 12 months and a big debt (debt hold).');
  if (!reasons.length) reasons.push('No late payment found.');
  return { score, paidN: paid.length, lateN, onTimePct: onTimePct === null ? null : r0(onTimePct), avgLate: r0(avgLate), worstLate: r0(worstLate), trend, reasons };
}

export function autoLevel(input: RiskInput, st: RiskStats, cfg: RiskSettings = DEFAULT_RISK): RiskLevel {
  if (input.hold) return 'black';
  // black = money is late NOW (a habit alone is only 'risk': nothing is overdue today)
  const meaningful = input.overdue >= cfg.blackAmount / 4;
  if (meaningful && (st.score >= 70 || (input.oldestOver >= cfg.blackDays && input.overdue >= cfg.blackAmount))) return 'black';
  if (st.score >= 45 || input.oldestOver >= 60) return 'risk';
  // too little to judge: a customer with one or two invoices and nothing overdue is fine
  if (st.paidN + input.open.filter((o) => o.daysOver > 0).length < 2 && input.overdue <= 0) return 'good';
  if (st.score >= 20 || input.oldestOver > 30 || st.avgLate >= 10) return 'watch';
  return 'good';
}

export function riskProfile(input: RiskInput, manual: { mode: 'black' | 'clear'; reason: string | null } | null, cfg: RiskSettings = DEFAULT_RISK): RiskProfile {
  const st = riskStats(input, cfg);
  const auto = autoLevel(input, st, cfg);
  const level: RiskLevel = manual?.mode === 'black' ? 'black' : manual?.mode === 'clear' ? 'good' : auto;
  return { ...st, auto, level, manual: manual?.mode ?? null, manualReason: manual?.reason ?? null };
}

// what to do about it, in plain rules (the AI writes a better one when it can)
export const RULE_ADVICE: Record<RiskLevel, string> = {
  good: '',
  watch: 'Remind the customer of the due dates when you speak; check the account before a big order.',
  risk: 'Ask for the overdue invoices to be paid before the next dispatch; think about a part advance for the next order.',
  black: 'Do not accept a new order or release a dispatch until the overdue amount is paid or an advance is received. Check with finance first.',
};
