import type { Value } from './formula';

// Formats a cell value the way Excel's number-format codes do - the subset the
// tece price workbook uses: digit placeholders, thousands separators, quoted and
// escaped literals, [$€-1]-style currency, percent, and date/time codes.

export type NumberStyle = 'eu' | 'en';

export interface FormatOptions {
  // 'eu' prints 1.234,56 (what the price workbook shows on the tece PCs); 'en' prints 1,234.56.
  style: NumberStyle;
  // Replaces the € in a currency token (used for USD offers).
  currencySymbol?: string;
}

type Token = { kind: 'lit'; text: string } | { kind: 'core'; text: string } | { kind: 'date'; text: string } | { kind: 'percent' };

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

function splitSections(fmt: string): string[] {
  const out: string[] = [];
  let cur = '';
  let quote = false;
  let bracket = false;
  for (let i = 0; i < fmt.length; i++) {
    const ch = fmt[i];
    if (ch === '\\' && !quote) { cur += ch + (fmt[++i] ?? ''); continue; }
    if (ch === '"') quote = !quote;
    else if (!quote && ch === '[') bracket = true;
    else if (!quote && ch === ']') bracket = false;
    if (ch === ';' && !quote && !bracket) { out.push(cur); cur = ''; continue; }
    cur += ch;
  }
  out.push(cur);
  return out;
}

function tokenize(section: string, opts: FormatOptions): Token[] {
  const tokens: Token[] = [];
  const pushLit = (text: string) => {
    const last = tokens[tokens.length - 1];
    if (last && last.kind === 'lit') last.text += text;
    else tokens.push({ kind: 'lit', text });
  };
  let i = 0;
  while (i < section.length) {
    const ch = section[i];
    if (ch === '"') {
      const end = section.indexOf('"', i + 1);
      pushLit(section.slice(i + 1, end < 0 ? undefined : end));
      i = end < 0 ? section.length : end + 1;
    } else if (ch === '\\') {
      pushLit(section[i + 1] ?? '');
      i += 2;
    } else if (ch === '_') {
      pushLit(' ');
      i += 2;
    } else if (ch === '*') {
      i += 2;
    } else if (ch === '[') {
      const end = section.indexOf(']', i);
      const inner = section.slice(i + 1, end < 0 ? undefined : end);
      i = end < 0 ? section.length : end + 1;
      if (inner.startsWith('$')) {
        const symbol = inner.slice(1).split('-')[0];
        if (symbol) pushLit(symbol === '€' && opts.currencySymbol ? opts.currencySymbol : symbol);
      }
      // colour / condition / locale-only brackets carry no printed text
    } else if (ch === '%') {
      tokens.push({ kind: 'percent' });
      i++;
    } else if ('0#?.,'.includes(ch)) {
      let j = i;
      while (j < section.length && '0#?.,'.includes(section[j])) j++;
      tokens.push({ kind: 'core', text: section.slice(i, j) });
      i = j;
    } else if (/[ymdhsAP]/i.test(ch)) {
      let j = i;
      if (/am\/pm|a\/p/i.test(section.slice(i, i + 5))) {
        const m = /^(am\/pm|a\/p)/i.exec(section.slice(i))!;
        tokens.push({ kind: 'date', text: m[0] });
        i += m[0].length;
        continue;
      }
      while (j < section.length && section[j].toLowerCase() === ch.toLowerCase()) j++;
      tokens.push({ kind: 'date', text: section.slice(i, j) });
      i = j;
    } else {
      pushLit(ch);
      i++;
    }
  }
  return tokens;
}

function group(intDigits: string, sep: string): string {
  return intDigits.replace(/\B(?=(\d{3})+(?!\d))/g, sep);
}

function formatCore(value: number, core: string, opts: FormatOptions): string {
  const dec = opts.style === 'eu' ? ',' : '.';
  const thou = opts.style === 'eu' ? '.' : ',';
  const dot = core.indexOf('.');
  const intPart = dot < 0 ? core : core.slice(0, dot);
  const decPart = dot < 0 ? '' : core.slice(dot + 1);
  const decimals = (decPart.match(/[0#?]/g) ?? []).length;
  const minDecimals = (decPart.match(/0/g) ?? []).length;
  const useThousands = /,/.test(intPart) && /[0#?]/.test(intPart);
  const minInt = (intPart.match(/0/g) ?? []).length;

  const abs = Math.abs(value);
  let fixed = abs.toFixed(decimals);
  let [ip, dp = ''] = fixed.split('.');
  while (dp.length > minDecimals && dp.endsWith('0')) dp = dp.slice(0, -1);
  if (ip.length < minInt) ip = ip.padStart(minInt, '0');
  if (ip === '0' && minInt === 0 && decimals > 0 && dp.length) ip = '';
  if (useThousands) ip = group(ip, thou);
  fixed = dp.length ? `${ip}${dec}${dp}` : ip;
  return fixed;
}

function formatDate(serial: number, tokens: Token[]): string {
  // Excel's day 1 is 1900-01-01 and it counts a non-existent 1900-02-29, hence 1899-12-30.
  const ms = Math.round((serial - 25569) * 86400 * 1000);
  const d = new Date(ms);
  const Y = d.getUTCFullYear(), M = d.getUTCMonth(), D = d.getUTCDate(), W = d.getUTCDay();
  const h = d.getUTCHours(), mi = d.getUTCMinutes(), s = d.getUTCSeconds();
  const has12 = tokens.some((t) => t.kind === 'date' && /am\/pm|a\/p/i.test(t.text));
  let out = '';
  tokens.forEach((t, idx) => {
    if (t.kind === 'lit') { out += t.text; return; }
    if (t.kind !== 'date') return;
    const x = t.text.toLowerCase();
    if (/am\/pm|a\/p/.test(x)) out += h < 12 ? 'AM' : 'PM';
    else if (x[0] === 'y') out += x.length <= 2 ? String(Y % 100).padStart(2, '0') : String(Y);
    else if (x[0] === 'd') out += x.length >= 4 ? DAYS[W] : x.length === 3 ? DAYS[W].slice(0, 3) : x.length === 2 ? String(D).padStart(2, '0') : String(D);
    else if (x[0] === 'h') { const hh = has12 ? (h % 12 || 12) : h; out += x.length >= 2 ? String(hh).padStart(2, '0') : String(hh); }
    else if (x[0] === 's') out += x.length >= 2 ? String(s).padStart(2, '0') : String(s);
    else if (x[0] === 'm') {
      // "m" is minutes when it follows hours or precedes seconds
      const prev = tokens.slice(0, idx).reverse().find((q) => q.kind === 'date');
      const next = tokens.slice(idx + 1).find((q) => q.kind === 'date');
      const asMinutes = (prev && /^h/i.test(prev.text)) || (next && /^s/i.test(next.text));
      if (asMinutes) out += x.length >= 2 ? String(mi).padStart(2, '0') : String(mi);
      else out += x.length >= 4 ? MONTHS[M] : x.length === 3 ? MONTHS[M].slice(0, 3) : x.length === 2 ? String(M + 1).padStart(2, '0') : String(M + 1);
    }
  });
  return out;
}

function general(value: number, opts: FormatOptions): string {
  if (Number.isInteger(value)) return String(value);
  const trimmed = Number(value.toPrecision(10));
  const text = Math.abs(trimmed) < 1e-4 || Math.abs(trimmed) >= 1e11 ? trimmed.toExponential() : String(trimmed);
  return opts.style === 'eu' ? text.replace('.', ',') : text;
}

export function formatCell(value: Value, z: string | undefined, opts: FormatOptions): string {
  if (value === null || value === undefined) return '';
  if (typeof value === 'boolean') return value ? 'TRUE' : 'FALSE';
  if (typeof value === 'string') return value;
  if (!Number.isFinite(value)) return '';
  if (!z || z === 'General') return general(value, opts);

  const sections = splitSections(z);
  let section = sections[0];
  let negative = false;
  if (value < 0 && sections.length > 1) section = sections[1];
  else if (value < 0) negative = true;
  if (value === 0 && sections.length > 2) section = sections[2];

  const tokens = tokenize(section, opts);
  const hasCore = tokens.some((t) => t.kind === 'core');
  const hasDate = tokens.some((t) => t.kind === 'date');
  if (hasDate && !hasCore) return formatDate(value, tokens);
  if (!hasCore) return tokens.map((t) => (t.kind === 'lit' ? t.text : '')).join('') || general(value, opts);

  const scaled = tokens.some((t) => t.kind === 'percent') ? value * 100 : value;
  let out = '';
  for (const t of tokens) {
    if (t.kind === 'lit') out += t.text;
    else if (t.kind === 'percent') out += '%';
    else if (t.kind === 'core') out += formatCore(scaled, t.text, opts);
  }
  return negative && !/^-/.test(out) && scaled < 0 ? `-${out}` : out;
}
