import { Router } from 'express';
import { requireAuth, requireAdmin } from '../middleware/auth';
import { DEFAULT_REFERRAL, distributorModel, type DistributorInput } from '../models/distributorModel';

const router = Router();
router.use(requireAuth);

// Everybody can see who the distributors are (the Review page tells staff when a country has one).
router.get('/', (_req, res) => {
  res.json({ distributors: distributorModel.list(), referral: distributorModel.referralText(), defaultReferral: DEFAULT_REFERRAL });
});

router.get('/for', (req, res) => {
  res.json(distributorModel.forCountry(String(req.query.country ?? '')) ?? null);
});

function read(body: Record<string, unknown> | undefined): DistributorInput | { error: string } {
  const country = String(body?.country ?? '').trim();
  const name = String(body?.name ?? '').trim();
  if (!country) return { error: 'Choose the country.' };
  if (!name) return { error: 'Write the name of the distributor.' };
  const email = String(body?.email ?? '').trim();
  if (email && !/^[^\s@,;]+@[^\s@,;]+\.[^\s@,;]+$/.test(email)) return { error: 'That e-mail address does not look right.' };
  const status = String(body?.status ?? '') === 'passive' ? 'passive' : 'active';
  const date = String(body?.status_date ?? '').slice(0, 10);
  return {
    country, name, phone: String(body?.phone ?? ''), email, notes: String(body?.notes ?? ''), sap: String(body?.sap ?? '').replace(/\D/g, ''), status,
    status_reason: status === 'passive' ? String(body?.status_reason ?? '') : '', status_date: status === 'passive' ? (/^\d{4}-\d{2}-\d{2}$/.test(date) ? date : new Date().toISOString().slice(0, 10)) : '',
    region: String(body?.region ?? ''), owner: String(body?.owner ?? ''),
  };
}

router.post('/', requireAdmin, (req, res) => {
  const d = read(req.body);
  if ('error' in d) return res.status(400).json(d);
  res.status(201).json(distributorModel.create(d));
});

router.put('/:id', requireAdmin, (req, res) => {
  const id = parseInt(String(req.params.id), 10);
  const d = read(req.body);
  if ('error' in d) return res.status(400).json(d);
  const updated = distributorModel.update(id, d);
  if (!updated) return res.status(404).json({ error: 'Not found' });
  res.json(updated);
});

router.delete('/:id', requireAdmin, (req, res) => {
  distributorModel.delete(parseInt(String(req.params.id), 10));
  res.json({ ok: true });
});

// The automatic reply text (subject and message).
router.put('/referral/text', requireAdmin, (req, res) => {
  const subject = String(req.body?.subject ?? '').trim().slice(0, 200);
  const body = String(req.body?.body ?? '').replace(/\r\n/g, '\n').trim().slice(0, 6000);
  if (!subject || !body) return res.status(400).json({ error: 'The subject and the message cannot be empty.' });
  distributorModel.setReferralText(subject, body);
  res.json(distributorModel.referralText());
});

router.post('/referral/reset', requireAdmin, (_req, res) => {
  distributorModel.resetReferralText();
  res.json(distributorModel.referralText());
});

export default router;
