// What is kept in memory, and when it is dropped.
//
// Heavy sums that are read far more often than data is written (every customer's account, the buying rhythm, the Today list) and small lists
// that are read hundreds of times while one page is put together (the country list, the distributors, a person's extra access) are kept in
// memory. The database wrapper (db/slowLog.ts) reports every write here THE MOMENT IT HAPPENS, with the table it went to - so what is kept is
// never older than the data, also inside the request that changed it. A write whose reach is not known for sure (a delete can cascade, a script,
// a rollback) drops everything.
//
// Before, the whole memory was dropped at the end of every request that was not a plain read - also the usage ping every browser tab sends twice
// a minute and the click log. With five people at work nothing was ever kept, and the account sums (the whole ledger) were added up again for
// almost every page: the 4 to 18 second waits in the usage log.

// tables that only log what people do: a write to them never changes a sum or a list that is kept
const LOG_ONLY = new Set(['ux_events', 'app_time', 'user_seen', 'ai_calls', 'ai_usage', 'audit_log', 'translations', 'queue_log', 'perm_log', 'intel_cache', 'explore_briefs', 'schema_migrations', 'sqlite_stat1']);

const tableVersions = new Map<string, number>();
let wideVersion = 0; // writes with an unknown reach
let total = 0; // every write that counts (not the log-only tables)

export const noteTableWrite = (table: string | null, wide: boolean): void => {
  if (wide || !table) { wideVersion += 1; total += 1; return; }
  if (LOG_ONLY.has(table)) return;
  tableVersions.set(table, (tableVersions.get(table) ?? 0) + 1);
  total += 1;
};
// something changed that the database wrapper cannot see (a restored backup, a file that sums are made from)
export const dropAllKept = (): void => { wideVersion += 1; total += 1; };

// Called at the end of every request that is not a plain read (app.ts). It used to drop everything that is kept; the writes are now noticed
// where they happen (see above), so a request that only logs a click or a ping no longer costs everybody their sums. Kept so nothing that calls it breaks.
export const bumpData = (): void => { /* writes are reported by the database wrapper */ };

const stampOf = (tables: readonly string[]): string => {
  let s = String(wideVersion);
  for (const t of tables) s += `.${tableVersions.get(t) ?? 0}`;
  return s;
};
// goes up with every write, except writes to the tables named (for a sum that is known not to read them)
const versionExcept = (ignored: readonly string[]): number => {
  let v = total;
  for (const t of ignored) v -= tableVersions.get(t) ?? 0;
  return v;
};
// the day in Istanbul; asked thousands of times while a list is made, so the answer is kept for a second
let dayAt = 0; let dayIs = '';
const istanbulDay = (): string => {
  const now = Date.now();
  if (now - dayAt > 1000) { dayIs = new Date(now).toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' }); dayAt = now; }
  return dayIs;
};

// A heavy sum for each key (a person): kept until something it could be made from is written, the day changes (sums count days), or it is
// `maxAgeMs` old. `ignored` = tables this sum is known not to read (what people log all day: notes, to-dos ...), so those writes do not drop it.
// `mark` = for an ignored table of which the sum reads only a small part: a fingerprint of that part (the sum is kept while it stays the same).
export function memoByData<T>(kept: Map<number | string, { v: number; at: number; day?: string; mark?: string; data: T }>, key: number | string, compute: () => T, maxAgeMs = 300_000, ignored: readonly string[] = [], mark?: () => string): T {
  const v = versionExcept(ignored);
  const day = istanbulDay();
  const m = mark ? mark() : '';
  const hit = kept.get(key);
  if (hit && hit.v === v && hit.day === day && (hit.mark ?? '') === m && Date.now() - hit.at < maxAgeMs) return hit.data;
  const data = compute();
  // something written while it was made (by this very sum, or by a request that ran in between an await): not kept
  if (versionExcept(ignored) === v && (mark ? mark() : '') === m) {
    if (kept.size > 200) kept.clear();
    kept.set(key, { v, at: Date.now(), day, mark: m, data });
  } else kept.delete(key);
  return data;
}

// one value, worked out again after any of these tables was written to
export function memoTables<T>(tables: readonly string[], compute: () => T): () => T {
  let stamp = '';
  let data: T | undefined;
  let have = false;
  return () => {
    const now = stampOf(tables);
    if (!have || now !== stamp) { data = compute(); stamp = now; have = true; }
    return data as T;
  };
}
// the same for a value per key (a person, a country): at most `max` keys are kept
export function memoTablesBy<K, T>(tables: readonly string[], compute: (key: K) => T, max = 500): (key: K) => T {
  let stamp = '';
  const kept = new Map<K, T>();
  return (key: K) => {
    const now = stampOf(tables);
    if (now !== stamp) { kept.clear(); stamp = now; }
    if (kept.has(key)) return kept.get(key) as T;
    const data = compute(key);
    if (stampOf(tables) === now) { if (kept.size >= max) kept.clear(); kept.set(key, data); }
    return data;
  };
}
