import { Router } from 'express';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { radar, silence, unsilence } from '../services/radar';

const router = Router();
router.use(requireAuth);

// everything that matters today, for the side tab that is on every page
router.get('/', (req: AuthedRequest, res) => {
  try { res.json(radar(req.user!)); } catch (err) { console.error('Radar failed:', err); res.status(500).json({ error: 'The radar could not be made.' }); }
});

// silence one line: for a day, a week, a month or for good (days = null); bring it back with DELETE
router.post('/silence', (req: AuthedRequest, res) => {
  const key = String(req.body?.key ?? '').trim();
  if (!/^[a-z]+:.{1,100}$/.test(key)) return res.status(400).json({ error: 'Nothing to silence.' });
  const d = req.body?.days === null || req.body?.days === undefined ? null : Number(req.body.days);
  silence(req.user!.id, key, d !== null && Number.isFinite(d) && d > 0 ? Math.min(365, Math.round(d)) : null, String(req.body?.label ?? key));
  res.json({ ok: true });
});
router.delete('/silence', (req: AuthedRequest, res) => {
  unsilence(req.user!.id, String(req.body?.key ?? req.query.key ?? ''));
  res.json({ ok: true });
});

export default router;
