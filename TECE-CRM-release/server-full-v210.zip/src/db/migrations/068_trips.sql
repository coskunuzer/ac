-- Trips: a plan to visit customers (countries, days, stops), with the place of each customer on the map.

-- Where a customer is (the city is on the customer already; this is the point on the map) and how we found it:
-- 'city list' (a major city of the bundled list), 'map search' (the address or the city looked up), 'ai' (the AI found the address first),
-- 'manual' (a person set it), 'none' (looked for, nothing found: not asked again unless a person asks).
ALTER TABLE cards ADD COLUMN lat REAL;
ALTER TABLE cards ADD COLUMN lon REAL;
ALTER TABLE cards ADD COLUMN geo_source TEXT;
ALTER TABLE cards ADD COLUMN geo_place TEXT;

CREATE TABLE IF NOT EXISTS trips (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  start_date TEXT,
  end_date TEXT,
  note TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_trips_user ON trips (user_id);

CREATE TABLE IF NOT EXISTS trip_stops (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  trip_id INTEGER NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
  card_id INTEGER NOT NULL,
  day_no INTEGER,            -- 1 = the first day of the trip; NULL = not on a day yet
  sort INTEGER NOT NULL DEFAULT 0,
  visit_time TEXT,           -- the local time of the visit ("10:30"), where the customer is
  note TEXT,
  messaged_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_trip_stops_trip ON trip_stops (trip_id, day_no, sort);
CREATE UNIQUE INDEX IF NOT EXISTS idx_trip_stops_card ON trip_stops (trip_id, card_id);
