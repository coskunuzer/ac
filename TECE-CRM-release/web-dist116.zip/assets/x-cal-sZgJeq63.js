// Drag and drop in the calendar: a to-do or a meeting is dragged onto another day. The chips carry data-todo / data-ev (set by the calendar
// page and by the "My work time" list); the day cells are the .cal-day boxes whose aria-label is the day.
import { api, ApiError, toast } from "./x-kit-br2FMvy0.js";

const MIME = "application/x-tece-cal";
const isTr = () => document.documentElement.lang === "tr";
const nice = (iso) => new Intl.DateTimeFormat(isTr() ? "tr-TR" : "en-GB", { weekday: "short", day: "numeric", month: "short", timeZone: "UTC" }).format(new Date(iso + "T12:00:00Z"));
// this file is not a screen of its own (no translator at hand): its four messages in both languages
const say = (en, tr) => (isTr() ? tr : en);
let dragging = null; // {kind, id, day, label}

// refresh: asks the calendar to read its to-dos and meetings again. Returns the function that switches it all off.
export function calendarDnD(refresh) {
  const cellOf = (el) => (el && el.closest ? el.closest(".cal-day") : null);
  let over = null;
  const mark = (cell) => {
    if (over === cell) return;
    if (over) over.removeAttribute("data-drop");
    over = cell;
    if (over) over.setAttribute("data-drop", "");
  };
  const start = (e) => {
    const chip = e.target && e.target.closest ? e.target.closest("[data-todo],[data-ev],[data-meeting]") : null;
    if (!chip || !e.dataTransfer) return;
    const kind = chip.hasAttribute("data-todo") ? "todo" : chip.hasAttribute("data-ev") ? "ev" : "meeting";
    dragging = { kind, id: chip.getAttribute("data-" + kind), day: chip.getAttribute("data-day") || "", label: (chip.textContent || "").replace(/^☐\s*/, "").trim().slice(0, 60) };
    e.dataTransfer.effectAllowed = "move";
    try { e.dataTransfer.setData(MIME, JSON.stringify(dragging)); e.dataTransfer.setData("text/plain", dragging.label); } catch { /* some browsers refuse a custom type */ }
    // after the browser has taken its picture of what is dragged (changing it now would stop the drag in some browsers)
    setTimeout(() => { if (dragging) { chip.setAttribute("data-dragging", ""); document.body.setAttribute("data-cal-drag", kind); } }, 0);
  };
  const end = () => {
    document.querySelectorAll("[data-dragging]").forEach((el) => el.removeAttribute("data-dragging"));
    document.body.removeAttribute("data-cal-drag");
    mark(null);
    dragging = null;
  };
  const dragOver = (e) => {
    if (!dragging) return;
    const cell = cellOf(e.target);
    if (!cell) { mark(null); return; }
    e.preventDefault();
    if (e.dataTransfer) e.dataTransfer.dropEffect = "move";
    mark(cell);
  };
  async function move(item, to) {
    if (item.kind === "todo") await api.patch(`/todos/${item.id}`, { dueDate: to });
    else if (item.kind === "ev") await api.post(`/calendar/events/${encodeURIComponent(item.id)}/move`, { date: to });
    else await api.post(`/calendar/meetings/${item.id}/move`, { date: to });
  }
  const drop = async (e) => {
    const cell = cellOf(e.target);
    const item = dragging;
    if (!cell || !item) return;
    e.preventDefault();
    const to = cell.getAttribute("aria-label") || "";
    end();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(to) || to === item.day) return;
    cell.setAttribute("data-landed", "");
    setTimeout(() => cell.removeAttribute("data-landed"), 900);
    try {
      await move(item, to);
      refresh();
      window.dispatchEvent(new Event("tece:logged"));
      const back = item.day && /^\d{4}/.test(item.day) ? async () => { try { await move(item, item.day); refresh(); } catch { toast(say("Could not move it back", "Geri taşınamadı"), "bad"); } } : null;
      toast(item.kind === "todo" ? say("To-do moved to " + nice(to), "İş " + nice(to) + " gününe taşındı") : say("Meeting moved to " + nice(to), "Toplantı " + nice(to) + " gününe taşındı"), "good", back ? { label: say("Undo", "Geri al"), run: back } : null);
    } catch (err) {
      toast(err instanceof ApiError && err.message ? err.message : say("Could not move it", "Taşınamadı"), "bad");
      refresh();
    }
  };
  document.addEventListener("dragstart", start);
  document.addEventListener("dragend", end);
  document.addEventListener("dragover", dragOver);
  document.addEventListener("drop", drop);
  return () => {
    document.removeEventListener("dragstart", start);
    document.removeEventListener("dragend", end);
    document.removeEventListener("dragover", dragOver);
    document.removeEventListener("drop", drop);
    end();
  };
}
