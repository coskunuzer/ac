-- Version 1.94: the SAP customer master (country, incoterm, payment time of every account), the revenue targets and forecasts,
-- and the marketing budget expenses (business trips, fairs, ads ...) that the accounting invoices are entered into.

-- the SAP customer master (ZSD customer list): one row per account, replaced by every upload
CREATE TABLE IF NOT EXISTS intel_master (
  code TEXT PRIMARY KEY, name TEXT, iso TEXT, country TEXT, city TEXT, province TEXT,
  incoterm TEXT, incoterm_place TEXT, pay_code TEXT, pay_days INTEGER, email TEXT, phone TEXT, channel TEXT,
  blocked INTEGER NOT NULL DEFAULT 0
);

-- Revenue targets. period is a month (YYYY-MM) or a whole year (YYYY); user_id 0 = the company, else the sales person it is given to.
CREATE TABLE IF NOT EXISTS sales_targets (
  period TEXT NOT NULL, user_id INTEGER NOT NULL DEFAULT 0, amount_eur REAL NOT NULL,
  set_by INTEGER, updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (period, user_id)
);
-- append-only: every change of a target
CREATE TABLE IF NOT EXISTS sales_targets_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT, period TEXT NOT NULL, user_id INTEGER NOT NULL, before_eur REAL, after_eur REAL,
  by_user INTEGER, at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- What a sales person expects to invoice in a month ("this month I will bring this much"), typed at the start of the month.
CREATE TABLE IF NOT EXISTS sales_forecasts (
  user_id INTEGER NOT NULL, ym TEXT NOT NULL, amount_eur REAL NOT NULL, note TEXT,
  first_at TEXT NOT NULL DEFAULT (datetime('now')), updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, ym)
);
-- append-only: every time a forecast was typed or changed (so the first one can always be found)
CREATE TABLE IF NOT EXISTS sales_forecasts_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, ym TEXT NOT NULL, amount_eur REAL NOT NULL, note TEXT,
  by_user INTEGER, at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Marketing budget: the invoices that come from accounting, entered as expenses (grp / item = the lines of the marketing budget sheet).
CREATE TABLE IF NOT EXISTS budget_expenses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  spent_on TEXT NOT NULL,                       -- the invoice date (YYYY-MM-DD): the month it counts in
  market TEXT NOT NULL DEFAULT 'export',        -- export | domestic
  grp TEXT NOT NULL, item TEXT NOT NULL,
  supplier TEXT, invoice_no TEXT, description TEXT,
  currency TEXT NOT NULL DEFAULT 'TRY', amount REAL NOT NULL,
  rate REAL,                                    -- TL per 1 EUR on the day
  amount_try REAL NOT NULL, amount_eur REAL NOT NULL,
  trip_id INTEGER, card_id INTEGER, exhibition_id INTEGER, country TEXT,
  file_path TEXT, file_name TEXT,
  entered_by INTEGER NOT NULL, created_at TEXT NOT NULL DEFAULT (datetime('now')), updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_budget_exp_date ON budget_expenses (spent_on);
CREATE INDEX IF NOT EXISTS idx_budget_exp_trip ON budget_expenses (trip_id);
-- append-only: who entered, changed or removed which invoice
CREATE TABLE IF NOT EXISTS budget_expense_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT, expense_id INTEGER NOT NULL, action TEXT NOT NULL, by_user INTEGER, before TEXT, after TEXT,
  at TEXT NOT NULL DEFAULT (datetime('now'))
);
-- the yearly budget per line and month, in EUR (the "Hedef" columns of the marketing budget sheet)
CREATE TABLE IF NOT EXISTS budget_targets (
  year INTEGER NOT NULL, market TEXT NOT NULL, grp TEXT NOT NULL, item TEXT NOT NULL, month INTEGER NOT NULL, amount_eur REAL NOT NULL,
  PRIMARY KEY (year, market, grp, item, month)
);
-- TL per EUR for each month (used when an invoice is in one currency and the report in the other)
CREATE TABLE IF NOT EXISTS budget_rates (
  ym TEXT PRIMARY KEY, try_per_eur REAL NOT NULL, usd_per_eur REAL
);

-- distributors: what the Turquality and the customer list reports ask for (SAP number, active or passive and why, the region, the TECE person)
ALTER TABLE distributors ADD COLUMN sap TEXT;
ALTER TABLE distributors ADD COLUMN status TEXT NOT NULL DEFAULT 'active';
ALTER TABLE distributors ADD COLUMN status_reason TEXT;
ALTER TABLE distributors ADD COLUMN status_date TEXT;
ALTER TABLE distributors ADD COLUMN region TEXT;
ALTER TABLE distributors ADD COLUMN owner TEXT;

-- the accounting account codes (760.xx "Satış ve Dağıtım Gider") that belong to a line of the marketing budget: an invoice with the code lands on the right line by itself
CREATE TABLE IF NOT EXISTS budget_accounts (
  code TEXT NOT NULL, name TEXT NOT NULL, market TEXT NOT NULL, grp TEXT NOT NULL, item TEXT NOT NULL,
  PRIMARY KEY (code, name)
);
INSERT OR IGNORE INTO budget_accounts (code, name, market, grp, item) VALUES
  ('760.30.10.10', 'Reklam Giderleri', 'domestic', 'İlanlar', 'Dergi İlanı'),
  ('760.30.10.11', 'Yurtdışı Reklam Giderleri', 'export', 'İlanlar', 'Dergi İlanı'),
  ('760.30.10.30', 'Misafir Ağırlama Gideri', 'domestic', 'Müşterilere Özel Çalışmalar', 'Konuk Ağırlama'),
  ('760.30.10.90', 'Fuar Diğer Sat.Teşvik ve Tan.Giderleri – INTERZUM (Almanya)', 'export', 'Fuarlar Giderleri', 'Fuar Diğer Giderler (gümrük, resmi prosedür vs)'),
  ('760.30.10.90', 'Fuar Diğer Sat.Teşvik ve Tan.Giderleri – SICAM (İtalya)', 'export', 'Fuarlar Giderleri', 'Fuar Diğer Giderler (gümrük, resmi prosedür vs)'),
  ('760.30.10.90', 'Fuar Diğer Sat.Teşvik ve Tan.Giderleri – INTERMOB (Türkiye)', 'domestic', 'Fuarlar Giderleri', 'Fuar Diğer Giderler (gümrük, resmi prosedür vs)'),
  ('760.30.50.20', 'Yurt İçi Yolluk ve Seyahat Giderleri', 'domestic', 'Müşterilere Özel Çalışmalar', 'Müşteri Ziyaretleri'),
  ('760.30.50.30', 'Yurtdışı Yolluk ve Seyahat Giderleri', 'export', 'Müşterilere Özel Çalışmalar', 'Müşteri Ziyaretleri'),
  ('760.30.50.40', 'Yurt İçi Konaklama Giderleri', 'domestic', 'Müşterilere Özel Çalışmalar', 'Müşteri Ziyaretleri'),
  ('760.30.50.20', 'Yurt Dışı Yolluk ve Seyahat Giderleri', 'export', 'Müşterilere Özel Çalışmalar', 'Müşteri Ziyaretleri');
ALTER TABLE budget_expenses ADD COLUMN account_code TEXT;
ALTER TABLE budget_expenses ADD COLUMN fair TEXT;
