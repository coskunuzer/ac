-- Who works this customer: NULL = by country (the distributor when the country has one), 'distributor' = forward to the distributor, 'direct' = TECE works it itself.
ALTER TABLE cards ADD COLUMN handling TEXT;
-- 1 when the person's own rating was not given by the person: it is the AI's rating copied in, so it follows the AI until the person rates.
ALTER TABLE cards ADD COLUMN rate_auto INTEGER NOT NULL DEFAULT 0;
UPDATE cards SET rate = ai_rate, rate_auto = 1 WHERE rate IS NULL AND ai_rate_source = 'ai' AND ai_rate IS NOT NULL;
