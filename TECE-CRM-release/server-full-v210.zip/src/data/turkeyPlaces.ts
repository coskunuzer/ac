// The 81 provinces of Turkey, and the districts of the big ones, so a customer written down as
// "BAŞAKŞEHİR" or "Nilüfer" is filed under İstanbul / Bursa.

export const PROVINCES = [
  'Adana', 'Adıyaman', 'Afyonkarahisar', 'Ağrı', 'Aksaray', 'Amasya', 'Ankara', 'Antalya', 'Ardahan', 'Artvin', 'Aydın',
  'Balıkesir', 'Bartın', 'Batman', 'Bayburt', 'Bilecik', 'Bingöl', 'Bitlis', 'Bolu', 'Burdur', 'Bursa',
  'Çanakkale', 'Çankırı', 'Çorum', 'Denizli', 'Diyarbakır', 'Düzce', 'Edirne', 'Elazığ', 'Erzincan', 'Erzurum', 'Eskişehir',
  'Gaziantep', 'Giresun', 'Gümüşhane', 'Hakkâri', 'Hatay', 'Iğdır', 'Isparta', 'İstanbul', 'İzmir',
  'Kahramanmaraş', 'Karabük', 'Karaman', 'Kars', 'Kastamonu', 'Kayseri', 'Kırıkkale', 'Kırklareli', 'Kırşehir', 'Kilis', 'Kocaeli', 'Konya', 'Kütahya',
  'Malatya', 'Manisa', 'Mardin', 'Mersin', 'Muğla', 'Muş', 'Nevşehir', 'Niğde', 'Ordu', 'Osmaniye', 'Rize',
  'Sakarya', 'Samsun', 'Siirt', 'Sinop', 'Sivas', 'Şanlıurfa', 'Şırnak', 'Tekirdağ', 'Tokat', 'Trabzon', 'Tunceli',
  'Uşak', 'Van', 'Yalova', 'Yozgat', 'Zonguldak',
];

// province -> its districts (only where the district is not also the name of another province)
const DISTRICTS: Record<string, string> = {
  İstanbul: 'Adalar, Arnavutköy, Ataşehir, Avcılar, Bağcılar, Bahçelievler, Bakırköy, Başakşehir, Bayrampaşa, Beşiktaş, Beykoz, Beylikdüzü, Beyoğlu, Büyükçekmece, Çatalca, Çekmeköy, Esenler, Esenyurt, Eyüpsultan, Fatih, Gaziosmanpaşa, Güngören, Kadıköy, Kağıthane, Kartal, Küçükçekmece, Maltepe, Pendik, Sancaktepe, Sarıyer, Silivri, Sultanbeyli, Sultangazi, Şile, Şişli, Tuzla, Ümraniye, Üsküdar, Zeytinburnu, Eyüp, İkitelli, Sefaköy, Halkalı, Bahçeşehir, Hadımköy, Ataköy',
  Ankara: 'Akyurt, Altındağ, Ayaş, Beypazarı, Çamlıdere, Çankaya, Çubuk, Elmadağ, Etimesgut, Gölbaşı, Haymana, Kahramankazan, Kalecik, Keçiören, Kızılcahamam, Mamak, Nallıhan, Polatlı, Pursaklar, Sincan, Şereflikoçhisar, Yenimahalle',
  İzmir: 'Aliağa, Balçova, Bayındır, Bayraklı, Bergama, Bornova, Buca, Çeşme, Çiğli, Dikili, Foça, Gaziemir, Güzelbahçe, Karabağlar, Karaburun, Karşıyaka, Kemalpaşa, Kınık, Konak, Menderes, Menemen, Narlıdere, Ödemiş, Seferihisar, Selçuk, Tire, Torbalı, Urla',
  Bursa: 'Gemlik, Gürsu, İnegöl, İznik, Karacabey, Kestel, Mudanya, Mustafakemalpaşa, Nilüfer, Orhaneli, Orhangazi, Osmangazi, Yıldırım',
  Kocaeli: 'Başiskele, Çayırova, Darıca, Derince, Dilovası, Gebze, Gölcük, Kandıra, Karamürsel, Kartepe, Körfez, İzmit',
  Adana: 'Ceyhan, Çukurova, İmamoğlu, Karaisalı, Kozan, Sarıçam, Seyhan, Yüreğir',
  Kayseri: 'Develi, Hacılar, İncesu, Kocasinan, Melikgazi, Talas, Yahyalı, Pınarbaşı',
  Konya: 'Selçuklu, Meram, Karatay, Ereğli, Akşehir, Beyşehir, Cihanbeyli, Çumra, Seydişehir, Ilgın',
  Gaziantep: 'Şahinbey, Şehitkamil, Nizip, İslahiye, Nurdağı, Oğuzeli',
  Antalya: 'Muratpaşa, Kepez, Konyaaltı, Alanya, Manavgat, Serik, Kemer, Kumluca, Aksu, Döşemealtı',
  Van: 'Tuşba, İpekyolu, Erciş',
  Şanlıurfa: 'Haliliye, Eyyübiye, Karaköprü, Siverek, Viranşehir',
  Şırnak: 'Cizre, Silopi',
  Mersin: 'Akdeniz, Mezitli, Toroslar, Tarsus, Erdemli, Silifke',
  Hatay: 'Antakya, İskenderun, Defne, Dörtyol',
  Denizli: 'Pamukkale, Merkezefendi, Çivril',
  Manisa: 'Yunusemre, Şehzadeler, Akhisar, Turgutlu, Salihli, Alaşehir',
  Balıkesir: 'Altıeylül, Karesi, Bandırma, Edremit, Ayvalık',
  Sakarya: 'Adapazarı, Serdivan, Erenler, Arifiye, Sapanca, Hendek',
  Tekirdağ: 'Çorlu, Çerkezköy, Süleymanpaşa, Kapaklı, Ergene, Malkara',
  Eskişehir: 'Odunpazarı, Tepebaşı',
  Samsun: 'İlkadım, Atakum, Canik, Çarşamba, Bafra, Tekkeköy',
  Trabzon: 'Ortahisar, Araklı',
  Ağrı: 'Doğubayazıt',
  Çanakkale: 'Biga, Çan',
  Zonguldak: 'Devrek, Ereğli',
  Elazığ: 'Karakoçan',
  Malatya: 'Battalgazi, Yeşilyurt',
  Diyarbakır: 'Bağlar, Kayapınar, Sur',
  Erzurum: 'Yakutiye, Palandöken',
  Kahramanmaraş: 'Dulkadiroğlu, Onikişubat',
  Aydın: 'Efeler, Nazilli, Söke, Didim',
  Muğla: 'Menteşe, Bodrum, Fethiye, Marmaris, Milas',
  Niğde: 'Bor',
};

export function placeKey(name: string): string {
  return name
    .replace(/İ/g, 'i')
    .normalize('NFD')
    .replace(/\p{Diacritic}/gu, '')
    .replace(/ı/g, 'i')
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim();
}

const provinceByKey = new Map<string, string>(PROVINCES.map((p) => [placeKey(p), p]));
// older or short names people still write
for (const [alias, province] of Object.entries({ icel: 'Mersin', afyon: 'Afyonkarahisar', antep: 'Gaziantep', maras: 'Kahramanmaraş', urfa: 'Şanlıurfa', izmit: 'Kocaeli', adapazari: 'Sakarya', istanbul: 'İstanbul' })) {
  if (!provinceByKey.has(alias)) provinceByKey.set(alias, province);
}
const districtToProvince = new Map<string, string>();
for (const [province, list] of Object.entries(DISTRICTS)) {
  for (const d of list.split(',')) {
    const k = placeKey(d);
    if (!provinceByKey.has(k) && !districtToProvince.has(k)) districtToProvince.set(k, province);
  }
}

// "BAŞAKŞEHİR" -> İstanbul, "bursa" -> Bursa, "İstanbul / Pendik" -> İstanbul. Unknown places come back as they were
// written (tidied), so nothing is lost; an empty one stays empty.
export function resolveCity(raw: string | null | undefined): { city: string | null; known: boolean } {
  const text = (raw ?? '').replace(/\s+/g, ' ').trim();
  if (!text) return { city: null, known: false };
  for (const part of text.split(/[/,;()-]+/).map((p) => p.trim()).filter(Boolean)) {
    const k = placeKey(part);
    const p = provinceByKey.get(k) ?? districtToProvince.get(k);
    if (p) return { city: p, known: true };
  }
  // "Merkez" only says "the town centre": without the province it tells nothing
  if (placeKey(text) === 'merkez') return { city: null, known: false };
  const tidy = text.toLocaleLowerCase('tr').replace(/(^|\s)(\S)/g, (_m, a: string, b: string) => a + b.toLocaleUpperCase('tr'));
  return { city: tidy, known: false };
}

// Looks for a province (or a known district) inside a postal address.
export function guessCityFromAddress(address: string | null | undefined): string | null {
  const text = placeKey(address ?? '').replace(/[^a-z0-9 ]+/g, ' ');
  if (!text) return null;
  const padded = ` ${text} `;
  for (const [k, p] of provinceByKey) if (padded.includes(` ${k} `)) return p;
  for (const [k, p] of districtToProvince) if (k.length > 4 && padded.includes(` ${k} `)) return p;
  return null;
}
