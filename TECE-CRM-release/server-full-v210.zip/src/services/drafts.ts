import { db } from '../db/connection';
import type { CardRow } from '../models/cardModel';
import { listCompetitors } from './competitors';
import { askJson } from './perfActions';
import { EDGEBAND_CONTEXT } from './edgebandingKnowledge';
import { pricingAnalysis } from './pricingAnalysis';
import { accountOfSapAny } from './perfAnalytics';
import { niceName } from './niceName';

// Two kinds of e-mail the system writes for the sender, who edits and sends it:
//  1. a nudge: the reminder says "write to them", the e-mail is already there (plain and natural, no AI needed; the AI can rewrite it on request)
//  2. an answer to a reply the customer sent about a price or about quality: the AI reads their message, our offer and what we know, and suggests a move and the answer.
export type NudgeKind = 'reorder' | 'offer_followup' | 'first_contact' | 'quiet' | 'proforma_followup' | 'payment' | 'appointment';
export interface Draft { subject: string; body: string }

const first = (card: CardRow) => niceName((card.name ?? '').trim().split(/\s+/)[0], true) || '';
const langOf = (card: CardRow): 'tr' | 'en' => ((card as { language?: string | null }).language === 'tr' ? 'tr' : 'en');

export interface NudgeCtx { days?: number | null; lastOrder?: string | null; usualDays?: number | null; offerAt?: string | null; proforma?: string | null; amount?: string | null; place?: string | null; dates?: string | null; time?: string | null }

export function nudgeTemplate(card: CardRow, kind: NudgeKind, c: NudgeCtx = {}): Draft {
  const company = card.company || card.name || '';
  const pfName = (c.proforma ?? '').trim() && !/^proforma$/i.test((c.proforma ?? '').trim()) ? (c.proforma ?? '').trim() : '';
  const lead = company ? `${company}: ` : '';
  const name = first(card);
  const tr = langOf(card) === 'tr';
  const hi = tr ? (name ? `Merhaba ${name},` : 'Merhaba,') : (name ? `Hello ${name},` : 'Hello,');
  const when = c.offerAt ? c.offerAt.slice(0, 10) : '';
  const place = (c.place ?? '').trim(); const dates = (c.dates ?? '').trim(); const time = (c.time ?? '').trim();
  const T: Record<NudgeKind, Draft> = tr ? {
    reorder: { subject: `${lead}yeni sipariş için bir şey lazım mı?`, body: `${hi}\n\nSon siparişinizden bu yana bir süre geçti${c.lastOrder ? ` (${c.lastOrder.slice(0, 10)})` : ''}. Stoklarınız nasıl, yeni bir sipariş planlıyor musunuz? Fiyat ya da renk konusunda bir ihtiyacınız varsa hemen hazırlayayım.\n\nİyi çalışmalar` },
    offer_followup: { subject: `${lead}teklifimiz hakkında`, body: `${hi}\n\n${when ? `${when} tarihinde` : 'Geçenlerde'} gönderdiğim teklife bir göz atabildiniz mi? Fiyat, ölçü ya da renklerle ilgili aklınıza takılan bir şey varsa birlikte çözelim.\n\nİyi çalışmalar` },
    first_contact: { subject: `TECE kenar bandı${company ? ': ' + company : ''}`, body: `${hi}\n\nBen TECE'den yazıyorum; PVC, ABS ve PP kenar bandı üretiyoruz. ${company} için uygun olabilir mi diye merak ettim. İsterseniz kısa bir fiyat listesi ve numune göndereyim.\n\nİyi çalışmalar` },
    quiet: { subject: `${lead}nasılsınız?`, body: `${hi}\n\nBir süredir haberleşemedik, nasılsınız? Yeni ürünlerimiz ve güncel fiyatlarımız var; ilginizi çekerse paylaşayım.\n\nİyi çalışmalar` },
    proforma_followup: { subject: `${lead}proforma onayı`, body: `${hi}\n\n${pfName ? `${pfName} numaralı ` : 'Gönderdiğim '}proformayı inceleyebildiniz mi? Onayınızla birlikte üretimi hemen planlayabilirim. Değiştirmek istediğiniz bir şey olursa söyleyin.\n\nİyi çalışmalar` },
    appointment: { subject: `${lead}görüşme için randevu`, body: `${hi}\n\n${place ? `${dates ? `${dates} tarihlerinde ` : ''}${place} bölgesinde olacağım.` : 'Yakında bölgenizde olacağım.'} Sizi ziyaret etmek isterim. ${time ? `Saat ${time} civarı uygun olur mu?` : 'Size uygun bir gün ve saat var mı?'} Ürünlerimizi ve güncel fiyatlarımızı yüz yüze konuşabiliriz.\n\nİyi çalışmalar` },
    payment: { subject: `${lead}ödeme hatırlatması`, body: `${hi}\n\nCari hesabınızda vadesi geçmiş bir tutar görünüyor${c.amount ? ` (${c.amount})` : ''}. Ödemenin ne zaman yapılabileceğini bildirirseniz çok sevinirim; bir sorun varsa birlikte çözelim.\n\nİyi çalışmalar` },
  } : {
    reorder: { subject: `${lead}time for your next order?`, body: `${hi}\n\nIt has been a while since your last order${c.lastOrder ? ` (${c.lastOrder.slice(0, 10)})` : ''}${c.usualDays ? `, and you usually order about every ${c.usualDays} days` : ''}. How is your stock? If you are planning the next order, tell me the colours and quantities and I will prepare everything today.\n\nBest regards` },
    offer_followup: { subject: `${lead}our offer`, body: `${hi}\n\nI wanted to follow up on the offer I sent${when ? ` on ${when}` : ' recently'}. Did you have a chance to look at it? If anything about the prices, sizes or colours is unclear, I am happy to go through it with you.\n\nBest regards` },
    first_contact: { subject: `TECE edgebanding for ${company || 'your company'}`, body: `${hi}\n\nI am writing from TECE, a Turkish maker of PVC, ABS and PP edgebanding. I thought we might be a good fit for ${company}. If you like, I can send a short price list and a few samples.\n\nBest regards` },
    quiet: { subject: `${lead}how are you?`, body: `${hi}\n\nWe have not been in touch for a while, so I wanted to say hello. We have new products and updated prices; I would be glad to share them if you are interested.\n\nBest regards` },
    proforma_followup: { subject: `${lead}your proforma`, body: `${hi}\n\nHave you had a chance to look at ${pfName ? `proforma ${pfName}` : 'the proforma I sent'}? As soon as you confirm, I can schedule production. If you want to change anything, just tell me.\n\nBest regards` },
    appointment: { subject: `${lead}can we meet?`, body: `${hi}\n\n${place ? `I will be in ${place}${dates ? ` (${dates})` : ''}.` : 'I will be in your area soon.'} I would like to visit you. ${time ? `Would around ${time} suit you?` : 'Is there a day and time that suits you?'} We can go through our products and current prices in person.\n\nBest regards` },
    payment: { subject: `${lead}payment reminder`, body: `${hi}\n\nOur records show an overdue amount on your account${c.amount ? ` (${c.amount})` : ''}. Could you let me know when the payment can be made? If there is any problem, I am happy to help sort it out.\n\nBest regards` },
  };
  return T[kind];
}

// "rewrite it so it sounds like a person": the same facts, the same language, shorter and warmer
export async function polishDraft(card: CardRow, draft: Draft, sender: string): Promise<Draft | null> {
  const j = await askJson([
    `You help ${sender}, a sales person at TECE (edgebanding for furniture), write natural business e-mails. Rewrite this e-mail so it sounds like a real person wrote it: warm, short (under 90 words), no clichés, no pressure. Keep the language and the facts exactly. Do not invent prices, dates or promises. Do not add a signature.`,
    `Customer: ${card.company || card.name || ''} (${card.country ?? ''}). Contact first name: ${first(card) || 'unknown'}.`,
    `Subject: ${draft.subject}\n\n${draft.body}`,
    'Answer as JSON: subject, body.',
  ].join('\n\n'), { type: 'OBJECT', properties: { subject: { type: 'STRING' }, body: { type: 'STRING' } }, required: ['subject', 'body'] });
  if (!j) return null;
  const subject = String(j.subject ?? '').trim(); const body = String(j.body ?? '').trim();
  return subject && body ? { subject: subject.slice(0, 200), body: body.slice(0, 3000) } : null;
}

// ---- the introduction / "getting back in touch" e-mail: written from what we know about this person and this company ---------------------------------
const clean = (s: string | null | undefined, n = 120) => (s ?? '').replace(/\s+/g, ' ').trim().slice(0, n);
export interface IntroContext {
  relation: 'lead' | 'customer' | 'former';
  lastInvoice: string | null; monthsSince: number | null; bought: string[]; lastNote: string | null; lastOfferAt: string | null;
}

// who they are to us: a potential customer, a customer, or a former customer (SAP number but no invoice for a year); what they bought; what was said last
export function introContext(card: CardRow): IntroContext {
  const ctx: IntroContext = { relation: 'lead', lastInvoice: null, monthsSince: null, bought: [], lastNote: null, lastOfferAt: null };
  try {
    const sap = (card.sap ?? '').trim();
    if (sap) {
      ctx.relation = 'customer';
      const a = accountOfSapAny(sap);
      if (a?.lastInvoice) {
        ctx.lastInvoice = a.lastInvoice;
        ctx.monthsSince = Math.max(0, Math.round((Date.now() - new Date(a.lastInvoice).getTime()) / (30.4 * 86400000)));
        if (ctx.monthsSince >= 12) ctx.relation = 'former';
      }
    }
    const docs = db.prepare('SELECT lines_json FROM customer_price_docs WHERE card_id = ? ORDER BY COALESCE(doc_date, \'\') DESC LIMIT 3').all(card.id) as { lines_json: string }[];
    const m = new Map<string, number>();
    for (const d of docs) for (const l of JSON.parse(d.lines_json) as { sap: string; thickness: number | null; meters: number | null }[]) {
      const prod = l.sap.endsWith('.012') ? 'PVC' : l.sap.endsWith('.042') ? 'ABS' : l.sap.endsWith('.023') ? 'melamine' : '';
      if (!prod) continue;
      const k = `${prod}${l.thickness ? ` ${l.thickness} mm` : ''}`;
      m.set(k, (m.get(k) ?? 0) + (l.meters ?? 0));
    }
    ctx.bought = [...m.entries()].sort((x, y) => y[1] - x[1]).slice(0, 3).map(([k]) => k);
    const note = db.prepare("SELECT text FROM activities WHERE card_id = ? AND type IN ('note','call','visit','meeting') AND COALESCE(imported, 0) = 0 ORDER BY id DESC LIMIT 1").get(card.id) as { text: string } | undefined;
    if (note?.text) ctx.lastNote = clean(note.text, 220);
    const off = db.prepare('SELECT sent_at FROM offers_sent WHERE card_id = ? ORDER BY sent_at DESC LIMIT 1').get(card.id) as { sent_at: string } | undefined;
    ctx.lastOfferAt = off?.sent_at?.slice(0, 10) ?? null;
  } catch { /* the e-mail is written from what is there */ }
  return ctx;
}

export function introTemplate(card: CardRow, sender = '', ctx: IntroContext = introContext(card)): Draft {
  const company = clean(card.company) || clean(card.name);
  const tr = langOf(card) === 'tr';
  const name = niceName(first(card), true);
  const me = (sender || '').trim().split(/\s+/)[0];
  const does = clean(card.work_area, 90);
  const wants = clean(card.interested_in, 90);
  const where = clean(card.country, 40);
  const hi = tr ? (name ? `Merhaba ${name},` : `Merhaba ${company} ekibi,`) : (name ? `Hello ${name},` : `Hello ${company} team,`);
  const since = ctx.monthsSince !== null ? (ctx.monthsSince >= 24 ? `${Math.round(ctx.monthsSince / 12)} years` : `${ctx.monthsSince} months`) : '';
  const boughtTxt = ctx.bought.length ? ctx.bought.join(' and ') : '';
  if (tr) {
    if (ctx.relation !== 'lead') {
      return { subject: `${company}: nasılsınız?`, body: `${hi}\n\n${me ? `Ben ${me}, TECE'den. ` : ''}${ctx.lastInvoice ? `En son ${ctx.lastInvoice.split('-').reverse().join('.')} tarihinde birlikte çalışmıştık${boughtTxt ? ` (${boughtTxt})` : ''}` : 'Daha önce birlikte çalışmıştık'}; aradan bir süre geçti, nasıl gidiyor?\n\nYeni renk ve fiyatlarımız var. ${boughtTxt ? `${boughtTxt} için güncel fiyatları ` : 'Güncel fiyatları '}size göndermemi ister misiniz? Bu ay planladığınız bir iş varsa söyleyin, hemen bakayım.\n\nİyi çalışmalar` };
    }
    const know = does ? `${company}'ın ${does} alanında çalıştığını gördüm` : `${company} hakkında bilgi edindim`;
    const fit = wants ? `${wants} ile ilgilendiğinizi biliyorum, biz de tam bunu üretiyoruz.` : 'Mobilya ve panel üreticilerine PVC, ABS ve PP kenar bandı sağlıyoruz.';
    return { subject: `TECE kenar bandı: ${company}`, body: `${hi}\n\n${me ? `Ben ${me}, TECE'den; ` : ''}PVC, ABS ve PP kenar bandı üretiyoruz. ${know}. ${fit}\n\nİsterseniz güncel fiyat listemizi ve kullandığınız renklerde birkaç numune göndereyim. Bu hafta kısa bir görüşme için uygun musunuz?\n\nİyi çalışmalar` };
  }
  if (ctx.relation !== 'lead') {
    const last = ctx.lastInvoice ? `Our last order together was in ${new Date(ctx.lastInvoice).toLocaleDateString('en-GB', { month: 'long', year: 'numeric' })}${boughtTxt ? ` (${boughtTxt})` : ''}` : 'We have worked together before';
    const gap = since && ctx.relation === 'former' ? `, and I realised it has been about ${since} since we last spoke` : '';
    return { subject: `${company}: it has been a while`, body: `${hi}\n\n${me ? `It's ${me} from TECE. ` : ''}${last}${gap}. How is business going${where ? ` in ${where}` : ''}?\n\nWe have new decors and updated prices, and I would like to make sure you are not paying more than you should. ${boughtTxt ? `Would you like me to send you today's prices for ${boughtTxt}?` : 'Would you like me to send you our current prices?'} And if something is planned for the next weeks, tell me what you need and I will prepare it.\n\nBest regards` };
  }
  const know = does ? `I saw that ${company} works in ${does}` : `I am writing to ${company}${where ? ` in ${where}` : ''} because I think we could be useful to you`;
  const fit = wants ? `You mention ${wants}, which is exactly what we make every day.` : 'We supply PVC, ABS and PP edgebanding to furniture and panel producers.';
  return { subject: `TECE edgebanding for ${company}`, body: `${hi}\n\n${me ? `I'm ${me} from TECE. ` : ''}${know}. ${fit}\n\nIf it helps, I can send our current price list and a few samples in the colours you use. Would you have 10 minutes for a call this week?\n\nBest regards` };
}

// the same e-mail, written by the AI as a person would: first person, one specific detail, short; in their language; never invents facts
export async function introWithAi(card: CardRow, base: Draft, sender: string, ctx: IntroContext = introContext(card)): Promise<Draft | null> {
  const lang = { en: 'English', tr: 'Turkish', ru: 'Russian', es: 'Spanish', fr: 'French' }[(card.language ?? 'en') as string] ?? 'English';
  const me = sender.trim().split(/\s+/)[0] || sender;
  const who = ctx.relation === 'lead' ? 'a POTENTIAL customer who has not bought from us yet' : ctx.relation === 'former' ? `a FORMER customer who has not ordered for about ${ctx.monthsSince ?? 12} months` : 'an EXISTING customer';
  const facts = [
    `Company: ${clean(card.company)}`, card.country ? `Country: ${clean(card.country, 40)}${card.city ? `, ${clean(card.city, 40)}` : ''}` : '', card.work_area ? `What they do: ${clean(card.work_area, 160)}` : '',
    card.interested_in ? `Interested in: ${clean(card.interested_in, 160)}` : '', card.website ? `Website: ${clean(card.website, 80)}` : '', card.ai_insight ? `Notes: ${clean(card.ai_insight, 300)}` : '',
    ctx.lastInvoice ? `Last invoice: ${ctx.lastInvoice}` : '', ctx.bought.length ? `They bought: ${ctx.bought.join(', ')}` : '', ctx.lastNote ? `Our last note about them: ${ctx.lastNote}` : '', ctx.lastOfferAt ? `Last offer sent: ${ctx.lastOfferAt}` : '',
    `Contact first name: ${niceName(first(card), true) || 'unknown (greet the team of the company instead)'}`,
  ].filter(Boolean).join('\n');
  const j = await askJson([
    `You write e-mails for ${me}, a sales person at TECE (Turkish maker of PVC, ABS and PP edgebanding for furniture). The e-mail goes to ${who}.`,
    `Write it in ${lang}, in the first person as ${me}, the way a real person writes to someone they want to help: warm and direct, short paragraphs, under 110 words, plain words (no "I hope this finds you well", no "reach out", no "leverage", no corporate phrases).`,
    (() => { const m = introModel(); return m ? `HOUSE MODEL (written by the sales director): follow its structure, tone and best lines, and keep any rule below it. Adapt it to the facts; do not copy it blindly.\nSubject: ${m.subject}\n\n${m.body}${m.rules ? `\nRules: ${m.rules}` : ''}` : ''; })(),
    'Make it personal: refer to ONE specific true detail from the facts (what they make, what they bought, when they last ordered, what was said last) so it could not be sent to anybody else. Greet the contact by first name; if the name is unknown greet the company team. Do not call a customer a stranger: for an existing or former customer say we know each other.',
    'End with ONE easy question or offer (a quick call, today\'s prices, samples in their colours). Use ONLY the facts below; do not invent prices, dates, products, deadlines, certificates or claims. Do not add a signature.',
    `FACTS:\n${facts}`, `A plain version to improve (keep its meaning):\nSubject: ${base.subject}\n\n${base.body}`,
    'Answer as JSON: subject (short, human, no hype), body.',
  ].join('\n\n'), { type: 'OBJECT', properties: { subject: { type: 'STRING' }, body: { type: 'STRING' } }, required: ['subject', 'body'] });
  if (!j) return null;
  const subject = String(j.subject ?? '').trim(); const body = String(j.body ?? '').trim();
  return subject && body ? { subject: subject.slice(0, 200), body: body.slice(0, 3000) } : null;
}

// ---- the customer answered: what can we do ---------------------------------------------------------------------------------------
export interface ReplyAdvice {
  summary: string;
  mood: 'positive' | 'neutral' | 'negative';
  theyWant: string;
  mainObjection: string;
  competitor: string;
  numbers: string;
  moves: { title: string; detail: string; discountPct: number | null }[];
  recommendedDiscountPct: number | null;
  nextStep: string;
  email: Draft;
  facts: string[];
}

const SCHEMA = {
  type: 'OBJECT',
  properties: {
    summary: { type: 'STRING' }, mood: { type: 'STRING' }, theyWant: { type: 'STRING' }, mainObjection: { type: 'STRING' }, competitor: { type: 'STRING' }, numbers: { type: 'STRING' },
    moves: { type: 'ARRAY', items: { type: 'OBJECT', properties: { title: { type: 'STRING' }, detail: { type: 'STRING' }, discountPct: { type: 'NUMBER' } }, required: ['title', 'detail'] } },
    recommendedDiscountPct: { type: 'NUMBER' }, nextStep: { type: 'STRING' },
    email: { type: 'OBJECT', properties: { subject: { type: 'STRING' }, body: { type: 'STRING' } }, required: ['subject', 'body'] },
  },
  required: ['summary', 'mood', 'moves', 'nextStep', 'email'],
};

// what we know about this customer that bears on the answer: our last offers, what they pay if they keep their own prices, what was said, what the competitors are
export function replyFacts(card: CardRow, viewer: { id: number; role: string; display_name: string | null }, text: string): string[] {
  const facts: string[] = [];
  const offers = db.prepare('SELECT sent_at, params FROM offers_sent WHERE card_id = ? ORDER BY id DESC LIMIT 3').all(card.id) as { sent_at: string; params: string }[];
  for (const o of offers) {
    try {
      const p = JSON.parse(o.params) as { currency?: string; transportPct?: number; pagePct?: Record<string, number>; widths?: number[]; deliveryTerm?: string; paymentTerm?: string };
      const pct = (v: number) => `${v > 0 ? '+' : ''}${Math.round(v * 1000) / 10} %`;
      facts.push(`Offer sent ${o.sent_at.slice(0, 10)}: ${p.currency ?? 'EUR'}, general level ${pct(p.transportPct ?? 0)}${p.pagePct ? `, per page ${Object.entries(p.pagePct).map(([k, v]) => `${k} ${pct(v)}`).join(', ')}` : ''}${p.widths?.length ? `, widths ${p.widths.join('/')} mm` : ''}${p.deliveryTerm ? `, delivery ${p.deliveryTerm}` : ''}${p.paymentTerm ? `, payment ${p.paymentTerm}` : ''}.`);
    } catch { /* an old offer without readable settings */ }
  }
  try {
    const row = pricingAnalysis(viewer, card.id).rows[0];
    if (row && row.indexPct !== null) facts.push(`This customer already buys from us and pays ${row.indexPct} % against our standard price list (${row.docs} proformas).`);
  } catch { /* no price memory */ }
  const notes = db.prepare("SELECT type, text, created_at FROM activities WHERE card_id = ? AND type IN ('note','call','visit','sample','thank_you','offer','email') ORDER BY id DESC LIMIT 6").all(card.id) as { type: string; text: string; created_at: string }[];
  for (const n of notes.reverse()) facts.push(`${n.created_at.slice(0, 10)} ${n.type}: ${String(n.text).replace(/\s+/g, ' ').slice(0, 220)}`);
  const low = text.toLowerCase();
  for (const c of listCompetitors()) {
    const key = c.name.replace(/\(.*\)/, '').trim().toLowerCase();
    if (key.length >= 4 && low.includes(key.split(' ')[0])) {
      facts.push(`Competitor named in the message: ${c.name}. Our battle card: ${c.card.summary} Angle: ${c.card.angle.slice(0, 3).join(' ')} Their weak points that are documented: ${c.card.weaknesses.slice(0, 3).join(' ') || 'none documented'}.`);
    }
  }
  return facts;
}

export async function adviseReply(card: CardRow, text: string, sender: string, facts: string[]): Promise<ReplyAdvice | null> {
  const lang = langOf(card) === 'tr' ? 'Turkish' : 'English (or the language of the customer message, if it is another one)';
  const j = await askJson([
    EDGEBAND_CONTEXT,
    `${sender} sells for TECE. The customer ${card.company || card.name || ''} (${card.country ?? ''}) answered about price or quality. Read their message, our offers and what we know, then say what we can do and write the answer.`,
    'RULES: never invent a price, a discount we did not agree to, a delivery date or a technical claim. A move that costs money (a discount, a free sample, a better price for a bigger quantity) is a SUGGESTION for the sender to decide: give it as a percentage of our last offer price, small and realistic (usually 2 to 8 %), and say what we should ask in return (quantity, a first order, prepayment, DAP terms). Do not criticise a competitor; ask questions that let the customer see the difference themselves. Where the e-mail needs a figure you do not know (the final price per meter, a date), write it in square brackets for the sender to fill in. If the customer gives numbers, do the arithmetic in "numbers" (for example their price per meter against ours, the saving for a quantity) and show it briefly.',
    `Answer as JSON: summary (2 sentences: what they said), mood (positive, neutral or negative), theyWant (what would make them move), mainObjection, competitor (who they buy from now, or empty), numbers (the arithmetic, or empty), moves[3 or 4]{title, detail, discountPct (number or omit)}, recommendedDiscountPct (the one number you would try first, or omit), nextStep (one sentence), email{subject, body}: the answer to send, in ${lang}, natural and short (under 160 words), starting with a greeting and ending without a signature.`,
    facts.length ? `WHAT WE KNOW:\n- ${facts.join('\n- ')}` : 'WHAT WE KNOW: nothing else is recorded.',
    `THE CUSTOMER'S MESSAGE:\n${text.trim().slice(0, 7000)}`,
  ].join('\n\n'), SCHEMA);
  if (!j) return null;
  const s = (v: unknown, n: number) => String(v ?? '').trim().slice(0, n);
  const pctOf = (v: unknown): number | null => { const n = Number(v); return Number.isFinite(n) && n > 0 ? Math.min(15, Math.round(n * 10) / 10) : null; };
  const moves = (Array.isArray(j.moves) ? j.moves : []).slice(0, 5).map((m) => { const o = m as Record<string, unknown>; return { title: s(o.title, 90), detail: s(o.detail, 420), discountPct: pctOf(o.discountPct) }; }).filter((m) => m.title);
  const em = (j.email ?? {}) as Record<string, unknown>;
  const mood = j.mood === 'positive' ? 'positive' : j.mood === 'negative' ? 'negative' : 'neutral';
  return { summary: s(j.summary, 500), mood, theyWant: s(j.theyWant, 300), mainObjection: s(j.mainObjection, 300), competitor: s(j.competitor, 80), numbers: s(j.numbers, 500), moves, recommendedDiscountPct: pctOf(j.recommendedDiscountPct), nextStep: s(j.nextStep, 300), email: { subject: s(em.subject, 200), body: s(em.body, 3500) }, facts };
}

// ---- the house model of the introduction e-mail (Admin -> Introduction e-mail): placeholders {name} {company} {country} {sender}; the AI follows its tone and structure
import { settingsModel } from '../models/settingsModel';
export interface IntroModel { subject: string; body: string; rules: string }
export function introModel(): IntroModel | null {
  const subject = (settingsModel.get('intro_model_subject') ?? '').trim(), body = (settingsModel.get('intro_model_body') ?? '').trim();
  return subject && body ? { subject, body, rules: (settingsModel.get('intro_rules') ?? '').trim() } : null;
}
export function fillModel(m: IntroModel, card: CardRow, sender: string): Draft {
  const company = clean(card.company) || clean(card.name);
  const name = niceName(first(card), true);
  const vars: Record<string, string> = { name: name || `${company} team`, company, country: clean(card.country, 40), sender: (sender || '').trim().split(/\s+/)[0] };
  const put = (s: string) => s.replace(/\{(\w+)\}/g, (x, k: string) => (k in vars ? vars[k] : x)).replace(/ +,/g, ',');
  return { subject: put(m.subject), body: put(m.body) };
}
