import PDFDocument from 'pdfkit';
import { db } from '../db/connection';
import { settingsModel } from '../models/settingsModel';
import { userModel, type PublicUser } from '../models/userModel';
import { sendThankYouEmail } from './thankYouEmail';
import { drawLogo, registerDesignFonts } from './priceBook/designed';
import { askJson } from './perfActions';
import { newsForToday, type NewsBlock } from './industryNews';
import { accountsFor, asksFor, overview, type Account, type Ask, type Overview } from './perfAnalytics';

// The morning brief: every sales person gets, at 8:30 on working days, two printable pages about their own customers - who to ask for payment,
// for an order, for a confirmation, for the dispatch; how the year is going against the same days of last year and the target; the to-do list;
// and the people to call. The AI writes the short opening and the "work harder" push; the numbers are plain sums from the ledger and SAP lists.

const TZ = 'Europe/Istanbul';
const SYMBOL: Record<string, string> = { EUR: '€', USD: '$' };
const money = (n: number, cur: string) => `${n < 0 ? '-' : ''}${SYMBOL[cur] ?? `${cur} `}${Math.abs(Math.round(n)).toLocaleString('en-US')}`;
const compact = (n: number, cur: string) => {
  const a = Math.abs(n);
  const s = a >= 1e6 ? `${(a / 1e6).toFixed(2)}M` : a >= 1e3 ? `${Math.round(a / 1e3)}k` : String(Math.round(a));
  return `${n < 0 ? '-' : ''}${SYMBOL[cur] ?? `${cur} `}${s}`;
};
const dmy = (iso: string | null | undefined) => (iso ? `${iso.slice(8, 10)}.${iso.slice(5, 7)}.${iso.slice(0, 4)}` : '');
const todayLocal = () => new Date().toLocaleDateString('en-CA', { timeZone: TZ });

interface Viewer { id: number; role: string; display_name: string | null }
interface Todo { text: string; due: string; company: string; late: boolean }
interface Person { name: string; company: string; phone: string; email: string; why: string }
interface Gap { name: string; currency: string; target: number; ytd: number; gap: number; pace: number }
export interface BriefData {
  user: string; date: string; per: { currency: string; ov: Overview }[]; asks: ReturnType<typeof asksFor>;
  harder: Gap[]; todos: Todo[]; people: Person[]; headline: string; focus: string[]; push: string; ai: boolean;
  // the one-page industry news (the same for everybody, made once a day); null = no news page
  news: NewsBlock | null;
}

function todosOf(userId: number, today: string): Todo[] {
  const rows = db.prepare(`SELECT t.text, t.due_date, c.company FROM todos t LEFT JOIN cards c ON c.id = t.card_id
    WHERE t.user_id = ? AND t.done_at IS NULL AND t.due_date <= date(?, '+7 days') ORDER BY t.due_date LIMIT 40`).all(userId, today) as { text: string; due_date: string; company: string | null }[];
  return rows.map((r) => ({ text: r.text, due: r.due_date, company: r.company ?? '', late: r.due_date < today }));
}

function contactOf(a: { cardId: number | null; sap: string; customer: string }, why: string): Person {
  if (a.cardId) {
    const c = db.prepare('SELECT name, last_name, company, tel, mobile, email FROM cards WHERE id = ?').get(a.cardId) as { name: string | null; last_name: string | null; company: string | null; tel: string | null; mobile: string | null; email: string | null } | undefined;
    if (c) return { name: [c.name, c.last_name].filter(Boolean).join(' '), company: c.company ?? a.customer, phone: c.mobile || c.tel || '', email: (c.email ?? '').split(/[;,\s]+/)[0], why };
  }
  const s = db.prepare('SELECT contact, email, phone FROM sap_customers WHERE sap_no = ?').get(a.sap) as { contact: string; email: string; phone: string } | undefined;
  return { name: s?.contact ?? '', company: a.customer, phone: s?.phone ?? '', email: (s?.email ?? '').split(/[;,\s]+/)[0], why };
}

export async function gatherBrief(viewer: Viewer, withAi = true): Promise<BriefData> {
  const today = todayLocal();
  const asks = asksFor(viewer);
  const first = overview(viewer, null, null);
  const per = first.currencies.map((c) => ({ currency: c, ov: c === first.currency ? first : overview(viewer, null, c) }));
  const elapsed = first.elapsedPct / 100;
  const harder: Gap[] = accountsFor(viewer).filter((a) => a.target && !a.inactive && a.health === 'behind')
    .map((a: Account) => ({ name: a.name, currency: a.currency, target: a.target!, ytd: a.ytd, gap: Math.max(0, a.target! * elapsed - a.ytd), pace: a.pace ?? 0 }))
    .sort((x, y) => y.gap - x.gap).slice(0, 8);
  const seen = new Set<string>();
  const people: Person[] = [];
  const add = (list: Ask[], why: string, n: number) => { for (const a of list.slice(0, n)) { if (seen.has(a.sap)) continue; seen.add(a.sap); people.push(contactOf(a, why)); } };
  add(asks.payment, 'payment', 4); add(asks.order, 'order', 3); add(asks.confirmation, 'confirmation', 2); add(asks.dispatch, 'dispatch', 2);
  const name = viewer.display_name ?? 'colleague';
  const base: BriefData = { user: name, date: today, per, asks, harder, todos: todosOf(viewer.id, today), people: people.slice(0, 10), headline: '', focus: [], push: '', ai: false, news: null };
  if (withAi) { try { base.news = await newsForToday(); } catch { base.news = null; } }

  // the plain-rule text, always there
  const eu = per[0];
  const late = asks.totals.payment;
  base.headline = `${name.split(' ')[0]}, ${late ? `${late} customer${late === 1 ? '' : 's'} owe you overdue money` : 'no overdue payments today'}${asks.totals.order ? `, ${asks.totals.order} could be asked for an order` : ''}${asks.totals.confirmation ? ` and ${asks.totals.confirmation} orders wait for a confirmation or the advance` : ''}.`;
  base.focus = [
    asks.payment[0] ? `Ask ${asks.payment[0].customer} for payment (${money(asks.payment[0].value, asks.payment[0].currency)} overdue).` : 'Keep an eye on the open balances.',
    asks.confirmation[0] ? `Get the confirmation or the advance from ${asks.confirmation[0].customer} (${money(asks.confirmation[0].value, asks.confirmation[0].currency)} waiting ${asks.confirmation[0].days ?? 0} days).` : 'No order is waiting for a confirmation.',
    asks.order[0] ? `Call ${asks.order[0].customer} for the next order.` : 'Ask your best customers for their next order.',
  ];
  base.push = eu ? `This year you have invoiced ${money(eu.ov.kpi.ytd, eu.currency)} against ${money(eu.ov.kpi.prevYtd, eu.currency)} on the same days last year${harder.length ? `; ${harder.length} customers are behind their target, the biggest gap is ${harder[0].name}` : ''}.` : '';
  if (!withAi) return base;

  const facts = [
    `Salesperson: ${name}. Date: ${today}.`,
    ...per.map((p) => `${p.currency}: invoiced this year ${money(p.ov.kpi.ytd, p.currency)}, same days last year ${money(p.ov.kpi.prevYtd, p.currency)}${p.ov.kpi.target ? `, target ${money(p.ov.kpi.target, p.currency)} (${p.ov.kpi.pace?.toFixed(0)}%, ${p.ov.elapsedPct.toFixed(0)}% of the year gone)` : ''}; overdue receivables ${money(p.ov.kpi.arOverdue, p.currency)}; waiting for confirmation ${money(p.ov.kpi.blockerValue, p.currency)}; ready to dispatch ${money(p.ov.kpi.dispatchValue, p.currency)} (${Math.round(p.ov.kpi.dispatchKg)} kg).`),
    `Ask for payment: ${asks.payment.slice(0, 5).map((a) => `${a.customer} ${money(a.value, a.currency)} (${a.line})`).join('; ') || 'none'}.`,
    `Ask for an order: ${asks.order.slice(0, 5).map((a) => `${a.customer} (${a.line})`).join('; ') || 'none'}.`,
    `Waiting for confirmation: ${asks.confirmation.slice(0, 4).map((a) => `${a.customer} ${money(a.value, a.currency)} ${a.days} days`).join('; ') || 'none'}.`,
    `Behind the target: ${harder.slice(0, 5).map((g) => `${g.name} gap ${money(g.gap, g.currency)}`).join('; ') || 'none'}.`,
    `To-dos: ${base.todos.length} (${base.todos.filter((t) => t.late).length} late).`,
  ].join('\n');
  const j = await askJson(
    ['You write the morning brief of a salesperson at TECE (Turkish edgebanding maker). Use ONLY these facts; invent nothing. English, direct, motivating but not cheesy.',
      'Give: headline (one sentence, the most important thing today), focus (exactly 3 short action sentences, most urgent first: who to call and why), push (2 sentences: how the year is going compared with last year and what to do to work harder).', facts].join('\n\n'),
    { type: 'OBJECT', properties: { headline: { type: 'STRING' }, focus: { type: 'ARRAY', items: { type: 'STRING' } }, push: { type: 'STRING' } }, required: ['headline', 'focus', 'push'] },
  );
  if (j?.headline && Array.isArray(j.focus) && j.focus.length) {
    base.headline = String(j.headline).trim();
    base.focus = (j.focus as unknown[]).map((x) => String(x).trim()).filter(Boolean).slice(0, 3);
    if (j.push) base.push = String(j.push).trim();
    base.ai = true;
  }
  return base;
}

// ---- the two printable pages -------------------------------------------------------------------------------------------------------
export async function renderBriefPdf(d: BriefData): Promise<Buffer> {
  const doc = new PDFDocument({ size: 'A4', margin: 0, autoFirstPage: false, info: { Title: `TECE daily brief ${d.date}`, Author: 'TECE' } });
  const chunks: Buffer[] = [];
  doc.on('data', (b: Buffer) => chunks.push(b));
  const done = new Promise<Buffer>((resolve, reject) => { doc.on('end', () => resolve(Buffer.concat(chunks))); doc.on('error', reject); });
  registerDesignFonts(doc);
  const NAVY = '#17243E', RED = '#8B1931', SMOKE = '#E3E6EC', STEEL = '#5E6676', MIST = '#F3F4F7', GREEN = '#2C8A68';
  const F = { r: 'TD-400', m: 'TD-500', b: 'TD-600', h: 'TD-700' };
  const PW = 595.28, PH = 841.89, L = 34, CW = PW - 2 * L;
  let y = 0;
  const pretty = new Date(`${d.date}T12:00:00Z`).toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' });

  const page = (n: number) => {
    doc.addPage();
    doc.rect(0, 0, PW, 54).fill(NAVY);
    drawLogo(doc, 'TECE_SloganliLogo_Beyaz_RGB.svg', L, (54 - 170 * (522 / 5990)) / 2, 170);
    doc.rect(0, 54, PW, 3).fill(RED);
    doc.font(F.h).fontSize(11).fillColor('#FFFFFF').text('DAILY BRIEF', L, 15, { width: CW, align: 'right', lineBreak: false });
    doc.font(F.r).fontSize(8).fillColor('#C9D4EE').text(`${d.user} · ${pretty}`, L, 32, { width: CW, align: 'right', lineBreak: false });
    doc.font(F.r).fontSize(7).fillColor(STEEL).text(`Page ${n} of ${d.news ? 3 : 2} · TECE customer system`, L, PH - 22, { width: CW, align: 'center', lineBreak: false });
    y = 70;
  };
  const cut = (s: string, w: number, size: number, font = F.r) => { doc.font(font).fontSize(size); let t = s; while (t.length > 3 && doc.widthOfString(t) > w) t = t.slice(0, -2); return t === s ? s : `${t.trimEnd()}…`; };
  const heading = (t: string, hint = '') => {
    doc.font(F.h).fontSize(9).fillColor(RED).text(t.toUpperCase(), L, y, { lineBreak: false });
    if (hint) doc.font(F.r).fontSize(7.5).fillColor(STEEL).text(hint, L + 170, y + 1, { width: CW - 170, align: 'right', lineBreak: false });
    doc.rect(L, y + 13, CW, 0.8).fill(NAVY);
    y += 19;
  };
  const row = (cells: { t: string; w: number; right?: boolean; bold?: boolean; color?: string }[], h = 14.5, zebra = false) => {
    if (zebra) doc.rect(L, y - 2, CW, h).fill(MIST);
    let x = L + 3;
    for (const c of cells) {
      doc.font(c.bold ? F.b : F.r).fontSize(8).fillColor(c.color ?? '#222222').text(cut(c.t, c.w - 6, 8, c.bold ? F.b : F.r), x, y, { width: c.w - 4, align: c.right ? 'right' : 'left', lineBreak: false });
      x += c.w;
    }
    y += h;
  };
  const none = (t: string) => { doc.font(F.r).fontSize(8).fillColor(STEEL).text(t, L + 3, y, { lineBreak: false }); y += 14; };
  const thead = (cells: { t: string; w: number; right?: boolean }[]) => {
    let x = L + 3;
    for (const c of cells) { doc.font(F.b).fontSize(7).fillColor(STEEL).text(c.t.toUpperCase(), x, y, { width: c.w - 4, align: c.right ? 'right' : 'left', lineBreak: false }); x += c.w; }
    y += 11;
  };

  // ---- page 1: the picture and the money
  page(1);
  doc.roundedRect(L, y, CW, 70, 4).fill(MIST);
  doc.rect(L, y, 3, 70).fill(RED);
  doc.font(F.h).fontSize(10.5).fillColor(NAVY).text(d.headline, L + 12, y + 7, { width: CW - 24, height: 26 });
  let fy = y + 34;
  for (const f of d.focus.slice(0, 3)) { doc.font(F.r).fontSize(8.3).fillColor('#222222').text(`•  ${cut(f, CW - 40, 8.3)}`, L + 12, fy, { width: CW - 24, lineBreak: false }); fy += 11.5; }
  y += 80;

  // the year: one box per currency
  const boxW = (CW - 10 * (d.per.length - 1)) / Math.max(1, d.per.length);
  d.per.forEach((p, i) => {
    const x = L + i * (boxW + 10);
    const k = p.ov.kpi;
    doc.roundedRect(x, y, boxW, 62, 4).lineWidth(0.8).stroke(SMOKE);
    doc.font(F.b).fontSize(7).fillColor(STEEL).text(`${p.currency === 'USD' ? 'DOLLAR' : 'EURO'} ACCOUNTS · THIS YEAR`, x + 8, y + 7, { lineBreak: false });
    doc.font(F.h).fontSize(16).fillColor(NAVY).text(compact(k.ytd, p.currency), x + 8, y + 18, { lineBreak: false });
    const ch = k.prevYtd > 0 ? ((k.ytd - k.prevYtd) / k.prevYtd) * 100 : null;
    doc.font(F.r).fontSize(7.5).fillColor('#222222').text(`Same days last year ${compact(k.prevYtd, p.currency)}${ch === null ? '' : `  ${ch >= 0 ? '▲' : '▼'} ${Math.abs(ch).toFixed(0)}%`}`, x + 8, y + 40, { lineBreak: false });
    doc.font(F.r).fontSize(7.5).fillColor(STEEL).text(k.target ? `Target ${compact(k.target, p.currency)} · ${k.pace?.toFixed(0)}% reached, ${p.ov.elapsedPct.toFixed(0)}% of the year gone` : 'No target set', x + 8, y + 50, { width: boxW - 14, lineBreak: false });
  });
  y += 70;

  // the curve: this year against last year, month by month (the first currency)
  const main = d.per[0];
  if (main) {
    const { prev, current, targetLine } = main.ov.trajectory;
    const gx = L + 36, gw = CW - 44, gh = 78;
    const max = Math.max(1, ...prev, ...(current.filter((v) => v !== null) as number[]), ...(targetLine ?? [])) * 1.05;
    const px = (i: number) => gx + (i * gw) / 11;
    const py = (v: number) => y + 4 + gh * (1 - v / max);
    doc.font(F.b).fontSize(7).fillColor(STEEL).text(`INVOICED, ADDED UP MONTH BY MONTH (${main.currency}) — grey: last year · navy: this year${targetLine ? ' · red: target' : ''}`, L, y - 2, { lineBreak: false });
    y += 8;
    for (const f of [0, 0.5, 1]) { doc.moveTo(gx, py(f * max)).lineTo(gx + gw, py(f * max)).lineWidth(0.4).stroke(SMOKE); doc.font(F.r).fontSize(6.5).fillColor(STEEL).text(compact(f * max, main.currency), L, py(f * max) - 3, { width: 32, align: 'right', lineBreak: false }); }
    const line = (arr: (number | null)[], color: string, w: number, dash?: number[]) => {
      let started = false;
      doc.lineWidth(w).strokeColor(color);
      if (dash) doc.dash(dash[0], { space: dash[1] });
      arr.forEach((v, i) => { if (v === null) return; if (!started) { doc.moveTo(px(i), py(v)); started = true; } else doc.lineTo(px(i), py(v)); });
      doc.stroke();
      if (dash) doc.undash();
    };
    if (targetLine) line(targetLine, RED, 1, [4, 3]);
    line(prev, '#9AA3B5', 1.4);
    line(current, NAVY, 2.2);
    ['J', 'F', 'M', 'A', 'M', 'J', 'J', 'A', 'S', 'O', 'N', 'D'].forEach((m, i) => doc.font(F.r).fontSize(6.5).fillColor(STEEL).text(m, px(i) - 3, y + gh + 6, { width: 6, align: 'center', lineBreak: false }));
    y += gh + 20;
  }

  heading('Ask for payment', `${d.asks.totals.payment} customers with overdue invoices`);
  const wP = [236, 90, 70, CW - 396];
  thead([{ t: 'Customer', w: wP[0] }, { t: 'Overdue', w: wP[1], right: true }, { t: 'Days late', w: wP[2], right: true }, { t: 'Action', w: wP[3] }]);
  if (!d.asks.payment.length) none('Nobody is overdue.');
  d.asks.payment.slice(0, 7).forEach((a, i) => row([{ t: a.customer, w: wP[0], bold: true }, { t: money(a.value, a.currency), w: wP[1], right: true }, { t: String(a.days ?? ''), w: wP[2], right: true, color: (a.days ?? 0) > 60 ? RED : '#222222' }, { t: 'Send the statement', w: wP[3], color: STEEL }], 14.5, i % 2 === 1));
  y += 6;
  const colW = (CW - 14) / 2;
  const startY = y;
  heading('Waiting for confirmation', `${d.asks.totals.confirmation} customers`);
  const yConf = y;
  const dispatchX = L + colW + 14;
  if (!d.asks.confirmation.length) none('Nothing is waiting.');
  d.asks.confirmation.slice(0, 5).forEach((a, i) => row([{ t: a.customer, w: colW - 118, bold: true }, { t: money(a.value, a.currency), w: 66, right: true }, { t: `${a.days ?? 0} d`, w: 50, right: true, color: (a.days ?? 0) > 14 ? RED : '#222222' }], 14.5, i % 2 === 1));
  const endLeft = y;
  y = startY;
  // the second column is drawn in the same row band, shifted to the right
  const save = { y: startY };
  doc.font(F.h).fontSize(9).fillColor(RED).text('READY TO DISPATCH', dispatchX, save.y, { lineBreak: false });
  doc.font(F.r).fontSize(7.5).fillColor(STEEL).text(`${d.asks.totals.dispatch} customers`, dispatchX + 100, save.y + 1, { width: colW - 100, align: 'right', lineBreak: false });
  doc.rect(dispatchX, save.y + 13, colW, 0.8).fill(NAVY);
  let dy = yConf;
  if (!d.asks.dispatch.length) { doc.font(F.r).fontSize(8).fillColor(STEEL).text('Nothing is ready.', dispatchX + 3, dy, { lineBreak: false }); }
  d.asks.dispatch.slice(0, 5).forEach((a, i) => {
    if (i % 2 === 1) doc.rect(dispatchX, dy - 2, colW, 14.5).fill(MIST);
    doc.font(F.b).fontSize(8).fillColor('#222222').text(cut(a.customer, colW - 124, 8, F.b), dispatchX + 3, dy, { width: colW - 120, lineBreak: false });
    doc.font(F.r).fontSize(8).fillColor('#222222').text(cut(`${money(a.value, a.currency)} · ${a.line.split(', ')[1] ?? ''}`, 116, 8), dispatchX + colW - 118, dy, { width: 116, align: 'right', lineBreak: false });
    dy += 14.5;
  });
  y = Math.max(endLeft, dy) + 4;

  // ---- page 2: the work
  page(2);
  heading('Ask for an order', `${d.asks.totals.order} customers behind the target or quiet for 3 months`);
  const wO = [250, 100, CW - 350];
  thead([{ t: 'Customer', w: wO[0] }, { t: 'Last year', w: wO[1], right: true }, { t: 'Why now', w: wO[2] }]);
  if (!d.asks.order.length) none('Nobody to ask.');
  d.asks.order.slice(0, 8).forEach((a, i) => row([{ t: a.customer, w: wO[0], bold: true }, { t: money(a.value, a.currency), w: wO[1], right: true }, { t: `  ${a.line}`, w: wO[2], color: STEEL }], 14.5, i % 2 === 1));
  y += 8;

  heading('Work harder: behind the target', 'the gap is what the target asks for by today, less what was invoiced');
  const wH = [190, 70, 70, 70, CW - 400];
  thead([{ t: 'Customer', w: wH[0] }, { t: 'Target', w: wH[1], right: true }, { t: 'Invoiced', w: wH[2], right: true }, { t: 'Gap', w: wH[3], right: true }, { t: 'Reached', w: wH[4] }]);
  if (!d.harder.length) none('Nobody is behind the target.');
  d.harder.forEach((g, i) => {
    row([{ t: g.name, w: wH[0], bold: true }, { t: compact(g.target, g.currency), w: wH[1], right: true }, { t: compact(g.ytd, g.currency), w: wH[2], right: true }, { t: compact(g.gap, g.currency), w: wH[3], right: true, color: RED }, { t: '', w: wH[4] }], 14.5, i % 2 === 1);
    const bx = L + wH[0] + wH[1] + wH[2] + wH[3] + 14, bw = wH[4] - 52;
    doc.rect(bx, y - 11, bw, 5).fill(SMOKE);
    doc.rect(bx, y - 11, Math.min(bw, (bw * g.pace) / 100), 5).fill(g.pace >= 60 ? GREEN : RED);
    doc.font(F.r).fontSize(7.5).fillColor('#222222').text(`${g.pace.toFixed(0)}%`, bx + bw + 4, y - 13, { lineBreak: false });
  });
  if (d.push) { y += 2; doc.font(F.r).fontSize(8).fillColor(NAVY).text(d.push, L + 3, y, { width: CW - 6, height: 24 }); y += 28; }
  y += 4;

  heading('To-do list', `${d.todos.length} open (due in the next 7 days or late)`);
  if (!d.todos.length) none('Nothing on your list. Add follow-ups on the customers.');
  d.todos.slice(0, 8).forEach((t) => {
    doc.rect(L + 3, y, 8, 8).lineWidth(0.8).stroke(NAVY);
    doc.font(F.r).fontSize(8).fillColor(t.late ? RED : '#222222').text(cut(`${t.company ? `${t.company}: ` : ''}${t.text}`, CW - 100, 8), L + 18, y, { width: CW - 100, lineBreak: false });
    doc.font(F.r).fontSize(7.5).fillColor(t.late ? RED : STEEL).text(`${t.late ? 'LATE · ' : ''}${dmy(t.due)}`, L + CW - 78, y, { width: 76, align: 'right', lineBreak: false });
    y += 14.5;
  });
  y += 6;

  heading('People to contact today');
  const wC = [120, 150, 92, CW - 362, 0];
  thead([{ t: 'Person', w: wC[0] }, { t: 'Company', w: wC[1] }, { t: 'Phone', w: wC[2] }, { t: 'E-mail', w: wC[3] }]);
  if (!d.people.length) none('No contact details found.');
  d.people.forEach((p, i) => row([{ t: p.name || '—', w: wC[0], bold: true }, { t: p.company, w: wC[1] }, { t: p.phone, w: wC[2] }, { t: p.email, w: wC[3], color: STEEL }], 14.5, i % 2 === 1));
  // ---- page 3: the industry news (only when there is some) ----------------------------------------------------------------------
  if (d.news) {
    const n = d.news;
    page(3);
    heading('Global industry news', 'the last 48 hours · trade press · from the feeds only');
    if (n.summary.length) {
      doc.font(F.h).fontSize(8).fillColor(NAVY).text('EXECUTIVE SUMMARY', L, y, { lineBreak: false }); y += 13;
      for (const b of n.summary) { doc.font(F.r).fontSize(8.5).fillColor('#222222').text(`•  ${b}`, L + 4, y, { width: CW - 8, height: 24 }); y += doc.heightOfString(`•  ${b}`, { width: CW - 8 }) > 12 ? 24 : 13; }
      y += 6;
    }
    const story = (title: string, source: string, body: string, tail: string, tailColor: string, link: string) => {
      doc.font(F.b).fontSize(8.5).fillColor(NAVY).text(cut(title, CW - 150, 8.5, F.b), L + 3, y, { width: CW - 150, lineBreak: false, link, underline: false });
      doc.font(F.r).fontSize(7).fillColor(STEEL).text(source, L + CW - 144, y + 1, { width: 142, align: 'right', lineBreak: false });
      y += 12;
      doc.font(F.r).fontSize(8).fillColor('#222222').text(body, L + 3, y, { width: CW - 8, height: 22 }); y += doc.heightOfString(body, { width: CW - 8 }) > 11 ? 23 : 12;
      if (tail) { doc.font(F.b).fontSize(8).fillColor(tailColor).text(tail, L + 3, y, { width: CW - 8, height: 12, lineBreak: false }); y += 12; }
      y += 6;
    };
    if (n.technical.length) {
      doc.font(F.h).fontSize(8).fillColor(NAVY).text('TECHNICAL & RAW MATERIALS (PRODUCTION / R&D)', L, y, { lineBreak: false }); y += 14;
      for (const s of n.technical) story(s.headline, s.source, s.fact, `Assessment: ${s.assessment} for the edgebanding / panel supply chain`, s.assessment === 'BAD' ? RED : GREEN, s.link);
    }
    if (n.regional.length) {
      doc.font(F.h).fontSize(8).fillColor(NAVY).text('REGIONAL EXPORT MARKETS', L, y, { lineBreak: false }); y += 14;
      for (const s of n.regional) story(`${s.region} · ${s.headline}`, s.source, s.summary, `CRM action: ${s.action}`, RED, s.link);
    }
    doc.font(F.r).fontSize(6.5).fillColor(STEEL).text('Headlines and links come from Google News searches of the trade sites; the AI only selects and comments. Click a headline to open it.', L, PH - 38, { width: CW, lineBreak: false });
  }
  doc.end();
  return done;
}

// ---- sending --------------------------------------------------------------------------------------------------------------------
// The people who get the brief: export people for now (domestic can be added later by changing this one line).
const wanted = (u: PublicUser) => !u.is_assistant && !u.assists_id && !!u.is_active && u.market !== 'domestic';

export async function sendBriefs(only?: number[], forceTest = false): Promise<{ sent: string[]; skipped: string[] }> {
  const sent: string[] = [];
  const skipped: string[] = [];
  const testTo = forceTest || settingsModel.get('test_mode') === '1' ? settingsModel.get('test_email') || null : null;
  for (const u of userModel.listAll().filter((x) => wanted(x) && (!only || only.includes(x.id)))) {
    const label = u.display_name ?? u.username;
    if (!u.email) { skipped.push(`${label} (no e-mail address)`); continue; }
    try {
      const d = await gatherBrief({ id: u.id, role: u.role, display_name: u.display_name }, true);
      if (!d.per.length && !d.todos.length && !d.asks.totals.payment && !d.asks.totals.order) { skipped.push(`${label} (nothing to report)`); continue; }
      const pdf = await renderBriefPdf(d);
      const body = [`Good morning ${label.split(' ')[0]},`, '', d.headline, '', ...d.focus.map((f) => `- ${f}`), '', 'Your two-page brief is attached, ready to print: the money to ask for, the orders to chase, how the year is going, your to-do list and the people to call.'].join('\n');
      await sendThankYouEmail({
        to: u.email, subject: `Your daily brief - ${dmy(d.date)}`, body,
        attachments: [{ filename: `TECE-brief-${d.date}.pdf`, content: pdf, contentType: 'application/pdf' }],
        signature: { text: 'TECE customer system', html: '<div style="font-family:Arial,sans-serif;color:#5e6676;font-size:12px">TECE customer system</div>' },
        testTo: testTo ? (forceTest ? u.email || testTo : testTo) : null,
      });
      sent.push(label);
    } catch (err) {
      console.error('Daily brief failed for', label, err);
      skipped.push(`${label} (${(err as Error).message})`);
    }
  }
  return { sent, skipped };
}

// Every working day at 8:30 (Istanbul time). If the server was off at 8:30 it still goes out before noon.
export function startBriefScheduler(): void {
  const tick = async () => {
    try {
      if (settingsModel.get('daily_brief') === '0') return;
      const parts = new Intl.DateTimeFormat('en-GB', { timeZone: TZ, hour: '2-digit', minute: '2-digit', hour12: false, weekday: 'short' }).formatToParts(new Date());
      const get = (t: string) => parts.find((p) => p.type === t)?.value ?? '';
      const minutes = parseInt(get('hour'), 10) * 60 + parseInt(get('minute'), 10);
      const [h, m] = (settingsModel.get('daily_brief_time') ?? '08:30').split(':').map((x) => parseInt(x, 10));
      const at = (h || 0) * 60 + (m || 0);
      const today = todayLocal();
      if (['Sat', 'Sun'].includes(get('weekday')) || minutes < at || minutes > 12 * 60 || settingsModel.get('daily_brief_last') === today) return;
      settingsModel.set('daily_brief_last', today);
      const r = await sendBriefs();
      console.log(`Daily brief ${today}: sent to ${r.sent.join(', ') || 'nobody'}${r.skipped.length ? `; skipped ${r.skipped.join(', ')}` : ''}`);
    } catch (err) {
      console.error('Daily brief failed:', err);
    }
  };
  setInterval(tick, 2 * 60 * 1000).unref();
}
