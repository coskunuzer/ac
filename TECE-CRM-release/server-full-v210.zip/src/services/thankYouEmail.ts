import nodemailer from 'nodemailer';
import { env } from '../config/env';
import type { CardRow } from '../models/cardModel';
import type { Signature } from './signature';
import { emailTemplateModel, type TemplateKind } from '../models/emailTemplateModel';
import { offerLogModel } from '../models/pricingModels';
import { followUpSentence, parseInsight } from './aiInsight';
import { distributorModel } from '../models/distributorModel';
import { languageOf } from './offerLanguage';
import { db } from '../db/connection';
import { cleanName, fairNameOfCard, mailProblems, MailBlockedError, realFairName } from './emailSafety';

export interface EmailTemplate {
  subject: string;
  body: string;
}

interface TemplateContext {
  card: CardRow;
  fairName: string | null;
}

// Placeholders a staff member can use in their own custom template (set on
// their user account) - kept intentionally small and named after the card
// fields staff already see on the Review page, not a general templating
// engine. {{fair}} resolves from the card's actual linked exhibition, not
// the deprecated free-text "Fair" field (removed from extraction/UI since
// it duplicated the exhibition already selected before upload).
const PLACEHOLDERS: Record<string, (ctx: TemplateContext) => string> = {
  '{{name}}': ({ card }) => cleanName(card.name) || 'there',
  '{{company}}': ({ card }) => cleanName(card.company),
  '{{fair}}': ({ fairName }) => realFairName(fairName) || 'our stand',
  '{{person}}': ({ card }) => cleanName(card.person) || 'the tece team',
  // sentence pieces that vanish cleanly when the card has no company / fair
  '{{greeting}}': ({ card }) => greetingIn(card),
  '{{at_fair}}': ({ fairName }) => (realFairName(fairName) ? ` at ${realFairName(fairName)}` : ''),
  '{{about_company}}': ({ card }) => (cleanName(card.company) ? ` and learning more about ${cleanName(card.company)}` : ''),
  '{{for_company}}': ({ card }) => (cleanName(card.company) ? ` for ${cleanName(card.company)}` : ''),
  // the distributor of the visitor's country (only used by the referral text)
  '{{country}}': ({ card }) => card.country || 'your country',
  '{{distributor}}': ({ card }) => distributorModel.forCard(card)?.name ?? '',
  '{{distributor_phone}}': ({ card }) => distributorModel.forCard(card)?.phone ?? '',
  '{{distributor_email}}': ({ card }) => distributorModel.forCard(card)?.email ?? '',
  '{{distributor_notes}}': ({ card }) => distributorModel.forCard(card)?.notes ?? '',
  // "We will send you our offer for ABS shortly." when the notes ask for one, otherwise the general line
  '{{follow_up_line}}': ({ card }) => followUpLine(card) ?? GENERIC_FOLLOW_UP,
};

// "Dear Ali," in the language of the customer
const GREETING: Record<string, [string, string]> = {
  en: ['Dear {name},', 'Hello,'],
  tr: ['Sayın {name},', 'Merhaba,'],
  ru: ['Уважаемый(ая) {name},', 'Здравствуйте,'],
  es: ['Estimado/a {name},', 'Hola,'],
  fr: ['Bonjour {name},', 'Bonjour,'],
};
function greetingIn(card: CardRow): string {
  const g = GREETING[languageOf(card)] ?? GREETING.en;
  const name = cleanName(card.name);
  return name ? g[0].replace('{name}', name) : g[1];
}

const GENERIC_FOLLOW_UP = 'We will follow up shortly with any further information you asked for.';

function offerSentTo(cardId: number): boolean {
  return offerLogModel.offerSentTo(cardId);
}

// What the AI read in the notes: an offer is wanted and has not gone out yet.
function followUpLine(card: CardRow): string | null {
  // the tick "send an offer" on the record decides; without it, what the AI read in the notes
  return followUpSentence(parseInsight(card.ai_insight), offerSentTo(card.id), card.send_offer === null || card.send_offer === undefined ? null : card.send_offer === 1);
}

// A text without {{follow_up_line}} (the admin's own wording) still promises the offer: the
// sentence goes in before the sign-off.
function withOfferPromise(t: EmailTemplate, card: CardRow): EmailTemplate {
  const line = followUpLine(card);
  if (!line || /\boffer\b/i.test(t.body)) return t;
  // the general "we will follow up" sentence is replaced, not repeated
  if (t.body.includes(GENERIC_FOLLOW_UP)) return { subject: t.subject, body: t.body.split(GENERIC_FOLLOW_UP).join(line) };
  const paragraphs = t.body.split(/\n{2,}/);
  const at = Math.max(1, paragraphs.length - 1);
  paragraphs.splice(at, 0, line);
  return { subject: t.subject, body: paragraphs.join('\n\n') };
}

export function interpolateTemplate(template: EmailTemplate, ctx: TemplateContext): EmailTemplate {
  let subject = template.subject;
  let body = template.body;
  for (const [placeholder, resolve] of Object.entries(PLACEHOLDERS)) {
    const value = resolve(ctx);
    subject = subject.split(placeholder).join(value);
    body = body.split(placeholder).join(value);
  }
  return { subject, body };
}

const greeting = (card: CardRow) => greetingIn(card);

// The sign-off ("Best wishes") ends the text; the sender's signature (name,
// title, phones, company lines) is added below it when the email is sent.
export function buildDefaultTemplate(card: CardRow, fairNameRaw: string | null): EmailTemplate {
  // "Direct contacts" and "Domestic customers" are not fairs: the text then names no fair
  const fairName = realFairName(fairNameRaw);
  const company = cleanName(card.company);
  const subject = `Thank you for visiting TECE${fairName ? ` at ${fairName}` : ''}`;
  const meeting = company
    ? `It was a pleasure meeting you and learning more about ${company}.`
    : 'It was a pleasure meeting you.';

  const body = `${greeting(card)}

Thank you for visiting our stand${fairName ? ` at ${fairName}` : ''}. ${meeting}

${followUpLine(card) ?? GENERIC_FOLLOW_UP} In the meantime, please do not hesitate to contact me if you have any questions.

Best wishes`;

  return { subject, body };
}

// The offer goes out as its own email. The line saying what is attached is
// added by the screen, between the first and the last paragraph.
export function buildOfferTemplate(card: CardRow): EmailTemplate {
  const subject = `Your TECE edgebanding offer${cleanName(card.company) ? ` - ${cleanName(card.company)}` : ''}`;
  const body = `${greeting(card)}

Thank you for your interest in TECE edgebanding.

If you would like samples, or would like us to adjust anything in the offer, please let me know. I will be glad to help.

Best wishes`;
  return { subject, body };
}

function isComplete(t: EmailTemplate | null): t is EmailTemplate {
  return !!t && !!t.subject && !!t.body;
}

// Priority: a staff member's own personal template (their user account)
// wins first, since that's their own voice/signature. Next, the exhibition's
// own template (set under Manage Fairs) - lets the same event's messaging
// differ from other events without every staff member having to remember to
// customize their personal template each time. Falls back to the generic
// hardcoded default when neither is set.
// The automatic reply for a visitor from a country that has a distributor: whoever the sender
// is, the visitor is directed to the distributor.
export function distributorReferral(card: CardRow, fairName: string | null): EmailTemplate | null {
  if (!distributorModel.forCard(card)) return null;
  const filled = interpolateTemplate(distributorModel.referralText(), { card, fairName });
  // a line that came out empty (a distributor without notes) leaves no gap
  return { subject: filled.subject, body: filled.body.replace(/\n{3,}/g, '\n\n').replace(/(\n(Phone|Email): )\n/g, '\n') };
}

export function resolveTemplate(
  card: CardRow,
  fairName: string | null,
  personalTemplate: EmailTemplate | null,
  exhibitionTemplate: EmailTemplate | null = null
): EmailTemplate {
  const referral = distributorReferral(card, fairName);
  if (referral) return referral;
  const template = isComplete(personalTemplate)
    ? personalTemplate
    : isComplete(exhibitionTemplate)
      ? exhibitionTemplate
      : null;
  if (template) {
    return withOfferPromise(interpolateTemplate(template, { card, fairName }), card);
  }
  const fromLibrary = resolveFromLibrary('thank_you', card, fairName);
  // the "we will send you the offer" sentence is English: it is not added to a text the admin wrote in another language
  return fromLibrary ? (fromLibrary.translated ? { subject: fromLibrary.subject, body: fromLibrary.body } : withOfferPromise(fromLibrary, card)) : buildDefaultTemplate(card, fairName);
}

// The text of a row in the language of the customer (the admin's translation), else the English one.
function textOf(row: { id: number; subject: string; body: string }, card: CardRow): EmailTemplate & { translated: boolean } {
  const lang = languageOf(card);
  const tr = lang === 'en' ? undefined : emailTemplateModel.translation(row.id, lang);
  return tr ? { subject: tr.subject, body: tr.body, translated: true } : { subject: row.subject, body: row.body, translated: false };
}

// The admin's default text of this kind (Admin > Email texts), filled in for this customer.
function resolveFromLibrary(kind: TemplateKind, card: CardRow, fairName: string | null): (EmailTemplate & { translated?: boolean }) | null {
  const row = emailTemplateModel.defaultFor(kind);
  if (!row) return null;
  const { translated, ...text } = textOf(row, card);
  return { ...interpolateTemplate(text, { card, fairName }), translated };
}

export function resolveOfferTemplate(card: CardRow, fairName: string | null): EmailTemplate {
  const found = resolveFromLibrary('offer', card, fairName);
  return found ? { subject: found.subject, body: found.body } : buildOfferTemplate(card);
}

// Every text the admin offers, filled in for this customer, so staff can switch on the send page.
export function templateChoices(card: CardRow, fairName: string | null): Record<TemplateKind, { id: number; name: string; isDefault: boolean; subject: string; body: string }[]> {
  const fill = (kind: TemplateKind) =>
    emailTemplateModel.list(kind).map((row) => {
      const { translated, ...text } = textOf(row, card);
      const filled = interpolateTemplate(text, { card, fairName });
      return {
        id: row.id,
        name: row.name,
        isDefault: !!row.is_default,
        ...(kind === 'thank_you' && !translated ? withOfferPromise(filled, card) : filled),
      };
    });
  const thank = fill('thank_you');
  const referral = distributorReferral(card, fairName);
  if (referral) {
    const d = distributorModel.forCard(card)!;
    return {
      thank_you: [{ id: -1, name: `Distributor referral (${d.name})`, isDefault: true, ...referral }, ...thank.map((t) => ({ ...t, isDefault: false }))],
      offer: fill('offer'),
    };
  }
  return { thank_you: thank, offer: fill('offer') };
}

export interface EmailAttachment {
  filename: string;
  content?: Buffer;
  path?: string;
  contentType?: string;
}

const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

// Plain text to simple HTML: blank lines separate paragraphs, lines starting
// with "- " become a bullet list, single line breaks stay line breaks.
export function bodyToHtml(body: string): string {
  const style = 'font-family:Calibri,Arial,sans-serif;font-size:14px;color:#17243e;line-height:1.5;margin:0 0 12px';
  return body
    .split(/\n{2,}/)
    .map((block) => {
      const lines = block.split('\n');
      if (lines.every((l) => l.startsWith('- '))) {
        return `<ul style="${style}">${lines.map((l) => `<li>${esc(l.slice(2))}</li>`).join('')}</ul>`;
      }
      // a lead-in line followed by bullets ("Please find attached:" then "- ...")
      const firstBullet = lines.findIndex((l) => l.startsWith('- '));
      if (firstBullet > 0 && lines.slice(firstBullet).every((l) => l.startsWith('- '))) {
        return (
          `<p style="${style}">${lines.slice(0, firstBullet).map(esc).join('<br>')}</p>` +
          `<ul style="${style}">${lines.slice(firstBullet).map((l) => `<li>${esc(l.slice(2))}</li>`).join('')}</ul>`
        );
      }
      return `<p style="${style}">${lines.map(esc).join('<br>')}</p>`;
    })
    .join('');
}

// Sends the email from the company mailbox, but replies go to the person who
// sent it (replyTo), and their signature is added under the text.
export async function sendThankYouEmail(input: {
  to: string;
  cc?: string | string[] | null;
  subject: string;
  body: string;
  attachments?: EmailAttachment[];
  replyTo?: string | null;
  signature?: Signature | null;
  // the text written in the rich editor (already cleaned): it is the e-mail body, `body` is then only its plain-text twin
  bodyHtml?: string;
  // ready HTML put under the text (a table of transactions), before the signature
  extraHtml?: string;
  // test: everything goes to this one address instead, marked as a test
  testTo?: string | null;
  // keep the e-mail in the history (the customer page lists them); nothing is kept for a test
  record?: { cardId?: number | null; userId?: number | null; kind: string; sap?: string | null } | null;
}): Promise<void> {
  // the safety check: an e-mail with a hole in it, or a thank-you for a "fair" that is not one, does not leave
  const problems = mailProblems({
    subject: input.subject,
    // what the reader sees: the plain text; an e-mail written in the rich editor is checked on its text twin too
    body: input.body,
    kind: input.record?.kind ?? null,
    fairName: input.record?.kind === 'thank_you' ? fairNameOfCard(input.record.cardId) : null,
  });
  if (problems.length) throw new MailBlockedError(problems);

  if (input.testTo) {
    const real = [`To: ${input.to}`, input.cc ? `CC: ${Array.isArray(input.cc) ? input.cc.join(', ') : input.cc}` : ''].filter(Boolean).join('   ');
    input = {
      ...input,
      to: input.testTo,
      cc: null,
      subject: `[TEST] ${input.subject}`,
      body: `TEST - this e-mail would have gone to:  ${real}\nNothing was recorded as sent.\n\n----------\n\n${input.body}`,
    };
  }
  if (!env.smtp.host || !env.smtp.user || !env.smtp.password) {
    throw new Error('SMTP is not configured on the server (SMTP_HOST/SMTP_USER/SMTP_PASSWORD)');
  }

  const transport = nodemailer.createTransport({
    host: env.smtp.host,
    port: env.smtp.port,
    secure: env.smtp.port === 465,
    auth: { user: env.smtp.user, pass: env.smtp.password },
  });

  const text = input.signature ? `${input.body.trimEnd()}\n\n${input.signature.text}` : input.body;
  const testNote = input.testTo && input.bodyHtml ? `<p style="background:#fff3cd;padding:8px"><b>TEST</b> - nothing was recorded as sent.</p>` : '';
  const html = input.bodyHtml
    ? `${testNote}<div style="font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.6;color:#1b2a41">${input.bodyHtml}</div>${input.extraHtml ?? ''}${input.signature?.html ?? ''}`
    : input.signature || input.extraHtml ? `${bodyToHtml(input.body.trimEnd())}${input.extraHtml ?? ''}${input.signature?.html ?? ''}` : undefined;

  await transport.sendMail({
    from: env.smtp.from || env.smtp.user,
    replyTo: input.replyTo || undefined,
    to: input.to,
    cc: input.cc || undefined,
    subject: input.subject,
    text,
    html,
    attachments: input.attachments,
  });

  // every e-mail that really left is kept: who sent it, to whom, what it said and which files went with it
  if (input.record && !input.testTo) {
    try {
      const cc = Array.isArray(input.cc) ? input.cc.join(', ') : input.cc ?? '';
      const internal = input.to.split(/[,;]+/).map((a) => a.trim()).filter(Boolean).every((a) => /@tece\.com\.tr$/i.test(a)) ? 1 : 0;
      db.prepare('INSERT INTO sent_emails (card_id, user_id, kind, internal, to_addr, cc_addr, subject, body, attachments, sap) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
        .run(input.record.cardId ?? null, input.record.userId ?? null, input.record.kind, internal, input.to, cc || null, input.subject, text, (input.attachments ?? []).map((a) => a.filename).filter(Boolean).join(', ') || null, input.record.sap ?? null);
    } catch (err) {
      console.error('The e-mail was sent but could not be recorded:', err);
    }
  }
}
