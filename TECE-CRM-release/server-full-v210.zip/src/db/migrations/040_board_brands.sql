-- The board producers (Kronospan, Egger ...) a customer works with: a tag on the customer, and a filter in the customer list.
CREATE TABLE IF NOT EXISTS board_brands (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE COLLATE NOCASE
);
CREATE TABLE IF NOT EXISTS card_boards (
  card_id INTEGER NOT NULL REFERENCES cards(id) ON DELETE CASCADE,
  brand_id INTEGER NOT NULL REFERENCES board_brands(id) ON DELETE CASCADE,
  PRIMARY KEY (card_id, brand_id)
);
CREATE INDEX IF NOT EXISTS idx_card_boards_brand ON card_boards (brand_id);
