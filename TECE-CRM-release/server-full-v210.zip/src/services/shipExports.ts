import { db } from '../db/connection';
import { isInvoiceText } from './perfAnalytics';
import { asc } from './shipPlaces';
import { todayIstanbul, todoModel } from './todos';

// The latest exports, from the ledger (every "cikis ..." invoice line), and whether the documents of each were sent. "Sent" is found in the CRM's own record of sent e-mails
// (to that customer, after the invoice date); what went out of Outlook is marked by hand. Nothing is deleted: a mark can always be changed.
export interface ExportRow {
  key: string; date: string; days: number; sheet: string; sap: string | null; customer: string; country: string | null; cardId: number | null;
  invoice: string; amount: number; currency: string;
  docs: { state: 'sent' | 'probable' | 'none' | 'ignored' | 'working'; by?: string | null; how?: 'crm' | 'manual'; at?: string | null; to?: string | null; files?: string[]; note?: string | null; mailId?: number | null; subject?: string | null };
  late: boolean;
  request: { id: string; status: string; forwarder: string | null; price: string | null } | null;
}
const invoiceNo = (d: string): string => (/[A-Za-zİıÇçŞşĞğÜüÖö]{0,4}\s?\d{6,}/.exec(d)?.[0] ?? d).replace(/\s+/g, '').slice(0, 24);
const digits = (s: string) => (s.match(/\d{6,}/g) ?? []);

const userName = (id: number | null): string | null => (id ? ((db.prepare('SELECT COALESCE(display_name, username) AS n FROM users WHERE id = ?').get(id) as { n: string } | undefined)?.n ?? null) : null);
// The same list is asked for several times by one page (the dashboard, the customer pages, the sales panel): it is kept for 20 seconds and thrown away at once when a mark changes.
type Exports = { rows: ExportRow[]; lastLedger: string | null };
const cache = new Map<string, { at: number; v: Exports }>();
export const forgetExports = (): void => cache.clear();
export function latestExports(days: number, lateDays: number): Exports {
  const k = days + '|' + lateDays;
  const hit = cache.get(k);
  if (hit && Date.now() - hit.at < 20_000) return hit.v;
  const v = latestExportsRaw(days, lateDays);
  cache.set(k, { at: Date.now(), v });
  return v;
}
function latestExportsRaw(days: number, lateDays: number): Exports {
  const today = new Date().toISOString().slice(0, 10);
  const lines = db.prepare(
    `SELECT t.sheet_name, t.tx_date, t.description, t.debit, t.currency, a.sap_no, s.name AS sname, s.country AS scountry
       FROM ledger_transactions t LEFT JOIN customer_aliases a ON a.sheet_name = t.sheet_name LEFT JOIN sap_customers s ON s.sap_no = a.sap_no
      WHERE t.debit > 0 AND t.tx_date <= ? AND t.tx_date >= date(?, ?) ORDER BY t.tx_date DESC, t.id DESC`
  ).all(today, today, `-${Math.max(1, Math.min(400, days))} days`) as unknown as { sheet_name: string; tx_date: string; description: string | null; debit: number; currency: string; sap_no: string | null; sname: string | null; scountry: string | null }[];
  const cards = new Map((db.prepare("SELECT id, TRIM(sap) AS sap, company, country FROM cards WHERE sap IS NOT NULL AND TRIM(sap) != ''").all() as { id: number; sap: string; company: string | null; country: string | null }[]).map((c) => [c.sap, c]));
  const marks = new Map((db.prepare('SELECT * FROM ship_export_docs').all() as unknown as { invoice_key: string; status: string; how: string | null; at: string | null; user_id: number | null; to_addr: string | null; files: string | null; note: string | null; mail_id: number | null }[]).map((m) => [m.invoice_key, m]));
  const q = db.prepare("SELECT id, kind, to_addr, subject, body, attachments, sent_at FROM sent_emails WHERE card_id = ? AND kind IN ('documents', 'personal', 'email') AND sent_at >= ? ORDER BY sent_at");
  const reqs = db.prepare("SELECT r.id, r.status, r.card_id, r.created_at, (SELECT forwarder_name || '|' || COALESCE(total, '') || ' ' || COALESCE(currency, '') FROM ship_quotes WHERE id = r.accepted_quote) AS acc FROM ship_requests r WHERE r.archived = 0 AND r.card_id IS NOT NULL").all() as { id: string; status: string; card_id: number; created_at: string; acc: string | null }[];

  const rows: ExportRow[] = [];
  for (const l of lines) {
    if (!isInvoiceText(l.description)) continue;
    const key = `${l.sheet_name}|${l.tx_date}|${l.description ?? ''}`;
    const sap = l.sap_no?.trim() ?? null;
    const card = sap ? cards.get(sap) : undefined;
    const no = invoiceNo(l.description ?? '');
    const age = Math.round((Date.parse(`${today}T12:00:00Z`) - Date.parse(`${l.tx_date}T12:00:00Z`)) / 86400000);
    let docs: ExportRow['docs'] = { state: 'none' };
    const mk = marks.get(key);
    // 'ignored' = do not follow: the sales person sends the documents; 'working' = Operations took it ("Belgeleri gönder") and has a reminder until it is marked sent
    if (mk?.status === 'sent') docs = { state: 'sent', how: mk.how === 'crm' ? 'crm' : 'manual', at: mk.at, to: mk.to_addr, files: (mk.files ?? '').split(', ').filter(Boolean), note: mk.note, mailId: mk.mail_id };
    else if (mk?.status === 'ignored') docs = { state: 'ignored', note: mk.note };
    else if (card) {
      const found = (q.all(card.id, `${l.tx_date} 00:00:00`) as unknown as { id: number; kind: string; to_addr: string | null; subject: string | null; body: string | null; attachments: string | null; sent_at: string }[])
        .filter((m) => m.sent_at.slice(0, 10) <= new Date(Date.parse(`${l.tx_date}T12:00:00Z`) + 21 * 86400000).toISOString().slice(0, 10) && !(mk?.note ?? '').includes(`not:${m.id}`));
      const strong = found.find((m) => digits(`${m.subject ?? ''} ${m.body ?? ''} ${m.attachments ?? ''}`).some((d) => no.includes(d) || d.includes(no.replace(/\D/g, '')) && no.replace(/\D/g, '').length >= 6));
      const likely = found.find((m) => m.kind === 'documents' || /invoice|fatura|packing|cmr|ceki|eur\.?1|origin/.test(asc(`${m.subject ?? ''} ${m.attachments ?? ''}`)));
      const hit = strong ?? likely;
      if (hit) docs = { state: strong ? 'sent' : 'probable', how: 'crm', at: hit.sent_at, to: hit.to_addr, files: (hit.attachments ?? '').split(', ').filter(Boolean), mailId: hit.id, subject: hit.subject };
    }
    if (mk?.status === 'working' && (docs.state === 'none' || docs.state === 'probable')) docs = { state: 'working', at: mk.at, by: userName(mk.user_id), note: mk.note };
    const rq = card ? reqs.filter((r) => r.card_id === card.id && Math.abs(Date.parse(`${r.created_at.slice(0, 10)}T12:00:00Z`) - Date.parse(`${l.tx_date}T12:00:00Z`)) <= 30 * 86400000)[0] : undefined;
    rows.push({
      key, date: l.tx_date, days: age, sheet: l.sheet_name, sap, customer: card?.company ?? l.sname ?? l.sheet_name, country: card?.country ?? l.scountry ?? null, cardId: card?.id ?? null,
      invoice: no, amount: l.debit, currency: l.currency, docs, late: docs.state === 'none' && age > lateDays,
      request: rq ? { id: rq.id, status: rq.status, forwarder: rq.acc ? rq.acc.split('|')[0] : null, price: rq.acc ? rq.acc.split('|')[1] : null } : null,
    });
  }
  const last = (db.prepare('SELECT MAX(at) AS at FROM perf_uploads WHERE kind = ?').get('ledger') as { at: string | null } | undefined)?.at ?? null;
  return { rows, lastLedger: last };
}

export function markExport(key: string, userId: number, input: { status: 'sent' | 'none' | 'ignored' | 'working'; how?: 'crm' | 'manual'; note?: string | null; mailId?: number | null; to?: string | null; files?: string[]; notMail?: number | null; log?: { action: string; role: string; customer?: string; invoice?: string } }): void {
  forgetExports();
  const prev = db.prepare('SELECT note FROM ship_export_docs WHERE invoice_key = ?').get(key) as { note: string | null } | undefined;
  const note = [input.note ?? (input.notMail ? '' : prev?.note ?? ''), input.notMail ? `not:${input.notMail}` : ''].filter(Boolean).join(' ').trim() || null;
  db.prepare("INSERT INTO ship_export_docs (invoice_key, status, how, at, user_id, to_addr, files, note, mail_id, updated_at) VALUES (?, ?, ?, datetime('now'), ?, ?, ?, ?, ?, datetime('now')) ON CONFLICT(invoice_key) DO UPDATE SET status = excluded.status, how = excluded.how, at = excluded.at, user_id = excluded.user_id, to_addr = excluded.to_addr, files = excluded.files, note = excluded.note, mail_id = excluded.mail_id, updated_at = datetime('now')")
    .run(key, input.status, input.how ?? null, userId, input.to ?? null, (input.files ?? []).join(', ') || null, note, input.mailId ?? null);
  // every move is written down for good (the log is never changed or deleted)
  const action = input.log?.action ?? (input.status === 'working' ? 'taken' : input.status === 'sent' ? 'sent' : input.status === 'ignored' ? 'handed_to_sales' : 'cleared');
  const role = input.log?.role ?? ((db.prepare('SELECT role FROM users WHERE id = ?').get(userId) as { role: string } | undefined)?.role === 'admin' ? 'admin' : 'operations');
  db.prepare('INSERT INTO ship_doc_log (invoice_key, customer, invoice, action, by_role, user_id, note) VALUES (?, ?, ?, ?, ?, ?, ?)').run(key, input.log?.customer ?? key.split('|')[0] ?? null, input.log?.invoice ?? null, action, role, userId, note);
}
// "Belgeleri gönder": the Operations person takes the documents of one export. A reminder (a to-do for today) is made for them and stays until the documents are marked sent.
const reminderText = (customer: string, invoice: string) => `Belgeleri gönder: ${customer} - fatura ${invoice}`;
export function takeExport(key: string, userId: number, row: { customer: string; invoice: string; cardId: number | null }): void {
  forgetExports();
  markExport(key, userId, { status: 'working', log: { action: 'taken', role: 'operations', customer: row.customer, invoice: row.invoice } });
  const text = reminderText(row.customer, row.invoice);
  const open = db.prepare('SELECT id FROM todos WHERE user_id = ? AND text = ? AND done_at IS NULL').get(userId, text);
  if (!open) todoModel.add({ userId, cardId: row.cardId, text, dueDate: todayIstanbul() });
}
// when the documents are marked sent (or handed back to Sales), the reminder is done
export function closeReminder(row: { customer: string; invoice: string }): void {
  forgetExports();
  db.prepare("UPDATE todos SET done_at = datetime('now') WHERE text = ? AND done_at IS NULL").run(reminderText(row.customer, row.invoice));
}
// every day an unfinished one is moved to today, so it is seen each time the account is opened
export function rollReminders(): void {
  db.prepare("UPDATE todos SET due_date = ? WHERE text LIKE 'Belgeleri gönder: %' AND done_at IS NULL AND due_date < ?").run(todayIstanbul(), todayIstanbul());
}

export const lateExportCount = (lateDays: number): number => latestExports(30, lateDays).rows.filter((r) => r.late).length;
