CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('admin','user')),
  display_name TEXT,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS exhibitions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  location TEXT,
  start_date TEXT,
  end_date TEXT,
  is_archived INTEGER NOT NULL DEFAULT 0,
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS cards (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  exhibition_id INTEGER NOT NULL REFERENCES exhibitions(id),
  uploaded_by INTEGER NOT NULL REFERENCES users(id),
  image_path TEXT NOT NULL,
  name TEXT,
  company TEXT,
  address TEXT,
  country TEXT,
  tel TEXT,
  email TEXT,
  interested_in TEXT,
  work_area TEXT,
  fair TEXT,
  form_date TEXT,
  person TEXT,
  rate INTEGER,
  notes TEXT,
  field_status TEXT NOT NULL DEFAULT '{}',
  extraction_model TEXT,
  status TEXT NOT NULL CHECK (status IN ('needs_review','confirmed')) DEFAULT 'needs_review',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_cards_exhibition ON cards(exhibition_id);
CREATE INDEX IF NOT EXISTS idx_cards_uploaded_by ON cards(uploaded_by);
