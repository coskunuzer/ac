import fs from 'fs';
import path from 'path';
import { paths } from '../config/env';
import { cardModel, type CardRow } from '../models/cardModel';
import { exhibitionModel } from '../models/exhibitionModel';
import { offerLogModel } from '../models/pricingModels';
import { followUpFor } from './followUp';
import { parseInsight } from './aiInsight';
import { priceHistoryText } from './priceHistory';
import { activityModel } from '../models/activityModel';
import { interestLabel, widthsLabel } from './interest';

// data/customer-files/<sales person>/<exhibition>/<customer> [id]/
//    Scan.jpg            the photographed form (shrunk)
//    details.txt         what we know about them and what was sent
//    Offers/             every offer that was sent, as the PDF the customer got
const ROOT = paths.customerFilesDir;

// File-system safe, but still readable ("Çağdaş Ltd. Şti." stays as it is).
export function safeName(value: string, max = 80): string {
  const cleaned = value
    .normalize('NFC')
    // eslint-disable-next-line no-control-regex
    .replace(/[\\/:*?"<>|\u0000-\u001f]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  return cleaned.slice(0, max).trim().replace(/[. ]+$/, '');
}

const abs = (rel: string) => path.join(ROOT, rel);
const inside = (p: string) => path.resolve(p).startsWith(path.resolve(ROOT) + path.sep);

export const NO_PERSON_FOLDER = 'No sales person yet';

// One folder per sales person, so a whole folder can be zipped and handed over.
function desiredRel(card: CardRow): string {
  const person = safeName(card.person ?? '') || NO_PERSON_FOLDER;
  const fair = safeName(exhibitionModel.findById(card.exhibition_id)?.name ?? '') || `Exhibition ${card.exhibition_id}`;
  // country first, so a person's folder sorts by country
  const who = safeName([card.country, card.company || card.name].filter(Boolean).join(' - ')) || 'Customer';
  // the id keeps two customers with the same name apart
  return path.join(person, fair, `${who} [${card.id}]`);
}

// Removes an empty folder and the empty folders above it (up to the top).
function pruneEmpty(dir: string): void {
  try {
    let current = dir;
    while (inside(current) && fs.existsSync(current) && fs.readdirSync(current).length === 0) {
      fs.rmdirSync(current);
      current = path.dirname(current);
    }
  } catch {
    /* leave it */
  }
}

function detailsText(card: CardRow): string {
  const fair = exhibitionModel.findById(card.exhibition_id)?.name ?? '';
  const entries = offerLogModel.listForCard(card.id);
  const follow = followUpFor(card, entries);
  const insight = parseInsight(card.ai_insight);
  const pct = (n: number | null) => (n === null ? '' : n === 0 ? 'list price' : `${n > 0 ? '+' : '-'}${Math.round(Math.abs(n) * 1000) / 10} %`);
  const lines = [
    `Exhibition:   ${fair}`,
    `Name:         ${card.name ?? ''}`,
    `Company:      ${card.company ?? ''}`,
    `Position:     ${card.position ?? ''}`,
    `Address:      ${card.address ?? ''}`,
    `Country:      ${card.country ?? ''}`,
    `Tel:          ${card.tel ?? ''}`,
    `Email:        ${card.email ?? ''}`,
    `Interested:   ${interestLabel(card)}`,
    `Edge widths:  ${widthsLabel(card)}`,
    `Work area:    ${card.work_area ?? ''}`,
    `Met by:       ${card.person ?? ''}`,
    `Rate:         ${card.rate ?? ''}`,
    `Discount / addition set on scan: ${pct(card.offer_percent) || 'none'}`,
    `Recorded:     ${card.created_at} (UTC)`,
    '',
    'Notes:',
    card.notes ?? '',
    '',
    ...(insight
      ? [
          'About the company (the AI):',
          ...[insight.companyType, insight.companyProfile, insight.websiteSummary ? `Web site: ${insight.websiteSummary}` : null, insight.website ? `Address: ${insight.website}` : null, insight.approach ? `How to approach: ${insight.approach}` : null].filter(Boolean).map((l) => `  ${l}`),
          '',
        ]
      : []),
    `Offer wanted: ${card.send_offer === 1 ? 'yes (confirmed)' : card.send_offer === 0 ? 'no' : insight?.sendOffer ? 'suggested by the AI' : 'not asked'}`,
    `Follow-up:    ${follow.label}`,
    ...entries
      .slice()
      .reverse()
      .map((e) => {
        const what = e.kind === 'offer' ? `price offer ${pct(e.percent)}` : e.kind === 'documents' ? 'documents' : e.kind === 'personal' ? 'personal e-mail' : 'thank-you note';
        const pages = e.kind === 'offer' ? ` - ${e.pages.map((p) => p.title).join(', ')}${e.includeMoq ? ', MOQ pages' : ''}` : '';
        const files = e.attachments.length ? ` + ${e.attachments.join(', ')}` : '';
        return `  ${e.sentAt} UTC  ${what}${pages}${files}${e.sentBy ? `  (by ${e.sentBy})` : ''}`;
      }),
  ];
  return lines.join('\n') + '\n';
}

// Creates or moves the customer's folder (the name may have changed) and
// refreshes the scan and details in it. Returns the folder, or null on failure
// - this is a convenience copy, so it never stops the app from working.
export function syncCustomerFolder(cardId: number): string | null {
  try {
    const card = cardModel.findById(cardId);
    if (!card) return null;
    const rel = desiredRel(card);
    const target = abs(rel);

    if (card.archive_dir && card.archive_dir !== rel) {
      const old = abs(card.archive_dir);
      if (inside(old) && fs.existsSync(old) && !fs.existsSync(target)) {
        fs.mkdirSync(path.dirname(target), { recursive: true });
        fs.renameSync(old, target);
        pruneEmpty(path.dirname(old));
      }
    }
    fs.mkdirSync(target, { recursive: true });
    if (card.archive_dir !== rel) cardModel.setArchiveDir(card.id, rel);

    const source = path.join(paths.uploadsDir, card.image_path);
    if (card.image_path && fs.existsSync(source)) {
      const ext = path.extname(card.image_path).toLowerCase() || '.jpg';
      const dest = path.join(target, `Scan${ext}`);
      for (const f of fs.readdirSync(target)) {
        if (/^Scan\./i.test(f) && f !== `Scan${ext}`) fs.unlinkSync(path.join(target, f));
      }
      if (!fs.existsSync(dest) || fs.statSync(dest).size !== fs.statSync(source).size) fs.copyFileSync(source, dest);
    }
    fs.writeFileSync(path.join(target, 'details.txt'), detailsText(card), 'utf8');
    // the notes and what was done with this customer, with the photos of the notes
    const acts = activityModel.forCard(card.id, 500);
    if (acts.length) {
      const notesDir = path.join(target, 'Notes');
      fs.mkdirSync(notesDir, { recursive: true });
      const lines = acts.slice().reverse().map((a) => `${a.at.slice(0, 16)} UTC  ${a.userName ?? ''}  [${a.type}]  ${(a.text ?? '').replace(/\s+/g, ' ')}${a.photos.length ? `  (photos: ${a.photos.join(', ')})` : ''}`);
      fs.writeFileSync(path.join(notesDir, 'Notes.txt'), lines.join('\n') + '\n', 'utf8');
      for (const a of acts) {
        for (const ph of a.photos) {
          const src = path.join(paths.uploadsDir, ph);
          const dest = path.join(notesDir, `${a.at.slice(0, 10)} ${ph}`);
          if (fs.existsSync(src) && !fs.existsSync(dest)) fs.copyFileSync(src, dest);
        }
      }
    }
    // the price history is its own file: every offer with its price level, every change of the discount level
    fs.writeFileSync(path.join(target, 'Price changes.txt'), priceHistoryText(card), 'utf8');
    return target;
  } catch (err) {
    console.error('Customer folder update failed:', err);
    return null;
  }
}

// Keeps the PDF the customer actually received (prices change with the price list).
export function saveOfferPdf(cardId: number, pdf: Buffer, percent: number | null, title?: string): string | null {
  try {
    const dir = syncCustomerFolder(cardId);
    if (!dir) return null;
    const offers = path.join(dir, 'Offers');
    fs.mkdirSync(offers, { recursive: true });
    const stamp = new Date().toISOString().slice(0, 16).replace('T', ' ').replace(':', '');
    const label = percent === null || percent === 0 ? 'list price' : `${percent > 0 ? '+' : '-'}${Math.round(Math.abs(percent) * 1000) / 10}%`;
    const what = title ? `Offer ${safeName(title, 40)}` : 'Offer';
    let name = `${what} ${stamp} (${label}).pdf`;
    for (let n = 2; fs.existsSync(path.join(offers, name)); n++) name = `${what} ${stamp} (${label}) ${n}.pdf`;
    fs.writeFileSync(path.join(offers, name), pdf);
    return path.join('Offers', name);
  } catch (err) {
    console.error('Saving the offer PDF failed:', err);
    return null;
  }
}

export interface CustomerFile {
  name: string; // path inside the customer folder, always with "/"
  label: string;
  kind: 'scan' | 'details' | 'offer' | 'price' | 'upload';
  size: number;
  modified: string;
}

const UPLOAD_EXT = new Set(['.pdf', '.png', '.jpg', '.jpeg', '.heic', '.webp', '.gif', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.txt', '.csv', '.zip']);
export const isUploadable = (name: string) => UPLOAD_EXT.has(path.extname(name).toLowerCase());

// A file added by a person (a photo of the workshop, a drawing, a signed PDF ...) goes into the customer's Files folder.
export function saveUploadedFile(cardId: number, originalName: string, data: Buffer): string | null {
  try {
    const dir = syncCustomerFolder(cardId);
    if (!dir || !isUploadable(originalName)) return null;
    const folder = path.join(dir, 'Files');
    fs.mkdirSync(folder, { recursive: true });
    const ext = path.extname(originalName).toLowerCase();
    const base = safeName(path.basename(originalName, path.extname(originalName)), 70) || 'File';
    let name = `${base}${ext}`;
    for (let n = 2; fs.existsSync(path.join(folder, name)); n++) name = `${base} (${n})${ext}`;
    fs.writeFileSync(path.join(folder, name), data);
    return `Files/${name}`;
  } catch (err) {
    console.error('Saving an uploaded file failed:', err);
    return null;
  }
}

export function deleteUploadedFile(cardId: number, rel: string): boolean {
  const full = resolveCustomerFile(cardId, rel);
  const card = cardModel.findById(cardId);
  if (!full || !card?.archive_dir) return false;
  if (!full.startsWith(path.resolve(abs(card.archive_dir), 'Files') + path.sep)) return false;
  fs.unlinkSync(full);
  return true;
}

export function listCustomerFiles(cardId: number): { folder: string | null; files: CustomerFile[] } {
  const card = cardModel.findById(cardId);
  if (!card) return { folder: null, files: [] };
  const dir = syncCustomerFolder(cardId);
  if (!dir) return { folder: null, files: [] };
  const files: CustomerFile[] = [];
  const add = (rel: string, label: string, kind: CustomerFile['kind']) => {
    const full = path.join(dir, rel);
    if (!fs.existsSync(full)) return;
    const s = fs.statSync(full);
    files.push({ name: rel.split(path.sep).join('/'), label, kind, size: s.size, modified: s.mtime.toISOString() });
  };
  for (const f of fs.readdirSync(dir)) if (/^Scan\./i.test(f)) add(f, 'Scan of the form', 'scan');
  add('details.txt', 'Customer details', 'details');
  add('Price changes.txt', 'Price changes (offers and discount level)', 'price');
  const offersDir = path.join(dir, 'Offers');
  if (fs.existsSync(offersDir)) {
    for (const f of fs.readdirSync(offersDir).sort().reverse()) add(path.join('Offers', f), f.replace(/\.pdf$/i, ''), 'offer');
  }
  const filesDir = path.join(dir, 'Files');
  const walk = (d: string, prefix: string) => {
    for (const f of fs.readdirSync(d).sort().reverse()) {
      const full = path.join(d, f);
      if (fs.statSync(full).isDirectory()) walk(full, `${prefix}${f}/`);
      else add(`Files/${prefix}${f}`.split('/').join(path.sep), `${prefix}${f}`, 'upload');
    }
  };
  if (fs.existsSync(filesDir)) walk(filesDir, '');
  return { folder: card.archive_dir ? card.archive_dir.split(path.sep).join(' / ') : null, files };
}

// Absolute path of one file in the customer's folder, or null if it is not there.
export function resolveCustomerFile(cardId: number, name: string): string | null {
  const card = cardModel.findById(cardId);
  if (!card?.archive_dir) return null;
  const dir = abs(card.archive_dir);
  const full = path.resolve(dir, name);
  if (!full.startsWith(path.resolve(dir) + path.sep) || !fs.existsSync(full) || !fs.statSync(full).isFile()) return null;
  return full;
}

export function removeCustomerFolder(card: Pick<CardRow, 'archive_dir'>): void {
  try {
    if (!card.archive_dir) return;
    const dir = abs(card.archive_dir);
    if (inside(dir) && fs.existsSync(dir)) fs.rmSync(dir, { recursive: true, force: true });
    pruneEmpty(path.dirname(dir));
  } catch (err) {
    console.error('Removing the customer folder failed:', err);
  }
}

// Every customer of one exhibition (e.g. after the exhibition was renamed).
export function syncExhibitionFolders(exhibitionId: number): void {
  for (const card of cardModel.listByExhibition(exhibitionId)) syncCustomerFolder(card.id);
}

// Folders for every customer that has none yet (existing records).
export function syncAllCustomerFolders(): number {
  let n = 0;
  for (const card of cardModel.listAll()) if (syncCustomerFolder(card.id)) n += 1;
  return n;
}

// The folders to put in a ZIP: <sales person>/<exhibition> for the customers that
// match (one exhibition, one sales person, both, or everything).
export function folderTargets(opts: { exhibitionId?: number; person?: string }): string[] {
  const cards = opts.exhibitionId ? cardModel.listByExhibition(opts.exhibitionId) : cardModel.listAll();
  const wanted = opts.person === undefined ? null : safeName(opts.person) || NO_PERSON_FOLDER;
  const targets = new Set<string>();
  for (const c of cards) {
    if (!c.archive_dir) continue;
    const parts = c.archive_dir.split(path.sep);
    if (wanted !== null && parts[0] !== wanted) continue;
    targets.add(parts.slice(0, 2).join(path.sep));
  }
  return [...targets].filter((n) => fs.existsSync(abs(n)));
}

// The sales people that have a folder, with how many customers are in it.
export function folderIndex(): { person: string; customers: number }[] {
  const counts = new Map<string, number>();
  for (const c of cardModel.listAll()) {
    if (!c.archive_dir || !fs.existsSync(abs(c.archive_dir))) continue;
    const person = c.archive_dir.split(path.sep)[0];
    counts.set(person, (counts.get(person) ?? 0) + 1);
  }
  return [...counts].map(([person, customers]) => ({ person, customers })).sort((a, b) => a.person.localeCompare(b.person));
}

// Absolute path of a customer folder given its relative path.
export function absoluteFolder(rel: string): string {
  return abs(rel);
}

export const customerFilesRoot = ROOT;
