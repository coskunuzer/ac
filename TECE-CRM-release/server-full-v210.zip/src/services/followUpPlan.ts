import type { CardRow } from '../models/cardModel';
import type { OfferEntry } from '../models/pricingModels';
import { HOT_RATE } from '../models/reportModel';
import { offerWanted, parseInsight, ruleInsight, type AiInsight } from './aiInsight';
import { INTEREST_PRODUCTS, interestLabel, interestOf } from './interest';
import { distributorModel } from '../models/distributorModel';
import { realFairIds } from './emailSafety';

// The follow-up list: for every customer, what should happen next, worked out from what the
// notes ask for (read by the AI when the form was scanned), what has been sent already and how
// long ago. The most urgent customers come first.

export type TaskKind = 'thank_you' | 'offer' | 'chase' | 'reminder' | 'check';
export type When = 'now' | 'this_week' | 'later';

export interface PlanTask {
  kind: TaskKind;
  label: string;
  detail: string | null;
  when: When;
}

export interface PlanItem {
  id: number;
  name: string | null;
  company: string | null;
  country: string | null;
  person: string | null;
  email: string | null;
  rate: number | null;
  interested_in: string;
  summary: string | null; // the notes in English, from the AI
  ai: boolean; // read by the AI (otherwise only the plain words of the notes)
  thank_you_sent_at: string | null;
  offers: number;
  last_offer_at: string | null;
  score: number;
  tasks: PlanTask[];
}

const DAY = 86_400_000;
const utc = (s: string) => new Date(`${s.replace(' ', 'T')}Z`).getTime();

function insightOf(card: CardRow): AiInsight {
  const existing = parseInsight(card.ai_insight);
  if (existing) return existing;
  const interest = interestOf(card);
  return ruleInsight({ notes: card.notes, interested_in: card.interested_in, products: interest.products, widths: interest.widths, other: interest.other });
}

export function buildPlan(cards: CardRow[], offers: OfferEntry[], now = new Date(), limit = 400): PlanItem[] {
  const byCard = new Map<number, OfferEntry[]>();
  for (const o of offers) (byCard.get(o.cardId) ?? byCard.set(o.cardId, []).get(o.cardId)!).push(o);

  const items: PlanItem[] = [];
  const fairs = realFairIds();
  for (const card of cards) {
    const insight = insightOf(card);
    const interest = interestOf(card);
    const entries = byCard.get(card.id) ?? [];
    const offerEntries = entries.filter((e) => e.kind === 'offer').sort((a, b) => utc(b.sentAt) - utc(a.sentAt));
    const lastOffer = offerEntries[0] ?? null; // newest first
    const thanked = !!(card.thank_you_sent_at || entries.some((e) => e.kind === 'thank_you'));
    const rate = card.rate ?? null;
    const hot = (rate ?? 0) >= HOT_RATE;
    const hasEmail = !!card.email?.trim();
    const tasks: PlanTask[] = [];
    let score = rate ?? 4;

    if (card.status === 'needs_review') {
      tasks.push({ kind: 'check', label: 'Check the record', detail: 'The form has not been confirmed yet.', when: 'now' });
    }

    const distributor = distributorModel.forCard(card);
    // a thank-you is for a visit at a real fair: a record from "Direct contacts" gets a first e-mail of its own kind instead
    if (!thanked && insight.sendThankYou && !fairs.has(card.exhibition_id) && hasEmail) {
      tasks.push({ kind: 'reminder', label: 'Write a first e-mail', detail: 'This record is not from a fair, so no thank-you for a visit.', when: 'this_week' });
    } else if (!thanked && insight.sendThankYou) {
      if (hasEmail) {
        tasks.push({
          kind: 'thank_you',
          label: distributor ? `Send the reply that points to our distributor (${distributor.name})` : 'Send the thank-you',
          detail: distributor ? `We have a distributor in ${card.country}.` : null,
          when: 'now',
        });
        score += 2;
      } else {
        tasks.push({ kind: 'check', label: 'Find an e-mail address', detail: 'There is no e-mail on the record, so nothing can be sent yet.', when: 'now' });
      }
    }

    const names = INTEREST_PRODUCTS.filter((p) => interest.products.includes(p.key)).map((p) => p.label);
    const wants = insight.offerFor || (names.length ? `${names.join(', ')}${interest.widths.length ? ` (${interest.widths.join(', ')} mm)` : ''}` : null);
    // the tick on the record: 1 = send an offer (confirmed), 0 = no offer, empty = the AI's suggestion
    const tick = card.send_offer;
    const wanted = offerWanted(card);
    // only when an offer is wanted (ticked, or read in the notes by the AI) - no guessing from interest or rate,
    // so the list never asks for an offer that nobody asked for
    if (!lastOffer && hasEmail && (tick === 1 || (tick === null && wanted))) {
      tasks.push({
        kind: 'offer',
        label: wants ? `Send the offer: ${wants}` : 'Send an offer',
        detail: tick === 1 ? 'Confirmed on the record.' : wanted ? 'The notes ask for an offer - tick "send an offer" on the record to confirm.' : hot ? 'A hot lead.' : 'They are interested in these products.',
        when: wanted || hot ? 'now' : 'this_week',
      });
      score += tick === 1 ? 5 : wanted ? 4 : hot ? 2 : 1;
    }

    if (lastOffer) {
      const days = Math.floor((now.getTime() - utc(lastOffer.sentAt)) / DAY);
      if (days >= 10) {
        tasks.push({ kind: 'chase', label: `Ask if the offer arrived (${days} days ago)`, detail: null, when: 'now' });
        score += 3;
      } else if (days >= 4) {
        tasks.push({ kind: 'chase', label: `Follow up on the offer sent ${days} days ago`, detail: null, when: 'this_week' });
        score += 1;
      }
    }

    if (insight.nextAction) {
      tasks.push({ kind: 'reminder', label: insight.nextAction, detail: 'From the notes.', when: insight.timing ?? 'this_week' });
      score += 2;
    }
    if (hot) score += 2;

    if (!tasks.length) continue;
    items.push({
      id: card.id,
      name: card.name,
      company: card.company,
      country: card.country,
      person: card.person,
      email: card.email,
      rate,
      interested_in: interestLabel(card),
      summary: insight.summary,
      ai: insight.source === 'ai',
      thank_you_sent_at: card.thank_you_sent_at,
      offers: offerEntries.length,
      last_offer_at: lastOffer?.sentAt ?? null,
      score,
      tasks,
    });
  }
  return items.sort((a, b) => b.score - a.score || (b.rate ?? 0) - (a.rate ?? 0)).slice(0, limit);
}
