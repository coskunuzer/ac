// Fairs: what became of the people we met (fair by fair), the fairs that come next, and "Fair focus" - working through the visitors of one fair
// against the clock, one after the other, with a note for each.
import { h, Fragment, useState, useEffect, useMemo, useRef, useCallback, api, useNavigate, useParams, useSearchParams, Link, useAuth, useT, Icon, logActivity, cx, errText, eur, pct, dateRange, ago, Ring, Bar, Chip, Stat, Skel, Empty, useApi, toast, burst } from "./x-kit-br2FMvy0.js";
import { EventBudget, BudgetLine } from "./x-budget-2YACrUIl.js";

const initials = (name) => String(name || "?").split(/\s+/).filter(Boolean).slice(0, 2).map((p) => p[0].toUpperCase()).join("");

// the four steps a visitor goes through, as bars that shrink
function Funnel({ f }) {
  const t = useT();
  const steps = [
    { key: "met", label: t("Met"), n: f.met },
    { key: "contacted", label: t("Contacted"), n: f.contacted },
    { key: "offers", label: t("Offer sent"), n: f.offers },
    { key: "won", label: t("Customer"), n: f.won },
  ];
  return h("div", { className: "xf-funnel" }, steps.map((s, i) =>
    h("div", { key: s.key, className: "xf-step xf-step--" + s.key },
      h("div", { className: "xf-step-top" }, h("span", null, s.label), h("b", null, s.n)),
      h("span", { className: "xf-step-bar" }, h("span", { style: { width: (f.met > 0 ? Math.max(s.n > 0 ? 4 : 0, (s.n / f.met) * 100) : 0) + "%" } })),
      i > 0 ? h("small", null, pct(s.n, f.met) + "%") : h("small", null, f.countries > 0 ? t("{n} countries", { n: f.countries }) : " "),
    ),
  ));
}

function PastFair({ f, canBudget, featured }) {
  const t = useT();
  const [showBudget, setShowBudget] = useState(false);
  const [money, setMoney] = useState(f.budget);
  const done = pct(f.contacted, f.met);
  const tone = done >= 90 ? "good" : done >= 50 ? "" : "bad";
  return h("article", { className: cx("xf-card", featured && "xf-card--featured", f.ongoing && "xf-card--live") },
    h("header", { className: "xf-card-head" },
      h("div", { className: "xf-card-id" },
        h("div", { className: "xf-card-chips" },
          f.ongoing ? h(Chip, { tone: "live", icon: "festival" }, t("Happening now")) : h(Chip, null, f.daysAgo === 0 ? t("ended today") : t("{n} days ago", { n: f.daysAgo })),
          h(Chip, null, f.presence === "participating" ? t("We took part") : t("We visited")),
        ),
        h("h3", null, f.name),
        h("p", null, [f.location, dateRange(f.startDate, f.endDate)].filter(Boolean).join(" · ")),
      ),
      h(Ring, { value: f.contacted, max: f.met, size: 76, stroke: 7, tone, label: t("{a} of {b} contacted", { a: f.contacted, b: f.met }) }),
    ),
    h(Funnel, { f }),
    f.waiting > 0
      ? h("div", { className: cx("xf-wait", f.hotWaiting > 0 && "xf-wait--hot") },
          h(Icon, { n: f.hotWaiting > 0 ? "local-fire-department" : "hourglass-empty", size: 24 }),
          h("div", null,
            h("b", null, f.hotWaiting > 0 ? t("{n} hot visitors are still waiting", { n: f.hotWaiting }) : t("{n} visitors are still waiting", { n: f.waiting })),
            h("span", null, f.hotWaiting > 0 ? t("{n} people in all have not heard from us since the fair.", { n: f.waiting }) : t("Nobody has written to them or called them since the fair.")),
          ),
        )
      : f.met > 0
        ? h("div", { className: "xf-wait xf-wait--done" }, h(Icon, { n: "check-circle", size: 24 }), h("div", null, h("b", null, t("Everybody we met has been contacted")), h("span", null, f.contactedByMe > 0 ? t("{n} of them by you.", { n: f.contactedByMe }) : " ")))
        : null,
    canBudget && money ? h(BudgetLine, { planned: money.planned, spent: money.spent }) : null,
    h("footer", { className: "xf-card-foot" },
      h(Link, { className: cx("tc-btn tc-btn--md", f.waiting === 0 && "tc-btn--secondary"), to: `/fairs/${f.id}/focus` }, h(Icon, { n: "bolt", size: 20 }), f.waiting > 0 ? t("Start the focus sprint") : t("Open the focus view")),
      h(Link, { className: "tc-btn tc-btn--secondary tc-btn--md", to: `/records?exhibitionId=${f.id}` }, t("Open the people")),
      canBudget ? h("button", { type: "button", className: "tc-btn tc-btn--ghost tc-btn--md", "aria-expanded": showBudget, onClick: () => setShowBudget((s) => !s) }, h(Icon, { n: "savings", size: 20 }), t("Budget")) : null,
    ),
    showBudget ? h(EventBudget, { kind: "exhibition", id: f.id, embedded: true, onChange: setMoney }) : null,
  );
}

function NextFair({ f, canBudget }) {
  const t = useT();
  const [showBudget, setShowBudget] = useState(false);
  const [money, setMoney] = useState(f.budget);
  const weeks = Math.floor(f.inDays / 7);
  return h("article", { className: "xf-card xf-card--next" },
    h("header", { className: "xf-card-head" },
      h("div", { className: "xf-count" }, h("b", null, f.inDays), h("span", null, f.inDays === 1 ? t("day to go") : t("days to go"))),
      h("div", { className: "xf-card-id" },
        h("div", { className: "xf-card-chips" }, h(Chip, null, f.presence === "participating" ? t("We take part") : t("We visit")), weeks >= 2 ? h(Chip, null, t("in {n} weeks", { n: weeks })) : h(Chip, { tone: "warn" }, t("very soon"))),
        h("h3", null, f.name),
        h("p", null, [f.location, dateRange(f.startDate, f.endDate)].filter(Boolean).join(" · ")),
      ),
    ),
    h("div", { className: "xf-team" },
      h("span", { className: "xf-team-label" }, t("Going")),
      f.attendees.length ? h("span", { className: "xf-avatars" }, f.attendees.slice(0, 6).map((a) => h("span", { key: a.id, className: "xf-avatar", title: a.name }, initials(a.name))), h("span", { className: "xf-team-names" }, f.attendees.map((a) => a.name.split(" ")[0]).join(", "))) : h("span", { className: "tx-muted" }, t("Nobody is named yet.")),
    ),
    canBudget && money ? h(BudgetLine, { planned: money.planned, spent: money.spent }) : null,
    h("footer", { className: "xf-card-foot" },
      h(Link, { className: "tc-btn tc-btn--secondary tc-btn--md", to: "/scan" }, h(Icon, { n: "qr-code-scanner", size: 20 }), t("Scan fair papers")),
      canBudget ? h("button", { type: "button", className: "tc-btn tc-btn--ghost tc-btn--md", "aria-expanded": showBudget, onClick: () => setShowBudget((s) => !s) }, h(Icon, { n: "savings", size: 20 }), money ? t("Budget") : t("Plan the budget")) : null,
    ),
    showBudget ? h(EventBudget, { kind: "exhibition", id: f.id, embedded: true, onChange: setMoney }) : null,
  );
}

export function FairsPage() {
  const t = useT();
  const { user } = useAuth();
  const [board, err] = useApi("/exhibitions/board");
  const [params, setParams] = useSearchParams();
  const tab = params.get("view") === "next" ? "next" : "past";
  const past = board ? board.past : [];
  const sum = useMemo(() => past.reduce((a, f) => ({ met: a.met + f.met, contacted: a.contacted + f.contacted, offers: a.offers + f.offers, won: a.won + f.won, waiting: a.waiting + f.waiting, hot: a.hot + f.hotWaiting }), { met: 0, contacted: 0, offers: 0, won: 0, waiting: 0, hot: 0 }), [board]);
  // the fair that needs work most: hot visitors waiting first, then anybody waiting, the newest fair first
  const urgent = useMemo(() => [...past].filter((f) => f.waiting > 0).sort((a, b) => b.hotWaiting - a.hotWaiting || a.daysAgo - b.daysAgo)[0] || null, [board]);
  return h("div", { className: "tx-page xf" },
    h("div", { className: "tx-ph" },
      h("div", { className: "tx-ph-main" },
        h("h1", { className: "tc-title tc-title--sm" }, h("b", null, t("Fairs"))),
        h("p", { className: "tx-lead" }, t("A fair only pays back when the people we met hear from us. Here is who is still waiting, fair by fair.")),
      ),
      h("div", { className: "tx-bar" },
        h(Link, { className: "tc-btn tc-btn--secondary tc-btn--md", to: "/scan" }, h(Icon, { n: "qr-code-scanner" }), t("Scan fair papers")),
        h(Link, { className: "tc-btn tc-btn--secondary tc-btn--md", to: "/fairs/results" }, h(Icon, { n: "bar-chart" }), t("Fair results")),
        user && user.role === "admin" ? h(Link, { className: "tc-btn tc-btn--secondary tc-btn--md", to: "/reports/visitors-by-country" }, h(Icon, { n: "public" }), t("Visitors by country")) : null,
      ),
    ),
    err ? h("p", { className: "tx-err", role: "alert" }, err) : null,
    !board ? h(Skel, { height: 320 }) : h(Fragment, null,
      past.length > 0 ? h("section", { className: "xf-hero", "aria-label": t("All fairs together") },
        h("div", { className: "xf-hero-ring" }, h(Ring, { value: sum.contacted, max: sum.met, size: 112, stroke: 10, tone: "onink" }), h("span", null, t("of everybody we met has been contacted"))),
        h("div", { className: "xf-hero-stats" },
          h(Stat, { n: sum.met.toLocaleString("en-US"), label: t("people met") }),
          h(Stat, { n: sum.offers.toLocaleString("en-US"), label: t("got an offer"), sub: pct(sum.offers, sum.met) + "%" }),
          h(Stat, { n: sum.won.toLocaleString("en-US"), label: t("are customers"), sub: pct(sum.won, sum.met) + "%" }),
          h(Stat, { n: sum.waiting.toLocaleString("en-US"), label: t("still waiting"), tone: sum.waiting > 0 ? "alert" : "", sub: sum.hot > 0 ? t("{n} of them hot", { n: sum.hot }) : null }),
        ),
        urgent ? h("div", { className: "xf-hero-cta" },
          h("span", null, t("Most urgent")),
          h("b", null, urgent.name),
          h(Link, { className: "tc-btn tc-btn--md xf-btn-onink", to: `/fairs/${urgent.id}/focus` }, h(Icon, { n: "bolt", size: 20 }), t("Work on {n} visitors", { n: urgent.waiting })),
        ) : h("div", { className: "xf-hero-cta" }, h(Icon, { n: "trophy", size: 32 }), h("b", null, t("Nobody is waiting.")), h("span", null, t("Every visitor has heard from us."))),
      ) : null,
      h("div", { className: "xk-tabs", role: "tablist", "aria-label": t("Fairs") },
        h("button", { type: "button", role: "tab", "aria-selected": tab === "past", onClick: () => setParams({}, { replace: true }) }, t("Results, fair by fair"), h("span", { className: "xk-tabs-n" }, past.length)),
        h("button", { type: "button", role: "tab", "aria-selected": tab === "next", onClick: () => setParams({ view: "next" }, { replace: true }) }, t("Fairs coming next"), h("span", { className: "xk-tabs-n" }, board.next.length)),
      ),
      tab === "past"
        ? past.length === 0 ? h(Empty, { icon: "festival", title: t("No old fairs yet.") }, t("Scan the papers of a fair and its visitors show here.")) : h("div", { className: "xf-grid" }, past.map((f) => h(PastFair, { key: f.id, f, canBudget: board.canBudget, featured: urgent && urgent.id === f.id })))
        : board.next.length === 0 ? h(Empty, { icon: "event", title: t("No coming fairs.") }, board.isAdmin ? h(Link, { className: "tc-link", to: "/admin/exhibitions" }, t("Add a fair")) : null) : h("div", { className: "xf-grid" }, board.next.map((f) => h(NextFair, { key: f.id, f, canBudget: board.canBudget }))),
    ),
  );
}

// ---- the block on the Home page: the last fairs, and who is still waiting -------------------------------------------------------------------------
export function HomeFairs() {
  const t = useT();
  const [board] = useApi("/exhibitions/board");
  if (!board) return null;
  const recent = board.past.filter((f) => f.daysAgo <= 200).slice(0, 3);
  const next = board.next[0];
  if (recent.length === 0 && !next) return null;
  return h("section", { className: "xh-fairs", "aria-labelledby": "xh-fairs-title" },
    h("div", { className: "xh-head" },
      h("h2", { className: "tx-h2", id: "xh-fairs-title" }, t("Fair results")),
      h("div", { className: "xh-head-side" },
        next ? h("span", { className: "xh-next" }, h(Icon, { n: "event", size: 16 }), next.name, " · ", h("b", null, next.inDays === 1 ? t("tomorrow") : t("in {n} days", { n: next.inDays }))) : null,
        h(Link, { className: "tc-link", to: "/fairs" }, t("All fairs")),
      ),
    ),
    h("div", { className: "xh-fair-row", "data-n": recent.length }, recent.map((f) => {
      const done = pct(f.contacted, f.met);
      return h("article", { key: f.id, className: cx("xh-fair", f.hotWaiting > 0 && "xh-fair--hot") },
        h("div", { className: "xh-fair-top" },
          h(Ring, { value: f.contacted, max: f.met, size: 60, stroke: 6, tone: done >= 90 ? "good" : done >= 50 ? "" : "bad" }),
          h("div", null, h("h3", null, f.name), h("p", null, f.ongoing ? t("Happening now") : t("{n} days ago", { n: f.daysAgo }), " · ", t("{n} met", { n: f.met }))),
        ),
        h("div", { className: "xh-fair-nums" },
          h("span", null, h("b", null, f.contacted), t("contacted")),
          h("span", null, h("b", null, f.offers), t("offers")),
          h("span", null, h("b", null, f.won), t("customers")),
          h("span", { className: f.waiting > 0 ? "is-alert" : "" }, h("b", null, f.waiting), t("waiting")),
        ),
        f.waiting > 0
          ? h(Link, { className: "xh-fair-cta", to: `/fairs/${f.id}/focus` }, h(Icon, { n: f.hotWaiting > 0 ? "local-fire-department" : "bolt", size: 20 }), f.hotWaiting > 0 ? t("{n} hot visitors wait - focus now", { n: f.hotWaiting }) : t("Work on the {n} who wait", { n: f.waiting }), h(Icon, { n: "arrow-forward", size: 16 }))
          : h(Link, { className: "xh-fair-cta xh-fair-cta--done", to: `/fairs/${f.id}/focus` }, h(Icon, { n: "check-circle", size: 20 }), t("Everybody contacted"), h(Icon, { n: "arrow-forward", size: 16 })),
      );
    })),
  );
}

// ---- Fair focus -----------------------------------------------------------------------------------------------------------------------------------
const TYPES = [["call", "Call", "call"], ["note", "Note", "edit-note"], ["meeting", "Meeting", "groups"], ["visit", "Visit", "location-on"], ["sample", "Sample", "inventory-2"]];
const FILTERS = [["waiting", "Waiting"], ["hot", "Hot"], ["parked", "Parked"], ["done", "Contacted"], ["all", "Everybody"]];
const isHot = (v) => (v.score ?? 0) >= 7;
const mmss = (s) => `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
const typing = (el) => !!el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.tagName === "SELECT" || el.isContentEditable);

export function FairFocusPage() {
  const t = useT();
  const { id } = useParams();
  const nav = useNavigate();
  const [data, err, reload, setData] = useApi(`/exhibitions/${id}/focus`);
  const [filter, setFilter] = useState("waiting");
  const [mine, setMine] = useState(false);
  const [q, setQ] = useState("");
  const [cur, setCur] = useState(null);
  const [type, setType] = useState("call");
  const [text, setText] = useState("");
  const [follow, setFollow] = useState(0);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState(null);
  // the session: the clock, and what was done in it
  const [clock, setClock] = useState({ target: 0, started: null, paused: 0, pausedAt: null });
  const [now, setNow] = useState(Date.now());
  const [session, setSession] = useState({ handled: 0, notes: 0, rated: 0, combo: 0, best: 0, last: 0 });
  const noteRef = useRef(null);
  useEffect(() => {
    if (!clock.started || clock.pausedAt) return undefined;
    const i = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(i);
  }, [clock.started, clock.pausedAt]);
  const elapsed = clock.started ? Math.floor(((clock.pausedAt || now) - clock.started - clock.paused) / 1000) : 0;
  const left = clock.target ? Math.max(0, clock.target * 60 - elapsed) : null;

  const visitors = data ? data.visitors : [];
  const state = useCallback((v) => (v.parked ? "parked" : v.touches > 0 ? "done" : "waiting"), []);
  const counts = useMemo(() => {
    const c = { waiting: 0, hot: 0, parked: 0, done: 0, all: visitors.length, mine: 0 };
    for (const v of visitors) {
      const s = state(v);
      c[s] += 1;
      if (s === "waiting" && isHot(v)) c.hot += 1;
      if (v.mine) c.mine += 1;
    }
    return c;
  }, [visitors, state]);
  const list = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return visitors
      .filter((v) => {
        const s = state(v);
        if (filter === "hot" ? !(s === "waiting" && isHot(v)) : filter !== "all" && s !== filter) return false;
        if (mine && !v.mine) return false;
        return !needle || [v.company, v.name, v.lastName, v.country, v.email].some((x) => x && String(x).toLowerCase().includes(needle));
      })
      .sort((a, b) => (b.score ?? -1) - (a.score ?? -1) || String(a.company || "").localeCompare(String(b.company || "")));
  }, [visitors, filter, mine, q, state]);
  const v = useMemo(() => list.find((x) => x.id === cur) || list[0] || null, [list, cur]);
  useEffect(() => {
    setText("");
    setFollow(0);
    setMsg(null);
  }, [v && v.id]);
  const idx = v ? list.findIndex((x) => x.id === v.id) : -1;
  const go = useCallback((d) => {
    if (!list.length) return;
    const n = list[Math.max(0, Math.min(list.length - 1, idx + d))];
    if (n) setCur(n.id);
  }, [list, idx]);
  const patch = (cardId, change) => setData((d) => (d ? { ...d, visitors: d.visitors.map((x) => (x.id === cardId ? { ...x, ...change } : x)) } : d));
  // every visitor handled keeps the chain alive; 90 seconds without one and it starts again
  const score = (kind) => setSession((s) => {
    const alive = Date.now() - s.last < 90000;
    const combo = alive ? s.combo + 1 : 1;
    return { ...s, handled: s.handled + (kind === "rated" ? 0 : 1), notes: s.notes + (kind === "note" ? 1 : 0), rated: s.rated + (kind === "rated" ? 1 : 0), combo, best: Math.max(s.best, combo), last: Date.now() };
  });
  const start = (target) => setClock({ target, started: Date.now(), paused: 0, pausedAt: null });
  const ensureClock = () => { if (!clock.started) start(0); };
  const nextAfter = (cardId) => {
    const i = list.findIndex((x) => x.id === cardId);
    const n = list[i + 1] || list[i - 1];
    setCur(n ? n.id : null);
  };
  async function save(ev) {
    if (ev) ev.preventDefault();
    if (!v || busy) return;
    if (!text.trim()) { setMsg(t("Write what happened first.")); if (noteRef.current) noteRef.current.focus(); return; }
    setBusy(true);
    setMsg(null);
    ensureClock();
    try {
      await logActivity(v.id, type, text.trim(), follow || null);
      const was = state(v);
      patch(v.id, { touches: v.touches + 1, myTouches: v.myTouches + 1, parked: null, lastTouch: new Date().toISOString().slice(0, 19).replace("T", " "), lastNote: { type, text: text.trim(), at: new Date().toISOString().slice(0, 19).replace("T", " "), by: null }, todoDue: follow ? "soon" : v.todoDue });
      score("note");
      const btn = document.querySelector(".xff-save");
      if (btn) { const r = btn.getBoundingClientRect(); burst(r.left + r.width / 2, r.top, was === "waiting" ? 22 : 10); }
      toast(was === "waiting" ? t("Contacted. One less waiting.") : t("Saved."), "good");
      window.dispatchEvent(new Event("tece:logged"));
      if (filter === "waiting" || filter === "hot" || filter === "parked") nextAfter(v.id);
      else go(1);
      setText("");
    } catch (e) {
      setMsg(errText(e, t("Could not save")));
    } finally {
      setBusy(false);
    }
  }
  async function rate(n) {
    if (!v) return;
    const before = v.rate;
    patch(v.id, { rate: n, score: n });
    try {
      await api.patch(`/cards/${v.id}`, { rate: n });
      score("rated");
    } catch (e) {
      patch(v.id, { rate: before, score: before ?? (v.aiRate != null ? Math.round(v.aiRate / 10) : null) });
      toast(errText(e, t("Could not save the rating")), "bad");
    }
  }
  async function park(kind) {
    if (!v) return;
    ensureClock();
    try {
      await api.post(`/exhibitions/${id}/focus/state`, { cardId: v.id, state: kind, days: 3 });
      const cardId = v.id;
      nextAfter(cardId);
      patch(cardId, { parked: kind });
      score("park");
      toast(kind === "later" ? t("Parked for 3 days.") : t("Closed: nothing to do here."));
    } catch (e) {
      toast(errText(e, t("Could not save")), "bad");
    }
  }
  async function unpark() {
    if (!v) return;
    try {
      await api.post(`/exhibitions/${id}/focus/state`, { cardId: v.id, state: "open" });
      patch(v.id, { parked: null });
    } catch (e) {
      toast(errText(e, t("Could not save")), "bad");
    }
  }
  useEffect(() => {
    const onKey = (e) => {
      const key = e.key || "";
      if ((e.ctrlKey || e.metaKey) && key === "Enter") { save(); return; }
      if (typing(e.target) || e.ctrlKey || e.metaKey || e.altKey) return;
      if (key === "ArrowDown" || key === "j") { e.preventDefault(); go(1); }
      else if (key === "ArrowUp" || key === "k") { e.preventDefault(); go(-1); }
      else if (/^[0-9]$/.test(key)) { e.preventDefault(); rate(key === "0" ? 10 : parseInt(key, 10)); }
      else if (key === "w" || key === "W") { e.preventDefault(); e.stopPropagation(); if (noteRef.current) noteRef.current.focus(); }
      else if (key === "l" || key === "L") park("later");
      else if (key === "x" || key === "X") park("closed");
      else if (key === "Enter" && v) nav(`/cards/${v.id}/review`);
    };
    document.addEventListener("keydown", onKey, true);
    return () => document.removeEventListener("keydown", onKey, true);
  });

  if (err) return h("div", { className: "tx-page" }, h("p", { className: "tx-err", role: "alert" }, err), h(Link, { className: "tc-link", to: "/fairs" }, t("Back to the fairs")));
  if (!data) return h("div", { className: "tx-page" }, h(Skel, { height: 420 }));
  const f = data.fair;
  const total = counts.all;
  const doneN = counts.done;
  const person = v ? [v.name, v.lastName].filter(Boolean).join(" ") : "";
  const wa = v && (v.mobile || v.tel) ? String(v.mobile || v.tel).replace(/[^\d]/g, "") : "";
  const timeUp = left === 0 && clock.target > 0;
  return h("div", { className: "tx-page xff" },
    h("div", { className: cx("xff-hud", timeUp && "xff-hud--up") },
      h("div", { className: "xff-hud-id" },
        h(Link, { className: "xff-back", to: "/fairs", "aria-label": t("Back to the fairs") }, h(Icon, { n: "arrow-back", size: 20 })),
        h("div", null, h("span", { className: "xff-kicker" }, t("Fair focus")), h("h1", null, f.name), h("p", null, [f.location, dateRange(f.startDate, f.endDate), f.ongoing ? t("happening now") : f.daysAgo != null ? t("{n} days ago", { n: f.daysAgo }) : null].filter(Boolean).join(" · "))),
      ),
      h("div", { className: "xff-hud-ring" }, h(Ring, { value: doneN, max: total, size: 84, stroke: 8, tone: "onink" }), h("span", null, h("b", null, doneN + " / " + total), t("contacted"))),
      h("div", { className: "xff-hud-stats" },
        h(Stat, { n: counts.waiting, label: t("waiting"), tone: counts.waiting > 0 ? "alert" : "" }),
        h(Stat, { n: counts.hot, label: t("hot waiting"), tone: counts.hot > 0 ? "alert" : "" }),
        h(Stat, { n: session.handled, label: t("this session") }),
        h(Stat, { n: "×" + Math.max(1, session.combo), label: t("chain"), tone: session.combo >= 3 ? "fire" : "", sub: session.best > 1 ? t("best ×{n}", { n: session.best }) : null }),
      ),
      h("div", { className: "xff-clock" },
        clock.started
          ? h(Fragment, null,
              h("b", { className: "xff-time", "aria-live": "off" }, left != null ? mmss(left) : mmss(elapsed)),
              h("span", null, timeUp ? t("Time is up. Well done.") : left != null ? t("left") : t("on the clock")),
              h("div", { className: "xff-clock-btns" },
                h("button", { type: "button", onClick: () => setClock((c) => (c.pausedAt ? { ...c, paused: c.paused + (Date.now() - c.pausedAt), pausedAt: null } : { ...c, pausedAt: Date.now() })) }, clock.pausedAt ? t("Resume") : t("Pause")),
                h("button", { type: "button", onClick: () => setClock({ target: 0, started: null, paused: 0, pausedAt: null }) }, t("Stop")),
              ),
            )
          : h(Fragment, null,
              h("span", null, t("Sprint against the clock")),
              h("div", { className: "xff-clock-btns" }, [15, 30, 45].map((m) => h("button", { key: m, type: "button", onClick: () => start(m) }, m + " " + t("min")))),
            ),
      ),
    ),
    h("div", { className: "xff-body" },
      h("aside", { className: "xff-queue", "aria-label": t("Visitors") },
        h("div", { className: "xff-filters", role: "tablist" }, FILTERS.map(([k, label]) => h("button", { key: k, type: "button", role: "tab", "aria-selected": filter === k, onClick: () => { setFilter(k); setCur(null); } }, t(label), h("span", null, counts[k])))),
        h("div", { className: "xff-search" },
          h(Icon, { n: "search", size: 20 }),
          h("input", { type: "search", value: q, onChange: (e) => setQ(e.target.value), placeholder: t("Company, person, country"), "aria-label": t("Search the visitors") }),
          counts.mine > 0 && counts.mine < counts.all ? h("label", { className: "xff-mine" }, h("input", { type: "checkbox", checked: mine, onChange: (e) => setMine(e.target.checked) }), t("Mine")) : null,
        ),
        list.length === 0
          ? h("div", { className: "xff-queue-empty" }, filter === "waiting" ? h(Fragment, null, h(Icon, { n: "trophy", size: 32 }), h("b", null, t("Nobody is waiting.")), h("span", null, t("Every visitor of this fair has heard from us."))) : h("span", null, t("Nobody here.")))
          : h("ol", { className: "xff-list" }, list.slice(0, 400).map((x, i) => h("li", { key: x.id },
              h("button", { type: "button", "aria-current": v && x.id === v.id ? "true" : undefined, onClick: () => setCur(x.id), ref: v && x.id === v.id ? (el) => el && el.scrollIntoView && el.scrollIntoView({ block: "nearest" }) : undefined },
                h("span", { className: cx("xff-dot", "xff-dot--" + state(x)) }),
                h("span", { className: "xff-li-main" }, h("b", null, x.company || [x.name, x.lastName].filter(Boolean).join(" ") || t("No name")), h("small", null, [[x.name, x.lastName].filter(Boolean).join(" "), x.country].filter(Boolean).join(" · "))),
                x.score != null ? h("span", { className: cx("xff-score", isHot(x) && "is-hot") }, x.score) : null,
              ),
            ))),
        list.length > 400 ? h("p", { className: "tx-small tx-muted", style: { padding: "10px 15px", margin: 0 } }, t("The first 400 are shown. Search to narrow the list.")) : null,
      ),
      !v
        ? h("main", { className: "xff-main" }, h(Empty, { icon: counts.waiting === 0 ? "trophy" : "person-search", title: counts.waiting === 0 ? t("This fair is done.") : t("Choose a visitor on the left.") }, counts.waiting === 0 ? t("Everybody we met has been contacted. Look at the contacted ones to plan the next step.") : null))
        : h("main", { className: "xff-main" },
            h("article", { className: "xff-card" },
              h("header", { className: "xff-card-head" },
                h("div", null,
                  h("div", { className: "xff-card-chips" },
                    state(v) === "waiting" ? h(Chip, { tone: isHot(v) ? "bad" : "warn", icon: isHot(v) ? "local-fire-department" : "hourglass-empty" }, isHot(v) ? t("Hot, and waiting") : t("Waiting")) : state(v) === "parked" ? h(Chip, { icon: "snooze" }, v.parked === "closed" ? t("Closed") : t("Parked")) : h(Chip, { tone: "good", icon: "check-circle" }, t("Contacted")),
                    v.thankedAt ? h(Chip, { icon: "mark-email-read" }, t("Thank-you sent")) : null,
                    v.offers > 0 ? h(Chip, { icon: "request-quote" }, t("{n} offers", { n: v.offers })) : null,
                    v.sap ? h(Chip, { tone: "good", icon: "verified" }, t("Customer")) : null,
                    v.todoDue ? h(Chip, { icon: "task-alt" }, t("To-do open")) : null,
                  ),
                  h("h2", null, v.company || person || t("No name")),
                  h("p", { className: "xff-who" }, [person, v.position, [v.city, v.country].filter(Boolean).join(", ")].filter(Boolean).join(" · ")),
                  v.owner && !v.mine ? h("p", { className: "tx-small tx-muted", style: { margin: 0 } }, t("Looked after by {name}", { name: v.owner })) : null,
                ),
                h("span", { className: "xff-pos" }, idx + 1, " / ", list.length),
              ),
              h("div", { className: "xff-contact" },
                v.email ? h("a", { href: "mailto:" + String(v.email).split(/[,; ]/)[0] }, h(Icon, { n: "mail", size: 20 }), String(v.email).split(/[,; ]/)[0]) : null,
                v.tel || v.mobile ? h("a", { href: "tel:" + String(v.mobile || v.tel).replace(/\s/g, "") }, h(Icon, { n: "call", size: 20 }), v.mobile || v.tel) : null,
                wa ? h("a", { href: "https://wa.me/" + wa, target: "_blank", rel: "noreferrer" }, h(Icon, { n: "chat", size: 20 }), "WhatsApp") : null,
                v.website ? h("a", { href: /^https?:/.test(v.website) ? v.website : "https://" + v.website, target: "_blank", rel: "noreferrer" }, h(Icon, { n: "language", size: 20 }), t("Web site")) : null,
              ),
              h("div", { className: "xff-cols" },
                h("section", { className: "xff-stand" },
                  h("h3", null, t("At the stand")),
                  v.notes ? h("p", { className: "xff-quote" }, v.notes) : h("p", { className: "tx-muted" }, t("Nothing was written down at the stand.")),
                  v.interestedIn || v.products.length || v.workArea ? h("div", { className: "xff-tags" }, v.workArea ? h(Chip, null, v.workArea) : null, v.products.map((p) => h(Chip, { key: p }, p)), v.interestedIn ? h(Chip, null, v.interestedIn) : null) : null,
                ),
                h("section", { className: "xff-last" },
                  h("h3", null, t("Since the fair")),
                  v.lastNote ? h(Fragment, null, h("p", { className: "xff-quote" }, v.lastNote.text || t(v.lastNote.type)), h("small", { className: "tx-muted" }, [t(v.lastNote.type), v.lastNote.by, ago(v.lastNote.at, t)].filter(Boolean).join(" · "), v.touches > 1 ? " · " + t("{n} contacts in all", { n: v.touches }) : "")) : h("p", { className: "xff-none" }, h(Icon, { n: "hourglass-empty", size: 20 }), t("Nobody has contacted them yet.")),
                ),
              ),
              h("div", { className: "xff-rate", role: "group", "aria-label": t("Your rating") },
                h("span", null, t("How good is this lead?"), v.rate == null && v.aiRate != null ? h("small", null, " · " + t("the system thinks {n}", { n: Math.round(v.aiRate / 10) })) : null),
                h("div", null, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((n) => h("button", { key: n, type: "button", "aria-pressed": v.rate === n, className: n >= 7 ? "is-hot" : "", onClick: () => rate(n) }, n))),
              ),
              h("form", { className: "xff-note", onSubmit: save },
                h("div", { className: "xff-types", role: "group", "aria-label": t("What was it") }, TYPES.map(([k, label, icon]) => h("button", { key: k, type: "button", "aria-pressed": type === k, onClick: () => setType(k) }, h(Icon, { n: icon, size: 20 }), t(label)))),
                h("textarea", { ref: noteRef, value: text, rows: 3, placeholder: t("What did you say to each other? What is the next step?"), "aria-label": t("Your note"), onChange: (e) => { setText(e.target.value); if (msg) setMsg(null); } }),
                h("div", { className: "xff-note-foot" },
                  h("label", null, t("Remind me"), h("select", { value: follow, onChange: (e) => setFollow(parseInt(e.target.value, 10)) }, h("option", { value: 0 }, t("no reminder")), h("option", { value: 1 }, t("tomorrow")), h("option", { value: 3 }, t("in 3 working days")), h("option", { value: 5 }, t("in a week")), h("option", { value: 10 }, t("in two weeks")))),
                  msg ? h("span", { className: "tx-err", role: "alert" }, msg) : null,
                  h("button", { type: "submit", className: "tc-btn tc-btn--md xff-save", disabled: busy }, busy ? t("Saving ...") : t("Save and next"), h("kbd", null, "Ctrl ↵")),
                ),
              ),
              h("footer", { className: "xff-actions" },
                h(Link, { className: "tc-btn tc-btn--secondary tc-btn--sm", to: `/cards/${v.id}/thank-you` }, h(Icon, { n: "mail", size: 16 }), v.thankedAt ? t("Write again") : t("Thank-you e-mail")),
                h(Link, { className: "tc-btn tc-btn--secondary tc-btn--sm", to: `/cards/${v.id}/thank-you?tab=offer` }, h(Icon, { n: "request-quote", size: 16 }), t("Make an offer")),
                h(Link, { className: "tc-btn tc-btn--secondary tc-btn--sm", to: `/cards/${v.id}/review` }, h(Icon, { n: "open-in-new", size: 16 }), t("Open the customer")),
                h("span", { className: "xff-actions-end" },
                  v.parked
                    ? h("button", { type: "button", className: "tc-btn tc-btn--ghost tc-btn--sm", onClick: unpark }, h(Icon, { n: "undo", size: 16 }), t("Bring back"))
                    : h(Fragment, null,
                        h("button", { type: "button", className: "tc-btn tc-btn--ghost tc-btn--sm", onClick: () => park("later") }, h(Icon, { n: "snooze", size: 16 }), t("Later"), h("kbd", null, "L")),
                        h("button", { type: "button", className: "tc-btn tc-btn--ghost tc-btn--sm", onClick: () => park("closed") }, h(Icon, { n: "block", size: 16 }), t("Not for us"), h("kbd", null, "X")),
                      ),
                  h("button", { type: "button", className: "tc-btn tc-btn--ghost tc-btn--sm", onClick: () => go(1), disabled: idx >= list.length - 1 }, t("Skip"), h(Icon, { n: "arrow-forward", size: 16 })),
                ),
              ),
            ),
            h("p", { className: "xff-keys" }, h("kbd", null, "↑"), h("kbd", null, "↓"), " ", t("move"), " · ", h("kbd", null, "1"), "–", h("kbd", null, "9"), h("kbd", null, "0"), " ", t("rate"), " · ", h("kbd", null, "W"), " ", t("write"), " · ", h("kbd", null, "L"), " ", t("later"), " · ", h("kbd", null, "X"), " ", t("not for us"), " · ", h("kbd", null, "↵"), " ", t("open")),
          ),
    ),
  );
}
