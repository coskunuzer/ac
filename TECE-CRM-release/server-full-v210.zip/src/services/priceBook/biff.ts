import * as XLSX from 'xlsx';

// Reads the formatting that SheetJS' community build drops from legacy .xls
// (Excel 97-2003, BIFF8) files: fonts, borders, alignment, rich-text runs, and
// print setup. SheetJS already supplies values, formulas, fills, number
// formats, merges, column widths and row heights; this adds what is needed to
// print a worksheet exactly as Excel does.

export interface FontInfo {
  name: string;
  size: number; // points
  bold: boolean;
  italic: boolean;
  underline: boolean;
  strike: boolean;
  color: string | null; // hex RGB without '#', null = automatic (black)
}

export interface BorderSide {
  style: 'none' | 'thin' | 'medium' | 'dashed' | 'dotted' | 'thick' | 'double' | 'hair';
  color: string | null;
}

export interface XfInfo {
  font: number;
  horizontal: 'general' | 'left' | 'center' | 'right' | 'fill' | 'justify' | 'centerAcross' | 'distributed';
  vertical: 'top' | 'center' | 'bottom' | 'justify';
  wrap: boolean;
  shrink: boolean; // "shrink to fit": the font is reduced until the text fits the cell
  indent: number;
  left: BorderSide;
  right: BorderSide;
  top: BorderSide;
  bottom: BorderSide;
}

export interface RichRun {
  text: string;
  font: FontInfo;
}

export interface SheetPrint {
  // Print_Area as 0-based inclusive cell bounds, when the sheet defines one.
  area: { r1: number; c1: number; r2: number; c2: number } | null;
  paperSize: number;
  landscape: boolean;
  scale: number;
  fitToPage: boolean;
  fitWidth: number;
  fitHeight: number;
  header: string;
  footer: string;
  centerHorizontally: boolean;
  // Manual page breaks: 0-based rows that start a new page.
  pageBreaks: number[];
}

export interface SheetPicture {
  // Anchor in 0-based cell coordinates, offsets as fractions of the cell (0..1).
  from: { col: number; row: number; dx: number; dy: number };
  to: { col: number; row: number; dx: number; dy: number };
  image: number; // index into BiffData.pictures (1-based, as Excel stores it)
}

export interface BiffSheet {
  xfByCell: Map<string, number>; // "r,c" (0-based) -> XF index
  sstByCell: Map<string, number>; // "r,c" -> shared string index (text cells)
  pictures: SheetPicture[];
  print: SheetPrint;
}

export interface BiffPicture {
  kind: 'jpeg' | 'png' | 'emf' | 'wmf' | 'other';
  data: Buffer | null;
}

export interface BiffData {
  fonts: FontInfo[];
  xfs: XfInfo[];
  sheets: Map<string, BiffSheet>;
  // Rich-text runs per shared-string index (only strings that have them).
  richStrings: Map<number, { start: number; font: FontInfo }[]>;
  // Picture store (1-based in shape references, so index 0 is a placeholder).
  pictures: BiffPicture[];
}

// Excel's default 56-colour palette (indices 8..63); a PALETTE record overrides it.
const DEFAULT_PALETTE = [
  '000000', 'FFFFFF', 'FF0000', '00FF00', '0000FF', 'FFFF00', 'FF00FF', '00FFFF',
  '800000', '008000', '000080', '808000', '800080', '008080', 'C0C0C0', '808080',
  '9999FF', '993366', 'FFFFCC', 'CCFFFF', '660066', 'FF8080', '0066CC', 'CCCCFF',
  '000080', 'FF00FF', 'FFFF00', '00FFFF', '800080', '800000', '008080', '0000FF',
  '00CCFF', 'CCFFFF', 'CCFFCC', 'FFFF99', '99CCFF', 'FF99CC', 'CC99FF', 'FFCC99',
  '3366FF', '33CCCC', '99CC00', 'FFCC00', 'FF9900', 'FF6600', '666699', '969696',
  '003366', '339966', '003300', '333300', '993300', '993366', '333399', '333333',
];

const BORDER_STYLES: BorderSide['style'][] = ['none', 'thin', 'medium', 'dashed', 'dotted', 'thick', 'double', 'hair', 'medium', 'dashed', 'medium', 'dashed', 'medium', 'dashed'];
const H_ALIGN: XfInfo['horizontal'][] = ['general', 'left', 'center', 'right', 'fill', 'justify', 'centerAcross', 'distributed'];
const V_ALIGN: XfInfo['vertical'][] = ['top', 'center', 'bottom', 'justify'];

interface Rec {
  type: number;
  offset: number;
  data: Buffer;
}

function* records(stream: Buffer, from = 0): Generator<Rec> {
  let pos = from;
  while (pos + 4 <= stream.length) {
    const type = stream.readUInt16LE(pos);
    const len = stream.readUInt16LE(pos + 2);
    yield { type, offset: pos, data: stream.subarray(pos + 4, pos + 4 + len) };
    pos += 4 + len;
  }
}

function readUnicode(data: Buffer, pos: number, cch: number, wide: boolean): string {
  return wide ? data.toString('utf16le', pos, pos + cch * 2) : data.toString('latin1', pos, pos + cch);
}

function parseFont(d: Buffer, palette: string[]): FontInfo {
  const height = d.readUInt16LE(0);
  const flags = d.readUInt16LE(2);
  const icv = d.readUInt16LE(4);
  const weight = d.readUInt16LE(6);
  const underline = d.readUInt8(10);
  const cch = d.readUInt8(14);
  const wide = (d.readUInt8(15) & 1) === 1;
  return {
    name: readUnicode(d, 16, cch, wide),
    size: height / 20,
    bold: weight >= 700,
    italic: (flags & 0x02) !== 0,
    underline: underline !== 0,
    strike: (flags & 0x08) !== 0,
    color: colorOf(icv, palette),
  };
}

// null means "automatic" (black text / no explicit border colour).
function colorOf(icv: number, palette: string[]): string | null {
  if (icv === 0x7fff || icv === 64) return null;
  if (icv === 65) return 'FFFFFF';
  if (icv < 8) return DEFAULT_PALETTE[icv];
  return palette[icv - 8] ?? null;
}

function side(style: number, icv: number, palette: string[]): BorderSide {
  const s = BORDER_STYLES[style] ?? 'thin';
  return { style: s, color: s === 'none' ? null : colorOf(icv, palette) };
}

function parseXf(d: Buffer, palette: string[]): XfInfo {
  const align = d.readUInt8(6);
  const indent = d.readUInt8(8) & 0x0f;
  const borders = d.readUInt16LE(10);
  const colors1 = d.readUInt16LE(12);
  const colors2 = d.readUInt32LE(14);
  return {
    font: d.readUInt16LE(0),
    horizontal: H_ALIGN[align & 0x07] ?? 'general',
    vertical: V_ALIGN[(align >> 4) & 0x07] ?? 'bottom',
    wrap: (align & 0x08) !== 0,
    shrink: (d.readUInt8(8) & 0x10) !== 0,
    indent,
    left: side(borders & 0x0f, colors1 & 0x7f, palette),
    right: side((borders >> 4) & 0x0f, (colors1 >> 7) & 0x7f, palette),
    top: side((borders >> 8) & 0x0f, colors2 & 0x7f, palette),
    bottom: side((borders >> 12) & 0x0f, (colors2 >> 7) & 0x7f, palette),
  };
}

// Strings in the shared-string table can be split across CONTINUE records;
// a continued string restarts with a flags byte that may change the char width.
function parseSst(chunks: Buffer[], fonts: (i: number) => FontInfo): Map<number, { start: number; font: FontInfo }[]> {
  const rich = new Map<number, { start: number; font: FontInfo }[]>();
  let ci = 0;
  let pos = 8; // skip cstTotal, cstUnique in the first chunk
  const cur = () => chunks[ci];
  const ensure = (n: number): boolean => {
    while (pos + n > cur().length) {
      if (ci + 1 >= chunks.length) return false;
      ci++;
      pos = 0;
    }
    return true;
  };
  const u8 = () => { ensure(1); return cur().readUInt8(pos++); };
  const u16 = () => { ensure(2); const v = cur().readUInt16LE(pos); pos += 2; return v; };
  const u32 = () => { ensure(4); const v = cur().readUInt32LE(pos); pos += 4; return v; };
  const total = chunks[0].readUInt32LE(4);

  for (let i = 0; i < total; i++) {
    if (ci >= chunks.length || (ci === chunks.length - 1 && pos >= cur().length)) break;
    const cch = u16();
    const flags = u8();
    let wide = (flags & 1) === 1;
    const hasExt = (flags & 4) !== 0;
    const isRich = (flags & 8) !== 0;
    const cRun = isRich ? u16() : 0;
    const cbExt = hasExt ? u32() : 0;

    // characters (possibly spanning a CONTINUE boundary)
    let remaining = cch;
    while (remaining > 0) {
      if (pos >= cur().length) {
        if (ci + 1 >= chunks.length) break;
        ci++;
        pos = 0;
        wide = (u8() & 1) === 1;
      }
      const bytesPer = wide ? 2 : 1;
      const take = Math.min(remaining, Math.floor((cur().length - pos) / bytesPer));
      pos += take * bytesPer;
      remaining -= take;
      if (take === 0 && pos < cur().length) { pos = cur().length; }
    }

    if (isRich && cRun > 0) {
      const runs: { start: number; font: FontInfo }[] = [];
      for (let r = 0; r < cRun; r++) {
        const start = u16();
        const ifnt = u16();
        runs.push({ start, font: fonts(ifnt) });
      }
      rich.set(i, runs);
    }
    // skip phonetic data
    let skip = cbExt;
    while (skip > 0) {
      if (pos >= cur().length) { if (ci + 1 >= chunks.length) break; ci++; pos = 0; }
      const n = Math.min(skip, cur().length - pos);
      pos += n;
      skip -= n;
    }
  }
  return rich;
}

function parseCellXfs(rec: Rec, out: Map<string, number>, sst: Map<string, number>) {
  const d = rec.data;
  if (rec.type === 0x00fd) sst.set(`${d.readUInt16LE(0)},${d.readUInt16LE(2)}`, d.readUInt32LE(6));
  switch (rec.type) {
    case 0x0201: case 0x0203: case 0x00fd: case 0x027e: case 0x0006: case 0x0205: case 0x0204: // BLANK NUMBER LABELSST RK FORMULA BOOLERR LABEL
      out.set(`${d.readUInt16LE(0)},${d.readUInt16LE(2)}`, d.readUInt16LE(4));
      break;
    case 0x00be: { // MULBLANK
      const row = d.readUInt16LE(0);
      const first = d.readUInt16LE(2);
      const last = d.readUInt16LE(d.length - 2);
      for (let c = first; c <= last; c++) out.set(`${row},${c}`, d.readUInt16LE(4 + (c - first) * 2));
      break;
    }
    case 0x00bd: { // MULRK
      const row = d.readUInt16LE(0);
      const first = d.readUInt16LE(2);
      const last = d.readUInt16LE(d.length - 2);
      for (let c = first; c <= last; c++) out.set(`${row},${c}`, d.readUInt16LE(4 + (c - first) * 6));
      break;
    }
  }
}

function parsePrintArea(d: Buffer, sheetIndex: number): { sheet: number; area: SheetPrint['area'] } | null {
  // NAME record: built-in Print_Area (code 6) with a single PtgArea3d.
  const flags = d.readUInt16LE(0);
  const cch = d.readUInt8(3);
  const cce = d.readUInt16LE(4);
  const itab = d.readUInt16LE(8);
  if ((flags & 0x20) === 0 || cch !== 1) return null;
  const nameStart = 14 + 1; // fixed header (14) + 1 flags byte for the name string
  if (d.readUInt8(nameStart) !== 0x06) return null;
  const rgce = d.subarray(nameStart + 1, nameStart + 1 + cce);
  if (rgce.length < 11 || rgce.readUInt8(0) !== 0x3b) return null;
  void sheetIndex;
  return {
    sheet: itab - 1,
    area: { r1: rgce.readUInt16LE(3), r2: rgce.readUInt16LE(5), c1: rgce.readUInt16LE(7) & 0x3fff, c2: rgce.readUInt16LE(9) & 0x3fff },
  };
}

function headerFooterText(d: Buffer): string {
  if (d.length < 3) return '';
  const cch = d.readUInt16LE(0);
  const wide = (d.readUInt8(2) & 1) === 1;
  return readUnicode(d, 3, cch, wide);
}

// ---- pictures (Escher / Office drawing records) -----------------------------

const EMF_TYPE = 0xf01a;
const WMF_TYPE = 0xf01b;
const JPEG_TYPES = [0xf01d, 0xf02a];
const PNG_TYPE = 0xf01e;

function readPictureStore(group: Buffer): BiffPicture[] {
  const pictures: BiffPicture[] = [{ kind: 'other', data: null }]; // shapes refer to pictures 1-based

  const walk = (start: number, end: number) => {
    let p = start;
    while (p + 8 <= end) {
      const verInst = group.readUInt16LE(p);
      const type = group.readUInt16LE(p + 2);
      const len = group.readUInt32LE(p + 4);
      const body = p + 8;
      if ((verInst & 0xf) === 0xf) walk(body, Math.min(end, body + len));
      else if (type === 0xf007) {
        const size = group.readUInt32LE(body + 20);
        const cbName = group.readUInt8(body + 33);
        const bs = body + 36 + cbName;
        if (size === 0 || bs + 8 > end) {
          pictures.push({ kind: 'other', data: null });
        } else {
          const blipInst = group.readUInt16LE(bs) >> 4;
          const blipType = group.readUInt16LE(bs + 2);
          const blipLen = group.readUInt32LE(bs + 4);
          const blipEnd = Math.min(group.length, bs + 8 + blipLen);
          const twoUids = blipInst === 0x46b || blipInst === 0x6e3 || blipInst === 0x6e1;
          if (JPEG_TYPES.includes(blipType)) {
            pictures.push({ kind: 'jpeg', data: Buffer.from(group.subarray(bs + 8 + 16 + (twoUids ? 16 : 0) + 1, blipEnd)) });
          } else if (blipType === PNG_TYPE) {
            pictures.push({ kind: 'png', data: Buffer.from(group.subarray(bs + 8 + 16 + (twoUids ? 16 : 0) + 1, blipEnd)) });
          } else if (blipType === EMF_TYPE) {
            // metafile header + compressed records, without the picture id(s)
            pictures.push({ kind: 'emf', data: Buffer.from(group.subarray(bs + 8 + 16 + (blipInst === 0x3d5 ? 16 : 0), blipEnd)) });
          } else {
            pictures.push({ kind: blipType === WMF_TYPE ? 'wmf' : 'other', data: null });
          }
        }
      }
      p = body + len;
    }
  };
  walk(0, group.length);
  return pictures;
}

// Pulls (picture index, anchor) pairs out of one MSODRAWING record's Escher data.
function readSheetPictures(drawing: Buffer, out: SheetPicture[]) {
  const walk = (start: number, end: number) => {
    let p = start;
    while (p + 8 <= end) {
      const verInst = drawing.readUInt16LE(p);
      const type = drawing.readUInt16LE(p + 2);
      const len = drawing.readUInt32LE(p + 4);
      const body = p + 8;
      if (type === 0xf004) {
        // SpContainer: one shape - look for its picture property and anchor
        let pib = 0;
        let anchor: SheetPicture['from'][] | null = null;
        let q = body;
        const stop = Math.min(end, body + len);
        while (q + 8 <= stop) {
          const vi = drawing.readUInt16LE(q);
          const t = drawing.readUInt16LE(q + 2);
          const l = drawing.readUInt32LE(q + 4);
          if (t === 0xf00b) {
            const n = vi >> 4;
            for (let i = 0; i < n; i++) {
              const o = q + 8 + i * 6;
              if (o + 6 > stop) break;
              if ((drawing.readUInt16LE(o) & 0x3fff) === 0x0104) pib = drawing.readUInt32LE(o + 2);
            }
          } else if (t === 0xf010 && l >= 18) {
            const o = q + 8;
            const frac = (col: number, dx: number, row: number, dy: number) => ({ col, row, dx: dx / 1024, dy: dy / 256 });
            anchor = [
              frac(drawing.readUInt16LE(o + 2), drawing.readUInt16LE(o + 4), drawing.readUInt16LE(o + 6), drawing.readUInt16LE(o + 8)),
              frac(drawing.readUInt16LE(o + 10), drawing.readUInt16LE(o + 12), drawing.readUInt16LE(o + 14), drawing.readUInt16LE(o + 16)),
            ];
          }
          q += 8 + l;
        }
        if (pib > 0 && anchor) out.push({ from: anchor[0], to: anchor[1], image: pib });
      } else if ((verInst & 0xf) === 0xf) {
        walk(body, Math.min(end, body + len));
      }
      p = body + len;
    }
  };
  walk(0, drawing.length);
}

export function readBiff(buffer: Buffer): BiffData | null {
  const cfb = XLSX.CFB.read(buffer, { type: 'buffer' });
  const entry = XLSX.CFB.find(cfb, '/Workbook') || XLSX.CFB.find(cfb, '/Book');
  if (!entry) return null;
  const stream = Buffer.from(entry.content as Uint8Array);

  const rawFonts: Buffer[] = [];
  const rawXfs: Buffer[] = [];
  let palette = [...DEFAULT_PALETTE];
  const boundSheets: { name: string; offset: number }[] = [];
  const sstChunks: Buffer[] = [];
  const dgChunks: Buffer[] = [];
  const printAreas = new Map<number, SheetPrint['area']>();

  let inGlobals = true;
  let inSst = false;
  let inDg = false;
  for (const rec of records(stream)) {
    if (!inGlobals) break;
    switch (rec.type) {
      case 0x0031: rawFonts.push(rec.data); break;
      case 0x00e0: rawXfs.push(rec.data); break;
      case 0x0092: {
        const n = rec.data.readUInt16LE(0);
        palette = Array.from({ length: n }, (_, i) => {
          const o = 2 + i * 4;
          return [rec.data[o], rec.data[o + 1], rec.data[o + 2]].map((b) => b.toString(16).padStart(2, '0')).join('').toUpperCase();
        });
        break;
      }
      case 0x0085: {
        const d = rec.data;
        const cch = d.readUInt8(6);
        const wide = (d.readUInt8(7) & 1) === 1;
        boundSheets.push({ name: readUnicode(d, 8, cch, wide), offset: d.readUInt32LE(0) });
        break;
      }
      case 0x00fc: sstChunks.push(rec.data); break;
      case 0x00eb: dgChunks.push(rec.data); break;
      case 0x003c: if (inSst) sstChunks.push(rec.data); else if (inDg) dgChunks.push(rec.data); break;
      case 0x0018: {
        const pa = parsePrintArea(rec.data, 0);
        if (pa) printAreas.set(pa.sheet, pa.area);
        break;
      }
      case 0x000a: inGlobals = false; break;
    }
    if (rec.type === 0x00fc) inSst = true;
    else if (rec.type !== 0x003c) inSst = false;
    if (rec.type === 0x00eb) inDg = true;
    else if (rec.type !== 0x003c) inDg = false;
  }

  // font index 4 is never used (an Excel quirk): indices >= 4 are shifted by one
  const parsed = rawFonts.map((d) => parseFont(d, palette));
  const fontList = parsed.length ? [...parsed.slice(0, 4), parsed[3], ...parsed.slice(4)] : [];
  const fontAt = (i: number): FontInfo => fontList[i] ?? fontList[0];
  const xfs = rawXfs.map((d) => parseXf(d, palette));
  const richStrings = sstChunks.length ? parseSst(sstChunks, fontAt) : new Map();

  const sheets = new Map<string, BiffSheet>();
  boundSheets.forEach((bs, index) => {
    const xfByCell = new Map<string, number>();
    const sstByCell = new Map<string, number>();
    const pictures: SheetPicture[] = [];
    const print: SheetPrint = {
      area: printAreas.get(index) ?? null,
      paperSize: 9, landscape: false, scale: 100, fitToPage: false, fitWidth: 1, fitHeight: 1,
      header: '', footer: '', centerHorizontally: false, pageBreaks: [],
    };
    let depth = 0;
    for (const rec of records(stream, bs.offset)) {
      if (rec.type === 0x0809) { depth++; continue; }
      if (rec.type === 0x000a) { depth--; if (depth <= 0) break; continue; }
      if (depth !== 1) continue;
      parseCellXfs(rec, xfByCell, sstByCell);
      switch (rec.type) {
        case 0x00ec: readSheetPictures(rec.data, pictures); break;
        case 0x0014: print.header = headerFooterText(rec.data); break;
        case 0x0015: print.footer = headerFooterText(rec.data); break;
        case 0x001b: {
          const n = rec.data.readUInt16LE(0);
          for (let i = 0; i < n; i++) print.pageBreaks.push(rec.data.readUInt16LE(2 + i * 6));
          break;
        }
        case 0x0083: print.centerHorizontally = rec.data.readUInt16LE(0) !== 0; break;
        case 0x0081: print.fitToPage = (rec.data.readUInt16LE(0) & 0x0100) !== 0; break;
        case 0x00a1: {
          const d = rec.data;
          print.paperSize = d.readUInt16LE(0);
          print.scale = d.readUInt16LE(2);
          print.fitWidth = d.readUInt16LE(6);
          print.fitHeight = d.readUInt16LE(8);
          print.landscape = (d.readUInt16LE(10) & 0x0002) === 0;
          break;
        }
      }
    }
    sheets.set(bs.name, { xfByCell, sstByCell, pictures, print });
  });

  return {
    fonts: fontList,
    xfs,
    sheets,
    richStrings,
    pictures: dgChunks.length ? readPictureStore(Buffer.concat(dgChunks)) : [{ kind: 'other', data: null }],
  };
}

export function fontOf(data: BiffData, xf: XfInfo): FontInfo {
  return data.fonts[xf.font] ?? data.fonts[0];
}

export function richRunsOf(text: string, runs: { start: number; font: FontInfo }[], base: FontInfo): RichRun[] {
  const out: RichRun[] = [];
  const first = runs[0]?.start ?? text.length;
  if (first > 0) out.push({ text: text.slice(0, first), font: base });
  runs.forEach((run, i) => {
    const end = runs[i + 1]?.start ?? text.length;
    if (end > run.start) out.push({ text: text.slice(run.start, end), font: run.font });
  });
  return out;
}
