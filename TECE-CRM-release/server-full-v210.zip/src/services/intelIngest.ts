/* eslint-disable @typescript-eslint/no-explicit-any */
import fs from 'fs';
import path from 'path';
import zlib from 'zlib';
import { db } from '../db/connection';
import { ISO2 } from '../data/isoNames';

// Sales intelligence: reading the SAP files. The Excel files are big (a year of sales is 12 MB and 66,000 rows), so they are read in a separate
// process: the CRM keeps answering people while the file is being read. The sales list is then kept as a SUMMARY (see 084_sales_intel.sql),
// and the internal mirror invoices of the trading company (DHL.MAHSUP) are dropped so that nothing is counted twice.

import { parseInChild, type IntelKind } from './intelParse';
export type { IntelKind };
export const INTEL_KINDS: IntelKind[] = ['sales', 'stock', 'kartela', 'master'];
import { aggregateRows, horizonFor, monthEnd, HORIZON_MONTHS, type Agg } from './intelAggregate';

const log = (kind: string, file: string, rows: number, added: number, note: string, by: number) =>
  db.prepare('INSERT INTO intel_uploads (kind, file_name, rows, added, note, by_user) VALUES (?, ?, ?, ?, ?, ?)').run(kind, file, rows, added, note, by);

export interface IntelUploadResult { kind: IntelKind | 'history'; file: string; rows: number; added: number; note: string }

// ---------------------------------------------------------------- the summary of the sales list
export { type Agg, aggregateRows, horizonFor, HORIZON_MONTHS, monthEnd };

// put a summary into the tables. 'upload': the months in the file are replaced (a month is never added twice). 'history': everything up to `through` is replaced.
export function applyAgg(agg: Agg, mode: 'upload' | 'history'): { note: string; months: number } {
  const monthsIn = new Set<string>(); for (const m of agg.month) monthsIn.add(String(m[0]));
  const ms = [...monthsIn].sort(); if (!ms.length) throw new Error('The file has no sales lines.');
  const first = ms[0], last = ms[ms.length - 1];
  const evDates = agg.events.map((e) => String(e[1])).sort();
  const have = db.prepare('SELECT MAX(last_date) d FROM intel_cust').get() as { d: string | null };
  const cut = [have.d ?? '', agg.through ?? '', evDates[evDates.length - 1] ?? ''].sort().pop()!; const H = horizonFor(cut);
  if (mode === 'upload') {
    if (first < H) throw new Error(`This file goes back to ${first}. Only the last ${HORIZON_MONTHS} months are kept month by month and the older years are already in the history. Export from ${H}-01 or later.`);
    const minDate = evDates[0] ?? '';
    if (minDate && minDate.slice(8, 10) !== '01') {
      const early = db.prepare('SELECT COUNT(*) n FROM intel_events WHERE d >= ? AND d < ?').get(`${first}-01`, minDate) as { n: number };
      if (early.n > 0) throw new Error(`The file starts on ${minDate}, but ${first} is already stored from its first day. Start the SAP export on the 1st of the month (${first}-01) so the month is replaced whole and nothing is counted twice.`);
    }
  }
  db.exec('BEGIN');
  try {
    if (mode === 'history') {
      const through = agg.through ?? monthEnd(last);
      db.prepare("DELETE FROM intel_fact WHERE period <= ? OR period LIKE '%-00'").run(through.slice(0, 7));
      db.prepare('DELETE FROM intel_month WHERE ym <= ?').run(through.slice(0, 7));
      db.prepare("DELETE FROM intel_spec WHERE period <= ? OR period LIKE '%-00'").run(through.slice(0, 7));
      db.prepare('DELETE FROM intel_events WHERE d <= ?').run(through);
    } else {
      const delFact = db.prepare('DELETE FROM intel_fact WHERE period = ?'), delMonth = db.prepare('DELETE FROM intel_month WHERE ym = ?'), delSpec = db.prepare('DELETE FROM intel_spec WHERE period = ?');
      for (const m of ms) { delFact.run(m); delMonth.run(m); delSpec.run(m); }
      db.prepare('DELETE FROM intel_events WHERE d >= ? AND d <= ?').run(`${first}-01`, monthEnd(last));
    }
    const f = db.prepare('INSERT OR REPLACE INTO intel_fact (period, customer, material, doc_type, reason, thickness, width, eur, meters, m2, kg) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    for (const r of agg.fact) f.run(...(r as (string | number)[]));
    const mo = db.prepare('INSERT OR REPLACE INTO intel_month (ym, ch, grp, eur, m2, meters) VALUES (?, ?, ?, ?, ?, ?)'); for (const r of agg.month) mo.run(...(r as (string | number)[]));
    const sp = db.prepare('INSERT OR REPLACE INTO intel_spec (period, thickness, width, grp, eur, meters) VALUES (?, ?, ?, ?, ?, ?)'); for (const r of agg.spec) sp.run(...(r as (string | number)[]));
    const ev = db.prepare('INSERT OR REPLACE INTO intel_events (customer, d, eur) VALUES (?, ?, ?)'); for (const r of agg.events) ev.run(...(r as (string | number)[]));
    const cu = db.prepare(`INSERT INTO intel_cust (code, name, region, city, rep, first_date, last_date) VALUES (?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(code) DO UPDATE SET first_date = MIN(first_date, excluded.first_date),
        name = CASE WHEN excluded.last_date >= last_date THEN COALESCE(NULLIF(excluded.name, ''), name) ELSE name END,
        region = CASE WHEN excluded.last_date >= last_date THEN COALESCE(NULLIF(excluded.region, ''), region) ELSE region END,
        city = CASE WHEN excluded.last_date >= last_date THEN COALESCE(NULLIF(excluded.city, ''), city) ELSE city END,
        rep = CASE WHEN excluded.last_date >= last_date THEN COALESCE(NULLIF(excluded.rep, ''), rep) ELSE rep END, last_date = MAX(last_date, excluded.last_date)`);
    for (const r of agg.cust) cu.run(...(r as string[]));
    const mt = db.prepare(`INSERT INTO intel_mat (code, descr, grp, typ, fin, first_date, last_date) VALUES (?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(code) DO UPDATE SET first_date = MIN(first_date, excluded.first_date),
        descr = CASE WHEN excluded.last_date >= last_date THEN COALESCE(NULLIF(excluded.descr, ''), descr) ELSE descr END,
        grp = CASE WHEN excluded.last_date >= last_date THEN excluded.grp ELSE grp END, typ = CASE WHEN excluded.last_date >= last_date THEN excluded.typ ELSE typ END,
        fin = CASE WHEN excluded.last_date >= last_date THEN excluded.fin ELSE fin END, last_date = MAX(last_date, excluded.last_date)`);
    for (const r of agg.mat) mt.run(...(r as string[]));
    compact();
    db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); throw e; }
  db.prepare("DELETE FROM intel_cache WHERE key = 'bundle'").run();
  return { note: `${agg.fact.length} summary rows for ${ms.length} month(s), ${first} to ${last}.`, months: ms.length };
}

// months older than the horizon are folded into one row per year (the thickness and width detail goes with them)
export function compact(): void {
  const have = db.prepare('SELECT MAX(last_date) d FROM intel_cust').get() as { d: string | null }; if (!have.d) return;
  const H = horizonFor(have.d);
  db.prepare(`INSERT INTO intel_fact (period, customer, material, doc_type, reason, thickness, width, eur, meters, m2, kg)
    SELECT substr(period, 1, 4) || '-00', customer, material, doc_type, reason, 0, 0, SUM(eur), SUM(meters), SUM(m2), SUM(kg) FROM intel_fact WHERE period < ? AND period NOT LIKE '%-00' GROUP BY 1, 2, 3, 4, 5
    ON CONFLICT(period, customer, material, doc_type, reason, thickness, width) DO UPDATE SET eur = eur + excluded.eur, meters = meters + excluded.meters, m2 = m2 + excluded.m2, kg = kg + excluded.kg`).run(H);
  db.prepare("DELETE FROM intel_fact WHERE period < ? AND period NOT LIKE '%-00'").run(H);
  db.prepare(`INSERT INTO intel_spec (period, thickness, width, grp, eur, meters) SELECT substr(period, 1, 4) || '-00', thickness, width, grp, SUM(eur), SUM(meters) FROM intel_spec WHERE period < ? AND period NOT LIKE '%-00' GROUP BY 1, 2, 3, 4
    ON CONFLICT(period, thickness, width, grp) DO UPDATE SET eur = eur + excluded.eur, meters = meters + excluded.meters`).run(H);
  db.prepare("DELETE FROM intel_spec WHERE period < ? AND period NOT LIKE '%-00'").run(H);
}

export async function ingestIntel(kind: IntelKind, buffer: Buffer, fileName: string, userId: number): Promise<IntelUploadResult> {
  const out = await parseInChild(kind, buffer);
  if (out.error) throw new Error(out.error);
  const rows = out.rows;
  let added = 0, note = '';
  if (kind === 'sales') {
    const ds = rows.map((r) => String(r[3])).sort();
    const have = db.prepare('SELECT MAX(last_date) d FROM intel_cust').get() as { d: string | null };
    const cut = [have.d ?? '', ds[ds.length - 1] ?? ''].sort().pop()!;
    const r = applyAgg(aggregateRows(rows, horizonFor(cut)), 'upload');
    added = rows.length; note = `${rows.length} lines read (${ds[0]} to ${ds[ds.length - 1]}); ${r.note} ${out.skipped ?? 0} internal mirror invoices left out. The month(s) in the file were replaced, never added twice.`;
  } else {
    db.exec('BEGIN');
    try {
      if (kind === 'stock') {
        db.exec('DELETE FROM intel_stock');
        const ins = db.prepare('INSERT INTO intel_stock (grp, grp_name, material, description, thickness, width, roll_length, qty, m2, depot, customer, customer_name, sales_doc, item, received, form) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        for (const r of rows) ins.run(...(r as (string | number)[]));
        added = rows.length; note = `${rows.length} edge band stock lots. The earlier stock list was replaced.`;
      } else if (kind === 'master') {
        // one account can be listed once per sales organisation: the first filled value of each field is kept
        const byCode = new Map<string, (string | number)[]>();
        for (const r of rows as (string | number)[][]) {
          const k = String(r[0]); const o = byCode.get(k);
          if (!o) byCode.set(k, [...r]); else for (let i = 1; i < r.length; i++) if (!o[i] && r[i]) o[i] = r[i];
        }
        db.exec('DELETE FROM intel_master');
        const ins = db.prepare('INSERT INTO intel_master (code, name, iso, country, city, province, incoterm, incoterm_place, pay_code, pay_days, email, phone, channel, blocked) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        for (const o of byCode.values()) {
          const iso = String(o[2] || ''), pay = String(o[7] || ''), m = /^Z(\d{3})$/.exec(pay);
          ins.run(String(o[0]), String(o[1] || ''), iso, ISO2[iso]?.name ?? '', String(o[3] || ''), String(o[4] || ''), String(o[5] || ''), String(o[6] || ''), pay, m ? Number(m[1]) : null, String(o[8] || ''), String(o[9] || ''), String(o[10] || ''), Number(o[11] || 0));
        }
        added = byCode.size; note = `${byCode.size} SAP accounts with country, incoterm and payment time. The earlier customer list was replaced.`;
      } else {
        db.exec('DELETE FROM intel_kartela'); db.exec('DELETE FROM intel_surface');
        const ins = db.prepare('INSERT INTO intel_kartela (list_name, section, no, code, match_code, producer, availability, surface) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        for (const r of rows) ins.run(...(r as (string | number)[]));
        const si = db.prepare('INSERT OR REPLACE INTO intel_surface (code, name) VALUES (?, ?)'); for (const s of out.surf ?? []) si.run(s[0], s[1]);
        added = rows.length; note = `${rows.length} kartela rows, ${(out.surf ?? []).length} surface types. The earlier kartela was replaced.`;
      }
      db.exec('COMMIT');
    } catch (e) { db.exec('ROLLBACK'); throw e; }
    db.prepare("DELETE FROM intel_cache WHERE key = 'bundle'").run();
  }
  log(kind, fileName, rows.length, added, note, userId);
  return { kind, file: fileName, rows: rows.length, added, note };
}

// the summary of the old years, shipped with the CRM (server/assets/intel/history.json.gz): one click instead of eight big uploads
export const HISTORY_FILE = path.resolve(__dirname, '../../assets/intel/history.json.gz');
export const historyAvailable = () => fs.existsSync(HISTORY_FILE);
// Which months the shipped history would add: nothing is overwritten that is already there. earliest = the first month stored now ('' = nothing stored yet).
export function historyGap(): { shipped: boolean; earliest: string; needs: boolean; first: string | null } {
  if (!historyAvailable()) return { shipped: false, earliest: '', needs: false, first: null };
  const e = db.prepare('SELECT MIN(ym) m FROM intel_month').get() as { m: string | null };
  const earliest = e.m ?? '';
  // the history starts in January 2019: if the first stored month is later than that, the old years are missing
  return { shipped: true, earliest, needs: !earliest || earliest > '2019-01', first: '2019-01' };
}
function readHistory(): Agg { return JSON.parse(zlib.gunzipSync(fs.readFileSync(HISTORY_FILE)).toString('utf8')) as Agg; }
// keeps only what is older than the month `before` (YYYY-MM), so the months that were uploaded are never replaced by the older summary
function olderThan(agg: Agg, before: string): Agg {
  const yr = before.slice(0, 4);
  const per = (p: string) => (p.endsWith('-00') ? p.slice(0, 4) < yr : p.slice(0, 7) < before);
  const prev = new Date(Date.UTC(+before.slice(0, 4), +before.slice(5, 7) - 1, 0)).toISOString().slice(0, 10);
  return { through: prev, cust: agg.cust, mat: agg.mat, fact: agg.fact.filter((r) => per(String(r[0]))), month: agg.month.filter((r) => String(r[0]) < before), spec: agg.spec.filter((r) => per(String(r[0]))), events: agg.events.filter((r) => String(r[1]) < before + '-01') };
}
export function loadHistory(userId: number, auto = false): IntelUploadResult {
  if (!historyAvailable()) throw new Error('The history file is not on this server (assets/intel/history.json.gz).');
  let agg = readHistory();
  const gap = historyGap();
  if (auto && gap.earliest) agg = olderThan(agg, gap.earliest); // newer months that are already stored stay as they are
  if (!agg.month.length) return { kind: 'history', file: 'history.json.gz', rows: 0, added: 0, note: 'Nothing older to add.' };
  const r = applyAgg(agg, 'history');
  const note = `History loaded up to ${agg.through}: ${r.note} Upload the sales list only from the 1st of the next month on.${auto ? ' (Added automatically: the old years were missing.)' : ''}`;
  log('history', 'history.json.gz', agg.fact.length, agg.fact.length, note, userId);
  return { kind: 'history', file: 'history.json.gz', rows: agg.fact.length, added: agg.fact.length, note };
}
// called when an admin opens the analysis or uploads the sales list: if the old years are not in yet, they are added (one step, no big uploads)
export function ensureHistory(userId: number): IntelUploadResult | null {
  const g = historyGap();
  if (!g.shipped || !g.needs) return null;
  try { return loadHistory(userId, true); } catch { return null; }
}
