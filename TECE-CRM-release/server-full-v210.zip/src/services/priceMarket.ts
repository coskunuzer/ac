import { marketsOf, type Viewer } from './visibility';

// Which market's price list this person may use for a given market, or null if none: the domestic team never gets
// the export prices (and the export team never the domestic ones) unless an admin has granted that market.
export function priceMarketFor(user: Viewer & { market?: string }, wanted: string | null | undefined): 'export' | 'domestic' | null {
  const market = wanted === 'domestic' ? 'domestic' : 'export';
  return marketsOf(user).has(market) ? market : null;
}
