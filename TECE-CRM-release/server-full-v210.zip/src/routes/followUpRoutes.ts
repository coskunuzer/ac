import { Router } from 'express';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { db } from '../db/connection';
import { visibilitySql } from '../services/visibility';
import type { CardRow } from '../models/cardModel';
import { offerLogModel } from '../models/pricingModels';
import { buildPlan, type PlanTask } from '../services/followUpPlan';
import { userModel } from '../models/userModel';
import { exhibitionModel } from '../models/exhibitionModel';
import { resolveTemplate } from '../services/thankYouEmail';
import { mailProblems, realFairIds } from '../services/emailSafety';

// Follow-ups: what should happen next, customer by customer. Offers and chases come before thank-yous; thank-yous are reviewed and sent
// as a batch. Every thank-you draft carries its safety check, so a draft with a hole in it can be seen (and cannot be sent).
const router = Router();
router.use(requireAuth);

type Kind = 'offer' | 'chase' | 'thank_you' | 'reminder' | 'check';
const ORDER: Record<Kind, number> = { offer: 0, chase: 1, reminder: 2, thank_you: 3, check: 4 };
const WHEN: Record<string, number> = { now: 0, this_week: 1, later: 2 };

router.get('/', (req: AuthedRequest, res) => {
  const user = req.user!;
  const params: Record<string, string | number> = {};
  const vis = visibilitySql(user, params);
  const open = db.prepare(`SELECT * FROM cards WHERE (stage IS NULL OR stage IN ('contacted', 'interested', 'quoted'))${vis ? ` AND ${vis}` : ''} ORDER BY created_at DESC LIMIT 3000`).all(params) as unknown as CardRow[];
  const ids = new Set(open.map((c) => c.id));
  const plan = buildPlan(open, offerLogModel.listForIdSet(ids), new Date(), 1500);
  const byId = new Map(open.map((c) => [c.id, c]));
  const fairs = realFairIds();

  const rows: {
    key: string; cardId: number; name: string | null; company: string | null; country: string | null; email: string | null; rate: number | null;
    kind: Kind; label: string; detail: string | null; when: string; score: number; summary: string | null;
    draft?: { subject: string; body: string; problems: string[] };
  }[] = [];
  for (const it of plan) {
    for (const task of it.tasks as PlanTask[]) {
      const kind = task.kind as Kind;
      const row: (typeof rows)[number] = { key: `${it.id}:${kind}`, cardId: it.id, name: it.name, company: it.company, country: it.country, email: it.email, rate: it.rate, kind, label: task.label, detail: task.detail, when: task.when, score: it.score, summary: it.summary };
      if (kind === 'thank_you') {
        const card = byId.get(it.id);
        if (card) {
          const ex = exhibitionModel.findById(card.exhibition_id);
          const responsible = card.person ? userModel.findByDisplayName(card.person) : undefined;
          const custom = responsible?.email_template_subject && responsible?.email_template_body ? { subject: responsible.email_template_subject, body: responsible.email_template_body } : null;
          const exTpl = ex?.email_template_subject && ex?.email_template_body ? { subject: ex.email_template_subject, body: ex.email_template_body } : null;
          const fairName = ex?.name ?? null;
          const t = resolveTemplate(card, fairName, custom, exTpl);
          const problems = mailProblems({ subject: t.subject, body: t.body, kind: 'thank_you', fairName: fairs.has(card.exhibition_id) ? fairName : null }).map((p) => p.message);
          row.draft = { subject: t.subject, body: t.body, problems };
        }
      }
      rows.push(row);
    }
  }
  rows.sort((a, b) => ORDER[a.kind] - ORDER[b.kind] || (WHEN[a.when] ?? 3) - (WHEN[b.when] ?? 3) || b.score - a.score);

  const counts: Record<string, number> = { all: rows.length, offer: 0, chase: 0, thank_you: 0, reminder: 0 };
  for (const r of rows) if (counts[r.kind] !== undefined) counts[r.kind] += 1;
  res.json({
    counts,
    drafts: { ready: rows.filter((r) => r.draft && !r.draft.problems.length).length, blocked: rows.filter((r) => r.draft && r.draft.problems.length).length },
    rows: rows.slice(0, 600),
  });
});

export default router;
