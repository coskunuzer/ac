-- Coaching reports (Performance > My team / My performance): one row per report, kept with the facts it was made from.
-- user_id = the person the report is about, by_user = who asked for it. facts_json = every number and named list (the report shows its numbers
-- from here, never from the AI text); ai_json = the words (summary, strengths, improve, plan30, explore), from the AI or from the rules (kind).
CREATE TABLE IF NOT EXISTS coaching_reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  by_user INTEGER REFERENCES users(id) ON DELETE SET NULL,
  lang TEXT NOT NULL DEFAULT 'tr',
  kind TEXT NOT NULL DEFAULT 'rules',
  facts_json TEXT NOT NULL,
  ai_json TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  sent_at TEXT,
  sent_to TEXT
);
CREATE INDEX IF NOT EXISTS idx_coaching_reports_user ON coaching_reports (user_id, created_at);
