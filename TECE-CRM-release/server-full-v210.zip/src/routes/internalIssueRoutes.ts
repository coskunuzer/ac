import { Router, type Response } from 'express';
import { shrinkUpload } from '../services/shrinkImage';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import multer from 'multer';
import { db } from '../db/connection';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { userModel } from '../models/userModel';
import { todoModel } from '../services/todos';
import { complaintsDir, ensureDir, imagePath } from '../services/complaints';
import { ensurePanel, isQuality, qualityEmails, sendNotice } from '../services/quality';
import { settingsModel } from '../models/settingsModel';

// Internal complaints: what the company must know even when the customer says nothing. Not official (no number, nothing to the customer or to sales as a status).
// Anybody can report one; the admin and quality read all of them, send them to departments and close them. Mounted under /api/quality/internal.
const router = Router();
router.use(requireAuth);
router.use((_req, _res, next) => { ensurePanel(); next(); });

export const KINDS = ['short_quantity', 'over_quantity', 'wrong_product', 'wrong_spec', 'late_delivery', 'packaging', 'quality_found', 'documents', 'other'] as const;
const str = (v: unknown, max = 2000) => String(v ?? '').trim().slice(0, max);
const numOf = (v: unknown): number | null => { if (v === null || v === undefined || String(v).trim() === '') return null; const n = Number(String(v).replace(',', '.')); return Number.isFinite(n) ? n : null; };
const day = (v: unknown): string | null => { const s = str(v, 10); return /^\d{4}-\d{2}-\d{2}$/.test(s) ? s : null; };
const nameOf = (id: number | null) => (id ? userModel.findById(id)?.display_name ?? null : null);

interface Issue {
  id: number; created_by: number; created_at: string; updated_at: string; kind: string; title: string; description: string | null; card_id: number | null; customer_name: string | null; order_no: string | null; product_code: string | null;
  unit: string; ordered_qty: number | null; shipped_qty: number | null; severity: string; customer_aware: number | null; cost_est: number | null; currency: string; status: string; source_dept: string | null; result: string | null; action: string | null; closed_at: string | null;
}
interface Task { id: number; issue_id: number; department: string; owner_user_id: number | null; due_date: string | null; instruction: string | null; answer: string | null; state: string; created_at: string; answered_at: string | null }
const issueOf = (id: number) => db.prepare('SELECT * FROM internal_issues WHERE id = ?').get(id) as Issue | undefined;
const log = (id: number, userId: number | null, kind: string, note: string | null) => db.prepare('INSERT INTO internal_issue_events (issue_id, user_id, kind, note) VALUES (?, ?, ?, ?)').run(id, userId, kind, note);
const gap = (i: Pick<Issue, 'ordered_qty' | 'shipped_qty'>) => (i.ordered_qty !== null && i.shipped_qty !== null ? Math.round((i.shipped_qty - i.ordered_qty) * 100) / 100 : null);
const gapPct = (i: Pick<Issue, 'ordered_qty' | 'shipped_qty'>) => (i.ordered_qty && i.shipped_qty !== null ? Math.round(((i.shipped_qty - i.ordered_qty) / i.ordered_qty) * 1000) / 10 : null);
const myDepartments = (userId: number) => (db.prepare('SELECT name FROM complaint_departments WHERE head_user_id = ?').all(userId) as { name: string }[]).map((r) => r.name);
const may = (req: AuthedRequest, i: Issue) => isQuality(req.user!) || i.created_by === req.user!.id;
function needQuality(req: AuthedRequest, res: Response): boolean { if (isQuality(req.user!)) return true; res.status(403).json({ error: 'Only the admin and quality read the internal complaints.' }); return false; }

const shape = (i: Issue) => ({
  id: i.id, kind: i.kind, title: i.title, description: i.description, cardId: i.card_id, customer: i.customer_name, orderNo: i.order_no, product: i.product_code, unit: i.unit, ordered: i.ordered_qty, shipped: i.shipped_qty, gap: gap(i), gapPct: gapPct(i),
  severity: i.severity, customerAware: i.customer_aware, cost: i.cost_est, currency: i.currency, status: i.status, sourceDept: i.source_dept, result: i.result, action: i.action, by: nameOf(i.created_by), createdAt: i.created_at, closedAt: i.closed_at,
  openTasks: (db.prepare("SELECT COUNT(*) AS n FROM internal_issue_tasks WHERE issue_id = ? AND state != 'accepted'").get(i.id) as { n: number }).n,
});

router.get('/meta', (_req, res) => {
  const deps = (db.prepare('SELECT name FROM complaint_departments ORDER BY name').all() as { name: string }[]).map((d) => d.name);
  // who is told by e-mail the moment a complaint is reported (shown on the form so nobody has to guess)
  const notifies = [...new Set([...qualityEmails(), ...(settingsModel.get('complaint_to') ?? '').split(/[,;\s]+/)].map((e) => String(e).trim()).filter((e) => e.includes('@')))];
  res.json({ kinds: KINDS, departments: deps, notifies });
});

// anybody may report
router.post('/', async (req: AuthedRequest, res) => {
  const b = (req.body ?? {}) as Record<string, unknown>;
  const kind = (KINDS as readonly string[]).includes(str(b.kind)) ? str(b.kind) : 'other';
  const title = str(b.title, 160);
  if (!title) return res.status(400).json({ error: 'Write a short title.' });
  const cardId = Number.isInteger(Number(b.cardId)) && Number(b.cardId) > 0 ? Number(b.cardId) : null;
  const r = db.prepare(`INSERT INTO internal_issues (created_by, kind, title, description, card_id, customer_name, order_no, product_code, unit, ordered_qty, shipped_qty, severity, customer_aware, cost_est, currency, source_dept)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(req.user!.id, kind, title, str(b.description, 4000) || null, cardId, str(b.customer, 160) || null, str(b.orderNo, 80) || null, str(b.product, 80) || null, ['m', 'm²', 'kg', 'pcs', 'rolls'].includes(str(b.unit, 6)) ? str(b.unit, 6) : 'm', numOf(b.ordered), numOf(b.shipped),
      ['low', 'normal', 'high'].includes(str(b.severity, 8)) ? str(b.severity, 8) : 'normal', b.customerAware === true || b.customerAware === 1 ? 1 : b.customerAware === false || b.customerAware === 0 ? 0 : null, numOf(b.cost), ['EUR', 'USD', 'TRY'].includes(str(b.currency, 3)) ? str(b.currency, 3) : 'EUR', str(b.sourceDept, 80) || null);
  const id = Number(r.lastInsertRowid);
  log(id, req.user!.id, 'created', null);
  const i = issueOf(id)!;
  // the people who must know are told at once (in Turkish: it stays inside TECE)
  const g = gap(i);
  void sendNotice([...qualityEmails(), ...(settingsModel.get('complaint_to') ?? '').split(/[,;\s]+/)], `İç şikayet: ${i.title}`,
    `Merhaba,\n\n${req.user!.display_name || req.user!.username} bir iç şikayet bildirdi (resmi şikayet değildir).\n\nKonu: ${i.title}\n${i.customer_name ? `Müşteri: ${i.customer_name}\n` : ''}${i.order_no ? `Sipariş: ${i.order_no}\n` : ''}${g !== null ? `Fark: ${g} ${i.unit} (${gapPct(i)} %)\n` : ''}${i.customer_aware === 0 ? 'Müşteri bundan haberdar değil.\n' : ''}\nCRM > Şikayetler > İç şikayetler ekranından görebilirsiniz.`);
  res.status(201).json({ id });
});

router.get('/', (req: AuthedRequest, res) => {
  const q = req.query as Record<string, string>;
  const where: string[] = []; const p: unknown[] = [];
  if (!isQuality(req.user!)) { where.push('created_by = ?'); p.push(req.user!.id); }
  if (q.status === 'open') where.push("status != 'closed'"); else if (q.status) { where.push('status = ?'); p.push(q.status); }
  if (q.kind) { where.push('kind = ?'); p.push(q.kind); }
  if (q.severity) { where.push('severity = ?'); p.push(q.severity); }
  if (q.q) { where.push("LOWER(COALESCE(title,'') || ' ' || COALESCE(customer_name,'') || ' ' || COALESCE(order_no,'') || ' ' || COALESCE(product_code,'')) LIKE ?"); p.push(`%${q.q.toLowerCase()}%`); }
  const rows = db.prepare(`SELECT * FROM internal_issues${where.length ? ` WHERE ${where.join(' AND ')}` : ''} ORDER BY id DESC LIMIT 500`).all(...(p as never[])) as unknown as Issue[];
  res.json({ rows: rows.map(shape) });
});

// the radar: what is going on, and what repeats
router.get('/dashboard', (req: AuthedRequest, res) => {
  if (!needQuality(req, res)) return;
  const all = <T,>(sql: string, ...a: unknown[]) => db.prepare(sql).all(...(a as never[])) as T[];
  const one = <T,>(sql: string, ...a: unknown[]) => db.prepare(sql).get(...(a as never[])) as T;
  const year = new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' }).slice(0, 4);
  const short = one<{ n: number; m: number; ship: number }>("SELECT COUNT(*) AS n, COALESCE(SUM(ordered_qty - shipped_qty), 0) AS m, COALESCE(SUM(ordered_qty), 0) AS ship FROM internal_issues WHERE kind = 'short_quantity' AND unit = 'm' AND ordered_qty IS NOT NULL AND shipped_qty IS NOT NULL AND substr(created_at, 1, 4) = ?", year);
  res.json({
    open: one<{ n: number }>("SELECT COUNT(*) AS n FROM internal_issues WHERE status != 'closed'").n, closed: one<{ n: number }>("SELECT COUNT(*) AS n FROM internal_issues WHERE status = 'closed'").n,
    high: one<{ n: number }>("SELECT COUNT(*) AS n FROM internal_issues WHERE status != 'closed' AND severity = 'high'").n,
    silent: one<{ n: number }>("SELECT COUNT(*) AS n FROM internal_issues WHERE customer_aware = 0 AND status != 'closed'").n,
    lateTasks: one<{ n: number }>("SELECT COUNT(*) AS n FROM internal_issue_tasks WHERE state = 'open' AND due_date IS NOT NULL AND due_date < date('now', 'localtime')").n,
    shortMeters: Math.round(short.m), shortCases: short.n, shortPct: short.ship ? Math.round((short.m / short.ship) * 1000) / 10 : null,
    byKind: all<{ kind: string; n: number }>('SELECT kind, COUNT(*) AS n FROM internal_issues GROUP BY kind ORDER BY n DESC'),
    byDept: all<{ dept: string; n: number }>("SELECT COALESCE(NULLIF(source_dept, ''), department) AS dept, COUNT(*) AS n FROM (SELECT i.id, i.source_dept, (SELECT t.department FROM internal_issue_tasks t WHERE t.issue_id = i.id ORDER BY t.id LIMIT 1) AS department FROM internal_issues i) WHERE COALESCE(NULLIF(source_dept, ''), department) IS NOT NULL GROUP BY 1 ORDER BY n DESC LIMIT 10"),
    byCustomer: all<{ customer: string; n: number }>("SELECT customer_name AS customer, COUNT(*) AS n FROM internal_issues WHERE COALESCE(customer_name, '') != '' GROUP BY LOWER(customer_name) ORDER BY n DESC LIMIT 8"),
    monthly: all<{ m: string; n: number }>("SELECT substr(created_at, 1, 7) AS m, COUNT(*) AS n FROM internal_issues WHERE substr(created_at, 1, 4) = ? GROUP BY m ORDER BY m", year),
    // the same kind of trouble again within 60 days, for the same customer or product: a pattern, not an accident
    repeats: all<{ kind: string; customer: string | null; product: string | null; n: number; last: string }>(`SELECT kind, customer_name AS customer, product_code AS product, COUNT(*) AS n, MAX(substr(created_at, 1, 10)) AS last FROM internal_issues
      WHERE created_at >= datetime('now', '-60 days') AND (COALESCE(customer_name, '') != '' OR COALESCE(product_code, '') != '') GROUP BY kind, LOWER(COALESCE(customer_name, '')), UPPER(COALESCE(product_code, '')) HAVING COUNT(*) > 1 ORDER BY n DESC LIMIT 8`),
    year,
  });
});

// a department head: the questions for their departments (before '/:id')
router.get('/tasks/mine', (req: AuthedRequest, res) => {
  const deps = myDepartments(req.user!.id);
  const marks = deps.map(() => '?').join(',');
  const rows = db.prepare(`SELECT t.*, i.title, i.customer_name, i.order_no, i.kind, i.description FROM internal_issue_tasks t JOIN internal_issues i ON i.id = t.issue_id WHERE (t.owner_user_id = ?${deps.length ? ` OR t.department IN (${marks})` : ''}) ORDER BY (t.state = 'open') DESC, t.due_date`).all(req.user!.id, ...deps) as unknown as (Task & { title: string; customer_name: string | null; order_no: string | null; kind: string; description: string | null })[];
  res.json({ tasks: rows.map((t) => ({ id: t.id, issueId: t.issue_id, department: t.department, due: t.due_date, instruction: t.instruction, answer: t.answer, state: t.state, title: t.title, customer: t.customer_name, order: t.order_no, kind: t.kind, description: t.description })) });
});
router.put('/tasks/:tid/answer', (req: AuthedRequest, res) => {
  const t = db.prepare('SELECT * FROM internal_issue_tasks WHERE id = ?').get(parseInt(String(req.params.tid), 10)) as Task | undefined;
  if (!t) return res.status(404).json({ error: 'Not found' });
  if (!isQuality(req.user!) && t.owner_user_id !== req.user!.id && !myDepartments(req.user!.id).includes(t.department)) return res.status(403).json({ error: 'This question is not for you.' });
  const answer = str(req.body?.answer, 3000);
  if (!answer) return res.status(400).json({ error: 'Write the answer.' });
  db.prepare("UPDATE internal_issue_tasks SET answer = ?, state = 'answered', answered_at = datetime('now') WHERE id = ?").run(answer, t.id);
  log(t.issue_id, req.user!.id, 'answer', `${t.department}: ${answer}`);
  const left = (db.prepare("SELECT COUNT(*) AS n FROM internal_issue_tasks WHERE issue_id = ? AND state = 'open'").get(t.issue_id) as { n: number }).n;
  if (!left) db.prepare("UPDATE internal_issues SET status = 'review', updated_at = datetime('now') WHERE id = ? AND status = 'with_dept'").run(t.issue_id);
  res.json({ ok: true });
});

function full(i: Issue) {
  return {
    ...shape(i),
    tasks: (db.prepare('SELECT * FROM internal_issue_tasks WHERE issue_id = ? ORDER BY id').all(i.id) as unknown as Task[]).map((t) => ({ id: t.id, department: t.department, owner: nameOf(t.owner_user_id), due: t.due_date, instruction: t.instruction, answer: t.answer, state: t.state, answeredAt: t.answered_at })),
    events: (db.prepare('SELECT * FROM internal_issue_events WHERE issue_id = ? ORDER BY id DESC').all(i.id) as { id: number; user_id: number | null; at: string; kind: string; note: string | null }[]).map((e) => ({ id: e.id, who: nameOf(e.user_id), at: e.at, kind: e.kind, note: e.note })),
    files: (db.prepare('SELECT id, original_name, uploaded_by, uploaded_at FROM internal_issue_files WHERE issue_id = ? ORDER BY id').all(i.id) as { id: number; original_name: string | null; uploaded_by: number | null; uploaded_at: string }[]).map((f) => ({ id: f.id, name: f.original_name, by: nameOf(f.uploaded_by), at: f.uploaded_at })),
  };
}
router.get('/:id', (req: AuthedRequest, res) => {
  const i = issueOf(parseInt(String(req.params.id), 10));
  if (!i) return res.status(404).json({ error: 'Not found' });
  if (!may(req, i)) return res.status(403).json({ error: 'You do not have access to this.' });
  res.json(full(i));
});

router.put('/:id', (req: AuthedRequest, res) => {
  if (!needQuality(req, res)) return;
  const i = issueOf(parseInt(String(req.params.id), 10));
  if (!i) return res.status(404).json({ error: 'Not found' });
  const b = (req.body ?? {}) as Record<string, unknown>;
  const has = (k: string) => Object.prototype.hasOwnProperty.call(b, k);
  db.prepare("UPDATE internal_issues SET severity = ?, kind = ?, source_dept = ?, result = ?, action = ?, updated_at = datetime('now') WHERE id = ?")
    .run(['low', 'normal', 'high'].includes(str(b.severity, 8)) ? str(b.severity, 8) : i.severity, (KINDS as readonly string[]).includes(str(b.kind)) ? str(b.kind) : i.kind, has('sourceDept') ? str(b.sourceDept, 80) || null : i.source_dept, has('result') ? str(b.result, 4000) || null : i.result, has('action') ? str(b.action, 4000) || null : i.action, i.id);
  res.json(full(issueOf(i.id)!));
});

router.post('/:id/status', (req: AuthedRequest, res) => {
  if (!needQuality(req, res)) return;
  const i = issueOf(parseInt(String(req.params.id), 10));
  if (!i) return res.status(404).json({ error: 'Not found' });
  const to = str(req.body?.to, 12);
  if (!['new', 'review', 'with_dept', 'closed'].includes(to)) return res.status(400).json({ error: 'Unknown status.' });
  if (to === 'closed' && !(i.result?.trim() || i.action?.trim())) return res.status(400).json({ error: 'Write the result or the action before closing.' });
  if (to === 'closed' && (db.prepare("SELECT COUNT(*) AS n FROM internal_issue_tasks WHERE issue_id = ? AND state = 'open'").get(i.id) as { n: number }).n) return res.status(400).json({ error: 'A department has not answered yet.' });
  db.prepare("UPDATE internal_issues SET status = ?, closed_at = CASE WHEN ? = 'closed' THEN datetime('now') ELSE NULL END, updated_at = datetime('now') WHERE id = ?").run(to, to, i.id);
  log(i.id, req.user!.id, 'status', `${i.status} → ${to}${req.body?.note ? `: ${str(req.body.note, 500)}` : ''}`);
  res.json(full(issueOf(i.id)!));
});
router.post('/:id/note', (req: AuthedRequest, res) => {
  const i = issueOf(parseInt(String(req.params.id), 10));
  if (!i) return res.status(404).json({ error: 'Not found' });
  if (!may(req, i)) return res.status(403).json({ error: 'No access' });
  const text = str(req.body?.text, 2000);
  if (!text) return res.status(400).json({ error: 'Write the note.' });
  log(i.id, req.user!.id, 'note', text);
  res.json(full(i));
});

// to the departments, like an official complaint, but unofficial
router.post('/:id/forward', async (req: AuthedRequest, res) => {
  if (!needQuality(req, res)) return;
  const i = issueOf(parseInt(String(req.params.id), 10));
  if (!i) return res.status(404).json({ error: 'Not found' });
  const list = (Array.isArray(req.body?.departments) ? req.body.departments : []) as { name?: string; due?: string }[];
  const instruction = str(req.body?.instruction, 1000);
  if (!list.length) return res.status(400).json({ error: 'Choose at least one department.' });
  const known = new Set((db.prepare('SELECT name FROM complaint_departments').all() as { name: string }[]).map((d) => d.name));
  if (list.some((d) => !known.has(String(d.name)))) return res.status(400).json({ error: 'Unknown department.' });
  for (const d of list) {
    const name = String(d.name);
    const dep = db.prepare('SELECT head_user_id, head_email FROM complaint_departments WHERE name = ?').get(name) as { head_user_id: number | null; head_email: string | null };
    db.prepare('INSERT INTO internal_issue_tasks (issue_id, department, owner_user_id, due_date, instruction) VALUES (?, ?, ?, ?, ?)').run(i.id, name, dep.head_user_id, day(d.due), instruction || null);
    log(i.id, req.user!.id, 'forward', `${name}${day(d.due) ? ` (${day(d.due)})` : ''}`);
    if (dep.head_user_id && day(d.due)) todoModel.add({ userId: dep.head_user_id, cardId: null, text: `İç şikayet #${i.id}: ${name} yanıtı`, dueDate: day(d.due)! });
    const head = dep.head_user_id ? userModel.findById(dep.head_user_id) : null;
    void sendNotice([head?.email ?? '', dep.head_email ?? ''], `İç şikayet - ${name}: ${i.title}`, `Merhaba,\n\n${name} birimi için resmi olmayan bir iç şikayet açıldı.\n\nKonu: ${i.title}\n${i.customer_name ? `Müşteri: ${i.customer_name}\n` : ''}${i.order_no ? `Sipariş: ${i.order_no}\n` : ''}${instruction ? `Not: ${instruction}\n` : ''}${day(d.due) ? `Son tarih: ${day(d.due)}\n` : ''}\nLütfen CRM > Görevlerim ekranından yanıtlayın.`);
  }
  db.prepare("UPDATE internal_issues SET status = 'with_dept', updated_at = datetime('now') WHERE id = ? AND status != 'closed'").run(i.id);
  res.json(full(issueOf(i.id)!));
});
router.post('/tasks/:tid/accept', (req: AuthedRequest, res) => {
  if (!needQuality(req, res)) return;
  const t = db.prepare('SELECT * FROM internal_issue_tasks WHERE id = ?').get(parseInt(String(req.params.tid), 10)) as Task | undefined;
  if (!t) return res.status(404).json({ error: 'Not found' });
  db.prepare("UPDATE internal_issue_tasks SET state = 'accepted' WHERE id = ?").run(t.id);
  log(t.issue_id, req.user!.id, 'accepted', t.department);
  res.json(full(issueOf(t.issue_id)!));
});

// photos and files
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 15 * 1024 * 1024, files: 6 } });
const TYPES: Record<string, string> = { 'image/jpeg': '.jpg', 'image/png': '.png', 'application/pdf': '.pdf', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': '.xlsx', 'application/vnd.ms-excel': '.xls', 'message/rfc822': '.eml', 'application/vnd.ms-outlook': '.msg' };
router.post('/:id/files', upload.array('files', 6), async (req: AuthedRequest, res) => {
  const i = issueOf(parseInt(String(req.params.id), 10));
  if (!i) return res.status(404).json({ error: 'Not found' });
  if (!may(req, i)) return res.status(403).json({ error: 'No access' });
  ensureDir();
  for (const f of (req.files as Express.Multer.File[]) ?? []) {
    const name = Buffer.from(f.originalname, 'latin1').toString('utf8');
    const ext = TYPES[f.mimetype] ?? (['.msg', '.eml', '.pdf', '.xlsx', '.xls', '.jpg', '.jpeg', '.png'].includes(path.extname(name).toLowerCase()) ? path.extname(name).toLowerCase() : undefined);
    if (!ext) return res.status(400).json({ error: 'Photos, PDF, Excel or e-mail files only.' });
    const small = await shrinkUpload(f, ext);
    const stored = `i${i.id}-${crypto.randomBytes(6).toString('hex')}${small.ext}`;
    fs.writeFileSync(path.join(complaintsDir, stored), small.buffer);
    db.prepare('INSERT INTO internal_issue_files (issue_id, stored_name, original_name, uploaded_by) VALUES (?, ?, ?, ?)').run(i.id, stored, name.slice(0, 140), req.user!.id);
  }
  res.json(full(i));
});
router.get('/:id/files/:fid', (req: AuthedRequest, res) => {
  const i = issueOf(parseInt(String(req.params.id), 10));
  const f = db.prepare('SELECT stored_name, original_name FROM internal_issue_files WHERE id = ? AND issue_id = ?').get(parseInt(String(req.params.fid), 10), parseInt(String(req.params.id), 10)) as { stored_name: string; original_name: string | null } | undefined;
  if (!i || !f || !fs.existsSync(imagePath(f.stored_name))) return res.status(404).json({ error: 'Not found' });
  if (!may(req, i)) return res.status(403).json({ error: 'No access' });
  res.download(imagePath(f.stored_name), f.original_name ?? f.stored_name);
});

export default router;
