import fs from 'fs';
import path from 'path';
import sharp from 'sharp';
import { paths } from '../config/env';
import { cardModel } from '../models/cardModel';

// Phone photos are 3-5 MB; a form is perfectly readable at 1600 px, which is
// about 100-200 KB (roughly 90 % smaller). The AI reads the full-quality photo
// first; only the copy that is kept is shrunk.
const MAX_SIDE = 1600;
const QUALITY = 75;
// Photos already smaller than this are left alone.
const SKIP_BELOW_BYTES = 300 * 1024;

// Re-encodes the stored photo as a smaller JPEG (orientation baked in) and
// removes the original. Returns the new file name (it can change extension),
// or the old one if shrinking would not help or fails.
export async function compressScan(fileName: string): Promise<string> {
  const source = path.join(paths.uploadsDir, fileName);
  try {
    const before = fs.statSync(source).size;
    if (before < SKIP_BELOW_BYTES && /\.jpe?g$/i.test(fileName)) return fileName;

    const target = path.join(paths.uploadsDir, `${path.parse(fileName).name}.jpg`);
    const temp = `${target}.tmp`;
    await sharp(source)
      .rotate()
      .resize({ width: MAX_SIDE, height: MAX_SIDE, fit: 'inside', withoutEnlargement: true })
      .jpeg({ quality: QUALITY, mozjpeg: true })
      .toFile(temp);
    const after = fs.statSync(temp).size;
    if (after >= before) {
      fs.unlinkSync(temp);
      return fileName;
    }
    fs.renameSync(temp, target); // replaces the original when it was already a .jpg
    if (path.resolve(target) !== path.resolve(source)) fs.unlinkSync(source);
    return path.basename(target);
  } catch (err) {
    console.error('Could not shrink scan', fileName, err);
    return fileName;
  }
}

// One pass over every stored scan (runs in the background at start-up; a scan
// that is already small is skipped, so later runs cost almost nothing).
export async function compressExistingScans(): Promise<{ shrunk: number; savedBytes: number }> {
  let shrunk = 0;
  let savedBytes = 0;
  for (const card of cardModel.listAll()) {
    if (!card.image_path) continue; // imported visitors have no photo
    const file = path.join(paths.uploadsDir, card.image_path);
    if (!fs.existsSync(file)) continue;
    const before = fs.statSync(file).size;
    const next = await compressScan(card.image_path);
    if (next !== card.image_path || (fs.existsSync(path.join(paths.uploadsDir, next)) && fs.statSync(path.join(paths.uploadsDir, next)).size < before)) {
      const after = fs.statSync(path.join(paths.uploadsDir, next)).size;
      if (next !== card.image_path) cardModel.setImagePath(card.id, next);
      shrunk += 1;
      savedBytes += Math.max(0, before - after);
    }
  }
  return { shrunk, savedBytes };
}
