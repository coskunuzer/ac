import { Router } from 'express';
import { requireAdmin, requireAuth, type AuthedRequest } from '../middleware/auth';
import { exhibitionModel } from '../models/exhibitionModel';
import { junkOwner, listJunk, purgeJunk, restoreJunk } from '../services/junk';

const router = Router();
router.use(requireAuth);

// A sales person's own junk: what they sent there. They can bring it back; they cannot delete it for good.
router.get('/mine', (req: AuthedRequest, res) => {
  res.json(listJunk(typeof req.query.q === 'string' ? req.query.q.trim() : '', 500, req.user!.id));
});

// The junk folder (admin): customers taken out of the lists.
router.get('/', requireAdmin, (req, res) => {
  res.json(listJunk(typeof req.query.q === 'string' ? req.query.q.trim() : ''));
});

router.post('/:id/restore', (req: AuthedRequest, res, next) => {
  const jid = parseInt(String(req.params.id), 10);
  if (req.user!.role !== 'admin' && junkOwner(jid) !== req.user!.id) return res.status(403).json({ error: 'You can bring back only what you sent to junk yourself.' });
  next();
}, (req: AuthedRequest, res) => {
  const list = exhibitionModel.listAll().find((e) => e.name === 'Domestic customers') ?? exhibitionModel.create({ name: 'Domestic customers', location: 'Customers in Turkey', createdBy: req.user!.id });
  const id = restoreJunk(parseInt(String(req.params.id), 10), req.user!.id, list.id);
  if (!id) return res.status(404).json({ error: 'Not found' });
  res.json({ cardId: id });
});

router.delete('/:id', requireAdmin, (req, res) => {
  res.json({ deleted: purgeJunk([parseInt(String(req.params.id), 10)]) });
});

router.post('/purge', requireAdmin, (req, res) => {
  if (req.body?.confirm !== 'DELETE') return res.status(400).json({ error: 'Type DELETE to confirm.' });
  res.json({ deleted: purgeJunk('all') });
});

export default router;
