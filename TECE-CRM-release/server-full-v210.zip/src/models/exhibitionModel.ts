import { db } from '../db/connection';

export interface Exhibition {
  id: number;
  name: string;
  location: string | null;
  start_date: string | null;
  end_date: string | null;
  is_archived: number;
  is_default: number;
  created_by: number | null;
  created_at: string;
  // Per-event override of the thank-you email default, editable under
  // Manage Fairs - falls back to the hardcoded generic default when unset.
  // A staff member's own personal template (on their user account) still
  // takes priority over this when both are set.
  email_template_subject: string | null;
  email_template_body: string | null;
  // feedback about the fair and a photo of it - printed at the top of every PDF report
  feedback: string | null;
  photo_path: string | null;
  // does TECE take part with a stand, or does the team only visit the fair
  presence: 'participating' | 'visiting';
  // who goes (users); filled in by withAttendees()
  attendees?: { id: number; name: string }[];
  // Only populated by listAll() (a LEFT JOIN aggregate) - undefined from
  // every other query here. Used to gate edit/delete: an exhibition that
  // already has scanned cards against it can't be renamed or deleted, only
  // archived, so historical records never point at data that's changed
  // out from under them.
  card_count?: number;
}

const isoDay = (d: Date) => d.toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });
const addDays = (n: number) => isoDay(new Date(Date.now() + n * 86400000));

// A fair shows in the lists of the team from the day before it starts until 6 months after it ended. The lists of customers (no dates) always show.
// The admin sees every fair.
export function visibleFor(list: Exhibition[], isAdmin: boolean): Exhibition[] {
  if (isAdmin) return list;
  const tomorrow = addDays(1);
  const oldest = addDays(-183);
  return list.filter((e) => {
    if (e.start_date && e.start_date > tomorrow) return false;
    const last = e.end_date || e.start_date;
    return !(last && last < oldest);
  });
}

export const exhibitionModel = {
  create(input: { name: string; location?: string; startDate?: string; endDate?: string; createdBy: number; presence?: string; attendeeIds?: number[] }): Exhibition {
    const result = db
      .prepare('INSERT INTO exhibitions (name, location, start_date, end_date, created_by, presence) VALUES (?, ?, ?, ?, ?, ?)')
      .run(input.name, input.location || null, input.startDate || null, input.endDate || null, input.createdBy, input.presence === 'participating' ? 'participating' : 'visiting');
    const id = result.lastInsertRowid as number;
    if (input.attendeeIds) this.setAttendees(id, input.attendeeIds);
    return this.findById(id)!;
  },

  attendeesOf(id: number): { id: number; name: string }[] {
    return db
      .prepare('SELECT u.id AS id, COALESCE(NULLIF(u.display_name, \'\'), u.username) AS name FROM exhibition_attendees a JOIN users u ON u.id = a.user_id WHERE a.exhibition_id = ? ORDER BY name')
      .all(id) as { id: number; name: string }[];
  },

  setAttendees(id: number, userIds: number[]): void {
    db.prepare('DELETE FROM exhibition_attendees WHERE exhibition_id = ?').run(id);
    const add = db.prepare('INSERT OR IGNORE INTO exhibition_attendees (exhibition_id, user_id) SELECT ?, id FROM users WHERE id = ?');
    for (const uid of new Set(userIds.filter((n) => Number.isInteger(n)))) add.run(id, uid);
  },

  withAttendees<T extends Exhibition>(list: T[]): T[] {
    return list.map((e) => ({ ...e, attendees: this.attendeesOf(e.id) }));
  },

  // fairs that have not ended yet, soonest first (for the Home page)
  upcoming(): Exhibition[] {
    const today = isoDay(new Date());
    return db
      .prepare('SELECT * FROM exhibitions WHERE is_archived = 0 AND start_date IS NOT NULL AND COALESCE(end_date, start_date) >= ? ORDER BY start_date')
      .all(today) as unknown as Exhibition[];
  },

  findById(id: number): Exhibition | undefined {
    return db.prepare('SELECT * FROM exhibitions WHERE id = ?').get(id) as Exhibition | undefined;
  },

  listActive(): Exhibition[] {
    return db
      .prepare('SELECT * FROM exhibitions WHERE is_archived = 0 ORDER BY created_at DESC')
      .all() as unknown as Exhibition[];
  },

  listAll(): Exhibition[] {
    return db
      .prepare(
        `SELECT e.*, COUNT(c.id) as card_count
         FROM exhibitions e LEFT JOIN cards c ON c.exhibition_id = e.id
         GROUP BY e.id ORDER BY e.created_at DESC`
      )
      .all() as unknown as Exhibition[];
  },

  findDefault(): Exhibition | undefined {
    return db
      .prepare('SELECT * FROM exhibitions WHERE is_default = 1 AND is_archived = 0 LIMIT 1')
      .get() as Exhibition | undefined;
  },

  setPhoto(id: number, photoPath: string | null): void {
    db.prepare('UPDATE exhibitions SET photo_path = ? WHERE id = ?').run(photoPath, id);
  },

  setDefault(id: number): Exhibition | undefined {
    db.prepare('UPDATE exhibitions SET is_default = 0 WHERE is_default = 1').run();
    db.prepare('UPDATE exhibitions SET is_default = 1 WHERE id = ?').run(id);
    return this.findById(id);
  },

  delete(id: number): void {
    db.prepare('DELETE FROM exhibitions WHERE id = ?').run(id);
  },

  update(
    id: number,
    input: {
      name?: string;
      location?: string;
      startDate?: string;
      endDate?: string;
      isArchived?: boolean;
      emailTemplateSubject?: string | null;
      emailTemplateBody?: string | null;
      feedback?: string | null;
      presence?: string;
      attendeeIds?: number[];
    }
  ): Exhibition | undefined {
    const existing = this.findById(id);
    if (!existing) return undefined;
    if (input.presence === 'participating' || input.presence === 'visiting') db.prepare('UPDATE exhibitions SET presence = ? WHERE id = ?').run(input.presence, id);
    if (input.attendeeIds) this.setAttendees(id, input.attendeeIds);
    db.prepare(
      `UPDATE exhibitions SET name = ?, location = ?, start_date = ?, end_date = ?, is_archived = ?,
        email_template_subject = ?, email_template_body = ?, feedback = ? WHERE id = ?`
    ).run(
      input.name ?? existing.name,
      input.location ?? existing.location,
      input.startDate ?? existing.start_date,
      input.endDate ?? existing.end_date,
      input.isArchived === undefined ? existing.is_archived : input.isArchived ? 1 : 0,
      // Unlike the fields above, these two are explicitly clearable - a
      // request that omits the key (undefined) keeps the existing value,
      // but an explicit null clears it back to "use the default".
      input.emailTemplateSubject !== undefined ? input.emailTemplateSubject : existing.email_template_subject,
      input.emailTemplateBody !== undefined ? input.emailTemplateBody : existing.email_template_body,
      input.feedback === undefined ? existing.feedback : (input.feedback ?? '').replace(/\r\n/g, '\n').trim().slice(0, 4000) || null,
      id
    );
    return this.findById(id);
  },
};
