import path from 'path';
import archiver from 'archiver';
import { Router } from 'express';
import { compressExistingScans } from '../services/scanImage';
import { backupCount, streamBackup } from '../services/backup';
import { customerFilesRoot, folderIndex, folderTargets, safeName, syncAllCustomerFolders } from '../services/customerFiles';
import { cardModel } from '../models/cardModel';
import { exhibitionModel } from '../models/exhibitionModel';
import { buildCardsWorkbook } from '../services/excelExport';
import { streamCardsZipWithPhotos } from '../services/exportWithPhotos';
import { requireAuth, requireAdminOr } from '../middleware/auth';
import { renderExhibitionReport } from '../services/exhibitionReport';
import { offerLogModel } from '../models/pricingModels';
import { refreshBatch } from '../services/refreshData';
import ExcelJS from 'exceljs';
import { db } from '../db/connection';
import { bulgariaWanted, parseInsight } from '../services/aiInsight';
import { interestLabel, widthsLabel } from '../services/interest';

// Header values must be plain ASCII - a fair called "Interzum Şişli" would otherwise crash the download.
const fileSafe = (s: string) => s.normalize('NFD').replace(/\p{Diacritic}/gu, '').replace(/ı/g, 'i').replace(/[^A-Za-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'exhibition';

const router = Router();

router.use(requireAuth, requireAdminOr('exp'));

// The whole customer list as one Excel file (every customer, and the people under each company on a second sheet).
router.get('/customers', async (_req, res) => {
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', `attachment; filename="TECE-customers-${new Date().toISOString().slice(0, 10)}.xlsx"`);
  const wb = new ExcelJS.stream.xlsx.WorkbookWriter({ stream: res, useStyles: false, useSharedStrings: false });
  const ws = wb.addWorksheet('Customers');
  ws.columns = [
    ['ID', 8], ['Company', 40], ['Contact', 26], ['Position', 22], ['E-mail', 34], ['SAP number', 12], ['Mobile (WhatsApp)', 20], ['Telephone', 20], ['Fax', 16], ['Web site', 32], ['Address', 34], ['Country', 18], ['City', 16], ['Team', 10],
    ['Kind', 11], ['Step', 14], ['Group of the database', 16], ['Responsible', 20], ['AI rating', 9], ['Own rating', 9], ['Tier', 14], ['Score', 8], ['Business type', 24],
    ['Where we met', 14], ['Offer language', 10], ['Fair or list', 24], ['Offers sent', 9], ['Last contact', 18], ['Added', 18],
  ].map(([header, width]) => ({ header: header as string, width: width as number }));
  const rows = db
    .prepare(
      `SELECT c.*, e.name AS fair, (SELECT COUNT(*) FROM offers_sent o WHERE o.card_id = c.id AND o.kind = 'offer') AS offers,
              (SELECT MAX(a.created_at) FROM activities a WHERE a.card_id = c.id AND a.type IN ('note', 'call', 'visit', 'meeting', 'sample')) AS last_contact
       FROM cards c LEFT JOIN exhibitions e ON e.id = c.exhibition_id ORDER BY c.id`
    )
    .iterate() as Iterable<Record<string, unknown>>;
  for (const c of rows) {
    let lead: { tier?: string; score?: number; businessType?: string } = {};
    try {
      lead = c.lead_info ? JSON.parse(String(c.lead_info)) : {};
    } catch {
      lead = {};
    }
    const stage = (c.stage as string | null) ?? null;
    ws.addRow([
      c.id, c.company, c.name, c.position, c.email, c.sap, c.mobile, c.tel, c.fax, c.website, c.address, c.country, c.city, c.market === 'domestic' ? 'Domestic' : 'Export',
      stage === 'customer' ? 'Existing' : stage === 'lost' ? 'Lost' : 'Potential', stage ?? 'met at a fair', c.contact_group ?? '', c.person, c.ai_rate, c.rate,
      lead.tier ?? '', lead.score ?? '', lead.businessType ?? '', c.source ?? '', c.language ?? '', c.fair, c.offers, c.last_contact, c.created_at,
    ]).commit();
  }
  ws.commit();
  const people = wb.addWorksheet('People');
  people.columns = [['Company', 40], ['Name', 26], ['Position', 24], ['E-mail', 34], ['Phone', 20]].map(([header, width]) => ({ header: header as string, width: width as number }));
  for (const p of db.prepare('SELECT c.company, p.name, p.position, p.email, p.tel FROM card_contacts p JOIN cards c ON c.id = p.card_id ORDER BY c.company').iterate() as Iterable<Record<string, unknown>>) {
    people.addRow([p.company, p.name, p.position, p.email, p.tel]).commit();
  }
  people.commit();
  await wb.commit();
});

router.get('/', async (req, res) => {
  const exhibitionId = req.query.exhibitionId ? parseInt(req.query.exhibitionId as string, 10) : undefined;
  const cards = exhibitionId ? cardModel.listByExhibition(exhibitionId) : cardModel.listAll();

  const exhibitions = exhibitionModel.listAll();
  const exhibitionsById = new Map(exhibitions.map((e) => [e.id, e]));

  const buffer = await buildCardsWorkbook(cards, exhibitionsById);
  const filenameSuffix = exhibitionId ? `-${fileSafe(exhibitionsById.get(exhibitionId)?.name ?? String(exhibitionId))}` : '-all';

  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', `attachment; filename="exhibition-cards${filenameSuffix}.xlsx"`);
  res.send(Buffer.from(buffer));
});

// PDF report of one exhibition: how many people came and who they are, by
// country, with what has been done with each (offer, thank-you only, nothing).
router.get('/exhibition-report', async (req, res) => {
  const exhibitionId = parseInt(String(req.query.exhibitionId ?? ''), 10);
  const exhibition = Number.isInteger(exhibitionId) ? exhibitionModel.findById(exhibitionId) : undefined;
  if (!exhibition) return res.status(404).json({ error: 'Choose an exhibition first.' });

  const cards = cardModel.listByExhibition(exhibition.id);
  const ids = new Set(cards.map((c) => c.id));
  const pdf = await renderExhibitionReport({
    exhibition,
    cards,
    offers: offerLogModel.listForIdSet(ids),
    generatedAt: new Date(),
  });
  const slug = exhibition.name.normalize('NFD').replace(/\p{Diacritic}/gu, '').replace(/[^A-Za-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'exhibition';
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="visitors-${slug}.pdf"`);
  res.send(pdf);
});

// The sales people that have a folder (for the choice on the Export page).
router.get('/customer-folders/people', (_req, res) => {
  res.json(folderIndex());
});

// Customer folders (scan, details, offers sent) as a ZIP laid out exactly like the
// folders on the server: <sales person>/<exhibition>/<customer>. For one sales
// person (to hand over), one exhibition, both, or everything.
router.get('/customer-folders', async (req, res) => {
  const exhibitionId = req.query.exhibitionId ? parseInt(String(req.query.exhibitionId), 10) : undefined;
  const person = typeof req.query.person === 'string' && req.query.person !== '' ? req.query.person : undefined;
  const folders = folderTargets({ exhibitionId, person });
  if (folders.length === 0) {
    return res.status(404).json({ error: 'There are no customer folders yet for this selection.' });
  }
  const label = [person ? safeName(person) : 'everyone', exhibitionId ? safeName(exhibitionModel.findById(exhibitionId)?.name ?? String(exhibitionId)) : 'all-exhibitions'];
  const name = label.map((l) => fileSafe(l)).join('-');
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', `attachment; filename="customer-folders-${name}.zip"`);
  const archive = archiver('zip', { zlib: { level: 6 } });
  archive.on('error', (err) => {
    console.error('Customer folders zip failed:', err);
    res.end();
  });
  archive.pipe(res);
  for (const folder of folders) archive.directory(path.join(customerFilesRoot, folder), folder);
  await archive.finalize();
});

// Creates the folders for customers scanned before this existed (and shrinks
// their scans). Safe to run again.
router.post('/customer-folders/rebuild', async (_req, res) => {
  const scans = await compressExistingScans();
  const folders = syncAllCustomerFolders();
  res.json({ folders, scansShrunk: scans.shrunk, savedMB: Math.round((scans.savedBytes / 1048576) * 10) / 10 });
});

// One click on the Export page: brings every existing record up to date with the latest features.
// The page calls this again and again (offset) until `next` is null, so no request takes long.
router.post('/refresh-data', async (req, res) => {
  const offset = Math.max(0, parseInt(String(req.body?.offset ?? 0), 10) || 0);
  res.json(await refreshBatch(offset));
});

// The contacts to pass to the Bulgaria office (TECE Dekor Ltd): ticked on the record, or suggested by the AI.
router.get('/bulgaria', async (req, res) => {
  const exhibitionId = req.query.exhibitionId ? parseInt(String(req.query.exhibitionId), 10) : undefined;
  const fairs = new Map(exhibitionModel.listAll().map((e) => [e.id, e]));
  const cards = (exhibitionId ? cardModel.listByExhibition(exhibitionId) : cardModel.listAll()).filter(bulgariaWanted);
  const wb = new ExcelJS.Workbook();
  const sheet = wb.addWorksheet('For the Bulgaria office');
  sheet.columns = [
    { header: 'Decision', key: 'decision', width: 16 },
    { header: 'Fair', key: 'fair', width: 22 },
    { header: 'Company', key: 'company', width: 28 },
    { header: 'Name', key: 'name', width: 22 },
    { header: 'Position', key: 'position', width: 22 },
    { header: 'Country', key: 'country', width: 16 },
    { header: 'Email', key: 'email', width: 28 },
    { header: 'Tel', key: 'tel', width: 18 },
    { header: 'Interested in', key: 'interest', width: 24 },
    { header: 'Why Bulgaria', key: 'why', width: 46 },
    { header: 'Notes from the stand', key: 'notes', width: 46 },
    { header: 'About the company (AI)', key: 'about', width: 60 },
    { header: 'Sales responsible', key: 'person', width: 20 },
  ];
  sheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
  sheet.getRow(1).eachCell((c) => (c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1F3864' } }));
  sheet.views = [{ state: 'frozen', ySplit: 1 }];
  for (const c of cards) {
    const i = parseInsight(c.ai_insight);
    sheet.addRow({
      decision: c.bulgaria === 1 ? 'Passed on' : 'Suggested by AI',
      fair: fairs.get(c.exhibition_id)?.name ?? '',
      company: c.company, name: c.name, position: c.position, country: c.country, email: c.email, tel: c.tel,
      interest: [interestLabel(c), widthsLabel(c)].filter(Boolean).join(' '),
      why: i?.bulgariaReason ?? '',
      notes: c.notes,
      about: i ? [i.companyType, i.companyProfile, i.websiteSummary ? `Web site: ${i.websiteSummary}` : ''].filter(Boolean).join(' - ') : '',
      person: c.person,
    });
  }
  const buffer = await wb.xlsx.writeBuffer();
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', 'attachment; filename="contacts-for-bulgaria.xlsx"');
  res.send(Buffer.from(buffer));
});

router.get('/with-photos', async (req, res) => {
  const exhibitionId = req.query.exhibitionId ? parseInt(req.query.exhibitionId as string, 10) : undefined;
  const cards = exhibitionId ? cardModel.listByExhibition(exhibitionId) : cardModel.listAll();

  const exhibitions = exhibitionModel.listAll();
  const exhibitionsById = new Map(exhibitions.map((e) => [e.id, e]));
  const filenameSuffix = exhibitionId ? `-${fileSafe(exhibitionsById.get(exhibitionId)?.name ?? String(exhibitionId))}` : '-all';

  await streamCardsZipWithPhotos(res, cards, exhibitionsById, filenameSuffix);
});

// The full backup (admin): the customer list as Excel, a folder for every customer under each sales person (not for the plain leads), the price lists.
router.get('/backup.zip', async (_req, res) => {
  try {
    await streamBackup(res);
  } catch (err) {
    console.error('Backup failed:', err);
    if (!res.headersSent) res.status(500).json({ error: 'The backup could not be made.' });
  }
});
router.get('/backup/summary', (_req, res) => {
  res.json(backupCount());
});

export default router;
