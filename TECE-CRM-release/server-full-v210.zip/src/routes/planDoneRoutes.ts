import { Router } from 'express';
import { db } from '../db/connection';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { activityModel } from '../models/activityModel';
import { cardModel } from '../models/cardModel';
import { canSeeCard } from '../services/visibility';

// "Done" with one click on a follow-up line. The line is hidden for 14 days (it comes back if it is still true after that, or at once with Undo). Every click stays in the table.
const router = Router();
router.use(requireAuth);

router.get('/', (req: AuthedRequest, res) => {
  res.json({ rows: db.prepare("SELECT id, card_id AS cardId, kind, label FROM plan_done WHERE user_id = ? AND undone_at IS NULL AND created_at >= datetime('now', '-14 days')").all(req.user!.id) });
});

router.post('/', (req: AuthedRequest, res) => {
  const cardId = parseInt(String(req.body?.cardId), 10);
  const kind = String(req.body?.kind ?? '').slice(0, 40);
  const label = String(req.body?.label ?? '').slice(0, 300);
  const card = cardModel.findById(cardId);
  if (!card || !kind || !label) return res.status(400).json({ error: 'Nothing to mark.' });
  if (!canSeeCard(req.user!, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  const id = Number(db.prepare('INSERT INTO plan_done (user_id, card_id, kind, label) VALUES (?, ?, ?, ?)').run(req.user!.id, card.id, kind, label).lastInsertRowid);
  activityModel.add({ userId: req.user!.id, cardId: card.id, type: 'note', text: `Done: ${label}`, imported: true });
  res.status(201).json({ id });
});

router.post('/:id/undo', (req: AuthedRequest, res) => {
  db.prepare("UPDATE plan_done SET undone_at = datetime('now') WHERE id = ? AND user_id = ?").run(parseInt(String(req.params.id), 10), req.user!.id);
  res.json({ ok: true });
});

export default router;
