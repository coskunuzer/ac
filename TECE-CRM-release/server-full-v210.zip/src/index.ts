import { fixCapitalNames } from './services/niceNameFix';
import fs from 'fs';
import path from 'path';
import express from 'express';
import { env } from './config/env';
import { runMigrations } from './db/migrate';
import { createApp } from './app';
import { startBriefScheduler } from './services/dailyBrief';
import { backfillSampleNotes, startTrackingScheduler } from './services/tracking';
import { startShipScheduler } from './services/shipMailbox';
import { startNewsletterScheduler } from './services/newsletter';
import { startDigestScheduler } from './services/team';
import { cardModel } from './models/cardModel';
import { rateMissingWithRules } from './services/aiRating';
import { backfillLanguages } from './services/offerLanguage';
import { backfillOwnerOverrides } from './services/ownership';
import { canonicalizeCountries } from './services/countrySpelling';
import { rescaleRuleRatings } from './services/aiRating';
import { installAiGate } from './services/aiGate';
import { activePriceBook } from './services/priceBook/store';
runMigrations();
// every question to the AI is counted in tokens, and can be stopped (Admin > AI usage)
installAiGate();
// records written before the company key existed, and customers nobody has rated yet
try {
  const n = cardModel.backfillCompanyKeys();
  if (n) console.log(`Company keys filled for ${n} records`);
  const l = backfillLanguages();
  if (l) console.log(`Offer language set from the country for ${l} customers`);
  const cc = canonicalizeCountries();
  if (cc) console.log(`Country spelling made the same for ${cc} customers`);
  const rr = rescaleRuleRatings();
  if (rr) console.log(`Quick rating (rules) lowered for ${rr} customers`);
  const o = backfillOwnerOverrides();
  if (o) console.log(`${o} customers that belong to one particular person were marked`);
  const r = rateMissingWithRules();
  if (r) console.log(`Quick rating (rules) for ${r} customers`);
} catch (err) {
  console.error('Start-up data fix failed:', err);
}

// the price lists are read once now, so the first offer or proforma of the day does not wait for it
try {
  activePriceBook('export');
  activePriceBook('domestic');
} catch (err) {
  console.error('Reading the price list at start-up failed:', err);
}

const app = createApp();

// In production, the built frontend is served directly by this same process
// (see deploy/DEPLOY.md) so there's only one process to run under PM2.
if (env.isProduction) {
  const webDist = path.resolve(__dirname, '../../web/dist');
  // the build leaves a compressed twin next to each script and style (name.js.gz): it is sent as it is to browsers that accept it
  const TYPES: Record<string, string> = { '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.json': 'application/json; charset=utf-8' };
  app.use((req, res, next) => {
    if (req.method !== 'GET' || !/gzip/.test(String(req.headers['accept-encoding'] ?? ''))) return next();
    const type = TYPES[path.extname(req.path).toLowerCase()];
    if (!type || req.path.includes('..')) return next();
    const gz = path.join(webDist, decodeURIComponent(req.path)) + '.gz';
    if (!gz.startsWith(webDist) || !fs.existsSync(gz)) return next();
    res.setHeader('Content-Type', type);
    res.setHeader('Content-Encoding', 'gzip');
    res.setHeader('Vary', 'Accept-Encoding');
    res.setHeader('Cache-Control', gz.includes(path.sep + 'assets' + path.sep) ? 'public, max-age=31536000, immutable' : 'no-cache');
    res.sendFile(gz);
  });
  // the built files have a hash in their name: the browser keeps them for a year; the page itself is always asked again
  app.use(express.static(webDist, { setHeaders: (res, file) => { if (/[\/]assets[\/]/.test(file)) res.setHeader('Cache-Control', 'public, max-age=31536000, immutable'); else if (/.html$/.test(file)) res.setHeader('Cache-Control', 'no-cache'); } }));
  // Express 5 (path-to-regexp v8) requires a named wildcard, not a bare '*'.
  app.get('/*splat', (req, res, next) => {
    if (req.path.startsWith('/api/')) return next();
    res.sendFile(path.join(webDist, 'index.html'));
  });
}

fixCapitalNames();
try { const n = backfillSampleNotes(); if (n) console.log(`${n} sample notes became sample records`); } catch (e) { console.error('Sample backfill failed:', e); }
startDigestScheduler();
  startBriefScheduler();
  startTrackingScheduler();
  startShipScheduler();
startNewsletterScheduler();

app.listen(env.port, () => {
  console.log(`Server listening on http://localhost:${env.port} (${env.nodeEnv})`);
});

// Kept awake. Under Passenger (cPanel) an app that nobody asked anything for about five minutes is stopped, and the next click waits for a whole
// start-up (the price lists are read again ...): in the usage log a quarter of all slow answers came right after such a silence. A small request to
// our own public address every four minutes keeps the one process running. Switch it off with KEEP_WARM=0 in .env.
if (env.isProduction && process.env.KEEP_WARM !== '0' && !/\/\/(localhost|127\.0\.0\.1|\[::1\])/.test(env.publicUrl)) {
  setInterval(() => { fetch(`${env.publicUrl}/api/health`, { signal: AbortSignal.timeout(10_000) }).catch(() => undefined); }, 4 * 60_000).unref();
}
