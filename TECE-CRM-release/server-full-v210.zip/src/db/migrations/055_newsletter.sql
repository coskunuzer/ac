-- The customer newsletter (Admin > Newsletter): a campaign, the customers it goes to (a snapshot made when it starts), and who asked not to get it.
CREATE TABLE IF NOT EXISTS newsletters (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  subject TEXT NOT NULL DEFAULT '',
  content_json TEXT NOT NULL DEFAULT '{}',        -- what was written (English)
  content_tr_json TEXT,                            -- the Turkish version, when written by hand
  translations_json TEXT,                          -- the other languages, made by the AI when the campaign starts
  status TEXT NOT NULL DEFAULT 'draft',            -- draft | sending | paused | done | cancelled
  batch_size INTEGER NOT NULL DEFAULT 100,
  interval_min INTEGER NOT NULL DEFAULT 15,
  last_batch_at TEXT,
  note TEXT,                                       -- why it was paused
  created_by INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  started_at TEXT,
  finished_at TEXT
);
CREATE TABLE IF NOT EXISTS newsletter_recipients (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  newsletter_id INTEGER NOT NULL REFERENCES newsletters(id) ON DELETE CASCADE,
  card_id INTEGER,
  sap TEXT,
  company TEXT,
  country TEXT,
  email TEXT NOT NULL,
  lang TEXT NOT NULL DEFAULT 'en',
  status TEXT NOT NULL DEFAULT 'queued',           -- queued | sent | failed
  error TEXT,
  sent_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_nl_rec ON newsletter_recipients(newsletter_id, status);
CREATE TABLE IF NOT EXISTS newsletter_optout (
  email TEXT PRIMARY KEY,
  card_id INTEGER,
  at TEXT NOT NULL DEFAULT (datetime('now')),
  via TEXT                                          -- link | admin
);
-- the person in charge can always put a customer in or out of the list, whatever the rules say
CREATE TABLE IF NOT EXISTS newsletter_overrides (
  card_id INTEGER PRIMARY KEY,
  mode TEXT NOT NULL,                               -- include | exclude
  note TEXT,
  at TEXT NOT NULL DEFAULT (datetime('now'))
);
