import { settingsModel } from '../models/settingsModel';
import { DEFAULT_ENABLED_TABS, LEGACY_TABS, PRODUCT_TABS, type CatalogSection } from './priceBook';

// Which product tabs of the price list are on offer. An admin switches them on and off (Price list page);
// until then the original products are on and the newer ones (hybrid, digital, Zero-Line, hot melt) are off.
export function enabledTabs(): string[] {
  const raw = settingsModel.get('offer_tabs');
  if (raw) {
    try {
      const list = JSON.parse(raw);
      // what was switched on under an old page name ("PP M2") stays on under the new one ("PP M2+22")
      if (Array.isArray(list)) { const on = new Set<string>(list); for (const [old, now] of Object.entries(LEGACY_TABS)) if (on.has(old)) on.add(now); return PRODUCT_TABS.filter((t) => on.has(t)); }
    } catch {
      // fall through to the default
    }
  }
  return DEFAULT_ENABLED_TABS;
}

export function setEnabledTabs(tabs: string[]): string[] {
  const clean = PRODUCT_TABS.filter((t) => tabs.includes(t));
  settingsModel.set('offer_tabs', JSON.stringify(clean));
  return clean;
}

// The part of a price list's catalog the staff can build offers from.
export function offerCatalog(catalog: CatalogSection[]): CatalogSection[] {
  const on = new Set(enabledTabs());
  return catalog.filter((s) => on.has(s.sheet));
}
