-- A person's own e-mail styles: as many as they like (another thank-you, a feedback request, a reminder ...). Placeholders as in the admin texts.
CREATE TABLE IF NOT EXISTS user_texts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'general',   -- thank_you | offer | feedback | general ...: only a label, every text can be used in every e-mail
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_user_texts_user ON user_texts(user_id);
