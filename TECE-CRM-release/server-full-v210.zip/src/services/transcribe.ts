import { env } from '../config/env';

// A voice note is written down in the browser (the phone's or the computer's own speech recognition), in the language the person chose.
// DeepSeek cannot listen to sound, so it is only asked for the Turkish version of the words (the team reads Turkish).
const GEMINI_URL = process.env.GEMINI_BASE_URL || 'https://generativelanguage.googleapis.com/v1beta/models'; // (the gate sends it to DeepSeek)
const MODEL = 'gemini-3.6-flash';

export async function toTurkish(text: string, language: string): Promise<string | null> {
  if (!env.geminiApiKey) return null;
  const prompt = `Translate this note of a TECE salesperson (language code: ${language || 'unknown'}) into Turkish. TECE makes edgebanding (PVC, ABS, PP, melamine). Keep numbers, codes, names and units. Answer with the Turkish text only.\n\n${text.slice(0, 4000)}`;
  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      const res = await fetch(`${GEMINI_URL}/${MODEL}:generateContent`, {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-goog-api-key': env.geminiApiKey },
        body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { temperature: 0 } }),
        signal: AbortSignal.timeout(60000),
      });
      if (!res.ok) { if (res.status === 429 || res.status >= 500) { await new Promise((r) => setTimeout(r, 2000)); continue; } return null; }
      const data = (await res.json()) as { candidates?: { content?: { parts?: { text?: string }[] } }[] };
      return (data.candidates?.[0]?.content?.parts ?? []).map((p) => p.text ?? '').join('').trim() || null;
    } catch { await new Promise((r) => setTimeout(r, 1500)); }
  }
  return null;
}
