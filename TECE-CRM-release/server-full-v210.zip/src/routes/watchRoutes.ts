import { Router } from 'express';
import { db } from '../db/connection';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { filterVisible } from '../services/visibility';

// Radar and To-do (the boxes on the right edge): what a person drags there to follow later. Only the person sees their own items.
const router = Router();
router.use(requireAuth);
const LISTS = ['radar', 'todo'];

router.get('/', (req: AuthedRequest, res) => {
  const rows = db.prepare('SELECT id, list, card_id, label, note, created_at FROM watch_items WHERE user_id = ? ORDER BY id DESC').all(req.user!.id) as unknown as { id: number; list: string; card_id: number | null; label: string; note: string; created_at: string }[];
  const ids = [...new Set(rows.map((r) => r.card_id).filter((x): x is number => !!x))];
  const cards = ids.length ? (db.prepare(`SELECT id, company, name, country, stage, market, person, uploaded_by, sap FROM cards WHERE id IN (${ids.map(() => '?').join(',')})`).all(...ids) as unknown as { id: number; company: string | null; name: string | null; country: string | null }[]) : [];
  const ok = new Set(filterVisible(req.user as never, cards as never[]).map((c: { id: number }) => c.id));
  const byId = new Map(cards.map((c) => [c.id, c]));
  res.json(rows.map((r) => {
    const c = r.card_id ? byId.get(r.card_id) : null;
    const seen = !r.card_id || ok.has(r.card_id);
    return { id: r.id, list: r.list, cardId: seen ? r.card_id : null, label: c && seen ? (c.company || c.name || r.label) : r.label, country: c && seen ? c.country : null, note: r.note, at: r.created_at };
  }));
});

router.post('/', (req: AuthedRequest, res) => {
  const list = String(req.body?.list ?? '');
  if (!LISTS.includes(list)) return res.status(400).json({ error: 'Radar or To-do?' });
  const cardId = parseInt(String(req.body?.cardId ?? ''), 10) || null;
  let label = String(req.body?.label ?? '').replace(/\s+/g, ' ').trim().slice(0, 200);
  if (cardId) {
    const c = db.prepare('SELECT id, company, name, country, stage, market, person, uploaded_by, sap FROM cards WHERE id = ?').get(cardId) as unknown as { id: number; company: string | null; name: string | null } | undefined;
    if (!c || !filterVisible(req.user as never, [c as never]).length) return res.status(404).json({ error: 'This customer is not on your list.' });
    label = c.company || c.name || label;
    if (db.prepare('SELECT 1 FROM watch_items WHERE user_id = ? AND list = ? AND card_id = ?').get(req.user!.id, list, cardId)) return res.json({ ok: true, duplicate: true });
  }
  if (!label) return res.status(400).json({ error: 'There is nothing to save.' });
  const r = db.prepare('INSERT INTO watch_items (user_id, list, card_id, label) VALUES (?, ?, ?, ?)').run(req.user!.id, list, cardId, label);
  res.status(201).json({ ok: true, id: Number(r.lastInsertRowid) });
});

router.patch('/:id', (req: AuthedRequest, res) => {
  const list = String(req.body?.list ?? '');
  if (LISTS.includes(list)) db.prepare('UPDATE watch_items SET list = ? WHERE id = ? AND user_id = ?').run(list, String(req.params.id), req.user!.id);
  if (typeof req.body?.note === 'string') db.prepare('UPDATE watch_items SET note = ? WHERE id = ? AND user_id = ?').run(req.body.note.slice(0, 500), String(req.params.id), req.user!.id);
  res.json({ ok: true });
});

router.delete('/:id', (req: AuthedRequest, res) => {
  db.prepare('DELETE FROM watch_items WHERE id = ? AND user_id = ?').run(String(req.params.id), req.user!.id);
  res.json({ ok: true });
});

export default router;
