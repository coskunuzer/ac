-- when a person last looked at a list of news (for example "new customers for you")
CREATE TABLE IF NOT EXISTS user_seen (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  key TEXT NOT NULL,
  at TEXT NOT NULL,
  PRIMARY KEY (user_id, key)
);
