import { Router, type Response, type NextFunction } from 'express';
import multer from 'multer';
import nodemailer from 'nodemailer';
import { db } from '../db/connection';
import { env } from '../config/env';
import { requireAuth, requireAdmin, type AuthedRequest } from '../middleware/auth';
import { hasIntel } from '../services/permissions';
import { INTEL_KINDS, ingestIntel, loadHistory, historyAvailable, historyGap, ensureHistory, type IntelKind } from '../services/intelIngest';
import { getBundle, status, cardLinks } from '../services/intelEngine';
import { renderReport } from '../services/intelReport';
import { setExcluded, listExcluded } from '../services/intelExclude';
import { settingsModel } from '../models/settingsModel';
import { cardModel } from '../models/cardModel';
import { exhibitionModel } from '../models/exhibitionModel';
import { countryModel } from '../models/countryModel';
import { smtpReady } from '../services/newsletter';

// Sales intelligence. Off for everybody until an admin switches it on for a person (Admin → Permissions → "Sales intelligence"); an admin always has it.
const router = Router();
router.use(requireAuth);
router.use((req: AuthedRequest, res: Response, next: NextFunction) => {
  if (!hasIntel(req.user as never)) return res.status(403).json({ error: 'Sales intelligence is not switched on for you.' });
  next();
});
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 80 * 1024 * 1024, files: 1 } });
const fail = (res: Response, err: unknown, code = 400) => res.status(code).json({ error: err instanceof Error ? err.message : String(err) });
// the analysis is rebuilt in the background after a change, so the next person to open the page does not wait for it
let warmTimer: NodeJS.Timeout | null = null; // several uploads in a row are one rebuild, a little after the last of them
const warm = () => { if (warmTimer) clearTimeout(warmTimer); warmTimer = setTimeout(() => { warmTimer = null; getBundle(true).catch((e) => console.error('Sales intelligence rebuild failed:', e)); }, 20000); };
const GM_DEFAULT = 'ecoskunuzer@tece.com.tr';

router.get('/status', (_req, res) => {
  res.json({ ...status(), historyShipped: historyAvailable(), historyNeeded: historyGap().needs, gm: settingsModel.get('intel_gm_email') || GM_DEFAULT, smtp: smtpReady() });
});

router.get('/bundle', async (req: AuthedRequest, res) => {
  try {
    const admin = req.user!.role === 'admin';
    if (admin) ensureHistory(req.user!.id); // the old years are added by themselves if they are missing (no big uploads)
    res.json({ ...(await getBundle()), admin, historyNeeded: historyGap().needs });
  } catch (e) { fail(res, e); }
});

// "This is not a customer" (a supplier that returns material...): the account is left out of every sales number. Nothing is deleted; "Put back" undoes it.
router.get('/excluded', requireAdmin, (_req, res) => res.json(listExcluded()));
router.post('/exclude', requireAdmin, async (req: AuthedRequest, res) => {
  try {
    const { code, on, reason } = req.body ?? {};
    setExcluded(String(code ?? ''), on !== false, String(reason ?? ''), req.user!.id);
    const b = await getBundle(true); // the numbers are drawn again at once, so the person sees the result
    res.json({ ok: true, excluded: listExcluded(), built: b.built });
  } catch (e) { fail(res, e); }
});

router.post('/rebuild', requireAdmin, async (_req, res) => {
  try { const b = await getBundle(true); res.json({ ok: true, built: b.built }); } catch (e) { fail(res, e); }
});

// the summary of the old years that ships with the CRM: one click, no big uploads
router.post('/load-history', requireAdmin, (req: AuthedRequest, res) => {
  // when the old years are missing, the months that were uploaded stay as they are
  try { const r = loadHistory(req.user!.id, historyGap().needs); res.json(r); warm(); } catch (e) { console.error('Sales intelligence history failed:', e); fail(res, e); }
});

router.post('/upload/:kind', requireAdmin, upload.single('file'), async (req: AuthedRequest, res) => {
  const kind = String(req.params.kind) as IntelKind;
  if (!INTEL_KINDS.includes(kind)) return fail(res, new Error('Unknown file kind'));
  if (!req.file) return fail(res, new Error('Choose a file first'));
  try {
    if (kind === 'sales') ensureHistory(req.user!.id); // old years first, so the new months go on top of them
    const r = await ingestIntel(kind, req.file.buffer, Buffer.from(req.file.originalname, 'latin1').toString('utf8'), req.user!.id);
    res.json(r); warm(); }
  catch (e) { console.error(`Sales intelligence upload (${kind}) failed:`, e); fail(res, e); }
});

// ---- connect an old SAP account to the CRM
const clearCache = () => db.prepare("DELETE FROM intel_cache WHERE key = 'bundle'").run();

// the card gets the SAP number (only a card that has none, and a number no other card has)
router.post('/link', requireAdmin, (req: AuthedRequest, res) => {
  const sap = String(req.body?.sap ?? '').replace(/\D/g, ''), id = Number(req.body?.cardId);
  if (!sap || !id) return fail(res, new Error('Choose the account and the customer card.'));
  const card = db.prepare('SELECT id, company, sap FROM cards WHERE id = ?').get(id) as { id: number; company: string; sap: string | null } | undefined;
  if (!card) return fail(res, new Error('That customer card does not exist.'), 404);
  if (card.sap && card.sap !== sap) return fail(res, new Error(`${card.company} already carries SAP number ${card.sap}.`));
  const other = db.prepare('SELECT id, company FROM cards WHERE sap = ? AND id <> ?').get(sap, id) as { id: number; company: string } | undefined;
  if (other) return fail(res, new Error(`SAP number ${sap} is already on the card of ${other.company}.`));
  db.prepare("UPDATE cards SET sap = ?, updated_at = datetime('now') WHERE id = ?").run(sap, id);
  clearCache();
  res.json({ ok: true, cardId: id, company: card.company });
});

// a new customer card from what SAP knows (name and country from the SAP customer list, else the name on the invoices); the owner of the country gets it
router.post('/create-card', requireAdmin, (req: AuthedRequest, res) => {
  const sap = String(req.body?.sap ?? '').replace(/\D/g, '');
  if (!sap) return fail(res, new Error('Choose the account.'));
  if (db.prepare('SELECT id FROM cards WHERE sap = ?').get(sap)) return fail(res, new Error('A customer card with this SAP number already exists.'));
  const m = db.prepare('SELECT name, country FROM sap_customers WHERE sap_no = ?').get(sap) as { name: string | null; country: string | null } | undefined;
  const s = db.prepare('SELECT name AS customer_name, region FROM intel_cust WHERE code = ?').get(sap) as { customer_name: string; region: string } | undefined;
  const company = (m?.name || s?.customer_name || '').trim();
  if (!company) return fail(res, new Error('SAP has no name for this account.'));
  const country = (m?.country || '').trim() || null;
  const domestic = sap.startsWith('1201');
  const listName = 'Customer database';
  const ex = exhibitionModel.listAll().find((e) => e.name.trim().toLowerCase() === listName.toLowerCase()) ?? exhibitionModel.create({ name: listName, location: 'All customers and leads', createdBy: req.user!.id });
  const owner = country ? countryModel.findByCountry(country)?.responsible ?? null : null;
  const card = cardModel.createFromExtraction({
    exhibitionId: ex.id, uploadedBy: req.user!.id, imagePath: '',
    fields: { name: null, company, address: null, country: country ?? (domestic ? 'Turkey' : null), tel: null, email: null, position: null, interestedIn: null, workArea: null, date: null, person: owner, rate: null, notes: 'Created from SAP (sales intelligence): the account sells, holds stock or has open orders.' },
    fieldStatus: {} as never, extractionModel: 'sap-account', status: 'confirmed', badgeId: `sap:${sap}`, stage: 'customer', market: domestic ? 'domestic' : 'export', source: 'database', sap,
  });
  db.prepare('UPDATE cards SET delete_locked = 1 WHERE id = ?').run(card.id);
  clearCache();
  res.json({ ok: true, cardId: card.id, company });
});

// ---- the report to the general manager (Turkish)
router.get('/report/preview', async (_req, res) => {
  try { const b = await getBundle(); res.type('html').send(renderReport(b).html); } catch (e) { fail(res, e); }
});
router.post('/report/gm', requireAdmin, (req: AuthedRequest, res) => {
  const to = String(req.body?.to ?? '').trim();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(to)) return fail(res, new Error('Write a valid e-mail address.'));
  settingsModel.set('intel_gm_email', to);
  res.json({ ok: true, to });
});
router.post('/report/send', async (req: AuthedRequest, res) => {
  const to = String(req.body?.to ?? settingsModel.get('intel_gm_email') ?? GM_DEFAULT).trim();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(to)) return fail(res, new Error('Write a valid e-mail address.'));
  if (settingsModel.get('test_mode') === '1') return fail(res, new Error('Test mode is on: switch it off to send e-mail.'));
  if (!smtpReady()) return fail(res, new Error('The mail server (SMTP) is not set up.'));
  try {
    const b = await getBundle(); const r = renderReport(b);
    const tp = nodemailer.createTransport({ host: env.smtp.host, port: env.smtp.port, secure: env.smtp.port === 465, auth: { user: env.smtp.user, pass: env.smtp.password } });
    await tp.sendMail({ from: env.smtp.from || env.smtp.user, to, subject: r.subject, text: r.text, html: r.html });
    db.prepare('INSERT INTO intel_reports (sent_to, subject, by_user, ok, note) VALUES (?, ?, ?, 1, NULL)').run(to, r.subject, req.user!.id);
    res.json({ ok: true, to, subject: r.subject });
  } catch (e) {
    db.prepare('INSERT INTO intel_reports (sent_to, subject, by_user, ok, note) VALUES (?, ?, ?, 0, ?)').run(to, 'Satış İstihbarat Raporu', req.user!.id, String((e as Error).message).slice(0, 300));
    fail(res, e);
  }
});
router.get('/report/log', (_req, res) => {
  res.json(db.prepare('SELECT r.id, r.sent_to, r.subject, r.ok, r.note, r.at, COALESCE(NULLIF(u.display_name, \'\'), u.username) by_name FROM intel_reports r LEFT JOIN users u ON u.id = r.by_user ORDER BY r.id DESC LIMIT 20').all());
});

export { cardLinks };
export default router;
