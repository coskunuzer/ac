// Which kind of e-mail suits this customer: worked out from what is on record, not from where the record came from.
// Order matters: money owed comes before a nice word, a nice word before a first hello.
import type { CardRow } from '../models/cardModel';
import { offerLogModel } from '../models/pricingModels';
import { distributorModel } from '../models/distributorModel';
import { offerWanted } from './aiInsight';
import { accountOfSapAny, linkMap } from './perfAnalytics';
import { pricePerfBase } from './pricePerf';
import { fairNameOfCard, isRealFair } from './emailSafety';
import { db } from '../db/connection';

export type MailKind = 'payment' | 'win_back' | 'chase' | 'offer' | 'dispatch' | 'thank_you' | 'distributor' | 'introduction' | 'personal';

export const MAIL_KINDS: MailKind[] = ['payment', 'win_back', 'chase', 'offer', 'dispatch', 'thank_you', 'distributor', 'introduction', 'personal'];

export interface KindOption { kind: MailKind; available: boolean; why: string }
export interface KindAdvice { kind: MailKind; reason: string; options: KindOption[]; fair: string | null }

const DAY = 86_400_000;
const daysSince = (s: string | null | undefined): number | null => {
  if (!s) return null;
  const t = new Date(`${s.replace(' ', 'T')}${s.length <= 10 ? 'T00:00:00' : ''}Z`).getTime();
  return Number.isFinite(t) ? Math.floor((Date.now() - t) / DAY) : null;
};

// the buying status of a customer in the sales list (slowing / lost / passive ...), or null
function buyingStatus(sap: string | null | undefined): string | null {
  if (!sap || !sap.trim()) return null;
  try {
    const base = pricePerfBase(); const L = linkMap();
    for (const code of sap.split(/[\s,;/|]+/).map((x) => x.trim()).filter(Boolean)) { const c = base.custs.get(L.get(code) ?? code); if (c) return c.status; }
  } catch { /* no sales list */ }
  return null;
}

export function adviseEmailKind(card: CardRow): KindAdvice {
  const fair = isRealFair(fairNameOfCard(card.id)) ? fairNameOfCard(card.id) : null;
  const account = card.sap ? accountOfSapAny(card.sap) : null;
  const entries = offerLogModel.listForCard(card.id);
  const offers = entries.filter((e) => e.kind === 'offer').sort((a, b) => (a.sentAt < b.sentAt ? 1 : -1));
  const lastOfferDays = offers[0] ? daysSince(offers[0].sentAt) : null;
  const thanked = !!(card.thank_you_sent_at || entries.some((e) => e.kind === 'thank_you'));
  const anyMail = (db.prepare('SELECT COUNT(*) AS n FROM sent_emails WHERE card_id = ?').get(card.id) as { n: number }).n > 0;
  const distributor = distributorModel.forCard(card);

  const owes = !!account && account.overdue > 0 && account.oldestOver > 0;
  const ready = !!account && account.readyValue > 0;
  const quiet = !!account && !!account.lastInvoice && (daysSince(account.lastInvoice) ?? 0) > 180;
  const chasing = lastOfferDays !== null && lastOfferDays >= 7 && !(account && account.lastInvoice && (daysSince(account.lastInvoice) ?? 9999) < lastOfferDays);
  const wantsOffer = offers.length === 0 && !!card.email && (card.send_offer === 1 || (card.send_offer == null && offerWanted(card)));
  const fresh = !anyMail && !account && !fair;

  const options: KindOption[] = [
    { kind: 'payment', available: owes, why: owes ? `${account!.oldestOver} days overdue` : 'Nothing is overdue.' },
    { kind: 'win_back', available: quiet, why: quiet ? `No invoice for ${daysSince(account!.lastInvoice)} days` : 'The customer bought recently or never.' },
    { kind: 'chase', available: lastOfferDays !== null, why: lastOfferDays !== null ? `Offer sent ${lastOfferDays} days ago` : 'No offer has been sent.' },
    { kind: 'offer', available: !!card.email, why: card.email ? (offers.length ? 'An offer went before' : 'No offer sent yet') : 'There is no e-mail address.' },
    { kind: 'dispatch', available: ready, why: ready ? 'An order is ready to dispatch' : 'Nothing is ready to dispatch.' },
    { kind: 'thank_you', available: !!fair, why: fair ? `Visited us at ${fair}` : 'The record names no real fair.' },
    { kind: 'distributor', available: !!distributor, why: distributor ? `Our distributor: ${distributor.name}` : 'No distributor in this country.' },
    { kind: 'introduction', available: true, why: 'A first hello' },
    { kind: 'personal', available: true, why: 'Your own words' },
  ];

  let kind: MailKind;
  let reason: string;
  if (owes) { kind = 'payment'; reason = `${account!.oldestOver} days overdue`; }
  else if (ready) { kind = 'dispatch'; reason = 'An order is ready to dispatch'; }
  else if (distributor && !account) { kind = 'distributor'; reason = card.country ? `We have a distributor in ${card.country}.` : 'We have a distributor in this country.'; }
  else if (chasing) { kind = 'chase'; reason = `Offer sent ${lastOfferDays} days ago, no answer`; }
  else if (wantsOffer) { kind = 'offer'; reason = 'The notes ask for an offer and none has gone'; }
  else if (quiet) { kind = 'win_back'; reason = `No invoice for ${daysSince(account!.lastInvoice)} days`; }
  else if (fair && !thanked) { kind = 'thank_you'; reason = `Visited us at ${fair}, not thanked yet`; }
  else if (fresh) { kind = 'introduction'; reason = 'No contact on record yet'; }
  else {
    // nothing else is waiting, but the customer buys less (the same status as Today's focus and My performance): say so, not "nothing is waiting"
    kind = 'personal';
    const st = buyingStatus(card.sap);
    reason = st === 'slowing' ? 'Buying less than in the 12 months before: call and ask what changed.' : st === 'lost' || st === 'passive' ? 'Stopped buying lately: call and ask what changed.' : 'Nothing is waiting: write your own words';
  }
  return { kind, reason, options, fair };
}
