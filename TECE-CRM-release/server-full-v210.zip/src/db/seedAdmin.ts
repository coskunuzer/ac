import bcrypt from 'bcryptjs';
import { runMigrations } from './migrate';
import { userModel } from '../models/userModel';

function main() {
  runMigrations();

  const username = process.argv[2];
  const password = process.argv[3];

  if (!username || !password) {
    console.error('Usage: npm run seed-admin -- <username> <password>');
    process.exit(1);
  }

  const existing = userModel.findByUsername(username);
  if (existing) {
    console.error(`User "${username}" already exists.`);
    process.exit(1);
  }

  const passwordHash = bcrypt.hashSync(password, 10);
  const user = userModel.create({ username, passwordHash, role: 'admin', displayName: 'Admin' });
  console.log(`Created admin user: ${user.username} (id ${user.id})`);
}

main();
