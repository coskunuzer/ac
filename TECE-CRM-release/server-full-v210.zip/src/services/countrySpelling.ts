import { db } from '../db/connection';
import { canonicalCountry } from '../models/countryModel';

// "USA", "United States of America" and "United States" are one country: every customer is put on the spelling of the country list (once).
export function canonicalizeCountries(): number {
  const rows = db.prepare("SELECT DISTINCT country FROM cards WHERE country IS NOT NULL AND TRIM(country) != ''").all() as { country: string }[];
  let n = 0;
  const upd = db.prepare('UPDATE cards SET country = ? WHERE country = ?');
  for (const { country } of rows) {
    const c = canonicalCountry(country) as string;
    if (c && c !== country) n += Number(upd.run(c, country).changes);
  }
  return n;
}
