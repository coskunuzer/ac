import PDFDocument from 'pdfkit';
import { drawLogo, registerDesignFonts } from './priceBook/designed';
import { COMPANY_ADDRESS_LINE } from './signature';
import { describe, type Lang } from './perfActions';
import { ledgerFor, type LedgerResult, type LedgerRow } from './ledgerMatch';

// The full account of a customer for a period, with every invoice and the payment that settled it shown together (same number, same colour);
// invoices nobody paid or paid short are in red. As a PDF, and a summary for the e-mail.
const SYMBOL: Record<string, string> = { EUR: '€', USD: '$' };
const money = (n: number, cur: string) => `${n < 0 ? '-' : ''}${SYMBOL[cur] ?? `${cur} `}${Math.abs(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const dmy = (iso: string | null) => (iso ? `${iso.slice(8, 10)}.${iso.slice(5, 7)}.${iso.slice(0, 4)}` : '');
const today = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });
const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

interface L { title: string; period: string; fromStart: string; opening: string; closing: string; date: string; description: string; invoice: string; payment: string; pair: string; note: string; paid: string; bank: string; short: string; unpaid: string; advance: string; legend: string; exceptions: string; summary: string; none: string; asOf: string; account: string }
const T: Record<string, L> = {
  en: { title: 'ACCOUNT STATEMENT', period: 'Period', fromStart: 'from the beginning', opening: 'Balance before', closing: 'Balance', date: 'Date', description: 'Description', invoice: 'Invoice', payment: 'Payment', pair: 'No.', note: 'Remark', paid: 'Paid', bank: 'Paid (bank charge', short: 'Short by', unpaid: 'Not paid', advance: 'Payment not yet matched', legend: 'An invoice and its payment have the same number and colour. Red: not paid, or paid short.', exceptions: 'Open points', summary: 'Summary', none: 'No open points.', asOf: 'As of', account: 'Account no.' },
  tr: { title: 'HESAP EKSTRESİ', period: 'Dönem', fromStart: 'başlangıçtan', opening: 'Önceki bakiye', closing: 'Bakiye', date: 'Tarih', description: 'Açıklama', invoice: 'Fatura', payment: 'Ödeme', pair: 'No', note: 'Not', paid: 'Ödendi', bank: 'Ödendi (banka masrafı', short: 'Eksik', unpaid: 'Ödenmedi', advance: 'Henüz eşleşmeyen ödeme', legend: 'Bir fatura ve ödemesi aynı numara ve renktedir. Kırmızı: ödenmemiş veya eksik ödenmiş.', exceptions: 'Açık noktalar', summary: 'Özet', none: 'Açık nokta yok.', asOf: 'Tarih', account: 'Hesap no' },
  de: { title: 'KONTOAUSZUG', period: 'Zeitraum', fromStart: 'seit Beginn', opening: 'Saldo vorher', closing: 'Saldo', date: 'Datum', description: 'Beschreibung', invoice: 'Rechnung', payment: 'Zahlung', pair: 'Nr.', note: 'Hinweis', paid: 'Bezahlt', bank: 'Bezahlt (Bankgebühr', short: 'Fehlbetrag', unpaid: 'Nicht bezahlt', advance: 'Zahlung noch nicht zugeordnet', legend: 'Eine Rechnung und ihre Zahlung haben dieselbe Nummer und Farbe. Rot: nicht bezahlt oder zu wenig bezahlt.', exceptions: 'Offene Punkte', summary: 'Zusammenfassung', none: 'Keine offenen Punkte.', asOf: 'Stand', account: 'Kontonr.' },
  es: { title: 'ESTADO DE CUENTA', period: 'Periodo', fromStart: 'desde el inicio', opening: 'Saldo anterior', closing: 'Saldo', date: 'Fecha', description: 'Descripción', invoice: 'Factura', payment: 'Pago', pair: 'N.º', note: 'Observación', paid: 'Pagada', bank: 'Pagada (gastos bancarios', short: 'Falta', unpaid: 'Sin pagar', advance: 'Pago aún sin asignar', legend: 'Una factura y su pago tienen el mismo número y color. Rojo: sin pagar o pagada de menos.', exceptions: 'Puntos abiertos', summary: 'Resumen', none: 'Sin puntos abiertos.', asOf: 'A fecha de', account: 'N.º de cuenta' },
  fr: { title: 'RELEVÉ DE COMPTE', period: 'Période', fromStart: 'depuis le début', opening: 'Solde précédent', closing: 'Solde', date: 'Date', description: 'Description', invoice: 'Facture', payment: 'Paiement', pair: 'N°', note: 'Remarque', paid: 'Payée', bank: 'Payée (frais bancaires', short: 'Manque', unpaid: 'Non payée', advance: 'Paiement non encore affecté', legend: 'Une facture et son paiement ont le même numéro et la même couleur. Rouge : non payée ou payée en moins.', exceptions: 'Points ouverts', summary: 'Résumé', none: 'Aucun point ouvert.', asOf: 'Au', account: 'N° de compte' },
  ru: { title: 'АКТ СВЕРКИ', period: 'Период', fromStart: 'с начала', opening: 'Сальдо на начало', closing: 'Сальдо', date: 'Дата', description: 'Описание', invoice: 'Счёт', payment: 'Платёж', pair: '№', note: 'Примечание', paid: 'Оплачен', bank: 'Оплачен (банковская комиссия', short: 'Недоплата', unpaid: 'Не оплачен', advance: 'Платёж пока не сопоставлен', legend: 'Счёт и его платёж имеют один номер и цвет. Красный: не оплачен или оплачен не полностью.', exceptions: 'Открытые вопросы', summary: 'Итого', none: 'Открытых вопросов нет.', asOf: 'На', account: 'Счёт №' },
};
const words = (l: Lang): L => T[l] ?? T.en;

// one colour per pair (golden-angle hues: no two neighbours look alike)
const hsl = (h: number, s: number, l: number): string => {
  const a = (s / 100) * Math.min(l / 100, 1 - l / 100);
  const f = (n: number) => { const k = (n + h / 30) % 12; const c = l / 100 - a * Math.max(-1, Math.min(k - 3, 9 - k, 1)); return Math.round(255 * c).toString(16).padStart(2, '0'); };
  return `#${f(0)}${f(8)}${f(4)}`;
};
export const pairColors = (no: number) => { const h = (no * 137.508) % 360; return { bg: hsl(h, 70, 92), strong: hsl(h, 60, 38) }; };

const noteOf = (r: LedgerRow, w: L, cur: string): string => {
  if (r.kind === 'payment') return r.status === 'advance' ? `${w.advance}: ${money(r.short, cur)}` : '';
  if (r.status === 'paid') return w.paid;
  if (r.status === 'bank') return `${w.bank} ${money(r.bankCharge, cur)})`;
  if (r.status === 'short') return `${w.short} ${money(r.short, cur)}`;
  return `${w.unpaid}: ${money(r.short, cur)}`;
};

export async function renderLedgerPdf(a: { name: string; sap: string; country: string; lang: Lang; from: string | null }): Promise<Buffer> {
  const led = ledgerFor(a.sap, a.from);
  const w = words(a.lang);
  const doc = new PDFDocument({ size: 'A4', margin: 0, autoFirstPage: false, info: { Title: `${w.title} ${a.name}`, Author: 'TECE' } });
  const chunks: Buffer[] = [];
  doc.on('data', (b: Buffer) => chunks.push(b));
  const done = new Promise<Buffer>((resolve, reject) => { doc.on('end', () => resolve(Buffer.concat(chunks))); doc.on('error', reject); });
  registerDesignFonts(doc);
  const NAVY = '#17243E', RED = '#8B1931', STEEL = '#5E6676', SMOKE = '#E3E6EC';
  const F = { r: 'TD-400', m: 'TD-500', b: 'TD-600', h: 'TD-700' };
  const PW = 595.28, PH = 841.89, L0 = 36, CW = PW - 2 * L0, BOTTOM = PH - 56;
  let y = 0;
  const cols = [{ x: L0, w: 26, k: w.pair }, { x: L0 + 26, w: 52, k: w.date }, { x: L0 + 78, w: 150, k: w.description }, { x: L0 + 228, w: 70, k: w.invoice, r: true }, { x: L0 + 298, w: 70, k: w.payment, r: true }, { x: L0 + 368, w: CW - 368, k: w.note }];
  const page = () => {
    doc.addPage();
    doc.rect(0, 0, PW, 58).fill(NAVY);
    drawLogo(doc, 'TECE_SloganliLogo_Beyaz_RGB.svg', L0, (58 - 190 * (522 / 5990)) / 2, 190);
    doc.rect(0, 58, PW, 3).fill(RED);
    doc.font(F.h).fontSize(13).fillColor('#FFFFFF').text(w.title, L0, 22, { width: CW, align: 'right', lineBreak: false });
    doc.font(F.r).fontSize(7.5).fillColor(STEEL).text(COMPANY_ADDRESS_LINE, L0, PH - 30, { width: CW, align: 'center', lineBreak: false });
    y = 78;
  };
  const head = () => {
    doc.font(F.b).fontSize(7.5).fillColor(STEEL);
    for (const c of cols) doc.text(c.k.toUpperCase(), c.x, y, { width: c.w - 4, align: c.r ? 'right' : 'left', lineBreak: false });
    doc.rect(L0, y + 12, CW, 1).fill(NAVY);
    y += 17;
  };
  page();
  doc.font(F.h).fontSize(14).fillColor(NAVY).text(a.name, L0, y, { width: CW });
  y = doc.y + 3;
  doc.font(F.r).fontSize(8.5).fillColor(STEEL).text(`${w.account}: ${a.sap}${a.country ? `   ·   ${a.country}` : ''}   ·   ${w.period}: ${a.from ? dmy(a.from) : w.fromStart} – ${dmy(today())}`, L0, y, { width: CW });
  y = doc.y + 4;
  doc.font(F.r).fontSize(8).fillColor(STEEL).text(w.legend, L0, y, { width: CW });
  y = doc.y + 10;
  if (!led || !led.rows.length) { doc.font(F.r).fontSize(10).fillColor('#222222').text(w.none, L0, y); doc.end(); return done; }
  const cur = led.currency;
  head();
  if (a.from) {
    doc.font(F.m).fontSize(8.5).fillColor(NAVY).text(`${w.opening}: ${money(led.openingBalance, cur)}`, L0 + 78, y, { width: 280, lineBreak: false });
    y += 15;
  }
  for (const r of led.rows) {
    if (y + 16 > BOTTOM) { page(); head(); }
    const bad = r.kind === 'invoice' && (r.status === 'short' || r.status === 'open');
    const pc = r.pair ? pairColors(r.pair) : null;
    if (bad) doc.rect(L0, y - 2, CW, 15).fill('#FBE4E4');
    else if (pc) doc.rect(L0, y - 2, CW, 15).fill(pc.bg);
    else if (r.status === 'advance') doc.rect(L0, y - 2, CW, 15).fill('#FFF3D6');
    if (r.pair) { doc.circle(L0 + 11, y + 4.5, 6.5).fill(bad ? RED : (pc?.strong ?? STEEL)); doc.font(F.b).fontSize(6.5).fillColor('#FFFFFF').text(String(r.pair), L0 + 1, y + 2, { width: 20, align: 'center', lineBreak: false }); }
    const col = bad ? RED : '#222222';
    doc.font(F.r).fontSize(8).fillColor(col);
    doc.text(dmy(r.date), cols[1].x, y, { width: cols[1].w - 4, lineBreak: false });
    doc.text(r.kind === 'invoice' ? describe(r.description, a.lang) : (r.description || w.payment), cols[2].x, y, { width: cols[2].w - 6, height: 10, ellipsis: true, lineBreak: false });
    doc.font(bad ? F.b : F.m).text(r.kind === 'invoice' ? money(r.amount, cur) : '', cols[3].x, y, { width: cols[3].w - 4, align: 'right', lineBreak: false });
    doc.font(F.m).fillColor(r.status === 'advance' ? '#9A6A00' : '#222222').text(r.kind === 'payment' ? money(r.amount, cur) : '', cols[4].x, y, { width: cols[4].w - 4, align: 'right', lineBreak: false });
    doc.font(bad ? F.b : F.r).fontSize(7.5).fillColor(bad ? RED : r.status === 'advance' ? '#9A6A00' : STEEL).text(noteOf(r, w, cur), cols[5].x, y, { width: cols[5].w - 2, height: 10, ellipsis: true, lineBreak: false });
    doc.rect(L0, y + 12.5, CW, 0.4).fill(SMOKE);
    y += 15;
  }
  if (y + 70 > BOTTOM) page();
  y += 8;
  doc.rect(L0, y, CW, 24).fill('#F3F4F7');
  doc.font(F.h).fontSize(10).fillColor(NAVY).text(w.closing, L0 + 8, y + 7, { lineBreak: false });
  doc.text(money(led.balance, cur), L0 + 228, y + 7, { width: 136, align: 'right', lineBreak: false });
  doc.end();
  return done;
}

// the part of the e-mail: the open points (not the whole account: that is in the PDF)
export function ledgerSummaryHtml(a: { sap: string; lang: Lang; from: string | null }): string {
  const led: LedgerResult | null = ledgerFor(a.sap, a.from);
  const w = words(a.lang);
  if (!led) return '';
  const cell = 'padding:5px 9px;border-bottom:1px solid #e3e6ec;font:13px Calibri,Arial,sans-serif;color:#17243e';
  const th = 'padding:5px 9px;border-bottom:2px solid #17243e;font:bold 11px Calibri,Arial,sans-serif;color:#5e6676;text-align:left;text-transform:uppercase';
  const ex = led.rows.filter((r) => (r.kind === 'invoice' && (r.status === 'short' || r.status === 'open')) || r.status === 'advance');
  const s = led.summary;
  const line = `<p style="font:13px Calibri,Arial,sans-serif;color:#17243e;margin:6px 0">${esc(w.summary)}: ${s.invoices} ${esc(w.invoice.toLowerCase())} · ${s.paid + s.bank} ${esc(w.paid.toLowerCase())} · <b style="color:#8b1931">${s.short + s.open} ${esc(w.unpaid.toLowerCase())}/${esc(w.short.toLowerCase())}</b> · ${esc(w.closing)} <b>${esc(money(led.balance, led.currency))}</b></p>`;
  if (!ex.length) return `${line}<p style="font:13px Calibri,Arial,sans-serif;color:#17243e">${esc(w.none)}</p>`;
  const rows = ex.map((r) => `<tr><td style="${cell}">${esc(dmy(r.date))}</td><td style="${cell}">${esc(r.kind === 'invoice' ? describe(r.description, a.lang) : (r.description || w.payment))}</td><td style="${cell};text-align:right;color:${r.kind === 'invoice' ? '#8b1931' : '#9a6a00'}"><b>${esc(noteOf(r, w, led.currency))}</b></td></tr>`).join('');
  return `${line}<p style="font:bold 12px Calibri,Arial,sans-serif;color:#5e6676;margin:10px 0 2px;text-transform:uppercase">${esc(w.exceptions)}</p><table cellspacing="0" cellpadding="0" style="border-collapse:collapse;margin:4px 0 14px;min-width:480px"><thead><tr><th style="${th}">${esc(w.date)}</th><th style="${th}">${esc(w.description)}</th><th style="${th};text-align:right">${esc(w.note)}</th></tr></thead><tbody>${rows}</tbody></table>`;
}
