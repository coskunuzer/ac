import fs from 'fs';
import path from 'path';
import type PDFDocument from 'pdfkit';
import { fontOf, richRunsOf, type BiffData, type BiffSheet, type BorderSide, type FontInfo, type XfInfo } from './biff';
import { decodeEmfBlip, drawEmf } from './emf';
import { formatCell, type FormatOptions } from './numfmt';
import { colToIndex, indexToCol, type CellRange, type Evaluator, type SheetData } from './workbook';

type Doc = InstanceType<typeof PDFDocument>;

const ASSETS = path.resolve(__dirname, '../../../assets');
const FONT_DIR = path.join(ASSETS, 'fonts');

// Excel on the tece PCs prints with Calibri; Carlito is its metric-compatible twin,
// so line breaks and cell fit come out the same.
const FACES = {
  regular: 'Sheet-Regular',
  bold: 'Sheet-Bold',
  italic: 'Sheet-Italic',
  boldItalic: 'Sheet-BoldItalic',
};

const PAPER: Record<number, [number, number]> = {
  1: [612, 792], // Letter
  8: [841.89, 1190.55], // A3
  9: [595.28, 841.89], // A4
  5: [612, 1008], // Legal
};

export function registerSheetFonts(doc: Doc) {
  doc.registerFont(FACES.regular, path.join(FONT_DIR, 'Carlito-Regular.ttf'));
  doc.registerFont(FACES.bold, path.join(FONT_DIR, 'Carlito-Bold.ttf'));
  doc.registerFont(FACES.italic, path.join(FONT_DIR, 'Carlito-Italic.ttf'));
  doc.registerFont(FACES.boldItalic, path.join(FONT_DIR, 'Carlito-BoldItalic.ttf'));
}

const faceOf = (f: FontInfo) => (f.bold && f.italic ? FACES.boldItalic : f.bold ? FACES.bold : f.italic ? FACES.italic : FACES.regular);
const hex = (c: string | null, fallback = '000000') => `#${c ?? fallback}`;

export interface SheetPrintJob {
  doc: Doc;
  sheet: SheetData;
  biff: BiffData;
  biffSheet: BiffSheet;
  ev: Evaluator;
  format: FormatOptions;
  // Rows/columns (0-based) to leave out, on top of anything the workbook itself hides.
  hideRows: Set<number>;
  hideCols: Set<number>;
  // Rows/columns (0-based) the workbook hides (other thicknesses, a base paper) but the offer asks for: they print anyway.
  showRows?: Set<number>;
  showCols?: Set<number>;
  // Row ranges (0-based, inclusive) that must stay together on one page - none yet.
  letterhead: { header: Buffer | null; footer: Buffer | null };
  // translates a text of the sheet (the offer in another language); numbers are never passed
  tr?: (text: string) => string;
}

interface Geometry {
  cols: number[]; // visible column indexes
  rows: number[]; // visible row indexes
  colX: Map<number, number>; // left edge of each visible column, in sheet points
  colW: Map<number, number>;
  rowH: Map<number, number>;
}

function usedArea(sheet: SheetData, biffSheet: BiffSheet): { r1: number; c1: number; r2: number; c2: number } {
  if (biffSheet.print.area) return biffSheet.print.area;
  return { r1: 0, c1: 0, r2: sheet.maxRow - 1, c2: sheet.maxCol - 1 };
}

function geometry(job: SheetPrintJob, area: { r1: number; c1: number; r2: number; c2: number }): Geometry {
  const { sheet } = job;
  const cols: number[] = [];
  const colX = new Map<number, number>();
  const colW = new Map<number, number>();
  let x = 0;
  for (let c = area.c1; c <= area.c2; c++) {
    const forced = job.showCols?.has(c) === true;
    if ((!forced && sheet.hiddenCols.has(indexToCol(c + 1))) || job.hideCols.has(c)) continue;
    let w = sheet.colWidthPt.get(c) ?? 48;
    // a column the workbook hides can be stored with no width: give it the width of its neighbours
    if (w <= 0.5 && forced) w = 56;
    if (w <= 0.5) continue;
    cols.push(c);
    colX.set(c, x);
    colW.set(c, w);
    x += w;
  }
  const rows: number[] = [];
  const rowH = new Map<number, number>();
  for (let r = area.r1; r <= area.r2; r++) {
    const forced = job.showRows?.has(r) === true;
    if ((!forced && sheet.hiddenRows.has(r)) || job.hideRows.has(r)) continue;
    let h = sheet.rowHeightPt.get(r) ?? 15;
    if (h <= 0.5 && forced) h = 15;
    if (h <= 0.5) continue;
    rows.push(r);
    rowH.set(r, h);
  }
  return { cols, rows, colX, colW, rowH };
}

function mergeAt(merges: CellRange[], r: number, c: number): CellRange | undefined {
  return merges.find((m) => r >= m.r1 && r <= m.r2 && c >= m.c1 && c <= m.c2);
}

export function drawSheet(job: SheetPrintJob): { pages: number } {
  const { doc, sheet, biff, biffSheet, ev } = job;
  const print = biffSheet.print;
  const area = usedArea(sheet, biffSheet);
  const g = geometry(job, area);
  if (!g.cols.length || !g.rows.length) return { pages: 0 };

  const [pageW, pageH] = (() => {
    const [w, h] = PAPER[print.paperSize] ?? PAPER[9];
    return print.landscape ? [h, w] : [w, h];
  })();
  const m = sheet.margins;
  const availW = pageW - (m.left + m.right) * 72;
  const availH = pageH - (m.top + m.bottom) * 72;
  const gridW = g.cols.reduce((s, c) => s + g.colW.get(c)!, 0);
  const gridH = g.rows.reduce((s, r) => s + g.rowH.get(r)!, 0);

  // Each sheet is meant to be one page: shrink it to fit (the sheets are laid out
  // for A4 but get printed on Letter too). Only the workbook's own manual page
  // breaks (e.g. between MOQ tables) start another page.
  const manual = print.pageBreaks.filter((b) => b > area.r1 && b <= area.r2);
  const chunks: number[][] = [];
  if (manual.length) {
    let cur: number[] = [];
    for (const r of g.rows) {
      if (manual.includes(r) && cur.length) { chunks.push(cur); cur = []; }
      cur.push(r);
    }
    if (cur.length) chunks.push(cur);
  } else {
    chunks.push(g.rows);
  }
  const tallest = Math.max(...chunks.map((rows) => rows.reduce((s, r) => s + g.rowH.get(r)!, 0)));
  let scale = Math.min(1, availW / gridW, availH / tallest);
  if (!Number.isFinite(scale) || scale <= 0) scale = 1;
  // A sheet far taller than a page keeps readable text instead and runs onto more
  // pages, breaking at the blank rows between its tables where possible.
  const pageRows: number[][] = [];
  const isBlankRow = (r: number) => {
    for (let c = area.c1; c <= area.c2; c++) {
      const raw = sheet.cells.get(`${indexToCol(c + 1)}${r + 1}`);
      if (raw && (raw.f !== undefined || (raw.v !== null && raw.v !== ''))) return false;
    }
    return true;
  };
  // a row that starts a new table: it carries a title-sized font (>= 14pt)
  const isTitleRow = (r: number) => {
    for (let c = area.c1; c <= area.c2; c++) {
      const raw = sheet.cells.get(`${indexToCol(c + 1)}${r + 1}`);
      if (!raw || raw.v === null || raw.v === '') continue;
      const xf = xfOf(job, r, c);
      if (xf && fontOf(biff, xf).size >= 14) return true;
    }
    return false;
  };
  if (scale < 0.7) {
    scale = Math.min(1, availW / gridW);
    for (const rows of chunks) {
      let cur: number[] = [];
      let used = 0;
      for (const r of rows) {
        const h = g.rowH.get(r)! * scale;
        if (used + h > availH + 0.5 && cur.length) {
          // prefer to break after a blank spacer row, if that keeps the page reasonably full
          let cut = -1;
          let softCut = -1;
          let acc = 0;
          for (let i = 0; i < cur.length; i++) {
            acc += g.rowH.get(cur[i])! * scale;
            if (!isBlankRow(cur[i]) || acc < availH * 0.4) continue;
            softCut = i + 1;
            const next = cur[i + 1] ?? r;
            if (isTitleRow(next)) cut = i + 1;
          }
          if (cut < 0) cut = softCut;
          if (cut > 0 && cut < cur.length) {
            pageRows.push(cur.slice(0, cut));
            cur = cur.slice(cut);
            used = cur.reduce((sum, rr) => sum + g.rowH.get(rr)! * scale, 0);
          } else {
            pageRows.push(cur);
            cur = [];
            used = 0;
          }
        }
        cur.push(r);
        used += h;
      }
      if (cur.length) pageRows.push(cur);
    }
  } else {
    pageRows.push(...chunks);
  }

  pageRows.forEach((rowsOnPage, pageIndex) => {
    doc.addPage({ size: [pageW, pageH], margin: 0 });
    const ox = m.left * 72 + Math.max(0, (availW - gridW * scale) / 2);
    const oy = m.top * 72;

    drawLetterhead(job, pageW, pageH, m, ox, gridW * scale);

    let yTop = 0;
    const rowY = new Map<number, number>();
    for (const r of rowsOnPage) { rowY.set(r, yTop); yTop += g.rowH.get(r)!; }
    const visibleRows = new Set(rowsOnPage);

    doc.save();
    doc.translate(ox, oy);
    doc.scale(scale);
    drawCells(job, g, area, rowsOnPage, rowY, visibleRows);
    drawPictures(job, g, rowY, visibleRows);
    doc.restore();
  });
  void biff;
  void ev;
  return { pages: pageRows.length };
}

function drawLetterhead(job: SheetPrintJob, pageW: number, pageH: number, m: SheetData['margins'], ox: number, width: number) {
  const { doc, letterhead } = job;
  if (letterhead.header) {
    const img = (doc as unknown as { openImage(b: Buffer): { width: number; height: number } }).openImage(letterhead.header);
    const h = (width * img.height) / img.width;
    doc.image(letterhead.header, ox, m.header * 72, { width, height: h });
  }
  if (letterhead.footer) {
    const img = (doc as unknown as { openImage(b: Buffer): { width: number; height: number } }).openImage(letterhead.footer);
    const h = (width * img.height) / img.width;
    doc.image(letterhead.footer, ox, pageH - m.footer * 72 - h, { width, height: h });
  }
  void pageW;
}

// ---- cells ------------------------------------------------------------------

function xfOf(job: SheetPrintJob, r: number, c: number): XfInfo | undefined {
  const i = job.biffSheet.xfByCell.get(`${r},${c}`);
  return i === undefined ? undefined : job.biff.xfs[i];
}

function cellText(job: SheetPrintJob, r: number, c: number): { text: string; isNumber: boolean; runs: { text: string; font: FontInfo }[] | null } {
  const addr = `${indexToCol(c + 1)}${r + 1}`;
  const raw = job.sheet.cells.get(addr);
  if (!raw) return { text: '', isNumber: false, runs: null };
  const value = job.ev.value(job.sheet.name, addr);
  if (raw.err && raw.f === undefined) return { text: '', isNumber: false, runs: null };
  const text = formatCell(value, raw.z, job.format);
  let runs: { text: string; font: FontInfo }[] | null = null;
  if (typeof value === 'string' && raw.f === undefined) {
    const sst = job.biffSheet.sstByCell.get(`${r},${c}`);
    const rich = sst !== undefined ? job.biff.richStrings.get(sst) : undefined;
    const xf = xfOf(job, r, c);
    if (rich && xf) runs = richRunsOf(text, rich, fontOf(job.biff, xf));
  }
  const isNumber = typeof value === 'number';
  // a translated text loses its mixed fonts (bold words inside a sentence): it is printed in the font of the cell
  if (job.tr && /\p{L}{3}/u.test(text)) return { text: job.tr(text), isNumber, runs: null };
  return { text, isNumber, runs };
}

function dash(doc: Doc, style: BorderSide['style']) {
  if (style === 'dashed') doc.dash(3, { space: 2 });
  else if (style === 'dotted') doc.dash(1, { space: 1.2 });
  else doc.undash();
}

function drawBorderLine(doc: Doc, side: BorderSide, x1: number, y1: number, x2: number, y2: number) {
  if (side.style === 'none') return;
  const widths: Record<BorderSide['style'], number> = { none: 0, hair: 0.3, thin: 0.6, dashed: 0.6, dotted: 0.6, medium: 1, double: 0.5, thick: 1.8 };
  doc.save();
  dash(doc, side.style);
  doc.lineWidth(widths[side.style]).strokeColor(hex(side.color));
  if (side.style === 'double') {
    const horizontal = y1 === y2;
    const o = 0.9;
    doc.moveTo(x1 + (horizontal ? 0 : -o), y1 + (horizontal ? -o : 0)).lineTo(x2 + (horizontal ? 0 : -o), y2 + (horizontal ? -o : 0)).stroke();
    doc.moveTo(x1 + (horizontal ? 0 : o), y1 + (horizontal ? o : 0)).lineTo(x2 + (horizontal ? 0 : o), y2 + (horizontal ? o : 0)).stroke();
  } else {
    doc.moveTo(x1, y1).lineTo(x2, y2).stroke();
  }
  doc.restore();
}

function drawCells(job: SheetPrintJob, g: Geometry, area: { r1: number; c1: number; r2: number; c2: number }, rowsOnPage: number[], rowY: Map<number, number>, visibleRows: Set<number>) {
  const { doc, sheet } = job;

  // Rectangle of a cell or merged block, in sheet points; null if it isn't on this page.
  const rectOf = (r: number, c: number): { x: number; y: number; w: number; h: number; range: CellRange } | null => {
    const mg = mergeAt(sheet.merges, r, c);
    const range = mg ?? { r1: r, c1: c, r2: r, c2: c };
    const cs = g.cols.filter((x) => x >= range.c1 && x <= range.c2);
    const rs = rowsOnPage.filter((x) => x >= range.r1 && x <= range.r2);
    if (!cs.length || !rs.length) return null;
    const x = g.colX.get(cs[0])!;
    const y = rowY.get(rs[0])!;
    return {
      x, y, range,
      w: cs.reduce((s, k) => s + g.colW.get(k)!, 0),
      h: rs.reduce((s, k) => s + g.rowH.get(k)!, 0),
    };
  };

  const isCovered = (r: number, c: number) => {
    const mg = mergeAt(sheet.merges, r, c);
    return !!mg && !(mg.r1 === r && mg.c1 === c);
  };

  const cellsToDraw: [number, number][] = [];
  for (const r of rowsOnPage) for (const c of g.cols) cellsToDraw.push([r, c]);
  // Excel still prints a merged cell whose first column/row is hidden
  for (const mg of sheet.merges) {
    const anchorVisible = g.cols.includes(mg.c1) && rowsOnPage.includes(mg.r1);
    const anyVisible = g.cols.some((c) => c >= mg.c1 && c <= mg.c2) && rowsOnPage.some((r) => r >= mg.r1 && r <= mg.r2);
    if (!anchorVisible && anyVisible) cellsToDraw.push([mg.r1, mg.c1]);
  }

  // 1. fills
  for (const [r, c] of cellsToDraw) {
    {
      if (isCovered(r, c)) continue;
      const fill = sheet.fills.get(`${indexToCol(c + 1)}${r + 1}`);
      if (!fill) continue;
      const rect = rectOf(r, c);
      if (rect) doc.rect(rect.x, rect.y, rect.w + 0.35, rect.h + 0.35).fill(`#${fill}`);
    }
  }

  // 2. borders
  for (const [r, c] of cellsToDraw) {
    {
      if (isCovered(r, c)) continue;
      const rect = rectOf(r, c);
      if (!rect) continue;
      const { range } = rect;
      const tl = xfOf(job, range.r1, range.c1);
      const br = xfOf(job, range.r2, range.c2);
      const tr = xfOf(job, range.r1, range.c2);
      const bl = xfOf(job, range.r2, range.c1);
      if (tl?.top) drawBorderLine(doc, tl.top, rect.x, rect.y, rect.x + rect.w, rect.y);
      if (bl?.bottom) drawBorderLine(doc, bl.bottom, rect.x, rect.y + rect.h, rect.x + rect.w, rect.y + rect.h);
      if (tl?.left) drawBorderLine(doc, tl.left, rect.x, rect.y, rect.x, rect.y + rect.h);
      if (tr?.right) drawBorderLine(doc, tr.right, rect.x + rect.w, rect.y, rect.x + rect.w, rect.y + rect.h);
      void br;
    }
  }

  // 3. text
  const emptyAt = (r: number, c: number) => {
    const raw = sheet.cells.get(`${indexToCol(c + 1)}${r + 1}`);
    return !raw || (raw.v === null || raw.v === '') && raw.f === undefined;
  };

  for (const [r, c] of cellsToDraw) {
    {
      if (isCovered(r, c)) continue;
      const { text: rawText, isNumber, runs } = cellText(job, r, c);
      let text = rawText;
      if (!text) continue;
      const rect = rectOf(r, c);
      const xf = xfOf(job, r, c);
      if (!rect || !xf) continue;
      const font = fontOf(job.biff, xf);
      const pad = 2;
      const indent = xf.indent * 5;

      const align: 'left' | 'center' | 'right' =
        xf.horizontal === 'center' || xf.horizontal === 'centerAcross' ? 'center'
          : xf.horizontal === 'right' ? 'right'
            : xf.horizontal === 'left' || xf.horizontal === 'fill' || xf.horizontal === 'justify' ? 'left'
              : isNumber ? 'right' : 'left';

      // clip box; unwrapped text may spill into empty neighbours like in Excel
      let clipX = rect.x;
      let clipW = rect.w;
      if (!xf.wrap) {
        const inRange = g.cols.filter((x) => x >= rect.range.c1 && x <= rect.range.c2);
        const visibleIdx = g.cols.indexOf(inRange[inRange.length - 1]);
        if (align === 'left' || align === 'center') {
          for (let k = visibleIdx + 1; k < g.cols.length && emptyAt(r, g.cols[k]) && !mergeAt(sheet.merges, r, g.cols[k]); k++) clipW += g.colW.get(g.cols[k])!;
        }
        if (align === 'right' || align === 'center') {
          const first = g.cols.indexOf(inRange[0]);
          for (let k = first - 1; k >= 0 && emptyAt(r, g.cols[k]) && !mergeAt(sheet.merges, r, g.cols[k]); k--) { clipX -= g.colW.get(g.cols[k])!; clipW += g.colW.get(g.cols[k])!; }
        }
      }

      const innerW = Math.max(1, rect.w - pad * 2 - (align === 'left' ? indent : 0));
      if (isNumber && !xf.wrap && !xf.shrink) {
        doc.font(faceOf(font)).fontSize(font.size);
        if (doc.widthOfString(text) > innerW) {
          const hashW = doc.widthOfString('#');
          text = '#'.repeat(Math.max(1, Math.floor(innerW / hashW)));
        }
      }
      const sourceRuns = runs && runs.length > 1 ? runs : [{ text, font }];

      // "shrink to fit": reduce the font until the unwrapped text fits the cell
      let fontScale = 1;
      if (xf.shrink && !xf.wrap) {
        const natural = layoutText(doc, sourceRuns, 1, null).lines.reduce((m, l) => Math.max(m, l.width), 0);
        if (natural > innerW) fontScale = Math.max(0.3, (innerW / natural) * 0.97);
      }
      const laid = layoutText(doc, sourceRuns, fontScale, xf.wrap ? innerW : null);
      const blockH = laid.lines.reduce((s, l) => s + l.height, 0);
      let y =
        xf.vertical === 'top' ? rect.y + 0.5
          : xf.vertical === 'center' ? rect.y + (rect.h - blockH) / 2
            : rect.y + rect.h - blockH - 0.5;

      doc.save();
      doc.rect(clipX, rect.y, clipW, rect.h).clip();
      for (const line of laid.lines) {
        let x =
          align === 'center' ? rect.x + (rect.w - line.width) / 2
            : align === 'right' ? rect.x + rect.w - pad - line.width
              : rect.x + pad + indent;
        for (const seg of line.segs) {
          doc.font(faceOf(seg.font)).fontSize(seg.font.size * fontScale).fillColor(hex(seg.font.color));
          doc.text(seg.text, x, y, { lineBreak: false, underline: seg.font.underline, strike: seg.font.strike });
          x += seg.width;
        }
        y += line.height;
      }
      doc.restore();
    }
  }
}

interface Seg { text: string; font: FontInfo; width: number }
interface Line { segs: Seg[]; width: number; height: number }

// Lays rich text out into lines, wrapping at word boundaries when maxWidth is given.
// Widths are measured per word in that word's own font, as Excel does.
function layoutText(doc: Doc, runs: { text: string; font: FontInfo }[], scale: number, maxWidth: number | null): { lines: Line[] } {
  const lines: Line[] = [];
  let cur: Seg[] = [];
  let curW = 0;
  let lastFont = runs[0]?.font;

  const lineHeightOf = (segs: Seg[], fallback: FontInfo) =>
    Math.max(...(segs.length ? segs.map((s) => s.font.size) : [fallback.size])) * scale * 1.22;
  const finish = () => {
    // trailing spaces don't count towards alignment
    while (cur.length && /^\s*$/.test(cur[cur.length - 1].text)) { curW -= cur[cur.length - 1].width; cur.pop(); }
    lines.push({ segs: cur, width: Math.max(0, curW), height: lineHeightOf(cur, lastFont) });
    cur = [];
    curW = 0;
  };

  for (const run of runs) {
    lastFont = run.font;
    doc.font(faceOf(run.font)).fontSize(run.font.size * scale);
    const parts = run.text.split(/(\r?\n)|(\s+)/).filter((p) => p !== undefined && p !== '');
    for (const part of parts) {
      if (/^\r?\n$/.test(part)) { finish(); continue; }
      const width = doc.widthOfString(part);
      const isSpace = /^\s+$/.test(part);
      if (maxWidth !== null && !isSpace && curW + width > maxWidth + 0.01 && cur.some((s) => !/^\s*$/.test(s.text))) finish();
      if (isSpace && cur.length === 0) continue; // no leading spaces on a wrapped line
      cur.push({ text: part, font: run.font, width });
      curW += width;
    }
  }
  if (cur.length || lines.length === 0) finish();
  return { lines };
}

// ---- pictures ---------------------------------------------------------------

function drawPictures(job: SheetPrintJob, g: Geometry, rowY: Map<number, number>, visibleRows: Set<number>) {
  const { doc, biffSheet, biff } = job;
  const at = (col: number, dx: number, row: number, dy: number): [number, number] | null => {
    if (!g.colX.has(col) || !visibleRows.has(row)) return null;
    return [g.colX.get(col)! + dx * g.colW.get(col)!, rowY.get(row)! + dy * g.rowH.get(row)!];
  };
  for (const pic of biffSheet.pictures) {
    const store = biff.pictures[pic.image];
    if (!store?.data) continue;
    const a = at(pic.from.col, pic.from.dx, pic.from.row, pic.from.dy);
    // the far corner may sit in a hidden column/row: fall back to the nearest visible one
    let b = at(pic.to.col, pic.to.dx, pic.to.row, pic.to.dy);
    if (!a) continue;
    if (!b) {
      const lastCol = [...g.cols].reverse().find((c) => c <= pic.to.col);
      const lastRow = [...visibleRows].sort((x, y) => x - y).reverse().find((r) => r <= pic.to.row);
      if (lastCol === undefined || lastRow === undefined) continue;
      b = [g.colX.get(lastCol)! + g.colW.get(lastCol)!, rowY.get(lastRow)! + g.rowH.get(lastRow)!];
    }
    const w = b[0] - a[0];
    const h = b[1] - a[1];
    if (w < 1 || h < 1) continue;
    try {
      if (store.kind === 'jpeg' || store.kind === 'png') doc.image(store.data, a[0], a[1], { width: w, height: h });
      else if (store.kind === 'emf') {
        const emf = decodeEmfBlip(store.data);
        if (emf) drawEmf(doc as never, emf, a[0], a[1], w, h);
      }
    } catch {
      // an undecodable picture is skipped rather than failing the whole offer
    }
  }
}

export function loadLetterhead(): { header: Buffer | null; footer: Buffer | null } {
  const read = (name: string) => {
    try { return fs.readFileSync(path.join(ASSETS, name)); } catch { return null; }
  };
  return { header: read('letterhead-header.png'), footer: read('letterhead-footer.png') };
}

export { colToIndex };
