import { db } from '../db/connection';
import { visibilityFor, type Viewer } from './visibility';

// The search that finds what you mean. The closest customers come first (the exact SAP number or e-mail, the company or person you typed), then customers that only look
// like it (a letter off, one word of the name, a phone number that ends the same), then the places where the words are written down (notes, calls, e-mails, offers).
// Spelling is forgiven: capitals, accents, Turkish letters, a missing letter. Nothing here uses the AI, so it costs nothing and answers at once.
export interface Hit {
  market: string | null; tel: string | null; mobile: string | null; position: string | null;
  id: number; company: string | null; name: string | null; email: string | null; country: string | null; city: string | null; stage: string | null; sap: string | null;
  score: number; why: string; snippet?: string; when?: string;
}
export interface SearchResult { q: string; best: Hit[]; related: Hit[]; context: Hit[]; total: number }

interface Doc {
  tel: string | null; mobile: string | null; position: string | null;
  id: number; uploaded_by: number | null; person: string | null; country: string | null; status: string; market: string | null; city: string | null; owner_override: number | null;
  company: string | null; name: string | null; email: string | null; stage: string | null; sap: string | null; rate: number | null; aiRate: number | null;
  nCompany: string; nName: string; nEmail: string; digits: string; nSap: string; nWeb: string; nPlace: string; nExtra: string; nNotes: string;
}

export const norm = (s: string | null | undefined): string => (s ?? '')
  .replace(/İ/g, 'i').normalize('NFD').replace(/\p{Diacritic}/gu, '').replace(/ı/g, 'i').toLowerCase().replace(/[^a-z0-9@. ]+/g, ' ').replace(/\s+/g, ' ').trim();

let index: Doc[] | null = null;
let builtAt = 0;
const TTL = 90_000;
export const forgetSearchIndex = () => { index = null; };

function build(): Doc[] {
  const contacts = new Map<number, { text: string; digits: string }>();
  for (const c of db.prepare('SELECT card_id, name, last_name, email, tel, mobile, position FROM card_contacts').all() as { card_id: number; name: string | null; last_name: string | null; email: string | null; tel: string | null; mobile: string | null; position: string | null }[]) {
    const x = contacts.get(c.card_id) ?? { text: '', digits: '' };
    x.text += ` ${c.name ?? ''} ${c.last_name ?? ''} ${c.email ?? ''} ${c.position ?? ''}`;
    x.digits += ` ${(c.tel ?? '').replace(/\D/g, '')} ${(c.mobile ?? '').replace(/\D/g, '')}`;
    contacts.set(c.card_id, x);
  }
  const rows = db.prepare('SELECT id, uploaded_by, person, country, status, market, city, owner_override, company, name, last_name, email, tel, mobile, sap, website, position, address, work_area, interested_in, notes, stage, rate, ai_rate FROM cards').all() as Record<string, unknown>[];
  return rows.map((r) => {
    const ct = contacts.get(r.id as number);
    const s = (k: string) => (r[k] as string | null) ?? '';
    return {
      tel: r.tel as string | null, mobile: r.mobile as string | null, position: r.position as string | null,
      id: r.id as number, uploaded_by: r.uploaded_by as number | null, person: r.person as string | null, country: r.country as string | null, status: s('status'), market: r.market as string | null, city: r.city as string | null,
      owner_override: r.owner_override as number | null, company: r.company as string | null, name: [s('name'), s('last_name')].filter(Boolean).join(' ') || null, email: r.email as string | null, stage: r.stage as string | null,
      sap: r.sap as string | null, rate: r.rate as number | null, aiRate: r.ai_rate as number | null,
      nCompany: norm(s('company')), nName: norm(`${s('name')} ${s('last_name')}`), nEmail: norm(`${s('email')} ${ct?.text.match(/\S+@\S+/g)?.join(' ') ?? ''}`),
      digits: `${s('tel').replace(/\D/g, '')} ${s('mobile').replace(/\D/g, '')} ${ct?.digits ?? ''}`, nSap: s('sap').replace(/\s+/g, '').toLowerCase(), nWeb: norm(s('website')),
      nPlace: norm(`${s('city')} ${s('country')} ${s('address')}`), nExtra: norm(`${s('position')} ${s('work_area')} ${s('interested_in')} ${ct?.text ?? ''}`), nNotes: norm(s('notes')),
    };
  });
}

function docs(): Doc[] {
  if (!index || Date.now() - builtAt > TTL) { index = build(); builtAt = Date.now(); }
  return index;
}

// the number of letters that differ (a letter more, less, or another), stops early
function dist(a: string, b: string, max: number): number {
  if (Math.abs(a.length - b.length) > max) return max + 1;
  let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    const cur = [i];
    let rowMin = i;
    for (let j = 1; j <= b.length; j++) {
      cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      if (cur[j] < rowMin) rowMin = cur[j];
    }
    if (rowMin > max) return max + 1;
    prev = cur;
  }
  return prev[b.length];
}

const wordStart = (hay: string, tok: string) => hay.startsWith(tok) || hay.includes(` ${tok}`);

function scoreDoc(d: Doc, qn: string, toks: string[], qDigits: string, qSap: string): { score: number; why: string } {
  let best = 0; let why = '';
  const give = (s: number, w: string) => { if (s > best) { best = s; why = w; } };
  // the number of the customer in SAP, or part of it
  if (qSap.length >= 4 && d.nSap) { if (d.nSap === qSap) give(1000, 'SAP number'); else if (d.nSap.endsWith(qSap) || d.nSap.startsWith(qSap)) give(720, 'SAP number'); else if (qSap.length >= 6 && d.nSap.includes(qSap)) give(520, 'SAP number'); }
  // the e-mail
  if (qn.includes('@') || qn.length >= 4) {
    if (d.nEmail) {
      const es = d.nEmail.split(' ');
      if (es.includes(qn)) give(960, 'E-mail');
      else if (es.some((e) => e.startsWith(qn))) give(640, 'E-mail');
      else if (qn.length >= 4 && d.nEmail.includes(qn)) give(470, 'E-mail');
    }
  }
  // the phone number
  if (qDigits.length >= 5 && d.digits.trim()) {
    const ds = d.digits.split(' ').filter(Boolean);
    if (ds.some((x) => x === qDigits || x.endsWith(qDigits))) give(780, 'Phone');
    else if (ds.some((x) => x.includes(qDigits))) give(430, 'Phone');
  }
  // the company and the person
  for (const [h, label, base] of [[d.nCompany, 'Company', 1], [d.nName, 'Name', 0.93]] as [string, string, number][]) {
    if (!h) continue;
    if (h === qn) give(900 * base, label);
    else if (h.startsWith(qn)) give(800 * base, label);
    else if (toks.length && toks.every((t) => wordStart(h, t))) give(690 * base, label);
    else if (toks.length && toks.every((t) => h.includes(t))) give(540 * base, label);
  }
  // the web site
  if (qn.length >= 4 && d.nWeb && d.nWeb.includes(qn)) give(360, 'Web site');
  // the words are spread over several fields (company + city, name + company ...)
  if (best < 450 && toks.length >= 2) {
    const all = `${d.nCompany} ${d.nName} ${d.nEmail} ${d.nPlace} ${d.nExtra} ${d.nWeb}`;
    if (toks.every((t) => all.includes(t))) give(330, 'Company and place');
  }
  // a letter off: every word of what was typed is close to a word of the company or the person
  if (best < 300 && toks.length) {
    const words = `${d.nCompany} ${d.nName}`.split(' ').filter((w) => w.length >= 3);
    let total = 0; let ok = true;
    for (const t of toks) {
      if (t.length < 4) { if (words.some((w) => w.startsWith(t))) continue; ok = false; break; }
      const max = t.length <= 6 ? 1 : 2;
      let m = max + 1;
      for (const w of words) { const x = dist(t, w.slice(0, Math.max(t.length + 1, 4)), max); if (x < m) m = x; if (m === 0) break; }
      if (m > max) { ok = false; break; }
      total += m;
    }
    if (ok && total > 0) give(260 - total * 40, 'Looks like');
  }
  if (best > 0) {
    if (d.stage === 'customer' || d.sap) best += 40;
    best += Math.min(30, (d.rate ?? d.aiRate ?? 0) * 3);
  }
  return { score: best, why };
}

export function smartSearch(viewer: Viewer, q: string, limit = 12): SearchResult {
  const qn = norm(q);
  const empty: SearchResult = { q, best: [], related: [], context: [], total: 0 };
  if (qn.length < 2) return empty;
  const toks = qn.split(' ').filter(Boolean);
  const qDigits = q.replace(/\D/g, '');
  const qSap = q.replace(/\s+/g, '').toLowerCase();
  const visible = visibilityFor(viewer);
  const hits: Hit[] = [];
  const found = new Set<number>();
  for (const d of docs()) {
    if (!visible({ uploaded_by: d.uploaded_by ?? 0, person: d.person, country: d.country, status: d.status as never, market: d.market, city: d.city, owner_override: d.owner_override })) continue;
    const { score, why } = scoreDoc(d, qn, toks, qDigits, qSap);
    if (score <= 0) continue;
    found.add(d.id);
    hits.push({ market: d.market, tel: d.tel, mobile: d.mobile, position: d.position, id: d.id, company: d.company, name: d.name, email: d.email, country: d.country, city: d.city, stage: d.stage, sap: d.sap, score, why });
  }
  hits.sort((a, b) => b.score - a.score || (a.company ?? '').localeCompare(b.company ?? ''));
  const best = hits.filter((h) => h.score >= 600).slice(0, limit);
  const related = hits.filter((h) => h.score < 600).slice(0, limit);

  // where the words are written down: the notes of the customer, and the history (notes, calls, e-mails, offers)
  const context: Hit[] = [];
  const ctxIds = new Set<number>();
  if (toks.length) {
    const like = toks.map(() => 'LOWER(a.text) LIKE ?').join(' AND ');
    const rows = db.prepare(`SELECT a.card_id, a.type, a.created_at, a.text FROM activities a WHERE a.card_id IS NOT NULL AND a.text IS NOT NULL AND ${like} ORDER BY a.id DESC LIMIT 60`).all(...toks.map((t) => `%${t}%`)) as { card_id: number; type: string; created_at: string; text: string }[];
    const byId = new Map(docs().map((d) => [d.id, d]));
    for (const r of rows) {
      const d = byId.get(r.card_id);
      if (!d || ctxIds.has(d.id) || !visible({ uploaded_by: d.uploaded_by ?? 0, person: d.person, country: d.country, status: d.status as never, market: d.market, city: d.city, owner_override: d.owner_override })) continue;
      ctxIds.add(d.id);
      const low = r.text.toLowerCase();
      const at = Math.max(0, low.indexOf(toks[0]));
      context.push({ market: d.market, tel: d.tel, mobile: d.mobile, position: d.position, id: d.id, company: d.company, name: d.name, email: d.email, country: d.country, city: d.city, stage: d.stage, sap: d.sap, score: 0, why: r.type, snippet: `${at > 30 ? '…' : ''}${r.text.slice(Math.max(0, at - 30), at + 110).replace(/\s+/g, ' ')}${r.text.length > at + 110 ? '…' : ''}`, when: r.created_at.slice(0, 10) });
      if (context.length >= limit) break;
    }
    if (context.length < limit) {
      for (const d of docs()) {
        if (ctxIds.has(d.id) || found.has(d.id)) continue;
        if (!toks.every((t) => d.nNotes.includes(t) || d.nExtra.includes(t))) continue;
        if (!visible({ uploaded_by: d.uploaded_by ?? 0, person: d.person, country: d.country, status: d.status as never, market: d.market, city: d.city, owner_override: d.owner_override })) continue;
        const at = Math.max(0, d.nNotes.indexOf(toks[0]));
        context.push({ market: d.market, tel: d.tel, mobile: d.mobile, position: d.position, id: d.id, company: d.company, name: d.name, email: d.email, country: d.country, city: d.city, stage: d.stage, sap: d.sap, score: 0, why: 'Notes', snippet: d.nNotes.slice(Math.max(0, at - 30), at + 110) });
        if (context.length >= limit) break;
      }
    }
  }
  return { q, best, related, context, total: hits.length + context.length };
}
