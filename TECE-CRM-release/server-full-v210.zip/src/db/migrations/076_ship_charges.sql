-- The items a forwarder is asked to include in the price (port charges, inland transport, YDG ...). Kept by an admin; ticked per request; the chosen ones are written in the e-mail.
CREATE TABLE IF NOT EXISTS ship_charges (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name_tr TEXT NOT NULL,
  name_en TEXT NOT NULL,
  default_on INTEGER NOT NULL DEFAULT 1,
  active INTEGER NOT NULL DEFAULT 1,
  sort INTEGER NOT NULL DEFAULT 0
);
ALTER TABLE ship_requests ADD COLUMN charges TEXT;   -- JSON list of the names asked to be included (Turkish)
