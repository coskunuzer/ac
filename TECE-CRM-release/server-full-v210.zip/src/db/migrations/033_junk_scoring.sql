-- Notes that came with an import (field visits of the domestic list) are marked, so they do not count as work done today.
ALTER TABLE activities ADD COLUMN imported INTEGER NOT NULL DEFAULT 0;

-- The junk folder (admin only): customers taken out of the lists - for example existing customers with no sale in the last 22 months.
-- data = what is needed to bring them back: a snapshot of the customer with its people, notes and offers, or - for a company that was
-- never in the app - the row of the list.
CREATE TABLE IF NOT EXISTS junk_cards (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company TEXT,
  city TEXT,
  sap TEXT,
  reason TEXT,
  origin TEXT NOT NULL,
  data TEXT NOT NULL,
  moved_by INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_junk_sap ON junk_cards(sap);

-- The company scoring (v12): Purchase Score and Fit Score worked out by code from facts with quotes (JSON).
ALTER TABLE cards ADD COLUMN company_score TEXT;
