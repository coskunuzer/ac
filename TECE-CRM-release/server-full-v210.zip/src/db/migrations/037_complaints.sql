-- Complaints: a customer complaint written by a salesperson (what happened, which order, what it cost), with photos, made into a clean PDF
-- and sent to the people who deal with it.
CREATE TABLE IF NOT EXISTS complaints (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_by INTEGER NOT NULL,
  card_id INTEGER,
  customer_name TEXT,
  customer_contact TEXT,
  customer_email TEXT,
  customer_country TEXT,
  order_no TEXT,
  -- quantity, quality, delivery, other
  kind TEXT NOT NULL DEFAULT 'quality',
  -- what the person wrote (any language), the numbers, and what the AI made of it (JSON)
  raw_text TEXT,
  items_json TEXT,
  amount_wasted REAL,
  currency TEXT NOT NULL DEFAULT 'EUR',
  polished_json TEXT,
  status TEXT NOT NULL DEFAULT 'draft',
  sent_at TEXT,
  sent_to TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_complaints_user ON complaints (created_by);

CREATE TABLE IF NOT EXISTS complaint_images (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  complaint_id INTEGER NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
  stored_name TEXT NOT NULL,
  original_name TEXT,
  caption TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_complaint_images ON complaint_images (complaint_id);
