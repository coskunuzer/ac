-- A sales person without a login (name + email only), like an assistant but
-- offered as the responsible person ("Person") of countries and customers.
ALTER TABLE users ADD COLUMN is_sales_contact INTEGER NOT NULL DEFAULT 0;
-- A person's own signature layout; empty = the company default.
ALTER TABLE users ADD COLUMN signature_style TEXT;

CREATE TABLE IF NOT EXISTS app_settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

-- Texts an admin can offer for the thank-you and the offer emails. One of each
-- kind is the default. Placeholders: {{greeting}} {{name}} {{company}} {{fair}}
-- {{person}} {{at_fair}} {{about_company}} {{for_company}}
CREATE TABLE IF NOT EXISTS email_templates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT NOT NULL CHECK (kind IN ('thank_you','offer')),
  name TEXT NOT NULL,
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  is_default INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

INSERT INTO email_templates (kind, name, subject, body, is_default) VALUES
('thank_you', 'Standard', 'Thank you for visiting TECE{{at_fair}}',
'{{greeting}}

Thank you for visiting our stand{{at_fair}}. It was a pleasure meeting you{{about_company}}.

We will follow up shortly with any further information you asked for. In the meantime, please do not hesitate to contact me if you have any questions.

Best wishes', 1),
('thank_you', 'Short and friendly', 'Great meeting you{{at_fair}}',
'{{greeting}}

Thank you for stopping by our stand{{at_fair}}. It was great to meet you!

I will be in touch soon. If you need anything in the meantime, just reply to this email.

Best wishes', 0),
('thank_you', 'Formal', 'Thank you for your visit to TECE{{at_fair}}',
'{{greeting}}

On behalf of TECE, thank you for visiting us{{at_fair}}. We appreciated the opportunity to meet you and to introduce our edgebanding range.

Our team will contact you shortly with the information you requested. Please feel free to contact me directly at any time.

Kind regards', 0),
('offer', 'Standard offer', 'Your TECE edgebanding offer{{for_company}}',
'{{greeting}}

Thank you for your interest in TECE edgebanding.

If you would like samples, or would like us to adjust anything in the offer, please let me know. I will be glad to help.

Best wishes', 1),
('offer', 'Short offer', 'TECE offer{{for_company}}',
'{{greeting}}

As promised, here is our offer.

Please let me know if you have any questions or would like samples.

Best wishes', 0),
('offer', 'Offer with next steps', 'Your TECE edgebanding offer{{for_company}}',
'{{greeting}}

Thank you for your interest in TECE edgebanding.

Once you have looked through the offer, I would be glad to arrange samples and answer any questions on prices, colours or delivery. A short call is often the quickest way: just tell me when suits you.

Best wishes', 0);
