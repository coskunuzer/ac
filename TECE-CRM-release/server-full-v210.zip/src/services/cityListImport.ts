import * as XLSX from 'xlsx';
import { db } from '../db/connection';
import { cityModel } from '../models/cityModel';
import { userModel } from '../models/userModel';
import { placeKey, resolveCity } from '../data/turkeyPlaces';
import { matchPerson } from './countryAssignment';

// The city list as Excel (columns Country, Continent, Sales Manager, Sales Manager Email, Assist, Assist Email, City): who looks after
// each city of Turkey. A city that is listed for two people has to be given to one of them - the person is chosen in the import
// (for Bursa and Kayseri the choice is already filled in). Customers of a city that changes hands, and that were with the
// previous person (or nobody), move to the new person; customers given to somebody else on purpose stay where they are.

const norm = (s: unknown) => String(s ?? '').replace(/\s+/g, ' ').trim();

// agreed choices for cities that are listed twice (the first name of the person)
export const PREFERRED: Record<string, string> = { bursa: 'Ahmet', kayseri: 'Kubilay' };

export interface CityImportReport {
  dryRun: boolean;
  rows: number;
  cities: number;
  perPerson: { person: string; cities: number }[];
  unmatched: string[];
  conflicts: { city: string; managers: string[]; chosen: string | null }[];
  changed: number;
  customersMoved: number;
}

export function importCityList(opts: { buffer: Buffer; dryRun: boolean; choices: Record<string, string> }): CityImportReport {
  const wb = XLSX.read(opts.buffer, { type: 'buffer' });
  const sheet = wb.Sheets[wb.SheetNames[0]];
  const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: '' });
  if (!rows.length || !('City' in rows[0]) || !('Sales Manager' in rows[0])) throw new Error('The first line of the sheet must have the columns "Sales Manager" and "City" (and "Assist").');

  const staff = userModel.listActive();
  const assistants = [...staff, ...userModel.listAssistants()];
  const unmatched = new Set<string>();
  const person = (raw: string, pool: typeof staff): string | null => {
    if (!raw) return null;
    const m = matchPerson(raw, pool);
    if (m.name) return m.name;
    unmatched.add(raw);
    return null;
  };

  // city -> the people it is listed for
  const byCity = new Map<string, { city: string; managers: { raw: string; name: string | null }[]; assistant: string | null }>();
  for (const r of rows) {
    const cityRaw = norm(r.City);
    const place = resolveCity(cityRaw);
    if (!place.city) continue;
    const k = placeKey(place.city);
    const e = byCity.get(k) ?? { city: place.city, managers: [], assistant: null };
    const raw = norm(r['Sales Manager']);
    if (raw && !e.managers.some((m) => m.raw === raw)) e.managers.push({ raw, name: person(raw, staff) });
    const a = norm(r.Assist);
    if (a && !e.assistant) e.assistant = person(a, assistants);
    byCity.set(k, e);
  }

  const report: CityImportReport = { dryRun: opts.dryRun, rows: rows.length, cities: byCity.size, perPerson: [], unmatched: [], conflicts: [], changed: 0, customersMoved: 0 };
  const count = new Map<string, number>();
  const toSave: { city: string; responsible: string | null; assistant: string | null }[] = [];
  for (const [k, e] of byCity) {
    let responsible: string | null = e.managers[0]?.name ?? null;
    if (e.managers.length > 1) {
      const want = opts.choices[e.city] ?? PREFERRED[k];
      // the person agreed for this city (it may be somebody who is not in the list for it at all)
      const inList = want ? e.managers.find((m) => m.name && (m.name === want || m.raw.toLowerCase().includes(want.toLowerCase()) || m.name.toLowerCase().includes(want.toLowerCase()))) : undefined;
      const chosen = inList?.name ?? (want ? matchPerson(want, staff).name : null);
      report.conflicts.push({ city: e.city, managers: e.managers.map((m) => m.name ?? m.raw), chosen });
      if (!chosen) continue; // nobody chosen: this city is left as it is
      responsible = chosen;
    }
    if (responsible) count.set(responsible, (count.get(responsible) ?? 0) + 1);
    toSave.push({ city: e.city, responsible, assistant: e.assistant });
  }
  report.perPerson = [...count.entries()].map(([p, cities]) => ({ person: p, cities })).sort((a, b) => b.cities - a.cities);
  report.unmatched = [...unmatched];

  for (const s of toSave) {
    const before = cityModel.findByCity(s.city);
    if ((before?.responsible ?? null) !== s.responsible || (before?.assistant ?? null) !== s.assistant) report.changed += 1;
    if (!s.responsible) continue;
    const old = before?.responsible ?? null;
    if (old !== s.responsible) {
      const where = `market = 'domestic' AND city = @city AND owner_override = 0 AND (person IS NULL OR TRIM(person) = ''${old ? ' OR person = @old' : ''})`;
      report.customersMoved += (db.prepare(`SELECT COUNT(*) AS n FROM cards WHERE ${where}`).get({ city: s.city, ...(old ? { old } : {}) }) as { n: number }).n;
      if (!opts.dryRun) db.prepare(`UPDATE cards SET person = @person WHERE ${where}`).run({ person: s.responsible, city: s.city, ...(old ? { old } : {}) });
    }
  }
  if (!opts.dryRun) cityModel.upsertMany(toSave);
  return report;
}
