import crypto from 'crypto';
import { db } from '../db/connection';
import { RULE_ADVICE, invoiceLines, LEVELS, type RiskInvoice, type RiskLevel } from './paymentRisk';
import { riskInputs, type Account } from './perfAnalytics';
import { askJson } from './perfActions';

// The AI's second opinion on how a customer pays (DeepSeek, through the AI gate). The rules in paymentRisk.ts always give the level; the AI
// reads the same figures, says what it sees in plain words and what to do. It may SUGGEST black, but only the rules or an admin make an account black.

export interface RiskAi { level: RiskLevel; headline: string; reasons: string[]; action: string; advance: string; ai: boolean; madeAt: string }

const SYMBOL: Record<string, string> = { EUR: '€', USD: '$' };
const money = (n: number, cur: string) => `${SYMBOL[cur] ?? `${cur} `}${Math.round(n).toLocaleString('en-US')}`;

export function riskInvoices(sap: string): RiskInvoice[] {
  const input = riskInputs.get(sap);
  return input ? invoiceLines(input).slice(0, 14) : [];
}

export function savedRiskAi(sap: string): RiskAi | null {
  const row = db.prepare('SELECT body, made_at FROM perf_risk_ai WHERE sap_no = ?').get(sap) as { body: string; made_at: string } | undefined;
  if (!row) return null;
  try { return { ...(JSON.parse(row.body) as RiskAi), madeAt: row.made_at }; } catch { return null; }
}

// what the AI looks at (and the key that tells whether the answer in the database is still current)
function facts(a: Account): string {
  const r = a.risk;
  const lines = riskInvoices(a.sap).map((i) => `${i.date}: ${money(i.amount, a.currency)}, ${i.paid ? `paid ${i.late > 0 ? `${i.late} days after the due date` : i.late === 0 ? 'on the due date' : `${-i.late} days before the due date`}` : `STILL UNPAID, ${i.late} days past due`}`);
  return [
    `Customer: ${a.name}${a.country ? `, ${a.country}` : ''}. Currency ${a.currency}. Payment terms: ${a.terms} days from the invoice date.`,
    `Invoiced: ${Object.entries(a.years).filter(([, v]) => v > 0).sort().slice(-4).map(([y, v]) => `${y}: ${money(v, a.currency)}`).join(', ') || 'nothing'}.`,
    `Open balance ${money(a.balance, a.currency)}; overdue ${money(a.overdue, a.currency)}; the oldest unpaid invoice is ${a.oldestOver} days past due. Last payment: ${a.lastPayment ?? 'unknown'}; last invoice: ${a.lastInvoice ?? 'unknown'}.`,
    `Rule score ${r.score}/100 (level by the rules: ${r.auto}). In the last 24 months ${r.lateN} of ${r.paidN} paid invoices were late; the amount-weighted delay in the last 12 months is ${r.avgLate} days; worst ${r.worstLate} days; trend ${r.trend ?? 'unknown'}.`,
    a.waitingValue > 0 || a.readyValue > 0 || a.backlogValue > 0 ? `Orders on the way: ${a.backlogValue ? `${money(a.backlogValue, 'EUR')} in production, ` : ''}${a.readyValue ? `${money(a.readyValue, a.currency)} ready to ship, ` : ''}${a.waitingValue ? `${money(a.waitingValue, a.currency)} waiting for confirmation` : ''}.` : 'No order is on the way.',
    lines.length ? `Latest invoices:\n${lines.join('\n')}` : 'No invoice history.',
  ].join('\n');
}
const hashOf = (a: Account) => crypto.createHash('sha1').update(`${a.risk.score}|${a.risk.auto}|${a.overdue}|${a.oldestOver}|${a.balance}|${a.risk.lateN}|${a.risk.paidN}|${a.risk.avgLate}`).digest('hex').slice(0, 16);

export const hasFreshRiskAi = (a: Account): boolean => {
  const row = db.prepare("SELECT data_hash FROM perf_risk_ai WHERE sap_no = ? AND made_at >= datetime('now', '-30 days')").get(a.sap) as { data_hash: string } | undefined;
  return !!row && row.data_hash === hashOf(a);
};

function ruleAnswer(a: Account): RiskAi {
  const level = a.risk.level;
  return {
    level, headline: level === 'good' ? 'Pays on time.' : level === 'watch' ? 'Pays a little late.' : level === 'risk' ? 'Often pays late.' : 'Pays very late: black account.',
    reasons: a.risk.reasons.slice(0, 4), action: RULE_ADVICE[level], advance: level === 'black' ? 'Ask for an advance payment or the overdue amount before the next order.' : level === 'risk' ? 'Consider a part advance (30%) on the next order.' : '', ai: false, madeAt: '',
  };
}

export async function assessRisk(a: Account, force = false): Promise<RiskAi> {
  if (!force && hasFreshRiskAi(a)) { const s = savedRiskAi(a.sap); if (s) return s; }
  const j = await askJson(
    [`You help the finance and sales team of TECE (a Turkish maker of edgebanding for furniture panels) judge how an export customer pays. Use ONLY the facts below; never invent numbers or events; say "possibly" when you infer.`,
      'Decide the level: "good" (pays on time), "watch" (sometimes late), "risk" (often late or something well past due), "black" (so late, or nothing paid, that a new order or a dispatch should be held until money arrives). Consider the size of the overdue amount compared with the yearly business, the trend, and whether the delays are one-off or a habit. A customer who pays a few days after the due date every time is normal, not black.',
      'Answer with: level; headline (one short sentence); reasons (2 to 4 short facts); action (one sentence: what the salesperson or finance should do now); advance (one short sentence about asking for an advance payment or a smaller credit limit, or empty when not needed). English.',
      facts(a)].join('\n\n'),
    { type: 'OBJECT', properties: { level: { type: 'STRING', enum: LEVELS }, headline: { type: 'STRING' }, reasons: { type: 'ARRAY', items: { type: 'STRING' } }, action: { type: 'STRING' }, advance: { type: 'STRING' } }, required: ['level', 'headline', 'action'] },
  );
  const lvl = String(j?.level ?? '').toLowerCase() as RiskLevel;
  if (!j || !LEVELS.includes(lvl) || !j.headline) return ruleAnswer(a);
  const list = (v: unknown) => (Array.isArray(v) ? v.map((x) => String(x).trim()).filter(Boolean).slice(0, 5) : []);
  const out: RiskAi = { level: lvl, headline: String(j.headline).trim(), reasons: list(j.reasons), action: String(j.action ?? '').trim(), advance: String(j.advance ?? '').trim(), ai: true, madeAt: '' };
  db.prepare("INSERT INTO perf_risk_ai (sap_no, body, data_hash, made_at) VALUES (?, ?, ?, datetime('now')) ON CONFLICT(sap_no) DO UPDATE SET body = excluded.body, data_hash = excluded.data_hash, made_at = excluded.made_at").run(a.sap, JSON.stringify(out), hashOf(a));
  return { ...out, madeAt: new Date().toISOString().slice(0, 16).replace('T', ' ') };
}
export { ruleAnswer as ruleRiskAnswer };
