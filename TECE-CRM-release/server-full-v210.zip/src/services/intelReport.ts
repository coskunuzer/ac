/* eslint-disable @typescript-eslint/no-explicit-any */
import type { Bundle } from './intelEngine';

// The sales intelligence report for the general manager, in Turkish, as an e-mail (tables and inline styles only, so every mail program shows it).
// Every number comes from the same analysis as the Sales intelligence page.

const NAVY = '#17243e', RED = '#8b1931', MUTE = '#6b7385', LINE = '#e0e3ea', GOOD = '#1f7a4d', BAD = '#b3261e';
const tr = (v: number, d = 0) => v.toLocaleString('tr-TR', { minimumFractionDigits: d, maximumFractionDigits: d });
const eur = (v: number) => { const a = Math.abs(v), s = v < 0 ? '-' : ''; return a >= 1e6 ? `${s}€${tr(a / 1e6, a >= 1e7 ? 1 : 2)} Mn` : a >= 1e3 ? `${s}€${tr(a / 1e3, a >= 1e5 ? 0 : 1)} bin` : `${s}€${tr(a)}`; };
const mtr = (v: number) => { const a = Math.abs(v); return a >= 1e6 ? `${tr(a / 1e6, a >= 1e7 ? 1 : 2)} Mn m` : a >= 1e3 ? `${tr(a / 1e3)} bin m` : `${tr(a)} m`; };
const pc = (p: number | null, d = 0) => (p === null ? '–' : `${p >= 0 ? '▲' : '▼'} %${tr(Math.abs(p), d)}`);
const pcol = (p: number | null) => (p === null ? MUTE : p >= 0 ? GOOD : BAD);
const chg = (a: number, b: number) => (b > 0 ? ((a - b) / b) * 100 : null);
const MONTHS = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
const ymTr = (ym: string) => `${MONTHS[+ym.slice(5, 7) - 1]} ${ym.slice(0, 4)}`;
const dmy = (d: string) => `${d.slice(8, 10)}.${d.slice(5, 7)}.${d.slice(0, 4)}`;
const esc = (s: any) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c] as string));
const sum = <T,>(a: T[], f: (x: T) => number) => a.reduce((s, x) => s + f(x), 0);

const bar = (p: number, color = NAVY) => `<table role="presentation" cellpadding="0" cellspacing="0" width="100%"><tr><td width="${Math.max(1, Math.min(100, p))}%" bgcolor="${color}" style="height:10px;font-size:0;line-height:0">&nbsp;</td><td style="font-size:0">&nbsp;</td></tr></table>`;
const h2 = (t: string) => `<tr><td style="padding:26px 28px 6px;font:700 17px Arial,Helvetica,sans-serif;color:${NAVY};border-top:1px solid ${LINE}">${esc(t)}</td></tr>`;
const para = (t: string) => `<tr><td style="padding:6px 28px;font:14px/1.55 Arial,Helvetica,sans-serif;color:#252525">${t}</td></tr>`;
const note = (t: string) => `<tr><td style="padding:4px 28px 6px;font:12px/1.5 Arial,Helvetica,sans-serif;color:${MUTE}">${t}</td></tr>`;
const tableRow = (cells: string[], head = false, align: string[] = []) => `<tr>${cells.map((c, i) => `<td align="${align[i] ?? 'left'}" style="padding:7px 8px;border-bottom:1px solid ${LINE};font:${head ? '700 11px' : '13px'} Arial,Helvetica,sans-serif;color:${head ? MUTE : '#252525'}${head ? ';text-transform:uppercase' : ''}">${c}</td>`).join('')}</tr>`;
const tbl = (rows: string) => `<tr><td style="padding:4px 20px"><table role="presentation" width="100%" cellpadding="0" cellspacing="0">${rows}</table></td></tr>`;
const kpis = (items: [string, string, string][]) => `<tr><td style="padding:10px 20px"><table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>${items.map(([l, v, d]) => `<td width="${Math.floor(100 / items.length)}%" valign="top" style="padding:0 8px"><div style="background:#f4f5f8;border-radius:10px;padding:12px 14px"><div style="font:12px Arial;color:${MUTE}">${esc(l)}</div><div style="font:700 22px Arial;color:${NAVY};margin:2px 0">${v}</div><div style="font:12px Arial;color:${MUTE}">${d}</div></div></td>`).join('')}</tr></table></td></tr>`;
const bullets = (items: string[]) => `<tr><td style="padding:4px 28px"><ul style="margin:0;padding-left:18px;font:14px/1.6 Arial,Helvetica,sans-serif;color:#252525">${items.map((i) => `<li style="margin-bottom:5px">${i}</li>`).join('')}</ul></td></tr>`;

export interface Report { subject: string; html: string; text: string }

export function renderReport(b: Bundle): Report {
  const D = b.D, D2 = b.D2, D3 = b.D3, YR: number[] = D.years;
  const L12 = 101, P12 = 100;
  const cube: number[][] = D.cube;
  const isGrp = (c: number) => D.cust[c][7] === 1;
  // customers and codes: last 12 whole months against the 12 before (TECE group companies left out)
  const C = new Map<number, { l: number; p: number; t: number; ml: number; mp: number }>(), M = new Map<number, { l: number; p: number; t: number }>();
  const yearTot: Record<number, number> = {};
  for (const r of cube) {
    const [y, c, m, e, , mt] = r; if (isGrp(c)) continue;
    const o = C.get(c) ?? { l: 0, p: 0, t: 0, ml: 0, mp: 0 }; const q = M.get(m) ?? { l: 0, p: 0, t: 0 };
    if (y === L12) { o.l += e; o.ml += mt; q.l += e; } else if (y === P12) { o.p += e; o.mp += mt; q.p += e; } else { o.t += e; q.t += e; yearTot[y] = (yearTot[y] || 0) + e; }
    C.set(c, o); M.set(m, q);
  }
  const L = sum([...C.values()], (x) => x.l), P = sum([...C.values()], (x) => x.p), Lm = sum([...C.values()], (x) => x.ml), Pm = sum([...C.values()], (x) => x.mp);
  const actL = [...C.values()].filter((x) => x.l > 0).length, actP = [...C.values()].filter((x) => x.p > 0).length;
  const cName = (c: number) => D.cust[c][0] as string;
  const byL = [...C].sort((a, c) => c[1].l - a[1].l);
  const share = (n: number) => (byL.slice(0, n).reduce((s, [, x]) => s + x.l, 0) / (L || 1)) * 100;
  const mv = [...C].map(([c, x]) => ({ c, d: x.l - x.p, ...x })).sort((a, c) => a.d - c.d);
  const down = mv.slice(0, 5), up = mv.slice(-5).reverse(), worst = mv[0];
  const exL = L - (worst ? C.get(worst.c)!.l : 0), exP = P - (worst ? C.get(worst.c)!.p : 0);
  // calendar view
  const lastYear = YR[YR.length - 1], cutYM: string = D.cut.slice(0, 7);
  const monthly: [string, number, number, number, number, number][] = D.monthly;
  const lastFullM = D.l12[1].slice(0, 7); // last whole month
  const ytdMonths = +lastFullM.slice(5, 7);
  const ytd = (y: number) => sum(monthly.filter((r) => +r[0].slice(0, 4) === y && +r[0].slice(5, 7) <= ytdMonths && r[1] < 10), (r) => r[3]);
  const ytdNow = ytd(+lastFullM.slice(0, 4)), ytdPrev = ytd(+lastFullM.slice(0, 4) - 1);
  const winL = [D.l12[0].slice(0, 7), D.l12[1].slice(0, 7)];
  const chL = [0, 0, 0]; for (const r of monthly) if (r[0] >= winL[0] && r[0] <= winL[1] && r[1] < 10) chL[r[1]] += r[3];
  const price = (L && Lm) ? L / Lm : 0;
  const statusOf = (c: number) => { const u = D.cust[c], days = Math.round((Date.parse(D.cut) - Date.parse(u[5])) / 864e5); return days > 365 ? 'lost' : days > 180 ? 'risk' : 'ok'; };
  const lost = [...C].filter(([c, x]) => statusOf(c) === 'lost' && x.t + x.l + x.p >= 15000).sort((a, c) => (c[1].t + c[1].l + c[1].p) - (a[1].t + a[1].l + a[1].p)).slice(0, 6);
  const risk = [...C].filter(([c, x]) => statusOf(c) === 'risk' && x.t + x.l + x.p >= 10000).sort((a, c) => (c[1].t + c[1].l + c[1].p) - (a[1].t + a[1].l + a[1].p)).slice(0, 5);
  const codes = [...M].sort((a, c) => c[1].l - a[1].l); let cum = 0, c80 = 0; const totalL = sum(codes, ([, x]) => x.l); for (const [i, [, x]] of codes.entries()) { cum += x.l; if (!c80 && cum >= totalL * 0.8) c80 = i + 1; }
  const mvC = [...M].map(([m, x]) => ({ m, d: x.l - x.p, ...x })).sort((a, c) => a.d - c.d);
  const mName = (m: number) => `${D.mat[m][0]} ${D.mat[m][1]}`;

  // kartela, pricing, forecast
  const K: any[] = D2.kart, kl = sum(K, (k) => k.l12), kp = sum(K, (k) => k.p12); let allL = 0; for (const g in D2.split) allL += D2.split[g].l12k + D2.split[g].l12c;
  const actK = K.filter((k) => k.l12 > 0).length, deadK = K.filter((k) => !k.l12 && !k.p12).length;
  const exK = sum(K.filter((k) => k.exp), (k) => k.l12), mqK = K.filter((k) => !k.exp);
  const sp = D2.split, pvc = sp['PVC'] ? sp['PVC'].l12k / ((sp['PVC'].l12k + sp['PVC'].l12c) || 1) * 100 : 0, abs = sp['ABS'] ? sp['ABS'].l12k / ((sp['ABS'].l12k + sp['ABS'].l12c) || 1) * 100 : 0;
  const segs: any[] = D2.pricing.segs; let pa = 0, pb = 0; for (const s of segs) if (s.prev) { pa += s.eur; pb += s.m2 * s.prev; }
  const pcust: any[] = D2.pricing.cust; const lowC = pcust.filter((c) => c.idx < 0.92), gapTot = sum(pcust.filter((c) => c.gap > 0), (c) => c.gap);
  const lowTop = [...pcust].filter((c) => c.eur >= 50000).sort((a, c) => a.idx - c.idx).slice(0, 5);
  const spread = (() => { const a = segs.map((s) => (s.p90 - s.p10) / s.p50).sort((x, y) => x - y); return a.length ? a[Math.floor(a.length / 2)] : 0; })();
  const F = D2.fc, fa = F.agg['All sales'], N = F.hist.length, f6 = sum(fa.f, (v: number) => v), f6ly = sum(fa.f.map((_: number, k: number) => fa.hist[N + k - 12] ?? 0), (v: number) => v);
  const T = D2.totals, BT = D2.btReorder;
  const due = D2.reorder.filter((r: any) => r.el / Math.max(1, r.med) >= 0.8 && r.el / Math.max(1, r.med) < 1.5 && r.n >= 8 && r.med <= 120).slice(0, 8);

  // stock and orders
  const S3 = D3, hasStock = !!S3;
  const free = hasStock ? S3.health.healthy + S3.health.heavy + S3.health.excess : 0;
  const lateN = hasStock ? S3.orders.filter((o: any[]) => o[13] > 0).length : 0;

  const today = new Date().toISOString().slice(0, 10);
  const subject = `TECE Satış İstihbarat Raporu – ${dmy(today)}`;
  const decNote = worst && worst.d < 0 && exP > 0 ? `${esc(cName(worst.c))} hariç tutulduğunda son 12 ay %${tr(Math.abs(chg(exL, exP) ?? 0), 1)} ${((chg(exL, exP) ?? 0) >= 0) ? 'artıştadır' : 'düşüştedir'} (hariç tutulmadan: %${tr(Math.abs(chg(L, P) ?? 0), 1)} ${(chg(L, P) ?? 0) >= 0 ? 'artış' : 'düşüş'}).` : '';

  // ---------------------------------------------------------------- the e-mail
  const rows: string[] = [];
  rows.push(`<tr><td style="background:${NAVY};padding:26px 28px"><div style="font:12px Arial;color:#aab4c8;letter-spacing:1px">TECE DEKOR</div><div style="font:700 24px Arial;color:#ffffff;margin-top:4px">Satış İstihbarat Raporu</div><div style="font:13px Arial;color:#cfd6e4;margin-top:6px">Veri dönemi: 2019 – ${dmy(D.cut)} · Son 12 ay: ${ymTr(winL[0])} – ${ymTr(winL[1])} · Hazırlanma: ${dmy(today)}</div></td></tr>`);
  rows.push(para(`Sayın Genel Müdürüm,<br>Satışların, müşterilerin, renk ve ürün kodlarının, fiyatların, stokun ve açık siparişlerin güncel durumunu aşağıda özetledim. Rakamlar SAP satış, stok ve sipariş raporlarından hesaplanmıştır; TECE grup şirketleri (Bulgaristan, Polonya, Türkiye) satışa dahil edilmemiştir.`));

  rows.push(h2('1. Yönetim özeti'));
  const sum_: string[] = [];
  sum_.push(`<b>Son 12 ayda satış ${eur(L)}</b>; bir önceki 12 aya göre <span style="color:${pcol(chg(L, P))}"><b>${pc(chg(L, P), 1)}</b></span> (${eur(P)}). Metre bazında ${mtr(Lm)} (<span style="color:${pcol(chg(Lm, Pm))}">${pc(chg(Lm, Pm), 1)}</span>).`);
  if (decNote) sum_.push(`Düşüşün ana nedeni <b>${esc(cName(worst.c))}</b>: ${eur(worst.p)} → ${eur(worst.l)} (${eur(worst.d)}). ${decNote}`);
  sum_.push(`${ymTr(`${lastFullM.slice(0, 4)}-01`).split(' ')[0]}–${MONTHS[ytdMonths - 1]} ${lastFullM.slice(0, 4)} döneminde satış ${eur(ytdNow)}; geçen yılın aynı dönemi ${eur(ytdPrev)} (<span style="color:${pcol(chg(ytdNow, ytdPrev))}">${pc(chg(ytdNow, ytdPrev), 1)}</span>).`);
  sum_.push(`İlk 10 müşteri satışın %${tr(share(10))}'ini, ilk müşteri %${tr(share(1))}'ini oluşturuyor; son 12 ayda ${actL} müşteri alım yaptı (bir önceki dönemde ${actP}).`);
  sum_.push(`Aynı ürünlerde ortalama satış fiyatı geçen yıla göre <span style="color:${pcol(pb ? chg(pa, pb) : null)}"><b>${pc(pb ? chg(pa, pb) : null, 1)}</b></span>; aynı ürün için müşteriler arası fiyat farkı tipik olarak %${tr(spread * 100)}.`);
  sum_.push(`Önümüzdeki 6 ay için satış tahmini <b>${eur(f6)}</b> (geçen yılın aynı dönemine göre ${pc(chg(f6, f6ly), 0)}).`);
  if (hasStock) sum_.push(`Kenar bandı stoğu ${mtr(S3.tot.all)}; açık siparişlerden sonra satışa serbest ${mtr(free)} (ortalama satışın yaklaşık ${tr(free / Math.max(1, Lm / 12) * 30)} günü). Açık siparişlerin %${tr(S3.ot.make / Math.max(1, S3.ot.pend) * 100)}'i henüz üretilmeyi bekliyor.`);
  rows.push(bullets(sum_));
  rows.push(kpis([['Son 12 ay satış', eur(L), `<span style="color:${pcol(chg(L, P))}">${pc(chg(L, P), 1)}</span>`], ['Aktif müşteri', String(actL), `önceki dönem ${actP}`], ['Satılan metre', mtr(Lm), 'son 12 ay'], ['Ort. fiyat', `€${tr(price, 3)}/m`, 'son 12 ay']]));

  rows.push(h2('2. Satış performansı'));
  const years = YR.map((y) => ({ y, v: yearTot[y] || 0 })); const mx = Math.max(...years.map((x) => x.v), 1);
  rows.push(tbl(tableRow(['Yıl', 'Satış', ''], true, ['left', 'right', 'left']) + years.map((x) => tableRow([`${x.y}${x.y === lastYear ? ' (yıl başından beri)' : ''}`, `<b>${eur(x.v)}</b>`, bar(x.v / mx * 100, x.y === lastYear ? RED : NAVY)], false, ['left', 'right', 'left'])).join('')));
  rows.push(note(`Son 12 ayın dağılımı: İhracat ${eur(chL[0])} (%${tr(chL[0] / Math.max(1, chL[0] + chL[1] + chL[2]) * 100)}), yurt içi ${eur(chL[1])} (%${tr(chL[1] / Math.max(1, chL[0] + chL[1] + chL[2]) * 100)}).`));

  rows.push(h2('3. Müşteriler'));
  rows.push(para('<b>En büyük 10 müşteri (son 12 ay)</b>'));
  rows.push(tbl(tableRow(['Müşteri', 'Son 12 ay', 'Önceki 12 ay', 'Değişim'], true, ['left', 'right', 'right', 'right']) + byL.slice(0, 10).map(([c, x]) => tableRow([esc(cName(c)), `<b>${eur(x.l)}</b>`, eur(x.p), `<span style="color:${pcol(chg(x.l, x.p))}">${pc(chg(x.l, x.p))}</span>`], false, ['left', 'right', 'right', 'right'])).join('')));
  rows.push(para('<b>En çok düşen ve en çok artan müşteriler</b> (euro olarak değişim)'));
  rows.push(tbl(tableRow(['Düşenler', 'Değişim', 'Artanlar', 'Değişim'], true, ['left', 'right', 'left', 'right']) + down.map((d, i) => tableRow([esc(cName(d.c)), `<span style="color:${BAD}"><b>${eur(d.d)}</b></span>`, esc(cName(up[i].c)), `<span style="color:${GOOD}"><b>${eur(up[i].d)}</b></span>`], false, ['left', 'right', 'left', 'right'])).join('')));
  if (lost.length) { rows.push(para('<b>Geri kazanılabilecek eski büyük müşteriler</b> (12 aydan uzun süredir alım yok)')); rows.push(tbl(tableRow(['Müşteri', '2019’dan beri satış', 'Son alım'], true, ['left', 'right', 'right']) + lost.map(([c, x]) => tableRow([esc(cName(c)), `<b>${eur(x.t + x.l + x.p)}</b>`, dmy(D.cust[c][5])], false, ['left', 'right', 'right'])).join(''))); }
  if (risk.length) rows.push(note(`Sessizleşenler (6–12 aydır alım yok): ${risk.map(([c, x]) => `${esc(cName(c))} (2019’dan beri toplam ${eur(x.t + x.l + x.p)})`).join(', ')}.`));

  rows.push(h2('4. Renk ve ürün kodları'));
  rows.push(para(`Son 12 ayda ${codes.filter(([, x]) => x.l > 0).length.toLocaleString('tr-TR')} farklı kod satıldı; satışın %80'ini <b>${tr(c80)}</b> kod oluşturuyor.`));
  rows.push(tbl(tableRow(['En çok satan kodlar', 'Son 12 ay', 'Değişim'], true, ['left', 'right', 'right']) + codes.slice(0, 10).map(([m, x]) => tableRow([esc(mName(m)), `<b>${eur(x.l)}</b>`, `<span style="color:${pcol(chg(x.l, x.p))}">${pc(chg(x.l, x.p))}</span>`], false, ['left', 'right', 'right'])).join('')));
  rows.push(tbl(tableRow(['Düşen kodlar', 'Değişim', 'Yükselen kodlar', 'Değişim'], true, ['left', 'right', 'left', 'right']) + [0, 1, 2, 3, 4].map((i) => tableRow([esc(mName(mvC[i].m)), `<span style="color:${BAD}">${eur(mvC[i].d)}</span>`, esc(mName(mvC[mvC.length - 1 - i].m)), `<span style="color:${GOOD}">${eur(mvC[mvC.length - 1 - i].d)}</span>`], false, ['left', 'right', 'left', 'right'])).join('')));
  rows.push(h2('5. Kartela'));
  rows.push(bullets([
    `Kartelada ${K.length} kod var; bunların ${actK} tanesi (%${tr(actK / Math.max(1, K.length) * 100)}) son 12 ayda satıldı, ${deadK} kodun son 24 ayda hiç satışı yok.`,
    `Kartela kodları son 12 ayda ${eur(kl)} satış yaptı (toplam satışın %${tr(kl / Math.max(1, allL) * 100)}'i; geçen döneme göre ${pc(chg(kl, kp))}). PVC satışının yalnızca %${tr(pvc)}'i, ABS satışının %${tr(abs)}'i kartela kodlarından geliyor; gerisi müşteriye özel renkler.`,
    `Stoktan hızlı çıkan (express) ${K.filter((k) => k.exp).length} kod kartela satışının %${tr(exK / Math.max(1, kl) * 100)}'ini yapıyor; sipariş üzerine üretilen (MOQ) ${mqK.length} kodun satışı kod başına ortalama ${eur(sum(mqK, (k) => k.l12) / Math.max(1, mqK.length))}.`,
    `Müşteriye özel renkler, aynı kalınlık ve yüzeyde kartela renklerinden yalnızca %${tr(D2.pricing.stdVsCustom * 100, 1)} pahalı satılıyor: özel renk eşleştirme işi fiyata yansımıyor.`,
  ]));
  if (D2.cands.length) rows.push(note(`Kartelada olmayan ama birden çok müşteriye satılan renkler (kartelaya alınabilir): ${D2.cands.slice(0, 5).map((c: any) => `${c.code} ${esc(c.desc)} (${eur(c.l12)}, ${c.b12} müşteri)`).join('; ')}.`));

  rows.push(h2('6. Fiyatlandırma'));
  rows.push(bullets([
    `Aynı ürünlerde (kenar bandı; malzeme, kalınlık, yüzey ve genişlik aynı) ortalama fiyat geçen yıla göre <b style="color:${pcol(pb ? chg(pa, pb) : null)}">${pc(pb ? chg(pa, pb) : null, 1)}</b>.`,
    `Aynı ürünü alan müşteriler arasında en ucuz %10 ile en pahalı %10 arasındaki fark tipik olarak %${tr(spread * 100)}.`,
    `${lowC.length} müşteri, aynı ürün karışımı için medyan fiyatın %8 veya daha altında ödüyor (${eur(sum(lowC, (c: any) => c.eur))} satış). Bu müşteriler medyan fiyattan alsalardı yıllık yaklaşık ${eur(gapTot)} daha fazla gelir olurdu. Hacim iskontosu gibi haklı nedenler olabilir; bu bir inceleme listesidir.`,
  ]));
  if (lowTop.length) rows.push(tbl(tableRow(['Medyanın altında ödeyen büyük müşteriler', 'Satış', 'Fiyat farkı'], true, ['left', 'right', 'right']) + lowTop.map((c: any) => tableRow([esc(c.name), eur(c.eur), `<span style="color:${BAD}"><b>${c.idx < 1 ? '-' : '+'}%${tr(Math.abs((c.idx - 1) * 100), 1)}</b></span>`], false, ['left', 'right', 'right'])).join('')));

  rows.push(h2('7. Tahmin'));
  rows.push(tbl(tableRow(['Ay', 'Tahmin', 'Olası aralık', 'Geçen yıl aynı ay'], true, ['left', 'right', 'right', 'right']) + F.months.map((m: string, k: number) => tableRow([ymTr(m), `<b>${eur(fa.f[k])}</b>`, `${eur(fa.lo[k])} – ${eur(fa.hi[k])}`, eur(fa.hist[N + k - 12] ?? 0)], false, ['left', 'right', 'right', 'right'])).join('')));
  rows.push(note(`Önümüzdeki 6 ay toplamı ${eur(f6)}. Doğrulama: model geçmiş aylarda denendiğinde 3 aylık toplamlarda ortalama %${tr(fa.wape * 100)} sapma verdi. Tahmin bir söz değil, bir aralıktır.`));
  rows.push(para(`<b>Müşteri sipariş ritmine göre önümüzdeki 90 gün:</b> yaklaşık ${eur(T.e90)} (30 gün: ${eur(T.e30)}, 60 gün: ${eur(T.e60)}), düzenli sipariş veren ${T.n} müşteriden. Modelin daha önce görmediği aylarda toplam tahmini ${eur(BT.cal)} iken gerçekleşen ${eur(BT.act)} oldu (her 90 günlük pencerede ortalama %${tr(BT.mae, 1)} sapma). Yeni müşteriler bu toplamın üstüne eklenir.`));
  if (due.length) rows.push(note(`Sipariş zamanı gelen düzenli müşteriler: ${due.map((r: any) => `${esc(r.name)} (olağan aralık ${r.med} gün, ${r.el} gündür sessiz)`).join('; ')}.`));

  if (hasStock) {
    const H = S3.health, O = S3.ot, tot = S3.tot;
    rows.push(h2('8. Stok ve açık siparişler (kenar bandı)'));
    rows.push(kpis([['Toplam stok', mtr(tot.all), 'tüm depolar'], ['Satışa serbest', mtr(free), 'açık siparişlerden sonra'], ['Sağlıklı', `%${tr(H.healthy / Math.max(1, free) * 100)}`, `~${eur(H.eurH)}`], ['Fazla / satılmayan', `%${tr(H.excess / Math.max(1, free) * 100)}`, `~${eur(H.eurE)}`]]));
    rows.push(bullets([
      `Stokun %${tr(tot.byDc.count / Math.max(1, tot.all) * 100)}'i (${mtr(tot.byDc.count)}) sayım deposunda görünüyor; fiziksel olarak doğrulanana kadar kullanılabilir stok sayılmadı.`,
      `Serbest stokun %${tr((H.age[3] + H.age[4]) / Math.max(1, free) * 100)}'i bir yıldan eski; %${tr(H.age[4] / Math.max(1, free) * 100)}'i iki yıldan eski.`,
      `Müşteri adına ayrılmış ama açık siparişi kalmamış stok: ${mtr(tot.stranded)}. En büyükleri: ${S3.strand.slice(0, 4).map((s: any) => `${esc(s.name)} (${mtr(s.q)})`).join(', ')}.`,
      `Açık siparişler (ZSD0013, kenar bandı): ${mtr(O.pend)}, ${O.lines.toLocaleString('tr-TR')} kalem. Bunun %${tr(O.ready / Math.max(1, O.pend) * 100)}'i hemen sevk edilebilir, %${tr(O.cut / Math.max(1, O.pend) * 100)}'i üretilmiş ve kesim bölümünde, %${tr(O.other / Math.max(1, O.pend) * 100)}'i başka stoktan karşılanabilir, <b>%${tr(O.make / Math.max(1, O.pend) * 100)}'i (${mtr(O.make)}) henüz üretilmeli</b>.`,
      `${lateN.toLocaleString('tr-TR')} sipariş kaleminin (%${tr(lateN / Math.max(1, S3.orders.length) * 100, 1)}) siparişte yazan teslim tarihi geçmiş durumda.`,
    ]));
    if (S3.gap?.length) rows.push(tbl(tableRow(['Önce üretilmesi gerekenler', 'Ölçü', 'Üretilecek'], true, ['left', 'left', 'right']) + S3.gap.slice(0, 8).map((g: any) => tableRow([`${esc(g.desc)} <span style="color:${MUTE}">${g.mat}</span>`, `${g.th} × ${g.w} mm`, `<b>${mtr(g.make)}</b>`], false, ['left', 'left', 'right'])).join('')));
    rows.push(note('Sayım deposu, kesim bölümü ve sevkiyat deposu eşlemesi SAP depo kodlarına göre yapılmıştır (3000/3001 sevkiyat, 2003 kesim, 9500 sayım).'));
  }

  rows.push(h2(`${hasStock ? 9 : 8}. Dikkat edilmesi gerekenler`));
  const act: string[] = [];
  if (worst && worst.d < 0) act.push(`<b>${esc(cName(worst.c))}</b> ile görüşülmeli: son 12 ayda ${eur(worst.d)} düşüş. Sipariş başka bir kod veya firma üzerinden mi akıyor, kontrol edilmeli.`);
  if (lost.length) act.push(`Eski büyük müşterilerden geri kazanım çalışması: ${lost.slice(0, 3).map(([c]) => esc(cName(c)).replace(/\.+$/, '')).join(', ')}.`);
  if (lowC.length) act.push(`${lowC.length} müşterinin fiyat seviyesi gözden geçirilmeli (medyanın %8 altı); yıllık fark yaklaşık ${eur(gapTot)}.`);
  if (hasStock) { act.push(`Sayım deposundaki ${mtr(S3.tot.byDc.count)} stok fiziksel olarak sayılıp doğrulanmalı.`); act.push(`Açık siparişi kalmamış müşteri stoğu (${mtr(S3.tot.stranded)}) SAP’de serbest bırakılmalı veya müşteriyle konuşulmalı; ${mtr(S3.health.excess)} fazla/satılmayan serbest stok için eritme planı yapılmalı.`); act.push(`Üretim planı: açık siparişlerin %${tr(S3.ot.make / Math.max(1, S3.ot.pend) * 100)}'i üretim bekliyor ve neredeyse tamamının teslim tarihi geçmiş durumda.`); act.push(`CRM: satış yapan, stok tutan veya açık siparişi olan ${S3.link.relevant} hesabın ${S3.link.notConnected}'si CRM müşteri kartına bağlı değil (son 12 ay satışın %${tr(S3.link.l12Unlinked / Math.max(1, S3.link.l12All) * 100)}'i); önce bunlar bağlanmalı.`); }
  rows.push(bullets(act));

  rows.push(h2('Veri notları'));
  rows.push(note(`Kaynak: SAP ZSD0005 satış listesi (2019 – ${dmy(D.cut)}), kartela dosyası, ZMM0006 stok raporu ve ZSD0013 açık siparişler. Ticaret şirketine (TEZER) kesilen iç mahsup faturaları çift sayımı önlemek için dışarıda bırakıldı. Tutarlar SAP’nin fatura tarihindeki kuruyla çevrilmiş net euro’dur. Son 12 ay, tam aylar olarak alınmıştır (${ymTr(winL[0])} – ${ymTr(winL[1])}); devam eden ay yıl başından beri rakamlarda yer alır.`));
  rows.push(`<tr><td style="padding:18px 28px 28px;font:12px Arial;color:${MUTE};border-top:1px solid ${LINE}">Saygılarımla,<br><br>Bu rapor TECE CRM Satış İstihbaratı modülünden otomatik hazırlanmıştır.</td></tr>`);

  const html = `<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(subject)}</title></head><body style="margin:0;background:#eef0f5"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#eef0f5"><tr><td align="center" style="padding:18px 8px"><table role="presentation" width="720" cellpadding="0" cellspacing="0" style="max-width:720px;width:100%;background:#ffffff;border-radius:12px;overflow:hidden">${rows.join('')}</table></td></tr></table></body></html>`;
  const text = [subject, '', ...sum_.map((s) => '- ' + s.replace(/<[^>]+>/g, '').replace(/&amp;/g, '&')), '', 'Ayrıntılar için e-postanın HTML sürümüne bakınız.'].join('\n');
  return { subject, html, text };
}
