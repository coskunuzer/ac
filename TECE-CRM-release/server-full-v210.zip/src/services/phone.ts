import { parsePhoneNumberFromString, type CountryCode } from 'libphonenumber-js/max';
import countries from 'i18n-iso-countries';
import en from 'i18n-iso-countries/langs/en.json';
import { countryKey } from '../models/countryModel';
import { COUNTRY_NAMES } from '../data/countries';
import type { CardRow } from '../models/cardModel';

countries.registerLocale(en);

// ISO code of a country as this app spells it (the first spelling that the library knows).
const SPECIAL: Record<string, string> = { turkey: 'TR', 'united kingdom': 'GB', 'united states': 'US', 'south korea': 'KR', 'north korea': 'KP', russia: 'RU', 'dr congo': 'CD', 'ivory coast': 'CI', kosovo: 'XK', vietnam: 'VN', syria: 'SY', iran: 'IR', bolivia: 'BO', venezuela: 'VE', tanzania: 'TZ', moldova: 'MD', laos: 'LA', brunei: 'BN', czechia: 'CZ', 'north macedonia': 'MK', palestine: 'PS', taiwan: 'TW', eswatini: 'SZ' };
export function isoOf(country: string | null | undefined): string | null {
  if (!country || !country.trim()) return null;
  const key = countryKey(country);
  if (SPECIAL[key]) return SPECIAL[key];
  return countries.getAlpha2Code(country.trim(), 'en') ?? COUNTRY_NAMES.map((n) => [n, countries.getAlpha2Code(n, 'en')] as const).find(([n, c]) => c && countryKey(n) === key)?.[1] ?? null;
}

export interface PhoneInfo {
  // +9715681259399: the number with + and its country code
  e164: string | null;
  kind: 'mobile' | 'fixed' | 'other' | 'invalid';
  // the number was written without a country code and the country of the customer was used
  guessed: boolean;
}

const MOBILE_TYPES = new Set(['MOBILE', 'FIXED_LINE_OR_MOBILE']);

// One number, in the way the customer's country writes it: checked, with its country code, and what kind of number it is.
export function analysePhone(raw: string | null | undefined, country: string | null | undefined): PhoneInfo {
  const text = String(raw ?? '').trim();
  if (!text) return { e164: null, kind: 'invalid', guessed: false };
  const iso = isoOf(country) as CountryCode | null;
  const plus = text.startsWith('+') || text.startsWith('00');
  const p = parsePhoneNumberFromString(text.startsWith('00') ? `+${text.slice(2)}` : text, iso ?? undefined);
  if (!p || !p.isValid()) return { e164: null, kind: 'invalid', guessed: false };
  const type = p.getType();
  return { e164: p.number, kind: type && MOBILE_TYPES.has(type) ? 'mobile' : type === 'FIXED_LINE' ? 'fixed' : 'other', guessed: !plus };
}

// A field can hold several numbers ("0212 555 1234 / 0532 111 2233"): each one on its own.
export const splitNumbers = (raw: string | null | undefined): string[] => String(raw ?? '').split(/\s*(?:\/|;|,|\|| - | ve | and )\s*/i).map((s) => s.trim()).filter((s) => s.replace(/\D/g, '').length >= 5);

// What is typed in a phone field, tidied: every number that is valid is written with + and its country code; the others stay as they were typed.
export function tidyPhones(raw: string | null | undefined, country: string | null | undefined): string | null {
  const nums = splitNumbers(raw);
  if (!nums.length) return String(raw ?? '').trim() || null;
  return nums.map((n) => analysePhone(n, country).e164 ?? n).filter((v, i, a) => a.indexOf(v) === i).join(' / ');
}

// ---- WhatsApp -----------------------------------------------------------------------------------------------------------
const HELLO: Record<string, string> = {
  en: 'Hello {name}, this is {user} from TECE, the edgebanding company.',
  tr: 'Merhaba {name}, ben TECE kenar bandı şirketinden {user}.',
  ru: 'Здравствуйте, {name}! Это {user} из компании TECE, производителя кромочной ленты.',
  es: 'Hola {name}, soy {user} de TECE, la empresa de cantos.',
  fr: "Bonjour {name}, ici {user} de TECE, l'entreprise de chants.",
};

// The mobile number to write to: the mobile field, or - when only a telephone is written - a number that turns out to be a mobile.
export function whatsappNumber(card: Pick<CardRow, 'mobile' | 'tel' | 'country'>): { e164: string | null; problem: string | null } {
  const country = card.country;
  for (const raw of [...splitNumbers(card.mobile), ...splitNumbers(card.tel)]) {
    const a = analysePhone(raw, country);
    if (a.e164 && a.kind === 'mobile') return { e164: a.e164, problem: null };
  }
  const any = [...splitNumbers(card.mobile), ...splitNumbers(card.tel)];
  if (!any.length) return { e164: null, problem: null };
  const first = analysePhone(any[0], country);
  return { e164: null, problem: first.e164 ? 'This number is not a mobile' : 'This number is not valid (check the country code)' };
}

// https://wa.me/<number>?text=<hello in the language of the customer>
export function whatsappLink(card: Pick<CardRow, 'mobile' | 'tel' | 'country' | 'name' | 'company' | 'language'>, userName: string): { url: string | null; problem: string | null } {
  const n = whatsappNumber(card);
  if (!n.e164) return { url: null, problem: n.problem };
  const first = (card.name ?? '').trim().split(/\s+/)[0] || (card.company ?? '').trim() || '';
  const lang = card.language && HELLO[card.language] ? card.language : 'en';
  const text = HELLO[lang].replace('{name}', first || (lang === 'tr' ? 'efendim' : '')).replace('{user}', userName).replace(/\s+,/g, ',').replace(/\s{2,}/g, ' ');
  return { url: `https://wa.me/${n.e164.slice(1)}?text=${encodeURIComponent(text)}`, problem: null };
}
