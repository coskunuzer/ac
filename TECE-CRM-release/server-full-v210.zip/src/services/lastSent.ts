import { db } from '../db/connection';

// "Statement sent 2 days ago by Sena": the last real e-mail of a kind (statement, offer, proforma ...) to a customer, by SAP number or by customer record. Used wherever a reminder
// is shown (radar, receivables table, customer page, Home), so nobody chases the same customer twice by accident. Test sends are never recorded, so they never show.
export interface SentInfo { at: string; days: number; by: string | null; to: string | null }

const row = (r: { sent_at: string; by: string | null; to_addr: string | null }): SentInfo => ({
  at: r.sent_at, by: r.by, to: r.to_addr, days: Math.max(0, Math.floor((Date.now() - new Date(`${r.sent_at.replace(' ', 'T')}Z`).getTime()) / 86_400_000)),
});

export function lastSent(kind: string, key: { sap?: string | null; cardId?: number | null }): SentInfo | null {
  const sap = (key.sap ?? '').trim(); const cardId = key.cardId ?? null;
  if (!sap && cardId === null) return null;
  const r = db.prepare(`SELECT s.sent_at, s.to_addr, u.display_name AS by FROM sent_emails s LEFT JOIN users u ON u.id = s.user_id
    WHERE s.kind = ? AND ((? != '' AND s.sap = ?) OR (? IS NOT NULL AND s.card_id = ?)) ORDER BY s.id DESC LIMIT 1`).get(kind, sap, sap, cardId, cardId) as { sent_at: string; by: string | null; to_addr: string | null } | undefined;
  return r ? row(r) : null;
}

// for a whole list at once: key "sap:123" or "card:45" -> the last one
export function lastSentMap(kind: string, days = 120): Map<string, SentInfo> {
  const out = new Map<string, SentInfo>();
  const rows = db.prepare(`SELECT s.sap, s.card_id, s.sent_at, s.to_addr, u.display_name AS by FROM sent_emails s LEFT JOIN users u ON u.id = s.user_id
    WHERE s.kind = ? AND s.sent_at >= datetime('now', ?) ORDER BY s.id ASC`).all(kind, `-${days} day`) as { sap: string | null; card_id: number | null; sent_at: string; to_addr: string | null; by: string | null }[];
  for (const r of rows) { const info = row(r); if (r.sap) out.set(`sap:${r.sap.trim()}`, info); if (r.card_id) out.set(`card:${r.card_id}`, info); }
  return out;
}
