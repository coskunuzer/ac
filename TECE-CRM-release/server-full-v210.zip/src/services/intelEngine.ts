/* eslint-disable @typescript-eslint/no-explicit-any */
import { db } from '../db/connection';
import { countryMap, continentOf } from './intelCountry';
import { adjustedMonths, excludedCodes, listExcluded } from './intelExclude';

// Sales intelligence: everything that is worked out from the SAP sales list, the kartela, the edge band stock and the open orders (ZSD0013), and
// tied to the CRM customers by the SAP number. The result is one JSON bundle that the page and the report both read; it is kept in intel_cache
// and rebuilt when a file is uploaded.

const r0 = Math.round, r1 = (v: number) => Math.round(v * 10) / 10, r3 = (v: number) => Math.round(v * 1000) / 1000;
const dayNum = (() => { const c = new Map<string, number>(); return (s: string): number => { let v = c.get(s); if (v === undefined) { v = Math.floor(Date.UTC(+s.slice(0, 4), +s.slice(5, 7) - 1, +s.slice(8, 10)) / 864e5); c.set(s, v); } return v; }; })();
const days = (a: string, b: string) => dayNum(b) - dayNum(a);
const addDays = (d: string, n: number) => new Date((dayNum(d) + n) * 864e5).toISOString().slice(0, 10);
const sum = <T,>(a: T[], f: (x: T) => number) => a.reduce((s, x) => s + f(x), 0);
const mode = (o: Record<string, number>) => Object.entries(o).sort((a, b) => b[1] - a[1])[0]?.[0] ?? '';
const GROUPCOS = /TECE\s*DE[CK]|TEZER/i;
const OWN = '1201999999'; // TECE DEKOR A.Ş. as the owner of free stock

// one row of the summary, shaped like an invoice line: d is the first day of its month (or of its year for the old years)
export interface Line { per?: string; d: string; so: string; ret: number; cust: string; cname: string; mat: string; desc: string; w: number; th: number; m: number; m2: number; kg: number; eur: number; grp: string; typ: string; fin: string; region: string; city: string; rep: string; reason: string }

export function loadLines(): Line[] {
  const rows = db.prepare(`SELECT f.period, f.doc_type, f.customer cust, c.name cname, f.material mat, m.descr, f.width w, f.thickness th, f.meters m, f.m2, f.kg, f.eur, m.grp, m.typ, m.fin, c.region, c.city, c.rep, f.reason
    FROM intel_fact f LEFT JOIN intel_cust c ON c.code = f.customer LEFT JOIN intel_mat m ON m.code = f.material
    WHERE f.customer NOT IN (SELECT code FROM intel_excluded)`).all() as any[]; // an account marked "not a customer" is left out of everything
  return rows.map((x) => ({ per: x.period as string, d: x.period.endsWith('-00') ? `${x.period.slice(0, 4)}-01-01` : `${x.period}-01`, so: '', ret: x.doc_type === 'R' ? 1 : 0, cust: x.cust, cname: x.cname ?? '', mat: x.mat, desc: x.descr ?? '', w: x.w ?? 0, th: x.th ?? 0, m: x.m ?? 0, m2: x.m2 ?? 0, kg: x.kg ?? 0, eur: x.eur ?? 0, grp: x.grp ?? '', typ: x.typ ?? '', fin: x.fin ?? '', region: x.region ?? '', city: x.city ?? '', rep: x.rep ?? '', reason: x.reason ?? '' }));
}

export interface Win { cut: string; lastFull: string; L12S: string; L12E: string; P12S: string }
const monthStart = (ym: string) => `${ym}-01`;
const monthsBack = (ym: string, n: number): string => { let y = +ym.slice(0, 4), m = +ym.slice(5, 7) - n; while (m < 1) { m += 12; y--; } return `${y}-${String(m).padStart(2, '0')}`; };
const monthEnd = (ym: string) => new Date(Date.UTC(+ym.slice(0, 4), +ym.slice(5, 7), 0)).toISOString().slice(0, 10);
// the last 12 whole months against the 12 before; the month that is still running counts in the year to date only
export function windows(): Win {
  const cut = ((db.prepare('SELECT MAX(last_date) d FROM intel_cust').get() as any).d as string) || new Date().toISOString().slice(0, 10);
  const lastFull = cut === monthEnd(cut.slice(0, 7)) ? cut.slice(0, 7) : monthsBack(cut.slice(0, 7), 1);
  const L12 = monthsBack(lastFull, 11);
  return { cut, lastFull, L12S: monthStart(L12), L12E: monthEnd(lastFull), P12S: monthStart(monthsBack(L12, 12)) };
}

// ---------------------------------------------------------------- 1. sales dashboard data
function buildSales(L: Line[], W: Win) {
  const { cut, L12S, L12E, P12S } = W;
  const y0 = +L.reduce((m, x) => (x.d < m ? x.d : m), cut).slice(0, 4), y1 = +cut.slice(0, 4);
  const YEARS: number[] = []; for (let y = y0; y <= y1; y++) YEARS.push(y);
  const CM = countryMap();
  const dimC = new Map<string, any>((db.prepare('SELECT code, name, region, city, rep, first_date, last_date FROM intel_cust').all() as any[]).map((r) => [r.code, r]));
  const eurBy = new Map<string, number>(); for (const x of L) eurBy.set(x.cust, (eurBy.get(x.cust) || 0) + x.eur);
  const custs = [...eurBy.keys()].sort((a, b) => eurBy.get(b)! - eurBy.get(a)!).map((code, i) => { const c = dimC.get(code) ?? {}; const name = c.name || ''; return { i, code, name, region: c.region || '', city: c.city || '', rep: c.rep || '', first: c.first_date || '', last: c.last_date || '', ch: code.startsWith('1202') ? 0 : code.startsWith('1201') ? 1 : 2, grp: GROUPCOS.test(name) ? 1 : 0, ctry: CM.get(code) ?? { country: '', continent: '', src: 'none' as const } }; });
  const cidx = new Map(custs.map((c) => [c.code, c.i]));
  const dimM = new Map<string, any>((db.prepare('SELECT code, descr, grp, typ FROM intel_mat').all() as any[]).map((r) => [r.code, r]));
  const meurBy = new Map<string, number>(); for (const x of L) meurBy.set(x.mat, (meurBy.get(x.mat) || 0) + x.eur);
  const gt: Record<string, number> = {};
  const mats = [...meurBy.keys()].sort((a, b) => meurBy.get(b)! - meurBy.get(a)!).map((code, i) => { const m = dimM.get(code) ?? {}; return { i, code, desc: m.descr || '', grp: m.grp || 'Other', type: m.typ || '', fam: code.split('.')[1] || '' }; });
  const midx = new Map(mats.map((m) => [m.code, m.i]));
  for (const x of L) { const g = mats[midx.get(x.mat)!].grp; gt[g] = (gt[g] || 0) + x.eur; }
  const topG = Object.entries(gt).filter(([g]) => g !== 'Other').sort((a, b) => b[1] - a[1]).slice(0, 7).map((e) => e[0]);
  const dg = (g: string) => (topG.includes(g) ? g : 'Other');
  const groups = [...topG, 'Other']; const gidx = new Map(groups.map((g, i) => [g, i]));
  const reasons = [...new Set(L.filter((l) => l.ret).map((l) => l.reason || 'Unspecified'))];
  const per = (d: string) => (d >= L12S && d <= L12E ? 101 : d >= P12S && d < L12S ? 100 : 0);
  const cm = new Map<string, any[]>(); // customer x month x product group, for any period the person picks (the months that are kept per customer)
  const cube = new Map<string, any>(), monthly = new Map<string, any>(), rets = new Map<string, any>(), spec = new Map<string, any>(), regs = new Map<string, any>();
  const add = (y: number, c: number, m: number, x: Line) => { const k = y + '|' + c + '|' + m; let o = cube.get(k); if (!o) { o = [y, c, m, 0, 0, 0]; cube.set(k, o); } o[3] += x.eur; o[4] += x.m2; o[5] += x.m; };
  for (const x of L) {
    const c = cidx.get(x.cust)!, m = midx.get(x.mat)!, y = +x.d.slice(0, 4);
    add(y, c, m, x); const p = per(x.d); if (p) add(p, c, m, x);
    if (x.per && !x.per.endsWith('-00')) { const gi = gidx.get(dg(mats[m].grp))!; const ck = x.per + '|' + c + '|' + gi; let q = cm.get(ck); if (!q) { q = [x.per, c, gi, 0, 0, 0]; cm.set(ck, q); } q[3] += x.eur; q[4] += x.m2; q[5] += x.m; }
    const ch = custs[c].ch + (custs[c].grp ? 10 : 0);
    if (x.ret) { const ri = reasons.indexOf(x.reason || 'Unspecified'); const rk = y + '|' + c + '|' + m + '|' + ri; let q = rets.get(rk); if (!q) { q = [y, c, m, ri, 0, 0]; rets.set(rk, q); } q[4] += x.eur; q[5] += x.m2; }
    if (x.region) { const rk = y + '|' + x.region + '|' + ch; let q = regs.get(rk); if (!q) { q = [y, x.region, ch, 0]; regs.set(rk, q); } q[3] += x.eur; }
  }
  for (const r of adjustedMonths().map((x) => ({ ...x, m: x.meters })) as any[]) { const g = gidx.get(dg(r.grp || 'Other'))!; const mk = r.ym + '|' + r.ch + '|' + g; let o = monthly.get(mk); if (!o) { o = [r.ym, r.ch, g, 0, 0, 0]; monthly.set(mk, o); } o[3] += r.eur; o[4] += r.m2; o[5] += r.m; }
  for (const r of db.prepare('SELECT period, thickness th, width w, grp, SUM(eur) eur, SUM(meters) m FROM intel_spec GROUP BY period, thickness, width, grp').all() as any[]) { const g = gidx.get(dg(r.grp || 'Other'))!; const wd = r.w >= 999 ? 'wide' : r.w; const y = +r.period.slice(0, 4); const sk = y + '|' + r.th + '|' + wd + '|' + g; let q = spec.get(sk); if (!q) { q = [y, r.th, wd, g, 0, 0]; spec.set(sk, q); } q[4] += r.eur; q[5] += r.m; }
  // what the left-out accounts bought comes off the thickness and width table too (the months that are kept per customer)
  for (const f of db.prepare(`SELECT f.period, f.thickness th, f.width w, m.grp, SUM(f.eur) eur, SUM(f.meters) m FROM intel_fact f JOIN intel_excluded e ON e.code = f.customer LEFT JOIN intel_mat m ON m.code = f.material
    WHERE f.period NOT LIKE '%-00' AND f.doc_type = 'S' GROUP BY f.period, f.thickness, f.width, m.grp`).all() as any[]) {
    const g = gidx.get(dg(f.grp || 'Other'))!; const wd = f.w >= 999 ? 'wide' : f.w; const q = spec.get(+f.period.slice(0, 4) + '|' + f.th + '|' + wd + '|' + g); if (q) { q[4] -= f.eur; q[5] -= f.m; }
  }
  const ctryList: string[][] = [], ctryAt = new Map<string, number>();
  const ctryIdx = (n: string): number => { if (!n) return -1; let i = ctryAt.get(n); if (i === undefined) { i = ctryList.length; ctryAt.set(n, i); ctryList.push([n, continentOf(n)]); } return i; };
  const custRows = custs.map((c) => [c.name, c.region, c.city, c.rep, c.first, c.last, c.ch, c.grp, c.code, ctryIdx(c.ctry.country), c.ctry.src]);
  return {
    cut, years: YEARS, l12: [L12S, L12E], p12: [P12S, addDays(L12S, -1)], groups, reasons,
    cust: custRows,
    ctry: ctryList,
    mat: mats.map((m) => [m.code, m.desc, gidx.get(dg(m.grp)), m.type, m.fam]),
    cube: [...cube.values()].map((o) => [o[0], o[1], o[2], r0(o[3]), r0(o[4]), r0(o[5])]).filter((o) => o[3] || o[4]),
    monthly: [...monthly.values()].map((o) => [o[0], o[1], o[2], r0(o[3]), r0(o[4]), r0(o[5])]),
    cm: [...cm.values()].map((o) => [o[0], o[1], o[2], r0(o[3]), r0(o[4]), r0(o[5])]).filter((o) => o[3] || o[5]),
    rets: [...rets.values()].map((o) => [o[0], o[1], o[2], o[3], r0(o[4]), r0(o[5])]),
    spec: [...spec.values()].map((o) => [o[0], o[1], o[2], o[3], r0(o[4]), r0(o[5])]),
    regs: [...regs.values()].map((o) => [o[0], o[1], o[2], r0(o[3])]),
    _dg: dg, _topG: topG,
  };
}

// ---------------------------------------------------------------- 2. kartela, forecast, reorder, pricing
function buildColour(L0: Line[], W: Win, dg: (g: string) => string, topG: string[]) {
  const { cut, L12S, L12E, P12S } = W;
  const L = L0.filter((x) => !GROUPCOS.test(x.cname));
  const decDim = new Map<string, { first: string; last: string }>(); for (const r of db.prepare('SELECT code, first_date f, last_date l FROM intel_mat').all() as any[]) { const k = String(r.code).split('.')[0]; const o = decDim.get(k); if (!o) decDim.set(k, { first: r.f, last: r.l }); else { if (r.f < o.first) o.first = r.f; if (r.l > o.last) o.last = r.l; } }
  const dec = (m: string) => m.split('.')[0];
  const kr = db.prepare('SELECT list_name, section, no, code, match_code, producer, availability, surface FROM intel_kartela').all() as any[];
  const surfMap = Object.fromEntries((db.prepare('SELECT code, name FROM intel_surface').all() as any[]).map((s) => [s.code, s.name]));
  const SEC = (s: string) => /INTENSIVE/i.test(s) ? 'Intensive solid' : /HIGH GLOSS WOOD/i.test(s) ? 'High gloss wood' : /HIGH GLOSS/i.test(s) ? 'High gloss solid' : /WOODGRAIN/i.test(s) ? 'Woodgrain' : /SOLID/i.test(s) ? 'Solid' : /BRUSHED/i.test(s) ? 'Metal brushed' : /MIRROR/i.test(s) ? 'Mirror' : s;
  const express = (a: string) => !/MOQ/i.test(a) && /MM/i.test(a);
  const kmap = new Map<string, any[]>(); for (const k of kr) { if (!kmap.has(k.code)) kmap.set(k.code, []); kmap.get(k.code)!.push(k); }
  const dstat = new Map<string, any>();
  for (const x of L) {
    const k = dec(x.mat); let o = dstat.get(k);
    if (!o) { o = { y: {}, l12: 0, p12: 0, m12: 0, first: x.d, last: x.d, b12: new Set(), ball: new Set(), desc: x.desc, tot: 0, g: {} }; dstat.set(k, o); }
    o.y[x.d.slice(0, 4)] = (o.y[x.d.slice(0, 4)] || 0) + x.eur; o.tot += x.eur;
    { const gg = dg(x.grp || 'Other'); o.g[gg] = (o.g[gg] || 0) + x.eur; }
    if (x.d >= L12S && x.d <= L12E) { o.l12 += x.eur; o.m12 += x.m; o.b12.add(x.cust); } else if (x.d >= P12S && x.d < L12S) o.p12 += x.eur;
    if (!x.ret) o.ball.add(x.cust);
  }
  const y0 = +cut.slice(0, 4) - 7; // eight yearly figures, the last is the year to date
  const yv = (o: any) => Array.from({ length: 8 }, (_, i) => r0(o.y[String(y0 + i)] || 0));
  const kart: any[] = [];
  for (const [code, ks] of kmap) {
    const s = dstat.get(code), k0 = ks[0];
    kart.push({ code, match: [...new Set(ks.map((k) => k.match_code))].join(' / '), prod: [...new Set(ks.map((k) => k.producer))].join(' / '), list: [...new Set(ks.map((k) => k.list_name))].join(' + '), sec: SEC(k0.section), sfc: k0.surface, surf: surfMap[k0.surface] || k0.surface, avail: k0.availability, exp: ks.some((k) => express(k.availability)) ? 1 : 0, desc: s ? s.desc : '', y: s ? yv(s) : Array(8).fill(0), l12: s ? r0(s.l12) : 0, p12: s ? r0(s.p12) : 0, m12: s ? r0(s.m12) : 0, b12: s ? s.b12.size : 0, ball: s ? s.ball.size : 0, first: decDim.get(code)?.first ?? '', last: decDim.get(code)?.last ?? '' });
  }
  const cands: any[] = [];
  for (const [code, s] of dstat) {
    if (kmap.has(code) || s.l12 < 25000 || s.b12.size < 3) continue;
    const gg = Object.entries(s.g).sort((a: any, b: any) => b[1] - a[1])[0][0] as string; if (!['PVC', 'ABS', 'Metal - Ayna', 'PVC - Tapa'].includes(gg)) continue;
    cands.push({ code, g: gg, desc: s.desc, l12: r0(s.l12), p12: r0(s.p12), b12: s.b12.size, y: yv(s) });
  }
  cands.sort((a, b) => b.l12 - a.l12);
  const split: any = {};
  for (const x of L) { if (x.d < P12S || x.d > L12E) continue; const per = x.d >= L12S ? 'l12' : 'p12'; const g = dg(x.grp || 'Other'); const o = split[g] || (split[g] = { l12k: 0, l12c: 0, p12k: 0, p12c: 0 }); o[per + (kmap.has(dec(x.mat)) ? 'k' : 'c')] += x.eur; }
  for (const g in split) for (const k in split[g]) split[g][k] = r0(split[g][k]);

  // ---- forecast
  const lastFull = W.lastFull;
  const firstM = monthsBack(lastFull, 37);
  const months: string[] = []; { let [y, m] = [+firstM.slice(0, 4), +firstM.slice(5, 7)]; for (;;) { const s = `${y}-${String(m).padStart(2, '0')}`; if (s > lastFull) break; months.push(s); m++; if (m > 12) { m = 1; y++; } } }
  const mi = new Map(months.map((m, i) => [m, i])); const N = months.length;
  const series = (filter: (x: Line) => boolean, key: 'eur' | 'm') => { const s = new Float64Array(N); for (const x of L) { const i = mi.get(x.d.slice(0, 7)); if (i === undefined || !filter(x)) continue; s[i] += x[key]; } return s; };
  const ssum = (a: Float64Array, f: number, t: number) => { let v = 0; for (let i = Math.max(0, f); i < t; i++) v += a[i]; return v; };
  const METH: Record<string, (s: Float64Array, o: number, h: number) => number> = {
    last3: (s, o, h) => ssum(s, o - 3, o) / 3 * h,
    last6: (s, o, h) => ssum(s, o - 6, o) / 6 * h,
    last12: (s, o, h) => ssum(s, o - 12, o) / 12 * h,
    seasonal: (s, o, h) => { const a = ssum(s, o - 12, o - 12 + h), r = ssum(s, o - 6, o), b = ssum(s, o - 18, o - 12); const f = b > 0 ? Math.min(1.5, Math.max(0.5, r / b)) : 1; return a * f; },
    blend: (s, o, h) => (METH.last12(s, o, h) + METH.seasonal(s, o, h)) / 2,
  };
  const nOr = Math.min(12, Math.max(3, N - 30));
  const backtest = (list: Float64Array[], h: number) => { const res: Record<string, number> = {}; for (const m in METH) { let e = 0, a = 0; for (const s of list) for (let o = N - h - nOr + 1; o <= N - h; o++) { const act = ssum(s, o, o + h), f = METH[m](s, o, h); e += Math.abs(f - act); a += act; } res[m] = a ? e / a : 9; } return res; };
  const ratios = (s: Float64Array, m: string, h: number) => { const r: number[] = []; for (let o = N - h - nOr + 1; o <= N - h; o++) { const act = ssum(s, o, o + h), f = METH[m](s, o, h); if (f > 0) r.push(act / f); } return r.sort((a, b) => a - b); };
  const q = (a: number[], p: number) => (a.length ? a[Math.min(a.length - 1, Math.floor(a.length * p))] : 1);
  const fmonths: string[] = []; { let [y, m] = [+lastFull.slice(0, 4), +lastFull.slice(5, 7)]; for (let i = 0; i < 6; i++) { m++; if (m > 12) { m = 1; y++; } fmonths.push(`${y}-${String(m).padStart(2, '0')}`); } }
  const fc: any = { months: fmonths, hist: months, agg: {} };
  const aggSets: Record<string, (x: Line) => boolean> = { 'All sales': () => true };
  for (const g of ['PVC', 'ABS', 'Melamin']) if (topG.includes(g)) aggSets[g] = (x) => dg(x.grp || 'Other') === g;
  for (const [name, f] of Object.entries(aggSets)) {
    const s = series(f, 'eur'); const b = backtest([s], 3); const best = Object.entries(b).sort((a, c) => a[1] - c[1])[0][0]; const rr = ratios(s, best, 3);
    const lvl = METH[best](s, N, 3) / 3;
    const seas = fmonths.map((_, k) => { const idx = N + k - 12; const lastYr = idx >= 0 ? s[idx] : 0; const yr = ssum(s, N - 12, N) / 12; return yr > 0 && lastYr > 0 ? Math.min(1.6, Math.max(0.5, lastYr / yr)) : 1; });
    const fv = seas.map((x) => lvl * (0.5 + 0.5 * x)); const spread = [q(rr, .1), q(rr, .9)]; const medr = q(rr, .5), adj = Math.min(1.05, Math.max(0.85, medr));
    fc.agg[name] = { hist: [...s].map(r0), f: fv.map((v) => r0(v * adj)), lo: fv.map((v) => r0(Math.min(v * adj * 0.92, v * spread[0]))), hi: fv.map((v) => r0(Math.max(v * adj * 1.06, v * spread[1]))), bias: r3(medr), method: best, wape: r3(b[best]), wapeAll: Object.fromEntries(Object.entries(b).map(([k, v]) => [k, r3(v)])) };
  }
  const topDec = [...dstat].sort((a, b) => b[1].l12 - a[1].l12).slice(0, 150).map((e) => e[0]);
  const dmap = new Map(topDec.map((c) => [c, { c, s: new Float64Array(N), m: new Float64Array(N) }]));
  for (const x of L) { const o = dmap.get(dec(x.mat)); if (!o) continue; const i = mi.get(x.d.slice(0, 7)); if (i === undefined) continue; o.s[i] += x.eur; o.m[i] += x.m; }
  const dser = topDec.map((c) => dmap.get(c)!);
  const bD = backtest(dser.map((d) => d.s), 3); const bestD = Object.entries(bD).sort((a, b) => a[1] - b[1])[0][0];
  fc.codes = dser.map((d) => { const f3 = METH[bestD](d.s, N, 3), fm = METH[bestD](d.m, N, 3), rr = ratios(d.s, bestD, 3); return { c: d.c, desc: dstat.get(d.c).desc, kart: kmap.has(d.c) ? 1 : 0, f: r0(f3), fm: r0(fm), l3: r0(ssum(d.s, N - 3, N)), ly: r0(ssum(d.s, N - 12, N - 9)), l12: r0(ssum(d.s, N - 12, N)), lo: r0(f3 * q(rr, .1)), hi: r0(f3 * q(rr, .9)), s: [...d.s.slice(Math.max(0, N - 24))].map(r0) }; });
  fc.codeMethod = bestD; fc.codeWape = Object.fromEntries(Object.entries(bD).map(([k, v]) => [k, r3(v)]));

  // ---- customer reorder rhythm
  const E = new Map<string, any>();
  { const nameOf = new Map<string, string>((db.prepare('SELECT code, name FROM intel_cust').all() as any[]).map((r) => [r.code, r.name ?? '']));
    const byDay = new Map<string, [string, number][]>(); for (const r of db.prepare('SELECT customer, d, eur FROM intel_events WHERE customer NOT IN (SELECT code FROM intel_excluded) ORDER BY customer, d').all() as any[]) { if (GROUPCOS.test(nameOf.get(r.customer) ?? '')) continue; if (!byDay.has(r.customer)) byDay.set(r.customer, []); byDay.get(r.customer)!.push([r.d, r.eur]); }
    for (const [c, list] of byDay) { const ev: any[] = []; for (const [dt, v] of list) { const l = ev[ev.length - 1]; if (l && days(l.d, dt) <= 10) { l.v += v; l.e = dt; } else ev.push({ d: dt, e: dt, v }); } E.set(c, { name: nameOf.get(c) ?? '', ev }); } }
  const erf = (x: number) => { const s = Math.sign(x); x = Math.abs(x); const t = 1 / (1 + .3275911 * x); return s * (1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - .284496736) * t + .254829592) * t * Math.exp(-x * x)); };
  const cdf = (x: number, mu: number, sg: number) => (x <= 0 ? 0 : .5 * (1 + erf((Math.log(x) - mu) / (sg * Math.SQRT2))));
  const rng = (a: number) => () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
  const hashS = (s: string) => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h; };
  const pool = (asof: string) => { const li: number[] = []; const lim = addDays(asof, -1100); for (const [, o] of E) { const ev = o.ev.filter((e: any) => e.d <= asof); for (let i = 1; i < ev.length; i++) { const g = days(ev[i - 1].d, ev[i].d); if (g > 0 && ev[i].d >= lim) li.push(Math.log(g)); } } const mu = li.reduce((a, b) => a + b, 0) / (li.length || 1); const sg = Math.sqrt(li.reduce((a, b) => a + (b - mu) ** 2, 0) / (li.length || 1)); return { mu, sg }; };
  function predict(asof: string, hs: number[]) {
    const P = pool(asof), res: any[] = []; const lim = addDays(asof, -1100);
    for (const [c, o] of E) {
      const ev = o.ev.filter((e: any) => e.d <= asof); if (ev.length < 2) continue;
      const last = ev[ev.length - 1]; const el = days(last.d, asof);
      const recent = ev.filter((e: any) => e.d >= lim); if (recent.length < 2 || days(recent[recent.length - 1].d, asof) > 900) continue;
      const gaps: number[] = []; for (let i = 1; i < recent.length; i++) gaps.push(Math.max(1, days(recent[i - 1].d, recent[i].d)));
      const n = gaps.length, lg = gaps.map(Math.log), mu0 = lg.reduce((a, b) => a + b, 0) / n, sg0 = Math.sqrt(lg.reduce((a, b) => a + (b - mu0) ** 2, 0) / n);
      const w = n / (n + 3), mu = w * mu0 + (1 - w) * P.mu, sg = Math.max(0.35, Math.sqrt(w * sg0 * sg0 + (1 - w) * P.sg * P.sg));
      const rnd = rng(hashS(c + asof)); const nrm = () => Math.sqrt(-2 * Math.log(rnd() || 1e-9)) * Math.cos(2 * Math.PI * rnd());
      const hm = Math.max(...hs), SIMS = 300, cnt = hs.map(() => 0), any = hs.map(() => 0);
      for (let s = 0; s < SIMS; s++) {
        let x = 0; for (let tr = 0; tr < 40; tr++) { x = Math.exp(mu + sg * nrm()); if (x > el) break; x = 0; }
        if (!x) x = el + Math.max(3, 0.25 * Math.exp(mu));
        let tt = x - el; const k = hs.map(() => 0);
        while (tt <= hm) { hs.forEach((h, j) => { if (tt <= h) k[j]++; }); tt += Math.max(1, Math.exp(mu + sg * nrm())); }
        k.forEach((v, j) => { cnt[j] += v; if (v > 0) any[j]++; });
      }
      const pr = any.map((v) => v / SIMS), en = cnt.map((v) => v / SIMS);
      const vals = recent.slice(-5).map((e: any) => e.v).sort((a: number, b: number) => a - b); const val = vals[Math.floor(vals.length / 2)];
      const gs = [...gaps].sort((a, b) => a - b);
      res.push({ c, name: o.name, n: ev.length, last: last.d, el, med: gs[Math.floor(gs.length / 2)], p75: gs[Math.min(gs.length - 1, Math.floor(gs.length * .75))], p: pr, en, val });
    }
    return res;
  }
  const firstDay = ((db.prepare('SELECT MIN(d) d FROM intel_events').get() as any).d as string) || cut;
  const bo: string[] = []; for (let k = 0; k < 20; k++) { const d = addDays(cut, -90 - 30 * k); if (days(firstDay, d) < 540) break; bo.unshift(d); }
  const RECS: any[] = []; const bkt = (x: number) => (x < 0.5 ? 0 : x < 1 ? 1 : x < 1.5 ? 2 : x < 2.5 ? 3 : x < 4 ? 4 : 5);
  for (const asof of bo) {
    const pr = predict(asof, [90]); const end = addDays(asof, 90); const act = new Map<string, number>();
    for (const [c, o] of E) for (const e of o.ev) if (e.d > asof && e.d <= end) act.set(c, (act.get(c) || 0) + e.v);
    const oi = bo.indexOf(asof); for (const r of pr) RECS.push({ i: oi, b: bkt(r.el / r.med), pe: r.en[0] * r.val, ae: act.get(r.c) || 0, p: r.p[0], a: act.has(r.c) ? 1 : 0 });
  }
  const factors = (recs: any[]) => { const s = Array.from({ length: 6 }, () => [0, 0]); for (const r of recs) { s[r.b][0] += r.pe; s[r.b][1] += r.ae; } return s.map(([p, a]) => (p > 0 ? a / p : 1)); };
  const half = Math.floor(bo.length / 2), trainR = RECS.filter((r) => r.i < half), testR = RECS.filter((r) => r.i >= half), fTrain = factors(trainR);
  const rawT = sum(testR, (r) => r.pe), calT = sum(testR, (r) => r.pe * fTrain[r.b]), actT = sum(testR, (r) => r.ae);
  const rk = [...testR].sort((a, b) => b.pe * fTrain[b.b] - a.pe * fTrain[a.b]); const tq2 = rk.slice(0, Math.ceil(rk.length / 5));
  const hitOOS = tq2.length ? tq2.filter((r) => r.a).length / tq2.length : 0, baseOOS = testR.length ? testR.filter((r) => r.a).length / testR.length : 0;
  const perO: Record<number, number[]> = {}; for (const r of testR) { const o = perO[r.i] || (perO[r.i] = [0, 0]); o[0] += r.pe * fTrain[r.b]; o[1] += r.ae; }
  const oe = Object.values(perO).map(([p, a]) => (a ? Math.abs(p - a) / a : 0));
  const FAC = factors(RECS);
  const OOS = { raw: r0(rawT), cal: r0(calT), act: r0(actT), mae: r1((oe.reduce((a, b) => a + b, 0) / (oe.length || 1)) * 100), hit: r1(hitOOS * 100), base: r1(baseOOS * 100), fac: FAC.map(r3), windows: oe.length };
  const final = predict(cut, [30, 60, 90]);
  const reorder = final.map((r) => ({ c: r.c, name: r.name, n: r.n, last: r.last, el: r.el, med: r.med, p75: r.p75, p30: r1(r.p[0] * 100), p60: r1(r.p[1] * 100), p90: r1(r.p[2] * 100), val: r0(r.val), exp: r0(r.en[2] * r.val * FAC[bkt(r.el / r.med)]), n90: r1(r.en[2]), due: addDays(r.last, r.med) })).sort((a, b) => b.exp - a.exp);
  const totals = { e30: r0(sum(final, (r) => r.en[0] * r.val * FAC[bkt(r.el / r.med)])), e60: r0(sum(final, (r) => r.en[1] * r.val * FAC[bkt(r.el / r.med)])), e90: r0(sum(reorder, (r) => r.exp)), n: final.length };

  // ---- realized pricing (edge band)
  const FIN = (f: string) => (/BASKILI$/.test(f) && !/HG/.test(f) ? 'Printed' : /BASKISIZ/.test(f) ? 'Plain' : /HG|LAK/.test(f) ? 'High gloss / lacquer' : /ALÜM|AYNA/.test(f) ? 'Metal / mirror' : 'Other');
  const WC = (w: number) => (w <= 23 ? '≤23 mm' : w <= 50 ? '24–50 mm' : '>50 mm');
  const px = L.filter((x) => !x.ret && x.eur > 0 && x.m2 > 0 && x.typ === 'Kenar Bandı' && x.th > 0 && x.w > 0 && x.w < 200 && x.d <= L12E);
  const segKey = (x: Line) => dg(x.grp || 'Other') + '|' + x.th + '|' + FIN(x.fin) + '|' + WC(x.w);
  const wq = (arr: number[][], p: number) => { arr.sort((a, b) => a[0] - b[0]); const t = arr.reduce((s, a) => s + a[1], 0); let c = 0; for (const a of arr) { c += a[1]; if (c >= t * p) return a[0]; } return arr.length ? arr[arr.length - 1][0] : 0; };
  const segs = new Map<string, Line[]>(); for (const x of px) { const k = segKey(x); if (!segs.has(k)) segs.set(k, []); segs.get(k)!.push(x); }
  const segOut: any[] = [], medOf = new Map<string, number>(); const qStart = addDays(cut, -3 * 365);
  for (const [k, rows] of segs) {
    const cur = rows.filter((x) => x.d >= L12S && x.d <= L12E); if (!cur.length) continue;
    const cust = new Set(cur.map((x) => x.cust)); const eur = sum(cur, (x) => x.eur), m2 = sum(cur, (x) => x.m2);
    if (eur < 60000 || cust.size < 6) continue;
    const arr = cur.map((x) => [x.eur / x.m2, x.m2]); const med = wq(arr, .5); medOf.set(k, med);
    const prev = rows.filter((x) => x.d >= P12S && x.d < L12S); const pm2 = sum(prev, (x) => x.m2), pe_ = sum(prev, (x) => x.eur);
    const qs: Record<string, number[]> = {}; for (const x of rows) { if (x.d < qStart) continue; const qk = x.d.slice(0, 4) + 'Q' + (Math.floor((+x.d.slice(5, 7) - 1) / 3) + 1); const o = qs[qk] || (qs[qk] = [0, 0]); o[0] += x.eur; o[1] += x.m2; }
    const [g, th, fin, wc] = k.split('|');
    segOut.push({ k, g, th: +th, fin, wc, eur: r0(eur), m2: r0(m2), n: cust.size, avg: r3(eur / m2), p10: r3(wq(arr, .1)), p50: r3(med), p90: r3(wq(arr, .9)), prev: pm2 ? r3(pe_ / pm2) : null, qt: Object.fromEntries(Object.entries(qs).map(([a, b]) => [a, b[1] ? r3(b[0] / b[1]) : null])) });
  }
  segOut.sort((a, b) => b.eur - a.eur); const segIdx = new Map(segOut.map((s, i) => [s.k, i]));
  const cp = new Map<string, any>();
  for (const x of px) {
    if (x.d < L12S || x.d > L12E) continue; const k = segKey(x); if (!segIdx.has(k)) continue; const med = medOf.get(k)!;
    let o = cp.get(x.cust); if (!o) { o = { name: x.cname, eur: 0, atMed: 0, gap: 0, seg: new Map() }; cp.set(x.cust, o); }
    o.eur += x.eur; o.atMed += x.m2 * med; o.gap += x.m2 * med - x.eur;
    const s = o.seg.get(k) || { eur: 0, m2: 0 }; s.eur += x.eur; s.m2 += x.m2; o.seg.set(k, s);
  }
  const cust = [...cp].filter(([, o]) => o.eur >= 8000).map(([c, o]) => ({ c, name: o.name, eur: r0(o.eur), idx: r3(o.eur / o.atMed), gap: r0(o.gap), seg: [...o.seg].map(([k, s]: any) => [segIdx.get(k), r3(s.eur / s.m2), r0(s.m2)]).sort((a: any, b: any) => b[2] - a[2]).slice(0, 8) })).sort((a, b) => b.eur - a.eur);
  const cmp = new Map<string, any>();
  for (const x of px) { if (x.d < L12S || x.d > L12E) continue; const k = segKey(x); if (!segIdx.has(k)) continue; const o = cmp.get(k) || { se: 0, sm: 0, ce: 0, cm: 0 }; if (kmap.has(dec(x.mat))) { o.se += x.eur; o.sm += x.m2; } else { o.ce += x.eur; o.cm += x.m2; } cmp.set(k, o); }
  let wDiff = 0, wBase = 0; for (const [, o] of cmp) if (o.sm > 500 && o.cm > 500) { wDiff += (o.ce / o.cm / (o.se / o.sm) - 1) * (o.ce + o.se); wBase += o.ce + o.se; }
  return { cut, groups: topG, kart, cands: cands.slice(0, 60), split, fc, reorder: reorder.slice(0, 300), btReorder: OOS, totals, pricing: { segs: segOut, cust, stdVsCustom: wBase ? r3(wDiff / wBase) : 0 } };
}

// ---------------------------------------------------------------- 3. stock against open orders, accounts against the CRM
const DEP: Record<string, string> = { '3000': 'ship', '3001': 'ship', '3100': 'ship', '2003': 'cut', '2000': 'cut', '2001': 'cut', '2012': 'cut', '9500': 'count', '8000': 'sample', '4010': 'blocked', '2007': 'blocked' };
const NOISE = new Set(['LTD', 'LTDA', 'LLC', 'SRL', 'SA', 'AS', 'A', 'S', 'TIC', 'SAN', 'SANAYI', 'TICARET', 'LIMITED', 'SIRKETI', 'STI', 'CO', 'INC', 'GMBH', 'KFT', 'OOO', 'ZAO', 'DOO', 'D', 'O', 'DE', 'CV', 'AND', 'VE', 'THE', 'COMPANY', 'GROUP', 'CIA', 'SP', 'ZO', 'JSC', 'PVT', 'PLC', 'CORP', 'SAS', 'SARL', 'BV', 'NV', 'AG', 'OY', 'AB', 'EOOD', 'ANONIM', 'MOB', 'MOBILYA']);
const norm = (s: string) => String(s || '').toUpperCase().replace(/İ/g, 'I').replace(/Ş/g, 'S').replace(/Ğ/g, 'G').replace(/Ü/g, 'U').replace(/Ö/g, 'O').replace(/Ç/g, 'C').replace(/[^A-Z0-9 ]/g, ' ').split(/\s+/).filter((t) => t && !NOISE.has(t));

export function cardLinks(): { withSap: Map<string, { id: number; company: string }>; cards: any[]; master: Map<string, any> } {
  const cards = db.prepare("SELECT id, company, country, sap FROM cards WHERE company IS NOT NULL AND company <> ''").all() as any[];
  const withSap = new Map<string, { id: number; company: string }>(); for (const c of cards) if (c.sap) withSap.set(String(c.sap).trim(), { id: c.id, company: c.company });
  const master = new Map<string, any>((db.prepare('SELECT sap_no, name, country FROM sap_customers').all() as any[]).map((r) => [r.sap_no, r]));
  return { withSap, cards, master };
}

function buildStock(L0: Line[], W: Win, today: string) {
  const { L12S, L12E } = W; const L = L0;
  const lots: any[] = (db.prepare('SELECT grp, grp_name, material mat, description descr, thickness th, width w, roll_length rl, qty q, m2, depot dep, customer cust, customer_name cname, sales_doc so, item, received rec, form FROM intel_stock').all() as any[]).map((x) => ({ ...x, desc: x.descr, dc: DEP[x.dep] || 'other', so: x.so || '', item: x.item || '' }));
  const orders: any[] = (db.prepare("SELECT order_no so, item_no item, doc_date doc, delivery_date del, sap_no cust, customer cname, material mat, material_name descr, thickness th, width w, roll_length rl, pending_qty pend, unit, pending_m2 pm2, value_eur eur FROM export_production_backlog WHERE unit = 'M' AND width > 0 AND width < 100 AND pending_qty > 0").all() as any[]).map((o) => ({ ...o, desc: o.descr, so: String(o.so), item: String(o.item), del: (o.del || '').slice(0, 10) }));
  const openKey = new Set(orders.map((o) => o.so + '|' + o.item));
  const dem = new Map<string, any>(), cs = new Map<string, any>(); const lastSale = new Map<string, string>();
  for (const s of L) {
    if (!s.ret && s.d >= L12S && s.d <= L12E) { let o = dem.get(s.mat); if (!o) { o = { m: 0, eur: 0 }; dem.set(s.mat, o); } o.m += s.m; o.eur += s.eur; }
    let c = cs.get(s.cust); if (!c) { c = { name: s.cname, l12: 0, all: 0, last: '' }; cs.set(s.cust, c); } c.all += s.eur; if (s.d >= L12S && s.d <= L12E) c.l12 += s.eur;
  }
  for (const r of db.prepare('SELECT code, last_date l FROM intel_cust').all() as any[]) { const c = cs.get(r.code); if (c) c.last = r.l; }
  for (const r of db.prepare('SELECT code, last_date l FROM intel_mat').all() as any[]) lastSale.set(r.code, r.l);
  const gp: Record<string, number[]> = {}; for (const [m, o] of dem) { const g = m.split('.')[1] || ''; const p = gp[g] || (gp[g] = [0, 0]); p[0] += o.eur; p[1] += o.m; }
  const priceOf = (mat: string) => { const o = dem.get(mat); if (o && o.m > 20000 && o.eur > 0) return o.eur / o.m; const g = gp[mat.split('.')[1] || '']; return g && g[1] ? g[0] / g[1] : 0.07; };
  for (const l of lots) { l.age = l.rec ? days(l.rec, today) : null; l.own = l.cust === OWN; l.reserved = !l.own && l.so && openKey.has(l.so + '|' + l.item); l.stranded = !l.own && !l.reserved; }
  const tot: any = { all: r0(sum(lots, (l) => l.q)), byDc: Object.fromEntries(['ship', 'cut', 'count', 'sample', 'blocked', 'other'].map((d) => [d, r0(sum(lots.filter((l) => l.dc === d), (l) => l.q))])) };
  const sell = lots.filter((l) => l.dc === 'ship' || l.dc === 'cut');
  tot.own = r0(sum(sell.filter((l) => l.own), (l) => l.q)); tot.reserved = r0(sum(sell.filter((l) => l.reserved), (l) => l.q)); tot.stranded = r0(sum(sell.filter((l) => l.stranded), (l) => l.q));
  const key = (o: any) => o.mat + '|' + o.th + '|' + o.w;
  const pool = (pred: (l: any) => boolean) => { const m = new Map<string, number>(); for (const l of lots) if (pred(l)) { const k = key(l); m.set(k, (m.get(k) || 0) + l.q); } return m; };
  const resShip = new Map<string, number>(), resCut = new Map<string, number>(), resCnt = new Map<string, number>();
  for (const l of lots) if (l.reserved) { const k = l.so + '|' + l.item; const t = l.dc === 'ship' ? resShip : l.dc === 'cut' ? resCut : l.dc === 'count' ? resCnt : null; if (t) t.set(k, (t.get(k) || 0) + l.q); }
  const fShipP = pool((l) => l.own && l.dc === 'ship'), fCutP = pool((l) => l.own && l.dc === 'cut'), strP = pool((l) => l.stranded && (l.dc === 'ship' || l.dc === 'cut')), cntP = pool((l) => l.dc === 'count' && !l.reserved);
  const take = (p: Map<string, number>, k: string, n: number) => { const a = p.get(k) || 0, t = Math.min(a, n); if (t > 0) p.set(k, a - t); return t; };
  const sorted = [...orders].sort((a, b) => ((a.del || '9') < (b.del || '9') ? -1 : (a.del || '9') > (b.del || '9') ? 1 : (a.doc || '') < (b.doc || '') ? -1 : 1));
  for (const o of sorted) {
    const k = o.so + '|' + o.item, kk = key(o); let need = o.pend;
    o.rShip = take(resShip, k, need); need -= o.rShip; o.rCut = take(resCut, k, need); need -= o.rCut; o.rCnt = take(resCnt, k, need); need -= o.rCnt;
    o.fShip = take(fShipP, kk, need); need -= o.fShip; o.fCut = take(fCutP, kk, need); need -= o.fCut;
    o.str = take(strP, kk, need); need -= o.str; o.unv = take(cntP, kk, need); need -= o.unv; o.make = Math.max(0, need);
    const ready = o.rShip + o.fShip, soon = ready + o.rCut + o.fCut, other = soon + o.str + o.unv + o.rCnt;
    o.st = ready >= o.pend * .98 ? 0 : soon >= o.pend * .98 ? 1 : soon > 0 ? 2 : other > 0 ? 3 : 4;
    o.late = o.del && o.del < today ? days(o.del, today) : 0;
  }
  const ot = { pend: r0(sum(orders, (o) => o.pend)), ready: r0(sum(orders, (o) => o.rShip + o.fShip)), cut: r0(sum(orders, (o) => o.rCut + o.fCut)), other: r0(sum(orders, (o) => o.str + o.unv + o.rCnt)), make: r0(sum(orders, (o) => o.make)), lines: orders.length };
  const mats = new Map<string, any>(); const AG = (a: number | null) => (a == null ? 4 : a < 90 ? 0 : a < 180 ? 1 : a < 365 ? 2 : a < 730 ? 3 : 4);
  for (const l of lots) {
    let m = mats.get(l.mat); if (!m) { m = { mat: l.mat, desc: l.desc, g: l.grp_name, ship: 0, cut: 0, cnt: 0, res: 0, str: 0, samp: 0, blk: 0, own: 0, age: [0, 0, 0, 0, 0], newest: '' }; mats.set(l.mat, m); }
    if (l.dc === 'sample') m.samp += l.q; else if (l.dc === 'blocked' || l.dc === 'other') m.blk += l.q; else if (l.dc === 'count') m.cnt += l.q;
    else if (l.reserved) m.res += l.q; else if (l.stranded) m.str += l.q;
    else { if (l.dc === 'ship') m.ship += l.q; else m.cut += l.q; m.own += l.q; m.age[AG(l.age)] += l.q; if (l.rec && l.rec > m.newest) m.newest = l.rec; }
  }
  const allocFree = new Map<string, number>(), pendBy = new Map<string, number>(), makeBy = new Map<string, number>();
  for (const o of orders) { allocFree.set(o.mat, (allocFree.get(o.mat) || 0) + o.fShip + o.fCut); pendBy.set(o.mat, (pendBy.get(o.mat) || 0) + o.pend); makeBy.set(o.mat, (makeBy.get(o.mat) || 0) + o.make); }
  const matRows: any[] = [];
  for (const m of mats.values()) {
    if (m.own + m.res + m.str + m.cnt <= 0) continue;
    const d = dem.get(m.mat), mon = d ? Math.max(0, d.m) / 12 : 0, price = priceOf(m.mat), avail = Math.max(0, m.own - (allocFree.get(m.mat) || 0));
    const young = m.newest && days(m.newest, today) < 120; let st: string, h = 0, hv = 0, ex = 0;
    if (!(mon > 0)) { st = (pendBy.get(m.mat) || 0) > 0 ? 'Open orders only' : young ? 'New' : 'No sales 12m'; ex = st === 'No sales 12m' ? avail : 0; h = st === 'New' || st === 'Open orders only' ? avail : 0; }
    else { const cov = avail / mon; st = cov < 1 ? 'Low' : cov <= 6 ? 'Healthy' : cov <= 12 ? 'Heavy' : 'Excess'; h = Math.min(avail, 6 * mon); hv = Math.min(Math.max(avail - 6 * mon, 0), 6 * mon); ex = Math.max(avail - 12 * mon, 0); }
    matRows.push({ mat: m.mat, desc: m.desc, g: m.g, ship: r0(m.ship), cut: r0(m.cut), cnt: r0(m.cnt), res: r0(m.res), str: r0(m.str), samp: r0(m.samp), own: r0(m.own), alloc: r0(allocFree.get(m.mat) || 0), avail: r0(avail), mon: r0(mon), cov: mon > 0 ? r1(avail / mon) : null, st, h: r0(h), hv: r0(hv), ex: r0(ex), price: r3(price), pend: r0(pendBy.get(m.mat) || 0), make: r0(makeBy.get(m.mat) || 0), age: m.age.map(r0), newest: m.newest, last: lastSale.get(m.mat) || '' });
  }
  matRows.sort((a, b) => b.avail * b.price - a.avail * a.price);
  const H: Record<string, number> = { Low: 0, Healthy: 0, Heavy: 0, Excess: 0, 'No sales 12m': 0, New: 0, 'Open orders only': 0 }, HV = { ...H };
  for (const m of matRows) { H[m.st] += m.avail; HV[m.st] += m.avail * m.price; }
  const healthy = r0(sum(matRows, (m) => m.h)), heavy = r0(sum(matRows, (m) => m.hv)), excess = r0(sum(matRows, (m) => m.avail) - healthy - heavy);
  const val = (f: (m: any) => number) => r0(sum(matRows, (m) => f(m) * m.price));
  const ageAll = [0, 0, 0, 0, 0]; for (const m of matRows) m.age.forEach((v: number, i: number) => (ageAll[i] += v));
  // accounts against the CRM
  const { withSap, cards, master } = cardLinks();
  const ctok = cards.filter((c) => !c.sap).map((c) => ({ c, t: new Set(norm(c.company)) })).filter((x) => x.t.size);
  const suggest = (name: string) => { const t = new Set(norm(name)); if (!t.size) return null; let best: any = null, bs = 0; for (const x of ctok) { let i = 0; for (const w of t) if (x.t.has(w)) i++; const s = i / (t.size + x.t.size - i); if (s > bs) { bs = s; best = x.c; } } return bs >= 0.6 ? { id: best.id, name: best.company, country: best.country || '', score: r3(bs) } : null; };
  const acc = new Map<string, any>();
  const A = (code: string, name: string) => { let a = acc.get(code); if (!a) { a = { code, name: name || '', l12: 0, all: 0, last: '', stockRes: 0, stockStr: 0, open: 0, openEur: 0, late: 0 }; acc.set(code, a); } if (name && !a.name) a.name = name; return a; };
  for (const [c, o] of cs) { const a = A(c, o.name); a.l12 = o.l12; a.all = o.all; a.last = o.last; }
  for (const l of lots) if (!l.own && l.cust && l.dc !== 'sample') { const a = A(l.cust, l.cname); if (l.reserved) a.stockRes += l.q; else a.stockStr += l.q; }
  for (const o of orders) { const a = A(o.cust, o.cname); a.open += o.pend; a.openEur += o.eur || 0; if (o.late > 0) a.late += o.pend; }
  const accounts = [...acc.values()].filter((a) => a.code && a.code !== OWN && !/^(2000|Z000)$/.test(a.code) && !excludedCodes().has(a.code)).map((a) => {
    const card = withSap.get(a.code); const sg = card ? null : suggest(a.name);
    return { ...a, l12: r0(a.l12), all: r0(a.all), stockRes: r0(a.stockRes), stockStr: r0(a.stockStr), open: r0(a.open), openEur: r0(a.openEur), late: r0(a.late), master: master.has(a.code) ? 1 : 0, mcountry: master.get(a.code)?.country ?? '', card: card ?? null, sug: sg };
  });
  const rel_ = accounts.filter((a) => a.l12 > 0 || a.open > 0 || a.stockRes + a.stockStr > 0 || a.all >= 5000); const unl = rel_.filter((a) => !a.card);
  const imp = (a: any) => a.open * 0.1 + a.l12 + a.all * 0.1 + (a.stockRes + a.stockStr) * 0.02; unl.sort((a, b) => imp(b) - imp(a));
  const cidx = new Map<string, number>(); const custList: any[] = []; const ci = (code: string, name: string) => { if (!cidx.has(code)) { cidx.set(code, custList.length); custList.push([code, name, withSap.has(code) ? 1 : 0]); } return cidx.get(code)!; };
  const midx = new Map<string, number>(); const matList: any[] = []; const mi = (m: string, d: string) => { if (!midx.has(m)) { midx.set(m, matList.length); matList.push([m, d]); } return midx.get(m)!; };
  const ordOut = sorted.map((o) => [ci(o.cust, o.cname), o.so, o.item, mi(o.mat, o.desc), o.th, o.w, o.rl, r0(o.pend), r0(o.rShip + o.fShip), r0(o.rCut + o.fCut), r0(o.str + o.unv + o.rCnt), r0(o.make), o.del, o.late, o.st, r0(o.eur || 0)]);
  const strBy = new Map<string, any>(); for (const l of lots) if (l.stranded && l.cust && (l.dc === 'ship' || l.dc === 'cut')) { const o = strBy.get(l.cust) || { name: l.cname, q: 0, old: 0, eur: 0 }; o.q += l.q; if ((l.age ?? 9999) > 365) o.old += l.q; o.eur += l.q * priceOf(l.mat); strBy.set(l.cust, o); }
  const strand = [...strBy].map(([c, o]) => ({ c, name: o.name, q: r0(o.q), old: r0(o.old), eur: r0(o.eur), card: withSap.has(c) ? 1 : 0 })).sort((a, b) => b.q - a.q).slice(0, 40);
  const gap = new Map<string, any>(); for (const o of orders) if (o.make > 0) { const k = o.mat + '|' + o.th + '|' + o.w + '|' + o.rl; const g = gap.get(k) || { mat: o.mat, desc: o.desc, th: o.th, w: o.w, rl: o.rl, make: 0, lines: 0, first: o.del }; g.make += o.make; g.lines++; if (o.del && o.del < g.first) g.first = o.del; gap.set(k, g); }
  return {
    cut: today, tot, ot, health: { m: Object.fromEntries(Object.entries(H).map(([k, v]) => [k, r0(v)])), eur: Object.fromEntries(Object.entries(HV).map(([k, v]) => [k, r0(v)])), healthy, heavy, excess, eurH: val((m) => m.h), eurV: val((m) => m.hv), eurE: val((m) => m.avail - m.h - m.hv), age: ageAll.map(r0) },
    mats: matRows.slice(0, 900), nMats: matRows.length, cust: custList, mat: matList, orders: ordOut, strand,
    gap: [...gap.values()].sort((a, b) => b.make - a.make).slice(0, 60).map((g) => ({ ...g, make: r0(g.make) })),
    accounts: unl.slice(0, 250).map((a) => ({ c: a.code, n: a.name, l12: a.l12, all: a.all, res: a.stockRes, str: a.stockStr, open: a.open, late: a.late, m: a.master, mc: a.mcountry, s: a.sug })),
    link: { seen: accounts.length, relevant: rel_.length, connected: rel_.length - unl.length, notConnected: unl.length, openOrderAccounts: unl.filter((a) => a.open > 0).length, l12Unlinked: r0(sum(unl, (a) => a.l12)), l12All: r0(sum(rel_, (a) => a.l12)), master: unl.filter((a) => a.master).length, cards: cards.length, cardsWithSap: withSap.size, withSuggestion: unl.filter((a) => a.sug).length },
    stockLots: lots.length, ordersLoaded: orders.length,
  };
}

// ---------------------------------------------------------------- the bundle
export interface Bundle { built: string; cut: string; hasSales: boolean; hasStock: boolean; hasKartela: boolean; D: any; D2: any; D3: any; links: Record<string, number>; excluded?: ReturnType<typeof listExcluded> }

export function status() {
  const s = db.prepare('SELECT COUNT(*) n, MIN(first_date) a, MAX(last_date) b FROM intel_cust').get() as any; const fr = db.prepare('SELECT COUNT(*) n FROM intel_fact').get() as any;
  const st = db.prepare('SELECT COUNT(*) n FROM intel_stock').get() as any, k = db.prepare('SELECT COUNT(*) n FROM intel_kartela').get() as any;
  const bl = db.prepare("SELECT COUNT(*) n FROM export_production_backlog WHERE unit = 'M' AND width > 0 AND width < 100").get() as any;
  const ups = db.prepare('SELECT u.id, u.kind, u.file_name, u.rows, u.added, u.note, u.at, COALESCE(NULLIF(x.display_name, \'\'), x.username) by_name FROM intel_uploads u LEFT JOIN users x ON x.id = u.by_user ORDER BY u.id DESC LIMIT 15').all();
  const built = db.prepare("SELECT built_at FROM intel_cache WHERE key = 'bundle'").get() as any;
  return { sales: { customers: s.n, rows: fr.n, from: s.a, to: s.b }, stock: { lots: st.n }, kartela: { rows: k.n }, backlog: { lines: bl.n }, uploads: ups, builtAt: built?.built_at ?? null };
}

let building: Promise<Bundle> | null = null;
export function getBundle(force = false): Promise<Bundle> {
  if (!force) { const c = db.prepare("SELECT body FROM intel_cache WHERE key = 'bundle'").get() as any; if (c) { const j = JSON.parse(c.body); if (j?.D?.cm) return Promise.resolve(j); } } // a bundle made before the period picker has no customer-by-month rows: build it again once
  if (building) return building;
  building = new Promise<Bundle>((resolve, reject) => {
    // let the server answer other people first, then work
    setImmediate(() => {
      try {
        const L = loadLines(); if (!L.length) throw new Error('No sales yet: load the history and upload the sales list first.');
        const W = windows(); const cut = W.cut;
        const { _dg, _topG, ...D } = buildSales(L, W) as any;
        const hasK = (db.prepare('SELECT COUNT(*) n FROM intel_kartela').get() as any).n > 0, hasS = (db.prepare('SELECT COUNT(*) n FROM intel_stock').get() as any).n > 0;
        const D2 = buildColour(L, W, _dg, _topG);
        const today = new Date().toISOString().slice(0, 10);
        const D3 = hasS ? buildStock(L, W, today) : null;
        const { withSap } = cardLinks(); const links: Record<string, number> = {}; for (const [k, v] of withSap) links[k] = v.id;
        const b: Bundle = { built: new Date().toISOString(), cut, hasSales: true, hasStock: hasS, hasKartela: hasK, D, D2, D3, links, excluded: listExcluded() };
        db.prepare("INSERT INTO intel_cache (key, body, built_at) VALUES ('bundle', ?, datetime('now')) ON CONFLICT(key) DO UPDATE SET body = excluded.body, built_at = excluded.built_at").run(JSON.stringify(b));
        resolve(b);
      } catch (e) { reject(e); } finally { building = null; }
    });
  });
  return building;
}
