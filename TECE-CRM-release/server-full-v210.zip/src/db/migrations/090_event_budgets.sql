-- A budget for each trip and each fair: what is planned per kind of cost (in EUR). What was really spent comes from the
-- expenses of the marketing budget that carry the trip or the fair, so the two always add up to the same report.
CREATE TABLE IF NOT EXISTS event_budgets (
  kind TEXT NOT NULL CHECK (kind IN ('trip', 'exhibition')),
  ref_id INTEGER NOT NULL,
  category TEXT NOT NULL,
  planned_eur REAL NOT NULL DEFAULT 0,
  note TEXT,
  updated_by INTEGER,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (kind, ref_id, category)
);
-- which kind of cost an expense is, inside its trip or fair (flights, hotel, stand ...)
ALTER TABLE budget_expenses ADD COLUMN event_category TEXT;
CREATE INDEX IF NOT EXISTS idx_budget_expenses_trip ON budget_expenses(trip_id);
CREATE INDEX IF NOT EXISTS idx_budget_expenses_exhibition ON budget_expenses(exhibition_id);

-- the dare a person took for a day ("push": 1.5x the goal, "beast": 2x, "record": beat the best day)
CREATE TABLE IF NOT EXISTS day_dares (
  user_id INTEGER NOT NULL,
  day TEXT NOT NULL,
  level TEXT NOT NULL,
  target INTEGER NOT NULL,
  taken_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, day)
);

-- working through the visitors of a fair: a visitor can be parked ("not now") or closed ("nothing to do here") by a person
CREATE TABLE IF NOT EXISTS fair_focus_state (
  user_id INTEGER NOT NULL,
  card_id INTEGER NOT NULL,
  state TEXT NOT NULL CHECK (state IN ('later', 'closed')),
  until TEXT,
  at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, card_id)
);
CREATE INDEX IF NOT EXISTS idx_cards_exhibition ON cards(exhibition_id);
