-- What the AI made of the visitor's notes (next steps, offer wanted, reminder), as JSON.
ALTER TABLE cards ADD COLUMN ai_insight TEXT;
