import type { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { env } from '../config/env';
import { userModel, type PublicUser } from '../models/userModel';
import { aiContext } from '../services/aiGate';
import { viewMode } from '../services/viewMode';
import { permsOf, blockedByPerms, hasAction, type Perms } from '../services/permissions';

const COOKIE_NAME = 'session';

export interface AuthedRequest extends Request {
  // the person the work is done as (for an assistant: the person they assist, without admin rights)
  user?: PublicUser;
  // who really signed in, when that is an assistant
  actor?: PublicUser;
}

export function signToken(userId: number): string {
  return jwt.sign({ userId }, env.jwtSecret, { expiresIn: '12h' });
}

export function setSessionCookie(res: Response, token: string) {
  res.cookie(COOKIE_NAME, token, {
    httpOnly: true,
    secure: env.isProduction,
    sameSite: 'lax',
    maxAge: 12 * 60 * 60 * 1000,
  });
}

export function clearSessionCookie(res: Response) {
  res.clearCookie(COOKIE_NAME);
}

const AREA_OK = ['/api/auth', '/api/quality', '/api/users', '/api/usage', '/api/help'];

export function requireAuth(req: AuthedRequest, res: Response, next: NextFunction) {
  const token = req.cookies?.[COOKIE_NAME];
  if (!token) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  try {
    const payload = jwt.verify(token, env.jwtSecret) as { userId: number };
    const user = userModel.findPublicById(payload.userId);
    if (!user || !user.is_active || user.is_assistant) {
      return res.status(401).json({ error: 'Not authenticated' });
    }
    req.user = user;
    if (user.assists_id) {
      const boss = userModel.findPublicById(user.assists_id);
      if (!boss || !boss.is_active) return res.status(401).json({ error: 'Not authenticated' });
      req.actor = user;
      req.user = { ...boss, role: boss.role === 'admin' ? 'user' : boss.role, can_oversee: 0 };
    }
    // menu / money / actions switched on for this person by an admin (a person without a row keeps what they had)
    // an assistant works as the person they assist, but the switches an admin set for the assistant herself decide what SHE sees:
    // before this, only the row of the person they work for was read, so the assistant's own switches did nothing
    (req.user as { perms?: Perms | null }).perms = (req.actor ? permsOf({ id: req.actor.id, role: 'user' }) : null) ?? permsOf(req.user);
    const blocked = blockedByPerms(req.user as PublicUser & { perms?: Perms | null }, req.baseUrl, req.originalUrl);
    if (blocked) return res.status(403).json({ error: blocked });
    // the quality person and the heads of departments reach the complaints module (and their own account) - no customers, no prices, no ledger
    // (a person the admin gave permissions to is no longer held to this: their switches decide)
    if (req.user.area && req.user.area !== 'brand' && !(req.user as { perms?: Perms | null }).perms && !AREA_OK.some((p) => req.baseUrl === p || req.baseUrl.startsWith(`${p}/`))) {
      return res.status(403).json({ error: 'This login is for the complaints module only.' });
    }
    // whatever the AI is asked during this request (also by a background job it starts) is booked on this person
    // the Salesperson / Manager switch: the browser says which one it is in
    const manager = req.headers['x-view-mode'] === 'manager' && !req.actor && (!req.user.area || req.user.area === 'brand');
    viewMode.run(req.user.id, manager, () => aiContext.run({ userId: req.user!.id }, () => next()));
  } catch {
    return res.status(401).json({ error: 'Not authenticated' });
  }
}

// an admin, or a person the admin switched this action on for (Permissions page)
export function requireAdminOr(action: string) {
  return (req: AuthedRequest, res: Response, next: NextFunction) => {
    if (!hasAction(req.user as never, action)) return res.status(403).json({ error: 'Admin only' });
    next();
  };
}

export function requireAdmin(req: AuthedRequest, res: Response, next: NextFunction) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Admin only' });
  }
  next();
}
