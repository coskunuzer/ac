-- Round 5: payment terms per customer, and the new sales pipeline (6 prospect stages, 3 exit states, a structured lead source).
CREATE TABLE IF NOT EXISTS perf_terms (
  sap_no TEXT PRIMARY KEY,
  days INTEGER NOT NULL,
  at TEXT NOT NULL DEFAULT (datetime('now'))
);

ALTER TABLE cards ADD COLUMN pipeline_stage INTEGER;       -- 1..6 while there is no SAP number
ALTER TABLE cards ADD COLUMN exit_status TEXT;             -- NULL | on_hold | lost | disqualified
ALTER TABLE cards ADD COLUMN exit_reason TEXT;
ALTER TABLE cards ADD COLUMN exit_note TEXT;
ALTER TABLE cards ADD COLUMN follow_up_date TEXT;
ALTER TABLE cards ADD COLUMN lead_source TEXT;

-- the old stages become the new ones: New lead -> 1, Contacted -> 2, Interested -> 3, Offer sent -> 5; Lost -> the exit state "lost"
UPDATE cards SET pipeline_stage = 1 WHERE COALESCE(stage, '') IN ('', 'lead');
UPDATE cards SET pipeline_stage = 2 WHERE stage = 'contacted';
UPDATE cards SET pipeline_stage = 3 WHERE stage = 'interested';
UPDATE cards SET pipeline_stage = 5 WHERE stage = 'quoted';
UPDATE cards SET pipeline_stage = 6 WHERE stage = 'customer';
UPDATE cards SET exit_status = 'lost', exit_reason = 'Unresponsive', pipeline_stage = COALESCE(pipeline_stage, 2) WHERE stage = 'lost';

-- "where we met" (cards.source) becomes the structured lead source
UPDATE cards SET lead_source = 'Trade Fair - Interzum / Other' WHERE source = 'fair';
UPDATE cards SET lead_source = 'Website / Inbound Inquiry' WHERE source = 'website';
UPDATE cards SET lead_source = 'Referral / Distributor' WHERE source = 'referral';
UPDATE cards SET lead_source = 'AI Lead Scoring / Outbound' WHERE source = 'database';
UPDATE cards SET lead_source = 'Direct Contact / Cold Call' WHERE source IN ('visit', 'email', 'call', 'other');

-- a customer with a SAP number is a customer (the pipeline bar is replaced by the account health)
UPDATE cards SET stage = 'customer', pipeline_stage = 6 WHERE TRIM(COALESCE(sap, '')) != '' AND COALESCE(stage, '') != 'customer';

-- a customer scanned at a fair gets that fair as its lead source (a trigger for every new record, and once for the old ones)
UPDATE cards SET lead_source = 'Trade Fair - ' || (SELECT name FROM exhibitions e WHERE e.id = cards.exhibition_id)
  WHERE lead_source IS NULL AND exhibition_id IN (SELECT id FROM exhibitions WHERE name NOT IN ('Direct contacts', 'Domestic customers'));
CREATE TRIGGER IF NOT EXISTS cards_lead_source AFTER INSERT ON cards WHEN NEW.lead_source IS NULL
BEGIN
  UPDATE cards SET lead_source = 'Trade Fair - ' || (SELECT name FROM exhibitions e WHERE e.id = NEW.exhibition_id)
    WHERE id = NEW.id AND NEW.exhibition_id IN (SELECT id FROM exhibitions WHERE name NOT IN ('Direct contacts', 'Domestic customers'));
END;
