import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import { userModel, type PublicUser } from '../models/userModel';

// An assistant (or a sales person without a login) is a row in the users table that can never sign in: it gets a
// placeholder username and a password nobody knows, and login is refused for
// anything flagged is_assistant. It exists so the person has a name and an
// email address to be copied on thank-you emails.
export function createAssistant(displayName: string, email: string | null, kind: 'assistant' | 'sales' = 'assistant'): PublicUser {
  const slug = displayName
    .normalize('NFD')
    .replace(/\p{Diacritic}/gu, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 30) || 'assistant';
  const prefix = kind === 'sales' ? 'sales' : 'assistant';
  let username = `${prefix}-${slug}`;
  for (let n = 2; userModel.findByUsername(username); n++) username = `${prefix}-${slug}-${n}`;
  const unusablePassword = bcrypt.hashSync(crypto.randomBytes(24).toString('hex'), 10);
  return userModel.create({ username, passwordHash: unusablePassword, role: 'user', displayName, email: email ?? undefined, isAssistant: true, isSalesContact: kind === 'sales' });
}
