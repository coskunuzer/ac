import type { PublicUser } from '../models/userModel';
import { settingsModel } from '../models/settingsModel';

// The company lines are the same under every email; the name, title and phone
// numbers come from the person who sends it.
export const COMPANY_NAME_LINE = 'TECE DEKOR || The Edgebanding Company';
export const COMPANY_ADDRESS_LINE = 'BOSB 75. Yil Bulv. No:12, Nilufer, Bursa, 16140 Türkiye';
export const COMPANY_SITE = 'tece.com.tr';
export const COMPANY_SLOGAN = 'Your Global Partner in Edgebanding';

export interface Signature {
  text: string;
  html: string;
}

type Sender = Pick<PublicUser, 'display_name' | 'job_title' | 'mobile' | 'office_phone' | 'username'> & { signature_text?: string | null };

export const SIGNATURE_STYLES = [
  { id: 'classic', label: 'Classic', description: 'Name and title, then the company block with phones, address and website.' },
  { id: 'compact', label: 'Compact', description: 'Four short lines: name and title, company, phones, website.' },
  { id: 'formal', label: 'Formal', description: 'Name, title, company and slogan, then phones, address and website on separate lines.' },
] as const;

export type SignatureStyle = (typeof SIGNATURE_STYLES)[number]['id'];
const STYLE_IDS = new Set<string>(SIGNATURE_STYLES.map((s) => s.id));

export function isSignatureStyle(value: unknown): value is SignatureStyle {
  return typeof value === 'string' && STYLE_IDS.has(value);
}

export function defaultSignatureStyle(): SignatureStyle {
  const stored = settingsModel.get('signature_style');
  return isSignatureStyle(stored) ? stored : 'classic';
}

// A person's own choice wins; otherwise the company default.
export function styleFor(user: { signature_style?: string | null } | undefined): SignatureStyle {
  return isSignatureStyle(user?.signature_style) ? user!.signature_style : defaultSignatureStyle();
}

const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

// A signature is groups of lines; groups are separated by a blank line. A line
// can be bold, or the website (a link) in the HTML version.
interface Line {
  text: string;
  bold?: boolean;
  site?: boolean;
}

function render(groups: Line[][]): Signature {
  const clean = groups.map((g) => g.filter((l) => l.text)).filter((g) => g.length);
  const text = clean.map((g) => g.map((l) => l.text).join('\n')).join('\n\n');
  const base = 'font-family:Calibri,Arial,sans-serif;font-size:14px;color:#17243e;margin:0;line-height:1.45';
  const html =
    `<div style="${base}">` +
    clean
      .map((g, gi) => {
        const lines = g
          .map((l) => {
            if (l.site) return `${l.text.startsWith('Visit ') ? 'Visit ' : ''}<a href="https://${COMPANY_SITE}" style="color:#8c1c2c">${COMPANY_SITE}</a>`;
            return l.bold ? `<strong>${esc(l.text)}</strong>` : esc(l.text);
          })
          .join('<br>');
        return `<p style="${base};${gi < clean.length - 1 ? 'margin-bottom:12px' : 'font-size:13px'}">${lines}</p>`;
      })
      .join('') +
    '</div>';
  return { text, html };
}

// A signature the person wrote themselves: blank lines separate paragraphs, **bold** works, and
// web addresses and e-mail addresses become links.
function renderCustom(raw: string): Signature {
  const text = raw.replace(/\r\n/g, '\n').trim();
  const base = 'font-family:Calibri,Arial,sans-serif;font-size:14px;color:#17243e;margin:0;line-height:1.45';
  const inline = (line: string) =>
    esc(line)
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/\b(https?:\/\/[^\s<]+)/g, '<a href="$1" style="color:#8c1c2c">$1</a>')
      .replace(/([\w.+-]+@[\w-]+(?:\.[\w-]+)+)/g, '<a href="mailto:$1" style="color:#8c1c2c">$1</a>')
      .replace(/(^|[\s>])((?:www\.)?tece\.com\.tr)\b/g, '$1<a href="https://$2" style="color:#8c1c2c">$2</a>');
  const blocks = text.split(/\n{2,}/);
  const html =
    `<div style="${base}">` +
    blocks.map((b, i) => `<p style="${base};${i < blocks.length - 1 ? 'margin-bottom:12px' : 'font-size:13px'}">${b.split('\n').map(inline).join('<br>')}</p>`).join('') +
    '</div>';
  return { text: text.replace(/\*\*(.+?)\*\*/g, '$1'), html };
}

export function buildSignature(sender: Sender | undefined, style: SignatureStyle = defaultSignatureStyle()): Signature {
  if (sender?.signature_text?.trim()) return renderCustom(sender.signature_text);
  const name = (sender?.display_name || sender?.username || '').toUpperCase();
  const mobile = sender?.mobile ? `Mobile: ${sender.mobile}` : '';
  const office = sender?.office_phone ? `Office: ${sender.office_phone}` : '';
  const title = sender?.job_title ?? '';
  const site = { text: `Visit ${COMPANY_SITE}`, site: true };

  if (style === 'compact') {
    const nameLine = [sender?.display_name || sender?.username || '', title].filter(Boolean).join(', ');
    return render([
      [
        { text: nameLine, bold: true },
        { text: COMPANY_NAME_LINE },
        { text: [mobile, office].filter(Boolean).join('  |  ') },
        { text: COMPANY_SITE, site: true },
      ],
    ]);
  }
  if (style === 'formal') {
    return render([
      [{ text: name, bold: true }, { text: title }],
      [{ text: COMPANY_NAME_LINE, bold: true }, { text: COMPANY_SLOGAN }],
      [{ text: mobile }, { text: office }, { text: COMPANY_ADDRESS_LINE }, site],
    ]);
  }
  // classic
  return render([
    [{ text: name, bold: true }, { text: title }],
    [{ text: COMPANY_NAME_LINE, bold: true }, { text: [mobile, office].filter(Boolean).join('    ') }, { text: COMPANY_ADDRESS_LINE }, site],
  ]);
}
