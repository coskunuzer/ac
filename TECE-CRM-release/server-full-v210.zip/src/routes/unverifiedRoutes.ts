import { Router, type Response, type NextFunction } from 'express';
import multer from 'multer';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { apply, cleanCriteria, download, mayUse, preview, summary, UvError } from '../services/unverified';

// Unverified customers (customers that are just a name): admins and the brand manager download the list, delete the rows of companies that do
// not exist, complete the others, and upload the file back. See services/unverified.ts.
const router = Router();
router.use(requireAuth, (req: AuthedRequest, res: Response, next: NextFunction) => {
  if (!mayUse(req.user as never, req.actor)) return res.status(403).json({ error: 'Only an admin or the brand manager can clean up unverified customers.' });
  next();
});
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 15 * 1024 * 1024 } });
const fail = (res: Response, err: unknown) => {
  if (err instanceof UvError) return res.status(err.status).json({ error: err.message });
  console.error('Unverified customers:', err);
  return res.status(500).json({ error: 'Something went wrong. Nothing was changed.' });
};

// how many customers match the rules and filters, a sample, and the choices of the filters
router.post('/summary', (req: AuthedRequest, res) => {
  try { res.json(summary(req.user!, cleanCriteria(req.body))); } catch (err) { fail(res, err); }
});

// the Excel file (kept as a batch: only the customers in it can be deleted by uploading it back)
router.post('/download', async (req: AuthedRequest, res) => {
  try {
    const out = await download(req.user!, cleanCriteria(req.body), req.body?.lang === 'tr' || (req.body?.lang !== 'en' && req.user!.ui_language === 'tr') ? 'tr' : 'en');
    if (!out.rows) return res.status(400).json({ error: 'No customer matches these rules: nothing to download.' });
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="unverified-customers-${out.batchId}.xlsx"`);
    res.setHeader('X-Batch-Id', String(out.batchId));
    res.send(out.buffer);
  } catch (err) { fail(res, err); }
});

// read the file back: what would happen (nothing is changed)
router.post('/preview', upload.single('file'), async (req: AuthedRequest, res) => {
  if (!req.file) return res.status(400).json({ error: 'Choose the Excel file first.' });
  try { res.json(await preview(req.user!, req.file.buffer)); } catch (err) { fail(res, err); }
});

// do it: complete, add the notes, move the missing ones to the junk folder
router.post('/apply', (req: AuthedRequest, res) => {
  const id = typeof req.body?.previewId === 'string' ? req.body.previewId : '';
  try { res.json(apply(req.user!, id, req.body?.confirm)); } catch (err) { fail(res, err); }
});

export default router;
