import { db } from '../db/connection';
import { settingsModel } from '../models/settingsModel';
import { userModel } from '../models/userModel';
import { descendants } from './team';
import { memoByData } from '../db/dataVersion';

// Points for the mission board: every useful thing a salesperson does earns points; a daily goal, daily challenges, a level, a weekly
// ranking and badges make it a game. Nothing is stored per person - it is all worked out from the activities, so the weights can be changed.

export interface PointType { key: string; label: string; points: number }
export const POINT_TYPES: PointType[] = [
  { key: 'note', label: 'A note about a customer', points: 1 },
  { key: 'call', label: 'A call', points: 2 },
  { key: 'visit', label: 'A visit', points: 4 },
  { key: 'meeting', label: 'A meeting', points: 3 },
  { key: 'sample', label: 'A sample sent', points: 3 },
  { key: 'offer', label: 'An offer sent', points: 5 },
  { key: 'thank_you', label: 'A thank-you sent', points: 2 },
  { key: 'email', label: 'A personal e-mail sent', points: 2 },
  { key: 'documents', label: 'Documents sent', points: 2 },
  { key: 'created', label: 'A new customer typed in', points: 3 },
  { key: 'scan', label: 'A new customer scanned', points: 3 },
  { key: 'rated', label: 'A customer rated', points: 1 },
  { key: 'bulgaria', label: 'A contact passed to Bulgaria', points: 2 },
  { key: 'todo', label: 'A to-do done', points: 2 },
  { key: 'explore', label: 'The daily 30 minutes in the lead list', points: 5 },
  { key: 'challenge', label: 'Each daily challenge done', points: 5 },
];

export interface GameSettings { weights: Record<string, number>; goalDay: number; capDay: number; message: string; messageWeekly: string; messageMonthly: string; celebrateMin: number }

export const DEFAULT_MESSAGE = 'You were the most active person of the team yesterday. Thank you - the whole management is proud of you!';
export const DEFAULT_MESSAGE_WEEKLY = 'You were the most active person of the team last week. Thank you - the whole management is proud of you!';
export const DEFAULT_MESSAGE_MONTHLY = 'You were the most active person of the team last month. Thank you - the whole management is proud of you!';

const num = (v: string | null, def: number, min: number, max: number) => {
  const n = parseInt(v ?? '', 10);
  return Number.isFinite(n) ? Math.max(min, Math.min(max, n)) : def;
};

export function gameSettings(): GameSettings {
  let saved: Record<string, unknown> = {};
  try { saved = JSON.parse(settingsModel.get('points_weights') ?? '{}'); } catch { saved = {}; }
  const weights: Record<string, number> = {};
  for (const p of POINT_TYPES) {
    const v = Number(saved[p.key]);
    weights[p.key] = Number.isFinite(v) && v >= 0 && v <= 100 ? Math.round(v) : p.points;
  }
  return {
    weights,
    goalDay: num(settingsModel.get('points_goal_day'), 20, 1, 500),
    capDay: num(settingsModel.get('points_cap_day'), 150, 10, 2000),
    message: settingsModel.get('management_message') || DEFAULT_MESSAGE,
    messageWeekly: settingsModel.get('management_message_weekly') || DEFAULT_MESSAGE_WEEKLY,
    messageMonthly: settingsModel.get('management_message_monthly') || DEFAULT_MESSAGE_MONTHLY,
    celebrateMin: num(settingsModel.get('celebrate_min'), 10, 1, 500),
  };
}

export function saveGameSettings(input: Partial<GameSettings>): GameSettings {
  if (input.weights) {
    const clean: Record<string, number> = {};
    for (const p of POINT_TYPES) {
      const v = Number(input.weights[p.key]);
      if (Number.isFinite(v) && v >= 0 && v <= 100) clean[p.key] = Math.round(v);
    }
    settingsModel.set('points_weights', JSON.stringify(clean));
  }
  if (input.goalDay !== undefined) settingsModel.set('points_goal_day', String(num(String(input.goalDay), 20, 1, 500)));
  if (input.capDay !== undefined) settingsModel.set('points_cap_day', String(num(String(input.capDay), 150, 10, 2000)));
  if (input.celebrateMin !== undefined) settingsModel.set('celebrate_min', String(num(String(input.celebrateMin), 10, 1, 500)));
  if (input.message !== undefined) settingsModel.set('management_message', String(input.message).trim().slice(0, 500));
  if (input.messageWeekly !== undefined) settingsModel.set('management_message_weekly', String(input.messageWeekly).trim().slice(0, 500));
  if (input.messageMonthly !== undefined) settingsModel.set('management_message_monthly', String(input.messageMonthly).trim().slice(0, 500));
  return gameSettings();
}

// ---- days (Istanbul) -----------------------------------------------------------------------------------------------------------
export const todayIst = (): string => new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });
const shift = (d: string, by: number): string => {
  const x = new Date(`${d}T12:00:00Z`);
  x.setUTCDate(x.getUTCDate() + by);
  return x.toISOString().slice(0, 10);
};
const dow = (d: string): number => new Date(`${d}T12:00:00Z`).getUTCDay();
const isWorkday = (d: string) => dow(d) !== 0 && dow(d) !== 6;
const dayNumber = (d: string): number => Math.floor(Date.parse(`${d}T12:00:00Z`) / 86400000);
export const weekStart = (d: string): string => shift(d, -((dow(d) + 6) % 7));

// the last working day before `d` (Monday -> Friday)
export function previousWorkday(d: string): string {
  let x = shift(d, -1);
  while (!isWorkday(x)) x = shift(x, -1);
  return x;
}

// ---- what happened on a day -------------------------------------------------------------------------------------------------------
type Counts = Record<string, number>;
const HUMAN = ['note', 'call', 'visit', 'meeting', 'sample'];

// counts per person and day: key `${userId}|${day}` -> {type: n, todo: n, exploreMin: n}
function load(from: string, to: string, userId?: number): Map<string, Counts> {
  const map = new Map<string, Counts>();
  const bump = (u: number, d: string, k: string, n: number) => {
    const key = `${u}|${d}`;
    const c = map.get(key) ?? {};
    c[k] = (c[k] ?? 0) + n;
    map.set(key, c);
  };
  const who = userId ? ' AND user_id = @u' : '';
  const p: Record<string, string | number> = userId ? { from, to, u: userId } : { from, to };
  for (const r of db
    .prepare(`SELECT user_id, date(datetime(created_at, '+3 hours')) AS d, type, COUNT(*) AS n FROM activities WHERE imported = 0${who} AND date(datetime(created_at, '+3 hours')) BETWEEN @from AND @to GROUP BY user_id, d, type`)
    .all(p) as { user_id: number; d: string; type: string; n: number }[]) bump(r.user_id, r.d, r.type, r.n);
  for (const r of db
    .prepare(`SELECT user_id, date(datetime(done_at, '+3 hours')) AS d, COUNT(*) AS n FROM todos WHERE done_at IS NOT NULL${who} AND date(datetime(done_at, '+3 hours')) BETWEEN @from AND @to GROUP BY user_id, d`)
    .all(p) as { user_id: number; d: string; n: number }[]) bump(r.user_id, r.d, 'todo', r.n);
  for (const r of db
    .prepare(`SELECT user_id, day AS d, minutes FROM daily_explore WHERE day BETWEEN @from AND @to${who}`)
    .all(p) as { user_id: number; d: string; minutes: number }[]) bump(r.user_id, r.d, 'exploreMin', r.minutes);
  return map;
}

// ---- the three challenges of a day (the same for a person all day, different from day to day) ------------------------------
interface ChallengeDef { key: string; text: string; target: number; count: (c: Counts) => number }
const c = (x: Counts, ...k: string[]) => k.reduce((a, b) => a + (x[b] ?? 0), 0);
const CHALLENGES: ChallengeDef[] = [
  { key: 'notes3', text: 'Write 3 notes about customers', target: 3, count: (x) => c(x, 'note', 'call', 'meeting') },
  { key: 'visit1', text: 'Visit or meet a customer', target: 1, count: (x) => c(x, 'visit', 'meeting') },
  { key: 'offer1', text: 'Send an offer', target: 1, count: (x) => c(x, 'offer') },
  { key: 'rate3', text: 'Rate 3 customers', target: 3, count: (x) => c(x, 'rated') },
  { key: 'new2', text: 'Add 2 new customers', target: 2, count: (x) => c(x, 'created', 'scan') },
  { key: 'explore', text: 'Explore the lead list for 30 minutes', target: 30, count: (x) => c(x, 'exploreMin') },
  { key: 'todo2', text: 'Finish 2 to-dos', target: 2, count: (x) => c(x, 'todo') },
  { key: 'mail2', text: 'Send 2 e-mails to customers', target: 2, count: (x) => c(x, 'thank_you', 'email', 'documents', 'offer') },
];
export function challengesFor(userId: number, day: string, counts: Counts) {
  const start = (userId * 7 + dayNumber(day)) % CHALLENGES.length;
  return [0, 3, 5].map((o) => {
    const d = CHALLENGES[(start + o) % CHALLENGES.length];
    const n = Math.min(d.target, d.count(counts));
    return { key: d.key, text: d.text, n, target: d.target, done: n >= d.target };
  });
}

export interface DayScore { points: number; base: number; bonus: number; challenges: ReturnType<typeof challengesFor>; capped: boolean }
export function scoreDay(userId: number, day: string, counts: Counts | undefined, s: GameSettings): DayScore {
  const x = counts ?? {};
  let base = 0;
  for (const p of POINT_TYPES) {
    if (p.key === 'challenge' || p.key === 'explore') continue;
    base += (x[p.key] ?? 0) * s.weights[p.key];
  }
  base += Math.round(s.weights.explore * Math.min(1, (x.exploreMin ?? 0) / 30));
  const challenges = challengesFor(userId, day, x);
  const bonus = challenges.filter((q) => q.done).length * s.weights.challenge;
  const raw = base + bonus;
  return { points: Math.min(raw, s.capDay), base, bonus, challenges, capped: raw > s.capDay };
}

// the points of some people over a period of days (the team overview)
export function pointsBetween(userIds: number[], from: string, to: string): Map<number, number> {
  const s = gameSettings();
  const counts = load(from, to);
  const out = new Map<number, number>();
  for (const id of userIds) {
    let sum = 0;
    for (let d = from; d <= to; d = shift(d, 1)) sum += scoreDay(id, d, counts.get(`${id}|${d}`), s).points;
    out.set(id, sum);
  }
  return out;
}

// ---- levels ---------------------------------------------------------------------------------------------------------------------
const LEVELS = ['Rookie', 'Scout', 'Closer', 'Hunter', 'Pro', 'Ace', 'Master', 'Legend'];
const threshold = (level: number) => 25 * level * (level - 1); // level 2 = 50, 3 = 150, 4 = 300 ...
export function levelOf(total: number) {
  let n = 1;
  while (total >= threshold(n + 1)) n += 1;
  const from = threshold(n);
  const next = threshold(n + 1);
  return { n, name: LEVELS[Math.min(n - 1, LEVELS.length - 1)], total, from, next, toNext: next - total, pct: Math.round(((total - from) / (next - from)) * 100) };
}

// ---- the active sales people (the admin is the coordinator, not a player) ------------------------------------------------------
const players = () => userModel.listActive().filter((u) => u.role !== 'admin' && !!u.display_name);

// who was the most active person on a working day: {id, name, points} or null when nobody reached the minimum
export function winnerOf(day: string, s: GameSettings, counts: Map<string, Counts>): { id: number; name: string; points: number } | null {
  let best: { id: number; name: string; points: number } | null = null;
  for (const u of players()) {
    const points = scoreDay(u.id, day, counts.get(`${u.id}|${day}`), s).points;
    if (points >= s.celebrateMin && (!best || points > best.points)) best = { id: u.id, name: u.display_name!, points };
  }
  return best;
}

export function celebrationFor(userId: number, s = gameSettings()) {
  const today = todayIst();
  const day = previousWorkday(today);
  const w = winnerOf(day, s, load(day, day));
  const seen = settingsModel.get(`celebrated:${userId}`);
  return { day, winner: w, show: !!w && w.id === userId && seen !== day, message: s.message };
}
export const markCelebrated = (userId: number, level: Level = 'daily', key?: string): void =>
  settingsModel.set(level === 'daily' ? `celebrated:${userId}` : `celebrated:${level}:${userId}`, key || (level === 'daily' ? previousWorkday(todayIst()) : ''));

// ---- three levels of "the most active person" ---------------------------------------------------------------------------------------
//  daily:   every morning from 8:30 (Istanbul) - the last working day
//  weekly:  every Monday from 8:30 - the seven days before (Monday to Sunday)
//  monthly: on the 1st of the month from 8:30 - the whole month before
// The person who has the most points in the period sees the message of the management (once). A quiet period (under the minimum) has no winner.
export type Level = 'daily' | 'weekly' | 'monthly';
const istMinutes = (): number => {
  const p = new Intl.DateTimeFormat('en-GB', { timeZone: 'Europe/Istanbul', hour: '2-digit', minute: '2-digit', hour12: false }).formatToParts(new Date());
  return parseInt(p.find((x) => x.type === 'hour')!.value, 10) * 60 + parseInt(p.find((x) => x.type === 'minute')!.value, 10);
};

function winnerBetween(from: string, to: string, s: GameSettings): { id: number; name: string; points: number } | null {
  const counts = load(from, to);
  let best: { id: number; name: string; points: number } | null = null;
  for (const u of players()) {
    let points = 0;
    for (let d = from; d <= to; d = shift(d, 1)) points += scoreDay(u.id, d, counts.get(`${u.id}|${d}`), s).points;
    if (points >= s.celebrateMin && (!best || points > best.points)) best = { id: u.id, name: u.display_name!, points };
  }
  return best;
}

export interface LevelCelebration { level: Level; key: string; from: string; to: string; winner: { id: number; name: string; points: number } | null; show: boolean; message: string }

export function celebrationsFor(userId: number, s = gameSettings()): LevelCelebration[] {
  const today = todayIst();
  const ready = istMinutes() >= 8 * 60 + 30;
  const out: LevelCelebration[] = [];

  // daily: the last working day (the key is that day, as before)
  const day = previousWorkday(today);
  out.push({ level: 'daily', key: day, from: day, to: day, winner: winnerBetween(day, day, s), show: false, message: s.message });

  // weekly: the latest Monday whose 8:30 has come
  let monday = weekStart(today);
  if (monday === today && !ready) monday = shift(monday, -7);
  out.push({ level: 'weekly', key: monday, from: shift(monday, -7), to: shift(monday, -1), winner: winnerBetween(shift(monday, -7), shift(monday, -1), s), show: false, message: s.messageWeekly });

  // monthly: the latest 1st whose 8:30 has come; the month before it is the period
  let first = `${today.slice(0, 8)}01`;
  if (first === today && !ready) first = `${shift(first, -1).slice(0, 8)}01`;
  const last = shift(first, -1);
  out.push({ level: 'monthly', key: first, from: `${last.slice(0, 8)}01`, to: last, winner: winnerBetween(`${last.slice(0, 8)}01`, last, s), show: false, message: s.messageMonthly });

  for (const c of out) {
    const seen = settingsModel.get(c.level === 'daily' ? `celebrated:${userId}` : `celebrated:${c.level}:${userId}`);
    // before 8:30 nothing new is announced (the daily one of an earlier morning is already seen)
    c.show = !!c.winner && c.winner.id === userId && seen !== c.key && (ready || c.level !== 'daily' || false);
  }
  return out;
}

// ---- everything for one person --------------------------------------------------------------------------------------------------
export function gameFor(userId: number) {
  const s = gameSettings();
  const today = todayIst();
  const wk = weekStart(today);
  const all = load('2000-01-01', today, userId);
  const mine = (d: string) => scoreDay(userId, d, all.get(`${userId}|${d}`), s);

  // all-time total, the best run of working days, the counts for the badges
  let total = 0;
  const totals: Counts = {};
  const days: string[] = [];
  for (const [key, counts] of all) {
    const d = key.split('|')[1];
    total += scoreDay(userId, d, counts, s).points;
    for (const [k, v] of Object.entries(counts)) totals[k] = (totals[k] ?? 0) + v;
    if (HUMAN.some((k) => (counts[k] ?? 0) > 0)) days.push(d);
  }
  const worked = new Set(days);
  let streak = 0;
  let best = 0;
  let run = 0;
  const first = days.sort()[0];
  if (first) {
    for (let d = first; d <= today; d = shift(d, 1)) {
      if (!isWorkday(d)) continue;
      if (worked.has(d)) { run += 1; best = Math.max(best, run); } else if (d !== today) run = 0;
    }
    run = 0;
    for (let d = today, g = 0; g < 400; d = shift(d, -1), g += 1) {
      if (!isWorkday(d)) continue;
      if (worked.has(d)) streak += 1;
      else if (d !== today) break;
    }
  }
  const doneToday = worked.has(today);

  // the week and the ranking (everybody's points)
  const team = load(shift(today, -35), today);
  // the ranking is among the people who report to this person (and the person): not the whole company
  const circle = new Set<number>([userId, ...descendants(userId).map((d) => d.user.id)]);
  const board = players().filter((u) => circle.has(u.id)).map((u) => {
    let points = 0;
    for (let d = wk; d <= today; d = shift(d, 1)) points += scoreDay(u.id, d, team.get(`${u.id}|${d}`), s).points;
    return { id: u.id, name: u.display_name!, points, today: scoreDay(u.id, today, team.get(`${u.id}|${today}`), s).points };
  }).sort((a, b) => b.points - a.points || a.name.localeCompare(b.name));
  const rank = board.findIndex((b) => b.id === userId) + 1;

  // days won in the last 35 days
  let won = 0;
  for (let d = shift(today, -35); d < today; d = shift(d, 1)) if (isWorkday(d) && winnerOf(d, s, team)?.id === userId) won += 1;

  const t = mine(today);
  const week = Array.from({ length: 7 }, (_, i) => {
    const d = shift(wk, i);
    return { date: d, points: d <= today ? mine(d).points : 0, future: d > today };
  });
  const exploreDone = db.prepare('SELECT COUNT(*) AS n FROM daily_explore WHERE user_id = ? AND done = 1').get(userId) as { n: number };
  const badge = (key: string, label: string, hint: string, n: number, target: number) => ({ key, label, hint, n: Math.min(n, target), target, earned: n >= target });
  const badges = [
    badge('first', 'First step', 'Write your first note', c(totals, ...HUMAN), 1),
    badge('streak5', 'On a roll', '5 working days in a row', best, 5),
    badge('streak20', 'Unstoppable', '20 working days in a row', best, 20),
    badge('visits10', 'Road warrior', '10 visits', totals.visit ?? 0, 10),
    badge('offers10', 'Offer maker', '10 offers sent', totals.offer ?? 0, 10),
    badge('offers50', 'Deal machine', '50 offers sent', totals.offer ?? 0, 50),
    badge('new25', 'Lead hunter', '25 new customers', c(totals, 'created', 'scan'), 25),
    badge('rated25', 'Sharp eye', '25 customers rated', totals.rated ?? 0, 25),
    badge('explore10', 'Explorer', '10 days of exploring the lead list', exploreDone.n, 10),
    badge('won1', 'Top of the day', 'Be the most active person of the team for one day', won, 1),
    badge('points1000', 'Thousand club', '1,000 points', total, 1000),
  ];

  return {
    settings: { goalDay: s.goalDay, capDay: s.capDay, weights: s.weights },
    today: { date: today, points: t.points, goal: s.goalDay, reached: t.points >= s.goalDay, base: t.base, bonus: t.bonus, capped: t.capped, challenges: t.challenges },
    week: { start: wk, points: week.reduce((a, d) => a + d.points, 0), days: week, rank, of: board.length, board },
    level: levelOf(total),
    streak: { days: streak, best, doneToday },
    badges,
    celebration: celebrationFor(userId, s),
    celebrations: celebrationsFor(userId, s),
  };
}


// ---- The challenge: everything that pushes a person a bit further today ---------------------------------------------------------------------------
// Nothing new is counted here - the same points as everywhere - but it is compared: with the person's own best day, with yesterday at this
// hour, with the colleague just ahead this week, and with a dare the person took for today (a higher goal they cannot take back).
export const DARE_LEVELS = ['push', 'beast', 'record'] as const;
export type DareLevel = (typeof DARE_LEVELS)[number];
const WORK_START = 8 * 60 + 30;
const WORK_END = 18 * 60 + 30;
const gameKept = new Map<number, { v: number; at: number; data: ReturnType<typeof gameFor> }>();
const cachedGame = (userId: number) => memoByData(gameKept, userId, () => gameFor(userId), 20_000);

// a dare is measured against the person's own usual day, never below the company goal: push = a clearly better day, beast = a great one, record = the best ever
function dareTarget(level: DareLevel, goal: number, best: number, usual = 0): number {
  const push = Math.max(Math.ceil(goal * 1.5), Math.ceil(usual * 1.15));
  const beast = Math.max(goal * 2, Math.ceil(usual * 1.4), push + Math.max(2, Math.ceil(goal / 4)));
  if (level === 'push') return push;
  if (level === 'beast') return beast;
  return Math.max(best + 1, beast + 1);
}

// which few actions close a gap of points (the biggest first, never more than three kinds)
function recipe(gap: number, w: Record<string, number>): { key: string; n: number; points: number }[] {
  const out: { key: string; n: number; points: number }[] = [];
  let left = gap;
  for (const key of ['offer', 'visit', 'call', 'note']) {
    const pts = w[key] ?? 0;
    if (pts <= 0 || left <= 0) continue;
    const cap = key === 'offer' ? 3 : key === 'visit' ? 1 : key === 'call' ? 6 : 99;
    const n = key === 'note' ? Math.ceil(left / pts) : Math.min(cap, Math.floor(left / pts));
    if (n > 0) { out.push({ key, n, points: n * pts }); left -= n * pts; }
  }
  return out;
}

export function challengeFor(userId: number) {
  const g = cachedGame(userId);
  const s = gameSettings();
  const today = todayIst();
  const goal = s.goalDay;
  const year = load(shift(today, -365), today, userId);
  const pts = (d: string) => scoreDay(userId, d, year.get(`${userId}|${d}`), s).points;

  // the best day of the last 12 months, and the usual day (the middle one of the working days somebody worked)
  let best = { points: 0, date: null as string | null };
  const worked: number[] = [];
  for (const key of year.keys()) {
    const d = key.split('|')[1];
    if (d === today) continue;
    const p = pts(d);
    if (p > best.points) best = { points: p, date: d };
    if (p > 0) worked.push(p);
  }
  worked.sort((a, b) => a - b);
  const usual = worked.length ? worked[Math.floor(worked.length / 2)] : 0;

  // yesterday at this hour: the same clock, the last working day
  const prev = previousWorkday(today);
  const nowMin = istMinutes();
  const hhmm = `${String(Math.floor(nowMin / 60)).padStart(2, '0')}:${String(nowMin % 60).padStart(2, '0')}`;
  const byNow: Counts = {};
  for (const r of db.prepare(`SELECT type, COUNT(*) AS n FROM activities WHERE imported = 0 AND user_id = ? AND date(datetime(created_at, '+3 hours')) = ? AND time(datetime(created_at, '+3 hours')) <= ? GROUP BY type`).all(userId, prev, `${hhmm}:59`) as unknown as { type: string; n: number }[]) byNow[r.type] = r.n;
  const todoByNow = db.prepare(`SELECT COUNT(*) AS n FROM todos WHERE user_id = ? AND done_at IS NOT NULL AND date(datetime(done_at, '+3 hours')) = ? AND time(datetime(done_at, '+3 hours')) <= ?`).get(userId, prev, `${hhmm}:59`) as { n: number };
  byNow.todo = todoByNow.n;
  let paceThen = 0;
  for (const p of POINT_TYPES) { if (p.key === 'challenge' || p.key === 'explore') continue; paceThen += (byNow[p.key] ?? 0) * s.weights[p.key]; }
  const lastAt = db.prepare("SELECT MAX(created_at) AS at FROM activities WHERE imported = 0 AND user_id = ? AND date(datetime(created_at, '+3 hours')) = ?").get(userId, today) as { at: string | null };

  // the dare of today
  const d = db.prepare('SELECT level, target, taken_at FROM day_dares WHERE user_id = ? AND day = ?').get(userId, today) as { level: DareLevel; target: number; taken_at: string } | undefined;
  const dareStats = db.prepare('SELECT day, target FROM day_dares WHERE user_id = ? AND day < ? ORDER BY day DESC LIMIT 120').all(userId, today) as unknown as { day: string; target: number }[];
  const daresWon = dareStats.filter((x) => pts(x.day) >= x.target).length;

  const points = g.today.points;
  const target = Math.max(goal, d?.target ?? goal);
  const gap = Math.max(0, target - points);
  const board = g.week.board;
  const me = board.findIndex((b) => b.id === userId);
  const ahead = me > 0 ? board[me - 1] : null;
  const behind = me >= 0 && me < board.length - 1 ? board[me + 1] : null;
  const minutesLeft = Math.max(0, WORK_END - Math.max(nowMin, WORK_START));
  const inHours = nowMin >= WORK_START && nowMin < WORK_END && isWorkday(today);

  // the last five working days against the five before them
  const days: string[] = [];
  for (let x = previousWorkday(today); days.length < 10; x = previousWorkday(x)) days.push(x);
  const avg = (list: string[]) => (list.length ? Math.round(list.reduce((a, x) => a + pts(x), 0) / list.length) : 0);
  const recent = avg(days.slice(0, 5));
  const before = avg(days.slice(5, 10));

  const workdaysLeft = [0, 1, 2, 3, 4, 5, 6].map((i) => shift(g.week.start, i)).filter((x) => x >= today && isWorkday(x)).length;
  const weekTarget = goal * 5;
  return {
    date: today, workday: isWorkday(today), inHours, minutesLeft, now: hhmm,
    points, goal, target, gap, reached: points >= target, goalReached: points >= goal,
    best, usual, beatBest: best.points > 0 && points > best.points, toBest: best.points > 0 ? Math.max(0, best.points + 1 - points) : null,
    yesterday: { date: prev, points: pts(prev), byNow: paceThen }, pace: points - paceThen,
    lastActionAt: lastAt.at, idleMinutes: lastAt.at ? Math.max(0, Math.round((Date.now() - Date.parse(`${lastAt.at.replace(' ', 'T')}Z`)) / 60000)) : null,
    dare: d ? { level: d.level, target: d.target, takenAt: d.taken_at, done: points >= d.target } : null,
    dares: { push: dareTarget('push', goal, best.points, usual), beast: dareTarget('beast', goal, best.points, usual), record: dareTarget('record', goal, best.points, usual), won: daresWon, taken: dareStats.length },
    recipe: recipe(gap, s.weights), weights: s.weights,
    streak: { ...g.streak, atRisk: isWorkday(today) && !g.streak.doneToday && g.streak.days > 0 && nowMin >= 14 * 60 },
    challenges: g.today.challenges, level: g.level,
    week: { points: g.week.points, target: weekTarget, days: g.week.days, rank: g.week.rank, of: g.week.of, workdaysLeft, needPerDay: workdaysLeft > 0 ? Math.max(0, Math.ceil((weekTarget - g.week.points) / workdaysLeft)) : 0 },
    rival: ahead ? { name: ahead.name, gap: ahead.points - (board[me]?.points ?? 0), today: ahead.today } : null,
    chaser: behind ? { name: behind.name, gap: (board[me]?.points ?? 0) - behind.points, today: behind.today } : null,
    leader: me === 0 && board.length > 1,
    momentum: { recent, before, delta: recent - before },
    badges: g.badges.filter((b) => !b.earned).sort((a, b) => b.n / b.target - a.n / a.target).slice(0, 2),
  };
}

// take a dare for today: a higher goal. It can be raised during the day, never lowered or taken back.
export function takeDare(userId: number, level: DareLevel): ReturnType<typeof challengeFor> {
  const today = todayIst();
  const c = challengeFor(userId);
  const target = c.dares[level];
  const cur = db.prepare('SELECT target FROM day_dares WHERE user_id = ? AND day = ?').get(userId, today) as { target: number } | undefined;
  if (cur && cur.target >= target) throw new Error('You already took a dare at least this hard today. A dare can only be raised.');
  db.prepare(`INSERT INTO day_dares (user_id, day, level, target) VALUES (?, ?, ?, ?) ON CONFLICT(user_id, day) DO UPDATE SET level = excluded.level, target = excluded.target, taken_at = datetime('now')`).run(userId, today, level, target);
  return challengeFor(userId);
}
