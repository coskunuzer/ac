-- the city of one of the other people at a company
ALTER TABLE card_contacts ADD COLUMN city TEXT;
