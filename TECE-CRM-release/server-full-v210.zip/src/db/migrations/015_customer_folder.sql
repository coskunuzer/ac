-- Where this customer's folder lives under data/customer-files (relative path:
-- "<exhibition>/<customer> [id]"), so it can be moved when the name changes.
ALTER TABLE cards ADD COLUMN archive_dir TEXT;
