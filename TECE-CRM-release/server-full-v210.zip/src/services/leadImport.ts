import * as XLSX from 'xlsx';
import { db } from '../db/connection';
import { cardModel } from '../models/cardModel';
import { countryKey, countryModel } from '../models/countryModel';
import type { ExtractedCardFields, FieldStatusMap } from '../schema/cardSchema';
import { resolveCountry } from './badgeImport';
import { tidyPhones } from './phone';

// The customer database (an Excel file of companies: tier, score, business type, suppliers, contact ...)
// becomes customers in one list, all in the "lead" stage, each already with the sales person of their
// country. Run again with a newer file: companies that are already in are left alone.

const ALIASES: Record<string, string[]> = {
  company: ['company', 'companyname', 'firma', 'sirket', 'name of company', 'customer'],
  country: ['country', 'nation', 'ulke', 'land'],
  tier: ['tier', 'priority', 'class'],
  score: ['score', 'points'],
  businessType: ['businesstype', 'type', 'segment', 'business'],
  salesAngle: ['salesangle', 'angle', 'pitch'],
  suppliers: ['knownsuppliers', 'suppliers'],
  tradeValue: ['tradevalueusd', 'tradevalue', 'trade'],
  sources: ['datasources', 'sources', 'source'],
  email: ['email', 'emailaddress', 'mail', 'epost'],
  phone: ['phone', 'tel', 'telephone', 'mobile'],
  sap: ['sap', 'sapnumber', 'sapno', 'sapcustomernumber'],
  website: ['website', 'web', 'site', 'url'],
  contact: ['contactperson', 'contact', 'person', 'name'],
  position: ['position', 'title', 'jobtitle', 'role'],
};

const norm = (s: string) => s.normalize('NFD').replace(/\p{Diacritic}/gu, '').toLowerCase().replace(/[^a-z0-9]/g, '');
const clean = (v: unknown) => String(v ?? '').replace(/\s+/g, ' ').trim();

export interface LeadImportReport {
  sheet: string;
  rows: number;
  created: number;
  duplicates: number;
  skipped: number;
  withEmail: number;
  withCountry: number;
  // rows with no country at all (the page asks which country they belong to before the real upload)
  missingCountry: number;
  withPerson: number;
  unknownCountries: string[];
  tiers: Record<string, number>;
  topCountries: { country: string; count: number }[];
  sample: { company: string; country: string | null; tier: string | null; email: string | null; person: string | null }[];
  columnsFound: string[];
}

function pickSheet(wb: XLSX.WorkBook): { name: string; rows: unknown[][] } {
  const candidates = [...wb.SheetNames].sort((a, b) => (/full/i.test(b) ? 1 : 0) - (/full/i.test(a) ? 1 : 0));
  for (const name of candidates) {
    const rows = XLSX.utils.sheet_to_json<unknown[]>(wb.Sheets[name], { header: 1, defval: '', blankrows: false });
    const head = (rows[0] ?? []).map((h) => norm(String(h)));
    if (head.some((h) => ALIASES.company.includes(h))) return { name, rows };
  }
  throw new Error('Could not find a sheet with a "Company" column. The first line must name the columns (Company, Country, Email ...).');
}

const emailOf = (raw: string) => (raw.split(/[;,|\s]+/).find((e) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)) ?? '').toLowerCase();

export async function importLeads(opts: { buffer: Buffer; exhibitionId: number; userId: number; dryRun: boolean; defaultCountry?: string | null }): Promise<LeadImportReport> {
  const wb = XLSX.read(opts.buffer, { type: 'buffer' });
  const { name, rows } = pickSheet(wb);
  const head = (rows[0] ?? []).map((h) => norm(String(h)));
  const col: Record<string, number> = {};
  for (const [key, names] of Object.entries(ALIASES)) {
    const i = head.findIndex((h) => names.includes(h));
    if (i >= 0) col[key] = i;
  }
  const get = (r: unknown[], key: string) => (col[key] === undefined ? '' : clean(r[col[key]]));

  const have = new Set(
    (db.prepare("SELECT badge_id FROM cards WHERE exhibition_id = ? AND badge_id LIKE 'db:%'").all(opts.exhibitionId) as { badge_id: string }[]).map((r) => r.badge_id)
  );
  const report: LeadImportReport = {
    sheet: name, rows: rows.length - 1, created: 0, duplicates: 0, skipped: 0, withEmail: 0, withCountry: 0, missingCountry: 0, withPerson: 0,
    unknownCountries: [], tiers: {}, topCountries: [], sample: [], columnsFound: Object.keys(col),
  };
  const unknown = new Map<string, number>();
  const byCountry = new Map<string, number>();
  const FOUND: FieldStatusMap = {
    name: 'found', company: 'found', address: 'found', country: 'found', tel: 'found', email: 'found', position: 'found', interestedIn: 'found',
    workArea: 'found', date: 'found', person: 'found', rate: 'found', notes: 'found',
  };
  const owners = new Map<string, string | null>();
  const ownerOf = (country: string | null) => {
    if (!country) return null;
    const k = countryKey(country);
    if (!owners.has(k)) owners.set(k, countryModel.findByCountry(country)?.responsible ?? null);
    return owners.get(k)!;
  };

  if (!opts.dryRun) db.exec('BEGIN');
  try {
    for (let i = 1; i < rows.length; i += 1) {
      const r = rows[i];
      const company = get(r, 'company');
      if (!company) {
        report.skipped += 1;
        continue;
      }
      // a file without a country: the country the person chose before the upload
      const rawCountry = get(r, 'country') || (opts.defaultCountry ?? '');
      const resolved = rawCountry ? resolveCountry(rawCountry) : null;
      const country = resolved ?? (rawCountry || null);
      if (rawCountry && !resolved) unknown.set(rawCountry, (unknown.get(rawCountry) ?? 0) + 1);
      const key = `db:${norm(company)}|${country ? countryKey(country) : ''}`;
      if (have.has(key)) {
        report.duplicates += 1;
        continue;
      }
      have.add(key);

      const email = emailOf(get(r, 'email'));
      // Turkish companies in the database belong to the domestic team (looked after by city, not by country)
      const domestic = !!country && countryKey(country) === 'turkey';
      const person = domestic ? null : ownerOf(country);
      const tier = get(r, 'tier') || null;
      const fields: ExtractedCardFields = {
        name: get(r, 'contact') || null,
        company,
        address: null,
        country,
        tel: tidyPhones(get(r, 'phone'), country),
        email: email || null,
        position: get(r, 'position') || null,
        interestedIn: null,
        workArea: get(r, 'businessType') || null,
        date: null,
        person,
        rate: null,
        notes: null,
      };
      report.created += 1;
      if (email) report.withEmail += 1;
      if (!country) report.missingCountry += 1;
      if (country) {
        report.withCountry += 1;
        byCountry.set(country, (byCountry.get(country) ?? 0) + 1);
      }
      if (person) report.withPerson += 1;
      if (tier) report.tiers[tier] = (report.tiers[tier] ?? 0) + 1;
      if (report.sample.length < 12) report.sample.push({ company, country, tier, email: email || null, person });

      if (!opts.dryRun) {
        const suppliers = get(r, 'suppliers').split('|').map((s) => s.trim()).filter(Boolean);
        cardModel.createFromExtraction({
          exhibitionId: opts.exhibitionId,
          uploadedBy: opts.userId,
          imagePath: '',
          fields,
          fieldStatus: FOUND,
          extractionModel: 'lead-database',
          status: 'confirmed',
          badgeId: key,
          stage: 'lead',
          market: domestic ? 'domestic' : 'export',
          website: get(r, 'website') || null,
          sap: get(r, 'sap') || null,
          leadInfo: {
            tier,
            score: Number(get(r, 'score')) || null,
            businessType: get(r, 'businessType') || null,
            salesAngle: get(r, 'salesAngle') || null,
            suppliers: suppliers.slice(0, 10),
            tradeValue: Number(get(r, 'tradeValue')) || null,
            sources: get(r, 'sources').split('|').map((s) => s.trim()).filter(Boolean).slice(0, 10),
          },
        });
      }
      // let other requests through now and then during the long run
      if (i % 1500 === 0) {
        if (!opts.dryRun) db.exec('COMMIT');
        await new Promise((resolve) => setImmediate(resolve));
        if (!opts.dryRun) db.exec('BEGIN');
      }
    }
    if (!opts.dryRun) db.exec('COMMIT');
  } catch (err) {
    if (!opts.dryRun) db.exec('ROLLBACK');
    throw err;
  }
  report.unknownCountries = [...unknown.entries()].sort((a, b) => b[1] - a[1]).slice(0, 25).map(([c, n]) => `${c} (${n})`);
  report.topCountries = [...byCountry.entries()].sort((a, b) => b[1] - a[1]).slice(0, 12).map(([country, count]) => ({ country, count }));
  return report;
}
