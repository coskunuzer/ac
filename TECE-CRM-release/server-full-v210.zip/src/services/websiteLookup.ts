import dns from 'dns/promises';
import net from 'net';
import { env } from '../config/env';
import type { CardRow } from '../models/cardModel';

const GEMINI_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent';
const MAX_BYTES = 600 * 1024;
const TIMEOUT_MS = 9000;

// Personal mail providers: the part after the @ says nothing about the company.
const FREE_MAIL = new Set([
  'gmail.com', 'googlemail.com', 'hotmail.com', 'hotmail.co.uk', 'outlook.com', 'live.com', 'msn.com', 'yahoo.com', 'yahoo.co.uk',
  'ymail.com', 'icloud.com', 'me.com', 'aol.com', 'gmx.com', 'gmx.de', 'web.de', 'mail.com', 'mail.ru', 'yandex.com', 'yandex.ru',
  'proton.me', 'protonmail.com', 'zoho.com', 'qq.com', '163.com', '126.com', 'naver.com', 'rediffmail.com', 'libero.it', 'virgilio.it',
  'orange.fr', 'wanadoo.fr', 'free.fr', 'sfr.fr', 'laposte.net', 't-online.de', 'freenet.de', 'btinternet.com', 'sky.com', 'telenet.be',
  'ziggo.nl', 'kpnmail.nl', 'terra.com.br', 'uol.com.br', 'bol.com.br', 'ig.com.br', 'prodigy.net.mx', 'hotmail.es', 'hotmail.fr', 'hotmail.it',
]);

// A website to try: a web address written on the form (work area, notes,
// address) or the company part of a work email address.
export function guessWebsite(card: Pick<CardRow, 'email' | 'work_area' | 'notes' | 'address'>): string | null {
  const written = [card.work_area, card.notes, card.address].filter(Boolean).join(' ');
  const url = /\b((?:https?:\/\/)?(?:www\.)?[a-z0-9][a-z0-9-]*(?:\.[a-z0-9-]+)*\.[a-z]{2,}(?:\/\S*)?)/i.exec(written.replace(/[\w.+-]+@[\w.-]+/g, ' '));
  if (url && /www\.|https?:\/\//i.test(url[1])) return url[1].replace(/[),.;]+$/, '');
  for (const email of (card.email ?? '').split(/[,;\s]+/)) {
    const domain = email.split('@')[1]?.toLowerCase();
    if (domain && !FREE_MAIL.has(domain)) return domain;
  }
  return null;
}

function isPrivateAddress(ip: string): boolean {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split('.').map(Number);
    return a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127);
  }
  const v = ip.toLowerCase();
  return v === '::1' || v === '::' || v.startsWith('fc') || v.startsWith('fd') || v.startsWith('fe80') || v.startsWith('::ffff:127.') || v.startsWith('::ffff:10.') || v.startsWith('::ffff:192.168.');
}

// The server fetches addresses that people type in, so only public web sites are allowed.
async function assertPublic(url: URL): Promise<void> {
  if (url.protocol !== 'http:' && url.protocol !== 'https:') throw new Error('Only web addresses (http/https) can be looked up.');
  if (url.port && url.port !== '80' && url.port !== '443') throw new Error('That address uses an unusual port.');
  const host = url.hostname;
  if (host === 'localhost' || host.endsWith('.local') || host.endsWith('.internal')) throw new Error('That is not a public web site.');
  const addresses = net.isIP(host) ? [{ address: host }] : await dns.lookup(host, { all: true });
  if (addresses.length === 0 || addresses.some((a) => isPrivateAddress(a.address))) throw new Error('That is not a public web site.');
}

export async function fetchHtml(start: string): Promise<{ finalUrl: string; html: string }> {
  let current = new URL(start);
  for (let hop = 0; hop < 4; hop++) {
    await assertPublic(current);
    const res = await fetch(current, {
      redirect: 'manual',
      signal: AbortSignal.timeout(TIMEOUT_MS),
      headers: { 'user-agent': 'Mozilla/5.0 (compatible; TECE-lookup/1.0)', accept: 'text/html,application/xhtml+xml' },
    });
    if (res.status >= 300 && res.status < 400 && res.headers.get('location')) {
      current = new URL(res.headers.get('location')!, current);
      continue;
    }
    if (!res.ok) throw new Error(`The web site answered with an error (${res.status}).`);
    const type = res.headers.get('content-type') ?? '';
    if (!/text\/html|application\/xhtml/i.test(type)) throw new Error('That address is not a web page.');
    // read a limited amount
    const reader = res.body!.getReader();
    const chunks: Uint8Array[] = [];
    let total = 0;
    while (total < MAX_BYTES) {
      const { done, value } = await reader.read();
      if (done || !value) break;
      chunks.push(value);
      total += value.length;
    }
    void reader.cancel().catch(() => {});
    return { finalUrl: current.toString(), html: Buffer.concat(chunks).toString('utf8') };
  }
  throw new Error('The web site redirected too many times.');
}

const decode = (s: string) =>
  s
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#0?39;|&apos;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&#(\d+);/g, (_m, n) => String.fromCharCode(Number(n)));

function meta(html: string, name: string): string {
  const re = new RegExp(`<meta[^>]+(?:name|property)=["']${name}["'][^>]*>`, 'i');
  const tag = re.exec(html)?.[0] ?? '';
  return decode(/content=["']([^"']*)["']/i.exec(tag)?.[1] ?? '').trim();
}

// Sentences about cookies, privacy and consent are on every page and say nothing about the company.
const NOISE = /\b(cookies?|privacy|gdpr|consent|all rights reserved|javascript|subscribe|newsletter|deactivation|browser|browsing|scrolling|banner|terms of (use|service)|complete information)\b/i;

function sentences(text: string): string[] {
  return text
    .split(/(?<=[.!?])\s+/)
    .map((s) => s.trim())
    .filter((s) => s.length >= 30 && !NOISE.test(s));
}

interface Page {
  title: string;
  description: string;
  menu: string[];
  text: string;
}

function readPage(html: string): Page {
  const title = decode(/<title[^>]*>([\s\S]*?)<\/title>/i.exec(html)?.[1] ?? '').replace(/\s+/g, ' ').trim();
  const description = meta(html, 'description') || meta(html, 'og:description');
  // the menu words ("Products", "Kitchens", "Contract") hint at the field of work
  const nav = /<nav[\s\S]*?<\/nav>/i.exec(html)?.[0] ?? /<header[\s\S]*?<\/header>/i.exec(html)?.[0] ?? '';
  const menu = [...new Set([...nav.matchAll(/<a\b[^>]*>([\s\S]*?)<\/a>/gi)].map((m) => decode(m[1].replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim()))]
    .filter((w) => w.length > 2 && w.length < 40)
    .slice(0, 14);
  const body = decode(
    html
      .replace(/<(script|style|noscript|svg|nav|footer|header|form)[\s\S]*?<\/\1>/gi, ' ')
      .replace(/<[^>]+>/g, ' ')
  )
    .replace(/\s+/g, ' ')
    .trim();
  // keep the real sentences, drop the cookie banner and the like
  const text = sentences(body).join(' ').slice(0, 3500);
  return { title, description, menu, text };
}

// The company's own "About" page tells more than a home page made of pictures.
function findAboutLink(html: string, base: string): string | null {
  const wanted = /(about|company|who[- ]we[- ]are|profile|our[- ]story|chi[- ]siamo|azienda|societ|hakk[iı]m[iı]zda|kurumsal|[üu]ber[- ]uns|unternehmen|qui[- ]sommes|entreprise|nosotros|empresa|quienes)/i;
  const baseUrl = new URL(base);
  const sameSite = (h: string) => h.replace(/^www\./, '') === baseUrl.hostname.replace(/^www\./, '');
  for (const m of html.matchAll(/<a\b[^>]*href=["']([^"'#]+)["'][^>]*>([\s\S]*?)<\/a>/gi)) {
    const label = decode(m[2].replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim();
    if (!wanted.test(label) && !wanted.test(m[1])) continue;
    if (/^(mailto|tel|javascript):/i.test(m[1]) || /\.(png|jpe?g|gif|pdf|zip|svg|webp)(\?|$)/i.test(m[1])) continue;
    try {
      const url = new URL(m[1], base);
      if (sameSite(url.hostname) && url.pathname !== baseUrl.pathname) return url.toString();
    } catch {
      /* ignore */
    }
  }
  return null;
}

const WORDS = (s: string) => s.split(/\s+/).filter(Boolean);

// The AI's one line, cleaned up. Anything that is not a real description - one
// word ("Italian"), a cut-off start ("Task:**"), a refusal - is thrown away so it
// never reaches the Work area box.
export function cleanSummary(raw: string | null | undefined): string | null {
  if (!raw) return null;
  const line = raw
    .replace(/[*_`#>]+/g, ' ')
    .replace(/^\s*(answer|summary|description|work area|task|output)\s*:\s*/i, '')
    .split('\n')
    .map((l) => l.trim())
    .find((l) => l.length > 0)
    ?.replace(/^["'“”‘’]+|["'“”‘’.]+$/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  if (!line) return null;
  if (WORDS(line).length < 3 || line.length > 160) return null;
  if (/^(unclear|unknown|n\/a|none|i (cannot|can't|could not)|sorry)/i.test(line)) return null;
  if (/[:;,-]$/.test(line)) return null; // cut off in the middle
  return line;
}

async function askGemini(prompt: string, withThinkingOff: boolean): Promise<string | null> {
  const res = await fetch(GEMINI_URL, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-goog-api-key': env.geminiApiKey },
    signal: AbortSignal.timeout(25000),
    body: JSON.stringify({
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      // room enough for a whole answer even when the model "thinks" first
      generationConfig: { temperature: 0.2, maxOutputTokens: 600, ...(withThinkingOff ? { thinkingConfig: { thinkingBudget: 0 } } : {}) },
    }),
  });
  if (!res.ok) {
    if (withThinkingOff && res.status === 400) return askGemini(prompt, false); // this model does not take that setting
    return null;
  }
  const data = (await res.json()) as { candidates?: { content?: { parts?: { text?: string; thought?: boolean }[] } }[] };
  const parts = data.candidates?.[0]?.content?.parts ?? [];
  // the answer is the last part that is not the model's own thinking
  const answer = [...parts].reverse().find((p) => !p.thought && p.text)?.text;
  return answer ?? null;
}

async function summarise(domain: string, page: Page, about: string): Promise<string | null> {
  if (!env.geminiApiKey) return null;
  const prompt =
    'Below is text from a company web site (menus and cookie notices removed). ' +
    'Say what the company does: write ONE line in English, 5 to 14 words, naming the products or services and the kind of business, ' +
    'for example "Manufacturer of kitchen and bathroom furniture" or "Wholesale distributor of wood-based panels and edgebanding". ' +
    'Use only what the text says. Reply with the line only: no quotes, no formatting, no label. ' +
    'If the text really does not say what they do, reply exactly: unclear\n\n' +
    `Web site: ${domain}\nTitle: ${page.title}\nDescription: ${page.description}\nMenu: ${page.menu.join(', ')}\n\nHome page:\n${page.text}\n\n` +
    (about ? `About page:\n${about}` : '');
  try {
    const first = cleanSummary(await askGemini(prompt, true));
    return first;
  } catch {
    return null;
  }
}

export interface WebsiteInfo {
  website: string;
  title: string;
  description: string;
  // a short line for the Work area box, from the AI when it is available, else the page's own words
  suggestion: string;
  source: 'ai' | 'page';
}

export async function lookupWebsite(input: string): Promise<WebsiteInfo> {
  const raw = input.trim();
  if (!raw) throw new Error('Type a web address first.');
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(raw) && !/^https?:\/\//i.test(raw)) throw new Error('Only web addresses (http/https) can be looked up.');
  let url: URL;
  try {
    url = new URL(/^https?:\/\//i.test(raw) ? raw : `https://${raw}`);
  } catch {
    throw new Error('That does not look like a web address.');
  }
  let page: { finalUrl: string; html: string };
  try {
    page = await fetchHtml(url.toString());
  } catch (err) {
    // many sites only answer on www.
    if (!url.hostname.startsWith('www.') && /ENOTFOUND|fetch failed|ECONNREFUSED/i.test(String((err as Error).message) + String((err as { cause?: Error }).cause?.message ?? ''))) {
      url.hostname = `www.${url.hostname}`;
      page = await fetchHtml(url.toString());
    } else {
      throw err;
    }
  }
  const home = readPage(page.html);

  // the company / about page, when the home page links to one
  let about = '';
  const aboutUrl = findAboutLink(page.html, page.finalUrl);
  if (aboutUrl) {
    try {
      const a = await fetchHtml(aboutUrl);
      const p = readPage(a.html);
      about = [p.description, p.text].filter(Boolean).join(' ').slice(0, 2500);
    } catch {
      /* the home page alone will do */
    }
  }

  const readable = [home.description, home.text, about].join(' ').trim();
  if (!home.title && !readable) throw new Error('The page has no readable text.');

  const ai = await summarise(new URL(page.finalUrl).hostname, home, about);
  // without the AI: the site's own description, or the first real sentence it says
  const candidates = [home.description, ...sentences(home.text), ...sentences(about)].filter((s) => s && WORDS(s).length >= 5);
  const aboutBusiness = /(produc|manufactur|supply|supplier|distribut|design|specialis|solutions?|services?|fabbric|manifattur|[üu]ret|imalat|herstell|fabri[ck])/i;
  const ownWords = candidates.find((s) => aboutBusiness.test(s)) ?? candidates[0];
  const oneLine = (ownWords ?? home.title).replace(/\s+/g, ' ').trim();
  // never cut a word in half
  const fallback = oneLine.length <= 140 ? oneLine : `${oneLine.slice(0, 140).replace(/\s+\S*$/, '')}…`;
  return {
    website: page.finalUrl,
    title: home.title,
    description: home.description,
    suggestion: ai ?? fallback,
    source: ai ? 'ai' : 'page',
  };
}

// exposed for tests
export const _internal = { readPage, findAboutLink, fetchHtml, sentences };
