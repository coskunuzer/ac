import { db } from '../db/connection';
import { cardModel, isJustLead, type CardRow } from '../models/cardModel';
import { countryModel, countryKey } from '../models/countryModel';
import { cityModel } from '../models/cityModel';
import { activityModel } from '../models/activityModel';
import { refreshOwnerOverride } from './ownership';
import { syncCustomerFolder } from './customerFiles';

// Handing customers to somebody else (a person leaves, or a whole country gets a new person).
//  - from + toName: every customer of "from" (all, or only those of one country)
//  - only a country: every customer of that country, whoever has them now
// The countries and cities that "from" looked after go with the customers, so new customers follow too.
export interface TransferInput { from?: string | null; country?: string | null; to: string; byUserId: number }
export interface TransferResult { moved: number; assignmentsMoved: number }

export function customersOf(from: string | null, country: string | null): { id: number }[] {
  const where: string[] = [];
  const args: string[] = [];
  if (from) { where.push('TRIM(person) = ?'); args.push(from); }
  if (country) { where.push("market != 'domestic' AND LOWER(TRIM(country)) = LOWER(?)"); args.push(country); }
  if (!where.length) return [];
  return db.prepare(`SELECT id FROM cards WHERE ${where.join(' AND ')}`).all(...args) as { id: number }[];
}

export function transferCustomers(input: TransferInput): TransferResult {
  const to = input.to.trim();
  const from = (input.from ?? '').trim() || null;
  const country = (input.country ?? '').trim() || null;
  if (!to) throw new Error('Choose who gets the customers.');
  if (!from && !country) throw new Error('Choose the person or the country.');
  const ids = customersOf(from, country).map((r) => r.id);
  let assignmentsMoved = 0;
  db.exec('BEGIN');
  try {
    const set = db.prepare("UPDATE cards SET person = ?, updated_at = datetime('now') WHERE id = ?");
    for (const id of ids) {
      set.run(to, id);
      refreshOwnerOverride(id);
      activityModel.add({ userId: input.byUserId, cardId: id, type: 'stage', imported: true, text: `Responsible: ${from ?? 'nobody'} -> ${to}` });
    }
    // the countries / cities that the person looked after
    if (country) {
      const cur = countryModel.findByCountry(country);
      if (cur) { countryModel.upsert({ country: cur.country, continent: cur.continent, responsible: to, assistant: cur.assistant }); assignmentsMoved += 1; }
    } else if (from) {
      for (const c of countryModel.listAll()) {
        if (c.responsible === from || c.assistant === from) {
          countryModel.upsert({ country: c.country, continent: c.continent, responsible: c.responsible === from ? to : c.responsible, assistant: c.assistant === from ? to : c.assistant });
          assignmentsMoved += 1;
        }
      }
      for (const c of cityModel.listAll()) {
        if (c.responsible === from || c.assistant === from) {
          cityModel.upsert({ city: c.city, responsible: c.responsible === from ? to : c.responsible, assistant: c.assistant === from ? to : c.assistant });
          assignmentsMoved += 1;
        }
      }
    }
    db.exec('COMMIT');
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
  // the folders follow the person (leads have none)
  for (const id of ids) {
    const card = cardModel.findById(id) as CardRow | undefined;
    if (card && !isJustLead(card)) syncCustomerFolder(id);
  }
  return { moved: ids.length, assignmentsMoved };
}

// how many customers a person has, and where
export function holdings(person: string): { total: number; countries: { country: string; n: number }[] } {
  const total = (db.prepare('SELECT COUNT(*) AS n FROM cards WHERE TRIM(person) = ?').get(person) as { n: number }).n;
  const countries = db.prepare("SELECT COALESCE(NULLIF(TRIM(country), ''), '(no country)') AS country, COUNT(*) AS n FROM cards WHERE TRIM(person) = ? GROUP BY 1 ORDER BY n DESC").all(person) as { country: string; n: number }[];
  return { total, countries };
}
export const countryHoldings = (): { country: string; n: number; person: string | null }[] =>
  (db.prepare("SELECT TRIM(country) AS country, COUNT(*) AS n FROM cards WHERE market != 'domestic' AND TRIM(COALESCE(country, '')) != '' GROUP BY LOWER(TRIM(country)) ORDER BY n DESC").all() as { country: string; n: number }[]).map((r) => ({ ...r, person: countryModel.findByCountry(r.country)?.responsible ?? null }));
void countryKey;
