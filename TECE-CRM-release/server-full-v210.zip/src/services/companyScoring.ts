import { settingsModel } from '../models/settingsModel';

// The TECE company scoring system (v12). Two scores for each company:
//  - Purchase Score (0-100): is it an edgebanding buyer, and how strong? The Tier (Hot / Warm / Cold / Disqualified) comes from it.
//  - Fit Score (0-100): how well do its needs match TECE's products? The Priority (P1-P4) comes from it (with the Tier).
// The AI does not give a score. It only reads the company's web site and writes down facts, each with a direct quote. Code checks that
// every quote is really in the text (a fact without a real quote is thrown away) and then works the scores out by these rules.

export type Tier = 'Hot' | 'Warm' | 'Cold' | 'Disqualified';
export type Priority = 'P1' | 'P2' | 'P3' | 'P4';

// The facts the AI may write down (key: what it means).
export const FACT_KEYS: Record<string, string> = {
  segment: 'What the company is: distributor, manufacturer, workshop, panel_manufacturer (it makes the boards themselves) or other.',
  dist_edgebanding: 'A distributor / dealer that sells edgebanding. (true)',
  dist_cutting: 'A distributor / dealer that offers cutting / sizing of boards. (true)',
  dist_boards: 'A distributor / dealer that sells boards (MDF, chipboard, laminate). (true)',
  dist_customers_carpenters: 'Its customers are carpenters and furniture makers. (true)',
  mfr_serial: 'Serial (industrial) production of furniture, kitchens, doors or panels. (true)',
  mfr_production: 'Production of furniture, kitchens, doors or similar. (true)',
  mfr_panels: 'It works with boards / panels (MDF, chipboard, laminated boards). (true)',
  mfr_edgebanding: 'It does edgebanding itself. (true)',
  mfr_cutting: 'It does cutting / sizing of boards itself. (true)',
  mfr_machinery: 'It has panel processing machinery (edgebander, panel saw, CNC). (true)',
  employees: 'Number of employees (a number).',
  branches: 'Number of branches or sales points (a number).',
  legal_suffix: 'The name has a legal ending (Ltd, A.S., GmbH ...). (true)',
  trade_registry: 'A trade registry number or record is shown. (true)',
  dealer_directory: 'It is listed in a dealer directory of a board or machine maker. (true)',
  machines: 'Number of different machines it lists (a number).',
  own_facility: 'It has its own factory or facility. (true)',
  exports: 'It exports. (true)',
  board_brands: 'Board brands it uses or sells (a comma separated list of names).',
  wide_decors: 'It offers a wide range of decors. (true)',
  project_volume: 'It does large project or contract volumes. (true)',
  neg_competitor: 'It is a maker of edgebanding (a competitor). (true)',
  neg_out_of_business: 'It is out of business. (true)',
  neg_irrelevant: 'It works in an unrelated industry. (true)',
  mixed_type: 'A mixed business: showroom, online_store, installation_only or hardware_only.',
  ev_eb_sales: 'It sells edgebanding. (true)',
  ev_eb_service: 'It offers an edgebanding service. (true)',
  ev_eb_machine: 'It has an edgebander machine. (true)',
  ev_job_listing: 'It advertises a job for an edgebanding operator. (true)',
  ev_channel: 'It is a dealer, wholesaler, processor / fabricator or tender winner. (true)',
  sales_office: 'This is a sales office only; production is in another country. (true)',
  no_panel_material: 'It works only with solid wood, upholstery, stone, glass or metal - no boards. (true)',
  fit_laser: 'Laser edgebanding is mentioned. (true)',
  fit_high_gloss: 'High-gloss surfaces. (true)',
  fit_veneer: 'Wood veneer. (true)',
  fit_sustainability: 'Sustainability is a theme. (true)',
  fit_thick: 'Thick edgebanding (2 mm or more). (true)',
  fit_wide: 'Wide edgebanding. (true)',
  fit_multi_decor: 'Many decors / colours. (true)',
  competitor_brands: 'Competitor edgebanding brands it uses (a comma separated list of names).',
  c_country: 'The country where the company is located (its name).',
  c_city: 'The city where the company is located.',
  c_address: 'The street address of the company.',
  c_email: 'A contact e-mail address of the company, written on the page.',
  c_decision_maker: 'The name of the owner, general manager, purchasing manager or similar, written on the page (name only).',
  c_decision_title: 'The job title of that person, written next to the name.',
  c_whatsapp: 'A WhatsApp number, written on the page or on a WhatsApp link.',
  c_founded: 'The year the company was founded (a number).',
  c_registry_no: 'The trade registry / tax number of the company, written on the page.',
  sig_growth: 'A sign of growth: a new factory, a new branch, a new machine, a big investment. (true)',
  sig_fair: 'It takes part in fairs / exhibitions (a fair is named). (true)',
  sig_competitor_dealer: 'It is a dealer of a competitor edgebanding brand (the brand is named in the quote). (true)',
  c_last_post: 'The date of the latest post or news item on the site or its social page (as written).',
  c_phone: 'A telephone or mobile number of the company, written on the page, with the country code if it is shown.',
};

export interface Fact { key: string; value: string | number | boolean; quote: string }
export interface CheckedFact extends Fact { verified: boolean }

export interface ScoreResult {
  method: 'v12' | 'prompt';
  scoredAt: string;
  status: 'scored' | 'candidate' | 'insufficient' | 'no_website';
  website: string | null;
  words: number;
  purchase: { score: number; tier: Tier; parts: { segment: number; flow: number; size: number; special: number }; floor: string | null; caps: string[] } | null;
  fit: { score: number; priority: Priority | null; parts: { volume: number; decor: number; product: number; competitor: number } } | null;
  // the line the company is routed to: sales, or a separate list
  track: 'sales' | 'disqualified' | 'partnership' | 'existing' | 'dealer_review' | 'workshop_dealer' | 'candidate';
  tags: string[];
  candidate: { category: 'Manufacturer' | 'Channel'; points: number } | null;
  facts: CheckedFact[];
  notes: string[];
  // a short, light story about the company (the AI writes it from what it read)
  story?: string;
}

// ---- settings: the board brands that TECE has matching decors for ------------------------------------------------------
export const DEFAULT_MATCHED_BRANDS = ['Egger', 'Kastamonu', 'AGT', 'Starwood', 'Yildiz', 'Swiss Krono', 'Pfleiderer', 'Sonae Arauco', 'Arauco', 'Duratex', 'Berneck', 'Masisa', 'Fantoni', 'Kaindl', 'Finsa', 'Unilin', 'Lamitak', 'Lamartin'];
export const PRIMARY_BRAND = 'Kronospan';
export const matchedBrands = (): string[] => {
  try {
    const list = JSON.parse(settingsModel.get('scoring_brands') ?? 'null');
    if (Array.isArray(list) && list.length) return list.map(String);
  } catch { /* the default list */ }
  return DEFAULT_MATCHED_BRANDS;
};
export const setMatchedBrands = (list: string[]): string[] => {
  const clean = [...new Set(list.map((s) => s.trim()).filter(Boolean))].slice(0, 80);
  settingsModel.set('scoring_brands', JSON.stringify(clean));
  return clean;
};

// ---- checking the quotes -----------------------------------------------------------------------------------------------
export const normText = (s: string) =>
  s.replace(/İ/g, 'i').normalize('NFD').replace(/\p{Diacritic}/gu, '').replace(/ı/g, 'i').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();

const asBool = (v: unknown) => v === true || /^(true|yes|1)$/i.test(String(v));
const asNum = (v: unknown) => { const n = Number(String(v).replace(/[^\d.]/g, '')); return Number.isFinite(n) && n > 0 ? n : null; };
const list = (v: unknown) => String(v ?? '').split(/[,;|]/).map((s) => s.trim()).filter(Boolean);

// Which facts are backed by a real quote of the text. `inferred` = facts the AI claimed that have no real quote (they earn no points).
export function checkFacts(facts: Fact[], text: string): { checked: CheckedFact[]; inferred: Set<string> } {
  const haystack = ` ${normText(text)} `;
  const checked: CheckedFact[] = [];
  const inferred = new Set<string>();
  for (const f of facts) {
    if (!f || !(f.key in FACT_KEYS)) continue;
    const q = normText(String(f.quote ?? ''));
    let verified = q.length >= 8 && haystack.includes(q);
    // a number must be in its quote
    if (verified && ['employees', 'branches', 'machines'].includes(f.key)) {
      const n = asNum(f.value);
      // "1.250" and "1 250" are the number 1250
      const flat = String(f.quote).replace(/(\d)[.,\s](?=\d{3}(\D|$))/g, '$1');
      verified = n !== null && new RegExp(String.raw`(^|\D)${n}(\D|$)`).test(flat);
    }
    checked.push({ key: f.key, value: f.value, quote: String(f.quote ?? '').slice(0, 300), verified });
    if (!verified && (asBool(f.value) || (typeof f.value === 'string' && f.value && !/^(false|no|none|other|unknown)$/i.test(f.value)))) inferred.add(f.key);
  }
  return { checked, inferred };
}

// ---- the rules ---------------------------------------------------------------------------------------------------------
export interface ScoreContext {
  checked: CheckedFact[];
  inferred: Set<string>;
  words: number;
  website: string | null;
  country: string | null;
  stage: string | null;
  // from the customer database: where the company's trade data came from, and the trade value in USD
  tradeSources: string[];
  tradeValue: number | null;
  businessType: string | null;
  // a TECE dealer / distributor exists in the company's country
  dealerInCountry: boolean;
}

export function computeScore(ctx: ScoreContext): ScoreResult {
  const v = new Map(ctx.checked.filter((f) => f.verified).map((f) => [f.key, f.value]));
  const has = (k: string) => v.has(k) && asBool(v.get(k));
  const num = (k: string) => (v.has(k) ? asNum(v.get(k)) : null);
  const str = (k: string) => String(v.get(k) ?? '').toLowerCase();
  const notes: string[] = [];
  const tags: string[] = [];
  const caps: string[] = [];

  const base: Omit<ScoreResult, 'purchase' | 'fit' | 'status' | 'track' | 'candidate'> = { method: 'v12', scoredAt: new Date().toISOString(), website: ctx.website, words: ctx.words, tags, facts: ctx.checked, notes };

  // no web site: it cannot be scored (there is no text to quote). It is a candidate to verify by phone.
  if (!ctx.website || ctx.words === 0) {
    const channel = /distribut|dealer|wholesal|trade|channel|market|hirdavat|hardware/i.test(ctx.businessType ?? '');
    const category = channel ? 'Channel' : 'Manufacturer';
    return { ...base, status: 'no_website', purchase: null, fit: null, track: 'candidate', candidate: { category, points: channel ? 30 : 39 }, tags: [...tags, 'candidate to verify'], notes: [...notes, 'No web site: nothing to quote, so no score. Verify it by phone.'] };
  }

  // eliminations
  const hardNegative = has('neg_competitor') || has('neg_out_of_business') || has('neg_irrelevant');
  const type = str('segment');
  const segmentVerified = ['distributor', 'manufacturer', 'workshop', 'panel_manufacturer'].includes(type);
  const claimed = ctx.inferred.has('segment');

  // a) segment (max 38)
  let segment = 0;
  type Kind = 'distributor' | 'manufacturer' | 'workshop' | 'panel_manufacturer' | 'unknown';
  const kind = (segmentVerified ? type : 'unknown') as Kind;
  if (kind === 'distributor') {
    segment = has('dist_edgebanding') && has('dist_cutting') ? 38 : has('dist_edgebanding') || has('dist_cutting') ? 34 : has('dist_boards') ? 30 : 18;
  } else if (kind === 'manufacturer') {
    const panels = has('mfr_panels');
    segment = has('mfr_serial') && panels ? 36 : (has('mfr_production') || has('mfr_serial')) && panels ? 30 : has('mfr_production') || has('mfr_serial') ? 20 : 14;
  } else if (kind === 'workshop') segment = 22;
  else if (kind === 'panel_manufacturer') segment = 26;
  else {
    // the type was not backed by a quote: the lowest "no evidence" value, and the score is capped later
    segment = ctx.businessType && /distribut|dealer/i.test(ctx.businessType) ? 18 : 10;
    if (claimed) caps.push('The kind of company is only the AI\'s guess: max 69');
  }

  // b) edgebanding flow (max 30)
  let flow = 0;
  if (kind === 'distributor') {
    flow = has('dist_edgebanding') && has('dist_cutting') ? 28 : has('dist_edgebanding') || has('dist_cutting') ? 21 : has('dist_boards') ? 12 : 0;
    if (has('dist_customers_carpenters')) flow += 2;
  } else if (kind !== 'unknown' && kind !== 'panel_manufacturer') {
    flow = has('mfr_edgebanding') ? 27 : has('mfr_cutting') ? 22 : has('mfr_panels') && (has('mfr_production') || has('mfr_serial')) ? 20 : has('mfr_production') || has('mfr_serial') ? 8 : 0;
    if (has('mfr_machinery')) flow += 3;
  }
  flow = Math.min(30, flow);

  // c) size (max 20)
  let size = 0;
  const employees = num('employees');
  const branches = num('branches');
  if (employees !== null) size = employees >= 250 ? 20 : employees >= 50 ? 17 : employees >= 10 ? 12 : 6;
  else if (branches !== null) size = branches >= 10 ? 16 : branches >= 5 ? 13 : branches >= 2 ? 8 : 0;
  else size = Math.min(12, 2 + (has('legal_suffix') ? 2 : 0) + (has('trade_registry') ? 2 : 0) + (has('dealer_directory') ? 3 : 0));
  if ((num('machines') ?? 0) >= 2) size += 3;
  if (has('own_facility')) size += 3;
  size = Math.min(20, size);

  // d) special signals (max 10)
  const brands = list(v.get('board_brands'));
  const special = (has('exports') ? 3 : 0) + (brands.length >= 3 ? 3 : 0) + (has('wide_decors') ? 2 : 0) + (has('project_volume') ? 2 : 0);

  let score = segment + flow + size + special;

  // evidence that raises the score to a floor
  const trade = ctx.tradeSources.includes('edgebanding_trade');
  const strong = ['ev_eb_sales', 'ev_eb_service', 'ev_eb_machine'].filter(has).length;
  let floor = 0;
  let floorWhy: string | null = null;
  const raise = (n: number, why: string) => { if (n > floor) { floor = n; floorWhy = why; } };
  if (trade) raise((ctx.tradeValue ?? 0) > 0 ? 70 : 50, 'Edgebanding purchases in trade data');
  if (strong) raise(strong >= 2 ? 70 : 55, 'Strong evidence on its web site (edgebanding sales, service or machine)');
  if (has('ev_job_listing')) raise(70, 'A job listing for edgebanding');
  if (has('ev_channel')) raise(55, 'Dealer, wholesaler, processor or tender winner');
  const independentStrong = trade || strong > 0 || has('ev_job_listing');
  if (floor && floor > score) score = floor;

  // ceilings
  let ceiling = 100;
  const cap = (n: number, why: string) => { ceiling = Math.min(ceiling, n); caps.push(why); };
  if (!independentStrong) cap(69, 'No independent, strong purchase evidence: it cannot be Hot (max 69)');
  if (has('no_panel_material')) cap(39, 'Works with solid wood, upholstery, stone, glass or metal only: max 39');
  if (ctx.inferred.has('mfr_panels') && !has('mfr_panels')) cap(69, 'Panel evidence is only the AI\'s inference: max 69');
  if (has('sales_office')) cap(69, 'A sales office (production is in another country): max 69');
  let status: ScoreResult['status'] = 'scored';
  if (ctx.words < 50) { cap(39, 'The web site has fewer than 50 words: max 39'); tags.push('insufficient data'); status = 'insufficient'; }
  score = Math.min(score, ceiling);
  // a cap from the list above that was only added for the explanation but did not bind is still true as a note

  // eliminations
  const purchaseEvidence = independentStrong || has('ev_channel') || has('dist_edgebanding') || has('dist_cutting') || has('mfr_edgebanding') || has('mfr_cutting');
  let disqualified = hardNegative;
  if (hardNegative) notes.push('A hard negative (competitor, out of business or an unrelated industry).');
  if (has('mixed_type')) {
    if (!purchaseEvidence) { disqualified = true; notes.push('A mixed business (' + str('mixed_type') + ') with no purchase evidence.'); }
    else tags.push('mixed');
  }
  if (disqualified) score = Math.min(score, 10);
  score = Math.max(0, Math.round(score));
  const tier: Tier = disqualified ? 'Disqualified' : score >= 70 ? 'Hot' : score >= 40 ? 'Warm' : 'Cold';

  // ---- fit score ----
  const employeesN = employees ?? 0;
  const panelsPresent = has('mfr_panels') || has('dist_boards') || has('dist_cutting') || has('dist_edgebanding') || kind === 'distributor';
  let volume = 0;
  if (kind === 'distributor') volume = has('dist_edgebanding') || has('dist_cutting') ? 32 : has('dist_boards') ? 25 : 0;
  else if (kind === 'workshop') volume = 5;
  else if (kind === 'manufacturer' || kind === 'unknown') volume = employeesN >= 250 ? 30 : employeesN >= 50 ? 20 : 12;
  if ((branches ?? 0) >= 5) volume += 3;
  volume = Math.min(35, volume);

  const matched = matchedBrands().map((b) => normText(b));
  const mine = brands.map((b) => normText(b));
  const hasPrimary = mine.some((b) => b.includes(normText(PRIMARY_BRAND)));
  const others = [...new Set(mine.filter((b) => matched.some((m) => b.includes(m) || m.includes(b))))];
  let decor = 0;
  if (hasPrimary) decor = 22 + 4 * others.length;
  else if (others.length) decor = 18 + 4 * (others.length - 1);
  else decor = panelsPresent ? 13 : 4;
  decor = Math.min(30, decor);

  let product = panelsPresent ? 13 : 6;
  product += (has('fit_laser') ? 7 : 0) + (has('fit_high_gloss') ? 5 : 0) + (has('fit_veneer') ? 5 : 0) + (has('fit_sustainability') ? 5 : 0) + (has('fit_thick') ? 4 : 0) + (has('fit_wide') ? 4 : 0) + (has('fit_multi_decor') ? 3 : 0);
  product = Math.min(25, product);

  const competitors = [...new Set(list(v.get('competitor_brands')).map(normText))];
  const competitor = competitors.length === 1 ? -6 : competitors.length >= 2 ? 4 : 0;
  const fitScore = Math.max(0, Math.min(100, Math.round(volume + decor + product + competitor)));

  const priority: Priority | null = tier === 'Hot' ? (fitScore >= 55 ? 'P1' : 'P2') : tier === 'Warm' ? (fitScore >= 55 ? 'P2' : 'P3') : tier === 'Cold' ? 'P4' : null;

  // the lines outside the standard sales priority
  let track: ScoreResult['track'] = 'sales';
  if (tier === 'Disqualified') track = 'disqualified';
  else if (kind === 'panel_manufacturer') { track = 'partnership'; tags.push('partnership list'); }
  else if (ctx.stage === 'customer') track = 'existing';
  else if (ctx.dealerInCountry) { track = 'dealer_review'; tags.push('region with a TECE dealer'); }
  else if (kind === 'workshop') { track = 'workshop_dealer'; tags.push('workshop: refer to the dealer'); }
  if (floorWhy) notes.push(`Raised to at least ${floor}: ${floorWhy}.`);

  return {
    ...base, status, track, candidate: null,
    purchase: { score, tier, parts: { segment, flow, size, special }, floor: floorWhy ? `${floor} - ${floorWhy}` : null, caps },
    fit: { score: fitScore, priority, parts: { volume, decor, product, competitor } },
  };
}

// the old 0-10 rating, kept for lists and sorting: the Purchase Score divided by ten
export const rateOf = (r: ScoreResult): number => (r.purchase ? Math.round(r.purchase.score / 10) : r.candidate ? Math.round(r.candidate.points / 10) : 0);

// what the clean-up page calls it: none = nothing found, unrelated = disqualified, unsuitable = cold and very low, fit = the rest
export function verdictOf(r: ScoreResult): 'fit' | 'none' | 'unrelated' | 'unsuitable' {
  if (r.status === 'no_website') return 'none';
  if (!r.purchase) return 'none';
  if (r.purchase.tier === 'Disqualified') return 'unrelated';
  if (r.purchase.tier === 'Cold' && r.purchase.score < 25) return 'unsuitable';
  return 'fit';
}
