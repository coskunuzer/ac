-- Export performance: the SAP exports (ledger of every customer, production backlog, orders waiting for confirmation or advance payment,
-- dispatch queue, customer master), kept in tables so the Performance page can be worked out from them.

-- one row for every line of the export ledger ("İHRACAT DURUM EXCEL"): never wiped, new lines are added by their hash
CREATE TABLE IF NOT EXISTS ledger_transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hash TEXT NOT NULL UNIQUE,
  sheet_name TEXT NOT NULL,
  seq INTEGER NOT NULL,            -- the row of the sheet (to keep the order of one day)
  tx_date TEXT NOT NULL,           -- YYYY-MM-DD
  description TEXT,
  debit REAL,                      -- invoiced / shipped (they owe us)
  credit REAL,                     -- payment received
  balance REAL,                    -- the running balance of the ledger (positive = they owe us)
  currency TEXT NOT NULL DEFAULT 'EUR',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_ledger_sheet ON ledger_transactions (sheet_name, tx_date, seq);

CREATE TABLE IF NOT EXISTS customer_financial_summary (
  sheet_name TEXT PRIMARY KEY,
  currency TEXT NOT NULL DEFAULT 'EUR',
  balance REAL NOT NULL DEFAULT 0,
  tx_count INTEGER NOT NULL DEFAULT 0,
  first_date TEXT,
  last_invoice_date TEXT,
  last_payment_date TEXT,
  last_transaction_date TEXT,
  total_invoiced REAL NOT NULL DEFAULT 0,   -- in the currency of the ledger
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- the SAP customer master (replaced on every upload)
CREATE TABLE IF NOT EXISTS sap_customers (
  sap_no TEXT PRIMARY KEY,
  name TEXT,
  country TEXT,
  contact TEXT,
  email TEXT,
  phone TEXT,
  website TEXT,
  first_order TEXT,
  last_order TEXT,
  status TEXT,
  status_key TEXT,                 -- active | passive | dormant
  orders INTEGER,
  m2 REAL,
  net_eur REAL,
  net_usd REAL,
  note TEXT
);

-- ZSD0013: what is still to be delivered (replaced on every upload)
CREATE TABLE IF NOT EXISTS export_production_backlog (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_no TEXT, item_no TEXT, doc_date TEXT, delivery_date TEXT, sap_no TEXT, customer TEXT,
  product_group TEXT, material TEXT, material_name TEXT, thickness REAL, width REAL, roll_length REAL,
  pending_qty REAL, unit TEXT, pending_kg REAL, pending_m2 REAL, value_eur REAL, customer_ref TEXT
);
CREATE INDEX IF NOT EXISTS idx_backlog_sap ON export_production_backlog (sap_no);

-- ZSD0010: orders not confirmed / waiting for the advance payment (replaced on every upload)
CREATE TABLE IF NOT EXISTS export_pipeline_blockers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sd_no TEXT, item_no TEXT, doc_date TEXT, sap_no TEXT, customer TEXT, material TEXT, material_name TEXT,
  thickness REAL, width REAL, qty REAL, unit TEXT, net_value REAL, currency TEXT, confirmed TEXT, status TEXT
);
CREATE INDEX IF NOT EXISTS idx_blockers_sap ON export_pipeline_blockers (sap_no);

-- VF04: ready to be invoiced / dispatched (replaced on every upload)
CREATE TABLE IF NOT EXISTS export_dispatch_queue (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sd_no TEXT, billing_date TEXT, sap_no TEXT, customer TEXT, country TEXT, city TEXT,
  net_value REAL, currency TEXT, weight REAL, sales_rep TEXT, ops_rep TEXT
);
CREATE INDEX IF NOT EXISTS idx_dispatch_sap ON export_dispatch_queue (sap_no);

-- which ledger sheet is which SAP customer (found by the program, or chosen by an admin)
CREATE TABLE IF NOT EXISTS customer_aliases (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sheet_name TEXT NOT NULL UNIQUE,
  sap_no TEXT,
  card_id INTEGER,
  is_manually_verified INTEGER NOT NULL DEFAULT 0,
  how TEXT
);
CREATE INDEX IF NOT EXISTS idx_alias_sap ON customer_aliases (sap_no);

CREATE TABLE IF NOT EXISTS export_targets (
  sap_no TEXT NOT NULL,
  year INTEGER NOT NULL,
  target_eur REAL NOT NULL,
  set_by INTEGER,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (sap_no, year)
);

-- an old, small account a rep has hidden from his list (never possible for a debt of 10,000 or more)
CREATE TABLE IF NOT EXISTS perf_hidden (
  sap_no TEXT NOT NULL,
  user_id INTEGER NOT NULL,
  at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (sap_no, user_id)
);

-- an admin lets a customer with a critical debt be quoted anyway
CREATE TABLE IF NOT EXISTS perf_hold_override (
  sap_no TEXT PRIMARY KEY,
  by_user INTEGER,
  note TEXT,
  at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- the AI's reading of an account that stopped ordering (kept)
CREATE TABLE IF NOT EXISTS perf_diagnostics (
  sap_no TEXT PRIMARY KEY,
  body TEXT NOT NULL,
  made_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS perf_uploads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT NOT NULL,
  file_name TEXT,
  rows INTEGER,
  added INTEGER,
  note TEXT,
  by_user INTEGER,
  at TEXT NOT NULL DEFAULT (datetime('now'))
);
