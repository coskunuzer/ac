import { db } from '../db/connection';

// The audit log: who changed what and when (price, owner, rating, handling, the customer's own prices, a ledger pair ...).
// Never in the way: a failure to write a line is logged and the work goes on.
export interface Actor { id: number; display_name?: string | null; username?: string | null }

export function audit(user: Actor | null | undefined, cardId: number | null, action: 'change' | 'prices' | 'assistant' | 'review', field: string | null, oldValue: unknown, newValue: unknown, note: string | null = null): void {
  try {
    const v = (x: unknown) => (x === null || x === undefined || x === '' ? null : String(x).slice(0, 300));
    db.prepare('INSERT INTO audit_log (user_id, user_name, card_id, action, field, old_value, new_value, note) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
      .run(user?.id ?? null, user ? (user.display_name || user.username || null) : null, cardId, action, field, v(oldValue), v(newValue), note ? note.slice(0, 300) : null);
  } catch (err) {
    console.error('Audit log failed:', err);
  }
}

// the fields of a customer that are watched: a change in any of them is written down
export const WATCHED: Record<string, string> = {
  person: 'Responsible person', rate: 'Rating', handling: 'Who works this customer', offer_percent: 'Price level', stage: 'Stage', sap: 'SAP number', market: 'Market', language: 'Offer language', lead_source: 'Lead source', company: 'Company', country: 'Country',
};
export function auditDiff(user: Actor | null | undefined, before: Record<string, unknown> | undefined, after: Record<string, unknown> | undefined): void {
  if (!before || !after) return;
  for (const k of Object.keys(WATCHED)) if ((before[k] ?? null) !== (after[k] ?? null)) audit(user, Number(after.id ?? before.id), 'change', WATCHED[k], before[k], after[k]);
}
