-- Per-person menu / money / actions. A person WITHOUT a row here keeps exactly what they had before (nothing changes until an admin edits them).
CREATE TABLE IF NOT EXISTS user_perms (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  menu TEXT NOT NULL DEFAULT '[]',
  actions TEXT NOT NULL DEFAULT '[]',
  money TEXT NOT NULL DEFAULT '[]',
  start_page TEXT,
  preset TEXT,
  updated_by INTEGER,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- append-only: who changed whose permissions, and what they were before / after
CREATE TABLE IF NOT EXISTS perm_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  by_user INTEGER,
  before TEXT,
  after TEXT,
  at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- the e-mails Nakliye sends, editable by an admin (a missing row = the built-in text)
CREATE TABLE IF NOT EXISTS ship_templates (
  key TEXT NOT NULL,
  lang TEXT NOT NULL,
  subject TEXT,
  body TEXT NOT NULL,
  updated_by INTEGER,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (key, lang)
);
