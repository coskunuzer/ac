// UX polish, round 2: small translated pieces dropped into older chunks by patch/js/95-polish.js.
// Styles: patch/css/95-polish.css (prefix xpo-). Turkish: patch/tr-polish.json.
import { h, Fragment, useState, Link, useAuth, useT, shortDate } from "./x-kit-1W3jRMzJ.js";

// a translated text for chunks that have no translator of their own
export function XT({ k, v }) {
  const t = useT();
  return t(k, v);
}

// Duplicates: one short sentence, the rest behind "How does this work?"
export function DupLead() {
  const t = useT();
  return h(
    "div",
    { className: "xpo-dup-lead" },
    h("p", null, t("Keep one record of each company; the other people move under it with their notes, offers and files.")),
    h(
      "details",
      null,
      h("summary", null, t("How does this work?")),
      h(
        "p",
        null,
        t("Companies are listed when they have the same name, the same company e-mail address, the same web site or the same telephone number. Only customers you may see are listed; two companies with the same name in different countries are not mixed up."),
      ),
      h("p", null, t("To put two customers together by hand, open one and choose More → Combine with another customer.")),
    ),
  );
}

// Targets: no sales data yet -> say what will come and give a way forward
export function TargetsEmpty({ msg, raw }) {
  const t = useT();
  const { user } = useAuth();
  const admin = user && user.role === "admin";
  return h(
    "div",
    { className: "xpo-empty xpo-empty--chart", role: "status" },
    // the server's sentence talks to an admin; everybody else gets the plain fact
    h("p", { className: "xpo-empty-t" }, !admin && /^There is no sales data yet/.test(raw || "") ? t("There is no sales data yet.") : msg || t("There is no sales data yet.")),
    h("p", { className: "xpo-empty-s" }, t("Your targets and the forecast appear here as soon as the sales history is in.")),
    h(
      "div",
      { className: "xpo-empty-acts" },
      h(Link, { className: "tc-btn tc-btn--secondary tc-btn--sm", to: "/performance" }, t("See my performance")),
      admin ? h(Link, { className: "tc-btn tc-btn--sm", to: "/intelligence" }, t("Load the sales history")) : null,
    ),
  );
}


// ==== Round 3 ====

// Fair results: a long day chart opens at the latest days (ref callback on the scroller)
export function scrollEnd(el) {
  if (el) requestAnimationFrame(() => { el.scrollLeft = el.scrollWidth; });
}

// Fair results: under a long day chart, the first and the last day instead of hundreds of unreadable labels
export function DayRange({ a, b, n }) {
  const t = useT();
  const d = (iso) => shortDate(iso) + " " + String(iso).slice(0, 4);
  return h(
    Fragment,
    null,
    h("span", { className: "xpo-dr-a" }, d(a)),
    h("span", { className: "xpo-dr-n" }, t("{n} days · scroll for earlier days", { n })),
    h("span", { className: "xpo-dr-b" }, d(b)),
  );
}

// "Show N more" under a long list
export function MoreBtn({ rest, step, onMore }) {
  const t = useT();
  return h(
    "div",
    { className: "xpo-more" },
    h(
      "button",
      { type: "button", className: "btn btn-secondary btn-sm", onClick: onMore },
      t("Show {n} more", { n: Math.min(step, rest) }),
    ),
    h("span", { className: "xpo-more-left" }, t("{n} left", { n: rest })),
  );
}

// My day: a long to-do list renders 30 rows, then grows on demand (items are ready <li> elements)
export function MoreItems({ items, step = 30 }) {
  const [n, setN] = useState(step);
  const t = useT();
  if (!Array.isArray(items) || items.length <= n) return h(Fragment, null, items);
  const rest = items.length - n;
  return h(
    Fragment,
    null,
    items.slice(0, n),
    h(
      "li",
      { className: "xpo-more-li", key: "xpo-more" },
      h("button", { type: "button", className: "btn btn-secondary btn-sm", onClick: () => setN(n + step) }, t("Show {n} more", { n: Math.min(step, rest) })),
      h("span", { className: "xpo-more-left" }, t("{n} left", { n: rest })),
    ),
  );
}

// Scrolling tab rows: the chosen tab is always in view, and soft edges show that the row scrolls
function edges(el) {
  const max = el.scrollWidth - el.clientWidth;
  const v = [];
  if (max > 2 && el.scrollLeft > 2) v.push("l");
  if (max > 2 && el.scrollLeft < max - 2) v.push("r");
  el.setAttribute("data-xpo-fade", v.join(" "));
}
export function tabRow(el) {
  if (!el) return;
  if (!el.__xpo) {
    el.__xpo = 1;
    el.addEventListener("scroll", () => edges(el), { passive: true });
    if (typeof ResizeObserver !== "undefined") new ResizeObserver(() => edges(el)).observe(el);
  }
  const s = el.querySelector('[aria-selected="true"]');
  if (s) {
    const a = el.getBoundingClientRect();
    const b = s.getBoundingClientRect();
    if (b.left < a.left + 8 || b.right > a.right - 8) el.scrollLeft += b.left + b.width / 2 - (a.left + a.width / 2);
  }
  edges(el);
}
