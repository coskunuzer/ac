import ExcelJS from 'exceljs';
import fs from 'fs';
import path from 'path';
import { db } from '../db/connection';
import { settingsModel } from '../models/settingsModel';
import { userModel } from '../models/userModel';
import { DEPARTMENTS, REASONS, STATUSES } from '../data/complaintPanel';
import { sendThankYouEmail } from './thankYouEmail';
import { askJson } from './perfActions';

// The complaints workflow of "TECE CRM Müşteri Şikayeti Paneli.xlsx":
//   sales writes it (steps 1-5)  ->  quality (KYS) receives, numbers, reviews and routes it (6-7)  ->  departments answer  ->  quality closes it (8).
// Sales sees a friendly status and never the internal notes (K04); every change of status is written down (K02).

export interface CRow {
  id: number; created_by: number; card_id: number | null; customer_name: string | null; customer_contact: string | null; customer_email: string | null; customer_country: string | null;
  order_no: string | null; kind: 'quantity' | 'quality' | 'delivery' | 'other'; raw_text: string | null; items_json: string | null; amount_wasted: number | null; currency: string; polished_json: string | null;
  status: string; sent_at: string | null; sent_to: string | null; created_at: string; updated_at: string;
  reported_date: string | null; product_code: string | null; order_qty: string | null; complained_qty: string | null; reason_code: string | null; channel: string | null; customer_request: string | null;
  complaint_no: string | null; internal_status: string | null; priority: string | null; op_occurred: string | null; op_detected: string | null; eval_team: string | null;
  root_cause: string | null; result_action: string | null; capa_required: number | null; capa_date: string | null; customer_replied: number | null; customer_reply_date: string | null;
  approved_reply: string | null; info_request: string | null; info_due: string | null; submitted_at: string | null; closed_at: string | null; reopen_count: number;
  credit_note: string | null; rep_user_id: number | null; result_text: string | null; share_result: number; close_target: string | null;
}
export interface TaskRow {
  id: number; complaint_id: number; department: string; owner_user_id: number | null; due_date: string | null; instruction: string | null; state: string;
  root_cause: string | null; correction: string | null; corrective: string | null; preventive: string | null; effectiveness: string | null; review_note: string | null;
  created_by: number | null; created_at: string; submitted_at: string | null; reviewed_at: string | null;
}

const today = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });

// the reasons and departments of the panel, put in the database once (so they can be joined and counted)
let seeded = false;
export function ensurePanel(): void {
  if (seeded) return;
  seeded = true;
  if (!(db.prepare('SELECT COUNT(*) AS n FROM complaint_reasons').get() as { n: number }).n) {
    const ins = db.prepare('INSERT OR IGNORE INTO complaint_reasons (code, name) VALUES (?, ?)');
    for (const r of REASONS) ins.run(r.code, r.name);
  }
  if (!(db.prepare('SELECT COUNT(*) AS n FROM complaint_departments').get() as { n: number }).n) {
    const ins = db.prepare('INSERT OR IGNORE INTO complaint_departments (name) VALUES (?)');
    for (const d of DEPARTMENTS) ins.run(d);
  }
}

export const statusInfo = (internal: string | null) => STATUSES.find((s) => s.internal === internal) ?? null;
export const isQuality = (u: { role: string; area?: string | null }) => u.role === 'admin' || u.area === 'quality';

// what sales may see: the label and the description of the status (and what quality asks for), never the internal notes or the root cause
export function externalView(row: CRow) {
  const s = statusInfo(row.internal_status);
  return {
    label: row.internal_status ? s?.label ?? row.internal_status : 'Taslak',
    description: row.internal_status ? s?.description ?? '' : 'Henüz kaliteye gönderilmedi.',
    infoRequest: row.internal_status === 'Bilgi bekleniyor' ? row.info_request : null,
    infoDue: row.internal_status === 'Bilgi bekleniyor' ? row.info_due : null,
    approvedReply: row.approved_reply,
    complaintNo: row.complaint_no,
    closed: row.internal_status === 'Kapatıldı',
  };
}

export function logEvent(complaintId: number, userId: number | null, kind: string, from: string | null, to: string | null, note: string | null, internal = true): void {
  db.prepare('INSERT INTO complaint_events (complaint_id, user_id, kind, from_status, to_status, note, internal) VALUES (?, ?, ?, ?, ?, ?, ?)').run(complaintId, userId, kind, from, to, note, internal ? 1 : 0);
}

// ---- the numbers: MHBK + running number + the number of the reason + the day (ddmmyy), as on the forms: MHBK281-07-031126 --------------------------------
export function nextComplaintNo(reasonCode: string, reported: string): string {
  const seq = (parseInt(settingsModel.get('complaint_seq') ?? '281', 10) || 281) + 1;
  settingsModel.set('complaint_seq', String(seq));
  const d = /^(\d{4})-(\d{2})-(\d{2})/.exec(reported) ?? /^(\d{4})-(\d{2})-(\d{2})/.exec(today())!;
  return `MHBK${seq}-${String((parseInt(reasonCode.replace(/\D/g, ''), 10) || 0) % 100).padStart(2, '0')}-${d[3]}${d[2]}${d[1].slice(2)}`;
}

// ---- statuses ---------------------------------------------------------------------------------------------------------------------------
// the 8 statuses of the panel ("Durum Takibi"); "Bilgi bekleniyor" can be asked from every open status and goes back to where it came from
const ALLOWED: Record<string, string[]> = {
  'Yeni kayıt': ['Ön inceleme', 'Bilgi bekleniyor'],
  'Bilgi bekleniyor': ['Ön inceleme', 'Birim yanıtı bekleniyor', 'KYS değerlendirmesi bekleniyor', 'Müşteri yanıtı bekleniyor', 'Yeniden açıldı'],
  'Ön inceleme': ['Birim yanıtı bekleniyor', 'KYS değerlendirmesi bekleniyor', 'Bilgi bekleniyor'],
  'Birim yanıtı bekleniyor': ['KYS değerlendirmesi bekleniyor', 'Ön inceleme', 'Bilgi bekleniyor'],
  'KYS değerlendirmesi bekleniyor': ['Birim yanıtı bekleniyor', 'Müşteri yanıtı bekleniyor', 'Kapatıldı', 'Bilgi bekleniyor'],
  'Müşteri yanıtı bekleniyor': ['Kapatıldı', 'KYS değerlendirmesi bekleniyor', 'Bilgi bekleniyor'],
  'Kapatıldı': ['Yeniden açıldı'],
  'Yeniden açıldı': ['Ön inceleme', 'Birim yanıtı bekleniyor'],
};
export const nextStatuses = (from: string | null): string[] => (from ? ALLOWED[from] ?? [] : []);

// where a complaint was before it waited for information from sales
export function statusBeforeInfo(complaintId: number): string {
  const e = db.prepare("SELECT from_status FROM complaint_events WHERE complaint_id = ? AND kind = 'status' AND to_status = 'Bilgi bekleniyor' ORDER BY id DESC LIMIT 1").get(complaintId) as { from_status: string | null } | undefined;
  const from = e?.from_status ?? 'Ön inceleme';
  return from === 'Yeni kayıt' ? 'Ön inceleme' : from;
}

export function openTasks(complaintId: number): TaskRow[] {
  return db.prepare("SELECT * FROM complaint_tasks WHERE complaint_id = ? AND state IN ('open', 'sent', 'more_info')").all(complaintId) as unknown as TaskRow[];
}

// Moves a complaint to another status, only along the allowed lines, and writes it down. Returns an error text, or null.
export function moveStatus(row: CRow, to: string, userId: number | null, note: string | null): string | null {
  const from = row.internal_status;
  if (!from) return 'This complaint has not been sent to quality yet.';
  if (!nextStatuses(from).includes(to)) return `"${from}" cannot go to "${to}". Allowed next: ${nextStatuses(from).join(', ') || 'none'}.`;
  if (to === 'Kapatıldı') {
    if (!row.reason_code || !row.complaint_no) return 'Give the complaint its reason and number before closing.';
    if (!row.result_action?.trim() && !row.result_text?.trim()) return 'Write the result and the action taken before closing.';
    if (openTasks(row.id).length) return 'A department has not answered yet, or an answer is not accepted: the complaint cannot be closed.';
  }
  if (to === 'Yeniden açıldı' && !note?.trim()) return 'Write the reason for reopening.';
  if (to === 'Bilgi bekleniyor' && !row.info_request?.trim()) return 'Write what you ask from sales first (Request information).';
  db.prepare('UPDATE complaints SET internal_status = ?, updated_at = datetime(\'now\') WHERE id = ?').run(to, row.id);
  if (to === 'Kapatıldı') db.prepare("UPDATE complaints SET closed_at = datetime('now') WHERE id = ?").run(row.id);
  if (to === 'Yeniden açıldı') db.prepare('UPDATE complaints SET closed_at = NULL, reopen_count = reopen_count + 1 WHERE id = ?').run(row.id);
  logEvent(row.id, userId, 'status', from, to, note, false);
  return null;
}

// ---- notices (an e-mail; the work itself is in the CRM) ---------------------------------------------------------------------------------------
async function mailTo(to: string[], subject: string, body: string): Promise<void> {
  const list = [...new Set(to.map((a) => a.trim()).filter((a) => /@/.test(a)))];
  if (!list.length) return;
  const testTo = settingsModel.get('test_mode') === '1' ? settingsModel.get('test_email') || null : null;
  try {
    await sendThankYouEmail({ to: list.join(', '), subject, body, signature: { text: 'TECE customer system', html: '<div style="font-family:Arial,sans-serif;color:#5e6676;font-size:12px">TECE customer system</div>' }, testTo });
  } catch (err) {
    console.error('Complaint notice failed:', err);
  }
}

export const sendNotice = mailTo;
export const qualityEmails = (): string[] => userModel.listAll().filter((u) => u.area === 'quality' && u.is_active && u.email).map((u) => u.email as string);

export async function noticeToQuality(row: CRow, who: string): Promise<void> {
  const rep = row.rep_user_id ? userModel.findById(row.rep_user_id)?.email : null;
  const to = [...qualityEmails(), ...(settingsModel.get('complaint_to') ?? 'tarik@tece.com.tr').split(/[,;\s]+/), rep ?? ''];
  await mailTo(to, `Yeni müşteri şikayeti: ${row.customer_name}${row.order_no ? ` - ${row.order_no}` : ''}`, `Merhaba,\n\n${who} yeni bir müşteri şikayeti kaydetti: ${row.customer_name}${row.customer_country ? ` (${row.customer_country})` : ''}.\n\nKayıt CRM > Şikayetler ekranında "Yeni kayıt" durumunda sizi bekliyor.`);
}

export async function noticeToDepartment(row: CRow, task: TaskRow): Promise<void> {
  const dep = db.prepare('SELECT head_user_id, head_email FROM complaint_departments WHERE name = ?').get(task.department) as { head_user_id: number | null; head_email: string | null } | undefined;
  const head = dep?.head_user_id ? userModel.findById(dep.head_user_id) : null;
  await mailTo([head?.email ?? '', dep?.head_email ?? ''], `Şikayet görevi: ${row.complaint_no ?? `#${row.id}`} - ${task.department}`, `Merhaba,\n\n${task.department} birimi için bir müşteri şikayeti görevi açıldı.\n\nŞikayet: ${row.complaint_no ?? `#${row.id}`} - ${row.customer_name}\nSon tarih: ${task.due_date ?? '-'}\n${task.instruction ? `\nKalite notu: ${task.instruction}\n` : ''}\nLütfen CRM > Görevlerim ekranından kök neden, düzeltme ve önleyici faaliyeti girin.`);
}

export async function noticeToSales(row: CRow, text: string): Promise<void> {
  const u = userModel.findById(row.created_by);
  const rep = row.rep_user_id ? userModel.findById(row.rep_user_id) : null;
  await mailTo([u?.email ?? '', rep?.email ?? ''], `Şikayet güncellemesi: ${row.complaint_no ?? `#${row.id}`}`, `${text}\n\n${row.customer_name}${row.order_no ? ` - ${row.order_no}` : ''}\nCRM > Şikayetler ekranından görebilirsiniz.`);
}

// ---- the AI picks the standard reason from the text ---------------------------------------------------------------------------------------------
export async function suggestReason(text: string): Promise<{ code: string; name: string } | null> {
  const j = await askJson(
    [`A customer of TECE (edgebanding maker) complains. Pick the ONE best matching standard complaint reason code. Answer {"code": "S0xx"} using only codes from this list:`, REASONS.map((r) => `${r.code} ${r.name}`).join('\n'), `Complaint:\n${text.slice(0, 2500)}`].join('\n\n'),
    { type: 'OBJECT', properties: { code: { type: 'STRING' } }, required: ['code'] },
  );
  const code = String(j?.code ?? '').trim().toUpperCase();
  const hit = REASONS.find((r) => r.code === code);
  return hit ?? null;
}

// ---- the dashboard -------------------------------------------------------------------------------------------------------------------------------
export function dashboard() {
  const one = <T,>(sql: string, ...a: unknown[]) => db.prepare(sql).get(...(a as never[])) as T;
  const all = <T,>(sql: string, ...a: unknown[]) => db.prepare(sql).all(...(a as never[])) as T[];
  const open = one<{ n: number }>("SELECT COUNT(*) AS n FROM complaints WHERE internal_status IS NOT NULL AND internal_status != 'Kapatıldı'").n;
  const closed = one<{ n: number }>("SELECT COUNT(*) AS n FROM complaints WHERE internal_status = 'Kapatıldı'").n;
  const avg = one<{ d: number | null }>("SELECT AVG(julianday(closed_at) - julianday(submitted_at)) AS d FROM complaints WHERE internal_status = 'Kapatıldı' AND closed_at IS NOT NULL AND submitted_at IS NOT NULL").d;
  const overdue = one<{ n: number }>("SELECT COUNT(*) AS n FROM complaint_tasks WHERE state IN ('open', 'more_info') AND due_date IS NOT NULL AND due_date < ?", today()).n;
  const year = today().slice(0, 4);
  const monthly = all<{ m: string; n: number }>("SELECT substr(COALESCE(reported_date, substr(created_at, 1, 10)), 1, 7) AS m, COUNT(*) AS n FROM complaints WHERE internal_status IS NOT NULL AND substr(COALESCE(reported_date, substr(created_at, 1, 10)), 1, 4) = ? GROUP BY m ORDER BY m", year);
  return {
    open, closed, total: open + closed, avgDays: avg === null ? null : Math.round(avg * 10) / 10, overdueTasks: overdue,
    waitingOnSales: one<{ n: number }>("SELECT COUNT(*) AS n FROM complaints WHERE internal_status = 'Bilgi bekleniyor'").n,
    unassigned: one<{ n: number }>("SELECT COUNT(*) AS n FROM complaints WHERE internal_status IN ('Yeni kayıt')").n,
    byStatus: all<{ status: string; n: number }>("SELECT internal_status AS status, COUNT(*) AS n FROM complaints WHERE internal_status IS NOT NULL GROUP BY internal_status ORDER BY n DESC"),
    byDepartment: all<{ dept: string; n: number }>("SELECT department AS dept, COUNT(DISTINCT complaint_id) AS n FROM complaint_tasks GROUP BY department ORDER BY n DESC LIMIT 12"),
    byReason: all<{ code: string; name: string; n: number }>("SELECT c.reason_code AS code, COALESCE(r.name, c.reason_code) AS name, COUNT(*) AS n FROM complaints c LEFT JOIN complaint_reasons r ON r.code = c.reason_code WHERE c.reason_code IS NOT NULL AND c.internal_status IS NOT NULL GROUP BY c.reason_code ORDER BY n DESC LIMIT 15"),
    monthly, year,
    // "Bölüm bazlı hata kaynağı": the department where the fault happened (as quality wrote it), counted
    bySource: all<{ dept: string; n: number }>("SELECT op_occurred AS dept, COUNT(*) AS n FROM complaints WHERE internal_status IS NOT NULL AND COALESCE(op_occurred, '') != '' GROUP BY op_occurred ORDER BY n DESC LIMIT 12"),
    byCustomer: all<{ customer: string; n: number }>("SELECT customer_name AS customer, COUNT(*) AS n FROM complaints WHERE internal_status IS NOT NULL GROUP BY LOWER(customer_name) ORDER BY n DESC, customer_name LIMIT 10"),
    // the same reason again: for the same customer or in the same product, two times or more
    repeats: all<{ reason: string; customer: string; product: string | null; n: number; last: string }>(`SELECT COALESCE(r.name, c.reason_code) AS reason, c.customer_name AS customer, c.product_code AS product, COUNT(*) AS n, MAX(COALESCE(c.reported_date, substr(c.created_at, 1, 10))) AS last
      FROM complaints c LEFT JOIN complaint_reasons r ON r.code = c.reason_code WHERE c.internal_status IS NOT NULL AND c.reason_code IS NOT NULL
      GROUP BY c.reason_code, LOWER(c.customer_name) HAVING COUNT(*) > 1 ORDER BY n DESC, last DESC LIMIT 10`),
    repeatsByProduct: all<{ reason: string; product: string; n: number }>(`SELECT COALESCE(r.name, c.reason_code) AS reason, c.product_code AS product, COUNT(*) AS n FROM complaints c LEFT JOIN complaint_reasons r ON r.code = c.reason_code
      WHERE c.internal_status IS NOT NULL AND c.reason_code IS NOT NULL AND COALESCE(c.product_code, '') != '' GROUP BY c.reason_code, UPPER(c.product_code) HAVING COUNT(*) > 1 ORDER BY n DESC LIMIT 10`),
  };
}

export interface Filters { status?: string; q?: string; dept?: string; reason?: string; scope?: 'open' | 'closed' | '' }
export function registerRows(f: Filters): (CRow & { reason_name: string | null; reporter: string | null; depts: string | null; open_tasks: number; late_tasks: number })[] {
  const where: string[] = ['c.internal_status IS NOT NULL'];
  const p: unknown[] = [];
  if (f.status) { where.push('c.internal_status = ?'); p.push(f.status); }
  if (f.scope === 'open') where.push("c.internal_status != 'Kapatıldı'");
  if (f.scope === 'closed') where.push("c.internal_status = 'Kapatıldı'");
  if (f.reason) { where.push('c.reason_code = ?'); p.push(f.reason); }
  if (f.dept) { where.push('EXISTS (SELECT 1 FROM complaint_tasks t WHERE t.complaint_id = c.id AND t.department = ?)'); p.push(f.dept); }
  if (f.q) { where.push("(LOWER(COALESCE(c.customer_name, '') || ' ' || COALESCE(c.complaint_no, '') || ' ' || COALESCE(c.order_no, '') || ' ' || COALESCE(c.product_code, '')) LIKE ?)"); p.push(`%${f.q.toLowerCase()}%`); }
  return db.prepare(`SELECT c.*, r.name AS reason_name, u.display_name AS reporter,
      (SELECT GROUP_CONCAT(DISTINCT department) FROM complaint_tasks t WHERE t.complaint_id = c.id) AS depts,
      (SELECT COUNT(*) FROM complaint_tasks t WHERE t.complaint_id = c.id AND t.state IN ('open', 'sent', 'more_info')) AS open_tasks,
      (SELECT COUNT(*) FROM complaint_tasks t WHERE t.complaint_id = c.id AND t.state IN ('open', 'more_info') AND t.due_date IS NOT NULL AND t.due_date < '${today()}') AS late_tasks
    FROM complaints c LEFT JOIN complaint_reasons r ON r.code = c.reason_code LEFT JOIN users u ON u.id = c.created_by
    WHERE ${where.join(' AND ')} ORDER BY c.id DESC LIMIT 1000`).all(...(p as never[])) as never;
}

// the TECE letterhead (logo, line) on top of an Excel sheet
function logo(wb: ExcelJS.Workbook, ws: ExcelJS.Worksheet, width: number): void {
  try {
    const file = path.join(__dirname, '..', '..', 'assets', 'letterhead-header.png');
    if (!fs.existsSync(file)) return;
    const id = wb.addImage({ filename: file, extension: 'png' });
    ws.addImage(id, { tl: { col: 0, row: 0 }, ext: { width, height: Math.round(width * 0.0825) } });
  } catch (err) { console.error('Logo not added to the Excel:', err); }
}

const dmy = (iso: string | null | undefined) => (iso ? `${iso.slice(8, 10)}.${iso.slice(5, 7)}.${iso.slice(0, 4)}` : '');

export async function registerWorkbook(rows: ReturnType<typeof registerRows>): Promise<Buffer> {
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Şikayet Kayıtları');
  const cols = [
    { header: 'Şikayet No', width: 22 }, { header: 'Tarih', width: 12 }, { header: 'Müşteri', width: 34 }, { header: 'Ülke', width: 16 }, { header: 'Kaydeden', width: 20 }, { header: 'Ürün Kodu', width: 16 }, { header: 'Sipariş No', width: 14 },
    { header: 'Şikayet Sebebi', width: 28 }, { header: 'Öncelik', width: 10 }, { header: 'Durum', width: 26 }, { header: 'Birimler', width: 30 }, { header: 'Kök Neden', width: 40 }, { header: 'Sonuç / Aksiyon', width: 40 },
    { header: 'Düzeltici Faaliyet', width: 12 }, { header: 'Müşteriye Dönüş', width: 14 }, { header: 'Gönderim', width: 12 }, { header: 'Kapanış', width: 12 }, { header: 'Çözüm Süresi (gün)', width: 14 },
  ];
  ws.columns = cols.map((c) => ({ width: c.width }));
  logo(wb, ws, 760);
  ws.getRow(1).height = 46;
  const head = ws.getRow(3);
  head.values = cols.map((c) => c.header);
  head.font = { bold: true, color: { argb: 'FFFFFFFF' } };
  head.eachCell((c) => { c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF17243E' } }; });
  ws.views = [{ state: 'frozen', ySplit: 3 }];
  for (const r of rows) {
    const days = r.closed_at && r.submitted_at ? Math.round(((Date.parse(r.closed_at.replace(' ', 'T')) - Date.parse(r.submitted_at.replace(' ', 'T'))) / 86_400_000) * 10) / 10 : '';
    ws.addRow([r.complaint_no ?? '', dmy(r.reported_date), r.customer_name, r.customer_country, r.reporter, r.product_code, r.order_no, r.reason_name ?? '', r.priority ?? '', r.internal_status, r.depts ?? '', r.root_cause ?? '', [r.result_text, r.result_action].filter(Boolean).join(' | '),
      r.capa_required === null ? '' : r.capa_required ? 'Evet' : 'Hayır', r.customer_replied === null ? '' : r.customer_replied ? 'Evet' : 'Hayır', dmy(r.submitted_at?.slice(0, 10)), dmy(r.closed_at?.slice(0, 10)), days]);
  }
  ws.autoFilter = { from: 'A3', to: 'R3' };
  return Buffer.from(await wb.xlsx.writeBuffer());
}

// the corporate "Hata Bildirim Formu" (the same blocks and wording as MHBK281-07-031126-Hata Bildirim Formu.xls)
export async function formWorkbook(row: CRow): Promise<Buffer> {
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Hata Bildirim');
  ws.columns = [{ width: 26 }, { width: 14 }, { width: 16 }, { width: 8 }, { width: 18 }, { width: 14 }, { width: 22 }, { width: 8 }, { width: 8 }, { width: 8 }, { width: 8 }, { width: 8 }];
  const thin = { style: 'thin' as const };
  const box = (a: string) => { const c = ws.getCell(a); c.border = { top: thin, left: thin, bottom: thin, right: thin }; };
  const put = (a: string, v: string | number, bold = false) => { const c = ws.getCell(a); c.value = v; c.font = { bold, size: 10 }; c.alignment = { vertical: 'middle', wrapText: true }; };
  const merge = (r: string, v = '', bold = false) => { ws.mergeCells(r); put(r.split(':')[0], v, bold); };
  const colNo = (a: string) => [...a.replace(/\d+/g, '')].reduce((n, ch) => n * 26 + ch.charCodeAt(0) - 64, 0);
  const rowNo = (a: string) => parseInt(a.replace(/\D+/g, ''), 10);
  const frame = (r: string) => { const [a, b] = r.split(':'); for (let row = rowNo(a); row <= rowNo(b); row += 1) for (let col = colNo(a); col <= colNo(b); col += 1) ws.getCell(row, col).border = { top: thin, left: thin, bottom: thin, right: thin }; };
  logo(wb, ws, 640);
  ws.getRow(1).height = 46;
  merge('B2:H4', 'Hata Bildirim Formu', true);
  const doc = (k: string, d: string) => settingsModel.get(k) || d;
  put('I2', `Dök. No.: ${doc('form_doc_no', 'F.235')}`, true); put('I3', `Rev: ${doc('form_rev', '01')}   Rev. Tarihi: ${doc('form_rev_date', '16.02.2026')}`); put('I4', `Yay. Tarihi: ${doc('form_pub_date', '04.03.2024')}`);
  ws.getCell('I2').font = { bold: true, size: 9 }; ws.getCell('I3').font = { size: 9 }; ws.getCell('I4').font = { size: 9 };
  ws.getCell('B2').font = { bold: true, size: 18 }; ws.getCell('B2').alignment = { horizontal: 'center', vertical: 'middle' };
  put('A7', 'Şikayet Alınma Tarihi:', true); merge('C7:D7', dmy(row.reported_date));
  put('E7', 'Şikayet No (1):', true); merge('G7:L7', row.complaint_no ?? '');
  put('A8', 'Şikayeti veya İsteği Kaydeden:', true); merge('C8:D8', userModel.findById(row.created_by)?.display_name ?? '');
  put('E8', 'Ürün Kodu/ Sipariş No:', true); merge('G8:L8', [row.product_code, row.order_qty, row.order_no].filter(Boolean).join(' / '));
  merge('A9:L9', 'MÜŞTERİ BİLGİLERİ :', true);
  const info: [string, string][] = [['Adı:', row.customer_name ?? ''], ['Adresi:', ''], ['Telefon:', ''], ['Fax:', ''], ['e-mail:', row.customer_email ?? ''], ['İlgili kişi:', row.customer_contact ?? '']];
  info.forEach(([k, v], i) => { put(`A${10 + i}`, k, true); merge(`B${10 + i}:L${10 + i}`, v); });
  const pol = JSON.parse(row.polished_json || 'null') as { title?: string; summary?: string } | null;
  const said = [pol?.title, pol?.summary].filter(Boolean).join(' - ');
  const raw = (row.raw_text ?? '').trim();
  const dup = !!raw && said.toLowerCase().includes(raw.toLowerCase().replace(/[.\s]+$/, ''));
  merge('A17:L21', `Şikayet Konusu: ${[said, dup ? '' : raw, row.order_no ? `Sipariş no: ${row.order_no}` : '', row.product_code ? `Ürün kodu: ${row.product_code}` : '', row.order_qty || row.complained_qty ? `Sipariş miktarı / şikayet edilen miktar: ${[row.order_qty, row.complained_qty].filter(Boolean).join(' / ')}` : '', row.customer_request ? `Müşteri talebi: ${row.customer_request}` : '', row.amount_wasted !== null || row.credit_note ? `Yansıyan maliyet: ${[row.amount_wasted !== null ? `${row.amount_wasted} ${row.currency}` : '', row.credit_note ? `credit note ${row.credit_note}` : ''].filter(Boolean).join(', ')}` : ''].filter(Boolean).join('\n')}`);
  put('A23', 'Hatanın Oluştuğu Operasyon:', true); merge('B23:D23', row.op_occurred ?? '');
  put('F23', 'Hatanın Belirlendiği Operasyon:', true); merge('G23:L23', row.op_detected ?? '');
  put('A25', 'Değerlendirmeyi Yapan Ekip:', true); merge('B25:L25', row.eval_team ?? '');
  merge('A27:L31', `Kök Neden: ${row.root_cause ?? ''}`);
  merge('A32:L36', `Sonuç: ${row.result_text ?? ''}\nAksiyon: ${row.result_action ?? ''}${row.close_target ? `\nPlanlanan kapanış tarihi: ${dmy(row.close_target)}` : ''}${row.closed_at ? `\nŞikayet kapanış tarihi: ${dmy(row.closed_at.slice(0, 10))}` : ''}`);
  put('A37', 'Düzeltici Faaliyet Gerekli mi?', true); put('B37', row.capa_required === 1 ? 'Evet  ☒' : 'Evet  ☐'); put('C37', row.capa_required === 0 ? 'Hayır  ☒' : 'Hayır  ☐'); put('F37', 'Tarih:', true); merge('G37:L37', dmy(row.capa_date));
  put('A39', 'Satış temsilcisine /Müşteriye Dönüş yapıldı mı?', true); put('B39', row.customer_replied === 1 ? 'Evet  ☒' : 'Evet  ☐'); put('C39', row.customer_replied === 0 ? 'Hayır  ☒' : 'Hayır  ☐'); put('F39', 'Tarih:', true); merge('G39:L39', dmy(row.customer_reply_date));
  merge('A41:L41', 'ONAY', true);
  merge('A42:D42', 'Şikayeti Kaydeden', true); merge('E42:H42', 'İlgili Birim/Kişi', true); merge('I42:L42', 'KYS Sorumlusu', true);
  merge('A43:D46', ''); merge('E43:H46', ''); merge('I43:L46', '');
  merge('A50:L50', '1)Bu numara Kalite Yönetim Sistem sorumlusu tarafından verilecektir.');
  for (const r of ['A7:L8', 'A9:L16', 'A17:L21', 'A23:L25', 'A27:L36', 'A37:L40', 'A41:L46']) frame(r);
  ws.pageSetup = { orientation: 'portrait', fitToPage: true, fitToWidth: 1, fitToHeight: 1 };
  return Buffer.from(await wb.xlsx.writeBuffer());
}
