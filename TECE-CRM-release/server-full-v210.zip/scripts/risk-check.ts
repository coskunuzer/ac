// A check of the payment-risk levels on the real ledger (not part of the app): npx tsx scripts/risk-check.ts
import { runMigrations } from '../src/db/migrate';
import { allAccountSets } from '../src/services/perfAnalytics';

async function main() {
  await Promise.resolve((runMigrations as unknown as () => unknown)());
  const { live } = allAccountSets(0);
  const by: Record<string, number> = {};
  for (const a of live) by[a.risk.level] = (by[a.risk.level] ?? 0) + 1;
  console.log('live accounts', live.length, by);
  const show = (level: string, n = 12) => {
    console.log(`\n--- ${level}`);
    for (const a of live.filter((x) => x.risk.level === level).sort((x, y) => y.risk.score - x.risk.score).slice(0, n)) {
      console.log(`${a.name.slice(0, 34).padEnd(34)} ${a.currency} bal ${String(Math.round(a.balance)).padStart(8)} over ${String(Math.round(a.overdue)).padStart(8)} oldest ${String(a.oldestOver).padStart(4)}d | score ${String(a.risk.score).padStart(3)} auto ${a.risk.auto} avgLate ${String(a.risk.avgLate).padStart(3)} onTime ${a.risk.onTimePct ?? '-'}% (${a.risk.lateN}/${a.risk.paidN}) trend ${a.risk.trend} hold ${a.hold}`);
    }
  };
  show('black', 20); show('risk', 10); show('watch', 8); show('good', 6);
  const dispatchReady = live.filter((a) => a.readyValue > 0);
  console.log('\nready-to-ship accounts', dispatchReady.length, 'black among them', dispatchReady.filter((a) => a.black).map((a) => a.name));
}
void main();
