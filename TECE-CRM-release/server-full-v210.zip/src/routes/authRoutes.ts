import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { userModel } from '../models/userModel';
import { settingsModel } from '../models/settingsModel';
import { signToken, setSessionCookie, clearSessionCookie, requireAuth, type AuthedRequest } from '../middleware/auth';

const router = Router();

router.post('/login', (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required' });
  }

  const user = userModel.findByUsername(username);
  if (!user || !user.is_active || user.is_assistant || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: 'Invalid username or password' });
  }

  const token = signToken(user.id);
  setSessionCookie(res, token);
  res.json(userModel.findPublicById(user.id));
});

// What the login page needs before anybody has signed in: the language the screens start in.
router.get('/public', (_req, res) => {
  res.json({ defaultLanguage: settingsModel.get('ui_default_language') === 'tr' ? 'tr' : 'en' });
});

router.post('/logout', (_req, res) => {
  clearSessionCookie(res);
  res.json({ ok: true });
});

router.get('/me', requireAuth, (req: AuthedRequest, res) => {
  // an assistant sees the work of the person they assist; the screen says who really signed in
  res.json(req.actor ? { ...req.user, theme: req.actor.theme, actor: { id: req.actor.id, display_name: req.actor.display_name, username: req.actor.username } } : req.user);
});

export default router;
