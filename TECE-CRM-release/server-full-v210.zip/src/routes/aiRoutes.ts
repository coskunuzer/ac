import { Router } from 'express';
import { type AuthedRequest } from '../middleware/auth';
import { useAi } from '../services/aiBudget';
import { aiFailureMessage } from '../services/aiGate';
import { toTurkish } from '../services/transcribe';
import { ratingPrompt, setRatingPrompt } from '../services/companyCheck';
import { requireAdmin, requireAuth } from '../middleware/auth';
import { settingsModel } from '../models/settingsModel';
import { aiPublicStatus, aiReport, setAiSettings } from '../services/aiGate';

const router = Router();
router.use(requireAuth);

// Does the AI work right now? Everybody gets this (the warning bar at the top of every page).
router.get('/status', (_req, res) => {
  res.json(aiPublicStatus());
});

// Admin: how many tokens were used (today, this week, this month), by what and by whom, and what the limits are.
router.get('/usage', requireAdmin, (_req, res) => {
  res.json(aiReport());
});

// Admin: switch the AI on or off, set the limits (tokens a day / a month; 0 = no limit) and the prices used to estimate the cost (per million tokens).
router.put('/settings', requireAdmin, (req, res) => {
  const b = req.body ?? {};
  const n = (v: unknown) => (v === undefined || v === null || v === '' ? undefined : Number(v));
  const patch = {
    enabled: typeof b.enabled === 'boolean' ? b.enabled : undefined,
    dayLimit: n(b.dayLimit),
    monthLimit: n(b.monthLimit),
    priceIn: n(b.priceIn),
    priceOut: n(b.priceOut),
    deepseekModel: typeof b.deepseekModel === 'string' ? b.deepseekModel : undefined,
    deepseekKey: typeof b.deepseekKey === 'string' ? b.deepseekKey : undefined,
  } as Parameters<typeof setAiSettings>[0];
  if ([patch.dayLimit, patch.monthLimit, patch.priceIn, patch.priceOut].some((v) => v !== undefined && !Number.isFinite(v))) {
    return res.status(400).json({ error: 'The limits and prices must be numbers.' });
  }
  setAiSettings(patch);
  res.json(aiReport());
});

// The Turkish version of a voice note (the words were written down in the browser). Counts as one AI question.
router.post('/to-turkish', async (req: AuthedRequest, res) => {
  const text = String(req.body?.text ?? '').trim();
  if (!text) return res.status(400).json({ error: 'No text.' });
  if (!useAi(req.user!, res)) return;
  const turkish = await toTurkish(text, String(req.body?.language ?? ''));
  if (!turkish) return res.status(503).json({ ai: true, error: aiFailureMessage('The AI could not translate the note just now.') });
  res.json({ turkish });
});

// the prompt of the AI rating (the text the AI follows when it scores a company)
router.get('/rating-prompt', (_req, res) => {
  res.json({ prompt: ratingPrompt(), isDefault: !settingsModel.get('ai_rating_prompt')?.trim() });
});
router.put('/rating-prompt', (req, res) => {
  const text = String(req.body?.prompt ?? '');
  if (text.trim().length < 200) return res.status(400).json({ error: 'The prompt is too short.' });
  setRatingPrompt(text);
  res.json({ prompt: ratingPrompt(), isDefault: !settingsModel.get('ai_rating_prompt')?.trim() });
});

export default router;
