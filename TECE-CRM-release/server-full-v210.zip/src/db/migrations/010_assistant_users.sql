-- Assistants are kept in the users table (name + email) but cannot log in.
ALTER TABLE users ADD COLUMN is_assistant INTEGER NOT NULL DEFAULT 0;
