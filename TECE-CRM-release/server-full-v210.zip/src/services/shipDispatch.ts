import { db } from '../db/connection';

// VF04, the list of orders ready to dispatch, as Operations uses it: silencing back orders the customer does not want yet, and the asks that
// Sales sends to Operations to organise the transport.

// SQL: the rows of export_dispatch_queue that are NOT silenced (used by every list and figure of "ready to ship")
export const NOT_SILENCED = `NOT EXISTS (SELECT 1 FROM ship_snooze s WHERE s.cleared_at IS NULL AND (s.until IS NULL OR s.until >= date('now')) AND (s.sap_no = export_dispatch_queue.sap_no AND (s.scope = 'customer' OR s.sd_no = export_dispatch_queue.sd_no)))`;

export interface Snooze { id: number; scope: 'sd' | 'customer'; sdNo: string | null; sap: string; customer: string | null; until: string | null; reason: string | null; userName: string | null; createdAt: string }
interface Raw { id: number; scope: string; sd_no: string | null; sap_no: string; customer: string | null; until: string | null; reason: string | null; user_name: string | null; created_at: string }
const toSnooze = (r: Raw): Snooze => ({ id: r.id, scope: r.scope === 'sd' ? 'sd' : 'customer', sdNo: r.sd_no, sap: r.sap_no, customer: r.customer, until: r.until, reason: r.reason, userName: r.user_name, createdAt: r.created_at });

export const activeSnoozes = (): Snooze[] =>
  (db.prepare("SELECT s.*, u.display_name AS user_name FROM ship_snooze s LEFT JOIN users u ON u.id = s.user_id WHERE s.cleared_at IS NULL AND (s.until IS NULL OR s.until >= date('now')) ORDER BY s.id DESC").all() as unknown as Raw[]).map(toSnooze);

export function snooze(input: { sap: string; sdNo?: string | null; until?: string | null; reason?: string | null; userId: number }): number {
  const row = db.prepare('SELECT customer FROM export_dispatch_queue WHERE sap_no = ? LIMIT 1').get(input.sap) as { customer: string } | undefined;
  const until = input.until && /^\d{4}-\d{2}-\d{2}$/.test(input.until) ? input.until : null;
  // the same thing silenced again replaces the older one
  db.prepare("UPDATE ship_snooze SET cleared_at = datetime('now') WHERE cleared_at IS NULL AND sap_no = ? AND COALESCE(sd_no, '') = ?").run(input.sap, input.sdNo ?? '');
  return Number(db.prepare('INSERT INTO ship_snooze (scope, sd_no, sap_no, customer, until, reason, user_id) VALUES (?, ?, ?, ?, ?, ?, ?)')
    .run(input.sdNo ? 'sd' : 'customer', input.sdNo ?? null, input.sap, row?.customer ?? null, until, (input.reason ?? '').trim().slice(0, 200) || null, input.userId).lastInsertRowid);
}
export const clearSnooze = (id: number): void => { db.prepare("UPDATE ship_snooze SET cleared_at = datetime('now') WHERE id = ? AND cleared_at IS NULL").run(id); };

// ---- what is ready, for the Operations screen ----------------------------------------------------------------------------------------------------
export interface ReadyRow { sd: string; date: string | null; days: number | null; value: number; currency: string; weight: number; snooze: Snooze | null }
export interface ReadyCustomer {
  sap: string; customer: string; country: string | null; city: string | null; cardId: number | null; salesRep: string | null; opsRep: string | null;
  rows: ReadyRow[]; value: number; currency: string; weight: number; silenced: boolean;
  request: { id: string; status: string; accepted: string | null } | null; ask: { id: number; note: string | null; from: string | null; at: string } | null;
}
export function readyList(includeSilenced: boolean): { customers: ReadyCustomer[]; silencedCount: number; snoozes: Snooze[] } {
  const snoozes = activeSnoozes();
  const rows = db.prepare('SELECT sd_no, billing_date, sap_no, customer, country, city, net_value, currency, weight, sales_rep, ops_rep FROM export_dispatch_queue ORDER BY billing_date, sd_no').all() as unknown as { sd_no: string; billing_date: string | null; sap_no: string; customer: string; country: string | null; city: string | null; net_value: number | null; currency: string; weight: number | null; sales_rep: string | null; ops_rep: string | null }[];
  const cards = new Map((db.prepare("SELECT id, sap FROM cards WHERE sap IS NOT NULL AND sap != ''").all() as { id: number; sap: string }[]).map((c) => [c.sap.trim(), c.id]));
  const reqBy = new Map<string, { id: string; status: string; accepted: string | null }>();
  for (const r of db.prepare("SELECT r.id, r.status, r.card_id, (SELECT forwarder_name FROM ship_quotes q WHERE q.id = r.accepted_quote) AS acc FROM ship_requests r WHERE r.archived = 0 AND r.card_id IS NOT NULL ORDER BY r.created_at").all() as { id: string; status: string; card_id: number; acc: string | null }[]) reqBy.set(String(r.card_id), { id: r.id, status: r.status, accepted: r.acc });
  const asks = new Map<string, { id: number; note: string | null; from: string | null; at: string }>();
  for (const a of db.prepare("SELECT a.id, a.sap_no, a.note, a.created_at, u.display_name AS from_name FROM ship_asks a LEFT JOIN users u ON u.id = a.from_user WHERE a.status = 'open' ORDER BY a.id").all() as { id: number; sap_no: string; note: string | null; created_at: string; from_name: string | null }[]) asks.set(a.sap_no, { id: a.id, note: a.note, from: a.from_name, at: a.created_at });
  const today = new Date().toISOString().slice(0, 10);
  const by = new Map<string, ReadyCustomer>();
  let silencedCount = 0;
  for (const r of rows) {
    const sn = snoozes.find((s) => s.sap === r.sap_no && (s.scope === 'customer' || s.sdNo === r.sd_no)) ?? null;
    if (sn) silencedCount++;
    if (sn && !includeSilenced) continue;
    const c = by.get(r.sap_no) ?? { sap: r.sap_no, customer: r.customer, country: r.country, city: r.city, cardId: cards.get(r.sap_no.trim()) ?? null, salesRep: r.sales_rep, opsRep: r.ops_rep, rows: [], value: 0, currency: r.currency, weight: 0, silenced: false, request: null, ask: asks.get(r.sap_no) ?? null };
    c.rows.push({ sd: r.sd_no, date: r.billing_date, days: r.billing_date ? Math.round((Date.parse(`${today}T12:00:00Z`) - Date.parse(`${r.billing_date}T12:00:00Z`)) / 86400000) : null, value: r.net_value ?? 0, currency: r.currency, weight: r.weight ?? 0, snooze: sn });
    if (!sn) { c.value += r.net_value ?? 0; c.weight += r.weight ?? 0; }
    c.silenced = c.rows.every((x) => x.snooze);
    c.request = c.cardId ? reqBy.get(String(c.cardId)) ?? null : null;
    by.set(r.sap_no, c);
  }
  return { customers: [...by.values()].sort((a, b) => Number(a.silenced) - Number(b.silenced) || (b.rows[0]?.days ?? 0) - (a.rows[0]?.days ?? 0)), silencedCount, snoozes };
}

// ---- asks from Sales ----------------------------------------------------------------------------------------------------------------------------------
export function addAsk(input: { sap: string; sdNos: string[]; note: string | null; userId: number }): number {
  const row = db.prepare('SELECT customer FROM export_dispatch_queue WHERE sap_no = ? LIMIT 1').get(input.sap) as { customer: string } | undefined;
  const card = db.prepare("SELECT id FROM cards WHERE TRIM(sap) = ? LIMIT 1").get(input.sap.trim()) as { id: number } | undefined;
  // one open ask for a customer: a new one updates it
  const open = db.prepare("SELECT id FROM ship_asks WHERE sap_no = ? AND status = 'open'").get(input.sap) as { id: number } | undefined;
  if (open) { db.prepare('UPDATE ship_asks SET sd_nos = ?, note = ?, from_user = ?, created_at = datetime(\'now\') WHERE id = ?').run(JSON.stringify(input.sdNos), input.note, input.userId, open.id); return open.id; }
  return Number(db.prepare('INSERT INTO ship_asks (sap_no, customer, card_id, sd_nos, note, from_user) VALUES (?, ?, ?, ?, ?, ?)').run(input.sap, row?.customer ?? null, card?.id ?? null, JSON.stringify(input.sdNos), input.note, input.userId).lastInsertRowid);
}
export const openAsks = () => db.prepare("SELECT a.*, u.display_name AS from_name FROM ship_asks a LEFT JOIN users u ON u.id = a.from_user WHERE a.status = 'open' ORDER BY a.id DESC").all() as unknown as { id: number; sap_no: string; customer: string | null; card_id: number | null; sd_nos: string; note: string | null; from_name: string | null; created_at: string }[];
export const openAskCount = (): number => (db.prepare("SELECT COUNT(*) AS n FROM ship_asks WHERE status = 'open'").get() as { n: number }).n;
export function finishAsk(id: number, status: 'done' | 'dismissed', userId: number, requestId: string | null): void {
  db.prepare("UPDATE ship_asks SET status = ?, request_id = ?, handled_at = datetime('now'), handled_by = ? WHERE id = ?").run(status, requestId, userId, id);
}
