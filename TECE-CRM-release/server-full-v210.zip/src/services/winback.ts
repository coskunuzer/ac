import { db } from '../db/connection';
import { cardModel, type CardRow } from '../models/cardModel';
import { setsFor } from './perfAnalytics';
import { visibilitySql, type Viewer } from './visibility';
import { translateEmail, isLang, type Lang } from './translate';
import { languageOf } from './offerLanguage';

// Win-back: the small customers that went quiet, and the prospects that were lost. For each one a reason to write ("a play"), a score that says who is
// worth the first call, and a ready text in the customer's language. Customers who owe money are not written to: they go to "collect first".

export type Play = 'bulgaria' | 'samples' | 'colours' | 'collect' | 'price' | 'again';
export const PLAYS: Record<Play, { title: string; hint: string }> = {
  bulgaria: { title: 'Small quantities from the Bulgaria stock', hint: 'A roll or less of the Kronospan collection, from stock, to Europe. Good for small buyers.' },
  samples: { title: 'A sample kit of the new colours', hint: 'They have been quiet for long: give them something to touch.' },
  colours: { title: 'What is new: colours and the decor list', hint: 'A light reason to be in touch again.' },
  collect: { title: 'Collect first, then talk', hint: 'They owe money: send the statement. No new offers.' },
  price: { title: 'A fresh price for a small order', hint: 'They left because of the price: ask again with a small-order price.' },
  again: { title: 'Ask again, simply', hint: 'They never answered: one short, friendly message.' },
};
export interface WinRow {
  key: string; kind: 'account' | 'lead'; cardId: number | null; name: string; country: string; lastInvoice: string | null; monthsSilent: number | null;
  bestYear: number; currency: string; owes: boolean; score: number; play: Play; why: string; hasEmail: boolean; language: Lang; rep: string; lostReason: string | null;
}
const EUROPE = new Set(['albania', 'austria', 'belarus', 'belgium', 'bosnia and herzegovina', 'bulgaria', 'croatia', 'cyprus', 'czechia', 'czech republic', 'denmark', 'estonia', 'finland', 'france', 'germany', 'greece', 'hungary', 'iceland', 'ireland', 'italy', 'kosovo', 'latvia', 'lithuania', 'luxembourg', 'macedonia', 'north macedonia', 'malta', 'moldova', 'montenegro', 'netherlands', 'norway', 'poland', 'portugal', 'romania', 'serbia', 'slovakia', 'slovenia', 'spain', 'sweden', 'switzerland', 'ukraine', 'united kingdom', 'uk']);
const isEurope = (c: string) => EUROPE.has(c.trim().toLowerCase());
const today = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });
const monthsSince = (iso: string | null) => (iso ? Math.round((Date.parse(today()) - Date.parse(iso.slice(0, 10))) / (86_400_000 * 30.4)) : null);
const TOUCH = "('note', 'call', 'visit', 'meeting', 'sample', 'offer', 'thank_you', 'documents', 'email')";

export function winbackList(viewer: Viewer): WinRow[] {
  const rows: WinRow[] = [];
  const touched = new Map<number, string>();
  for (const r of db.prepare(`SELECT card_id, MAX(created_at) AS at FROM activities WHERE card_id IS NOT NULL AND type IN ${TOUCH} GROUP BY card_id`).all() as { card_id: number; at: string }[]) touched.set(r.card_id, r.at);
  const sets = setsFor(viewer, null);
  const seen = new Set<number>();
  for (const a of [...sets.live, ...sets.dead]) {
    const m = monthsSince(a.lastInvoice);
    if (m === null || m < 6 || a.bestYear <= 0 || a.bestYear > 60_000) continue;
    const card = a.cardId ? cardModel.findById(a.cardId) : undefined;
    if (a.cardId) seen.add(a.cardId);
    const owes = a.overdue > 0.5 || a.hold || a.risk.level === 'black';
    const recent = a.cardId ? monthsSince(touched.get(a.cardId) ?? null) : null;
    const years = Object.values(a.years).filter((v) => v > 0).length;
    const hasEmail = !!card?.email;
    let score = 40 * Math.min(1, Math.log10(a.bestYear + 1) / 4.7) + (m <= 18 ? 30 : m <= 30 ? 18 : m <= 48 ? 8 : 2) + Math.min(20, years * 4) + (hasEmail ? 5 : 0);
    if (recent !== null && recent < 2) score -= 12; // somebody was in touch lately
    const small = a.bestYear < 15_000;
    let play: Play; let why: string;
    if (owes) { play = 'collect'; why = `Owes ${Math.round(a.overdue).toLocaleString('en-US')} ${a.currency}${a.hold ? ' (debt hold)' : ''}`; score -= 25; }
    else if (small && m <= 30 && isEurope(a.country)) { play = 'bulgaria'; why = `Small buyer (best year ${Math.round(a.bestYear).toLocaleString('en-US')} ${a.currency}), in Europe, quiet for ${m} months`; }
    else if (m > 18) { play = 'samples'; why = `Quiet for ${m} months; bought in ${years} different year${years === 1 ? '' : 's'}`; }
    else { play = 'colours'; why = `Quiet for ${m} months; best year ${Math.round(a.bestYear).toLocaleString('en-US')} ${a.currency}`; }
    rows.push({ key: `a${a.sap}`, kind: 'account', cardId: a.cardId, name: a.name, country: a.country, lastInvoice: a.lastInvoice, monthsSilent: m, bestYear: Math.round(a.bestYear), currency: a.currency, owes, score: Math.max(1, Math.min(100, Math.round(score))), play, why, hasEmail, language: card ? (card.market === 'domestic' ? 'tr' : languageOf(card)) : 'en', rep: a.rep, lostReason: null });
  }
  // prospects that were lost
  const params: Record<string, string | number> = {};
  const vis = visibilitySql(viewer, params);
  const leads = db.prepare(`SELECT * FROM cards WHERE exit_status = 'lost' AND TRIM(COALESCE(sap, '')) = ''${vis ? ` AND ${vis}` : ''} ORDER BY updated_at DESC LIMIT 400`).all(params) as unknown as CardRow[];
  for (const c of leads) {
    if (seen.has(c.id)) continue;
    const m = monthsSince(touched.get(c.id) ?? c.updated_at);
    const reason = c.exit_reason ?? '';
    const rating = c.rate ?? (c.ai_rate_source === 'ai' ? c.ai_rate : null) ?? 3;
    const play: Play = reason === 'Price' ? 'price' : reason === 'Color Match / Quality' ? 'samples' : reason === 'Lead Time' && isEurope(c.country ?? '') ? 'bulgaria' : reason === 'Competitor' ? 'colours' : 'again';
    let score = rating * 6 + (m !== null && m >= 3 && m <= 18 ? 25 : 8) + (c.email ? 5 : 0);
    if (m !== null && m < 2) score -= 15;
    rows.push({ key: `l${c.id}`, kind: 'lead', cardId: c.id, name: c.company || c.name || `#${c.id}`, country: (c.market === 'domestic' ? c.city : c.country) ?? '', lastInvoice: null, monthsSilent: m, bestYear: 0, currency: 'EUR', owes: false, score: Math.max(1, Math.min(100, Math.round(score))), play,
      why: `Lost${reason ? `: ${reason}` : ''}${m !== null ? `, last contact ${m} months ago` : ''}${rating >= 6 ? `, rated ${rating}/10` : ''}`, hasEmail: !!c.email, language: c.market === 'domestic' ? 'tr' : languageOf(c), rep: c.person ?? '', lostReason: reason || null });
  }
  return rows.sort((x, y) => y.score - x.score).slice(0, 400);
}

// ---- the text ----
const EN: Record<Play, { subject: string; body: (n: string) => string }> = {
  bulgaria: { subject: 'Small quantities of edgebanding, from stock', body: (n) => `Dear ${n},\n\nIt has been a while since we worked together, and we would be glad to do so again.\n\nFor smaller needs we now serve Europe from our stock in Bulgaria: the Kronospan collection, from one roll, with fast delivery. No big order is needed.\n\nIf you tell me the colours and the widths you use, I will send you the prices today.\n\nBest regards`,},
  samples: { subject: 'New colours from TECE: can we send you samples?', body: (n) => `Dear ${n},\n\nWe have added new colours to our range and updated our decor list since we last worked together.\n\nMay I send you a small sample kit, free of charge? It is the easiest way to see the colours and the surface.\n\nPlease confirm the delivery address and I will send it this week.\n\nBest regards` },
  colours: { subject: 'What is new at TECE: new colours and the decor list', body: (n) => `Dear ${n},\n\nA short note to keep you up to date: we have new colours in the range, and our decor list is updated.\n\nIf you tell me which colours or widths you need now, I will prepare an offer for you.\n\nBest regards` },
  collect: { subject: 'Your account with TECE', body: (n) => `Dear ${n},\n\nI am writing about your account with us. Please find the statement attached; there is an open balance that we ask you to settle.\n\nIf anything is unclear, tell me and we will look at it together.\n\nBest regards` },
  price: { subject: 'A new price for your small orders', body: (n) => `Dear ${n},\n\nWhen we spoke, the price was a problem for you. We have since reviewed our prices for smaller orders, and I would like to give you a new offer.\n\nPlease tell me the colours, widths and quantities you have in mind.\n\nBest regards` },
  again: { subject: 'Are you still looking for edgebanding?', body: (n) => `Dear ${n},\n\nWe spoke some time ago about edgebanding. I wanted to ask whether your needs have changed and whether we can help now.\n\nIf you tell me what you need, I will send you an offer within a day.\n\nBest regards` },
};
const TRK: Record<Play, { subject: string; body: (n: string) => string }> = {
  bulgaria: { subject: 'Kenar bandında küçük miktarlar, stoktan', body: (n) => `Sayın ${n},\n\nBirlikte çalışmayalı uzun zaman oldu; tekrar çalışmaktan memnuniyet duyarız.\n\nKüçük ihtiyaçlarınız için Avrupa'ya Bulgaristan stoğumuzdan hizmet veriyoruz: Kronospan koleksiyonu, bir rulodan başlayarak, hızlı teslimatla.\n\nKullandığınız renkleri ve genişlikleri yazarsanız fiyatları bugün göndereyim.\n\nSaygılarımla` },
  samples: { subject: 'TECE\'den yeni renkler: numune gönderelim mi?', body: (n) => `Sayın ${n},\n\nSon çalışmamızdan bu yana koleksiyonumuza yeni renkler ekledik ve dekor listemizi güncelledik.\n\nÜcretsiz küçük bir numune seti göndermemi ister misiniz? Renkleri ve yüzeyi görmenin en kolay yolu.\n\nTeslimat adresinizi onaylarsanız bu hafta göndereyim.\n\nSaygılarımla` },
  colours: { subject: 'TECE\'de yenilikler: yeni renkler ve dekor listesi', body: (n) => `Sayın ${n},\n\nSizi bilgilendirmek için kısa bir not: koleksiyonumuzda yeni renkler var ve dekor listemiz güncellendi.\n\nŞu an hangi renk veya genişliklere ihtiyacınız olduğunu yazarsanız size teklif hazırlayayım.\n\nSaygılarımla` },
  collect: { subject: 'TECE hesabınız', body: (n) => `Sayın ${n},\n\nHesabınızla ilgili yazıyorum. Ekte ekstreyi bulabilirsiniz; ödenmesini rica ettiğimiz açık bir bakiye var.\n\nAnlaşılmayan bir şey varsa yazın, birlikte bakalım.\n\nSaygılarımla` },
  price: { subject: 'Küçük siparişleriniz için yeni fiyat', body: (n) => `Sayın ${n},\n\nGörüştüğümüzde fiyat sizin için sorundu. O zamandan beri küçük siparişler için fiyatlarımızı gözden geçirdik ve size yeni bir teklif vermek isterim.\n\nAklınızdaki renk, genişlik ve miktarları yazar mısınız?\n\nSaygılarımla` },
  again: { subject: 'Hâlâ kenar bandı arıyor musunuz?', body: (n) => `Sayın ${n},\n\nBir süre önce kenar bandı konusunda görüşmüştük. İhtiyacınızın değişip değişmediğini ve şimdi yardımcı olup olamayacağımızı sormak istedim.\n\nNe gerektiğini yazarsanız bir gün içinde teklif göndereyim.\n\nSaygılarımla` },
};

export async function winbackDraft(card: CardRow, play: Play, sender: string): Promise<{ subject: string; body: string; language: Lang; translated: boolean }> {
  const lang: Lang = card.market === 'domestic' ? 'tr' : languageOf(card);
  const n = card.name?.split(/\s+/)[0] || card.company || '';
  const sign = (b: string) => `${b}\n${sender}`;
  if (lang === 'tr') { const t = TRK[play]; return { subject: t.subject, body: sign(t.body(n)), language: 'tr', translated: true }; }
  const e = EN[play];
  const base = { subject: e.subject, body: sign(e.body(n)) };
  if (lang !== 'en' && isLang(lang)) {
    const tr = await translateEmail(base.subject, base.body, lang);
    if (tr) return { ...tr, language: lang, translated: true };
  }
  return { ...base, language: 'en', translated: lang === 'en' };
}
