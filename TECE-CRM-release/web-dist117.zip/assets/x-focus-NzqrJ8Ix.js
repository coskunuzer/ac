// "Your focus" (owner, 21 Nov: "CRM should tell us hey man, you need to focus there - the sprint is just a way for us to manage this").
// The server (GET /api/focus/me, /api/focus/person/:id - services/focusAreas.ts) decides the 1-3 places where effort pays most today, with
// the reason in numbers and the expected value; this module only shows them:
//   HomeFocus    on Today, right under the page title (above the challenge board): the decision comes before the game
//   FocusCards   the same cards for a manager on a person's scorecard (no "Not now": that is the person's own choice)
//   FocusRun     /focus/run?key=<focus>[&person=<id>]: a light "run" through a list of customers, one after the other, with Next
// The card is the decision, the start button opens the tool (a country sprint, the fair focus, a customer, a run, Price performance).
import { h, Fragment, useState, useEffect, useRef, api, Link, useT, useSearchParams, useNavigate, Icon, cx, errText, toast, burst, Skel, Bar, loc, locVars, trPct } from "./x-kit-1W3jRMzJ.js";

const KIND = {
  country: { icon: "public", label: "Country" },
  customer: { icon: "person", label: "Customer" },
  fair: { icon: "festival", label: "Fair" },
  followups: { icon: "alarm", label: "Follow-ups" },
  offers: { icon: "request-quote", label: "Offers" },
  meetings: { icon: "event", label: "Meetings" },
  price: { icon: "price-check", label: "Prices" },
  explore: { icon: "rocket-launch", label: "Explore" },
};
const say = (t, p) => (p && p.t ? trPct(t(p.t, locVars(p.v))) : "");
const evText = (t, v) => {
  if (v == null) return null;
  const a = Math.abs(v);
  const s = a >= 1e6 ? (a / 1e6).toLocaleString(loc(), { maximumFractionDigits: 1 }) + "M" : a >= 10000 ? Math.round(a / 1000) + "k" : Math.round(a).toLocaleString(loc());
  return t("≈ €{v} a year", { v: s });
};

// one card: kind, title, why in numbers, the expected value, the big start button, "Not now"
function Card({ f, rank, onSnooze, person, compact }) {
  const t = useT();
  const [how, setHow] = useState(false);
  const k = KIND[f.kind] || KIND.explore;
  const to = person && f.start.to.startsWith("/focus/run") ? f.start.to + "&person=" + person : f.start.to;
  const ev = evText(t, f.ev);
  const title = f.titleT ? say(t, f.titleT) : f.kind === "country" || f.kind === "customer" || f.kind === "fair" ? f.title : t(f.title);
  return h(
    "article",
    { className: cx("xf-card", "xf-card--" + f.kind, rank === 0 && "xf-card--lead", compact && "xf-card--compact") },
    h("div", { className: "xf-card-top" },
      h("span", { className: "xf-ic", "aria-hidden": true }, h(Icon, { n: k.icon, size: 22 })),
      h("span", { className: "xf-kind" }, t(k.label), rank != null ? h("small", null, " · #" + (rank + 1)) : null),
      ev ? h("span", { className: "xf-ev", title: t("Expected value") + ": " + say(t, f.formula) }, ev) : null,
    ),
    h("h3", { className: "xf-title" }, title),
    h("p", { className: "xf-why" }, f.why.map((p, i) => h(Fragment, { key: i }, i ? h("span", { className: "xf-dot", "aria-hidden": true }, " · ") : null, h("span", null, say(t, p))))),
    how && f.formula && f.formula.t ? h("p", { className: "xf-how" }, h(Icon, { n: "info", size: 14 }), " ", say(t, f.formula), ". ", t("Order: expected value × urgency ÷ the time it takes.")) : null,
    h("div", { className: "xf-actions" },
      h(Link, { className: "xf-start", to }, h(Icon, { n: "play-arrow", size: 20 }), t(f.start.label), f.runCount ? h("small", null, " · " + t("the first {n}", { n: f.runCount })) : null),
      h("div", { className: "xf-sub" },
        onSnooze ? h("button", { type: "button", className: "xf-link", onClick: () => onSnooze(f) }, h(Icon, { n: "snooze", size: 16 }), t("Not now")) : null,
        f.formula && f.formula.t ? h("button", { type: "button", className: "xf-link", "aria-expanded": how, onClick: () => setHow(!how) }, h(Icon, { n: "info", size: 16 }), t("Why this?")) : null,
        f.alt ? h(Link, { className: "xf-link", to: f.alt.to }, t(f.alt.label)) : null,
      ),
    ),
  );
}

function EmptyCard({ e }) {
  const t = useT();
  return h("article", { className: "xf-card xf-card--explore xf-card--empty" },
    h("div", { className: "xf-card-top" }, h("span", { className: "xf-ic", "aria-hidden": true }, h(Icon, { n: "rocket-launch", size: 22 })), h("span", { className: "xf-kind" }, t("Explore"))),
    h("h3", { className: "xf-title" }, t("Nothing urgent — explore a new country")),
    h("p", { className: "xf-why" }, t("No customer, fair or follow-up needs you more than new business today. Twenty minutes in a country you have not touched for a while.")),
    h("div", { className: "xf-actions" }, h(Link, { className: "xf-start", to: e.start.to }, h(Icon, { n: "play-arrow", size: 20 }), t("Start a sprint"))),
  );
}

// ================================================================== Today
export function HomeFocus() {
  const t = useT();
  const [d, setD] = useState(null);
  const [n, setN] = useState(0);
  useEffect(() => {
    let alive = true;
    api.get("/focus/me").then((x) => alive && setD(x)).catch(() => alive && setD({ applies: false }));
    return () => { alive = false; };
  }, [n]);
  if (d === null) return h("section", { className: "xf", "aria-busy": true }, h("div", { className: "xf-head" }, h("h2", { className: "tx-h2" }, t("Your focus"))), h("div", { className: "xf-grid" }, [0, 1, 2].map((i) => h(Skel, { key: i, height: 210 }))));
  if (!d.applies) return null;
  const snooze = (f) => {
    api.post("/focus/snooze", { key: f.key, days: 1 })
      .then(() => { setN((x) => x + 1); toast(t("“{f}” comes back tomorrow", { f: f.titleT ? say(t, f.titleT) : f.kind === "country" || f.kind === "customer" || f.kind === "fair" ? f.title : t(f.title) }), "good", { label: t("Undo"), run: () => api.post("/focus/unsnooze", { key: f.key }).then(() => setN((x) => x + 1)) }); })
      .catch((e) => toast(errText(e, t("Could not save it")), "bad"));
  };
  const list = d.focus || [];
  return h(
    "section",
    { className: "xf", "aria-labelledby": "xf-title" },
    h("div", { className: "xf-head" },
      h("div", null,
        h("h2", { className: "tx-h2", id: "xf-title" }, t("Your focus")),
        h("p", null, list.length ? t("Where your effort pays most today, worked out from your customers, countries and fairs.") : t("Nothing stands out today.")),
      ),
      d.snoozed ? h("button", { type: "button", className: "xf-link", onClick: () => Promise.all((d.snoozedKeys || []).map((k) => api.post("/focus/unsnooze", { key: k }))).then(() => setN((x) => x + 1)) }, t("{n} put off until tomorrow", { n: d.snoozed })) : null,
    ),
    list.length
      ? h("div", { className: "xf-grid", "data-n": list.length }, list.map((f, i) => h(Card, { key: f.key, f, rank: i, onSnooze: snooze })))
      : d.empty ? h("div", { className: "xf-grid", "data-n": 1 }, h(EmptyCard, { e: d.empty })) : null,
  );
}

// ================================================================== a person's focus (manager, scorecard)
export function FocusCards({ personId, name }) {
  const t = useT();
  const [d, setD] = useState(null);
  const [err, setErr] = useState(null);
  useEffect(() => {
    let alive = true; setD(null);
    api.get("/focus/person/" + personId).then((x) => alive && setD(x)).catch((e) => alive && setErr(errText(e, t("Could not open it"))));
    return () => { alive = false; };
  }, [personId]);
  if (err) return null;
  if (!d) return h("section", { className: "tm-card xf-in" }, h(Skel, { height: 160 }));
  if (!d.applies) return null;
  const list = d.focus || [];
  return h(
    "section",
    { className: "tm-card xf-in" },
    h("div", { className: "tm-card-head" }, h("h3", null, h(Icon, { n: "ads-click", size: 18 }), " ", t("{name}’s focus right now", { name: (name || d.person.name).split(" ")[0] })), h("small", null, t("What the CRM shows {name} on Today: the places where effort pays most.", { name: (name || d.person.name).split(" ")[0] }))),
    list.length ? h("div", { className: "xf-grid", "data-n": list.length }, list.map((f, i) => h(Card, { key: f.key, f, rank: i, person: d.person.self ? null : d.person.id, compact: true }))) : h("p", { className: "tm-muted" }, t("Nothing stands out today.")),
  );
}

// ================================================================== the run: a list of customers, one after the other
const runKey = (key, person) => "xf-run:" + key + ":" + (person || "me") + ":" + new Date().toISOString().slice(0, 10);
const readRun = (k) => { try { return JSON.parse(sessionStorage.getItem(k) || "null") || { i: 0, done: [] }; } catch { return { i: 0, done: [] }; } };
const saveRun = (k, v) => { try { sessionStorage.setItem(k, JSON.stringify(v)); } catch { /* the run still works, it is only not remembered */ } };

export function FocusRun() {
  const t = useT();
  const [sp] = useSearchParams();
  const nav = useNavigate();
  const key = sp.get("key") || "";
  const person = sp.get("person");
  const [d, setD] = useState(null);
  const [err, setErr] = useState(null);
  const sk = runKey(key, person);
  const [st, setSt] = useState(() => readRun(sk));
  const doneRef = useRef(null);
  useEffect(() => {
    let alive = true;
    api.get(person ? "/focus/person/" + person + "?all=1" : "/focus/me?all=1")
      .then((x) => { if (!alive) return; const f = [...(x.focus || []), ...(x.more || [])].find((y) => y.key === key); if (f) setD(f); else setErr(t("This list is not there any more - it may be done already.")); })
      .catch((e) => alive && setErr(errText(e, t("Could not open it"))));
    return () => { alive = false; };
  }, [key, person]);
  useEffect(() => { saveRun(sk, st); }, [st]);
  if (err) return h("div", { className: "xf-run" }, h("div", { className: "xk-empty" }, h(Icon, { n: "task-alt", size: 32 }), h("b", null, t("Run")), h("p", null, err), h(Link, { className: "tc-btn tc-btn--md", to: "/today" }, t("Back to Today"))));
  if (!d) return h("div", { className: "xf-run" }, h(Skel, { height: 80 }), h(Skel, { height: 260 }));
  const items = d.run || [];
  const k = KIND[d.kind] || KIND.explore;
  const title = d.kind === "country" || d.kind === "customer" || d.kind === "fair" ? d.title : t(d.title);
  const i = Math.min(st.i, items.length);
  const cur = items[i];
  const finished = i >= items.length;
  const go = (j, markDone) => {
    setSt((s) => ({ i: Math.max(0, j), done: markDone && cur && !s.done.includes(cur.id) ? [...s.done, cur.id] : s.done }));
    if (j >= items.length) setTimeout(() => { const r = doneRef.current && doneRef.current.getBoundingClientRect(); if (r) burst(r.left + r.width / 2, r.top + 30); }, 60);
  };
  return h(
    "div",
    { className: "xf-run" },
    h("div", { className: "xf-run-head" },
      h("button", { type: "button", className: "tc-btn tc-btn--ghost tc-btn--sm", onClick: () => nav(-1) }, h(Icon, { n: "arrow-back", size: 16 }), t("Back")),
      h("div", { className: "xf-run-title" },
        h("span", { className: "xf-ic", "aria-hidden": true }, h(Icon, { n: k.icon, size: 22 })),
        h("div", null, h("h1", null, title), h("p", null, d.why.map((p) => say(t, p)).join(" · "))),
      ),
      h("div", { className: "xf-run-prog" }, h("b", null, Math.min(i + (finished ? 0 : 1), items.length), " / ", items.length), h(Bar, { value: st.done.length, max: items.length || 1, tone: "good", label: t("Done") })),
    ),
    finished
      ? h("section", { className: "xf-run-card xf-run-card--done", ref: doneRef },
        h(Icon, { n: "done-all", size: 40 }),
        h("h2", null, t("Run finished")),
        h("p", null, t("{a} of {b} done. Well done - the next focus is waiting on Today.", { a: st.done.length, b: items.length })),
        h("div", { className: "xf-run-btns" },
          h(Link, { className: "xf-start", to: "/today" }, h(Icon, { n: "arrow-forward", size: 20 }), t("Back to Today")),
          h("button", { type: "button", className: "xf-link", onClick: () => setSt({ i: 0, done: [] }) }, h(Icon, { n: "undo", size: 16 }), t("Start again")),
          d.alt ? h(Link, { className: "xf-link", to: d.alt.to }, t(d.alt.label)) : null,
        ))
      : h("section", { className: "xf-run-card", "aria-live": "polite" },
        h("small", { className: "xf-kind" }, t("Step {i} of {n}", { i: i + 1, n: items.length })),
        h("h2", null, cur.name || t("A company")),
        cur.note ? h("p", { className: "xf-why" }, say(t, cur.note)) : null,
        h("div", { className: "xf-run-btns" },
          h(Link, { className: "xf-start", to: "/cards/" + cur.id + "/review?tab=" + (/^(price|slowing|customer)/.test(String(key)) ? "buys" : "details") }, h(Icon, { n: "north-east", size: 20 }), t("Open the customer")),
          h("button", { type: "button", className: "tc-btn tc-btn--secondary tc-btn--md xf-next", onClick: () => go(i + 1, true) }, h(Icon, { n: "check", size: 18 }), t("Done - next")),
          h("button", { type: "button", className: "xf-link", onClick: () => go(i + 1, false) }, h(Icon, { n: "chevron-right", size: 16 }), t("Skip")),
          i > 0 ? h("button", { type: "button", className: "xf-link", onClick: () => go(i - 1, false) }, h(Icon, { n: "arrow-back", size: 16 }), t("Previous")) : null,
        ),
        h("p", { className: "xf-hint" }, t("Open the customer, do what is needed (a call, a mail, a note), come back here and press Next. The run remembers where you are.")),
      ),
    items.length > 1 && h("ol", { className: "xf-run-list" }, items.map((it, j) => h("li", { key: it.id + ":" + j, className: cx(j === i && "is-cur", st.done.includes(it.id) && "is-done") },
      h("button", { type: "button", onClick: () => setSt((s) => ({ ...s, i: j })) }, h(Icon, { n: st.done.includes(it.id) ? "check-circle" : "chevron-right", size: 16 }), h("span", null, it.name || t("A company")), it.note ? h("small", null, say(t, it.note)) : null)))),
  );
}
