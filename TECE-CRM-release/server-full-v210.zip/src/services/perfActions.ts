import PDFDocument from 'pdfkit';
import { db } from '../db/connection';
import { env } from '../config/env';
import { blockedReason } from './aiGate';
import { drawLogo, registerDesignFonts } from './priceBook/designed';
import { COMPANY_ADDRESS_LINE } from './signature';
import { statementItems, termsDays, type Account, type DispatchSum } from './perfAnalytics';

// What the Performance page can do with an account: the statement of account (PDF + an e-mail in the language of the customer), the
// dispatch request to the operations team, and the two AI texts (why a big customer went silent, an offer to win them back).

export const OPERATIONS_EMAIL = 'operasyon@tece.com.tr';
export type Lang = 'en' | 'es' | 'de' | 'tr' | 'fr' | 'ru';
export const LANGS: Lang[] = ['en', 'es', 'de', 'tr', 'fr', 'ru'];
export const langOf = (v: string | null | undefined): Lang => (LANGS.includes((v ?? '').toLowerCase() as Lang) ? ((v ?? '').toLowerCase() as Lang) : 'en');

const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const SYMBOL: Record<string, string> = { EUR: '€', USD: '$' };
const money = (n: number, cur: string) => `${SYMBOL[cur] ?? `${cur} `}${n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const dmy = (iso: string | null) => (iso ? `${iso.slice(8, 10)}.${iso.slice(5, 7)}.${iso.slice(0, 4)}` : '');
const today = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });

// ---- the statement of account ----------------------------------------------------------------------------------------------------
interface Words { title: string; asOf: string; customer: string; account: string; date: string; description: string; amount: string; overdue: string; total: string; balance: string; none: string; terms: (d: number) => string; thanks: string; days: string; invoice: string; carried: string }
const W: Record<string, Words> = {
  en: { title: 'ACCOUNT STATEMENT', asOf: 'As of', customer: 'Customer', account: 'Account no.', date: 'Invoice date', description: 'Description', amount: 'Open amount', overdue: 'Days overdue', total: 'Total open', balance: 'Balance', none: 'There are no open items.', terms: (d) => `Payment terms: ${d} days from the invoice date.`, thanks: 'Please send the payment to the bank account on the invoice and mention the invoice number.', days: 'days', invoice: 'Invoice', carried: 'Balance brought forward' },
  es: { title: 'ESTADO DE CUENTA', asOf: 'A fecha de', customer: 'Cliente', account: 'N.º de cuenta', date: 'Fecha de factura', description: 'Descripción', amount: 'Importe pendiente', overdue: 'Días de retraso', total: 'Total pendiente', balance: 'Saldo', none: 'No hay partidas abiertas.', terms: (d) => `Condiciones de pago: ${d} días desde la fecha de factura.`, thanks: 'Por favor, realice el pago a la cuenta bancaria indicada en la factura e indique el número de factura.', days: 'días', invoice: 'Factura', carried: 'Saldo anterior' },
  de: { title: 'KONTOAUSZUG', asOf: 'Stand', customer: 'Kunde', account: 'Kontonr.', date: 'Rechnungsdatum', description: 'Beschreibung', amount: 'Offener Betrag', overdue: 'Tage überfällig', total: 'Offen gesamt', balance: 'Saldo', none: 'Es gibt keine offenen Posten.', terms: (d) => `Zahlungsbedingungen: ${d} Tage ab Rechnungsdatum.`, thanks: 'Bitte überweisen Sie auf das Bankkonto der Rechnung und nennen Sie die Rechnungsnummer.', days: 'Tage', invoice: 'Rechnung', carried: 'Übertrag aus früheren Rechnungen' },
  tr: { title: 'HESAP EKSTRESİ', asOf: 'Tarih', customer: 'Müşteri', account: 'Hesap no', date: 'Fatura tarihi', description: 'Açıklama', amount: 'Açık tutar', overdue: 'Gecikme (gün)', total: 'Toplam açık', balance: 'Bakiye', none: 'Açık kalem yok.', terms: (d) => `Ödeme vadesi: fatura tarihinden itibaren ${d} gün.`, thanks: 'Lütfen ödemeyi faturadaki banka hesabına, fatura numarasını belirterek yapınız.', days: 'gün', invoice: 'Fatura', carried: 'Önceki faturalardan devreden bakiye' },
  fr: { title: 'RELEVÉ DE COMPTE', asOf: 'Au', customer: 'Client', account: 'N° de compte', date: 'Date de facture', description: 'Description', amount: 'Montant dû', overdue: 'Jours de retard', total: 'Total dû', balance: 'Solde', none: 'Aucune facture ouverte.', terms: (d) => `Conditions de paiement : ${d} jours à compter de la date de facture.`, thanks: 'Merci de régler sur le compte bancaire indiqué sur la facture en précisant le numéro de facture.', days: 'jours', invoice: 'Facture', carried: 'Solde reporté' },
};
const words = (l: Lang): Words => W[l] ?? W.en;
// "çıkış TEZ2020000000082" in the ledger is an invoice: "Invoice TEZ2020000000082" (in the language of the customer)
export const describe = (d: string, l: Lang): string => {
  const f = d.replace(/İ/g, 'i').normalize('NFD').replace(/\p{Diacritic}/gu, '').replace(/ı/g, 'i').toLowerCase();
  const m = /^\s*(?:cik\S*|kdv\S*\s+cik\S*)\s*(.*)$/.exec(f);
  if (!m) return d.trim() || '—';
  const tail = d.trim().slice(d.trim().length - m[1].length);
  return `${words(l).invoice}${tail ? ` ${tail}` : ''}`;
};

export async function renderStatementPdf(a: { name: string; sap: string; country: string; lang: Lang }): Promise<Buffer> {
  const st = statementItems(a.sap);
  const w = words(a.lang);
  const doc = new PDFDocument({ size: 'A4', margin: 0, autoFirstPage: false, info: { Title: `${w.title} ${a.name}`, Author: 'TECE' } });
  const chunks: Buffer[] = [];
  doc.on('data', (b: Buffer) => chunks.push(b));
  const done = new Promise<Buffer>((resolve, reject) => { doc.on('end', () => resolve(Buffer.concat(chunks))); doc.on('error', reject); });
  registerDesignFonts(doc);
  const NAVY = '#17243E', RED = '#8B1931', SMOKE = '#E3E6EC', STEEL = '#5E6676';
  const F = { r: 'TD-400', m: 'TD-500', b: 'TD-600', h: 'TD-700' };
  const PW = 595.28, PH = 841.89, L = 40, CW = PW - 2 * L, BOTTOM = PH - 60;
  let y = 0;
  const page = () => {
    doc.addPage();
    doc.rect(0, 0, PW, 58).fill(NAVY);
    drawLogo(doc, 'TECE_SloganliLogo_Beyaz_RGB.svg', L, (58 - 190 * (522 / 5990)) / 2, 190);
    doc.rect(0, 58, PW, 3).fill(RED);
    doc.font(F.h).fontSize(13).fillColor('#FFFFFF').text(w.title, L, 22, { width: CW, align: 'right', lineBreak: false });
    doc.font(F.r).fontSize(7.5).fillColor(STEEL).text(COMPANY_ADDRESS_LINE, L, PH - 34, { width: CW, align: 'center', lineBreak: false });
    y = 80;
  };
  page();
  doc.font(F.h).fontSize(15).fillColor(NAVY).text(a.name, L, y, { width: CW });
  y = doc.y + 4;
  doc.font(F.r).fontSize(9).fillColor(STEEL).text(`${w.account}: ${a.sap}${a.country ? `   ·   ${a.country}` : ''}   ·   ${w.asOf} ${dmy(today())}`, L, y, { width: CW });
  y = doc.y + 18;

  const cols = [{ x: L, w: 78, k: w.date }, { x: L + 78, w: 230, k: w.description }, { x: L + 308, w: 100, k: w.amount, right: true }, { x: L + 408, w: CW - 408, k: w.overdue, right: true }];
  const head = () => {
    doc.font(F.b).fontSize(8).fillColor(STEEL);
    for (const c of cols) doc.text(c.k.toUpperCase(), c.x, y, { width: c.w - 6, align: c.right ? 'right' : 'left', lineBreak: false });
    doc.rect(L, y + 13, CW, 1).fill(NAVY);
    y += 20;
  };
  head();
  if (!st.items.length) {
    doc.font(F.r).fontSize(10).fillColor('#222222').text(w.none, L, y, { width: CW });
    y = doc.y + 10;
  }
  let total = 0;
  const terms = termsDays();
  for (const it of st.items) {
    if (y + 20 > BOTTOM) { page(); head(); }
    total += it.amount;
    const late = it.daysOver > 0;
    doc.font(F.r).fontSize(9).fillColor('#222222');
    doc.text(dmy(it.date), cols[0].x, y, { width: cols[0].w - 6, lineBreak: false });
    doc.text(it.carried ? words(a.lang).carried : describe(it.description, a.lang), cols[1].x, y, { width: cols[1].w - 8, height: 12, ellipsis: true, lineBreak: false });
    doc.font(F.m).text(money(it.amount, st.currency), cols[2].x, y, { width: cols[2].w - 6, align: 'right', lineBreak: false });
    doc.font(late ? F.b : F.r).fillColor(late ? RED : '#222222').text(late ? `${it.daysOver} ${w.days}` : '—', cols[3].x, y, { width: cols[3].w - 2, align: 'right', lineBreak: false });
    doc.rect(L, y + 14, CW, 0.5).fill(SMOKE);
    y += 20;
  }
  if (y + 60 > BOTTOM) page();
  y += 6;
  doc.rect(L, y, CW, 26).fill('#F3F4F7');
  doc.font(F.h).fontSize(10).fillColor(NAVY).text(w.total, L + 8, y + 8, { lineBreak: false });
  doc.text(money(total, st.currency), L + 308, y + 8, { width: 94, align: 'right', lineBreak: false });
  y += 40;
  doc.font(F.r).fontSize(8.5).fillColor(STEEL).text(w.terms(terms), L, y, { width: CW });
  y = doc.y + 4;
  doc.text(w.thanks, L, y, { width: CW });
  doc.end();
  return done;
}

// ---- the e-mail with the statement -----------------------------------------------------------------------------------------------
const MAIL: Record<Lang, { subject: (n: string, d: string) => string; body: (hello: string, total: string, late: string, d: string) => string }> = {
  en: { subject: (n, d) => `Account statement ${n} – ${d}`, body: (h, t, l, d) => `${h}\n\nPlease find below the open items on your account with TECE as of ${d}. The total open amount is ${t}${l}.\n\nThe statement is also attached as a PDF. If you have already made a payment, please send us the transfer receipt so we can match it. If anything does not agree with your records, tell us and we will check it together.\n\nThank you for your cooperation.` },
  es: { subject: (n, d) => `Estado de cuenta ${n} – ${d}`, body: (h, t, l, d) => `${h}\n\nA continuación encontrará las partidas abiertas de su cuenta con TECE a fecha de ${d}. El importe total pendiente es ${t}${l}.\n\nAdjuntamos también el estado de cuenta en PDF. Si ya ha realizado un pago, le agradeceremos que nos envíe el comprobante de la transferencia para poder aplicarlo. Si algo no coincide con sus registros, avísenos y lo revisaremos juntos.\n\nGracias por su colaboración.` },
  de: { subject: (n, d) => `Kontoauszug ${n} – ${d}`, body: (h, t, l, d) => `${h}\n\nanbei die offenen Posten Ihres Kontos bei TECE per ${d}. Der offene Gesamtbetrag beträgt ${t}${l}.\n\nDen Kontoauszug senden wir Ihnen außerdem als PDF. Falls Sie bereits gezahlt haben, schicken Sie uns bitte den Überweisungsbeleg, damit wir die Zahlung zuordnen können. Sollte etwas nicht mit Ihren Unterlagen übereinstimmen, geben Sie uns bitte Bescheid, dann prüfen wir es gemeinsam.\n\nVielen Dank für Ihre Mithilfe.` },
  tr: { subject: (n, d) => `Hesap ekstresi ${n} – ${d}`, body: (h, t, l, d) => `${h}\n\n${d} tarihi itibarıyla TECE nezdindeki hesabınızın açık kalemleri aşağıdadır. Toplam açık tutar ${t}${l}.\n\nEkstreyi ayrıca PDF olarak ekledik. Ödemeyi daha önce yaptıysanız, eşleştirebilmemiz için dekontu bize iletmenizi rica ederiz. Kayıtlarınızla uyuşmayan bir şey varsa lütfen bildirin, birlikte kontrol edelim.\n\nİlginiz için teşekkür ederiz.` },
  fr: { subject: (n, d) => `Relevé de compte ${n} – ${d}`, body: (h, t, l, d) => `${h}\n\nVeuillez trouver ci-dessous les factures ouvertes sur votre compte chez TECE au ${d}. Le montant total dû est de ${t}${l}.\n\nLe relevé est également joint en PDF. Si vous avez déjà effectué un paiement, merci de nous envoyer la preuve de virement afin que nous puissions l'affecter. Si quelque chose ne correspond pas à vos écritures, dites-le-nous et nous vérifierons ensemble.\n\nMerci de votre collaboration.` },
  ru: { subject: (n, d) => `Акт сверки ${n} – ${d}`, body: (h, t, l, d) => `${h}\n\nНиже приведены неоплаченные позиции по вашему счёту в TECE на ${d}. Общая сумма к оплате: ${t}${l}.\n\nАкт сверки также приложен в формате PDF. Если вы уже произвели оплату, пришлите, пожалуйста, подтверждение перевода, чтобы мы могли её зачесть. Если что-то не совпадает с вашими данными, сообщите нам, и мы проверим вместе.\n\nБлагодарим за сотрудничество.` },
};
const HELLO: Record<Lang, (n: string) => string> = { en: (n) => `Dear ${n},`, es: (n) => `Estimado/a ${n}:`, de: (n) => `Sehr geehrte/r ${n},`, tr: (n) => `Sayın ${n},`, fr: (n) => `Cher/Chère ${n},`, ru: (n) => `Уважаемый(ая) ${n},` };
const LATE: Record<Lang, (m: string) => string> = { en: (m) => `, of which ${m} is overdue`, es: (m) => `, de los cuales ${m} están vencidos`, de: (m) => `, davon ${m} überfällig`, tr: (m) => `, bunun ${m} tutarı vadesi geçmiştir`, fr: (m) => `, dont ${m} sont échus`, ru: (m) => `, из них просрочено ${m}` };

export function statementTableHtml(sap: string, lang: Lang): string {
  const w = words(lang);
  const st = statementItems(sap);
  if (!st.items.length) return '';
  const cell = 'padding:6px 10px;border-bottom:1px solid #e3e6ec;font:13px Calibri,Arial,sans-serif;color:#17243e';
  const th = 'padding:6px 10px;border-bottom:2px solid #17243e;font:bold 11px Calibri,Arial,sans-serif;color:#5e6676;text-align:left;text-transform:uppercase';
  const total = st.items.reduce((s, i) => s + i.amount, 0);
  const rows = st.items.map((i) => `<tr><td style="${cell}">${esc(dmy(i.date))}</td><td style="${cell}">${esc(i.carried ? w.carried : describe(i.description, lang))}</td><td style="${cell};text-align:right">${esc(money(i.amount, st.currency))}</td><td style="${cell};text-align:right;${i.daysOver > 0 ? 'color:#8b1931;font-weight:bold' : ''}">${i.daysOver > 0 ? `${i.daysOver} ${esc(w.days)}` : '—'}</td></tr>`).join('');
  return `<table cellspacing="0" cellpadding="0" style="border-collapse:collapse;margin:6px 0 16px;min-width:480px"><thead><tr><th style="${th}">${esc(w.date)}</th><th style="${th}">${esc(w.description)}</th><th style="${th};text-align:right">${esc(w.amount)}</th><th style="${th};text-align:right">${esc(w.overdue)}</th></tr></thead><tbody>${rows}<tr><td colspan="2" style="${cell};font-weight:bold">${esc(w.total)}</td><td style="${cell};text-align:right;font-weight:bold">${esc(money(total, st.currency))}</td><td style="${cell}"></td></tr></tbody></table>`;
}

export function statementDraft(a: { name: string; sap: string; contact: string; lang: Lang }): { subject: string; body: string } {
  const st = statementItems(a.sap);
  const total = st.items.reduce((s, i) => s + i.amount, 0);
  const late = st.items.filter((i) => i.daysOver > 0).reduce((s, i) => s + i.amount, 0);
  const d = dmy(today());
  const m = MAIL[a.lang];
  return { subject: m.subject(a.name, d), body: m.body(HELLO[a.lang](a.contact || a.name), money(total, st.currency), late > 0 ? LATE[a.lang](money(late, st.currency)) : '', d) };
}

// ---- the dispatch request --------------------------------------------------------------------------------------------------------
export function dispatchDraft(r: DispatchSum): { to: string; subject: string; body: string } {
  return {
    to: OPERATIONS_EMAIL,
    subject: `Sevkiyat talebi - ${r.customer} - SD: ${r.sds.join(', ')}`,
    body: `Merhaba,\n\n${r.lots === 1 ? 'Bu sipariş' : 'Bu siparişler'} Bursa'da hazır. Lütfen sevkiyata hazırlayın ve sevkiyat tarihini bildirin.\n\nPaketleme notları: \n\nTeşekkürler.`,
  };
}

export function dispatchTableHtml(r: DispatchSum): string {
  const cell = 'padding:6px 12px;border:1px solid #e3e6ec;font:13px Calibri,Arial,sans-serif;color:#17243e';
  const k = `${cell};background:#f3f4f7;font-weight:bold;width:170px`;
  const line = (a: string, b: string) => `<tr><td style="${k}">${esc(a)}</td><td style="${cell}">${esc(b)}</td></tr>`;
  return `<table cellspacing="0" cellpadding="0" style="border-collapse:collapse;margin:6px 0 16px">${[
    line('Müşteri', r.customer), line('Ülke', r.country), line('SD No', r.sds.join(', ')), line('Parti sayısı', String(r.lots)), line('En eski fatura tarihi', dmy(r.firstDate)),
    line('Brüt ağırlık (kg)', r.weight ? r.weight.toLocaleString('tr-TR', { maximumFractionDigits: 1 }) : '—'), line('Net tutar', money(r.value, r.currency)),
    line('Satış / Operasyon', `${r.salesRep || '—'} / ${r.opsRep || '—'}`),
    ...(r.risk === 'black' ? [line('HESAP DURUMU', `KARA HESAP - ${money(r.account?.overdue ?? 0, r.account?.currency ?? r.currency)} vadesi geçmiş. Finans onaylamadan sevk etmeyin.`)] : r.risk === 'risk' ? [line('Hesap durumu', 'Geç ödüyor - sevkiyattan önce satış temsilcisiyle görüşün.')] : []),
  ].join('')}</table>`;
}

// ---- the AI texts ----------------------------------------------------------------------------------------------------------------
const GEMINI_URL = process.env.GEMINI_BASE_URL || 'https://generativelanguage.googleapis.com/v1beta/models'; // (the gate sends it to DeepSeek)
const MODEL = 'gemini-3.6-flash';

export async function askJson(prompt: string, schema: Record<string, unknown>): Promise<Record<string, unknown> | null> {
  if (!env.geminiApiKey || blockedReason()) return null;
  try {
    const res = await fetch(`${GEMINI_URL}/${MODEL}:generateContent`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-goog-api-key': env.geminiApiKey },
      body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { temperature: 0.4, responseMimeType: 'application/json', responseSchema: schema } }),
      signal: AbortSignal.timeout(60000),
    });
    if (!res.ok) return null;
    const data = (await res.json()) as { candidates?: { content?: { parts?: { text?: string }[] } }[] };
    return JSON.parse((data.candidates?.[0]?.content?.parts ?? []).map((p) => p.text ?? '').join('')) as Record<string, unknown>;
  } catch {
    return null;
  }
}

const eur = (n: number, cur = 'EUR') => `${SYMBOL[cur] ?? `${cur} `}${Math.round(n).toLocaleString('en-US')}`;

// "Why did they stop ordering?" The first sentences are plain facts from the ledger; the AI adds what it can say with care. Kept in perf_diagnostics.
export async function diagnose(a: Account, years: Record<number, number>, force = false): Promise<string> {
  if (!force) {
    const row = db.prepare("SELECT body FROM perf_diagnostics WHERE sap_no = ? AND made_at >= datetime('now', '-60 days')").get(a.sap) as { body: string } | undefined;
    if (row) return row.body;
  }
  const best = Object.entries(years).sort((x, y) => y[1] - x[1])[0];
  const facts = `Why did they stop ordering? ${a.name} generated ${eur(a.bestYear, a.currency)} in its best year${best ? ` (${best[0]})` : ''}; the last invoice was on ${dmy(a.lastInvoice) || 'an unknown date'}. The balance is ${a.balance <= 0 ? 'clear' : `only ${eur(a.balance, a.currency)}`}. A likely reason is that our decors no longer match their range, or that they changed supplier (for example REHAU, Roma, Surteco). Suggest starting a reactivation flow with matched decors.`;
  const yearsText = Object.entries(years).filter(([, v]) => v > 0).sort().map(([y, v]) => `${y}: ${eur(v, a.currency)}`).join(', ');
  const j = await askJson(
    [`TECE is a Turkish edgebanding maker (PVC, ABS, PP, melamine). A customer stopped ordering and the account is clear. Give a short, careful assessment for the salesperson (max 3 sentences, English, no invented facts, say "possibly" where you are not sure) of why they may have stopped and the one best next step.`,
      `Customer: ${a.name}${a.country ? `, ${a.country}` : ''}. Invoiced per year: ${yearsText || 'unknown'}. Last invoice: ${a.lastInvoice ?? 'unknown'}. Open balance: ${eur(a.balance, a.currency)}.`].join('\n'),
    { type: 'OBJECT', properties: { assessment: { type: 'STRING' } }, required: ['assessment'] },
  );
  const text = j?.assessment ? `${facts}\n\n${String(j.assessment).trim()}` : facts;
  db.prepare("INSERT INTO perf_diagnostics (sap_no, body, made_at) VALUES (?, ?, datetime('now')) ON CONFLICT(sap_no) DO UPDATE SET body = excluded.body, made_at = excluded.made_at").run(a.sap, text);
  return text;
}

export async function reactivationDraft(a: Account, contact: string, lang: Lang, sender: string): Promise<{ subject: string; body: string; ai: boolean }> {
  const hello = HELLO[lang](contact || a.name);
  const fallback: Record<Lang, { subject: string; body: string }> = {
    en: { subject: 'New decors for your range – TECE', body: `${hello}\n\nIt has been a while since our last order together, and we would like to hear how your business is going. We have added many new decors and finishes to our edgebanding range, and I would be glad to send you matching samples for your current panels.\n\nWould you have a few minutes this week for a short call?\n\nBest regards,\n${sender}` },
    es: { subject: 'Nuevos decorados para su gama – TECE', body: `${hello}\n\nHa pasado un tiempo desde nuestro último pedido y nos gustaría saber cómo va su negocio. Hemos añadido muchos decorados y acabados nuevos a nuestra gama de cantos, y con gusto le enviaría muestras a juego con sus tableros actuales.\n\n¿Tendría unos minutos esta semana para una breve llamada?\n\nSaludos cordiales,\n${sender}` },
    de: { subject: 'Neue Dekore für Ihr Sortiment – TECE', body: `${hello}\n\nunser letzter gemeinsamer Auftrag liegt schon eine Weile zurück, und wir würden gern erfahren, wie Ihr Geschäft läuft. Wir haben viele neue Dekore und Oberflächen in unser Kantensortiment aufgenommen und senden Ihnen gern passende Muster zu Ihren aktuellen Platten.\n\nHätten Sie diese Woche ein paar Minuten für ein kurzes Gespräch?\n\nMit freundlichen Grüßen\n${sender}` },
    tr: { subject: 'Ürün gamınız için yeni dekorlar – TECE', body: `${hello}\n\nSon siparişimizin üzerinden bir süre geçti, işlerinizin nasıl gittiğini duymak isteriz. Kenar bandı gamımıza çok sayıda yeni dekor ve yüzey ekledik; mevcut panellerinize uygun numuneleri memnuniyetle göndeririz.\n\nBu hafta kısa bir görüşme için birkaç dakikanız olur mu?\n\nSaygılarımla,\n${sender}` },
    fr: { subject: 'Nouveaux décors pour votre gamme – TECE', body: `${hello}\n\nNotre dernière commande commune remonte à un moment et nous aimerions savoir comment va votre activité. Nous avons ajouté de nombreux décors et finitions à notre gamme de chants, et je vous enverrais volontiers des échantillons assortis à vos panneaux actuels.\n\nAuriez-vous quelques minutes cette semaine pour un bref appel ?\n\nCordialement,\n${sender}` },
    ru: { subject: 'Новые декоры для вашего ассортимента – TECE', body: `${hello}\n\nС нашего последнего заказа прошло некоторое время, и нам хотелось бы узнать, как идут ваши дела. Мы добавили много новых декоров и покрытий в ассортимент кромки и с радостью вышлем образцы, подходящие к вашим текущим плитам.\n\nНайдётся ли у вас на этой неделе несколько минут для короткого звонка?\n\nС уважением,\n${sender}` },
  };
  const names: Record<Lang, string> = { en: 'English', es: 'Spanish', de: 'German', tr: 'Turkish', fr: 'French', ru: 'Russian' };
  const j = await askJson(
    [`Write a short, warm, professional e-mail in ${names[lang]} from ${sender} at TECE (Turkish maker of edgebanding for furniture panels: PVC, ABS, PP, melamine) to ${contact || 'the buyer'} at ${a.name}${a.country ? ` (${a.country})` : ''}, a customer who bought about ${eur(a.bestYear, a.currency)} in their best year but has not ordered for over 12 months and owes nothing.`,
      'Goal: restart the relationship. Mention that we have new decors and finishes, offer matching samples for their current panels, and ask for a short call. Do not invent prices, product codes or promises, and do not mention that they stopped ordering in a blaming way. Maximum 120 words. Start with the greeting and end with the sender name.'].join('\n'),
    { type: 'OBJECT', properties: { subject: { type: 'STRING' }, body: { type: 'STRING' } }, required: ['subject', 'body'] },
  );
  if (j?.subject && j?.body) return { subject: String(j.subject), body: String(j.body), ai: true };
  return { ...fallback[lang], ai: false };
}

// ---- the full suggestion for a customer ------------------------------------------------------------------------------------------
export interface Suggestion { summary: string; risks: string[]; actions: string[]; offer: string; talking: string[]; ai: boolean; madeAt: string }

// plain rules over the numbers: always there, even when the AI is off
function ruleSuggestion(a: Account): Omit<Suggestion, 'ai' | 'madeAt'> {
  const risks: string[] = [];
  const actions: string[] = [];
  const cur = a.currency;
  const ys = Object.entries(a.years).map(([y, v]) => [Number(y), v] as const).sort((x, y) => x[0] - y[0]);
  const last = ys.at(-1);
  if (a.hold) { risks.push(`Debt hold: owes ${eur(a.balance, cur)} and has not been invoiced for 12 months.`); actions.push('Send the account statement and ask for payment before any new offer.'); }
  if (a.overdue > 0) { risks.push(`${eur(a.overdue, cur)} is past its due date (the oldest invoice by ${a.oldestOver} days).`); actions.push(`Ask for payment: send the statement (${eur(a.overdue, cur)} overdue).`); }
  if (a.blockers > 0) actions.push(`${a.blockers} order(s) wait for confirmation or the advance payment: ask the customer to confirm.`);
  if (a.readyToShip > 0) actions.push(`${a.readyToShip} shipment(s) are ready in Bursa: agree the dispatch with operations.`);
  if (a.yoy !== null && a.yoy < -15) { risks.push(`Invoicing is ${Math.abs(a.yoy).toFixed(0)}% below the same days of last year.`); actions.push('Call the customer: ask what changed (stock, price, a competitor, decors) and offer matched samples.'); }
  if (a.yoy !== null && a.yoy > 25) actions.push('Growing fast: confirm the forecast for the rest of the year and offer a stock or frame agreement.');
  if (a.target && a.health === 'behind') actions.push(`Behind the target (${a.pace?.toFixed(0)}%): ask for the next order.`);
  if (!a.target && a.prevYear > 0) actions.push(`Set a target for this year (last year: ${eur(a.prevYear, cur)}).`);
  if (a.inactive && a.bestYear > 0) actions.push('No invoice for 12 months: start the reactivation flow with matched decors.');
  if (!actions.length) actions.push('Keep the regular contact: ask about the next order and new decors.');
  const summary = last ? `${a.name} (${a.country || 'no country'}): invoiced ${eur(last[1], cur)} in ${last[0]}${a.ytd ? `, ${eur(a.ytd, cur)} so far this year` : ''}. Open balance ${a.balance > 0.5 ? eur(a.balance, cur) : 'none'}.` : `${a.name}: no invoices on the ledger yet.`;
  return { summary, risks, actions, offer: '', talking: [] };
}

export function savedSuggestion(sap: string): Suggestion | null {
  const row = db.prepare('SELECT body, made_at FROM perf_suggestions WHERE sap_no = ?').get(sap) as { body: string; made_at: string } | undefined;
  if (!row) return null;
  try { return { ...(JSON.parse(row.body) as Suggestion), madeAt: row.made_at }; } catch { return null; }
}

export async function suggest(a: Account): Promise<Suggestion> {
  const base = ruleSuggestion(a);
  const yearsText = Object.entries(a.years).filter(([, v]) => v > 0).sort().map(([y, v]) => `${y}: ${eur(v, a.currency)}`).join(', ') || 'none';
  const sap = db.prepare('SELECT status, orders, m2, first_order, last_order, note FROM sap_customers WHERE sap_no = ?').get(a.sap) as { status: string; orders: number | null; m2: number | null; first_order: string | null; last_order: string | null; note: string } | undefined;
  const facts = [
    `Customer: ${a.name}, ${a.country || 'country unknown'}. Currency: ${a.currency}.`,
    `Invoiced per year: ${yearsText}. This year so far: ${eur(a.ytd, a.currency)} (same days last year: ${eur(a.prevYtd, a.currency)}${a.yoy !== null ? `, ${a.yoy.toFixed(0)}%` : ''}). Target this year: ${a.target ? eur(a.target, a.currency) : 'not set'}.`,
    `Open balance ${eur(a.balance, a.currency)}; overdue ${eur(a.overdue, a.currency)}; oldest unpaid invoice ${a.oldestOver} days past due. Last invoice ${a.lastInvoice ?? 'never'}, last payment ${a.lastPayment ?? 'never'}. Small bank charges that TECE absorbs: ${eur(a.bankCuts, a.currency)} (never ask the customer for these).`,
    `Orders on the way: ${a.blockers} waiting for confirmation/advance, ${a.backlogM2 ? `${Math.round(a.backlogM2)} m² in production` : 'nothing in production'}, ${a.readyToShip} ready to dispatch.`,
    sap ? `SAP: status ${sap.status}, ${sap.orders ?? '?'} orders in all, ${sap.m2 ? `${Math.round(sap.m2)} m² in all, ` : ''}first order ${sap.first_order ?? '?'}, last order ${sap.last_order ?? '?'}. ${sap.note || ''}` : '',
    a.hold ? 'DEBT HOLD: no invoice for 12 months and a big debt; no new offers until an admin lifts it.' : '',
  ].filter(Boolean).join('\n');
  const j = await askJson(
    [`You advise a salesperson of TECE (Turkish maker of edgebanding for furniture panels: PVC, ABS, PP, melamine) about one export customer. Use ONLY the facts below; do not invent numbers, products or events; say "possibly" when you infer.`,
      'Give: summary (2-3 sentences: where the customer stands, the trend); risks (up to 4 short items); actions (3 to 5 concrete next steps, most urgent first, e.g. ask for payment, ask for the order, confirm the dispatch, offer matched decors); offer (one idea for the next offer or sample, or empty); talking (up to 3 questions to ask the customer on the next call). English.',
      facts].join('\n\n'),
    { type: 'OBJECT', properties: { summary: { type: 'STRING' }, risks: { type: 'ARRAY', items: { type: 'STRING' } }, actions: { type: 'ARRAY', items: { type: 'STRING' } }, offer: { type: 'STRING' }, talking: { type: 'ARRAY', items: { type: 'STRING' } } }, required: ['summary', 'actions'] },
  );
  const list = (v: unknown) => (Array.isArray(v) ? v.map((x) => String(x).trim()).filter(Boolean).slice(0, 6) : []);
  const out: Suggestion = j && j.summary
    ? { summary: String(j.summary).trim(), risks: list(j.risks), actions: list(j.actions).length ? list(j.actions) : base.actions, offer: String(j.offer ?? '').trim(), talking: list(j.talking), ai: true, madeAt: '' }
    : { ...base, ai: false, madeAt: '' };
  if (out.ai) db.prepare("INSERT INTO perf_suggestions (sap_no, body, made_at) VALUES (?, ?, datetime('now')) ON CONFLICT(sap_no) DO UPDATE SET body = excluded.body, made_at = excluded.made_at").run(a.sap, JSON.stringify(out));
  return { ...out, madeAt: new Date().toISOString().slice(0, 16).replace('T', ' ') };
}
