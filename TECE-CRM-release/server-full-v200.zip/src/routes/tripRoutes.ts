import { Router, type Response } from 'express';
import { db } from '../db/connection';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { activityModel } from '../models/activityModel';
import { cardModel } from '../models/cardModel';
import { settingsModel } from '../models/settingsModel';
import { useAi } from '../services/aiBudget';
import { aiFailureMessage } from '../services/aiGate';
import { locateStatus, startLocating } from '../services/geocode';
import { LOCALE, langOf, tripMessage, tripSubject } from '../services/outreachText';
import { askJson } from '../services/perfActions';
import { peopleOf } from '../services/meetingPeople';
import { buildSignature, styleFor } from '../services/signature';
import { renderTablePdf, type PdfSection } from '../services/tablePdf';
import { sendThankYouEmail } from '../services/thankYouEmail';
import { addDays, candidates, optimise, routeOf, tripModel, type Kind, type Stop, type Trip } from '../services/trips';
import { interestOf } from '../services/interest';
import { visibilitySql, visibilityFor } from '../services/visibility';
import { env } from '../config/env';
import countryNames from 'i18n-iso-countries';
import trNames from 'i18n-iso-countries/langs/tr.json';
import { isoOf } from '../services/phone';
countryNames.registerLocale(trNames);

const router = Router();
router.use(requireAuth);

const asInt = (v: unknown): number => parseInt(String(v), 10);
const sendPdf = (res: Response, pdf: Buffer, name: string) => { res.setHeader('Content-Type', 'application/pdf'); res.setHeader('Content-Disposition', `inline; filename="${name}"`); res.send(pdf); };

// a trip belongs to the person who made it (an admin may open any)
function mine(req: AuthedRequest, res: Response): Trip | null {
  const t = tripModel.find(asInt(req.params.id));
  if (!t || (t.userId !== req.user!.id && req.user!.role !== 'admin')) { res.status(404).json({ error: 'Trip not found' }); return null; }
  return t;
}

router.get('/', (req: AuthedRequest, res) => res.json(tripModel.list(req.user!, req.query.all === '1')));

router.post('/', (req: AuthedRequest, res) => res.status(201).json(tripModel.create(req.user!.id, req.body ?? {})));

// The countries a person can plan a trip to: those with customers they may see, with how many.
router.get('/countries', (req: AuthedRequest, res) => {
  const params: Record<string, string | number> = {};
  const vis = visibilitySql(req.user!, params);
  const rows = db.prepare(`SELECT country, COUNT(*) AS n FROM cards WHERE market != 'domestic' AND status != 'needs_review' AND COALESCE(country, '') != '' ${vis ? `AND ${vis}` : ''} GROUP BY country ORDER BY country`).all(params) as { country: string; n: number }[];
  // the Turkish name and the ISO code go along, so a person can type either name (or a continent) in the planner
  res.json(rows.map((r) => { const iso = isoOf(r.country); return { country: r.country, n: r.n, iso, tr: iso ? countryNames.getName(iso, 'tr') ?? null : null }; }));
});

router.get('/candidates', (req: AuthedRequest, res) => {
  const list = (v: unknown) => String(v ?? '').split(',').map((x) => x.trim()).filter(Boolean);
  const kinds = list(req.query.kinds).filter((k): k is Kind => k === 'existing' || k === 'important' || k === 'tiers');
  res.json(candidates(req.user!, { countries: list(req.query.countries), kinds, text: String(req.query.q ?? '') }));
});

// ---- finding the place of customers -------------------------------------------------------------------------------------------------
router.post('/locate', (req: AuthedRequest, res) => {
  const ids = (Array.isArray(req.body?.ids) ? req.body.ids : []).map(asInt).filter((n: number) => Number.isInteger(n)).slice(0, 400);
  const ok = visibilityFor(req.user!);
  const allowed = ids.filter((id: number) => { const c = cardModel.findById(id); return !!c && ok(c); });
  const useAiNow = req.body?.useAi !== false;
  if (useAiNow && env.geminiApiKey && !useAi(req.user!, res)) return;
  // the AI search costs tokens: an admin may ask it for many customers, anybody else for a few at a time
  res.json(startLocating(allowed, { useAi: useAiNow, force: req.body?.force === true, aiMax: req.user!.role === 'admin' ? 300 : 15 }));
});
router.get('/locate/status', (_req, res) => res.json(locateStatus()));

// A person puts a customer on the map by hand (the marker is dragged to the right place).
router.post('/place', (req: AuthedRequest, res) => {
  const card = cardModel.findById(asInt(req.body?.cardId));
  const lat = Number(req.body?.lat); const lon = Number(req.body?.lon);
  if (!card || !visibilityFor(req.user!)(card)) return res.status(404).json({ error: 'Customer not found' });
  if (!Number.isFinite(lat) || !Number.isFinite(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) return res.status(400).json({ error: 'That is not a place on the map.' });
  db.prepare("UPDATE cards SET lat = ?, lon = ?, geo_source = 'manual' WHERE id = ?").run(lat, lon, card.id);
  res.json({ ok: true });
});

// ---- one trip ----------------------------------------------------------------------------------------------------------------------------
router.get('/:id', (req: AuthedRequest, res) => {
  const t = mine(req, res);
  if (!t) return;
  res.json({ trip: t, stops: tripModel.stops(t.id, req.user!) });
});

router.put('/:id', (req: AuthedRequest, res) => {
  const t = mine(req, res);
  if (!t) return;
  res.json(tripModel.update(t.id, req.body ?? {}));
});

router.delete('/:id', (req: AuthedRequest, res) => {
  const t = mine(req, res);
  if (!t) return;
  tripModel.remove(t.id);
  res.json({ ok: true });
});

// The whole plan (customers, their day and order), sent after every change.
router.put('/:id/stops', (req: AuthedRequest, res) => {
  const t = mine(req, res);
  if (!t) return;
  const items = (Array.isArray(req.body?.stops) ? req.body.stops : []).map((s: Record<string, unknown>) => ({ cardId: asInt(s.cardId), dayNo: s.dayNo === null || s.dayNo === undefined ? null : asInt(s.dayNo), visitTime: typeof s.visitTime === 'string' ? s.visitTime : null, note: typeof s.note === 'string' ? s.note : null }));
  tripModel.setStops(t.id, items, req.user!);
  res.json({ stops: tripModel.stops(t.id, req.user!) });
});

// "Plan the route": the shortest way through the customers, cut into days.
router.post('/:id/optimise', (req: AuthedRequest, res) => {
  const t = mine(req, res);
  if (!t) return;
  const r = optimise(t.id, req.user!, { perDay: asInt(req.body?.perDay) || 4, startCardId: req.body?.startCardId ? asInt(req.body.startCardId) : null });
  res.json({ ...r, stops: tripModel.stops(t.id, req.user!) });
});

router.get('/:id/route', async (req: AuthedRequest, res) => {
  const t = mine(req, res);
  if (!t) return;
  res.json(await routeOf(t, tripModel.stops(t.id, req.user!)));
});

// ---- the route explained --------------------------------------------------------------------------------------------------------------
const name = (s: Stop) => `${s.company || s.name || 'customer'} (${[s.city, s.country].filter(Boolean).join(', ')})`;

// Plain sentences from the numbers - always available, never invented.
function plainExplain(t: Trip, stops: Stop[], r: Awaited<ReturnType<typeof routeOf>>): string {
  const byId = new Map(stops.map((s) => [s.stopId, s]));
  const lines: string[] = [];
  for (const d of r.days) {
    const list = d.stopIds.map((id) => byId.get(id)!).filter(Boolean);
    const when = d.date ? `Day ${d.dayNo} (${d.date})` : `Day ${d.dayNo}`;
    lines.push(`${when}: ${list.map(name).join(' → ')}${d.totalKm ? `. About ${d.totalKm} km${d.totalMinutes ? ` and ${Math.floor(d.totalMinutes / 60)} h ${d.totalMinutes % 60} min of driving` : ''}.` : '.'}`);
    const tr = r.transfers.find((x) => x.fromDay === d.dayNo);
    if (tr) lines.push(`Then ${tr.mode === 'flight' ? 'fly' : 'travel'} from ${tr.from} to ${tr.to} (about ${tr.km} km).`);
  }
  if (r.unplaced.length) lines.push(`${r.unplaced.length} customer(s) are not on a day or have no place on the map yet.`);
  lines.push(`In total about ${r.totalKm} km.`);
  return lines.join('\n');
}

router.post('/:id/explain', async (req: AuthedRequest, res) => {
  const t = mine(req, res);
  if (!t) return;
  const stops = tripModel.stops(t.id, req.user!);
  const r = await routeOf(t, stops);
  const plain = plainExplain(t, stops, r);
  if (!r.days.length) return res.json({ text: 'Plan the route first: put customers on days.', source: 'rules' });
  if (!env.geminiApiKey) return res.json({ text: plain, source: 'rules' });
  if (!useAi(req.user!, res)) return;
  const lang = req.body?.lang === 'tr' ? 'Turkish' : 'English';
  const facts = JSON.stringify({ trip: t.title, days: r.days.map((d) => ({ day: d.dayNo, date: d.date, stops: d.stopIds.map((id) => stops.find((s) => s.stopId === id)).map((s) => s && { company: s.company, city: s.city, country: s.country, stage: s.stage, rating: s.rating, tier: s.tier, visitTime: s.visitTime }), km: d.totalKm, driveMinutes: d.totalMinutes })), transfers: r.transfers, totalKm: r.totalKm, notPlaced: r.unplaced.length });
  const j = await askJson(`You are helping a sales manager plan a customer trip. Explain this route in ${lang}, in plain words, as a short plan day by day: what is visited in which order and why that order makes sense (distances, same city or region, flights between countries). Mention which customers matter most (existing customers, high rating or Hot/Warm tier) when the data says so. Use ONLY the facts in this JSON: do not invent places, distances, times, opening hours or road conditions. Under 220 words.\n\n${facts}`, { type: 'OBJECT', properties: { explanation: { type: 'STRING' } }, required: ['explanation'] });
  const text = typeof j?.explanation === 'string' && j.explanation.trim() ? j.explanation.trim() : null;
  res.json(text ? { text, source: 'ai' } : { text: plain, source: 'rules', note: aiFailureMessage('The AI did not answer: this is the plain version.') });
});

// ---- the PDF report ----------------------------------------------------------------------------------------------------------------------
router.get('/:id/pdf', async (req: AuthedRequest, res) => {
  const t = mine(req, res);
  if (!t) return;
  const stops = tripModel.stops(t.id, req.user!);
  const r = await routeOf(t, stops);
  const lastNote = db.prepare("SELECT text, created_at FROM activities WHERE card_id = ? AND type IN ('note','call','visit','meeting','sample','offer','email') AND COALESCE(text,'') != '' ORDER BY created_at DESC LIMIT 1");
  const row = (s: Stop) => {
    const card = cardModel.findById(s.cardId);
    const interest = card ? interestOf(card as never) : null;
    const last = lastNote.get(s.cardId) as { text: string; created_at: string } | undefined;
    const status = [s.stage === 'customer' ? 'Customer' : s.stage ? s.stage[0].toUpperCase() + s.stage.slice(1) : '', s.rating != null ? `rating ${s.rating}` : '', s.tier ?? ''].filter(Boolean).join(' · ');
    return [
      s.visitTime ? `${s.visitTime}  ${s.company || s.name || ''}` : s.company || s.name || '',
      [s.city, s.country].filter(Boolean).join(', '),
      [s.name, s.position].filter(Boolean).join(', ') || '-',
      [s.mobile || s.tel, s.email, s.website].filter(Boolean).join('\n') || '-',
      { text: status || '-', tone: s.stage === 'customer' ? 'good' as const : undefined },
      [interest?.products?.length ? interest.products.join(', ') : '', card?.work_area ?? ''].filter(Boolean).join(' · ').slice(0, 120) || '-',
      last ? `${last.created_at.slice(0, 10)}: ${last.text.replace(/\s+/g, ' ').slice(0, 110)}` : '-',
    ];
  };
  const columns = [{ label: 'Customer', w: 130 }, { label: 'Place', w: 90 }, { label: 'Contact', w: 110 }, { label: 'Phone / e-mail / web', w: 150 }, { label: 'Status', w: 90 }, { label: 'Interested in / does', w: 110 }, { label: 'Last contact', w: 80 }];
  const sections: PdfSection[] = r.days.map((d) => {
    const leg = d.totalKm ? ` · about ${d.totalKm} km${d.totalMinutes ? `, ${Math.floor(d.totalMinutes / 60)} h ${d.totalMinutes % 60} min driving` : ''}` : '';
    const tr = r.transfers.find((x) => x.fromDay === d.dayNo);
    return {
      heading: `Day ${d.dayNo}${d.date ? ` - ${d.date}` : ''}`,
      note: `${d.stopIds.length} customer${d.stopIds.length === 1 ? '' : 's'}${leg}${tr ? ` · then ${tr.mode === 'flight' ? 'fly' : 'go'} to ${tr.to} (about ${tr.km} km)` : ''}`,
      columns,
      rows: d.stopIds.map((id) => stops.find((s) => s.stopId === id)!).filter(Boolean).map(row),
    };
  });
  const loose = stops.filter((s) => s.dayNo === null || !r.days.some((d) => d.stopIds.includes(s.stopId)));
  if (loose.length) sections.push({ heading: 'Not on a day yet', columns, rows: loose.map(row) });
  const countries = [...new Set(stops.map((s) => s.country).filter(Boolean))];
  const pdf = await renderTablePdf({
    title: t.title,
    subtitle: [t.startDate && t.endDate ? `${t.startDate} to ${t.endDate}` : t.startDate ?? '', countries.join(', ')].filter(Boolean).join('  ·  ') || undefined,
    facts: [`${stops.length} customers`, `${r.days.length} day${r.days.length === 1 ? '' : 's'}`, r.totalKm ? `about ${r.totalKm} km` : '', `made by ${req.user!.display_name || req.user!.username}`].filter(Boolean),
    sections,
    landscape: true,
  });
  sendPdf(res, pdf, `${t.title.replace(/[^\w.-]+/g, '_')}.pdf`);
});

// ---- messages to the customers of the trip ------------------------------------------------------------------------------------------------
// preview: the text for each customer, in its language. send: e-mails (from the server, as the person) and/or WhatsApp links (the person presses send).
function rangeText(t: Trip, lang: string | null): string {
  const loc = LOCALE[langOf(lang)];
  const f = (d: string) => new Date(`${d}T12:00:00Z`);
  const o: Intl.DateTimeFormatOptions = { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' };
  try {
    if (t.startDate && t.endDate && t.endDate !== t.startDate) return new Intl.DateTimeFormat(loc, o).formatRange(f(t.startDate), f(t.endDate));
    if (t.startDate) return new Intl.DateTimeFormat(loc, o).format(f(t.startDate));
  } catch { /* fall through */ }
  return '';
}
const dayText = (t: Trip, s: Stop): string => {
  if (!t.startDate || s.dayNo === null) return rangeText(t, s.language);
  return new Intl.DateTimeFormat(LOCALE[langOf(s.language)], { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' }).format(new Date(`${addDays(t.startDate, s.dayNo - 1)}T12:00:00Z`));
};

router.post('/:id/messages', async (req: AuthedRequest, res) => {
  const t = mine(req, res);
  if (!t) return;
  const b = (req.body ?? {}) as Record<string, unknown>;
  const send = b.send === true;
  const wantIds = new Set((Array.isArray(b.stopIds) ? b.stopIds : []).map(asInt));
  const stops = tripModel.stops(t.id, req.user!).filter((s) => wantIds.has(s.stopId)).slice(0, 60);
  const extra = String(b.extra ?? '').slice(0, 1000).trim();
  const user = req.user!.display_name || req.user!.username;
  const testWanted = b.test === true || settingsModel.get('test_mode') === '1';
  const testTo = testWanted ? settingsModel.get('test_email') || req.user!.email || '' : null;
  if (send && testTo === '') return res.status(400).json({ error: 'There is no test address. Add your e-mail under My account.' });

  const out: { stopId: number; company: string; person: string; language: string; subject: string; body: string; emails: string[]; whatsapp: { name: string; to: string; url: string }[]; sent?: boolean; error?: string; skipped?: string }[] = [];
  for (const s of stops) {
    const card = cardModel.findById(s.cardId);
    if (!card) continue;
    const people = peopleOf(card);
    const main = people.find((p) => p.emails.length) ?? people[0];
    const first = (main?.name ?? '').split(/\s+/)[0] || card.company || '';
    const place = s.city || s.country || '';
    const body = tripMessage(card.language, { name: first, user, place, when: dayText(t, s), at: s.visitTime ?? undefined, extra });
    const subject = tripSubject(card.language, place, dayText(t, s) || t.title);
    const wa = people.filter((p) => p.whatsapp).map((p) => ({ name: p.name || card.company || '', to: p.whatsapp!, url: `https://wa.me/${p.whatsapp!.slice(1)}?text=${encodeURIComponent(tripMessage(card.language, { name: p.name.split(/\s+/)[0] || card.company || '', user, place, when: dayText(t, s), at: s.visitTime ?? undefined, extra }))}` }));
    out.push({ stopId: s.stopId, company: s.company || s.name || '', person: main?.name ?? '', language: langOf(card.language), subject, body, emails: main?.emails ?? [], whatsapp: wa });
  }

  if (send && b.channel === 'email') {
    for (const m of out) {
      if (!m.emails.length) { m.skipped = 'No e-mail address'; continue; }
      const s = stops.find((x) => x.stopId === m.stopId)!;
      try {
        await sendThankYouEmail({
          to: m.emails.join(', '), cc: req.user!.email || null, subject: m.subject, body: m.body, replyTo: req.user!.email,
          signature: buildSignature(req.user, styleFor(req.user)), testTo: testTo || null,
          record: { cardId: s.cardId, userId: req.user!.id, kind: 'trip' },
        });
        m.sent = true;
        if (!testTo) {
          db.prepare("UPDATE trip_stops SET messaged_at = datetime('now') WHERE id = ?").run(m.stopId);
          activityModel.add({ userId: req.user!.id, cardId: s.cardId, type: 'email', text: `Trip message sent (${t.title}): ${m.subject}` });
        }
      } catch (err) {
        m.error = (err as Error).message;
      }
    }
  }
  res.json({ messages: out, test: !!testTo, testTo: testTo || null });
});

// A WhatsApp link was opened: remember that this customer was written to.
router.post('/:id/messaged', (req: AuthedRequest, res) => {
  const t = mine(req, res);
  if (!t) return;
  const stopId = asInt(req.body?.stopId);
  const s = tripModel.stops(t.id, req.user!).find((x) => x.stopId === stopId);
  if (!s) return res.status(404).json({ error: 'Not found' });
  db.prepare("UPDATE trip_stops SET messaged_at = datetime('now') WHERE id = ?").run(stopId);
  activityModel.add({ userId: req.user!.id, cardId: s.cardId, type: 'note', text: `Trip message sent on WhatsApp (${t.title})` });
  res.json({ ok: true });
});

export default router;
