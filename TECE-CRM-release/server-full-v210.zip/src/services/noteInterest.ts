import { db } from '../db/connection';
import { listBrands } from './boardBrands';

// The panel producers a person writes about in a note ("they buy Kronospan and Kastamonu") are added to the customer's panel interest, so nobody has to tick them by hand.
// Only ever ADDS: what a person set is never taken away.
const norm = (s: string) => ' ' + s.toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/ı/g, 'i').replace(/[^a-z0-9]+/g, ' ').trim() + ' ';

let cache: { at: number; list: { id: number; name: string; key: string }[] } | null = null;
function brands() {
  if (cache && Date.now() - cache.at < 60_000) return cache.list;
  const list = listBrands().map((b) => ({ id: b.id, name: b.name, key: norm(b.name) })).filter((b) => b.key.trim().length >= 3);
  cache = { at: Date.now(), list };
  return list;
}

export function brandsInText(text: string | null | undefined): { id: number; name: string }[] {
  const t = norm(String(text ?? ''));
  if (t.trim().length < 3) return [];
  return brands().filter((b) => t.includes(b.key));
}

export function applyNotesToBoards(cardId: number, ...texts: (string | null | undefined)[]): string[] {
  const found = brandsInText(texts.filter(Boolean).join('\n'));
  if (!found.length) return [];
  const ins = db.prepare('INSERT OR IGNORE INTO card_boards (card_id, brand_id) VALUES (?, ?)');
  const added: string[] = [];
  for (const b of found) if (Number(ins.run(cardId, b.id).changes) > 0) added.push(b.name);
  return added;
}
