import fs from 'fs';
import { Router } from 'express';
import { db } from '../db/connection';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { cardModel } from '../models/cardModel';
import { canSeeCard } from '../services/visibility';
import { archiveFile, type ArchiveRow } from '../services/archive';
import { forwardToStaff, staffOptions } from '../services/forwardMail';

// Forward a document to a colleague: the list of colleagues, and a PDF kept in the archive (a proforma or a price list).
const router = Router();
router.use(requireAuth);

router.get('/staff', (req: AuthedRequest, res) => {
  res.json(staffOptions(req.user!.id).map((s) => ({ id: s.id, name: s.name })));
});

router.post('/archive/:id', async (req: AuthedRequest, res) => {
  const row = db.prepare('SELECT * FROM document_archive WHERE id = ?').get(parseInt(String(req.params.id), 10)) as ArchiveRow | undefined;
  if (!row || !fs.existsSync(archiveFile(row))) return res.status(404).json({ error: 'Not found' });
  if (row.kind === 'proforma') {
    const card = row.card_id ? cardModel.findById(row.card_id) : undefined;
    if (!card || !canSeeCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  }
  try {
    const r = await forwardToStaff({
      sender: req.user!, staffId: Number(req.body?.userId), note: String(req.body?.note ?? ''),
      what: `${row.kind === 'price_list' ? 'Fiyat listesi' : 'Proforma'}: ${row.title ?? row.file_name}`,
      attachments: [{ filename: row.file_name, content: fs.readFileSync(archiveFile(row)), contentType: 'application/pdf' }],
    });
    res.json({ ok: true, ...r });
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

export default router;
