// The coaching report (Performance > My performance, and a person's scorecard under My team): make one (AI when it may be used, else rules),
// read the earlier ones, download the PDF, e-mail it to the person. Every number shown comes from the facts the server kept, never from the AI.
import { h, Fragment, useState, useEffect, useRef, api, Link, useT, Icon, cx, errText, toast, Skel, useTx, locVars, loc, trPct } from "./x-kit-1W3jRMzJ.js";

const when = (s) => { if (!s) return ""; const d = new Date(String(s).replace(" ", "T") + (/Z$|[+-]\d\d:\d\d$/.test(s) ? "" : "Z")); return Number.isFinite(d.getTime()) ? new Intl.DateTimeFormat(loc(), { timeZone: "Europe/Istanbul", day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" }).format(d) : String(s).slice(0, 16); };

// ---- the verdict (server: teamPerf.verdictFor): status, the decisive reasons in numbers, the strengths, the manager's options ------------
const VSTATUS = { on_track: ["good", "On track", "check-circle"], attention: ["warn", "Needs attention", "warning"], at_risk: ["bad", "At risk", "error"] };
const OPT_ICON = { coach: "wand-stars", pair: "handshake", reassign: "group-add", target: "flag", trip: "flight", price: "price-check" };
const OPT_GO = { reassign: "Open Admin > Countries", target: "Open Targets", trip: "Plan a trip", price: "Open Price performance" };
// {m} is a metric name ("sales growth"): translated as well, so a Turkish sentence does not carry an English word
const vsay = (t, p) => (p && p.t ? trPct(t(p.t, locVars(p.v && typeof p.v.m === "string" ? { ...p.v, m: t(p.v.m) } : p.v || {}))) : "");
export function VerdictPill({ status, big }) {
  const t = useTx("team");
  const s = VSTATUS[status] || VSTATUS.on_track;
  return h("span", { className: cx("tm-verdict-pill", "tm-verdict-pill--" + s[0], big && "tm-verdict-pill--big") }, h(Icon, { n: s[2], size: big ? 18 : 14 }), t(s[1]));
}
export function VerdictOptions({ options, onCoach, limit }) {
  const t = useTx("team");
  const [all, setAll] = useState(false);
  if (!options || !options.length) return null;
  const list = limit && !all ? options.slice(0, limit) : options;
  return h("div", { className: "tm-vopts" },
    h("b", { className: "tm-vopts-h" }, t("Your options")),
    h("ul", null, list.map((o, i) => h("li", { key: o.kind + i },
      h("span", { className: "tm-vopt-ic", "aria-hidden": true }, h(Icon, { n: OPT_ICON[o.kind] || "lightbulb", size: 18 })),
      h("span", { className: "tm-vopt-txt" }, h("b", null, vsay(t, o.title)), o.effect && o.effect.t ? h("small", null, vsay(t, o.effect)) : null, o.note ? h("small", { className: "tm-muted" }, vsay(t, o.note)) : null),
      o.action === "coach" && onCoach ? h("button", { type: "button", className: "tc-btn tc-btn--secondary tc-btn--sm", onClick: onCoach }, h(Icon, { n: "wand-stars", size: 16 }), t("Coaching report"))
        : o.to ? h(Link, { className: "tc-btn tc-btn--secondary tc-btn--sm", to: o.to }, t(OPT_GO[o.kind] || "Open")) : null,
    ))),
    limit && options.length > limit ? h("button", { type: "button", className: "tm-link tm-small", onClick: () => setAll(!all) }, all ? t("Fewer options") : t("All options ({n})", { n: options.length })) : null,
  );
}
export function VerdictPanel({ v, name, onCoach, self }) {
  const t = useTx("team");
  if (!v) return null;
  return h("section", { className: cx("tm-card tm-verdict", "tm-verdict--" + v.status) },
    h("div", { className: "tm-verdict-head" },
      h("div", null, h("h3", null, self ? t("Verdict") : t("Verdict for {name}", { name: (name || "").split(" ")[0] })), h("small", null, t("By fixed rules on the last 12 months: sales against target and last year, customers slowing or lost, price index, overdue follow-ups, activity - compared with the team."))),
      h(VerdictPill, { status: v.status, big: true }),
    ),
    h("div", { className: "tm-verdict-body" },
      v.reasons.length ? h("ul", { className: "tm-vreasons" }, v.reasons.map((r, i) => h("li", { key: i }, h(Icon, { n: "trending-down", size: 16 }), vsay(t, r)))) : null,
      v.strengths.length ? h("ul", { className: "tm-vreasons tm-vreasons--good" }, v.strengths.map((r, i) => h("li", { key: i }, h(Icon, { n: "trending-up", size: 16 }), vsay(t, r)))) : null,
    ),
    h(VerdictOptions, { options: v.options, onCoach }),
  );
}

export function Coaching({ person, auto }) {
  const t = useTx("team");
  const [list, setList] = useState(null);
  const [err, setErr] = useState(null);
  const [open, setOpen] = useState(null); // the report shown
  const [busy, setBusy] = useState(false);
  const load = () => api.get("/team-perf/coaching?user=" + person.id).then((d) => { setList(d); setErr(null); }).catch((e) => setErr(errText(e, t("Could not open it"))));
  useEffect(() => { setOpen(null); setList(null); load(); }, [person.id]);
  // "Coach on X" (the verdict's option): make a report now and show it
  const box = useRef(null);
  useEffect(() => { if (auto) { if (box.current) box.current.scrollIntoView({ behavior: "smooth", block: "start" }); if (!busy) make(); } }, [auto]);
  const make = () => {
    setBusy(true);
    api.post("/team-perf/coaching?user=" + person.id, {})
      .then((r) => { setOpen(r); setBusy(false); load(); toast(r.kind === "ai" ? t("The coaching report is ready (AI)") : t("The coaching report is ready (rules)"), "good"); })
      .catch((e) => { setBusy(false); toast(errText(e, t("Could not make the report")), "bad"); });
  };
  const show = (id) => api.get("/team-perf/coaching/" + id).then(setOpen).catch((e) => toast(errText(e, t("Could not open it")), "bad"));
  const first = person.name.split(" ")[0];
  return h(
    "section",
    { className: "tm-card tm-coach", ref: box },
    h("div", { className: "tm-coach-head" },
      h("div", null,
        h("h3", null, h(Icon, { n: "wand-stars", size: 18 }), " ", t("Coaching report")),
        h("small", null, person.self ? t("A report in your language: what goes well, what to improve, a 30-day plan with named customers and where to explore and grow.") : t("A report for {name}: what goes well, what to improve, a 30-day plan with named customers and where to explore and grow.", { name: first })),
      ),
      h("button", { type: "button", className: "tc-btn tc-btn--md tm-coach-go", onClick: make, disabled: busy }, h(Icon, { n: busy ? "hourglass-empty" : "wand-stars", size: 18 }), busy ? t("Writing the report…") : t("Coaching report")),
    ),
    list && list.ai && h("p", { className: "tm-muted tm-small" }, h(Icon, { n: "info", size: 14 }), " ", t("The AI is not available now ({why}): the report is written by rules from the same facts.", { why: t(list.ai === "nokey" ? "no AI key" : list.ai === "limit" ? "daily limit used" : "switched off or over its limit") })),
    err && h("p", { className: "error-text" }, err),
    busy && !open && h(Skel, { height: 160 }),
    open && h(Report, { r: open, person, mailbox: list ? list.mailbox : null, hasEmail: list ? list.person.email : true, onClose: () => setOpen(null), onSent: load }),
    list && list.reports.length > 0 && h(
      "div",
      { className: "tm-coach-list" },
      h("b", null, t("Earlier reports")),
      h("ul", null, list.reports.map((r) => h("li", { key: r.id },
        h("button", { type: "button", className: cx("tm-link", open && open.id === r.id && "is-on"), onClick: () => show(r.id) }, when(r.created_at)),
        h("span", { className: cx("tm-pill", r.kind === "ai" ? "tm-pill--ai" : "") }, r.kind === "ai" ? t("AI") : t("Rules")),
        r.by_name ? h("small", { className: "tm-muted" }, t("by {n}", { n: r.by_name })) : null,
        r.sent_at ? h("small", { className: "tm-muted" }, h(Icon, { n: "mark-email-read", size: 14 }), " " + t("sent {d}", { d: when(r.sent_at) })) : null,
      ))),
    ),
    list && !list.reports.length && !open && !busy && h("p", { className: "tm-muted tm-small" }, t("No report yet. The first one takes a few seconds.")),
  );
}

function Metrics({ list, team }) {
  if (!list || !list.length) return null;
  return h("span", { className: "tm-mets" }, list.map((m) => h("span", { key: m.key, className: "tm-met" }, m.label, ": ", h("b", null, m.value), m.team ? h("small", null, " · " + (team || "team") + " " + m.team) : null)));
}
function Items({ items, numbered, team }) {
  const t = useTx("team");
  return h(numbered ? "ol" : "ul", { className: "tm-items" }, items.map((it, i) => h("li", { key: i },
    h("span", null, it.text),
    (it.customers.length > 0 || it.countries.length > 0) && h("span", { className: "tm-a-items" },
      it.customers.map((c) => (c.link ? h(Link, { key: c.id, to: c.link, className: "tm-chip" }, c.name) : h("span", { key: c.id, className: "tm-chip tm-chip--peek" }, h(Icon, { n: "visibility", size: 14 }), c.name))),
      it.countries.map((c) => h(Link, { key: c.name, to: c.sprint, className: "tm-chip tm-chip--country", title: t("Start a sprint in {c}", { c: c.name }) }, h(Icon, { n: "public", size: 14 }), c.name))),
    h(Metrics, { list: it.metrics, team }),
  )));
}

function Report({ r, person, mailbox, hasEmail, onClose, onSent }) {
  const t = useTx("team");
  const [facts, setFacts] = useState(false);
  const [ask, setAsk] = useState(false);
  const [sending, setSending] = useState(false);
  const w = r.words || {};
  const pdf = () => {
    let mode = "manager"; try { mode = localStorage.getItem("tece-view-mode") === "sales" ? "sales" : "manager"; } catch { /* default */ }
    fetch("/api/team-perf/coaching/" + r.id + "/pdf", { credentials: "include", headers: { "X-View-Mode": mode } })
      .then((res) => { if (!res.ok) throw new Error(t("Could not make the PDF")); return res.blob(); })
      .then((b) => { const u = URL.createObjectURL(b); const a = document.createElement("a"); a.href = u; a.download = (w.title || "Coaching report") + " " + person.name + " " + r.createdAt.slice(0, 10) + ".pdf"; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 4000); })
      .catch((e) => toast(e.message, "bad"));
  };
  const send = () => {
    setSending(true);
    api.post("/team-perf/coaching/" + r.id + "/send", {})
      .then((x) => { setSending(false); setAsk(false); toast(x.test ? t("Test mode: sent to {to}", { to: x.to }) : t("Sent to {to}", { to: x.to }), "good"); onSent(); })
      .catch((e) => { setSending(false); toast(errText(e, t("Could not send it")), "bad"); });
  };
  const sec = (title, items, numbered) => items && items.length ? h("div", { className: "tm-rsec" }, h("h4", null, title), h(Items, { items, numbered, team: w.team })) : null;
  return h(
    "article",
    { className: "tm-report" },
    h("div", { className: "tm-report-head" },
      h("div", null,
        h("span", { className: cx("tm-pill", r.kind === "ai" ? "tm-pill--ai" : "") }, h(Icon, { n: r.kind === "ai" ? "wand-stars" : "rule", size: 14 }), " ", r.kind === "ai" ? t("AI") : t("Rules")),
        h("small", { className: "tm-muted" }, " ", r.label, " · ", when(r.createdAt)),
      ),
      h("div", { className: "tm-report-tools" },
        h("button", { type: "button", className: "tc-btn tc-btn--secondary tc-btn--sm", onClick: pdf }, h(Icon, { n: "download", size: 16 }), t("PDF")),
        !person.self && h("button", { type: "button", className: "tc-btn tc-btn--secondary tc-btn--sm", onClick: () => setAsk(true), disabled: !!mailbox || !hasEmail, title: mailbox ? t(mailbox) : !hasEmail ? t("No e-mail address") : undefined }, h(Icon, { n: "send", size: 16 }), t("Send to {n}", { n: person.name.split(" ")[0] })),
        h("button", { type: "button", className: "tc-btn tc-btn--ghost tc-btn--sm", onClick: onClose, "aria-label": t("Close") }, h(Icon, { n: "close", size: 16 })),
      ),
    ),
    !person.self && mailbox && h("p", { className: "tm-note" }, h(Icon, { n: "info", size: 16 }), t(mailbox)),
    ask && h("div", { className: "tm-confirm", role: "alertdialog", "aria-label": t("Send the report") },
      h("span", null, t("E-mail this report as a PDF to {n}? It goes from the company mailbox (in test mode to the test address).", { n: person.name })),
      h("button", { type: "button", className: "tc-btn tc-btn--sm", onClick: send, disabled: sending }, h(Icon, { n: "send", size: 16 }), sending ? t("Sending…") : t("Send it")),
      h("button", { type: "button", className: "tc-btn tc-btn--ghost tc-btn--sm", onClick: () => setAsk(false) }, t("Cancel")),
    ),
    r.facts && r.facts.verdict ? h("div", { className: "tm-rsec tm-rverdict" },
      h("h4", null, t("Verdict"), " ", h(VerdictPill, { status: r.facts.verdict.status })),
      r.facts.verdict.reasons.length ? h("ul", { className: "tm-vreasons" }, r.facts.verdict.reasons.map((x, i) => h("li", { key: i }, h(Icon, { n: "trending-down", size: 16 }), vsay(t, x)))) : null,
      r.facts.verdict.strengths.length ? h("ul", { className: "tm-vreasons tm-vreasons--good" }, r.facts.verdict.strengths.map((x, i) => h("li", { key: i }, h(Icon, { n: "trending-up", size: 16 }), vsay(t, x)))) : null,
      h(VerdictOptions, { options: (r.facts.verdict.options || []).filter((o) => o.action !== "coach") }),
    ) : null,
    h("div", { className: "tm-rsec tm-rsum" }, h("h4", null, w.summary || t("Summary")), h("p", null, r.summary.text), h(Metrics, { list: r.summary.metrics, team: w.team })),
    h("div", { className: "tm-rcols" }, sec(w.strengths, r.strengths), sec(w.improve, r.improve)),
    sec(w.plan30, r.plan30, true),
    sec(w.explore, r.explore),
    h("button", { type: "button", className: "tm-link tm-facts-btn", "aria-expanded": facts, onClick: () => setFacts(!facts) }, h(Icon, { n: facts ? "keyboard-arrow-up" : "keyboard-arrow-down", size: 16 }), w.facts || t("The facts used")),
    facts && h("table", { className: "tm-facts" }, h("tbody", null, r.metrics.map((m) => h("tr", { key: m.key }, h("th", { scope: "row" }, m.label), h("td", { className: "num" }, m.value), h("td", { className: "num tm-muted" }, m.team ? (w.team || "team") + " " + m.team : ""))))),
  );
}
