import { db } from '../db/connection';
import seed from '../data/boardBrands.json';

// The board producers: the list of the user's file is loaded once; an admin can add more.
export interface Brand { id: number; name: string }

export function ensureBrands(): void {
  const n = (db.prepare('SELECT COUNT(*) AS n FROM board_brands').get() as { n: number }).n;
  if (n > 0) return;
  const ins = db.prepare('INSERT OR IGNORE INTO board_brands (name) VALUES (?)');
  db.exec('BEGIN');
  try { for (const name of seed as string[]) ins.run(name); db.exec('COMMIT'); } catch (err) { db.exec('ROLLBACK'); throw err; }
}

export const listBrands = (): Brand[] => { ensureBrands(); return db.prepare('SELECT id, name FROM board_brands ORDER BY name COLLATE NOCASE').all() as unknown as Brand[]; };
export const boardsOf = (cardId: number): Brand[] => db.prepare('SELECT b.id, b.name FROM card_boards cb JOIN board_brands b ON b.id = cb.brand_id WHERE cb.card_id = ? ORDER BY b.name COLLATE NOCASE').all(cardId) as unknown as Brand[];

export function addBrand(name: string): Brand | null {
  const clean = name.trim().slice(0, 80);
  if (!clean) return null;
  ensureBrands();
  db.prepare('INSERT OR IGNORE INTO board_brands (name) VALUES (?)').run(clean);
  return db.prepare('SELECT id, name FROM board_brands WHERE name = ?').get(clean) as unknown as Brand;
}

export function setBoards(cardId: number, brandIds: number[]): Brand[] {
  const ids = [...new Set(brandIds.filter((n) => Number.isInteger(n)))].slice(0, 60);
  db.exec('BEGIN');
  try {
    db.prepare('DELETE FROM card_boards WHERE card_id = ?').run(cardId);
    const ins = db.prepare('INSERT OR IGNORE INTO card_boards (card_id, brand_id) SELECT ?, id FROM board_brands WHERE id = ?');
    for (const id of ids) ins.run(cardId, id);
    db.exec('COMMIT');
  } catch (err) { db.exec('ROLLBACK'); throw err; }
  return boardsOf(cardId);
}
