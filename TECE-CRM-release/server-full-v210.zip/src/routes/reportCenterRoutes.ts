import { Router, type Response, type NextFunction } from 'express';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { hasReports } from '../services/permissions';
import { turqData, turqualityWorkbook, customerListWorkbook } from '../services/salesReports';

// The Excel reports (Turquality, customer list). Off for everybody until an admin switches "Reports" on for a person (Admin → Permissions); an admin always has it.
const router = Router();
router.use(requireAuth);
router.use((req: AuthedRequest, res: Response, next: NextFunction) => {
  if (!hasReports(req.user as never)) return res.status(403).json({ error: 'The reports are not switched on for you.' });
  next();
});
const fail = (res: Response, err: unknown, code = 400) => res.status(code).json({ error: err instanceof Error ? err.message : String(err) });
const scopeOf = (v: unknown): 'export' | 'all' => (v === 'all' ? 'all' : 'export');
const xlsx = (res: Response, name: string, buf: Buffer) => {
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', `attachment; filename="${name}"`);
  res.send(buf);
};

router.get('/turquality', (req, res) => { try { res.json(turqData(Number(req.query.year) || null, scopeOf(req.query.scope))); } catch (e) { console.error('Turquality report failed:', e); fail(res, e); } });
router.get('/turquality.xlsx', async (req, res) => {
  try { const t = turqData(Number(req.query.year) || null, scopeOf(req.query.scope)); if (!t.ready) throw new Error(t.message || 'No data'); xlsx(res, `Turquality-${t.year}.xlsx`, await turqualityWorkbook(t)); } catch (e) { fail(res, e); }
});
// the customer list in Sena's template: the customers the person may see (an admin: also the old SAP accounts that have no card yet)
router.get('/customer-list.xlsx', async (req: AuthedRequest, res) => {
  try {
    const u = req.user! as typeof req.user & { perms?: { money: string[]; menu: string[] } | null }; const admin = u.role === 'admin';
    const money = admin || !!u.perms?.money.includes('ledger') || !!u.perms?.menu.includes('intel');
    const buf = await customerListWorkbook({ id: u.id, role: u.role, display_name: u.display_name, market: u.market }, { includeSapOnly: String(req.query.sapOnly ?? '') === '1', money });
    xlsx(res, `Musteri-Listesi-${new Date().toISOString().slice(0, 10)}.xlsx`, buf);
  } catch (e) { console.error('Customer list failed:', e); fail(res, e); }
});

export default router;
