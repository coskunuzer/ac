import { niceName } from '../services/niceName';
import { db } from '../db/connection';
import { memoTablesBy } from '../db/dataVersion';
import type { ExtractedCardFields, FieldStatusMap } from '../schema/cardSchema';
import { detectInterest, interestOf, sanitiseProducts, sanitiseWidths } from '../services/interest';
import { canonicalCountry } from './countryModel';
import { filterVisible, visibilitySql, type Viewer } from '../services/visibility';
import { resolveCity } from '../data/turkeyPlaces';
import { companyKey } from '../services/companyKey';
import { isLang } from '../services/translate';
import type { AiInsight } from '../services/aiInsight';
import { logAi } from '../services/aiLog';

export interface CardRow {
  id: number;
  exhibition_id: number;
  uploaded_by: number;
  image_path: string;
  name: string | null;
  company: string | null;
  address: string | null;
  // where the customer is on the map (trips): see services/geocode.ts
  lat?: number | null;
  lon?: number | null;
  geo_source?: string | null;
  geo_place?: string | null;
  country: string | null;
  tel: string | null;
  email: string | null;
  // the visitor's job title
  position: string | null;
  // the tick "send this customer an offer": null = not decided (the AI's suggestion shows), 1 = yes, 0 = no
  send_offer: number | null;
  // why no offer is sent (already sent before, too small ...)
  offer_skip_reason: string | null;
  // pass this contact to the Bulgaria office: null = not decided, 1 = yes, 0 = no
  bulgaria: number | null;
  // when the details were e-mailed to the Bulgaria office
  bulgaria_sent_at: string | null;
  // the offer design for this customer ('' = the sender's / the company's), where they are in the pipeline,
  // their web site, and what the lead database knew about them (JSON)
  offer_style: string | null;
  stage: string | null;
  website: string | null;
  last_name: string | null;
  lead_info: string | null;
  // 'export' (a country's customer) or 'domestic' (a customer in Turkey, looked after by city)
  market: 'export' | 'domestic';
  city: string | null;
  // the AI's rating (0-10) and why; 'ai' or a quick estimate from the rules ('rules')
  ai_rate: number | null;
  ai_rate_reason: string | null;
  ai_rate_source: string | null;
  ai_rated_at: string | null;
  // the company name boiled down, to find the same company twice
  company_key: string | null;
  // the language of the offer and e-mail to this customer (en ru tr es fr), and how we got to know them
  language: string | null;
  source: string | null;
  // the sales pipeline (see services/pipeline.ts)
  pipeline_stage: number | null;
  exit_status: string | null;
  exit_reason: string | null;
  exit_note: string | null;
  follow_up_date: string | null;
  lead_source: string | null;
  handling: string | null;
  rate_auto: number;
  // the group of the uploaded customer database: existing | reachable | no_contact; and what the web-site search found: found | none
  contact_group: string | null;
  website_check: string | null;
  interested_in: string | null;
  // ticked products / other text / edge widths (JSON) - see services/interest.ts
  interest_products: string | null;
  interest_other: string | null;
  interest_widths: string | null;
  // discount (-) or addition (+) agreed with the customer, as a fraction; null = list price
  offer_percent: number | null;
  // this customer's folder under data/customer-files (relative path)
  archive_dir: string | null;
  // visitor ID in a badge-scanner export (null for scanned forms)
  badge_id: string | null;
  // what the AI made of the notes (JSON, see services/aiInsight.ts)
  ai_insight: string | null;
  work_area: string | null;
  fair: string | null;
  form_date: string | null;
  person: string | null;
  // 1 = given to somebody other than the usual person of the country (or city): only that person sees it (services/ownership.ts)
  owner_override: number;
  // what the AI found on the web about the company (JSON, services/companyCheck.ts)
  company_check: string | null;
  // SAP customer number; mobile (WhatsApp) and fax - tel is the ordinary telephone
  sap: string | null;
  mobile: string | null;
  fax: string | null;
  // the company scoring (v12): JSON, services/companyScoring.ts
  company_score: string | null;
  rate: number | null;
  notes: string | null;
  field_status: string;
  extraction_model: string | null;
  extraction_error: string | null;
  status: 'needs_review' | 'confirmed';
  thank_you_sent_at: string | null;
  created_at: string;
  delete_locked?: number;
  updated_at: string;
}

export interface CardUpdateInput {
  name?: string | null;
  lastName?: string | null;
  company?: string | null;
  address?: string | null;
  country?: string | null;
  tel?: string | null;
  mobile?: string | null;
  fax?: string | null;
  sap?: string | null;
  email?: string | null;
  position?: string | null;
  sendOffer?: boolean | null;
  offerSkipReason?: string | null;
  offerStyle?: string | null;
  stage?: string | null;
  website?: string | null;
  city?: string | null;
  market?: string | null;
  language?: string | null;
  source?: string | null;
  bulgaria?: boolean | null;
  interestedIn?: string | null;
  interestProducts?: string[];
  interestOther?: string | null;
  interestWidths?: number[];
  offerPercent?: number | null;
  workArea?: string | null;
  formDate?: string | null;
  person?: string | null;
  rate?: number | null;
  notes?: string | null;
  status?: 'needs_review' | 'confirmed';
}

// -90 % .. +500 %, the same limits as an offer; 0 or nothing means list price.
function clampPercent(value: unknown): number | null {
  const n = typeof value === 'number' ? value : parseFloat(String(value));
  if (!Number.isFinite(n) || n === 0) return null;
  return Math.round(Math.min(5, Math.max(-0.9, n)) * 10000) / 10000;
}

// What the AI read from the form decides which products start ticked.
function interestColumns(f: ExtractedCardFields, insight?: AiInsight | null) {
  const found = detectInterest({ interestedIn: f.interestedIn, workArea: f.workArea, notes: f.notes });
  const products = [...new Set([...found.products, ...(insight?.products ?? [])])];
  const widths = [...new Set([...found.widths, ...(insight?.widths ?? [])])].sort((a, b) => a - b);
  return {
    interestProducts: JSON.stringify(sanitiseProducts(products)),
    interestOther: found.other || insight?.otherInterest || null,
    interestWidths: JSON.stringify(sanitiseWidths(widths)),
  };
}

// Where a customer is in the pipeline (NULL = met at a fair).
export const STAGES = new Set(['lead', 'contacted', 'interested', 'quoted', 'customer', 'lost']);
// How we got to know a customer (they are not always met at a fair).
// The four kinds of customer of the Customers page.
//  - exhibition: met at a fair or exhibition (not from an uploaded database)
//  - important: existing customers and hot deals (a step of Interested / Quoted, or a rating of 5 or more)
//  - leads ("just leads"): everybody else that has no web site and no e-mail, or that nobody - neither a person nor the AI - has rated yet
// The rating that counts is the person's own, and when there is none the AI's - but only a real AI rating (Gemini read the company),
// not the quick estimate every customer gets from the rules, so "not rated yet" stays meaningful.
export const SQL_RATING = "COALESCE(rate, CASE WHEN ai_rate_source = 'ai' THEN ai_rate END)";
const IMPORTED_MODELS = "('lead-database', 'domestic-list', 'customer-database')";
// A lead that may be cleaned up after the AI looked at it: it comes from the uploaded database (never a fair, never a customer who
// buys from us) and it had neither an e-mail nor a web site when it came in.
export const SQL_CLEANABLE = `(COALESCE(extraction_model, '') IN ${IMPORTED_MODELS} AND COALESCE(stage, '') != 'customer' AND (contact_group = 'no_contact' OR json_extract(company_check, '$.wasNoContact') = 1))`;
export const SQL_VERDICT = "json_extract(company_check, '$.verdict')";
export const SQL_EXHIBITION = `((source IS NULL OR source = 'fair') AND COALESCE(extraction_model, '') NOT IN ${IMPORTED_MODELS})`;
export const SQL_IMPORTANT = `(stage = 'customer' OR stage IN ('interested', 'quoted') OR COALESCE(${SQL_RATING}, 0) >= 5)`;
// existing customers nobody has been in touch with (or sent anything) for 90 days
const TOUCH = "('note', 'call', 'visit', 'meeting', 'sample', 'offer', 'thank_you', 'documents', 'email')";
export const SQL_REACTIVATE = `(stage = 'customer' AND NOT EXISTS (SELECT 1 FROM activities a WHERE a.card_id = cards.id AND a.type IN ${TOUCH} AND a.created_at >= datetime('now', '-90 days')))`;
export const SQL_LEADS = `((stage IS NULL OR stage IN ('lead', 'contacted')) AND COALESCE(${SQL_RATING}, 0) < 5 AND (((email IS NULL OR email = '') AND (website IS NULL OR website = '')) OR ${SQL_RATING} IS NULL))`;

// the same rule for one customer already read from the database
export function isJustLead(card: Pick<CardRow, 'stage' | 'rate' | 'ai_rate' | 'ai_rate_source' | 'email' | 'website'>): boolean {
  if (card.stage && !['lead', 'contacted'].includes(card.stage)) return false;
  const rating = card.rate ?? (card.ai_rate_source === 'ai' ? card.ai_rate : null);
  if (rating !== null && rating !== undefined && rating >= 5) return false;
  const noContact = !(card.email ?? '').trim() && !(card.website ?? '').trim();
  return noContact || rating === null || rating === undefined;
}

export const SOURCES = new Set(['fair', 'visit', 'email', 'call', 'website', 'referral', 'database', 'other']);

const keptCard = memoTablesBy(['cards'], (id: number) => db.prepare('SELECT * FROM cards WHERE id = ?').get(id) as CardRow | undefined, 4000);

export const cardModel = {
  createFromExtraction(input: {
    exhibitionId: number;
    uploadedBy: number;
    imagePath: string;
    fields: ExtractedCardFields;
    fieldStatus: FieldStatusMap;
    extractionModel: string;
    extractionError?: string | null;
    status?: 'needs_review' | 'confirmed';
    badgeId?: string | null;
    insight?: AiInsight | null;
    stage?: string | null;
    website?: string | null;
    leadInfo?: Record<string, unknown> | null;
    market?: string | null;
    city?: string | null;
    language?: string | null;
    source?: string | null;
    contactGroup?: string | null;
    sap?: string | null;
    mobile?: string | null;
    fax?: string | null;
  }): CardRow {
    const f = input.fields;
    const result = db
      .prepare(
        `INSERT INTO cards
         (exhibition_id, uploaded_by, image_path, name, company, address, country, tel, email,
          interested_in, interest_products, interest_other, interest_widths, work_area, form_date, person, rate, notes, field_status, extraction_model, extraction_error, status, badge_id, ai_insight, offer_percent, position, stage, website, lead_info, market, city, company_key, language, source, contact_group)
         VALUES (@exhibitionId, @uploadedBy, @imagePath, @name, @company, @address, @country, @tel, @email,
          @interestedIn, @interestProducts, @interestOther, @interestWidths, @workArea, @formDate, @person, @rate, @notes, @fieldStatus, @extractionModel, @extractionError, @status, @badgeId, @aiInsight, @offerPercent, @position, @stage, @website, @leadInfo, @market, @city, @companyKey, @language, @source, @contactGroup)`
      )
      .run({
        exhibitionId: input.exhibitionId,
        uploadedBy: input.uploadedBy,
        imagePath: input.imagePath,
        name: f.name,
        company: f.company,
        address: f.address,
        country: canonicalCountry(f.country) as string | null,
        tel: f.tel,
        email: f.email,
        interestedIn: f.interestedIn,
        ...interestColumns(f, input.insight),
        workArea: f.workArea,
        formDate: f.date,
        person: f.person,
        rate: f.rate,
        notes: f.notes,
        fieldStatus: JSON.stringify(input.fieldStatus),
        extractionModel: input.extractionModel,
        extractionError: input.extractionError ?? null,
        status: input.status ?? 'needs_review',
        badgeId: input.badgeId ?? null,
        position: f.position ?? null,
        stage: input.stage ?? null,
        website: input.website ?? null,
        market: input.market === 'domestic' ? 'domestic' : 'export',
        city: input.market === 'domestic' ? resolveCity(input.city).city : null,
        companyKey: companyKey(f.company),
        contactGroup: input.contactGroup === 'existing' || input.contactGroup === 'reachable' || input.contactGroup === 'no_contact' ? input.contactGroup : null,
        language: isLang(input.language) ? input.language : null,
        source: typeof input.source === 'string' && SOURCES.has(input.source) ? input.source : null,
        leadInfo: input.leadInfo ? JSON.stringify(input.leadInfo) : null,
        aiInsight: input.insight ? JSON.stringify(input.insight) : null,
        // a discount that was promised in the notes starts the offer
        offerPercent: input.insight?.discountPercent ? clampPercent(input.insight.discountPercent / 100) : null,
      });
    const id = result.lastInsertRowid as number;
    if (input.sap || input.mobile || input.fax) db.prepare('UPDATE cards SET sap = ?, mobile = ?, fax = ? WHERE id = ?').run(input.sap ?? null, input.mobile ?? null, input.fax ?? null, id);
    return this.findById(id)!;
  },

  // A visitor already imported from a badge export into this exhibition.
  findByBadge(exhibitionId: number, badgeId: string): CardRow | undefined {
    return db.prepare('SELECT * FROM cards WHERE exhibition_id = ? AND badge_id = ?').get(exhibitionId, badgeId) as CardRow | undefined;
  },

  // Used by the "Retry AI extraction" action - re-runs extraction against
  // the already-stored photo and overwrites the AI-derived fields in place
  // (rather than creating a duplicate record). Resets status to
  // 'needs_review' since it's fresh, unreviewed data.
  applyExtraction(
    id: number,
    input: {
      fields: ExtractedCardFields;
      fieldStatus: FieldStatusMap;
      extractionModel: string;
      extractionError: string | null;
      insight?: AiInsight | null;
    }
  ): CardRow | undefined {
    const f = input.fields;
    db.prepare(
      `UPDATE cards SET
        name = @name, company = @company, company_key = @companyKey, address = @address, country = @country, tel = @tel, email = @email, position = @position,
        interested_in = @interestedIn, interest_products = @interestProducts, interest_other = @interestOther,
        interest_widths = @interestWidths, work_area = @workArea, form_date = @formDate, person = @person,
        rate = @rate, notes = @notes, field_status = @fieldStatus, extraction_model = @extractionModel,
        extraction_error = @extractionError, ai_insight = @aiInsight, status = 'needs_review', updated_at = datetime('now')
       WHERE id = @id`
    ).run({
      id,
      name: f.name,
      company: f.company,
      address: f.address,
      country: canonicalCountry(f.country) as string | null,
      tel: f.tel,
      email: f.email,
      position: f.position ?? null,
      interestedIn: f.interestedIn,
      ...interestColumns(f, input.insight),
      aiInsight: input.insight ? JSON.stringify(input.insight) : null,
      workArea: f.workArea,
      formDate: f.date,
      person: f.person,
      rate: f.rate,
      notes: f.notes,
      fieldStatus: JSON.stringify(input.fieldStatus),
      extractionModel: input.extractionModel,
      extractionError: input.extractionError,
    });
    return this.findById(id);
  },

  setExtractionError(id: number, error: string): void {
    db.prepare("UPDATE cards SET extraction_error = @error, updated_at = datetime('now') WHERE id = @id").run({
      id,
      error,
    });
  },

  // Asked again and again while one page is put together (may this person see it? what is its name?): the last few thousand customers that were
  // read are kept until any customer is written (the database wrapper reports that the moment it happens). Every caller gets its own copy.
  findById(id: number): CardRow | undefined {
    const row = keptCard(id);
    return row ? { ...row } : undefined;
  },

  update(id: number, input: CardUpdateInput): CardRow | undefined {
    const existing = this.findById(id);
    if (!existing) return undefined;
    db.prepare(
      `UPDATE cards SET
        name = @name, last_name = @lastName, company = @company, company_key = @companyKey, address = @address, country = @country, tel = @tel, mobile = @mobile, fax = @fax, sap = @sap, email = @email,
        position = @position, send_offer = @sendOffer, offer_skip_reason = @offerSkipReason, bulgaria = @bulgaria,
        offer_style = @offerStyle, stage = @stage, website = @website, city = @city, market = @market, language = @language, source = @source,
        interested_in = @interestedIn, interest_products = @interestProducts, interest_other = @interestOther,
        interest_widths = @interestWidths, offer_percent = @offerPercent, work_area = @workArea, form_date = @formDate, person = @person,
        rate = @rate, rate_auto = @rateAuto, notes = @notes, status = @status, updated_at = datetime('now')
       WHERE id = @id`
    ).run({
      // a rating the person typed or changed is theirs; the same number as the AI's copy stays "automatic"
      rateAuto: input.rate !== undefined && input.rate !== existing.rate ? 0 : existing.rate_auto ?? 0,
      id,
      name: niceName(input.name ?? existing.name, true),
      lastName: input.lastName === undefined ? existing.last_name : (input.lastName ?? '').trim().slice(0, 120) || null,
      company: niceName(input.company ?? existing.company),
      companyKey: companyKey(input.company ?? existing.company),
      address: input.address ?? existing.address,
      country: canonicalCountry(input.country ?? existing.country) as string | null,
      tel: input.tel === undefined ? existing.tel : (input.tel ?? '').trim().slice(0, 120) || null,
      mobile: input.mobile === undefined ? existing.mobile : (input.mobile ?? '').trim().slice(0, 120) || null,
      fax: input.fax === undefined ? existing.fax : (input.fax ?? '').trim().slice(0, 120) || null,
      sap: input.sap === undefined ? existing.sap : (input.sap ?? '').trim().slice(0, 40) || null,
      email: input.email ?? existing.email,
      position: input.position === undefined ? existing.position : (input.position ?? '').trim().slice(0, 120) || null,
      sendOffer: input.sendOffer === undefined ? existing.send_offer : input.sendOffer === null ? null : input.sendOffer ? 1 : 0,
      offerStyle: input.offerStyle === undefined ? existing.offer_style : input.offerStyle === 'tece' || input.offerStyle === 'classic' ? input.offerStyle : null,
      stage: input.stage === undefined ? existing.stage : STAGES.has(String(input.stage)) ? String(input.stage) : null,
      website: input.website === undefined ? existing.website : (input.website ?? '').trim().slice(0, 200) || null,
      market: input.market === undefined ? existing.market : input.market === 'domestic' ? 'domestic' : 'export',
      language: input.language === undefined ? existing.language : isLang(input.language) ? input.language : null,
      source: input.source === undefined ? existing.source : typeof input.source === 'string' && SOURCES.has(input.source) ? input.source : null,
      city: input.city === undefined ? existing.city : resolveCity(input.city).city,
      offerSkipReason: input.offerSkipReason === undefined ? existing.offer_skip_reason : (input.offerSkipReason ?? '').trim().slice(0, 200) || null,
      bulgaria: input.bulgaria === undefined ? existing.bulgaria : input.bulgaria === null ? null : input.bulgaria ? 1 : 0,
      interestedIn: input.interestedIn ?? existing.interested_in,
      interestProducts: input.interestProducts === undefined ? existing.interest_products : JSON.stringify(sanitiseProducts(input.interestProducts)),
      interestOther: input.interestOther === undefined ? existing.interest_other : (input.interestOther ?? '').trim().slice(0, 300) || null,
      offerPercent: input.offerPercent === undefined ? existing.offer_percent : clampPercent(input.offerPercent),
      interestWidths: input.interestWidths === undefined ? existing.interest_widths : JSON.stringify(sanitiseWidths(input.interestWidths)),
      workArea: input.workArea ?? existing.work_area,
      formDate: input.formDate ?? existing.form_date,
      person: input.person ?? existing.person,
      rate: input.rate === undefined ? existing.rate : input.rate,
      notes: input.notes ?? existing.notes,
      status: input.status ?? existing.status,
    });
    return this.findById(id);
  },

  // Work area filled from what was found out about the company (only ever when it was empty).
  setWorkAreaGuess(id: number, text: string): void {
    const row = this.findById(id);
    if (!row || (row.work_area ?? '').trim()) return;
    const status = JSON.parse(row.field_status || '{}');
    status.workArea = 'uncertain';
    db.prepare("UPDATE cards SET work_area = ?, field_status = ?, updated_at = datetime('now') WHERE id = ?").run(text, JSON.stringify(status), id);
  },

  // Adds the products / widths the AI found to the ticked ones (nothing is ever unticked).
  mergeInterest(id: number, products: string[], widths: number[]): void {
    const row = this.findById(id);
    if (!row) return;
    const have = interestOf(row);
    const nextProducts = [...new Set([...have.products, ...products])];
    const nextWidths = [...new Set([...have.widths, ...widths])].sort((a, b) => a - b);
    db.prepare('UPDATE cards SET interest_products = ?, interest_widths = ? WHERE id = ?').run(
      JSON.stringify(sanitiseProducts(nextProducts)),
      JSON.stringify(sanitiseWidths(nextWidths)),
      id
    );
  },

  // The responsible person, only when nobody is set yet.
  setPersonIfEmpty(id: number, person: string): void {
    db.prepare("UPDATE cards SET person = ? WHERE id = ? AND (person IS NULL OR TRIM(person) = '')").run(person, id);
  },

  setInsight(id: number, insight: AiInsight | null): void {
    db.prepare('UPDATE cards SET ai_insight = ? WHERE id = ?').run(insight ? JSON.stringify(insight) : null, id);
  },

  setImagePath(id: number, imagePath: string): void {
    db.prepare('UPDATE cards SET image_path = ? WHERE id = ?').run(imagePath, id);
  },

  setArchiveDir(id: number, archiveDir: string | null): void {
    db.prepare('UPDATE cards SET archive_dir = ? WHERE id = ?').run(archiveDir, id);
  },

  // `log: false` when the caller writes its own line in the customer's history (the AI rating is written there when the AI did it)
  setAiRate(id: number, rate: number, reason: string | null, source: 'ai' | 'rules' | 'person', opts: { log?: boolean } = {}): void {
    const value = Math.max(0, Math.min(10, Math.round(rate)));
    db.prepare("UPDATE cards SET ai_rate = ?, ai_rate_reason = ?, ai_rate_source = ?, ai_rated_at = datetime('now') WHERE id = ?").run(value, reason ? reason.slice(0, 200) : null, source, id);
    // nobody rated this customer: the AI's number is shown as the rating too (and follows the AI) until a person gives their own
    if (source === 'ai') db.prepare('UPDATE cards SET rate = ?, rate_auto = 1 WHERE id = ? AND (rate IS NULL OR rate_auto = 1)').run(value, id);
    if (source === 'ai' && opts.log !== false) logAi(id, `AI rating ${value}/10${reason ? ` - ${reason.slice(0, 200)}` : ''}`);
  },

  // Fills company_key for records written before it existed (a few thousand at a time, once).
  backfillCompanyKeys(): number {
    const rows = db.prepare("SELECT id, company FROM cards WHERE company_key IS NULL AND company IS NOT NULL AND company != ''").all() as { id: number; company: string }[];
    if (!rows.length) return 0;
    const set = db.prepare('UPDATE cards SET company_key = ? WHERE id = ?');
    db.exec('BEGIN');
    try {
      for (const r of rows) {
        const k = companyKey(r.company);
        if (k) set.run(k, r.id);
      }
      db.exec('COMMIT');
    } catch (err) {
      db.exec('ROLLBACK');
      throw err;
    }
    return rows.length;
  },

  markBulgariaSent(id: number): void {
    db.prepare("UPDATE cards SET bulgaria = 1, bulgaria_sent_at = datetime('now') WHERE id = ?").run(id);
  },

  markThankYouSent(id: number): CardRow | undefined {
    db.prepare("UPDATE cards SET thank_you_sent_at = datetime('now') WHERE id = ?").run(id);
    return this.findById(id);
  },

  delete(id: number): void {
    db.prepare('DELETE FROM cards WHERE id = ?').run(id);
  },

  listByExhibition(exhibitionId: number): CardRow[] {
    return db
      .prepare('SELECT * FROM cards WHERE exhibition_id = ? ORDER BY created_at DESC')
      .all(exhibitionId) as unknown as CardRow[];
  },

  listAll(): CardRow[] {
    return db.prepare('SELECT * FROM cards ORDER BY created_at DESC').all() as unknown as CardRow[];
  },

  search(query: {
    exhibitionId?: number;
    text?: string;
    country?: string;
    // Who is asking: staff only get the customers they may see (see services/visibility.ts).
    visibleTo?: Viewer;
    // leave out the database leads and the domestic customers in the database itself (the fair reports never count them),
    // instead of reading tens of thousands of rows and dropping them afterwards
    fairWork?: boolean;
  }): CardRow[] {
    const clauses: string[] = [];
    const params: Record<string, string | number> = {};
    if (query.fairWork) clauses.push("(stage IS NULL OR stage != 'lead') AND (market IS NULL OR market != 'domestic')");
    // the same rule as a piece of SQL first (so only this person's rows are read), then the rule itself on what came back: the answer is exactly the rule's
    const vis = query.visibleTo ? visibilitySql(query.visibleTo, params) : null;
    if (vis) clauses.push(vis);
    if (query.exhibitionId) {
      clauses.push('exhibition_id = @exhibitionId');
      params.exhibitionId = query.exhibitionId;
    }
    if (query.text) {
      clauses.push('(name LIKE @text OR company LIKE @text OR email LIKE @text OR notes LIKE @text)');
      params.text = `%${query.text}%`;
    }
    if (query.country === '__none') clauses.push("(country IS NULL OR TRIM(country) = '') AND market != 'domestic'");
    else if (query.country) {
      clauses.push('country = @country');
      params.country = query.country;
    }
    const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
    const rows = db.prepare(`SELECT * FROM cards ${where} ORDER BY created_at DESC`).all(params) as unknown as CardRow[];
    return query.visibleTo ? filterVisible(query.visibleTo, rows) : rows;
  },

  // One page of customers for the list, with the filters done in the database - the customer database has
  // tens of thousands of rows. A staff member only gets the customers they may see (services/visibility.ts).
  searchPaged(q: {
    exhibitionId?: number;
    text?: string;
    country?: string;
    person?: string;
    stage?: string;
    status?: string;
    market?: string;
    city?: string;
    group?: string;
    websiteCheck?: string;
    // existing = buys from us; potential = everybody who might (met at a fair, a lead, in conversation, offer sent); lost
    segment?: string;
    source?: string;
    tier?: string;
    thankYou?: 'sent' | 'not';
    offer?: 'sent' | 'not' | 'wanted';
    bulgaria?: boolean;
    hasEmail?: boolean;
    noEmail?: boolean;
    // person's own rating: none = not rated by a person; hot = 5 or more (own, else a real AI rating)
    rated?: 'none' | 'hot';
    // samples (colour cards, sample boxes) sent: missing = an offer went out but no sample
    sample?: 'missing' | 'sent';
    businessType?: string;
    // the board producer (a tag on the customer): Kronospan, Egger ...
    board?: string;
    // what the AI check decided: fit, none (nothing found), unrelated, unsuitable - or unchecked
    verdict?: string;
    // the company scoring (v12): the tier (Hot, Warm, Cold, Disqualified), candidate (no web site) or unscored; the priority P1-P4
    scoreTier?: string;
    priority?: string;
    // what the column headings of the list sort by (the ones with "_desc" run backwards)
    sort?: 'newest' | 'score' | 'company' | 'ai' | 'score_asc' | 'ai_asc' | 'purchase' | 'company_desc' | 'place' | 'place_desc' | 'stage' | 'stage_desc' | 'last_contact' | 'last_contact_desc' | 'next';
    // the customers nobody has worked yet (no note, call, visit, e-mail or offer), or the ones this person has
    touched?: 'none' | 'mine';
    aiMin?: number;
    page: number;
    pageSize: number;
    visibleTo?: Viewer;
  }): { rows: CardRow[]; total: number } {
    const where: string[] = [];
    const params: Record<string, string | number> = {};
    if (q.exhibitionId) { where.push('exhibition_id = @exhibitionId'); params.exhibitionId = q.exhibitionId; }
    if (q.text) {
      // Every word must be found somewhere: in the company, the name of the person, the e-mail, the numbers ... or in one of the other people of the company
      // (name, last name, e-mail, telephone). So "Abdullah", "Abdullah Yilmaz" (name + company) and a colleague's name all find the customer.
      const words = q.text.split(/\s+/).map((w) => w.trim()).filter(Boolean).slice(0, 6);
      words.forEach((w, i) => {
        where.push(`(name LIKE @text${i} OR last_name LIKE @text${i} OR company LIKE @text${i} OR email LIKE @text${i} OR notes LIKE @text${i} OR work_area LIKE @text${i} OR website LIKE @text${i} OR tel LIKE @text${i} OR mobile LIKE @text${i} OR sap LIKE @text${i} OR position LIKE @text${i}
          OR EXISTS (SELECT 1 FROM card_contacts pc WHERE pc.card_id = cards.id AND (pc.name LIKE @text${i} OR pc.last_name LIKE @text${i} OR pc.email LIKE @text${i} OR pc.tel LIKE @text${i} OR pc.mobile LIKE @text${i} OR pc.position LIKE @text${i})))`);
        params[`text${i}`] = `%${w}%`;
      });
    }
    if (q.board) { where.push('EXISTS (SELECT 1 FROM card_boards cb JOIN board_brands bb ON bb.id = cb.brand_id WHERE cb.card_id = cards.id AND bb.name = @board)'); params.board = q.board; }
    if (q.country === '__none') where.push("(country IS NULL OR TRIM(country) = '') AND market != 'domestic'");
    else if (q.country) { where.push('country = @country'); params.country = q.country; }
    if (q.market === 'domestic' || q.market === 'export') where.push(q.market === 'domestic' ? "market = 'domestic'" : "market != 'domestic'");
    if (q.city === '—') where.push("market = 'domestic' AND (city IS NULL OR city = '')");
    else if (q.city) { where.push('city = @city'); params.city = q.city; }
    if (q.person === '—') where.push("(person IS NULL OR person = '')");
    else if (q.person) { where.push('person = @person'); params.person = q.person; }
    if (q.stage === 'visitor') where.push('stage IS NULL');
    else if (q.stage && q.stage.includes(',')) {
      // several stages at once ("contacted,interested,quoted": the people in conversation)
      const list = q.stage.split(',').map((s) => s.trim()).filter(Boolean).slice(0, 8);
      list.forEach((s, i) => { params[`stageIn${i}`] = s; });
      where.push(`stage IN (${list.map((_, i) => `@stageIn${i}`).join(', ')})`);
    }
    else if (q.stage) { where.push('stage = @stage'); params.stage = q.stage; }
    if (q.status) { where.push('status = @status'); params.status = q.status; }
    if (q.segment === 'exhibition') where.push(SQL_EXHIBITION);
    else if (q.segment === 'important') where.push(SQL_IMPORTANT);
    else if (q.segment === 'leads') where.push(SQL_LEADS);
    else if (q.segment === 'reactivate') where.push(SQL_REACTIVATE);
    else if (q.segment === 'existing') where.push("stage = 'customer'");
    else if (q.segment === 'potential') where.push("(stage IS NULL OR stage IN ('lead', 'contacted', 'interested', 'quoted'))");
    else if (q.segment === 'lost') where.push("stage = 'lost'");
    if (q.source && SOURCES.has(q.source)) { where.push('source = @source'); params.source = q.source; }
    if (q.group === 'existing' || q.group === 'reachable' || q.group === 'no_contact') { where.push('contact_group = @group'); params.group = q.group; }
    if (q.websiteCheck === 'none' || q.websiteCheck === 'found') { where.push('website_check = @websiteCheck'); params.websiteCheck = q.websiteCheck; }
    if (q.tier) { where.push("json_extract(lead_info, '$.tier') LIKE @tier"); params.tier = `${q.tier}%`; }
    if (q.aiMin !== undefined && Number.isFinite(q.aiMin)) { where.push('ai_rate >= @aiMin'); params.aiMin = q.aiMin; }
    if (q.hasEmail) where.push("(email IS NOT NULL AND email != '')");
    if (q.noEmail) where.push("(email IS NULL OR email = '')");
    if (q.rated === 'none') where.push('rate IS NULL');
    if (q.rated === 'hot') where.push(`COALESCE(${SQL_RATING}, 0) >= 5`);
    const sampleSent = "EXISTS (SELECT 1 FROM activities s WHERE s.card_id = cards.id AND s.type = 'sample')";
    const offerGone = "EXISTS (SELECT 1 FROM offers_sent o WHERE o.card_id = cards.id AND o.kind = 'offer')";
    if (q.sample === 'sent') where.push(sampleSent);
    if (q.sample === 'missing') where.push(`${offerGone} AND NOT ${sampleSent}`);
    if (q.verdict === 'unchecked') where.push('company_check IS NULL');
    else if (['fit', 'none', 'unrelated', 'unsuitable'].includes(q.verdict ?? '')) { where.push(`${SQL_VERDICT} = @verdict`); params.verdict = q.verdict!; }
    if (['Hot', 'Warm', 'Cold', 'Disqualified'].includes(q.scoreTier ?? '')) { where.push("json_extract(company_score, '$.purchase.tier') = @scoreTier"); params.scoreTier = q.scoreTier!; }
    else if (q.scoreTier === 'candidate') where.push("json_extract(company_score, '$.status') = 'no_website'");
    else if (q.scoreTier === 'unscored') where.push('company_score IS NULL');
    if (['P1', 'P2', 'P3', 'P4'].includes(q.priority ?? '')) { where.push("json_extract(company_score, '$.fit.priority') = @priority"); params.priority = q.priority!; }
    if (q.businessType) { where.push("json_extract(lead_info, '$.businessType') = @businessType"); params.businessType = q.businessType; }
    if (q.thankYou === 'sent') where.push('thank_you_sent_at IS NOT NULL');
    if (q.thankYou === 'not') where.push('thank_you_sent_at IS NULL');
    const offerSent = "EXISTS (SELECT 1 FROM offers_sent o WHERE o.card_id = cards.id AND o.kind = 'offer')";
    if (q.offer === 'sent') where.push(offerSent);
    if (q.offer === 'not') where.push(`NOT ${offerSent}`);
    if (q.offer === 'wanted') where.push(`(send_offer = 1 OR (send_offer IS NULL AND ai_insight LIKE '%"sendOffer":true%')) AND NOT ${offerSent}`);
    if (q.bulgaria) where.push("(bulgaria = 1 OR (bulgaria IS NULL AND ai_insight LIKE '%\"bulgariaFit\":true%'))");
    const worked = `EXISTS (SELECT 1 FROM activities w WHERE w.card_id = cards.id AND w.imported = 0 AND w.type IN ${TOUCH})`;
    if (q.touched === 'none') where.push(`NOT ${worked}`);
    if (q.touched === 'mine' && q.visibleTo) { where.push(`${worked.replace('w.imported = 0', 'w.imported = 0 AND w.user_id = @touchedBy')}`); params.touchedBy = q.visibleTo.id; }

    if (q.visibleTo) {
      const sql = visibilitySql(q.visibleTo, params);
      if (sql) where.push(sql);
    }

    const clause = where.length ? `WHERE ${where.join(' AND ')}` : '';
    const lastContact = "(SELECT MAX(a.created_at) FROM activities a WHERE a.card_id = cards.id AND a.type IN ('note', 'call', 'visit', 'meeting', 'sample'))";
    const stageRank = "CASE stage WHEN 'customer' THEN 5 WHEN 'quoted' THEN 4 WHEN 'interested' THEN 3 WHEN 'contacted' THEN 2 WHEN 'lead' THEN 1 WHEN 'lost' THEN 0 ELSE 1 END";
    const placeOf = "COALESCE(NULLIF(CASE WHEN market = 'domestic' THEN city ELSE country END, ''), 'zzzz')";
    const order =
      q.sort === 'company_desc' ? 'ORDER BY company COLLATE NOCASE DESC, id DESC'
      : q.sort === 'place' ? `ORDER BY ${placeOf} COLLATE NOCASE ASC, company COLLATE NOCASE ASC, id ASC`
      : q.sort === 'place_desc' ? `ORDER BY ${placeOf} COLLATE NOCASE DESC, company COLLATE NOCASE ASC, id ASC`
      : q.sort === 'stage' ? `ORDER BY ${stageRank} ASC, company COLLATE NOCASE ASC, id ASC`
      : q.sort === 'stage_desc' ? `ORDER BY ${stageRank} DESC, company COLLATE NOCASE ASC, id ASC`
      // newest contact first / those never contacted and the oldest first
      : q.sort === 'last_contact_desc' ? `ORDER BY ${lastContact} IS NULL ASC, ${lastContact} DESC, id DESC`
      : q.sort === 'last_contact' ? `ORDER BY ${lastContact} IS NULL DESC, ${lastContact} ASC, id ASC`
      // the customers that wait for something first: an offer to send, nobody has been in touch, or the oldest contact
      : q.sort === 'next' ? `ORDER BY CASE WHEN (send_offer = 1 OR (send_offer IS NULL AND ai_insight LIKE '%"sendOffer":true%')) AND NOT EXISTS (SELECT 1 FROM offers_sent o WHERE o.card_id = cards.id AND o.kind = 'offer') THEN 0 WHEN ${lastContact} IS NULL THEN 1 ELSE 2 END ASC, ${lastContact} ASC, id ASC`
      : q.sort === 'purchase' ? "ORDER BY COALESCE(json_extract(company_score, '$.purchase.score'), -1) DESC, id DESC"
      : q.sort === 'ai_asc' ? 'ORDER BY COALESCE(ai_rate, 99) ASC, id ASC'
      : q.sort === 'score_asc' ? "ORDER BY COALESCE(json_extract(lead_info, '$.score'), 999999) ASC, id ASC"
      : q.sort === 'ai' ? 'ORDER BY COALESCE(ai_rate, -1) DESC, COALESCE(rate, -1) DESC, id DESC'
      : q.sort === 'score' ? "ORDER BY COALESCE(json_extract(lead_info, '$.score'), -1) DESC, id DESC"
      : q.sort === 'company' ? 'ORDER BY company COLLATE NOCASE ASC, id ASC'
      : 'ORDER BY created_at DESC, id DESC';
    const total = (db.prepare(`SELECT COUNT(*) AS n FROM cards ${clause}`).get(params) as { n: number }).n;
    const rows = db
      .prepare(`SELECT * FROM cards ${clause} ${order} LIMIT @limit OFFSET @offset`)
      .all({ ...params, limit: q.pageSize, offset: (q.page - 1) * q.pageSize }) as unknown as CardRow[];
    return { rows, total };
  },

  // How many customers of each kind this person may see (for the tabs of the customer list).
  segmentCounts(visibleTo?: Viewer): { existing: number; potential: number; lost: number; all: number; exhibition: number; important: number; leads: number; reactivate: number } {
    const params: Record<string, string | number> = {};
    const vis = visibleTo ? visibilitySql(visibleTo, params) : null;
    const r = db
      .prepare(
        `SELECT SUM(CASE WHEN stage = 'customer' THEN 1 ELSE 0 END) AS existing,
                SUM(CASE WHEN stage IS NULL OR stage IN ('lead', 'contacted', 'interested', 'quoted') THEN 1 ELSE 0 END) AS potential,
                SUM(CASE WHEN stage = 'lost' THEN 1 ELSE 0 END) AS lost,
                SUM(CASE WHEN ${SQL_EXHIBITION} THEN 1 ELSE 0 END) AS exhibition,
                SUM(CASE WHEN ${SQL_IMPORTANT} THEN 1 ELSE 0 END) AS important,
                SUM(CASE WHEN ${SQL_LEADS} THEN 1 ELSE 0 END) AS leads,
                SUM(CASE WHEN ${SQL_REACTIVATE} THEN 1 ELSE 0 END) AS reactivate, COUNT(*) AS n FROM cards${vis ? ` WHERE ${vis}` : ''}`
      )
      .get(params) as { existing: number | null; potential: number | null; lost: number | null; exhibition: number | null; important: number | null; leads: number | null; reactivate: number | null; n: number };
    return { existing: r.existing ?? 0, potential: r.potential ?? 0, lost: r.lost ?? 0, all: r.n, exhibition: r.exhibition ?? 0, important: r.important ?? 0, leads: r.leads ?? 0, reactivate: r.reactivate ?? 0 };
  },

  countForExhibition(exhibitionId: number): number {
    const row = db.prepare('SELECT COUNT(*) as count FROM cards WHERE exhibition_id = ?').get(exhibitionId) as {
      count: number;
    };
    return row.count;
  },

  // Aggregate counts, not individual records - deliberately not subject to
  // the per-uploader/per-person visibility restriction that search() applies,
  // since the whole point is a shared team total for the exhibition everyone
  // is currently working (confirmed directly by the user).
  countByCountry(exhibitionId?: number): { country: string; count: number }[] {
    const where = exhibitionId
      ? "WHERE exhibition_id = @exhibitionId AND market != 'domestic' AND country IS NOT NULL AND country != '' AND (stage IS NULL OR stage != 'lead')"
      : "WHERE market != 'domestic' AND country IS NOT NULL AND country != '' AND (stage IS NULL OR stage != 'lead')";
    return db
      .prepare(`SELECT country, COUNT(*) as count FROM cards ${where} GROUP BY country ORDER BY count DESC`)
      .all(exhibitionId ? { exhibitionId } : {}) as unknown as { country: string; count: number }[];
  },
};
