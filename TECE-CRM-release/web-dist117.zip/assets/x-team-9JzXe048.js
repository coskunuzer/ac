// Team analysis on the Performance page (owner, 21 Nov): "My team" for managers (a row per person + the team total) and "My performance"
// for everybody (their own scorecard against the team average, next actions with named customers, the coaching report).
// One call per tab: GET /api/team-perf/team, GET /api/team-perf/person?user=<id>; the coaching report: /api/team-perf/coaching (x-team-coach.js).
// The server decides who may see whom and whether money shows; every chart is hand-written SVG.
import { h, Fragment, useState, useEffect, useMemo, useRef, api, Link, useT, Icon, cx, errText, eur, Skel, Empty, loc, pctTxt, useTx, locVars, trPct } from "./x-kit-1W3jRMzJ.js";
const dmy = (iso) => (iso && /^\d{4}-\d{2}-\d{2}/.test(iso) ? new Intl.DateTimeFormat(loc(), { day: "2-digit", month: "2-digit", year: "numeric", timeZone: "UTC" }).format(new Date(iso.slice(0, 10) + "T12:00:00Z")) : iso || "–");
import { Coaching, VerdictPill, VerdictPanel, VerdictOptions } from "./x-team-coach-xDO1A9Z3.js";
import { FocusCards } from "./x-focus-NzqrJ8Ix.js";

const num = (v, d = 0) => (v == null || !Number.isFinite(v) ? "–" : Number(v).toLocaleString(loc(), { minimumFractionDigits: d, maximumFractionDigits: d }));
const signed = (v, d = 1, unit = "%") => (v == null ? "–" : (v > 0 ? "+" : v < 0 ? "−" : "±") + (unit === "%" ? pctTxt(num(Math.abs(v), d)) : num(Math.abs(v), d) + unit));
const dayTxt = (iso) => (iso && /^\d{4}-\d{2}-\d{2}/.test(iso) ? new Intl.DateTimeFormat(loc(), { day: "2-digit", month: "2-digit", year: "numeric", timeZone: "UTC" }).format(new Date(iso.slice(0, 10) + "T12:00:00Z")) : iso || "–");
const tone = (v) => (v == null ? "flat" : v > 0 ? "up" : v < 0 ? "down" : "flat");
const MONTHS_TR = ["Oca", "Şub", "Mar", "Nis", "May", "Haz", "Tem", "Ağu", "Eyl", "Eki", "Kas", "Ara"];
const MONTHS_EN = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const monthName = (ym, t) => { const m = +ym.slice(5, 7) - 1; return (t("Jan") === "Oca" ? MONTHS_TR : MONTHS_EN)[m] + " " + ym.slice(2, 4); };

// ---- sparkline: one series in the de-emphasis ink, the last point in the accent; hover shows the month and value
function Spark({ values, labels, fmt = (v) => num(v), w = 92, h: H = 26, label, ref100 }) {
  const [hi, setHi] = useState(null);
  const vals = (values || []).map((v) => (v == null || !Number.isFinite(v) ? null : v));
  const real = vals.filter((v) => v != null);
  if (real.length < 2) return h("span", { className: "tm-spark tm-spark--none", "aria-hidden": true });
  let lo = Math.min(...real), up = Math.max(...real);
  if (ref100 != null) { lo = Math.min(lo, ref100); up = Math.max(up, ref100); }
  if (up === lo) { up += 1; lo -= 1; }
  const pad = 3, n = vals.length;
  const x = (i) => pad + (i * (w - 2 * pad)) / Math.max(1, n - 1);
  const y = (v) => H - pad - ((v - lo) / (up - lo)) * (H - 2 * pad);
  let d = "", pen = false;
  vals.forEach((v, i) => { if (v == null) { pen = false; return; } d += (pen ? "L" : "M") + x(i).toFixed(1) + " " + y(v).toFixed(1); pen = true; });
  const last = vals.length - 1 - [...vals].reverse().findIndex((v) => v != null);
  const tip = hi != null && vals[hi] != null ? (labels ? labels[hi] + ": " : "") + fmt(vals[hi]) : null;
  return h(
    "span",
    { className: "tm-spark", role: "img", "aria-label": (label ? label + ": " : "") + vals.map((v, i) => (labels ? labels[i] + " " : "") + (v == null ? "–" : fmt(v))).join(", ") },
    h(
      "svg",
      { width: w, height: H, viewBox: `0 0 ${w} ${H}`, onMouseLeave: () => setHi(null) },
      ref100 != null && h("line", { x1: pad, x2: w - pad, y1: y(ref100), y2: y(ref100), className: "tm-spark-ref" }),
      h("path", { d, className: "tm-spark-line" }),
      hi != null && vals[hi] != null && h("line", { x1: x(hi), x2: x(hi), y1: pad, y2: H - pad, className: "tm-spark-cross" }),
      h("circle", { cx: x(last), cy: y(vals[last]), r: 2.6, className: "tm-spark-dot" }),
      hi != null && vals[hi] != null && h("circle", { cx: x(hi), cy: y(vals[hi]), r: 3, className: "tm-spark-hi" }),
      vals.map((v, i) => h("rect", { key: i, x: x(i) - (w / n) / 2, y: 0, width: w / n, height: H, fill: "transparent", onMouseEnter: () => setHi(i) })),
    ),
    tip && h("span", { className: "tm-spark-tip" }, tip),
  );
}

// a status split as one thin bar (active, new, slowing, passive, lost), with a legend in words beside it in the scorecard
const STATUS = [["active", "Active"], ["new", "New"], ["slowing", "Slowing"], ["passive", "Passive"], ["lost", "Lost"]];
function StatusBar({ c, thin }) {
  const t = useTx("team");
  const tot = STATUS.reduce((s, [k]) => s + (c[k] || 0), 0) || 1;
  return h("span", { className: cx("tm-seg", thin && "tm-seg--thin"), role: "img", "aria-label": STATUS.map(([k, l]) => t(l) + " " + (c[k] || 0)).join(", ") },
    STATUS.filter(([k]) => c[k] > 0).map(([k, l]) => h("span", { key: k, className: "tm-st--" + k, style: { flexGrow: c[k] }, title: t(l) + ": " + num(c[k]) + " (" + pctTxt(Math.round((c[k] / tot) * 100)) + ")" })));
}

// where a value sits against the team (the person's bar and the team mark)
function VsTeam({ me, team, better = "high", fmt = (v) => num(v) }) {
  const t = useTx("team");
  if (team == null || me == null) return null;
  const good = better === "high" ? me >= team : me <= team;
  return h("span", { className: cx("tm-vs", good ? "tm-vs--good" : "tm-vs--bad") }, h("i", { "aria-hidden": true }, good ? "▲" : "▼"), t("team avg {v}", { v: fmt(team) }));
}

// ================================================================== My team
const COLS = [
  { k: "name", l: "Person" },
  { k: "sales", l: "Sales, 12 months", money: true, v: (r) => r.sales && r.sales.v, better: "high" },
  { k: "target", l: "Of target", money: true, v: (r) => r.sales && r.sales.targetPct, better: "high" },
  { k: "growth", l: "vs 12 months before", money: true, v: (r) => r.sales && r.sales.growth, better: "high" },
  { k: "active", l: "Active customers", v: (r) => r.customers.active + r.customers.new, better: "high" },
  { k: "risk", l: "Slowing / lost", v: (r) => r.customers.slowing + r.customers.lost, better: "low" },
  { k: "retention", l: "Kept", v: (r) => r.customers.retention, better: "high" },
  { k: "calls", l: "Calls", v: (r) => r.act.calls, better: "high" },
  { k: "visits", l: "Visits", v: (r) => r.act.visits, better: "high" },
  { k: "meetings", l: "Meetings", v: (r) => r.act.meetings, better: "high" },
  { k: "offers", l: "Offers", v: (r) => r.act.offers, better: "high" },
  { k: "done", l: "Follow-ups done", v: (r) => r.act.done, better: "high" },
  { k: "overdue", l: "Overdue", v: (r) => r.act.overdue, better: "low" },
  { k: "first", l: "Days to first contact", v: (r) => r.act.firstDays, better: "low" },
  { k: "index", l: "Price index", money: true, v: (r) => r.price && r.price.index, better: "high" },
];

export function TeamTab() {
  const t = useTx("team");
  const [data, setData] = useState(null);
  const [err, setErr] = useState(null);
  const [pick, setPick] = useState(null);
  const [coachIt, setCoachIt] = useState(false);
  const [sort, setSort] = useState({ k: "sales", dir: -1 });
  useEffect(() => {
    let alive = true;
    api.get("/team-perf/team").then((d) => alive && (setData(d), setErr(null))).catch((e) => alive && setErr(errText(e, t("Could not open it"))));
    return () => { alive = false; };
  }, []);
  if (pick) return h(MyPerf, { userId: pick, coach: coachIt, onBack: () => { setPick(null); setCoachIt(false); } });
  if (err) return h("div", { className: "tm" }, h(Empty, { icon: "groups", title: t("My team") }, t(err)));
  if (!data) return h("div", { className: "tm" }, h("div", { className: "tm-tiles" }, [1, 2, 3, 4, 5].map((i) => h(Skel, { key: i, height: 96 }))), h(Skel, { height: 320 }));
  const cols = COLS.filter((c) => !c.money || data.money);
  const sortK = cols.some((c) => c.k === sort.k) ? sort.k : "active";
  const col = cols.find((c) => c.k === sortK);
  const rows = [...data.rows].sort((a, b) => {
    if (sortK === "name") return a.name.localeCompare(b.name) * sort.dir;
    const va = col.v(a), vb = col.v(b);
    if (va == null && vb == null) return 0; if (va == null) return 1; if (vb == null) return -1;
    return (va - vb) * sort.dir;
  });
  // best and worst per column (among the people, never the total)
  const marks = {};
  if (data.rows.length > 1) for (const c of cols) {
    if (!c.v) continue;
    // a person without customers in the sales list (the domestic team, for one) is left out of the customer and money columns
    const pool = c.k === "sales" || c.k === "target" || c.k === "growth" || c.k === "active" || c.k === "risk" || c.k === "retention" || c.k === "index" ? data.rows.filter((r) => r.customers.total > 0) : data.rows;
    const vals = pool.map((r) => c.v(r)).filter((v) => v != null);
    if (new Set(vals).size < 2) continue;
    const hiV = Math.max(...vals), loV = Math.min(...vals);
    marks[c.k] = { best: c.better === "high" ? hiV : loV, worst: c.better === "high" ? loV : hiV };
  }
  const T = data.total;
  const months = data.months;
  return h(
    "div",
    { className: "tm" },
    h("div", { className: "tm-bar" },
      h("div", null, h("h2", null, t("My team")), h("p", null, t("{n} people", { n: data.rows.length }), " · ", data.money ? t("sales to {d}", { d: dayTxt(data.asOf) }) + " · " : "", t("activity to {d}", { d: dayTxt(data.today) }))),
    ),
    h(TeamTiles, { T, money: data.money, months }),
    h(TeamVerdicts, { rows: data.rows, onPick: (id, coach) => { setCoachIt(!!coach); setPick(id); } }),
    h(
      "section",
      { className: "tm-card" },
      h("div", { className: "tm-card-head" }, h("h3", null, t("The team side by side")), h("small", null, t("Last 12 months. Green: the best in a column, red: the one to help first. Press a person for their scorecard."))),
      h(
        "div",
        { className: "tm-scroll" },
        h(
          "table",
          { className: "tm-table" },
          h("thead", null, h("tr", null, cols.map((c) => h("th", { key: c.k, className: c.k === "name" ? "tm-sticky" : "num", "aria-sort": sortK === c.k ? (sort.dir === 1 ? "ascending" : "descending") : "none" },
            h("button", { type: "button", onClick: () => setSort((s) => ({ k: c.k, dir: s.k === c.k ? -s.dir : c.k === "name" ? 1 : -1 })) }, t(c.l), sortK === c.k ? h("i", { "aria-hidden": true }, sort.dir === 1 ? " ↑" : " ↓") : null))))),
          h("tbody", null,
            rows.map((r) => h(TeamRow, { key: r.id, r, cols, marks, months, onPick: () => setPick(r.id) })),
            h(TeamRow, { r: { ...T, name: t("Team total") }, cols, marks: {}, months, total: true }),
          ),
        ),
      ),
    ),
    h("p", { className: "tm-foot" }, t("Sales and customers: the same customers and status rules as Price performance (sales list up to the last invoice day). Target: the targets of the same 12 months. Activity: calls (and WhatsApp), visits, meetings, notes, offers and follow-ups recorded in the CRM in the last 12 months. Days to first contact: from a new lead or fair visitor to the first call, mail or visit. Price index: 100 = the average of all customers for the same products in the same 12 months.")),
  );
}

// one card per person: the verdict, the 2-3 reasons, the first options (press the name for the whole scorecard)
function TeamVerdicts({ rows, onPick }) {
  const t = useTx("team");
  const withV = rows.filter((r) => r.verdict);
  if (!withV.length) return null;
  const rank = { at_risk: 0, attention: 1, on_track: 2 };
  const list = [...withV].sort((a, b) => rank[a.verdict.status] - rank[b.verdict.status] || b.verdict.points - a.verdict.points);
  const count = (s) => withV.filter((r) => r.verdict.status === s).length;
  return h(
    "section",
    { className: "tm-card tm-verdicts" },
    h("div", { className: "tm-card-head" },
      h("h3", null, h(Icon, { n: "rule", size: 18 }), " ", t("Verdict per person")),
      h("small", null, t("{a} at risk · {b} need attention · {c} on track", { a: count("at_risk"), b: count("attention"), c: count("on_track") }), " · ", t("fixed rules on the facts below, compared with the team"))),
    h("div", { className: "tm-vgrid" }, list.map((r) => h("article", { key: r.id, className: cx("tm-vcard", "tm-vcard--" + r.verdict.status) },
      h("div", { className: "tm-vcard-head" },
        h("button", { type: "button", className: "tm-link tm-vname", onClick: () => onPick(r.id) }, r.name, r.self ? h("small", null, " (" + t("you") + ")") : null),
        h(VerdictPill, { status: r.verdict.status })),
      r.verdict.reasons.length
        ? h("ul", { className: "tm-vreasons" }, r.verdict.reasons.map((x, i) => h("li", { key: i }, h(Icon, { n: "trending-down", size: 16 }), trPct(t(x.t, locVars(x.v))))))
        : h("ul", { className: "tm-vreasons tm-vreasons--good" }, r.verdict.strengths.map((x, i) => h("li", { key: i }, h(Icon, { n: "trending-up", size: 16 }), trPct(t(x.t, locVars(x.v)))))),
      h(VerdictOptions, { options: r.verdict.options, limit: 2, onCoach: () => onPick(r.id, true) }),
      h("button", { type: "button", className: "tm-link tm-small tm-vmore", onClick: () => onPick(r.id) }, t("Scorecard and focus"), h(Icon, { n: "arrow-forward", size: 14 })),
    ))),
  );
}

function TeamTiles({ T, money, months }) {
  const t = useTx("team");
  const act = T.act;
  const sumSpark = (keys) => months.act.map((_, i) => keys.reduce((s, k) => s + ((act.spark[k] || [])[i] || 0), 0));
  return h(
    "div",
    { className: "tm-tiles" },
    money && T.sales && h(Tile, { icon: "euro", label: t("Team sales, last 12 months"), value: eur(T.sales.v, { short: true }), delta: T.sales.growth, deltaLabel: t("vs the 12 months before"), spark: T.sales.spark, labels: months.sales.map((m) => monthName(m, t)), fmt: (v) => eur(v, { short: true }),
      sub: T.sales.target ? t("{p} of the target ({v})", { p: pctTxt(num(T.sales.targetPct, 0)), v: eur(T.sales.target, { short: true }) }) : t("no target set for these months"), bar: T.sales.targetPct }),
    h(Tile, { icon: "groups", label: t("Customers"), value: num(T.customers.active + T.customers.new), sub: t("active or new, of {n} with purchases", { n: num(T.customers.total) }), status: T.customers }),
    h(Tile, { icon: "handshake", label: t("Customers kept"), value: T.customers.retention == null ? "–" : pctTxt(num(T.customers.retention, 0)), sub: t("{a} of {b} who bought the year before bought again", { a: T.customers.kept, b: T.customers.of }) }),
    h(Tile, { icon: "call", label: t("Calls, visits, meetings"), value: num(act.calls + act.visits + act.meetings), sub: t("{o} offers · {d} follow-ups done", { o: num(act.offers), d: num(act.done) }), spark: sumSpark(["calls", "visits", "meetings"]), labels: months.act.map((m) => monthName(m, t)) }),
    h(Tile, { icon: "alarm", label: t("Overdue follow-ups"), value: num(act.overdue), warn: act.overdue > 0, sub: act.firstDays == null ? t("of {n} open", { n: num(act.open) }) : t("of {n} open · first contact after {d} days", { n: num(act.open), d: num(act.firstDays, 1) }) }),
    money && T.price && h(Tile, { icon: "price-check", label: t("Price index"), value: T.price.index == null ? "–" : num(T.price.index, 0), hero: true, delta: T.price.change, deltaPts: true, deltaLabel: t("points vs the 12 months before"), spark: T.price.trend.map((w) => w.index), labels: T.price.trend.map((w) => w.from + " – " + w.to), ref100: 100, sub: t("100 = average of all customers, same products, same 12 months") }),
  );
}

function TeamRow({ r, cols, marks, months, onPick, total }) {
  const t = useTx("team");
  const MONEYISH = { sales: 1, target: 1, growth: 1, active: 1, risk: 1, retention: 1, index: 1 };
  const mark = (k, v) => { const m = marks[k]; if (!m || v == null || (MONEYISH[k] && !r.customers.total)) return null; return v === m.best ? "tm-best" : v === m.worst ? "tm-worst" : null; };
  const cell = (c) => {
    const v = c.v ? c.v(r) : null;
    const cls = cx("num", mark(c.k, v));
    switch (c.k) {
      case "name": return h("th", { key: c.k, scope: "row", className: "tm-sticky" }, total ? h("b", null, r.name) : h("span", { className: "tm-namecell" }, h("button", { type: "button", className: "tm-link", onClick: onPick }, r.name, r.self ? h("small", null, " (" + t("you") + ")") : null), r.verdict ? h(VerdictPill, { status: r.verdict.status }) : null));
      case "sales": return h("td", { key: c.k, className: cls }, h("span", { className: "tm-cell" }, h("b", null, eur(v, { short: true })), h(Spark, { values: r.sales.spark, labels: months.sales.map((m) => monthName(m, t)), fmt: (x) => eur(x, { short: true }), w: 64, h: 20, label: t("Sales per month") })));
      case "target": return h("td", { key: c.k, className: cls }, v == null ? h("span", { className: "tm-muted", title: t("no target set") }, "–") : h("span", { className: "tm-cell tm-cell--col" }, pctTxt(num(v, 0)), h("span", { className: "tm-mbar" }, h("span", { style: { width: Math.min(100, v) + "%" }, className: v >= 100 ? "is-good" : v >= 85 ? "is-warn" : "is-bad" }))));
      case "growth": return h("td", { key: c.k, className: cls }, h("span", { className: "tm-ch tm-ch--" + tone(v) }, signed(v)));
      case "active": return h("td", { key: c.k, className: cls }, h("span", { className: "tm-cell tm-cell--col" }, num(v), h(StatusBar, { c: r.customers, thin: true })));
      case "risk": return h("td", { key: c.k, className: cls, title: t("Slowing") + " " + r.customers.slowing + " · " + t("Lost") + " " + r.customers.lost }, num(r.customers.slowing), h("small", null, " / " + num(r.customers.lost)));
      case "retention": return h("td", { key: c.k, className: cls }, v == null ? "–" : pctTxt(num(v, 0)));
      case "calls": case "visits": case "offers": case "done": return h("td", { key: c.k, className: cls }, h("span", { className: "tm-cell" }, num(v)));
      case "first": return h("td", { key: c.k, className: cls }, v == null ? "–" : num(v, 1), r.act.waiting ? h("small", { title: t("new leads not contacted yet") }, " · " + num(r.act.waiting) + " " + t("waiting")) : null);
      case "index": return h("td", { key: c.k, className: cls }, h("span", { className: "tm-cell" }, h("b", null, v == null ? "–" : num(v, 0)), h(Spark, { values: r.price.trend.map((w) => w.index), labels: r.price.trend.map((w) => w.from + " – " + w.to), w: 40, h: 18, ref100: 100, label: t("Price index per 12-month window") }), r.price.change != null ? h("small", { className: "tm-ch tm-ch--" + tone(r.price.change) }, signed(r.price.change, 1, "")) : null));
      default: return h("td", { key: c.k, className: cls }, num(v));
    }
  };
  return h("tr", { className: cx(total && "tm-total") }, cols.map(cell));
}

// ================================================================== My performance (and a person's scorecard)
export function MyPerf({ userId, onBack, coach }) {
  const t = useTx("team");
  const [coachN, setCoachN] = useState(coach ? 1 : 0);
  const [user, setUser] = useState(userId ? String(userId) : "");
  const [data, setData] = useState(null);
  const [err, setErr] = useState(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    let alive = true;
    setBusy(true);
    api.get("/team-perf/person" + (user ? "?user=" + encodeURIComponent(user) : ""))
      .then((d) => { if (alive) { setData(d); setErr(null); setBusy(false); } })
      .catch((e) => { if (alive) { setErr(errText(e, t("Could not open it"))); setBusy(false); } });
    return () => { alive = false; };
  }, [user]);
  if (err && !data) return h("div", { className: "tm" }, onBack && h(Back, { onBack }), h(Empty, { icon: "person", title: t("My performance") }, t(err)));
  if (!data) return h("div", { className: "tm" }, h("div", { className: "tm-tiles" }, [1, 2, 3, 4, 5, 6].map((i) => h(Skel, { key: i, height: 96 }))), h(Skel, { height: 260 }));
  const r = data.row, tm = data.team, months = data.months, money = data.money;
  const mlab = months.act.map((m) => monthName(m, t));
  const who = data.person.self ? t("My performance") : data.person.name;
  return h(
    "div",
    { className: cx("tm", busy && "tm--busy") },
    onBack && h(Back, { onBack }),
    h("div", { className: "tm-bar" },
      h("div", null, h("h2", null, who), h("p", null, data.person.self ? data.person.name + " · " : "", money ? t("sales to {d}", { d: dayTxt(data.asOf) }) + " · " : "", t("activity to {d}", { d: dayTxt(data.today) }), tm ? " · " + t("compared with the team average ({n} people)", { n: tm.people }) : "")),
      h("div", { className: "tm-controls" },
        data.people.length > 1 && h("label", { className: "tm-select" }, h("span", null, t("Person")),
          h("select", { value: String(data.person.id), onChange: (e) => setUser(e.target.value), "aria-label": t("Person") }, data.people.map((p) => h("option", { key: p.id, value: String(p.id) }, p.name + (p.self ? " (" + t("you") + ")" : ""))))),
      ),
    ),
    !money && h("p", { className: "tm-note" }, h(Icon, { n: "lock", size: 16 }), t("Sales, targets and prices are not switched on for you: the activity, the customers and the follow-ups show.")),
    data.verdict && h(VerdictPanel, { v: data.verdict, name: data.person.name, self: data.person.self, onCoach: () => setCoachN((n) => n + 1) }),
    !data.person.self && h(FocusCards, { personId: data.person.id, name: data.person.name }),
    h(
      "div",
      { className: "tm-tiles" },
      money && r.sales && h(Tile, { icon: "euro", label: t("Sales, last 12 months"), value: eur(r.sales.v, { short: true }), delta: r.sales.growth, deltaLabel: t("vs the 12 months before"), spark: r.sales.spark, labels: months.sales.map((m) => monthName(m, t)), fmt: (v) => eur(v, { short: true }),
        sub: r.sales.target ? t("{p} of the target ({v})", { p: pctTxt(num(r.sales.targetPct, 0)), v: eur(r.sales.target, { short: true }) }) : t("no target set for these months"), bar: r.sales.targetPct, vs: tm && tm.sales && h(VsTeam, { me: r.sales.v, team: tm.sales.v, fmt: (v) => eur(v, { short: true }) }) }),
      money && r.price && h(Tile, { icon: "price-check", label: t("Price index"), value: r.price.index == null ? "–" : num(r.price.index, 0), hero: true, delta: r.price.change, deltaPts: true, deltaLabel: t("points vs the 12 months before"), spark: r.price.trend.map((w) => w.index), labels: r.price.trend.map((w) => w.from + " – " + w.to), ref100: 100, sub: t("100 = average of all customers, same products, same 12 months") }),
      h(Tile, { icon: "groups", label: t("Customers"), value: num(r.customers.active + r.customers.new), sub: t("active or new, of {n} with purchases", { n: num(r.customers.total) }), status: r.customers, vs: tm && h(VsTeam, { me: r.customers.active + r.customers.new, team: tm.customers.active + tm.customers.new }) }),
      h(Tile, { icon: "handshake", label: t("Customers kept"), value: r.customers.retention == null ? "–" : pctTxt(num(r.customers.retention, 0)), sub: t("{a} of {b} who bought the year before bought again", { a: r.customers.kept, b: r.customers.of }), vs: tm && h(VsTeam, { me: r.customers.retention, team: tm.customers.retention, fmt: (v) => pctTxt(num(v, 0)) }) }),
    ),
    h(
      "section",
      { className: "tm-card" },
      h("div", { className: "tm-card-head" }, h("h3", null, t("The work that brings the sales")), h("small", null, t("last 12 months, per month"))),
      h(
        "div",
        { className: "tm-acts" },
        [["calls", "Calls and messages", "call", "high"], ["visits", "Visits", "location-on", "high"], ["meetings", "Meetings", "event", "high"], ["notes", "Notes", "edit-note", null], ["offers", "Offers sent", "request-quote", "high"], ["done", "Follow-ups done", "task-alt", "high"]].map(([k, l, ic, better]) =>
          h("div", { key: k, className: "tm-act" },
            h("span", { className: "tm-act-head" }, h(Icon, { n: ic, size: 16 }), t(l)),
            h("b", null, num(r.act[k])),
            h(Spark, { values: r.act.spark[k], labels: mlab, w: 120, h: 30, label: t(l) }),
            better && tm ? h(VsTeam, { me: r.act[k], team: tm.act[k], better }) : h("span", { className: "tm-muted tm-small" }, t("{n} the 12 months before", { n: num(r.act.prev[k]) })),
          )),
        h("div", { className: cx("tm-act", r.act.overdue > 0 && "tm-act--warn") },
          h("span", { className: "tm-act-head" }, h(Icon, { n: "alarm", size: 16 }), t("Overdue follow-ups")),
          h("b", null, num(r.act.overdue)), h("span", { className: "tm-muted tm-small" }, t("of {n} open", { n: num(r.act.open) })),
          tm ? h(VsTeam, { me: r.act.overdue, team: tm.act.overdue, better: "low" }) : null),
        h("div", { className: "tm-act" },
          h("span", { className: "tm-act-head" }, h(Icon, { n: "timer", size: 16 }), t("Days to first contact")),
          h("b", null, r.act.firstDays == null ? "–" : num(r.act.firstDays, 1)), h("span", { className: "tm-muted tm-small" }, t("{n} new leads still waiting", { n: num(r.act.waiting) })),
          tm ? h(VsTeam, { me: r.act.firstDays, team: tm.act.firstDays, better: "low", fmt: (v) => num(v, 1) }) : null),
      ),
    ),
    h(Actions, { actions: data.actions }),
    h(Coaching, { person: data.person, ai: data.ai, auto: coachN }),
    h("div", { className: "tm-grid" },
      h(List, { title: t("Slowing customers"), icon: "trending-down", rows: data.slowing, count: data.counts.slowing, empty: t("No customer is slowing down."), cols: money ? [["growth", (x) => h("span", { className: "tm-ch tm-ch--" + tone(x.growth) }, signed(x.growth))], ["rev", (x) => eur(x.rev, { short: true })]] : [["growth", (x) => signed(x.growth)]] }),
      money && h(List, { title: t("Priced well below average"), icon: "price-check", rows: data.discounted, count: data.counts.discounted, empty: t("No customer is priced well below the average."), cols: [["index", (x) => h("span", { className: "tm-pill tm-pill--bad", title: x.group ? x.group.grp + ": €" + num(x.group.price, 2) + " " + t("vs {p} avg", { p: "€" + num(x.group.avg, 2) }) : "" }, num(x.index, 0))], ["rev", (x) => eur(x.rev, { short: true })]] }),
      h(List, { title: t("Lost in the last months"), icon: "person-off", rows: data.lost, count: data.counts.lost, empty: t("No customer lost lately."), cols: [["last", (x) => dmy(x.last)]] }),
      h(List, { title: t("Hot fair visitors waiting"), icon: "local-fire-department", rows: data.fairWaiting, count: data.fairWaitingCount, empty: t("Every hot fair visitor has been contacted."), cols: [["score", (x) => h("span", { className: "tm-pill" }, num(x.score))]] }),
    ),
    h(Countries, { list: data.countries }),
    money && data.groups && data.groups.length > 0 && h(Groups, { groups: data.groups }),
  );
}

const Back = ({ onBack }) => { const t = useTx("team"); return h("button", { type: "button", className: "tc-btn tc-btn--ghost tc-btn--sm tm-back", onClick: onBack }, h(Icon, { n: "arrow-back", size: 16 }), t("Back to the team")); };

function Tile({ icon, label, value, sub, delta, deltaLabel, deltaPts, spark, labels, fmt, ref100, hero, warn, bar, status, vs }) {
  const t = useTx("team");
  return h(
    "div",
    { className: cx("tm-tile", hero && "tm-tile--hero", warn && "tm-tile--warn") },
    h("span", { className: "tm-tile-label" }, icon && h(Icon, { n: icon, size: 16 }), label),
    h("b", { className: "tm-tile-value" }, value),
    spark && h("span", { className: "tm-tile-spark" }, h(Spark, { values: spark, labels, fmt, ref100, w: 168, h: 28, label })),
    delta !== undefined && h("span", { className: "tm-delta tm-delta--" + tone(delta) }, delta == null ? "–" : h(Fragment, null, h("i", { "aria-hidden": true }, delta > 0 ? "▲" : delta < 0 ? "▼" : "•"), deltaPts ? signed(delta, 1, "") : signed(delta)), deltaLabel ? h("small", null, " ", deltaLabel) : null),
    bar != null && h("span", { className: "tm-mbar tm-mbar--wide", role: "progressbar", "aria-valuenow": Math.round(bar), "aria-valuemin": 0, "aria-valuemax": 100, "aria-label": t("Of target") }, h("span", { style: { width: Math.min(100, bar) + "%" }, className: bar >= 100 ? "is-good" : bar >= 85 ? "is-warn" : "is-bad" })),
    status && h(Fragment, null, h(StatusBar, { c: status }), h("span", { className: "tm-legend" }, STATUS.map(([k, l]) => h("span", { key: k }, h("i", { className: "tm-st--" + k, "aria-hidden": true }), t(l), " ", h("b", null, num(status[k])))))),
    sub && h("small", { className: "tm-tile-sub" }, sub),
    vs || null,
  );
}

const KIND_ICON = { overdue: "alarm", first: "person-add", fair: "festival", slowing: "trending-down", price: "price-check", lost: "person-off", explore: "public" };
function Actions({ actions }) {
  const t = useTx("team");
  return h(
    "section",
    { className: "tm-card tm-actions" },
    h("div", { className: "tm-card-head" }, h("h3", null, t("Next actions")), h("small", null, t("worked out from your customers, follow-ups, fairs and countries"))),
    !actions.length ? h(Empty, { icon: "task-alt", title: t("Nothing urgent") }, t("No overdue follow-ups, no waiting visitors, no slowing customers.")) :
      h("ol", { className: "tm-alist" }, actions.map((a, i) => h(
        "li",
        { key: a.kind, className: "tm-a tm-a--" + a.kind },
        h("span", { className: "tm-a-n", "aria-hidden": true }, i + 1),
        h("div", { className: "tm-a-body" },
          h("div", { className: "tm-a-head" }, h(Icon, { n: KIND_ICON[a.kind] === "travel-explore" ? "public" : KIND_ICON[a.kind] || "bolt", size: 18 }), h("b", null, t(a.title)), h("span", { className: "tm-a-count" }, num(a.n))),
          h("small", null, t(a.why)),
          h("div", { className: "tm-a-items" }, a.items.filter((x) => x.link || x.name).map((x, k) => x.link ? h(Link, { key: k, to: x.link, className: "tm-chip" }, x.name || t("a customer"), x.note && a.kind === "explore" ? h("small", null, " · " + x.note) : null) : h("span", { key: k, className: "tm-chip tm-chip--off" }, x.name || t("a customer (not yours to open)"))), a.items.some((x) => !x.link && !x.name) ? h("span", { className: "tm-chip tm-chip--off" }, t("+{n} without a card you can open", { n: a.items.filter((x) => !x.link && !x.name).length })) : null),
        ),
        a.link && h(Link, { to: a.link, className: "tc-btn tc-btn--secondary tc-btn--sm tm-a-go" }, t("Open"), h(Icon, { n: "arrow-forward", size: 16 })),
      ))),
  );
}

function List({ title, icon, rows, count, empty, cols }) {
  const t = useTx("team");
  return h(
    "section",
    { className: "tm-card tm-list" },
    h("div", { className: "tm-card-head" }, h("h3", null, h(Icon, { n: icon, size: 18 }), " ", title), count ? h("small", null, count > rows.length ? t("{a} of {b}", { a: rows.length, b: count }) : num(count)) : null),
    !rows.length ? h("p", { className: "tm-muted tm-small" }, empty) :
      h("ul", null, rows.filter((x) => x.link || x.name).map((x, i) => h("li", { key: (x.id || "n") + "-" + i },
        x.link ? h(Link, { to: x.link, className: "tm-link" }, x.name || t("a customer")) : h("span", { className: "tm-muted" }, x.name),
        x.country ? h("small", { className: "tm-muted" }, " · " + x.country) : null,
        h("span", { className: "tm-list-v" }, cols.map(([k, f]) => h("span", { key: k }, f(x)))),
      )), rows.some((x) => !x.link && !x.name) ? h("li", { className: "tm-muted tm-small" }, t("{n} more without a customer card you can open", { n: rows.filter((x) => !x.link && !x.name).length })) : null),
  );
}

function Countries({ list }) {
  const t = useTx("team");
  if (!list || !list.length) return null;
  return h(
    "section",
    { className: "tm-card" },
    h("div", { className: "tm-card-head" }, h("h3", null, t("Your countries: room to grow")), h("small", null, t("leads and customers nobody contacted for a year, and companies looked after by colleagues (view only)"))),
    h("div", { className: "tm-countries" }, list.slice(0, 8).map((c) => h(
      "div",
      { key: c.country, className: "tm-country" },
      h("div", { className: "tm-country-head" }, h("b", null, c.country), h(Link, { to: c.sprint, className: "tc-btn tc-btn--ghost tc-btn--sm" }, h(Icon, { n: "bolt", size: 16 }), t("Sprint"))),
      h("div", { className: "tm-country-nums" },
        h("span", null, h("b", null, num(c.untouched)), t("untouched"), c.untouchedCustomers ? h("small", null, " · " + t("{n} customers", { n: c.untouchedCustomers })) : null),
        h("span", null, h("b", null, num(c.viewOnly)), t("view only")),
        h("span", { className: "tm-muted" }, t("{n} in the CRM", { n: num(c.cards) })),
      ),
      c.untouchedTop.filter((x) => x.name).length > 0 && h("div", { className: "tm-a-items" }, c.untouchedTop.filter((x) => x.name).slice(0, 4).map((x) => h(Link, { key: x.id, to: x.link, className: "tm-chip" }, x.customer && h(Icon, { n: "star", size: 14 }), x.name))),
      c.viewOnlyTop.filter((x) => x.name).length > 0 && h("div", { className: "tm-a-items" }, c.viewOnlyTop.filter((x) => x.name).slice(0, 3).map((x) => h("span", { key: x.id, className: "tm-chip tm-chip--peek", title: t("looked after by {n}", { n: x.owner || "" }) }, h(Icon, { n: "visibility", size: 14 }), x.name, x.owner ? h("small", null, " · " + x.owner) : null))),
    ))),
  );
}

const GROUP_LABEL = { Melamin: "Melamine", "Ahşap": "Veneer" };
function Groups({ groups }) {
  const t = useTx("team");
  const rows = groups.filter((g) => g.unit);
  if (!rows.length) return null;
  const max = 130, min = 70;
  return h(
    "section",
    { className: "tm-card" },
    h("div", { className: "tm-card-head" }, h("h3", null, t("Price by product group")), h("small", null, t("your price per kg or m² against the average of all customers, last 12 months"))),
    h("div", { className: "tm-groups" }, rows.map((g) => {
      const p = g.index == null ? null : Math.max(0, Math.min(100, ((g.index - min) / (max - min)) * 100));
      return h("div", { key: g.grp, className: "tm-group" },
        h("span", { className: "tm-group-name" }, t(GROUP_LABEL[g.grp] || g.grp)),
        h("span", { className: "tm-group-meter", role: "img", "aria-label": (GROUP_LABEL[g.grp] || g.grp) + " " + (g.index == null ? "–" : num(g.index, 0)) },
          h("span", { className: "tm-group-mid" }), p != null && h("span", { className: cx("tm-group-dot", g.index < 90 ? "is-low" : g.index >= 105 ? "is-high" : ""), style: { left: p + "%" } })),
        h("b", null, g.index == null ? "–" : num(g.index, 0)),
        h("small", { className: "tm-muted" }, "€" + num(g.price, 2) + "/" + (g.unit === "m2" ? "m²" : "kg") + " · " + t("avg {p}", { p: "€" + num(g.avg, 2) })),
      );
    })),
  );
}
