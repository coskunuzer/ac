-- A note, visit or meeting written on a customer from a trip carries the trip: it shows on the customer's history with the trip's name,
-- and the trip lists what was written on each of its customers (and the manager sees where the person has really been).
ALTER TABLE activities ADD COLUMN trip_id INTEGER;
CREATE INDEX IF NOT EXISTS idx_activities_trip ON activities(trip_id) WHERE trip_id IS NOT NULL;
