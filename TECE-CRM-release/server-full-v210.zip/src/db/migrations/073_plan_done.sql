-- One click on a follow-up line says "done": the line leaves the person's list (nothing is deleted; it can be taken back, and every click is kept as a log).
CREATE TABLE IF NOT EXISTS plan_done (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  card_id INTEGER NOT NULL,
  kind TEXT NOT NULL,
  label TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  undone_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_plan_done_user ON plan_done (user_id, undone_at);
