import { Router } from 'express';
import { db } from '../db/connection';
import { requireAuth, requireAdmin, type AuthedRequest } from '../middleware/auth';
import { ACTION_KEYS, MENU_KEYS, MONEY_KEYS, permsOf, resetPerms, savePerms } from '../services/permissions';

// Admin → Permissions: who sees which menu items, which money figures, and may do which actions.
const router = Router();
router.use(requireAuth, requireAdmin);

interface U { id: number; username: string; display_name: string | null; role: string; market: string; area: string | null; is_assistant: number; is_sales_contact: number; can_ship: number; can_oversee: number; job_title: string | null; assists_id: number | null }

router.get('/', (_req, res) => {
  const users = db.prepare('SELECT id, username, display_name, role, market, area, is_assistant, is_sales_contact, can_ship, can_oversee, job_title, assists_id FROM users WHERE is_active = 1 AND is_sales_contact = 0 ORDER BY role = \'admin\' DESC, display_name').all() as unknown as U[];
  const grants = db.prepare('SELECT user_id, kind, value FROM user_access').all() as unknown as { user_id: number; kind: string; value: string }[];
  const last = db.prepare('SELECT user_id, MAX(at) AS at FROM perm_log GROUP BY user_id').all() as unknown as { user_id: number; at: string }[];
  const lastBy = new Map(last.map((l) => [l.user_id, l.at]));
  res.json({
    menuKeys: MENU_KEYS, actionKeys: ACTION_KEYS, moneyKeys: MONEY_KEYS,
    people: users.map((u) => {
      const g = grants.filter((x) => x.user_id === u.id);
      return {
        id: u.id, name: u.display_name || u.username, role: u.role, market: u.market, area: u.area, assistant: !!u.assists_id || !!u.is_assistant, title: u.job_title,
        canShip: !!u.can_ship, canOversee: !!u.can_oversee,
        grants: g.map((x) => (x.kind === 'market' ? `All ${x.value} customers` : `${x.kind === 'country' ? 'Country' : 'City'}: ${x.value}`)),
        perms: permsOf({ id: u.id, role: u.role }), changedAt: lastBy.get(u.id) ?? null,
      };
    }),
  });
});

router.put('/:userId', (req: AuthedRequest, res) => {
  const id = parseInt(String(req.params.userId), 10);
  const u = db.prepare('SELECT id, role FROM users WHERE id = ?').get(id) as { id: number; role: string } | undefined;
  if (!u) return res.status(404).json({ error: 'Person not found' });
  if (u.role === 'admin') return res.status(400).json({ error: 'An admin always has everything; this cannot be changed.' });
  const b = (req.body ?? {}) as { menu?: string[]; actions?: string[]; money?: string[]; start?: string | null; preset?: string | null };
  const arr = (v: unknown) => (Array.isArray(v) ? v.map(String) : []);
  res.json(savePerms(id, req.user!.id, { menu: arr(b.menu), actions: arr(b.actions), money: arr(b.money), start: b.start ?? null, preset: b.preset ?? null }));
});

// back to what the person had before any permissions were set
router.delete('/:userId', (req: AuthedRequest, res) => {
  resetPerms(parseInt(String(req.params.userId), 10), req.user!.id);
  res.json({ ok: true });
});

router.get('/log', (_req, res) => {
  res.json(db.prepare('SELECT l.id, l.at, l.after, l.before, p.display_name AS person, a.display_name AS by FROM perm_log l LEFT JOIN users p ON p.id = l.user_id LEFT JOIN users a ON a.id = l.by_user ORDER BY l.id DESC LIMIT 100').all());
});

export default router;
