import { Router, type Response } from 'express';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { useAi } from '../services/aiBudget';
import { userModel } from '../models/userModel';
import { permsOf } from '../services/permissions';
import { access, scorecard, teamView, type Access, type Person } from '../services/teamPerf';
import { aiUnavailable, findReport, listReports, mailboxProblem, makeReport, readReport, reportPdf, sendReport } from '../services/coaching';

// /api/team-perf - the team analysis of the Performance page (services/teamPerf.ts) and the coaching reports (services/coaching.ts).
//   GET  /team                         "My team": a row per person + the team total (a manager in Manager mode, an admin)
//   GET  /person?user=<id>             "My performance" / a person's scorecard (yourself; a manager the people below him; an admin everybody)
//   GET  /coaching?user=<id>           the stored coaching reports of a person (dates)
//   POST /coaching?user=<id>           make a new one (AI when it may be used, else rules)
//   GET  /coaching/:id                 one report; GET /coaching/:id/pdf the PDF; POST /coaching/:id/send e-mails it to the person
// Who may see whom: services/teamPerf.access (403 otherwise). Money (sales, targets, prices) needs the "ledger" switch for a person with a
// permissions row; without it the activity and customer counts still show and the reports leave money out.

const router = Router();
router.use(requireAuth);

const fail = (res: Response, err: unknown, code = 500) => { if (code === 500) console.error('Team analysis failed:', err); res.status(code).json({ error: err instanceof Error ? err.message : String(err) }); };
const acc = (req: AuthedRequest): Access => access(req.user as never, req.actor ?? null);
// the person asked for (default: the viewer himself; an admin without a pick: the first person)
function subjectOf(a: Access, raw: unknown): Person | null {
  if (raw == null || raw === '') return a.me ?? a.people[0] ?? null;
  const id = Number(raw);
  return a.people.find((p) => p.id === id) ?? null;
}
const NOPE = 'You can see only yourself and the people who report to you.';

router.get('/team', (req: AuthedRequest, res) => {
  try {
    const a = acc(req);
    if (!a.ok) return res.status(403).json({ error: a.error });
    if (!a.canTeam) return res.status(403).json({ error: 'The team view is for managers (in Manager mode) and admins.' });
    res.json({ ...teamView(a, req.user as never), canTeam: true });
  } catch (e) { fail(res, e); }
});

router.get('/person', (req: AuthedRequest, res) => {
  try {
    const a = acc(req);
    if (!a.ok) return res.status(403).json({ error: a.error });
    const s = subjectOf(a, req.query.user);
    if (!s) return res.status(403).json({ error: NOPE });
    res.json({ ...scorecard(a, req.user!, s), canTeam: a.canTeam, people: a.people.map((p) => ({ id: p.id, name: p.name, self: p.self })), ai: aiUnavailable(req.user!) === null });
  } catch (e) { fail(res, e); }
});

router.get('/coaching', (req: AuthedRequest, res) => {
  try {
    const a = acc(req);
    if (!a.ok) return res.status(403).json({ error: a.error });
    const s = subjectOf(a, req.query.user);
    if (!s) return res.status(403).json({ error: NOPE });
    res.json({ person: { id: s.id, name: s.name, email: !!s.email }, reports: listReports(s.id), ai: aiUnavailable(req.user!), mailbox: mailboxProblem() });
  } catch (e) { fail(res, e); }
});

router.post('/coaching', async (req: AuthedRequest, res) => {
  try {
    const a = acc(req);
    if (!a.ok) return res.status(403).json({ error: a.error });
    const s = subjectOf(a, req.query.user ?? req.body?.user);
    if (!s) return res.status(403).json({ error: NOPE });
    // the AI is counted through the gate (aiBudget.useAi); when it may not be used, the rules write the report (the button always works)
    const id = await makeReport(a, req.user!, s, req.actor?.id ?? req.user!.id, () => useAi(req.user!, { status: () => ({ json: () => undefined }) } as unknown as Response));
    const rep = findReport(id)!;
    res.status(201).json(readReport(rep, req.user!, a.money));
  } catch (e) { fail(res, e); }
});

// a report may be read by whoever may see its person
function reportFor(req: AuthedRequest, res: Response) {
  const a = acc(req);
  if (!a.ok) { res.status(403).json({ error: a.error }); return null; }
  const rep = findReport(Number(req.params.id));
  if (!rep) { res.status(404).json({ error: 'Report not found' }); return null; }
  const s = a.people.find((p) => p.id === rep.user_id);
  if (!s) { res.status(403).json({ error: NOPE }); return null; }
  return { a, rep, s, read: readReport(rep, req.user!, a.money) };
}

router.get('/coaching/:id', (req: AuthedRequest, res) => {
  try { const r = reportFor(req, res); if (r) res.json(r.read); } catch (e) { fail(res, e); }
});

router.get('/coaching/:id/pdf', async (req: AuthedRequest, res) => {
  try {
    const r = reportFor(req, res); if (!r) return;
    const pdf = await reportPdf(r.read);
    const name = `${r.read.words.title} ${r.s.name} ${r.rep.created_at.slice(0, 10)}.pdf`.replace(/[\\/:*?"<>|]+/g, '');
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${name.replace(/[^\x20-\x7e]/g, '_')}"; filename*=UTF-8''${encodeURIComponent(name)}`);
    res.send(pdf);
  } catch (e) { fail(res, e); }
});

router.post('/coaching/:id/send', async (req: AuthedRequest, res) => {
  try {
    const r = reportFor(req, res); if (!r) return;
    const p = mailboxProblem(); if (p) return res.status(409).json({ error: p, mailbox: false });
    if (!r.s.email) return res.status(409).json({ error: `${r.s.name} has no e-mail address in the CRM.` });
    // the e-mail is read as the PERSON it goes to (not as the sender): only the names he may look at, money only when he may see money
    const to = userModel.findPublicById(r.s.id);
    if (!to) return res.status(404).json({ error: 'Person not found' });
    const toPerms = permsOf(to);
    const forHim = readReport(r.rep, to, to.role === 'admin' || !toPerms || toPerms.money.includes('ledger'));
    const out = await sendReport(forHim, { name: r.s.name, email: r.s.email }, { email: (req.actor ?? req.user!).email ?? null, name: (req.actor ?? req.user!).display_name ?? '' });
    res.json({ ok: true, ...out });
  } catch (e) { fail(res, e, 400); }
});

export default router;
