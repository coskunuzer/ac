import fs from 'fs';
import path from 'path';
import { Router, type Response, type NextFunction } from 'express';
import multer from 'multer';
import ExcelJS from 'exceljs';
import { db } from '../db/connection';
import { paths } from '../config/env';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { hasBudget } from '../services/permissions';
import { DOC_TYPES, EVENT_CATEGORIES, categoryOf, docTypeOf, eventBudget, eventTitle, eventTotals, isEventKind, rowCategory, savePlan, type EventKind } from '../services/eventBudget';
import { eventExpensesXlsx, turqualityPdf } from '../services/budgetReport';
import { viewMode } from '../services/viewMode';

// Marketing budget. The invoices that come from accounting are entered here as expenses (a business trip, a fair, an advert ...) and the report of the
// marketing budget (the "Pazarlama Bütçesi" sheet: target in EUR, actual in TL, per line and month) is taken from the CRM.
// Entering and reading everything: an admin and the people an admin switched "Marketing budget" on for (Admin → Permissions). The person who made a trip
// sees the expenses of THEIR trip (read only) on the trip page.
const router = Router();
router.use(requireAuth);
const fail = (res: Response, err: unknown, code = 400) => res.status(code).json({ error: err instanceof Error ? err.message : String(err) });
const need = (req: AuthedRequest, res: Response, next: NextFunction) => (hasBudget(req.user as never) ? next() : res.status(403).json({ error: 'The marketing budget is not switched on for you.' }));
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 12 * 1024 * 1024, files: 1 } });
// the invoices are kept under data/ (never in uploads/, which can be reached by a link): only the budget screens give them out
const FILES = path.join(path.dirname(paths.dbFile), 'budget-files');

// the lines of the marketing budget sheet (same names and order as the Excel)
export const BUDGET_LINES: { grp: string; items: string[] }[] = [
  { grp: 'Fuarlar Giderleri', items: ['Stant ve Sponsorluk Bedeli', 'Fuar Stant Giderleri (tasarım ve üretim / stant giydirmeleri)', 'Lojistik Giderler', 'Fuar Ekibi İaşe Giderleri', 'Fuar Diğer Giderler (gümrük, resmi prosedür vs)', 'Promosyon & İkram', 'Diğer'] },
  { grp: 'İlanlar', items: ['Dergi İlanı'] },
  { grp: 'Müşterilere Özel Çalışmalar', items: ['E-mailing', 'Müşteri Ziyaretleri', 'Müşteri Numune Gönderimleri', 'Konuk Ağırlama', 'Sponsorluk', 'Ralli Aracı', 'Öğrenci Destek Projeleri'] },
  { grp: 'Baskı', items: ['Katalog', 'Broşür', 'Bloknot', 'Çanta', 'Dosya', 'Diğer'] },
  { grp: 'Sabit Giderler', items: ['Yayın Abonelikleri', 'Site Abonelikleri', 'Ajans Giderleri (PR ya da Reklam)'] },
  { grp: 'Digital', items: ['Hosting & SEO', 'Ajans Fee', 'Web Tasarım', 'Digital Platform Reklamları / Banner vs', 'Diğer'] },
  { grp: 'Diğer Giderler', items: ['Foto Çekimi', 'Promosyon Ürünleri', 'Posta Gönderimleri', 'İletişim Giderleri', 'Kırtasiye Giderleri', 'Kargo Bedelleri', 'Numune Giderleri', 'Diğer'] },
];
const validLine = (grp: string, item: string) => BUDGET_LINES.some((g) => g.grp === grp && g.items.includes(item));
const MARKETS = ['export', 'domestic'];
const CURRENCIES = ['TRY', 'EUR', 'USD', 'GBP'];
const r2 = (v: number) => Math.round(v * 100) / 100;

interface Exp {
  id: number; spent_on: string; market: string; grp: string; item: string; supplier: string | null; invoice_no: string | null; description: string | null; currency: string; amount: number; rate: number | null;
  amount_try: number; amount_eur: number; trip_id: number | null; card_id: number | null; exhibition_id: number | null; country: string | null; file_path: string | null; file_name: string | null;
  entered_by: number; created_at: string; account_code: string | null; fair: string | null;
}
const SELECT = `SELECT e.*, u.display_name AS entered_name, t.title AS trip_title, c.company AS customer FROM budget_expenses e
  LEFT JOIN users u ON u.id = e.entered_by LEFT JOIN trips t ON t.id = e.trip_id LEFT JOIN cards c ON c.id = e.card_id`;
const publicRow = (r: Record<string, unknown>) => { const { file_path, ...rest } = r; return { ...rest, hasFile: !!file_path }; };

function rateFor(ym: string): number | null { const r = db.prepare('SELECT try_per_eur t FROM budget_rates WHERE ym = ?').get(ym) as { t: number } | undefined; return r?.t ?? null; }
// amounts in TL and EUR from what is on the invoice
function convert(currency: string, amount: number, rate: number | null, spentOn: string, amountTry: number | null): { rate: number; try: number; eur: number } {
  const ym = spentOn.slice(0, 7);
  const rt = rate && rate > 0 ? rate : rateFor(ym);
  if (!rt) throw new Error(`Type the rate (TL for 1 €) for ${ym}: it is needed to show the expense in both TL and EUR. You can also store a rate for the month (Rates).`);
  if (currency === 'TRY') return { rate: rt, try: r2(amount), eur: r2(amount / rt) };
  if (currency === 'EUR') return { rate: rt, try: r2(amount * rt), eur: r2(amount) };
  if (!amountTry || amountTry === 0) throw new Error(`For ${currency} type the amount in TL as accounting booked it.`);
  return { rate: rt, try: r2(amountTry), eur: r2(amountTry / rt) };
}
function clean(body: Record<string, unknown>, userMarket: string) {
  const spent_on = String(body.spent_on ?? '').slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(spent_on)) throw new Error('Type the date of the invoice.');
  const grp = String(body.grp ?? ''), item = String(body.item ?? '');
  if (!validLine(grp, item)) throw new Error('Choose the budget line (group and item).');
  const market = MARKETS.includes(String(body.market)) ? String(body.market) : userMarket;
  const currency = CURRENCIES.includes(String(body.currency).toUpperCase()) ? String(body.currency).toUpperCase() : 'TRY';
  const amount = Number(String(body.amount ?? '').replace(/\s/g, '').replace(',', '.'));
  if (!Number.isFinite(amount) || amount === 0) throw new Error('Type the amount on the invoice.');
  const rate = body.rate !== undefined && body.rate !== '' && body.rate !== null ? Number(String(body.rate).replace(',', '.')) : null;
  const at = body.amount_try !== undefined && body.amount_try !== '' && body.amount_try !== null ? Number(String(body.amount_try).replace(',', '.')) : null;
  const conv = convert(currency, amount, rate, spent_on, at);
  const num = (v: unknown) => { const n = Number(v); return Number.isFinite(n) && n > 0 ? n : null; };
  const txt = (v: unknown, n = 200) => (typeof v === 'string' && v.trim() ? v.trim().slice(0, n) : null);
  return { spent_on, market, grp, item, supplier: txt(body.supplier), invoice_no: txt(body.invoice_no, 60), description: txt(body.description, 400), currency, amount: r2(amount), rate: conv.rate, amount_try: conv.try, amount_eur: conv.eur, trip_id: num(body.trip_id), card_id: num(body.card_id), exhibition_id: num(body.exhibition_id), country: txt(body.country, 60), account_code: txt(body.account_code, 30), fair: txt(body.fair, 120) };
}
const log = (id: number, action: string, by: number, before: unknown, after: unknown) => db.prepare('INSERT INTO budget_expense_log (expense_id, action, by_user, before, after) VALUES (?, ?, ?, ?, ?)').run(id, action, by, before ? JSON.stringify(before) : null, after ? JSON.stringify(after) : null);

router.get('/lines', (_req, res) => { res.json({ lines: BUDGET_LINES, accounts: db.prepare('SELECT code, name, market, grp, item FROM budget_accounts ORDER BY code, name').all(), currencies: CURRENCIES }); });

// ---- what a trip cost (the person who made the trip, or anybody with the budget switched on)
router.get('/trip/:id', (req: AuthedRequest, res) => {
  const id = Number(req.params.id);
  const trip = db.prepare('SELECT id, user_id, title FROM trips WHERE id = ?').get(id) as { id: number; user_id: number; title: string } | undefined;
  if (!trip) return fail(res, new Error('Trip not found'), 404);
  const budget = hasBudget(req.user as never);
  if (!budget && trip.user_id !== req.user!.id) return fail(res, new Error('This is not your trip.'), 403);
  const rows = db.prepare(`${SELECT} WHERE e.trip_id = ? ORDER BY e.spent_on, e.id`).all(id) as Record<string, unknown>[];
  res.json({ canEdit: budget, rows: rows.map(publicRow), totalTry: r2(rows.reduce((s, r) => s + Number(r.amount_try), 0)), totalEur: r2(rows.reduce((s, r) => s + Number(r.amount_eur), 0)) });
});

// ---- the budget of one trip / one fair: the plan per kind of cost, what was spent, what is left ------------------------------------------------------
// Who: a trip - the person who made it (they plan it and type in their own costs with the receipt), their managers (read only), an admin and the
//      people with the marketing budget switched on.
//      a fair - an admin, the people with the marketing budget, and the people going to / at the fair (they type in their own costs; the plan stays
//      with the budget people). A person changes or removes only what they typed in themselves; the budget people and an admin manage all of it.
interface Access { see: boolean; plan: boolean; spend: boolean; manage: boolean; found: boolean }
function eventAccess(req: AuthedRequest, kind: EventKind, id: number): Access {
  const head = eventTitle(kind, id);
  if (!head) return { see: false, plan: false, spend: false, manage: false, found: false };
  const u = req.user!;
  const budget = hasBudget(u as never);
  if (kind === 'trip') {
    const owner = head.ownerId === u.id;
    const lead = !owner && !budget && head.ownerId != null && viewMode.team(u.id).ids.includes(head.ownerId);
    return { found: true, see: budget || owner || lead, plan: budget || owner, spend: budget || owner, manage: budget };
  }
  const attendee = !!db.prepare('SELECT 1 FROM exhibition_attendees WHERE exhibition_id = ? AND user_id = ?').get(id, u.id);
  return { found: true, see: budget || attendee, plan: budget, spend: budget || attendee, manage: budget };
}
// the trip / fair of the request and what this person may do with it (null: the answer was already sent)
function eventOf(req: AuthedRequest, res: Response, what: 'see' | 'plan' | 'spend' = 'see'): { kind: EventKind; id: number; a: Access } | null {
  const kind = req.params.kind; const id = Number(req.params.id);
  if (!isEventKind(kind) || !Number.isInteger(id)) { fail(res, new Error('Not found'), 404); return null; }
  const a = eventAccess(req, kind, id);
  if (!a.found) { fail(res, new Error(kind === 'trip' ? 'Trip not found' : 'Fair not found'), 404); return null; }
  if (!a[what]) {
    const msg = what === 'see' ? (kind === 'trip' ? 'This is not your trip.' : 'The marketing budget is not switched on for you.') : what === 'plan' ? 'You cannot change this budget.' : kind === 'trip' ? 'Only the person who made the trip and the budget people type in its costs.' : 'Only the people at the fair and the budget people type in its costs.';
    fail(res, new Error(msg), 403); return null;
  }
  return { kind, id, a };
}
const eventOut = (req: AuthedRequest, kind: EventKind, id: number, a: Access) => ({ ...eventBudget(kind, id, req.user! as never), canPlan: a.plan, canSpend: a.spend, canManage: a.manage, me: req.user!.id, currencies: CURRENCIES, docTypes: DOC_TYPES });
// an expense of this trip / fair that this person may change: their own, or all of them for the budget people
function ownExpense(req: AuthedRequest, res: Response, kind: EventKind, id: number, a: Access): Exp | null {
  const col = kind === 'trip' ? 'trip_id' : 'exhibition_id';
  const row = db.prepare(`SELECT * FROM budget_expenses WHERE id = ? AND ${col} = ?`).get(Number(req.params.eid), id) as unknown as Exp | undefined;
  if (!row) { fail(res, new Error('Expense not found'), 404); return null; }
  if (!a.manage && row.entered_by !== req.user!.id) { fail(res, new Error('You can change only the costs you typed in yourself. The budget people can change all of them.'), 403); return null; }
  return row;
}
const flagOf = (v: unknown): number => (v === undefined || v === null || v === '' ? 1 : v === '0' || v === 'false' || v === false || v === 0 ? 0 : 1);

router.get('/event/:kind/:id', (req: AuthedRequest, res) => {
  const e = eventOf(req, res); if (!e) return;
  res.json(eventOut(req, e.kind, e.id, e.a));
});
router.put('/event/:kind/:id/plan', (req: AuthedRequest, res) => {
  const e = eventOf(req, res, 'plan'); if (!e) return;
  const lines = Array.isArray(req.body?.lines) ? (req.body.lines as { category?: unknown; planned?: unknown; note?: unknown }[]) : [];
  try {
    savePlan(e.kind, e.id, req.user!.id, lines.map((l) => ({ category: String(l.category ?? ''), planned: Number(String(l.planned ?? '').replace(/\s/g, '').replace(',', '.')) || 0, note: typeof l.note === 'string' ? l.note : null })));
    res.json(eventOut(req, e.kind, e.id, e.a));
  } catch (err) { fail(res, err); }
});
// an expense typed straight on the trip / the fair: it is booked on the right line of the marketing budget by its kind of cost
router.post('/event/:kind/:id/expense', upload.single('file'), (req: AuthedRequest, res) => {
  const e = eventOf(req, res, 'spend'); if (!e) return;
  const { kind, id } = e;
  try {
    const cat = categoryOf(kind, String(req.body?.category ?? ''));
    if (!cat) throw new Error('Choose the kind of cost.');
    const u = req.user!;
    const head = eventTitle(kind, id)!;
    const c = clean({ ...(req.body ?? {}), grp: cat.grp, item: cat.item, trip_id: kind === 'trip' ? id : null, exhibition_id: kind === 'exhibition' ? id : null, fair: kind === 'exhibition' ? head.title : null }, u.market === 'domestic' ? 'domestic' : 'export');
    const doc = docTypeOf(req.body?.doc_type) ?? 'invoice'; const tq = flagOf(req.body?.turquality);
    db.exec('BEGIN');
    let eid = 0;
    try {
      const r = db.prepare(`INSERT INTO budget_expenses (spent_on, market, grp, item, supplier, invoice_no, description, currency, amount, rate, amount_try, amount_eur, trip_id, card_id, exhibition_id, country, account_code, fair, entered_by, event_category, doc_type, turquality)
        VALUES (@spent_on, @market, @grp, @item, @supplier, @invoice_no, @description, @currency, @amount, @rate, @amount_try, @amount_eur, @trip_id, @card_id, @exhibition_id, @country, @account_code, @fair, @by, @cat, @doc, @tq)`).run({ ...c, by: u.id, cat: cat.key, doc, tq });
      eid = Number(r.lastInsertRowid);
      saveFile(eid, req.file); // a wrong kind of file stops the whole expense
      db.exec('COMMIT');
    } catch (err) { db.exec('ROLLBACK'); throw err; }
    log(eid, 'created', u.id, null, { ...c, event_category: cat.key, doc_type: doc, turquality: tq });
    res.status(201).json(eventOut(req, kind, id, e.a));
  } catch (err) { fail(res, err); }
});
// changing an expense (a new file replaces the old one; the log keeps what it was)
router.post('/event/:kind/:id/expense/:eid', upload.single('file'), (req: AuthedRequest, res) => {
  const e = eventOf(req, res, 'spend'); if (!e) return;
  const before = ownExpense(req, res, e.kind, e.id, e.a); if (!before) return;
  try {
    const cat = categoryOf(e.kind, String(req.body?.category ?? ''));
    if (!cat) throw new Error('Choose the kind of cost.');
    // the kind of cost not changed: the expense stays on its own line of the marketing budget (the budget people may have booked it on another line)
    const keep = cat.key === rowCategory(e.kind, { event_category: (before as Exp & { event_category: string | null }).event_category, grp: before.grp, item: before.item, description: before.description }) && validLine(before.grp, before.item);
    const c = clean({ ...(req.body ?? {}), grp: keep ? before.grp : cat.grp, item: keep ? before.item : cat.item }, before.market);
    const doc = docTypeOf(req.body?.doc_type) ?? 'invoice'; const tq = flagOf(req.body?.turquality);
    db.prepare(`UPDATE budget_expenses SET spent_on=@spent_on, grp=@grp, item=@item, supplier=@supplier, invoice_no=@invoice_no, description=@description, currency=@currency, amount=@amount, rate=@rate,
      amount_try=@amount_try, amount_eur=@amount_eur, event_category=@cat, doc_type=@doc, turquality=@tq, updated_at=datetime('now') WHERE id=@id`).run({ spent_on: c.spent_on, grp: c.grp, item: c.item, supplier: c.supplier, invoice_no: c.invoice_no, description: c.description, currency: c.currency, amount: c.amount, rate: c.rate, amount_try: c.amount_try, amount_eur: c.amount_eur, cat: cat.key, doc, tq, id: before.id });
    saveFile(before.id, req.file);
    log(before.id, 'changed', req.user!.id, before, { ...c, event_category: cat.key, doc_type: doc, turquality: tq });
    res.json(eventOut(req, e.kind, e.id, e.a));
  } catch (err) { fail(res, err); }
});
router.delete('/event/:kind/:id/expense/:eid', (req: AuthedRequest, res) => {
  const e = eventOf(req, res, 'spend'); if (!e) return;
  const before = ownExpense(req, res, e.kind, e.id, e.a); if (!before) return;
  const files = db.prepare('SELECT * FROM budget_expense_files WHERE expense_id = ?').all(before.id);
  db.prepare('DELETE FROM budget_expenses WHERE id = ?').run(before.id);
  log(before.id, 'removed', req.user!.id, { ...before, files }, null); // the log keeps what was removed (the files stay on the disk)
  res.json(eventOut(req, e.kind, e.id, e.a));
});
// one more document for the same cost (the payment proof of an invoice, the boarding passes of a flight ...)
router.post('/event/:kind/:id/expense/:eid/doc', upload.single('file'), (req: AuthedRequest, res) => {
  const e = eventOf(req, res, 'spend'); if (!e) return;
  const exp = ownExpense(req, res, e.kind, e.id, e.a); if (!exp) return;
  try {
    if (!req.file) throw new Error('Choose the file.');
    const doc = docTypeOf(req.body?.doc_type) ?? 'other';
    const n = (db.prepare('SELECT COUNT(*) AS n FROM budget_expense_files WHERE expense_id = ?').get(exp.id) as { n: number }).n;
    if (n >= 20) throw new Error('This cost already has 20 documents.');
    const f = keepFile(`${exp.id}-doc`, req.file);
    const r = db.prepare('INSERT INTO budget_expense_files (expense_id, doc_type, file_path, file_name, uploaded_by) VALUES (?, ?, ?, ?, ?)').run(exp.id, doc, f.rel, f.name, req.user!.id);
    log(exp.id, 'document added', req.user!.id, null, { file: Number(r.lastInsertRowid), doc_type: doc, name: f.name });
    res.status(201).json(eventOut(req, e.kind, e.id, e.a));
  } catch (err) { fail(res, err); }
});
router.delete('/event/:kind/:id/doc/:fid', (req: AuthedRequest, res) => {
  const e = eventOf(req, res, 'spend'); if (!e) return;
  const col = e.kind === 'trip' ? 'trip_id' : 'exhibition_id';
  const f = db.prepare(`SELECT f.*, x.entered_by FROM budget_expense_files f JOIN budget_expenses x ON x.id = f.expense_id WHERE f.id = ? AND x.${col} = ?`).get(Number(req.params.fid), e.id) as { id: number; expense_id: number; entered_by: number; uploaded_by: number | null } | undefined;
  if (!f) return fail(res, new Error('Document not found'), 404);
  if (!e.a.manage && f.entered_by !== req.user!.id && f.uploaded_by !== req.user!.id) return fail(res, new Error('You can remove only the documents you added yourself.'), 403);
  db.prepare('DELETE FROM budget_expense_files WHERE id = ?').run(f.id);
  log(f.expense_id, 'document removed', req.user!.id, f, null);
  res.json(eventOut(req, e.kind, e.id, e.a));
});
// the files, for everybody who may see this budget
function sendKept(res: Response, rel: string | null | undefined, name: string | null | undefined) {
  if (!rel) return fail(res, new Error('No file'), 404);
  const full = path.resolve(FILES, rel);
  if (!full.startsWith(path.resolve(FILES) + path.sep) || !fs.existsSync(full)) return fail(res, new Error('File not found'), 404);
  res.download(full, name || path.basename(full));
}
router.get('/event/:kind/:id/expense/:eid/file', (req: AuthedRequest, res) => {
  const e = eventOf(req, res); if (!e) return;
  const r = db.prepare(`SELECT file_path, file_name FROM budget_expenses WHERE id = ? AND ${e.kind === 'trip' ? 'trip_id' : 'exhibition_id'} = ?`).get(Number(req.params.eid), e.id) as { file_path: string | null; file_name: string | null } | undefined;
  sendKept(res, r?.file_path, r?.file_name);
});
router.get('/event/:kind/:id/doc/:fid/file', (req: AuthedRequest, res) => {
  const e = eventOf(req, res); if (!e) return;
  const r = db.prepare(`SELECT f.file_path, f.file_name FROM budget_expense_files f JOIN budget_expenses x ON x.id = f.expense_id WHERE f.id = ? AND x.${e.kind === 'trip' ? 'trip_id' : 'exhibition_id'} = ?`).get(Number(req.params.fid), e.id) as { file_path: string; file_name: string | null } | undefined;
  sendKept(res, r?.file_path, r?.file_name);
});
// the Turquality file: one PDF with the summary, the list of costs, the visit report and a copy of every document. ?all=1: every cost, not only the Turquality ones
router.get('/event/:kind/:id/turquality.pdf', async (req: AuthedRequest, res) => {
  const e = eventOf(req, res); if (!e) return;
  try {
    const out = await turqualityPdf(e.kind, e.id, { all: req.query.all === '1', viewer: req.user! as never, team: !req.actor && (!req.user!.area || req.user!.area === 'brand'), by: req.user!.display_name || req.user!.username, lang: req.query.lang === 'tr' || (req.query.lang !== 'en' && req.user!.ui_language === 'tr') ? 'tr' : 'en' });
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `${req.query.dl === '1' ? 'attachment' : 'inline'}; filename="${out.name}"; filename*=UTF-8''${encodeURIComponent(out.name)}`);
    res.send(out.pdf);
  } catch (err) { console.error('Turquality report failed:', err); fail(res, err, 500); }
});
router.get('/event/:kind/:id/expenses.xlsx', async (req: AuthedRequest, res) => {
  const e = eventOf(req, res); if (!e) return;
  try {
    const out = await eventExpensesXlsx(e.kind, e.id);
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${out.name}"; filename*=UTF-8''${encodeURIComponent(out.name)}`);
    res.send(out.xlsx);
  } catch (err) { console.error('Expense list failed:', err); fail(res, err, 500); }
});
// the rate of a month, for the quick form (and the last rate stored, as a first guess when the month has none yet)
router.get('/event-rate', (req: AuthedRequest, res) => {
  const ym = String(req.query.ym ?? '').slice(0, 7);
  // no rate stored for the month: the last stored rate, else the rate of the last invoice typed in up to that month
  const last = (db.prepare('SELECT ym, try_per_eur AS rate FROM budget_rates WHERE ym <= ? ORDER BY ym DESC LIMIT 1').get(ym || '9999-12')
    ?? db.prepare("SELECT substr(spent_on, 1, 7) AS ym, rate FROM budget_expenses WHERE rate > 0 AND substr(spent_on, 1, 7) <= ? ORDER BY spent_on DESC, id DESC LIMIT 1").get(ym || '9999-12')) as { ym: string; rate: number } | undefined;
  res.json({ rate: rateFor(ym), last: last ?? null });
});
// planned and spent of my trips (everybody: their own; budget people: all) and of the fairs (budget people only) - the numbers the lists show
router.get('/events', (req: AuthedRequest, res) => {
  const budget = hasBudget(req.user as never);
  const trips = (budget ? db.prepare('SELECT id FROM trips').all() : db.prepare('SELECT id FROM trips WHERE user_id = ?').all(req.user!.id)) as unknown as { id: number }[];
  const fairs = budget ? (db.prepare('SELECT id FROM exhibitions WHERE start_date IS NOT NULL').all() as unknown as { id: number }[]) : [];
  const obj = (m: Map<number, { planned: number; spent: number }>) => Object.fromEntries([...m].filter(([, v]) => v.planned > 0 || v.spent > 0));
  res.json({ canSeeFairs: budget, canSpend: budget, trip: obj(eventTotals('trip', trips.map((t) => t.id))), exhibition: obj(eventTotals('exhibition', fairs.map((f) => f.id))), categories: EVENT_CATEGORIES });
});

router.use(need);

router.get('/expenses', (req, res) => {
  const w: string[] = []; const p: (string | number)[] = [];
  const year = Number(req.query.year) || null; if (year) { w.push("substr(e.spent_on, 1, 4) = ?"); p.push(String(year)); }
  const month = Number(req.query.month) || null; if (month) { w.push("substr(e.spent_on, 6, 2) = ?"); p.push(String(month).padStart(2, '0')); }
  if (MARKETS.includes(String(req.query.market))) { w.push('e.market = ?'); p.push(String(req.query.market)); }
  if (req.query.tripId) { w.push('e.trip_id = ?'); p.push(Number(req.query.tripId)); }
  const q = String(req.query.q ?? '').trim(); if (q) { w.push("(e.supplier LIKE ? OR e.invoice_no LIKE ? OR e.description LIKE ? OR e.fair LIKE ?)"); p.push(`%${q}%`, `%${q}%`, `%${q}%`, `%${q}%`); }
  const rows = db.prepare(`${SELECT} ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY e.spent_on DESC, e.id DESC LIMIT 1500`).all(...p) as Record<string, unknown>[];
  res.json({ rows: rows.map(publicRow), totalTry: r2(rows.reduce((s, r) => s + Number(r.amount_try), 0)), totalEur: r2(rows.reduce((s, r) => s + Number(r.amount_eur), 0)) });
});

function keepFile(prefix: string | number, file: Express.Multer.File): { rel: string; name: string } {
  const orig = Buffer.from(file.originalname, 'latin1').toString('utf8');
  const ext = path.extname(orig).toLowerCase();
  if (!['.pdf', '.png', '.jpg', '.jpeg', '.xlsx', '.xls', '.doc', '.docx', '.webp'].includes(ext)) throw new Error('Attach a PDF, a picture or an Excel file.');
  fs.mkdirSync(FILES, { recursive: true });
  const rel = `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}${ext}`;
  fs.writeFileSync(path.join(FILES, rel), file.buffer);
  return { rel, name: orig.slice(0, 120) };
}
function saveFile(id: number, file: Express.Multer.File | undefined): void {
  if (!file) return;
  const f = keepFile(id, file);
  db.prepare('UPDATE budget_expenses SET file_path = ?, file_name = ? WHERE id = ?').run(f.rel, f.name, id);
}

router.post('/expenses', upload.single('file'), (req: AuthedRequest, res) => {
  try {
    const u = req.user!; const c = clean(req.body ?? {}, u.market === 'domestic' ? 'domestic' : 'export');
    const r = db.prepare(`INSERT INTO budget_expenses (spent_on, market, grp, item, supplier, invoice_no, description, currency, amount, rate, amount_try, amount_eur, trip_id, card_id, exhibition_id, country, account_code, fair, entered_by)
      VALUES (@spent_on, @market, @grp, @item, @supplier, @invoice_no, @description, @currency, @amount, @rate, @amount_try, @amount_eur, @trip_id, @card_id, @exhibition_id, @country, @account_code, @fair, @by)`).run({ ...c, by: u.id });
    const id = Number(r.lastInsertRowid);
    saveFile(id, req.file);
    log(id, 'created', u.id, null, c);
    res.status(201).json({ ok: true, id });
  } catch (e) { fail(res, e); }
});

router.put('/expenses/:id', upload.single('file'), (req: AuthedRequest, res) => {
  try {
    const id = Number(req.params.id); const u = req.user!;
    const before = db.prepare('SELECT * FROM budget_expenses WHERE id = ?').get(id) as unknown as Exp | undefined;
    if (!before) return fail(res, new Error('Expense not found'), 404);
    if (u.role !== 'admin' && before.entered_by !== u.id) return fail(res, new Error('Only the person who entered the invoice (or an admin) can change it.'), 403);
    const c = clean(req.body ?? {}, before.market);
    db.prepare(`UPDATE budget_expenses SET spent_on=@spent_on, market=@market, grp=@grp, item=@item, supplier=@supplier, invoice_no=@invoice_no, description=@description, currency=@currency, amount=@amount, rate=@rate,
      amount_try=@amount_try, amount_eur=@amount_eur, trip_id=@trip_id, card_id=@card_id, exhibition_id=@exhibition_id, country=@country, account_code=@account_code, fair=@fair, updated_at=datetime('now') WHERE id=@id`).run({ ...c, id });
    saveFile(id, req.file);
    log(id, 'changed', u.id, before, c);
    res.json({ ok: true });
  } catch (e) { fail(res, e); }
});

router.delete('/expenses/:id', (req: AuthedRequest, res) => {
  const id = Number(req.params.id); const u = req.user!;
  const before = db.prepare('SELECT * FROM budget_expenses WHERE id = ?').get(id) as unknown as Exp | undefined;
  if (!before) return fail(res, new Error('Expense not found'), 404);
  if (u.role !== 'admin' && before.entered_by !== u.id) return fail(res, new Error('Only the person who entered the invoice (or an admin) can remove it.'), 403);
  db.prepare('DELETE FROM budget_expenses WHERE id = ?').run(id);
  log(id, 'removed', u.id, before, null); // the log keeps what was removed
  res.json({ ok: true });
});

router.get('/expenses/:id/file', (req, res) => {
  const r = db.prepare('SELECT file_path, file_name FROM budget_expenses WHERE id = ?').get(Number(req.params.id)) as { file_path: string | null; file_name: string | null } | undefined;
  if (!r?.file_path) return fail(res, new Error('No file'), 404);
  const full = path.resolve(FILES, r.file_path);
  if (!full.startsWith(path.resolve(FILES)) || !fs.existsSync(full)) return fail(res, new Error('File not found'), 404);
  res.download(full, r.file_name || path.basename(full));
});

router.get('/rates', (_req, res) => { res.json(db.prepare('SELECT ym, try_per_eur FROM budget_rates ORDER BY ym DESC LIMIT 60').all()); });
router.put('/rates', (req: AuthedRequest, res) => {
  try {
    const ym = String(req.body?.ym ?? ''); const v = Number(String(req.body?.tryPerEur ?? '').replace(',', '.'));
    if (!/^\d{4}-\d{2}$/.test(ym) || !(v > 0)) throw new Error('Type the month and the rate (TL for 1 €).');
    db.prepare('INSERT INTO budget_rates (ym, try_per_eur) VALUES (?, ?) ON CONFLICT(ym) DO UPDATE SET try_per_eur = excluded.try_per_eur').run(ym, v);
    res.json({ ok: true });
  } catch (e) { fail(res, e); }
});
router.get('/rate', (req, res) => { res.json({ rate: rateFor(String(req.query.ym ?? '').slice(0, 7)) }); });

// ---- the yearly budget per line and month (EUR): admin only
router.put('/targets', (req: AuthedRequest, res) => {
  try {
    if (req.user!.role !== 'admin') return fail(res, new Error('Only an admin sets the budget.'), 403);
    const year = Number(req.body?.year), market = String(req.body?.market);
    const items = Array.isArray(req.body?.items) ? req.body.items as { grp: string; item: string; month: number; amount: number | null }[] : [];
    if (!year || !MARKETS.includes(market) || !items.length || items.length > 700) throw new Error('Nothing to save.');
    db.exec('BEGIN');
    try {
      for (const it of items) {
        if (!validLine(it.grp, it.item) || !(it.month >= 1 && it.month <= 12)) continue;
        const a = it.amount === null || it.amount === undefined || Number(it.amount) <= 0 ? null : Number(it.amount);
        if (a === null) db.prepare('DELETE FROM budget_targets WHERE year = ? AND market = ? AND grp = ? AND item = ? AND month = ?').run(year, market, it.grp, it.item, it.month);
        else db.prepare('INSERT INTO budget_targets (year, market, grp, item, month, amount_eur) VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT(year, market, grp, item, month) DO UPDATE SET amount_eur = excluded.amount_eur').run(year, market, it.grp, it.item, it.month, a);
      }
      db.exec('COMMIT');
    } catch (e) { db.exec('ROLLBACK'); throw e; }
    res.json({ ok: true });
  } catch (e) { fail(res, e); }
});

// ---- the report: per line and month, target (EUR) against actual (TL and EUR)
interface Cell { t: number; a: number; e: number }
// an expense booked on a line that is not on the sheet (an old name like 'Stand Kirası') still counts: a trip or fair cost goes to the sheet
// line of its kind of cost, anything else to 'Diğer' of its group (or of 'Diğer Giderler'), so the report adds up to every invoice
function sheetLine(e: { grp: string; item: string; trip_id: number | null; exhibition_id: number | null; event_category: string | null; description: string | null }): [string, string] {
  if (validLine(e.grp, e.item)) return [e.grp, e.item];
  const kind: EventKind | null = e.exhibition_id ? 'exhibition' : e.trip_id ? 'trip' : null;
  if (kind) { const c = categoryOf(kind, rowCategory(kind, e)); if (c && validLine(c.grp, c.item)) return [c.grp, c.item]; }
  return validLine(e.grp, 'Diğer') ? [e.grp, 'Diğer'] : ['Diğer Giderler', 'Diğer'];
}
export function report(year: number, market: 'all' | 'export' | 'domestic') {
  const cells = new Map<string, Cell[]>();
  const key = (g: string, i: string) => `${g}|${i}`;
  const get = (g: string, i: string) => cells.get(key(g, i)) ?? (cells.set(key(g, i), Array.from({ length: 12 }, () => ({ t: 0, a: 0, e: 0 }))).get(key(g, i))!);
  for (const t of db.prepare('SELECT market, grp, item, month, amount_eur FROM budget_targets WHERE year = ?').all(year) as { market: string; grp: string; item: string; month: number; amount_eur: number }[]) if (market === 'all' || t.market === market) get(t.grp, t.item)[t.month - 1].t += t.amount_eur;
  for (const e of db.prepare("SELECT market, grp, item, CAST(substr(spent_on, 6, 2) AS INTEGER) m, amount_try, amount_eur, trip_id, exhibition_id, event_category, description FROM budget_expenses WHERE substr(spent_on, 1, 4) = ?").all(String(year)) as { market: string; grp: string; item: string; m: number; amount_try: number; amount_eur: number; trip_id: number | null; exhibition_id: number | null; event_category: string | null; description: string | null }[]) { if (market !== 'all' && e.market !== market) continue; const [g, i] = sheetLine(e); const c = get(g, i)[e.m - 1]; c.a += e.amount_try; c.e += e.amount_eur; }
  const groups = BUDGET_LINES.map((g) => ({
    grp: g.grp,
    items: g.items.map((it) => { const c = get(g.grp, it); return { item: it, months: c.map((x) => ({ t: r2(x.t), a: r2(x.a), e: r2(x.e) })), t: r2(c.reduce((s, x) => s + x.t, 0)), a: r2(c.reduce((s, x) => s + x.a, 0)), e: r2(c.reduce((s, x) => s + x.e, 0)) }; }),
  }));
  const sum = (f: (x: { t: number; a: number; e: number }) => number) => Array.from({ length: 12 }, (_, m) => r2(groups.reduce((s, g) => s + g.items.reduce((s2, i) => s2 + f(i.months[m]), 0), 0)));
  const totals = { t: sum((x) => x.t), a: sum((x) => x.a), e: sum((x) => x.e) };
  const byTrip = db.prepare(`SELECT e.trip_id, COALESCE(t.title, '(no trip)') AS title, COUNT(*) n, SUM(e.amount_try) tl, SUM(e.amount_eur) eur FROM budget_expenses e LEFT JOIN trips t ON t.id = e.trip_id WHERE substr(e.spent_on, 1, 4) = ? ${market === 'all' ? '' : 'AND e.market = ?'} AND e.trip_id IS NOT NULL GROUP BY e.trip_id ORDER BY tl DESC`).all(...(market === 'all' ? [String(year)] : [String(year), market])) as { trip_id: number; title: string; n: number; tl: number; eur: number }[];
  const byCountry = db.prepare(`SELECT COALESCE(NULLIF(country, ''), '(no country)') AS country, COUNT(*) n, SUM(amount_try) tl, SUM(amount_eur) eur FROM budget_expenses WHERE substr(spent_on, 1, 4) = ? ${market === 'all' ? '' : 'AND market = ?'} GROUP BY 1 ORDER BY tl DESC`).all(...(market === 'all' ? [String(year)] : [String(year), market])) as { country: string; n: number; tl: number; eur: number }[];
  return { year, market, groups, totals, totalTarget: r2(totals.t.reduce((a, b) => a + b, 0)), totalTry: r2(totals.a.reduce((a, b) => a + b, 0)), totalEur: r2(totals.e.reduce((a, b) => a + b, 0)), byTrip: byTrip.map((x) => ({ ...x, tl: r2(x.tl), eur: r2(x.eur) })), byCountry: byCountry.map((x) => ({ ...x, tl: r2(x.tl), eur: r2(x.eur) })) };
}
router.get('/report', (req, res) => { const m = String(req.query.market); res.json(report(Number(req.query.year) || new Date().getFullYear(), m === 'export' || m === 'domestic' ? m : 'all')); });

const MONTHS_TR = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
router.get('/report.xlsx', async (req, res) => {
  try {
    const year = Number(req.query.year) || new Date().getFullYear();
    const wb = new ExcelJS.Workbook(); wb.creator = 'TECE CRM';
    const border = { top: { style: 'thin' as const, color: { argb: 'FFD0D0D0' } }, left: { style: 'thin' as const, color: { argb: 'FFD0D0D0' } }, bottom: { style: 'thin' as const, color: { argb: 'FFD0D0D0' } }, right: { style: 'thin' as const, color: { argb: 'FFD0D0D0' } } };
    const sheet = (name: string, title: string, market: 'all' | 'export' | 'domestic') => {
      const rep = report(year, market); const ws = wb.addWorksheet(name);
      ws.getColumn(1).width = 52; for (let c = 2; c <= 27; c++) ws.getColumn(c).width = 13;
      ws.getCell('A1').value = `${title} ${year}`; ws.getCell('A1').font = { bold: true, size: 13, name: 'Arial' };
      const h2 = ws.getRow(2), h3 = ws.getRow(3);
      MONTHS_TR.forEach((m, i) => { ws.mergeCells(2, 2 + i * 2, 2, 3 + i * 2); h2.getCell(2 + i * 2).value = m; h3.getCell(2 + i * 2).value = 'Hedef (€)'; h3.getCell(3 + i * 2).value = 'Gerçekleşen (₺)'; });
      ws.mergeCells(2, 26, 2, 27); h2.getCell(26).value = 'TOPLAM'; h3.getCell(26).value = 'Hedef (€)'; h3.getCell(27).value = 'Gerçekleşen (₺)'; h3.getCell(1).value = '';
      [h2, h3].forEach((r) => r.eachCell({ includeEmpty: true }, (c) => { c.font = { bold: true, size: 10, name: 'Arial' }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFFF00' } }; c.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true }; c.border = border; }));
      let r = 4;
      for (const g of rep.groups) {
        const gt = g.items.reduce((s, i) => s + i.t, 0), ga = g.items.reduce((s, i) => s + i.a, 0);
        const gr = ws.getRow(r++); gr.getCell(1).value = g.grp; gr.getCell(1).font = { bold: true, size: 10, name: 'Arial' };
        for (let m = 0; m < 12; m++) { gr.getCell(2 + m * 2).value = g.items.reduce((s, i) => s + i.months[m].t, 0) || null; gr.getCell(3 + m * 2).value = g.items.reduce((s, i) => s + i.months[m].a, 0) || null; }
        gr.getCell(26).value = gt || null; gr.getCell(27).value = ga || null;
        gr.eachCell({ includeEmpty: true }, (c) => { c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFEDEDED' } }; c.border = border; c.font = { bold: true, size: 10, name: 'Arial' }; if (Number(c.col) > 1) c.numFmt = '#,##0.00;(#,##0.00);-'; });
        for (const it of g.items) {
          const row = ws.getRow(r++); row.getCell(1).value = '   ' + it.item;
          for (let m = 0; m < 12; m++) { row.getCell(2 + m * 2).value = it.months[m].t || null; row.getCell(3 + m * 2).value = it.months[m].a || null; }
          row.getCell(26).value = it.t || null; row.getCell(27).value = it.a || null;
          row.eachCell({ includeEmpty: true }, (c) => { c.border = border; c.font = { size: 10, name: 'Arial' }; if (Number(c.col) > 1) c.numFmt = '#,##0.00;(#,##0.00);-'; });
        }
      }
      const tr = ws.getRow(r + 1); tr.getCell(1).value = 'GENEL TOPLAM';
      for (let m = 0; m < 12; m++) { tr.getCell(2 + m * 2).value = rep.totals.t[m] || null; tr.getCell(3 + m * 2).value = rep.totals.a[m] || null; }
      tr.getCell(26).value = rep.totalTarget || null; tr.getCell(27).value = rep.totalTry || null;
      tr.eachCell({ includeEmpty: true }, (c) => { c.font = { bold: true, size: 10, name: 'Arial' }; c.border = border; if (Number(c.col) > 1) c.numFmt = '#,##0.00;(#,##0.00);-'; });
      ws.views = [{ state: 'frozen', xSplit: 1, ySplit: 3 }];
    };
    sheet('TOPLAM', 'TOPLAM Pazarlama Bütçesi', 'all'); sheet('Yurt içi', 'YURT İÇİ Pazarlama Bütçesi', 'domestic'); sheet('Yurt dışı', 'YURT DIŞI Pazarlama Bütçesi', 'export');
    // every invoice
    const ex = wb.addWorksheet('Harcama Listesi');
    const cols = ['Fatura Tarihi', 'Pazar', 'Bütçe Grubu', 'Bütçe Kalemi', 'Tedarikçi', 'Fatura No', 'Hesap Kodu', 'Açıklama', 'Para Birimi', 'Tutar', 'Kur (₺/€)', 'Tutar (₺)', 'Tutar (€)', 'Gezi', 'Müşteri', 'Ülke', 'Fuar', 'Giren'];
    const hr = ex.getRow(1); hr.values = cols; hr.eachCell((c) => { c.font = { bold: true, size: 10, name: 'Arial' }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFFF00' } }; c.border = border; c.alignment = { wrapText: true, vertical: 'middle' }; });
    const widths = [12, 10, 26, 34, 24, 14, 14, 36, 8, 14, 9, 14, 14, 26, 26, 16, 22, 16]; widths.forEach((w, i) => { ex.getColumn(i + 1).width = w; });
    (db.prepare(`${SELECT} WHERE substr(e.spent_on, 1, 4) = ? ORDER BY e.spent_on, e.id`).all(String(year)) as Record<string, unknown>[]).forEach((e, i) => {
      const row = ex.getRow(i + 2);
      row.values = [new Date(`${String(e.spent_on)}T00:00:00Z`), e.market === 'domestic' ? 'Yurt içi' : 'Yurt dışı', e.grp, e.item, e.supplier, e.invoice_no, e.account_code, e.description, e.currency, e.amount, e.rate, e.amount_try, e.amount_eur, e.trip_title, e.customer, e.country, e.fair, e.entered_name] as ExcelJS.CellValue[];
      row.eachCell({ includeEmpty: true }, (c) => { c.border = border; c.font = { size: 10, name: 'Arial' }; });
      row.getCell(1).numFmt = 'dd.mm.yyyy'; [10, 12, 13].forEach((c) => { row.getCell(c).numFmt = '#,##0.00;(#,##0.00);-'; });
    });
    ex.views = [{ state: 'frozen', ySplit: 1 }]; ex.autoFilter = { from: 'A1', to: { row: 1, column: cols.length } };
    // by trip
    const rep = report(year, 'all'); const tr = wb.addWorksheet('Gezi Bazında');
    tr.columns = [{ width: 44 }, { width: 10 }, { width: 16 }, { width: 16 }];
    const th = tr.getRow(1); th.values = ['Gezi', 'Fatura', 'Tutar (₺)', 'Tutar (€)']; th.eachCell((c) => { c.font = { bold: true, size: 10, name: 'Arial' }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFFF00' } }; c.border = border; });
    rep.byTrip.forEach((x, i) => { const row = tr.getRow(2 + i); row.values = [x.title, x.n, x.tl, x.eur]; row.eachCell((c) => { c.border = border; c.font = { size: 10, name: 'Arial' }; }); row.getCell(3).numFmt = '#,##0.00'; row.getCell(4).numFmt = '#,##0.00'; });
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="Pazarlama-Butcesi-${year}.xlsx"`);
    res.send(Buffer.from(await wb.xlsx.writeBuffer()));
  } catch (e) { console.error('Budget report failed:', e); fail(res, e); }
});

export default router;
