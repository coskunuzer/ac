import { db } from '../db/connection';
import { applyImport, asc, listForwarders, matchPlace, processRows, saveForwarder, type Mode } from './shipPlaces';

// Loads the history of the OLD Nakliye app (exported to JSON by tools/export-old-nakliye.cjs) into the new tables. Nothing is deleted anywhere;
// a request that is already here (same number) is skipped, so the import can be run again safely. Everything loaded is marked imported = 1.
type Row = Record<string, unknown>;
export interface OldExport { tables: Record<string, Row[]> }
export interface OldReport { firmsAdded: number; firmsUpdated: number; unknownPlaces: string[]; requests: number; skipped: number; quotes: number; events: number; messages: number; extraFirms: number }

const MODE: Record<string, Mode> = { Road: 'Karayolu', SeaContainer: 'Denizyolu (Konteyner)', SeaLcl: 'Denizyolu (LCL)', Air: 'Havayolu' };
const key = (s: unknown) => asc(String(s ?? '')).replace(/[^a-z0-9]/g, '');
const str = (v: unknown) => (v === null || v === undefined ? '' : String(v).trim());
const num = (v: unknown): number | null => { const n = Number(v); return v === null || v === undefined || v === '' || !Number.isFinite(n) ? null : n; };
const iso = (v: unknown): string | null => { const d = v ? new Date(String(v)) : null; return d && !Number.isNaN(d.getTime()) ? d.toISOString().slice(0, 19).replace('T', ' ') : null; };
const money = (c: unknown): string | null => { const s = str(c).toLowerCase(); if (/^(€|eur|euro)/.test(s)) return 'EUR'; if (/^(\$|usd|dolar|dollar)/.test(s)) return 'USD'; if (/^(₺|try|tl|lira)/.test(s)) return 'TRY'; return null; };
const EVENT_TEXT: Record<string, string> = { SupplierQuoted: 'Firma fiyat verdi', SupplierRevised: 'Firma fiyatını güncelledi', Rejected: 'Teklif reddedildi', CounterOffered: 'Karşı teklif yapıldı', Accepted: 'Teklif kabul edildi', RejectedOnClose: 'Talep kapanınca reddedildi', ManualPriceConfirmed: 'Fiyat elle girildi', ManualReplySent: 'Firmaya elle yanıt gönderildi' };

export function importOld(data: OldExport, userId: number | null): OldReport {
  const t = data.tables ?? {};
  const rep: OldReport = { firmsAdded: 0, firmsUpdated: 0, unknownPlaces: [], requests: 0, skipped: 0, quotes: 0, events: 0, messages: 0, extraFirms: 0 };

  // 1) the firm list (through the same cleaning and merging as an Excel upload)
  const comp = t.Companies ?? [];
  if (comp.length) {
    const rows: string[][] = [['Firma', 'Ülke', 'E-posta', 'Taşıma türü'], ...comp.map((c) => [str(c.CompanyName), str(c.Country), str(c.Email), MODE[str(c.TransportType)] ?? str(c.TransportType)])];
    const res = processRows(rows);
    if (res) { const r = applyImport(res, {}); rep.firmsAdded = r.added; rep.firmsUpdated = r.updated; rep.unknownPlaces = res.unknown; }
  }

  // 2) the firm of each name (a firm that took part in a request but is not in the list is added as a passive one, so its history has a place)
  const byKey = new Map(listForwarders().map((f) => [key(f.name), f]));
  const firmId = (name: string, email: string, mode: Mode): number => {
    const hit = byKey.get(key(name));
    if (hit) return hit.id;
    const id = saveForwarder(null, { name, emails: [email || 'bilinmiyor@example.invalid'], modes: [mode], active: false, covAll: true, note: 'Eski uygulamadan: aktif listede yoktu' });
    byKey.set(key(name), listForwarders().find((f) => f.id === id)!);
    rep.extraFirms += 1;
    return id;
  };

  db.exec('BEGIN');
  try {
    const exists = db.prepare('SELECT 1 FROM ship_requests WHERE id = ?');
    const insReq = db.prepare("INSERT INTO ship_requests (id, original_text, country, country_iso, mode, pallets, status, archived, imported, closed_at, created_at) VALUES (?, ?, ?, ?, ?, ?, 'closed', ?, 1, ?, ?)");
    const insFw = db.prepare('INSERT OR IGNORE INTO ship_request_fw (request_id, forwarder_id, forwarder_name, emails, lang, sent_at, answered_at, cancelled_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    const insQ = db.prepare("INSERT INTO ship_quotes (request_id, forwarder_id, forwarder_name, sender_email, base, extra, total, currency, out_items, status, review_reason, counter, imported, received_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)");
    const insEv = db.prepare('INSERT INTO ship_events (request_id, quote_id, kind, text, imported, created_at) VALUES (?, ?, ?, ?, 1, ?)');
    const insMsg = db.prepare("INSERT OR IGNORE INTO ship_messages (direction, kind, request_id, forwarder_id, address, subject, body, msg_key, status, created_at) VALUES ('in', 'reply', ?, ?, ?, ?, ?, ?, 'stored', ?)");

    const quotesByReq = new Map<string, Row[]>();
    for (const q of t.ReceivedQuotes ?? []) { const k = str(q.RequestId); quotesByReq.set(k, [...(quotesByReq.get(k) ?? []), q]); }
    const newQuoteId = new Map<unknown, number>(); // the old quote id -> the new one

    for (const r of t.FreightRequests ?? []) {
      const id = str(r.Id);
      if (!id || exists.get(id)) { rep.skipped += 1; continue; }
      const recips = (t.FreightRequestRecipients ?? []).filter((x) => str(x.RequestId) === id);
      const modes = recips.map((x) => MODE[str(x.TransportType)]).filter(Boolean) as Mode[];
      const mode = ([...new Set(modes)].sort((a, b) => modes.filter((m) => m === b).length - modes.filter((m) => m === a).length)[0] ?? 'Karayolu') as Mode;
      const place = matchPlace(str(r.DestinationCountry));
      const created = /^\d{8}/.test(id) ? `${id.slice(0, 4)}-${id.slice(4, 6)}-${id.slice(6, 8)} 09:00:00` : iso(r.DeletedAt) ?? new Date().toISOString().slice(0, 19).replace('T', ' ');
      const quotes = quotesByReq.get(id) ?? [];
      const lastQ = quotes.map((q) => iso(q.DateReceived) ?? iso(q.FirstSeenAt)).filter(Boolean).sort().pop() ?? created;
      insReq.run(id, str(r.CargoDetails) || `(eski kayıt) ${str(r.DestinationCountry)}`, str(r.DestinationCountry), place?.type === 'country' ? place.iso : null, mode, num(r.TotalPallets), /^test$/i.test(str(r.DestinationCountry)) ? 1 : 0, lastQ, created);
      rep.requests += 1;

      for (const x of recips) {
        const m = MODE[str(x.TransportType)] ?? mode;
        const answered = quotes.find((q) => key(q.CompanyName) === key(x.CompanyName));
        insFw.run(id, firmId(str(x.CompanyName), str(x.Email), m), str(x.CompanyName), JSON.stringify(str(x.Email) ? [str(x.Email).toLowerCase()] : []), 'tr', created, answered ? iso(answered.FirstSeenAt) ?? iso(answered.DateReceived) : null, iso(x.CancellationNotifiedAt));
      }
      let accepted: number | null = null;
      for (const q of quotes) {
        const total = num(q.TotalFreightAllIn), base = num(q.BaseFreight);
        const status = str(q.Status) === 'Accepted' ? 'accepted' : 'rejected';
        const fwId = firmId(str(q.CompanyName), str(q.SenderEmail), mode);
        const when = iso(q.DateReceived) ?? iso(q.FirstSeenAt) ?? created;
        const qid = Number(insQ.run(id, fwId, str(q.CompanyName), str(q.SenderEmail).toLowerCase() || null, base, total !== null && base !== null && total > base ? Math.round((total - base) * 100) / 100 : null, total, money(q.Currency), str(q.ExcludedItems) || null, status, str(q.ReviewReason) || null, num(q.LastCounterPrice), when, when).lastInsertRowid);
        newQuoteId.set(q.Id, qid);
        if (status === 'accepted') accepted = qid;
        rep.quotes += 1;
        if (str(q.EmailBody)) { insMsg.run(id, fwId, str(q.SenderEmail).toLowerCase() || null, str(q.EmailSubject) || null, str(q.EmailBody), `old-q-${q.Id}`, when); rep.messages += 1; }
      }
      if (accepted) db.prepare('UPDATE ship_requests SET accepted_quote = ? WHERE id = ?').run(accepted, id);
    }
    for (const e of t.QuoteEvents ?? []) {
      const q = newQuoteId.get(e.QuoteId);
      if (q === undefined) continue; // belongs to a request that was skipped (already here)
      const price = num(e.Price);
      insEv.run(str(e.RequestId), q, str(e.Kind), `${EVENT_TEXT[str(e.Kind)] ?? str(e.Kind)}${price !== null ? ` (${price} ${money(e.Currency) ?? ''})`.replace(' )', ')') : ''}${str(e.Note) ? `: ${str(e.Note)}` : ''}`, iso(e.OccurredAt) ?? new Date().toISOString().slice(0, 19).replace('T', ' '));
      rep.events += 1;
    }
    db.exec('COMMIT');
  } catch (err) { db.exec('ROLLBACK'); throw err; }
  if (userId) db.prepare("INSERT INTO ship_events (request_id, kind, text, user_id, imported) VALUES (NULL, 'import', ?, ?, 0)").run(`Eski uygulamadan ${rep.requests} talep, ${rep.quotes} teklif aktarıldı`, userId);
  return rep;
}
