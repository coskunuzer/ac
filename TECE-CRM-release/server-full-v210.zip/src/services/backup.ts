import fs from 'fs';
import path from 'path';
import archiver from 'archiver';
import ExcelJS from 'exceljs';
import type { Response } from 'express';
import { db } from '../db/connection';
import { cardModel, isJustLead, type CardRow } from '../models/cardModel';
import { customerFilesRoot, safeName, syncCustomerFolder, NO_PERSON_FOLDER } from './customerFiles';
import { archiveFile, type ArchiveRow } from './archive';
import { filePath as priceListFile } from './priceBook/store';
import type { PriceListRow } from '../models/pricingModels';

// The full backup (an admin only): one zip with
//   Customers.xlsx           every customer in the list: "Customers" (the people we work with), "Leads" (the potential customers that were checked or
//                            not: only here, one row each, no folder), "People" (the other persons of the companies), "Offers sent", "Notes", "Complaints"
//   <sales person>/...       for every customer that is not a plain lead: the folder with the scan, the details and every offer / proforma PDF
//   _Price lists/            every price workbook that was uploaded, and every price-list PDF that was made
const date = () => new Date().toISOString().slice(0, 10);

interface Row { [k: string]: unknown }
const rows = (sql: string, ...args: (string | number)[]) => db.prepare(sql).all(...args) as unknown as Row[];

const CARD_COLUMNS: [string, string, number][] = [
  ['ID', 'id', 8], ['Company', 'company', 38], ['Contact', 'name', 24], ['Position', 'position', 20], ['E-mail', 'email', 32], ['Telephone', 'tel', 18], ['Mobile', 'mobile', 18], ['Fax', 'fax', 14],
  ['Web site', 'website', 30], ['Address', 'address', 32], ['Country', 'country', 16], ['City', 'city', 16], ['Team', 'market', 10], ['Step', 'stage', 12], ['Responsible', 'person', 18],
  ['Own rating', 'rate', 9], ['AI rating', 'ai_rate', 9], ['SAP number', 'sap', 12], ['Interested in', 'interested_in', 24], ['Fair or list', 'fair', 24], ['Offers sent', 'offers', 9],
  ['Last contact', 'last_contact', 18], ['Notes', 'notes', 50], ['Added', 'created_at', 18], ['Folder', 'folder', 50],
];

function sheet(wb: ExcelJS.Workbook, name: string, cols: [string, string, number][], data: Row[]) {
  const ws = wb.addWorksheet(name, { views: [{ state: 'frozen', ySplit: 1 }] });
  ws.columns = cols.map(([header, , width]) => ({ header, width }));
  ws.getRow(1).font = { bold: true };
  for (const r of data) ws.addRow(cols.map(([, key]) => r[key] ?? ''));
  ws.autoFilter = { from: { row: 1, column: 1 }, to: { row: 1, column: cols.length } };
}

export async function streamBackup(res: Response): Promise<void> {
  const zip = archiver('zip', { zlib: { level: 6 } });
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', `attachment; filename="TECE-full-backup-${date()}.zip"`);
  zip.on('error', (err) => { console.error('Backup failed:', err); res.destroy(err); });
  zip.pipe(res);

  const all = rows(
    `SELECT c.*, e.name AS fair, (SELECT COUNT(*) FROM offers_sent o WHERE o.card_id = c.id AND o.kind = 'offer') AS offers,
            (SELECT MAX(a.created_at) FROM activities a WHERE a.card_id = c.id AND a.type IN ('note', 'call', 'visit', 'meeting', 'sample')) AS last_contact
     FROM cards c LEFT JOIN exhibitions e ON e.id = c.exhibition_id ORDER BY c.id`
  );
  const customers: Row[] = [];
  const leads: Row[] = [];
  const foldered: CardRow[] = [];
  for (const r of all) {
    const card = r as unknown as CardRow;
    if (isJustLead(card)) leads.push(r);
    else { customers.push(r); foldered.push(card); }
  }

  // the folders of the customers (not of the leads), under the sales person
  const folderOf = new Map<number, string>();
  const root = customerFilesRoot;
  for (const card of foldered) {
    const dir = syncCustomerFolder(card.id);
    if (!dir || !fs.existsSync(dir)) continue;
    const rel = path.relative(root, dir);
    folderOf.set(card.id, rel);
    zip.directory(dir, rel.split(path.sep).join('/'));
    // the PDFs of the proformas that were made (kept in the archive) go in the same folder
    for (const a of rows("SELECT * FROM document_archive WHERE kind = 'proforma' AND card_id = ? ORDER BY id", card.id) as unknown as ArchiveRow[]) {
      const f = archiveFile(a);
      if (fs.existsSync(f)) zip.file(f, { name: `${rel.split(path.sep).join('/')}/Proformas/${a.created_at.slice(0, 10)} ${safeName(a.file_name, 70)}` });
    }
  }
  for (const r of customers) r.folder = folderOf.get(r.id as number) ?? '';

  const wb = new ExcelJS.Workbook();
  wb.creator = 'TECE CRM';
  sheet(wb, 'Customers', CARD_COLUMNS, customers);
  sheet(wb, 'Leads', CARD_COLUMNS.filter(([, k]) => k !== 'folder'), leads);
  sheet(wb, 'People', [['Customer ID', 'card_id', 12], ['Company', 'company', 34], ['Name', 'name', 20], ['Last name', 'last_name', 20], ['Position', 'position', 20], ['E-mail', 'email', 30], ['Telephone', 'tel', 18], ['Mobile', 'mobile', 18]],
    rows('SELECT p.*, c.company FROM card_contacts p LEFT JOIN cards c ON c.id = p.card_id ORDER BY p.card_id, p.id'));
  sheet(wb, 'Offers sent', [['Customer ID', 'card_id', 12], ['Company', 'company', 34], ['Sent', 'sent_at', 18], ['Kind', 'kind', 12], ['By', 'by', 20], ['Summary', 'summary', 80]],
    rows("SELECT o.card_id, c.company, o.sent_at, o.kind, u.display_name AS by, o.summary FROM offers_sent o LEFT JOIN cards c ON c.id = o.card_id LEFT JOIN users u ON u.id = o.created_by ORDER BY o.id"));
  sheet(wb, 'Notes', [['Customer ID', 'card_id', 12], ['Company', 'company', 34], ['When', 'created_at', 18], ['By', 'by', 20], ['Type', 'type', 12], ['Text', 'text', 90]],
    rows("SELECT a.card_id, c.company, a.created_at, u.display_name AS by, a.type, a.text FROM activities a LEFT JOIN cards c ON c.id = a.card_id LEFT JOIN users u ON u.id = a.user_id WHERE a.imported = 0 AND a.type IN ('note', 'call', 'visit', 'meeting', 'sample', 'email') ORDER BY a.id"));
  sheet(wb, 'Complaints', [['No', 'id', 8], ['Customer', 'customer_name', 30], ['Order no', 'order_no', 16], ['Type', 'kind', 10], ['Amount lost', 'amount_wasted', 12], ['Currency', 'currency', 9], ['Status', 'status', 9], ['Created', 'created_at', 18], ['Text', 'raw_text', 70]],
    rows('SELECT * FROM complaints ORDER BY id'));
  zip.append(Buffer.from(await wb.xlsx.writeBuffer()), { name: 'Customers.xlsx' });

  // price lists: every workbook and every PDF
  for (const pl of rows('SELECT * FROM price_lists ORDER BY id') as unknown as PriceListRow[]) {
    try {
      const f = priceListFile(pl);
      if (fs.existsSync(f)) zip.file(f, { name: `_Price lists/Workbooks/${pl.uploaded_at?.slice(0, 10) ?? ''} (${pl.id}) ${safeName(pl.original_name, 80)}` });
    } catch { /* a missing workbook is left out */ }
  }
  for (const a of rows("SELECT * FROM document_archive WHERE kind = 'price_list' ORDER BY id") as unknown as ArchiveRow[]) {
    const f = archiveFile(a);
    if (fs.existsSync(f)) zip.file(f, { name: `_Price lists/PDFs/${a.created_at.slice(0, 10)} ${safeName(a.file_name, 70)}` });
  }
  zip.append(`TECE CRM full backup, ${new Date().toISOString()}\n\nCustomers.xlsx: all customers ("Customers"), the potential customers ("Leads", no folder), the other people of the companies, offers sent, notes and complaints.\nThe folders are one per sales person (${NO_PERSON_FOLDER} = nobody yet), and only for customers that are not plain leads.\n`, { name: 'README.txt' });
  await zip.finalize();
}

export const backupCount = (): { customers: number; leads: number } => {
  let customers = 0;
  let leads = 0;
  for (const r of rows('SELECT * FROM cards')) (isJustLead(r as unknown as CardRow) ? (leads += 1) : (customers += 1));
  return { customers, leads };
};
void cardModel;
