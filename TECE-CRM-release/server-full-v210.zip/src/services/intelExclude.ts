import { db } from '../db/connection';

// SAP accounts that an admin marked "not a customer" (a supplier that returns material...). They stay in the database; every sales number leaves them out.
export const NOT_EXCLUDED = 'customer NOT IN (SELECT code FROM intel_excluded)';

export interface Excluded { code: string; name: string; reason: string; at: string; by: string | null; total?: number }

export function excludedCodes(): Set<string> {
  return new Set((db.prepare('SELECT code FROM intel_excluded').all() as { code: string }[]).map((r) => r.code));
}

export function listExcluded(): Excluded[] {
  return db.prepare(`SELECT e.code, COALESCE(c.name, '') name, e.reason, e.at, COALESCE(NULLIF(u.display_name, ''), u.username) by,
      (SELECT ROUND(SUM(eur)) FROM intel_fact f WHERE f.customer = e.code) total
    FROM intel_excluded e LEFT JOIN intel_cust c ON c.code = e.code LEFT JOIN users u ON u.id = e.by_user ORDER BY e.at DESC`).all() as unknown as Excluded[];
}

export function setExcluded(code: string, on: boolean, reason: string, userId: number): void {
  const c = String(code || '').trim();
  if (!c) throw new Error('Which account?');
  if (on) db.prepare('INSERT INTO intel_excluded (code, reason, by_user) VALUES (?, ?, ?) ON CONFLICT(code) DO UPDATE SET reason = excluded.reason, by_user = excluded.by_user, at = datetime(\'now\')').run(c, String(reason || '').slice(0, 200), userId);
  else db.prepare('DELETE FROM intel_excluded WHERE code = ?').run(c);
}

const GROUPCOS = /TECE\s*DE[CK]|TEZER/i;
const chOf = (code: string, name: string) => (code.startsWith('1202') ? 0 : code.startsWith('1201') ? 1 : 2) + (GROUPCOS.test(name) ? 10 : 0);

// The month totals (month x channel x product group) are kept without a customer. This is that table with the left-out accounts taken out:
// exactly for the months that are kept per customer; for the older years (kept as a year per customer) the year's amount comes off the months of that year
// in proportion to what that channel and group sold in each month, so the year totals are right and the shape of the months is close.
export interface MonthRow { ym: string; ch: number; grp: string; eur: number; m2: number; meters: number }
export function adjustedMonths(): MonthRow[] {
  const rows = (db.prepare('SELECT ym, ch, grp, SUM(eur) eur, SUM(m2) m2, SUM(meters) meters FROM intel_month GROUP BY ym, ch, grp').all() as unknown as MonthRow[]).map((r) => ({ ...r }));
  if (!(db.prepare('SELECT COUNT(*) n FROM intel_excluded').get() as { n: number }).n) return rows;
  const at = new Map<string, MonthRow>(); for (const r of rows) at.set(`${r.ym}|${r.ch}|${r.grp}`, r);
  const facts = db.prepare(`SELECT f.period, f.customer, COALESCE(c.name, '') name, COALESCE(m.grp, '') grp, SUM(f.eur) eur, SUM(f.m2) m2, SUM(f.meters) meters
    FROM intel_fact f JOIN intel_excluded e ON e.code = f.customer LEFT JOIN intel_cust c ON c.code = f.customer LEFT JOIN intel_mat m ON m.code = f.material
    GROUP BY f.period, f.customer, m.grp`).all() as { period: string; customer: string; name: string; grp: string; eur: number; m2: number; meters: number }[];
  const yearly = new Map<string, { ch: number; grp: string; y: string; eur: number; m2: number; meters: number }>();
  for (const f of facts) {
    const ch = chOf(f.customer, f.name);
    if (f.period.endsWith('-00')) {
      const y = f.period.slice(0, 4), k = `${y}|${ch}|${f.grp}`; const o = yearly.get(k) ?? { ch, grp: f.grp, y, eur: 0, m2: 0, meters: 0 };
      o.eur += f.eur; o.m2 += f.m2; o.meters += f.meters; yearly.set(k, o);
    } else { const r = at.get(`${f.period}|${ch}|${f.grp}`); if (r) { r.eur -= f.eur; r.m2 -= f.m2; r.meters -= f.meters; } }
  }
  for (const o of yearly.values()) {
    const ms = rows.filter((r) => r.ym.startsWith(o.y) && r.ch === o.ch && r.grp === o.grp); const tot = ms.reduce((s, r) => s + r.eur, 0); if (!tot) continue;
    for (const r of ms) { const sh = r.eur / tot; r.eur -= o.eur * sh; r.m2 -= o.m2 * sh; r.meters -= o.meters * sh; }
  }
  return rows;
}
