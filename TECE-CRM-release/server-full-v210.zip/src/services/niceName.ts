// "FONTANA S.R.L" -> "Fontana S.R.L", "LAJTER-BUTOR KFT" -> "Lajter-Butor KFT". Only a name written ENTIRELY in capitals is changed (a name somebody wrote with small letters is never touched),
// and the legal forms and acronyms that are written in capitals everywhere stay as they are.
const KEEP = new Set(['LLC', 'SRL', 'SA', 'AG', 'KFT', 'FZCO', 'FZE', 'DOO', 'OOO', 'JSC', 'PJSC', 'ZOO', 'BV', 'NV', 'AB', 'AS', 'SAS', 'SARL', 'LTDA', 'CIA', 'UAB', 'SIA', 'SPA', 'SRO', 'EOOD', 'LLP', 'PLC', 'KG', 'CV', 'RNC', 'NIT', 'USA', 'UAE', 'UK', 'SP', 'PT', 'MDF', 'PVC', 'ABS', 'DIY', 'HG', 'TECE', 'CRM', 'II', 'III', 'IV', 'SAC', 'EIRL', 'OHG', 'AD', 'DD', 'ASA', 'OY', 'SRL.', 'SCS', 'GIE']);
const SPECIAL: Record<string, string> = { GMBH: 'GmbH', LTD: 'Ltd', INC: 'Inc', CO: 'Co', CORP: 'Corp', LIMITED: 'Limited', COMPANY: 'Company', INT: 'Int', GROUP: 'Group' };
const SMALL = new Set(['DE', 'DEL', 'LA', 'LAS', 'LOS', 'Y', 'E', 'DA', 'DO', 'DOS', 'DI', 'VAN', 'VON', 'DER', 'EL', 'AL', 'BEN', 'BIN']);

const isAllCaps = (s: string): boolean => {
  const letters = s.replace(/[^A-Za-zÀ-ÖØ-öø-ÿĞğİıŞşÇçÖöÜüĀ-ž]/g, '');
  return letters.length >= 3 && letters === letters.toLocaleUpperCase('tr-TR') && letters !== letters.toLocaleLowerCase('tr-TR');
};

// person: a person's name written like 'Abdullah COSKUNUZER' is also fixed word by word
export function niceName(input: string | null | undefined, person = false): string {
  const s = (input ?? '').trim();
  const hasWordCaps = person && /(^|[\s-])[A-ZÇĞİÖŞÜ]{3,}(?=$|[\s-])/.test(s);
  if (!s || (!isAllCaps(s) && !hasWordCaps)) return input ?? '';
  const tr = /[İŞĞÜÖÇ]/.test(s) || /İ/.test(s);
  const lower = (w: string) => w.toLocaleLowerCase(tr ? 'tr-TR' : 'en-US');
  const upper = (w: string) => w.toLocaleUpperCase(tr ? 'tr-TR' : 'en-US');
  let first = true;
  return s.replace(/[^\s/&,()\-.«»"“”]+|[\s/&,()\-.«»"“”]+/g, (tok) => {
    if (!/[^\s/&,()\-.«»"“”]/.test(tok)) return tok; // separators stay
    const w = tok;
    const isFirst = first; first = false;
    const key = w.toUpperCase();
    if (KEEP.has(key)) return w;
    if (SPECIAL[key]) return SPECIAL[key];
    if (/\d/.test(w)) return w; // 17K, A4 ...
    if (!isFirst && SMALL.has(key)) return lower(w);
    if (w.length === 1) return w; // a single letter (S.R.L, J.P.)
    // in a person's name only the words written in capitals change
    if (person && !isAllCaps(s) && w !== key) return w;
    const parts = w.split("'");
    return parts.map((p, i) => (i > 0 && p.length > 1 && parts[i - 1].length === 1 ? upper(p[0]) + lower(p.slice(1)) : upper(p.slice(0, 1)) + lower(p.slice(1)))).join("'");
  });
}
