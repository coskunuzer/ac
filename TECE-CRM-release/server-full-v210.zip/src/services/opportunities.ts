import { db } from '../db/connection';
import { settingsModel } from '../models/settingsModel';
import { cardModel } from '../models/cardModel';
import { canSeeCard, type Viewer } from './visibility';
import { sendNotice } from './quality';
import { userModel } from '../models/userModel';
import { audit, type Actor } from './audit';

// Opportunities: an offer or a proforma that went to a customer, followed until it is won or lost. Made by itself when an offer or proforma is e-mailed (or by hand).
// A reminder shows when nobody answered for a while. Nothing here talks to SAP: a SAP order is linked by its number (from the files that are uploaded).
export interface Opp {
  id: number; card_id: number; kind: string; title: string; value: number | null; currency: string; status: 'open' | 'won' | 'lost'; expected_date: string | null;
  sap_order_no: string | null; lost_reason: string | null; competitor: string | null; note: string | null; source_ref: string | null; created_by: number | null; created_at: string; closed_at: string | null; snoozed_until: string | null;
}
const today = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });
const addDays = (iso: string, n: number) => { const d = new Date(`${iso}T00:00:00Z`); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const intSetting = (k: string, d: number, lo: number, hi: number) => { const n = parseInt(settingsModel.get(k) ?? '', 10); return Number.isFinite(n) ? Math.max(lo, Math.min(hi, n)) : d; };
export const followUpDays = () => intSetting('opp_followup_days', 7, 1, 90);
export const expectedDays = () => intSetting('opp_expected_days', 30, 1, 365);
export const setOppSettings = (followup: number, expected: number) => { settingsModel.set('opp_followup_days', String(Math.max(1, Math.min(90, Math.round(followup))))); settingsModel.set('opp_expected_days', String(Math.max(1, Math.min(365, Math.round(expected))))); };

export function addOpportunity(i: { cardId: number; kind: 'offer' | 'proforma' | 'other'; title: string; value?: number | null; currency?: string; expected?: string | null; sourceRef?: string | null; userId?: number | null; note?: string | null }): number | null {
  try {
    if (i.sourceRef) { const ex = db.prepare('SELECT id FROM opportunities WHERE source_ref = ?').get(i.sourceRef) as { id: number } | undefined; if (ex) return ex.id; }
    const r = db.prepare('INSERT INTO opportunities (card_id, kind, title, value, currency, expected_date, source_ref, created_by, note) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
      .run(i.cardId, i.kind, i.title.slice(0, 160), i.value && Number.isFinite(i.value) ? Math.round(i.value * 100) / 100 : null, i.currency === 'USD' ? 'USD' : 'EUR', i.expected && /^\d{4}-\d{2}-\d{2}$/.test(i.expected) ? i.expected : addDays(today(), expectedDays()), i.sourceRef ?? null, i.userId ?? null, i.note?.slice(0, 400) ?? null);
    return Number(r.lastInsertRowid);
  } catch (err) { console.error('Opportunity not made:', err); return null; }
}

export const oppsOfCard = (cardId: number): Opp[] => db.prepare("SELECT * FROM opportunities WHERE card_id = ? ORDER BY CASE status WHEN 'open' THEN 0 ELSE 1 END, id DESC").all(cardId) as unknown as Opp[];

export function updateOpportunity(id: number, p: Record<string, unknown>, user: Actor): Opp | null {
  const o = db.prepare('SELECT * FROM opportunities WHERE id = ?').get(id) as unknown as Opp | undefined;
  if (!o) return null;
  const str = (v: unknown, n: number) => String(v ?? '').trim().slice(0, n) || null;
  const status = p.status === 'won' || p.status === 'lost' || p.status === 'open' ? (p.status as Opp['status']) : o.status;
  const value = p.value === undefined ? o.value : p.value === null || p.value === '' ? null : Number.isFinite(Number(p.value)) ? Math.round(Number(p.value) * 100) / 100 : o.value;
  db.prepare('UPDATE opportunities SET title = ?, value = ?, currency = ?, status = ?, expected_date = ?, sap_order_no = ?, lost_reason = ?, competitor = ?, note = ?, closed_at = ? WHERE id = ?').run(
    p.title === undefined ? o.title : (str(p.title, 160) ?? o.title), value, p.currency === 'USD' ? 'USD' : p.currency === 'EUR' ? 'EUR' : o.currency, status,
    p.expected_date === undefined ? o.expected_date : /^\d{4}-\d{2}-\d{2}$/.test(String(p.expected_date)) ? String(p.expected_date) : null,
    p.sap_order_no === undefined ? o.sap_order_no : str(p.sap_order_no, 40), status === 'lost' ? (p.lost_reason === undefined ? o.lost_reason : str(p.lost_reason, 200)) : null, status === 'lost' ? (p.competitor === undefined ? o.competitor : str(p.competitor, 80)) : null,
    p.note === undefined ? o.note : str(p.note, 400), status === 'open' ? null : (o.closed_at ?? new Date().toISOString().slice(0, 19).replace('T', ' ')), id);
  if (status !== o.status) audit(user, o.card_id, 'change', 'Opportunity', `${o.title}: ${o.status}`, status, status === 'lost' ? `${p.lost_reason ?? ''} ${p.competitor ?? ''}`.trim() : null);
  return db.prepare('SELECT * FROM opportunities WHERE id = ?').get(id) as unknown as Opp;
}
export const snooze = (id: number, days: number) => db.prepare('UPDATE opportunities SET snoozed_until = ? WHERE id = ?').run(addDays(today(), Math.max(1, Math.min(60, days))), id);

// open opportunities nobody answered for N days (no contact logged since they were made, or since the last contact)
export function followUps(viewer: Viewer): (Opp & { customer: string; country: string; days: number; lastContact: string | null })[] {
  const n = followUpDays();
  const rows = db.prepare(`SELECT o.*, COALESCE(c.company, c.name) AS customer, c.country AS country,
      (SELECT MAX(a.created_at) FROM activities a WHERE a.card_id = o.card_id AND a.type IN ('note','call','visit','meeting','email')) AS lastContact
    FROM opportunities o JOIN cards c ON c.id = o.card_id WHERE o.status = 'open' AND COALESCE(o.snoozed_until, '') <= ? ORDER BY o.created_at`).all(today()) as unknown as (Opp & { customer: string; country: string; lastContact: string | null })[];
  const out: (Opp & { customer: string; country: string; days: number; lastContact: string | null })[] = [];
  for (const r of rows) {
    const base = (r.lastContact && r.lastContact > r.created_at ? r.lastContact : r.created_at).slice(0, 10);
    const days = Math.round((Date.parse(today()) - Date.parse(base)) / 86_400_000);
    if (days < n) continue;
    const card = cardModel.findById(r.card_id);
    if (!card || !canSeeCard(viewer, card)) continue;
    out.push({ ...r, days });
  }
  return out.sort((a, b) => b.days - a.days).slice(0, 100);
}

// the forecast (what is open, by month of the expected date), the conversion (won against lost) and why they are lost
export function overview(viewer: Viewer) {
  const all = db.prepare('SELECT o.*, c.country, c.person FROM opportunities o JOIN cards c ON c.id = o.card_id').all() as unknown as (Opp & { country: string | null; person: string | null })[];
  const seen = new Map<number, boolean>();
  const mine = all.filter((o) => { if (!seen.has(o.card_id)) { const c = cardModel.findById(o.card_id); seen.set(o.card_id, !!c && canSeeCard(viewer, c)); } return seen.get(o.card_id); });
  const open = mine.filter((o) => o.status === 'open');
  const closed = mine.filter((o) => o.status !== 'open');
  const month = (s: string | null) => (s ?? '').slice(0, 7) || 'none';
  const f = new Map<string, { month: string; currency: string; count: number; value: number }>();
  for (const o of open) { const k = `${month(o.expected_date)}|${o.currency}`; const x = f.get(k) ?? { month: month(o.expected_date), currency: o.currency, count: 0, value: 0 }; x.count += 1; x.value += o.value ?? 0; f.set(k, x); }
  const conv = (rows: typeof closed) => { const won = rows.filter((o) => o.status === 'won').length; const lost = rows.length - won; return { won, lost, pct: rows.length ? Math.round((won / rows.length) * 100) : null }; };
  const by = (key: (o: typeof closed[number]) => string) => { const m = new Map<string, typeof closed>(); for (const o of closed) { const k = key(o) || '—'; m.set(k, [...(m.get(k) ?? []), o]); } return [...m].map(([name, rows]) => ({ name, ...conv(rows) })).sort((a, b) => b.won + b.lost - (a.won + a.lost)).slice(0, 25); };
  const lostBy = new Map<string, { competitor: string; country: string; n: number }>();
  for (const o of closed.filter((x) => x.status === 'lost' && x.competitor)) { const k = `${o.competitor}|${o.country ?? ''}`; const x = lostBy.get(k) ?? { competitor: o.competitor!, country: o.country ?? '—', n: 0 }; x.n += 1; lostBy.set(k, x); }
  const reasons = new Map<string, number>();
  for (const o of closed.filter((x) => x.status === 'lost' && x.lost_reason)) reasons.set(o.lost_reason!, (reasons.get(o.lost_reason!) ?? 0) + 1);
  return {
    open: open.length, openValue: ['EUR', 'USD'].map((c) => ({ currency: c, value: Math.round(open.filter((o) => o.currency === c).reduce((a, o) => a + (o.value ?? 0), 0)) })).filter((x) => x.value > 0),
    forecast: [...f.values()].sort((a, b) => a.month.localeCompare(b.month)).map((x) => ({ ...x, value: Math.round(x.value) })),
    conversion: conv(closed), byCountry: by((o) => o.country ?? ''), byRep: by((o) => o.person ?? ''),
    lostByCompetitor: [...lostBy.values()].sort((a, b) => b.n - a.n).slice(0, 30), lostReasons: [...reasons].map(([reason, n]) => ({ reason, n })).sort((a, b) => b.n - a.n).slice(0, 12),
    followUpDays: followUpDays(), expectedDays: expectedDays(),
  };
}

// SAP orders of this customer (from the uploaded SAP files) since the opportunity was made: to link one by its number
export function sapCandidates(o: Opp): { orderNo: string; date: string | null; value: number | null; source: string }[] {
  const card = cardModel.findById(o.card_id);
  const sap = (card?.sap ?? '').trim();
  if (!sap) return [];
  const since = addDays(o.created_at.slice(0, 10), -3);
  const out = new Map<string, { orderNo: string; date: string | null; value: number | null; source: string }>();
  for (const r of db.prepare('SELECT order_no AS no, MIN(doc_date) AS d, SUM(value_eur) AS v FROM export_production_backlog WHERE sap_no = ? GROUP BY order_no').all(sap) as { no: string; d: string | null; v: number | null }[]) if (!r.d || r.d >= since) out.set(r.no, { orderNo: r.no, date: r.d, value: r.v, source: 'in production' });
  for (const r of db.prepare('SELECT sd_no AS no, MIN(doc_date) AS d, SUM(net_value) AS v FROM export_pipeline_blockers WHERE sap_no = ? GROUP BY sd_no').all(sap) as { no: string; d: string | null; v: number | null }[]) if (!r.d || r.d >= since) out.set(r.no, { orderNo: r.no, date: r.d, value: r.v, source: 'waiting' });
  for (const r of db.prepare('SELECT sd_no AS no, billing_date AS d, net_value AS v FROM export_dispatch_queue WHERE sap_no = ?').all(sap) as { no: string; d: string | null; v: number | null }[]) if (!r.d || r.d >= since) out.set(r.no, { orderNo: r.no, date: r.d, value: r.v, source: 'ready to ship' });
  // the number of one of this customer's own SAP proformas is the order number too
  const hit = o.sap_order_no ? o.sap_order_no : null;
  if (hit && !out.has(hit)) out.set(hit, { orderNo: hit, date: null, value: null, source: 'typed' });
  return [...out.values()].sort((a, b) => String(b.date).localeCompare(String(a.date))).slice(0, 20);
}

// ---- the price review (Abdullah looks; nobody is stopped) ----------------------------------------------------------------------------------------------
export const reviewThreshold = () => intSetting('price_review_pct', 15, 1, 90);
export function reviewerIds(): number[] {
  const set = (settingsModel.get('price_review_users') ?? '').split(',').map((s) => parseInt(s, 10)).filter((n) => Number.isInteger(n));
  if (set.length) return set;
  const abdullah = userModel.listAll().find((u) => u.is_active && u.role === 'admin' && /^abdullah/i.test(u.display_name ?? ''));
  const any = abdullah ?? userModel.listAll().find((u) => u.is_active && u.role === 'admin');
  return any ? [any.id] : [];
}
export const setReviewerIds = (ids: number[]) => settingsModel.set('price_review_users', ids.filter((n) => Number.isInteger(n)).join(','));

export function priceReview(user: Actor, cardId: number, p: { indexPct: number; gap: number; goods: number; currency: string; note: string }): void {
  try {
    if (p.indexPct > -reviewThreshold()) return;
    const recent = db.prepare("SELECT id FROM price_reviews WHERE card_id = ? AND reviewed_at IS NULL AND created_at >= datetime('now', '-1 day')").get(cardId);
    if (recent) return;
    db.prepare('INSERT INTO price_reviews (card_id, created_by, index_pct, gap, currency, goods, note) VALUES (?, ?, ?, ?, ?, ?, ?)').run(cardId, user.id, p.indexPct, p.gap, p.currency, p.goods, p.note.slice(0, 200));
    audit(user, cardId, 'review', 'Price review', null, `${p.indexPct}% against standard`, p.note);
    const card = cardModel.findById(cardId);
    const to = reviewerIds().map((id) => userModel.findById(id)?.email ?? '').filter(Boolean);
    void sendNotice(to, `Fiyat incelemesi: ${card?.company || card?.name || cardId}`, `Merhaba,\n\n${user.display_name || user.username} ${card?.company || card?.name || ''} için standart fiyatın %${Math.abs(p.indexPct)} altında bir proforma hazırladı (fark: ${Math.round(p.gap)} ${p.currency}).\n\nBu yalnızca bir bilgilendirmedir: iş durdurulmadı. CRM > Performans > Fiyat ve alım ekranından inceleyebilirsiniz.`);
  } catch (err) { console.error('Price review not made:', err); }
}
