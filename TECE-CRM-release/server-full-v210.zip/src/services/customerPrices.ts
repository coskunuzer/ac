import { db } from '../db/connection';


// The prices of an old customer, learned from their SAP proformas (read in the browser, sent here as lines). A product keeps the price of the NEWEST proforma.
// Used only for that customer, only when they have uploaded proformas, and only when the person does not switch it off on the proforma.
export interface DocLine { reference: string; code: string; sap: string; description: string; thickness: number | null; width: number | null; rollLength: number | null; meters: number | null; priceM2: number }
export interface DocInput { proformaNo: string; date: string; customer: string; currency: 'EUR' | 'USD'; adjustPct: number; fileName: string; lines: DocLine[] }

const s = (v: unknown, max: number) => String(v ?? '').trim().slice(0, max);
const n = (v: unknown): number | null => { const x = Number(v); return Number.isFinite(x) ? x : null; };

export function cleanDoc(raw: unknown): DocInput | null {
  const d = (raw ?? {}) as Record<string, unknown>;
  const proformaNo = s(d.proformaNo, 30).replace(/\D/g, '');
  if (!proformaNo) return null;
  const lines: DocLine[] = (Array.isArray(d.lines) ? d.lines : []).slice(0, 600).map((x) => {
    const l = (x ?? {}) as Record<string, unknown>;
    return { reference: s(l.reference, 80), code: s(l.code, 40), sap: s(l.sap, 30), description: s(l.description, 160), thickness: n(l.thickness), width: n(l.width), rollLength: n(l.rollLength), meters: n(l.meters), priceM2: Number(l.priceM2) };
  }).filter((l) => l.sap && Number.isFinite(l.priceM2) && l.priceM2 > 0 && l.priceM2 < 10000);
  if (!lines.length) return null;
  const pct = n(d.adjustPct) ?? 0;
  return {
    proformaNo, date: /^\d{4}-\d{2}-\d{2}$/.test(s(d.date, 10)) ? s(d.date, 10) : '', customer: s(d.customer, 160), currency: d.currency === 'USD' ? 'USD' : 'EUR',
    adjustPct: Math.abs(pct) <= 100 ? Math.round(pct * 100) / 100 : 0, fileName: s(d.fileName, 160), lines,
  };
}

// the prices of a customer: the newest proforma wins for every product
function rebuild(cardId: number): void {
  const docs = db.prepare('SELECT id, doc_date, currency, lines_json FROM customer_price_docs WHERE card_id = ? ORDER BY COALESCE(doc_date, \'\'), proforma_no').all(cardId) as { id: number; doc_date: string | null; currency: string; lines_json: string }[];
  const put = db.prepare('INSERT OR REPLACE INTO customer_prices (card_id, sap, currency, price_m2, description, doc_id, doc_date) VALUES (?, ?, ?, ?, ?, ?, ?)');
  db.exec('BEGIN');
  try {
    db.prepare('DELETE FROM customer_prices WHERE card_id = ?').run(cardId);
    for (const d of docs) for (const l of JSON.parse(d.lines_json) as DocLine[]) put.run(cardId, l.sap, d.currency, l.priceM2, l.description || null, d.id, d.doc_date);
    db.exec('COMMIT');
  } catch (err) { db.exec('ROLLBACK'); throw err; }
}

// the same proforma uploaded again (v2, v3 ...) replaces the earlier one
export function importDocs(cardId: number, docs: DocInput[], userId: number): { docs: number; lines: number } {
  const up = db.prepare(`INSERT INTO customer_price_docs (card_id, proforma_no, doc_date, currency, adjust_pct, customer_name, file_name, lines_json, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(card_id, proforma_no) DO UPDATE SET doc_date = excluded.doc_date, currency = excluded.currency, adjust_pct = excluded.adjust_pct, customer_name = excluded.customer_name, file_name = excluded.file_name, lines_json = excluded.lines_json, created_by = excluded.created_by, created_at = datetime('now')`);
  let lines = 0;
  for (const d of docs) { up.run(cardId, d.proformaNo, d.date || null, d.currency, d.adjustPct, d.customer || null, d.fileName || null, JSON.stringify(d.lines), userId); lines += d.lines.length; }
  rebuild(cardId);
  return { docs: docs.length, lines };
}

export function removeDoc(cardId: number, docId: number): void {
  db.prepare('DELETE FROM customer_price_docs WHERE id = ? AND card_id = ?').run(docId, cardId);
  rebuild(cardId);
}

export interface Memory { count: number; docs: { id: number; proformaNo: string; date: string | null; currency: string; adjustPct: number; lines: number; fileName: string | null }[]; latest: { proformaNo: string; date: string | null; currency: string; adjustPct: number } | null }
export function memoryFor(cardId: number): Memory {
  const docs = (db.prepare("SELECT id, proforma_no, doc_date, currency, adjust_pct, file_name, lines_json FROM customer_price_docs WHERE card_id = ? ORDER BY COALESCE(doc_date, '') DESC, proforma_no DESC").all(cardId) as { id: number; proforma_no: string; doc_date: string | null; currency: string; adjust_pct: number; file_name: string | null; lines_json: string }[])
    .map((d) => ({ id: d.id, proformaNo: d.proforma_no, date: d.doc_date, currency: d.currency, adjustPct: d.adjust_pct, lines: (JSON.parse(d.lines_json) as unknown[]).length, fileName: d.file_name }));
  const count = (db.prepare('SELECT COUNT(*) AS n FROM customer_prices WHERE card_id = ?').get(cardId) as { n: number }).n;
  const l = docs[0];
  return { count, docs, latest: l ? { proformaNo: l.proformaNo, date: l.date, currency: l.currency, adjustPct: l.adjustPct } : null };
}

export function priceMap(cardId: number, currency: string): Record<string, number> {
  const o: Record<string, number> = {};
  for (const r of db.prepare('SELECT sap, price_m2 FROM customer_prices WHERE card_id = ? AND currency = ?').all(cardId, currency) as { sap: string; price_m2: number }[]) o[r.sap] = r.price_m2;
  return o;
}

// the lines of an earlier order, to start the next one from it
export function docLines(cardId: number, docId: number): { doc: { proformaNo: string; date: string | null; currency: string; adjustPct: number }; lines: DocLine[] } | null {
  const d = db.prepare('SELECT proforma_no, doc_date, currency, adjust_pct, lines_json FROM customer_price_docs WHERE id = ? AND card_id = ?').get(docId, cardId) as { proforma_no: string; doc_date: string | null; currency: string; adjust_pct: number; lines_json: string } | undefined;
  return d ? { doc: { proformaNo: d.proforma_no, date: d.doc_date, currency: d.currency, adjustPct: d.adjust_pct }, lines: JSON.parse(d.lines_json) as DocLine[] } : null;
}
