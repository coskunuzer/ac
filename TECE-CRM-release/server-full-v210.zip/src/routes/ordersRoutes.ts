import { Router } from 'express';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { accountOfSap, overview, usdPerEur } from '../services/perfAnalytics';
import { sapAsOf } from '../services/todayQueue';

// Orders and dispatch: three stages, from the SAP files - waiting for confirmation (or the advance), in production, ready to dispatch.
// Old items are kept apart from current ones, so a lot that has sat for months does not hide today's work. Reads only.
const router = Router();
router.use(requireAuth);

const OLD_WAITING_DAYS = 90; // waiting for confirmation / the advance for longer than this
const OLD_DELIVERY_DAYS = 30; // the delivery date passed more than this many days ago
const OLD_READY_DAYS = 45; // ready to dispatch for longer than this
const r0 = (n: number) => Math.round(n);
const daysBetween = (a: string, b: string) => Math.round((Date.parse(b.slice(0, 10)) - Date.parse(a.slice(0, 10))) / 86_400_000);

router.get('/', (req: AuthedRequest, res) => {
  const viewer = req.user!;
  const ov = overview(viewer, null, null);
  const today = new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });
  const rate = usdPerEur();
  const toEur = (v: number, cur: string) => (cur === 'USD' ? v / rate : v);
  const who = (sap: string) => { const a = accountOfSap(viewer, sap); return { cardId: a?.cardId ?? null, country: a?.country ?? '', rep: a?.rep ?? '' }; };

  const waiting = ov.blockers.map((b) => ({
    sap: b.sap, customer: b.customer, ...who(b.sap), orders: b.orders, lines: b.lines, value: r0(b.value), cur: b.currency, days: b.days, level: b.level,
    detail: b.detail.slice(0, 12).map((o) => ({ sd: o.sd, date: o.date, days: o.days, value: r0(o.value), items: o.items.slice(0, 4) })),
    old: b.days > OLD_WAITING_DAYS,
  })).sort((a, b) => toEur(b.value, b.cur) - toEur(a.value, a.cur));

  const production = ov.production.map((p) => ({
    sap: p.sap, customer: p.customer, ...who(p.sap), orders: p.orders, m2: r0(p.m2), value: r0(p.value), cur: 'EUR', firstDelivery: p.firstDelivery, daysLeft: p.daysLeft, groups: p.groups,
    mix: p.mix.slice(0, 6),
    old: p.daysLeft !== null && p.daysLeft < -OLD_DELIVERY_DAYS,
  })).sort((a, b) => (a.daysLeft ?? 9999) - (b.daysLeft ?? 9999));

  const ready = ov.dispatch.map((d) => ({
    sap: d.sap, customer: d.customer, cardId: who(d.sap).cardId, country: d.country, rep: d.salesRep, lots: d.lots, kg: r0(d.weight), value: r0(d.value), cur: d.currency, firstDate: d.firstDate,
    days: d.firstDate ? daysBetween(d.firstDate, today) : null,
    account: d.account ? { overdue: r0(d.account.overdue), oldest: d.account.oldestOver, cur: d.account.currency, weOwe: d.account.weOwe } : null,
    risk: d.risk, riskReasons: d.riskReasons.slice(0, 3),
    production: d.production ? { value: r0(d.production.value), m2: r0(d.production.m2), orders: d.production.orders, daysLeft: d.production.daysLeft } : null,
    waiting: d.waiting,
    detail: d.detail.slice(0, 10),
    old: d.firstDate ? daysBetween(d.firstDate, today) > OLD_READY_DAYS : false,
  })).sort((a, b) => toEur(b.value, b.cur) - toEur(a.value, a.cur));

  const split = <T extends { old: boolean }>(l: T[]) => ({ current: l.filter((x) => !x.old), old: l.filter((x) => x.old) });
  res.json({
    sapAsOf: sapAsOf(),
    limits: { waiting: OLD_WAITING_DAYS, delivery: OLD_DELIVERY_DAYS, ready: OLD_READY_DAYS },
    waiting: split(waiting),
    production: split(production),
    ready: split(ready),
    totals: {
      waitingEur: r0(waiting.filter((x) => !x.old).reduce((a, x) => a + toEur(x.value, x.cur), 0)),
      productionEur: r0(production.filter((x) => !x.old).reduce((a, x) => a + toEur(x.value, x.cur), 0)),
      readyEur: r0(ready.filter((x) => !x.old).reduce((a, x) => a + toEur(x.value, x.cur), 0)),
    },
  });
});

export default router;
