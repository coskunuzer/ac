import path from 'path';
import { Router } from 'express';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { asMarket, userModel } from '../models/userModel';
import { accessModel } from '../models/accessModel';
import { settingsModel } from '../models/settingsModel';
import { wouldLoop } from '../services/team';
import { requireAuth, requireAdmin, type AuthedRequest } from '../middleware/auth';
import { upload } from '../middleware/upload';
import { createAssistant } from '../services/assistants';
import { countryModel } from '../models/countryModel';
import { cityModel } from '../models/cityModel';
import { db } from '../db/connection';
import { savePerms, BRAND_PERMS } from '../services/permissions';
import { countryHoldings, holdings, transferCustomers } from '../services/transfer';

const router = Router();

// The routes below are registered before the router-wide admin gate further
// down, so they only require requireAuth - Express matches routes in
// registration order, so a route defined earlier isn't affected by a
// router.use() added later. These are the self-service routes: any staff
// member manages their own Person-dropdown visibility, profile details,
// thank-you email template, and photo without needing an admin - confirmed
// directly by the user ("Both Admin and the user can manage this both").
// Assistants (name + email, no login) - offered as the assistant of a country.
router.get('/assistants', requireAuth, (_req, res) => {
  res.json(userModel.listAssistants().filter((u) => u.display_name).map((u) => u.display_name));
});

router.get('/active', requireAuth, (_req, res) => {
  const active = userModel
    .listActive()
    .filter((u) => u.display_name)
    .map((u) => ({ id: u.id, display_name: u.display_name }));
  res.json(active);
});

// colleagues who can be invited to a meeting (name + e-mail), not the person asking
router.get('/colleagues', requireAuth, (req: AuthedRequest, res) => {
  // everybody who works here and can be asked: the assistants too (Sena, Ziya...). A person with no e-mail address is listed, but cannot be invited until one is written.
  const rows = db.prepare("SELECT id, display_name, email, is_assistant FROM users WHERE is_active = 1 AND COALESCE(display_name, '') != '' AND id != ? ORDER BY display_name").all(req.user!.id) as unknown as { id: number; display_name: string; email: string | null; is_assistant: number }[];
  res.json(rows.map((u) => ({ id: u.id, name: u.display_name, email: (u.email ?? '').trim(), assistant: !!u.is_assistant })));
});

router.patch('/me', requireAuth, (req: AuthedRequest, res) => {
  if (req.actor) return res.status(403).json({ error: 'You work for ' + (req.user!.display_name ?? 'this person') + ': the profile is theirs. You can change your own password.' });
  const { displayName, email, emailTemplateSubject, emailTemplateBody, jobTitle, mobile, officePhone, signatureStyle, signatureText, offerStyle, uiLanguage } = req.body || {};
  if (!displayName || !email) {
    return res.status(400).json({ error: 'displayName and email are required' });
  }
  // Deliberately does not accept role/username/isActive here - a self-service
  // route must never let staff touch their own permissions.
  const updated = userModel.update(req.user!.id, { displayName, email, emailTemplateSubject, emailTemplateBody, jobTitle, mobile, officePhone, signatureStyle, signatureText, offerStyle, uiLanguage });
  res.json(updated);
});

router.post('/me/photo', requireAuth, upload.single('photo'), (req: AuthedRequest, res) => {
  if (req.actor) return res.status(403).json({ error: 'The photo belongs to the person you work for.' });
  if (!req.file) return res.status(400).json({ error: 'photo file is required' });
  const updated = userModel.updatePhoto(req.user!.id, path.basename(req.file.path));
  res.json(updated);
});

// Only the language of the screens (everybody may change their own).
router.patch('/me/language', requireAuth, (req: AuthedRequest, res) => {
  const v = req.body?.uiLanguage;
  res.json(userModel.update((req.actor ?? req.user)!.id, { uiLanguage: v === 'en' || v === 'tr' ? v : null }));
});

// The theme of the screens (light, dark, or empty = follow the computer): everybody chooses their own, an assistant too.
router.patch('/me/theme', requireAuth, (req: AuthedRequest, res) => {
  userModel.setTheme((req.actor ?? req.user)!.id, String(req.body?.theme ?? ''));
  res.json({ ok: true });
});

// A person's own e-mail styles (as many as they like).
const textRow = (r: { id: number; name: string; kind: string; subject: string; body: string }) => ({ id: r.id, name: r.name, kind: r.kind, subject: r.subject, body: r.body });
router.get('/me/texts', requireAuth, (req: AuthedRequest, res) => {
  res.json({ texts: (db.prepare('SELECT id, name, kind, subject, body FROM user_texts WHERE user_id = ? ORDER BY name').all(req.user!.id) as { id: number; name: string; kind: string; subject: string; body: string }[]).map(textRow) });
});
router.post('/me/texts', requireAuth, (req: AuthedRequest, res) => {
  const name = String(req.body?.name ?? '').trim().slice(0, 80);
  const subject = String(req.body?.subject ?? '').trim().slice(0, 300);
  const body = String(req.body?.body ?? '').trim().slice(0, 8000);
  const kind = String(req.body?.kind ?? 'general').trim().slice(0, 30) || 'general';
  if (!name || !subject || !body) return res.status(400).json({ error: 'Give the text a name, a subject and a message.' });
  const id = Number(db.prepare('INSERT INTO user_texts (user_id, name, kind, subject, body) VALUES (?, ?, ?, ?, ?)').run(req.user!.id, name, kind, subject, body).lastInsertRowid);
  res.status(201).json({ text: textRow(db.prepare('SELECT id, name, kind, subject, body FROM user_texts WHERE id = ?').get(id) as { id: number; name: string; kind: string; subject: string; body: string }) });
});
router.put('/me/texts/:id', requireAuth, (req: AuthedRequest, res) => {
  const id = parseInt(String(req.params.id), 10);
  const name = String(req.body?.name ?? '').trim().slice(0, 80);
  const subject = String(req.body?.subject ?? '').trim().slice(0, 300);
  const body = String(req.body?.body ?? '').trim().slice(0, 8000);
  const kind = String(req.body?.kind ?? 'general').trim().slice(0, 30) || 'general';
  if (!name || !subject || !body) return res.status(400).json({ error: 'Give the text a name, a subject and a message.' });
  const r = db.prepare('UPDATE user_texts SET name = ?, kind = ?, subject = ?, body = ? WHERE id = ? AND user_id = ?').run(name, kind, subject, body, id, req.user!.id);
  if (!r.changes) return res.status(404).json({ error: 'Not found' });
  res.json({ ok: true });
});
router.delete('/me/texts/:id', requireAuth, (req: AuthedRequest, res) => {
  db.prepare('DELETE FROM user_texts WHERE id = ? AND user_id = ?').run(parseInt(String(req.params.id), 10), req.user!.id);
  res.json({ ok: true });
});

router.patch('/me/password', requireAuth, (req: AuthedRequest, res) => {
  const { currentPassword, newPassword } = req.body || {};
  if (!currentPassword || !newPassword) {
    return res.status(400).json({ error: 'currentPassword and newPassword are required' });
  }
  if (newPassword.length < 8) {
    return res.status(400).json({ error: 'newPassword must be at least 8 characters' });
  }
  const full = userModel.findById((req.actor ?? req.user)!.id)!;
  if (!bcrypt.compareSync(currentPassword, full.password_hash)) {
    return res.status(401).json({ error: 'Current password is incorrect' });
  }
  userModel.setPasswordHash(full.id, bcrypt.hashSync(newPassword, 10));
  res.json({ ok: true });
});

router.use(requireAuth, requireAdmin);

router.get('/', (_req, res) => {
  res.json(userModel.listAll());
});

// Everybody with what they look after (countries for the export team, cities for the domestic team) and the things that look wrong:
// a person in the export team who looks after cities, a domestic person with countries, somebody who reports across the two teams ...
router.get('/overview', (_req, res) => {
  const users = userModel.listAll();
  const byId = new Map(users.map((u) => [u.id, u]));
  const countries = countryModel.listAll();
  const cities = cityModel.listAll();
  const owned = db.prepare("SELECT person, market, COUNT(*) AS n FROM cards WHERE person IS NOT NULL AND person != '' GROUP BY person, market").all() as { person: string; market: string; n: number }[];
  res.json(
    users.map((u) => {
      const name = u.display_name;
      const myCountries = name ? countries.filter((c) => c.responsible === name || c.assistant === name).map((c) => c.country) : [];
      const myCities = name ? cities.filter((c) => c.responsible === name || c.assistant === name).map((c) => c.city) : [];
      const own = { export: 0, domestic: 0 };
      for (const o of owned) if (o.person === name) own[o.market === 'domestic' ? 'domestic' : 'export'] += o.n;
      const problems: string[] = [];
      if (u.is_active && !u.is_assistant && u.role !== 'admin') {
        if (u.market === 'domestic' && myCountries.length) problems.push(`In the domestic team, but looks after ${myCountries.length} export countries (${myCountries.slice(0, 4).join(', ')}${myCountries.length > 4 ? '…' : ''}).`);
        if (u.market === 'export' && myCities.length) problems.push(`In the export team, but looks after ${myCities.length} cities of Turkey (${myCities.slice(0, 4).join(', ')}${myCities.length > 4 ? '…' : ''}).`);
        if (u.market === 'domestic' && own.export) problems.push(`Has ${own.export} export customers with their name.`);
        if (u.market === 'export' && own.domestic) problems.push(`Has ${own.domestic} domestic customers with their name.`);
        const boss = u.manager_id ? byId.get(u.manager_id) : undefined;
        if (boss && boss.role !== 'admin' && !boss.is_assistant && boss.market !== u.market) problems.push(`Reports to ${boss.display_name || boss.username}, who is in the other team.`);
      }
      return { id: u.id, countries: myCountries, cities: myCities, customers: own, problems };
    })
  );
});

router.post('/', (req, res) => {
  // An assistant is just a name and an email address to copy: no username,
  // no password, cannot sign in.
  if (req.body?.role === 'assistant' || req.body?.role === 'sales') {
    const kind = req.body.role === 'sales' ? 'sales' : 'assistant';
    const displayName = String(req.body.displayName ?? '').trim().slice(0, 80);
    const email = String(req.body.email ?? '').trim().slice(0, 200);
    if (!displayName) return res.status(400).json({ error: 'A name is required' });
    if (!/^[^\s@,;]+@[^\s@,;]+\.[^\s@,;]+$/.test(email)) return res.status(400).json({ error: 'A valid email address is required' });
    if (userModel.listAll().some((u) => u.display_name === displayName)) {
      return res.status(409).json({ error: `Someone called "${displayName}" already exists` });
    }
    return res.status(201).json(createAssistant(displayName, email, kind));
  }

  const { username, password, role, displayName, email, market, canOversee } = req.body || {};
  if (!username || !password || !role || !displayName || !email) {
    return res.status(400).json({ error: 'username, password, role, displayName, and email are all required' });
  }
  if (role !== 'admin' && role !== 'user') {
    return res.status(400).json({ error: 'role must be "admin" or "user"' });
  }
  if (userModel.findByUsername(username)) {
    return res.status(409).json({ error: 'Username already exists' });
  }

  const passwordHash = bcrypt.hashSync(password, 10);
  const user = userModel.create({ username, passwordHash, role, displayName, email, market: asMarket(market), canOversee: !!canOversee });
  res.status(201).json(user);
});

// what a login is for: sales / admin (empty), the quality person, or a department head - the last two see only the complaints module
router.put('/:id/area', requireAdmin, (req, res) => {
  const id = parseInt(String(req.params.id), 10);
  if (!userModel.findById(id)) return res.status(404).json({ error: 'User not found' });
  const area = String(req.body?.area ?? '');
  userModel.setArea(id, area === 'quality' || area === 'dept' || area === 'brand' ? area : null);
  // a brand manager gets the brand set of switches at once (menu, actions, start page); the admin can still fine-tune them on Permissions
  if (area === 'brand') savePerms(id, (req as AuthedRequest).user!.id, BRAND_PERMS);
  res.json({ ok: true });
});

router.patch('/:id/active', (req, res) => {
  const id = parseInt(String(req.params.id), 10);
  const { isActive } = req.body || {};
  userModel.setActive(id, !!isActive);
  res.json(userModel.findPublicById(id));
});

// An assistant (a name and an e-mail so far) gets a login: a username and a password, and the person they work for. They then see that person's
// customers and activities - nobody else's - and can do what that person does, without admin rights.
router.post('/:id/login', (req, res) => {
  const id = parseInt(String(req.params.id), 10);
  const person = userModel.findPublicById(id);
  if (!person) return res.status(404).json({ error: 'Not found' });
  const username = String(req.body?.username ?? '').trim().toLowerCase();
  const password = String(req.body?.password ?? '');
  const boss = userModel.findPublicById(parseInt(String(req.body?.assistsId ?? ''), 10));
  if (!/^[a-z0-9._@-]{3,60}$/.test(username)) return res.status(400).json({ error: 'The username: 3 to 60 letters, digits or . _ - @' });
  if (password.length < 8) return res.status(400).json({ error: 'The password must have at least 8 characters.' });
  if (!boss || boss.id === id || boss.is_assistant || boss.assists_id || !boss.is_active) return res.status(400).json({ error: 'Choose the person they work for.' });
  const taken = userModel.findByUsername(username);
  if (taken && taken.id !== id) return res.status(409).json({ error: 'That username is taken.' });
  res.json(userModel.giveLogin(id, username, bcrypt.hashSync(password, 10), boss.id));
});
router.put('/:id/assists', (req, res) => {
  const id = parseInt(String(req.params.id), 10);
  const boss = req.body?.assistsId ? userModel.findPublicById(parseInt(String(req.body.assistsId), 10)) : null;
  if (req.body?.assistsId && (!boss || boss.id === id || boss.assists_id)) return res.status(400).json({ error: 'Choose the person they work for.' });
  userModel.setAssists(id, boss?.id ?? null);
  res.json(userModel.findPublicById(id));
});

// Handing customers over (a person leaves, or a country gets a new person).
router.get('/transfer/preview', (req, res) => {
  const from = String(req.query.from ?? '').trim();
  res.json({ ...(from ? holdings(from) : { total: 0, countries: [] }), allCountries: countryHoldings() });
});
router.post('/transfer', (req: AuthedRequest, res) => {
  const b = (req.body ?? {}) as { from?: unknown; country?: unknown; to?: unknown };
  const to = String(b.to ?? '').trim();
  const target = userModel.findByDisplayName(to);
  if (!target || !target.is_active) return res.status(400).json({ error: 'Choose an active person who gets the customers.' });
  if (b.from && String(b.from).trim() === to) return res.status(400).json({ error: 'The customers are with that person already.' });
  try {
    res.json(transferCustomers({ from: String(b.from ?? ''), country: String(b.country ?? ''), to, byUserId: req.user!.id }));
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

// Delete a person (an admin only). Their notes, offers and uploads stay, under the admin who deletes.
router.delete('/:id', (req: AuthedRequest, res) => {
  const id = parseInt(String(req.params.id), 10);
  const user = userModel.findPublicById(id);
  if (!user) return res.status(404).json({ error: 'Not found' });
  if (id === req.user!.id) return res.status(400).json({ error: 'You cannot delete yourself.' });
  if (user.role === 'admin' && userModel.listAll().filter((u) => u.role === 'admin' && u.is_active && u.id !== id).length === 0) return res.status(400).json({ error: 'This is the last admin.' });
  try {
    userModel.remove(id, req.user!.id);
  } catch (err) {
    return res.status(409).json({ error: 'This person could not be deleted: ' + (err as Error).message + ' Switch them off instead.' });
  }
  res.json({ ok: true });
});

router.patch('/:id', (req, res) => {
  const id = parseInt(String(req.params.id), 10);
  if (!userModel.findPublicById(id)) return res.status(404).json({ error: 'Not found' });
  const { displayName, email, emailTemplateSubject, emailTemplateBody, jobTitle, mobile, officePhone, signatureStyle, signatureText } = req.body || {};
  const updated = userModel.update(id, { displayName, email, emailTemplateSubject, emailTemplateBody, jobTitle, mobile, officePhone, signatureStyle, signatureText });
  res.json(updated);
});

// The language the screens start in for everybody who has not chosen their own ('en' or 'tr').
router.put('/default-language', (req, res) => {
  const lang = req.body?.language === 'tr' ? 'tr' : 'en';
  settingsModel.set('ui_default_language', lang);
  res.json({ defaultLanguage: lang });
});

// Which team a person is in, and whether they may watch what everybody does (read-only).
router.patch('/:id/team', (req, res) => {
  const id = parseInt(String(req.params.id), 10);
  if (!userModel.findPublicById(id)) return res.status(404).json({ error: 'Not found' });
  const { market, canOversee, canShip } = req.body || {};
  res.json(userModel.update(id, { market: market === undefined ? undefined : asMarket(market), canOversee: canOversee === undefined ? undefined : !!canOversee, canShip: canShip === undefined ? undefined : !!canShip }));
});

// Extra customers this person may see: a whole market, a country or a city.
router.get('/:id/access', (req, res) => {
  res.json(accessModel.forUser(parseInt(String(req.params.id), 10)));
});
router.put('/:id/access', (req, res) => {
  const id = parseInt(String(req.params.id), 10);
  if (!userModel.findPublicById(id)) return res.status(404).json({ error: 'Not found' });
  res.json(accessModel.replace(id, Array.isArray(req.body?.grants) ? req.body.grants : []));
});

// Sets up the domestic team in one go: accounts (the e-mail address is the username), the domestic market, who reports to
// whom, and who may watch the others. Existing accounts are kept (only their team and manager are set); a person without an
// e-mail address is skipped. New accounts get a random password, returned once so it can be handed over.
function randomPassword(): string {
  const chars = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789';
  return Array.from(crypto.randomBytes(12), (b) => chars[b % chars.length]).join('');
}
router.post('/domestic-team', (req, res) => {
  const members = (Array.isArray(req.body?.members) ? req.body.members : []) as { name?: string; email?: string }[];
  const managerEmail = String(req.body?.managerEmail ?? '').trim().toLowerCase();
  const watchers = (Array.isArray(req.body?.watchEmails) ? req.body.watchEmails : []).map((e: unknown) => String(e).trim().toLowerCase());
  const created: { name: string; username: string; password: string }[] = [];
  const kept: string[] = [];
  const skipped: string[] = [];
  const ids = new Map<string, number>();
  for (const m of members) {
    const name = String(m.name ?? '').trim().slice(0, 80);
    const email = String(m.email ?? '').trim().toLowerCase();
    if (!name || !/^[^\s@,;]+@[^\s@,;]+\.[^\s@,;]+$/.test(email)) {
      skipped.push(`${name || '(no name)'} (needs a valid e-mail address)`);
      continue;
    }
    let user = userModel.findByUsername(email);
    if (user) {
      kept.push(name);
      userModel.update(user.id, { market: 'domestic' });
      ids.set(email, user.id);
      continue;
    }
    const password = randomPassword();
    const made = userModel.create({ username: email, passwordHash: bcrypt.hashSync(password, 10), role: 'user', displayName: name, email, market: 'domestic' });
    created.push({ name, username: email, password });
    ids.set(email, made.id);
  }
  const boss = ids.get(managerEmail);
  if (boss) {
    for (const [, id] of ids) {
      if (id !== boss && !wouldLoop(id, boss)) userModel.update(id, { managerId: boss });
    }
  }
  // who may watch everybody's activity (the manager here, and people from the export team such as Sunay):
  // matched by the part of the e-mail address before the @
  const watching: string[] = [];
  for (const w of watchers) {
    const local = w.split('@')[0];
    const person = userModel.listAll().find((u) => !u.is_assistant && u.is_active && [u.username, u.email ?? ''].some((x) => x.toLowerCase().split('@')[0] === local));
    if (person) {
      userModel.update(person.id, { canOversee: true });
      watching.push(person.display_name ?? person.username);
    } else {
      skipped.push(`${w} (no such account, so it cannot watch the team)`);
    }
  }
  res.status(201).json({ created, kept, skipped, watching });
});

router.post('/:id/photo', upload.single('photo'), (req, res) => {
  const id = parseInt(String(req.params.id), 10);
  if (!userModel.findPublicById(id)) return res.status(404).json({ error: 'Not found' });
  if (!req.file) return res.status(400).json({ error: 'photo file is required' });
  const updated = userModel.updatePhoto(id, path.basename(req.file.path));
  res.json(updated);
});

router.post('/:id/reset-password', (req, res) => {
  const id = parseInt(String(req.params.id), 10);
  const target = userModel.findPublicById(id);
  if (!target) return res.status(404).json({ error: 'Not found' });
  if (target.is_assistant) return res.status(400).json({ error: 'Assistants cannot log in, so they have no password.' });
  const { newPassword } = req.body || {};
  if (!newPassword || newPassword.length < 8) {
    return res.status(400).json({ error: 'newPassword must be at least 8 characters' });
  }
  userModel.setPasswordHash(id, bcrypt.hashSync(newPassword, 10));
  res.json({ ok: true });
});

export default router;
