-- Every question that was sent to the AI (Gemini), with the tokens it used: what it costs, who asked, and for which customer.
CREATE TABLE IF NOT EXISTS ai_calls (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  user_id INTEGER,
  card_id INTEGER,
  model TEXT,
  purpose TEXT,
  label TEXT,
  prompt_tokens INTEGER NOT NULL DEFAULT 0,
  output_tokens INTEGER NOT NULL DEFAULT 0,
  thought_tokens INTEGER NOT NULL DEFAULT 0,
  total_tokens INTEGER NOT NULL DEFAULT 0,
  status INTEGER,
  ok INTEGER NOT NULL DEFAULT 1,
  error TEXT
);
CREATE INDEX IF NOT EXISTS idx_ai_calls_created ON ai_calls (created_at);
CREATE INDEX IF NOT EXISTS idx_ai_calls_card ON ai_calls (card_id);
