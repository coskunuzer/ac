import fs from 'fs';
import PDFDocument from 'pdfkit';
import { readBiff, type BiffData } from './biff';
import { formatCell, type NumberStyle } from './numfmt';
import { drawSheet, loadLetterhead, registerSheetFonts } from './sheetPrint';
import { drawDesignedSheet } from './designed';
import { Workbook, colToIndex, indexToCol, type Evaluator } from './workbook';
import type { Value } from './formula';

// The offer is the price workbook itself, printed: each product page is one
// worksheet drawn with its own layout, fonts, colours and pictures. The app only
// feeds the Main tab (customer, currency, percentages) and hides unselected
// rows/columns - so changing the Excel changes the offer.

// Tabs an offer can be made of, in the order they are printed. An admin decides which of them are on offer
// (the first group is on by default; the others - hybrid, digital, Zero-Line, hot melt - when they are switched on).
// The price pages to send. The October 2026 template has one page for each product with the m2 prices and the width prices ("PVC M2+22", "PP M2+22" ...).
// The older names ("PP M2", "Hybrid M2", "Digital") are still read when a workbook has no new page of that product.
export const PRODUCT_TABS = ['PVC M2+22', 'ABS M2+22', 'PP M2+22', 'PP M2', 'Hybrid M2+22', 'Hybrid M2', 'Digital M2+22', 'Digital', 'Airtec', 'Air ABS', 'Hot_Melt', 'Melamine', 'Veneer', 'Screw', 'Accessories for distributor'];
export const LEGACY_TABS: Record<string, string> = { 'PP M2': 'PP M2+22', 'Hybrid M2': 'Hybrid M2+22', Digital: 'Digital M2+22' };
export const DEFAULT_ENABLED_TABS = ['PVC M2+22', 'ABS M2+22', 'PP M2+22', 'PP M2', 'Melamine', 'Veneer', 'Screw', 'Accessories for distributor'];
// MOQ and Packaging are documents: they are ticked with the documents of the e-mail, not in the offer
export const MOQ_TAB = 'MOQ';
export const PACKAGING_TAB = 'Packaging';

const MAIN = 'Main';
const NAME_HEADER = 'product name and description';

// The price pages list a price per m² for each kind of decor: which row (by the start of its name) is which price category.
const M2_ROWS: Record<'PVC' | 'ABS' | 'PP', Record<number, string>> = {
  PVC: { 1: 'solid colors', 2: 'woodgrain', 3: 'high gloss solid colors', 4: 'high gloss woodgrain', 5: 'intensive solid colors' },
  ABS: { 1: 'solid colors', 2: 'woodgrain', 3: 'high gloss solid colors', 4: 'high gloss woodgrain', 5: 'intensive solid colors' },
  PP: { 1: 'solid colors | no lacquer', 2: 'intensive + woodgrain', 3: 'high gloss solid colors', 5: 'intensive solid colors | no lacquer' },
};

export interface OfferParams {
  currency: 'EUR' | 'USD';
  // 1 EUR = usdRate USD (Main!C13). Only used when currency is USD.
  usdRate: number;
  // Fractions: 0.05 = +5 %, -0.03 = 3 % discount.
  transportPct: number;
  // Surcharge/discount cells that exist on the Main page (PVC, ABS, PP), by product tab.
  adjust: Record<string, number>;
  // The custom edge widths in mm. The first three are the template's own (Main!C22:C24): they head the
  // per-meter columns and drive the MOQ rows. Further widths print on an extra copy of the same page.
  widths: number[];
  // a different price increase / decrease (fraction) for one product page, by tab name; the others use transportPct
  pagePct?: Record<string, number>;
  // a customer's own prices: 'Sheet!D13' -> the value that cell must show (the price per m² of that row); the per-meter columns follow by the workbook's own formulas
  cellOverrides?: Record<string, number>;
  numberStyle: NumberStyle;
  deliveryTerm: string;
  paymentTerm: string;
  dispatchTime: string;
}

export interface OfferContext {
  name: string | null;
  company: string | null;
  address: string | null;
  country: string | null;
  tel: string | null;
  email: string | null;
  // Optional: print these two contact lines exactly as given (instead of "Tel: ..." / "Email: ...").
  contactLine1?: string;
  contactLine2?: string;
  preparedBy: string;
  date: Date;
  // the language of the offer (en ru tr es fr) and the function that gives the translation of a text of the workbook
  lang?: string;
  tr?: (text: string) => string;
}

export interface SectionSelection {
  sheet: string;
  rows: number[]; // spreadsheet row numbers (1-based)
  columns: string[]; // spreadsheet column letters
}

export interface CatalogSection {
  sheet: string;
  title: string;
  // `hidden`: the Excel hides it (another thickness, a base paper) - it is offered on request, never by default
  columns: { id: string; label: string; hidden?: boolean }[];
  rows: { id: number; name: string; detail: string; hidden?: boolean }[];
  // Name of this tab's surcharge/discount cell on the Main page ("Surcharge PVC / Discount %"), if it has one.
  adjustLabel: string | null;
}

export interface PreviewSection {
  sheet: string;
  // cells[rowId][columnId] = the text Excel would print
  cells: Record<number, Record<string, string>>;
}

interface SectionLayout {
  tab: string;
  titleAddr: string;
  headerRow: number; // 0-based
  firstRow: number;
  lastRow: number;
  columns: { id: string; index: number; hidden?: boolean }[];
  dataRows: number[]; // 0-based rows that are real product rows
  hiddenRows: Set<number>; // the ones of them the Excel hides
}

const EMPTY_CONTEXT: OfferContext = {
  name: '', company: '', address: '', country: '', tel: '', email: '', preparedBy: '', date: new Date(),
};

function excelSerial(d: Date): number {
  return Math.floor(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) / 86400000) + 25569;
}

function firstLine(v: Value): string {
  return typeof v === 'string' ? v.split(/\r?\n/)[0].trim() : v === null ? '' : String(v);
}

export class PriceBook {
  readonly defaults: OfferParams;
  readonly catalog: CatalogSection[];
  readonly hasMoq: boolean;
  readonly hasPackaging: boolean;

  private layouts: SectionLayout[] = [];
  // product tab -> its surcharge/discount cell on the Main page (e.g. 'C15'), when it has one
  private surcharge = new Map<string, string>();
  private sourceSheets = new Set<string>();
  private baselineRate = 1;
  private baselineTransport = 0;
  // product tab -> its per-meter columns that follow the offer's widths (slot 0..2 = first..third width)
  private widthCols = new Map<string, { index: number; slot: number }[]>();
  // header cells that hold a typed-in width (Melamine: "Price for 20 mm / mt"): cell -> slot
  private fixedWidth = new Map<string, number>();

  private constructor(private wb: Workbook, private biff: BiffData) {
    const base = wb.evaluator();
    this.hasMoq = wb.sheets.has(MOQ_TAB) && biff.sheets.has(MOQ_TAB);
    this.hasPackaging = wb.sheets.has(PACKAGING_TAB) && biff.sheets.has(PACKAGING_TAB);
    this.baselineRate = base.number(MAIN, 'C13') ?? 1;
    this.baselineTransport = base.number(MAIN, 'C14') ?? 0;

    const multiplierCells = this.findMultiplierCells();
    // an old page name is skipped when the workbook has the new page of that product
    const tabs = PRODUCT_TABS.filter((t) => !(LEGACY_TABS[t] && wb.sheets.has(LEGACY_TABS[t])));
    for (const tab of tabs) {
      const src = this.sourceSheetFor(tab, multiplierCells);
      if (!src) continue;
      this.sourceSheets.add(src);
      // the sheet's price multiplier reads: Main!C13 (rate) + Main!C14 (transport) + Main!C15.. (this material's surcharge)
      const formula = this.wb.sheets.get(src)?.cells.get(multiplierCells.get(src)!)?.f ?? '';
      const third = /^Main!\$?C\$?13\s*\+\s*\(?\s*Main!\$?C\$?14\s*\)?\s*\+\s*\(?\s*Main!\$?(C)\$?(\d+)\s*\)?\s*$/i.exec(formula);
      if (third) this.surcharge.set(tab, `${third[1]}${third[2]}`);
    }

    this.catalog = [];
    for (const tab of tabs) {
      const layout = this.layoutFor(tab, base);
      if (!layout) continue;
      this.layouts.push(layout);
      this.catalog.push({
        sheet: tab,
        title: firstLine(base.value(tab, layout.titleAddr)),
        columns: layout.columns.map((c) => ({ id: c.id, label: this.shown(tab, `${c.id}${layout.headerRow + 1}`, base) || c.id, ...(c.hidden ? { hidden: true } : {}) })),
        rows: layout.dataRows.map((r) => ({
          id: r + 1,
          name: firstLine(base.value(tab, `B${r + 1}`)) || `Row ${r + 1}`,
          detail: this.detailOf(tab, r, layout, base),
          ...(layout.hiddenRows.has(r) ? { hidden: true } : {}),
        })),
        adjustLabel: this.surcharge.has(tab)
          ? firstLine(base.value(MAIN, `B${this.surcharge.get(tab)!.slice(1)}`)) || 'Surcharge / discount %'
          : null,
      });
    }

    // which columns of each tab are the width columns
    for (const layout of this.layouts) {
      const sd = this.wb.sheets.get(layout.tab)!;
      const cols: { index: number; slot: number }[] = [];
      for (const { id, index } of layout.columns) {
        const f = sd.cells.get(`${id}${layout.headerRow + 1}`)?.f;
        const m = f ? /^Main!\$?C\$?(2[234])$/i.exec(f.trim()) : null;
        if (m) cols.push({ index, slot: parseInt(m[1], 10) - 22 });
      }
      if (!cols.length) {
        // a tab whose headers hold typed-in widths (Melamine: 20 and 40 mm): they follow the offer's widths in order
        let slot = 0;
        for (const { id, index } of layout.columns) {
          const addr = `${id}${layout.headerRow + 1}`;
          const raw = sd.cells.get(addr);
          if (slot < 3 && raw && raw.f === undefined && typeof raw.v === 'number' && raw.v >= 5 && raw.v <= 200 && /price/i.test(raw.z ?? '') && /mm/i.test(raw.z ?? '')) {
            cols.push({ index, slot });
            this.fixedWidth.set(`${layout.tab}!${addr}`, slot);
            slot += 1;
          }
        }
      }
      if (cols.length) this.widthCols.set(layout.tab, cols);
    }

    const adjust: Record<string, number> = {};
    for (const [tab, cell] of this.surcharge) adjust[tab] = base.number(MAIN, cell) ?? 0;
    const currencyText = firstLine(base.value(MAIN, 'F7')) || '€ - EUR';
    const text = (addr: string, fallback: string) => firstLine(base.value(MAIN, addr)) || fallback;
    this.defaults = {
      currency: /usd|\$/i.test(currencyText) ? 'USD' : 'EUR',
      usdRate: /usd|\$/i.test(currencyText) ? this.baselineRate : 1,
      transportPct: this.baselineTransport,
      adjust,
      widths: ['C22', 'C23', 'C24'].map((a) => base.number(MAIN, a)).filter((n): n is number => n !== null),
      numberStyle: 'eu',
      deliveryTerm: text('F8', 'EXW (Ex Works - Tece)'),
      paymentTerm: text('F9', ''),
      dispatchTime: text('F10', ''),
    };
  }

  static fromFile(path: string): PriceBook {
    return PriceBook.fromBuffer(fs.readFileSync(path));
  }

  static fromBuffer(buffer: Buffer): PriceBook {
    // Excel 97-2003 (.xls) files are OLE containers; .xlsx files are zip archives.
    if (buffer.length > 4 && buffer.readUInt32BE(0) === 0x504b0304) {
      throw new Error('This is an .xlsx file. Please upload the Excel 97-2003 (.xls) version of the price template - its formatting is read directly from that format.');
    }
    const wb = Workbook.parse(buffer);
    if (!wb.sheets.has(MAIN)) throw new Error('This workbook has no "Main" tab - is it the tece price template?');
    const biff = readBiff(buffer);
    if (!biff) throw new Error('Could not read the formatting of this workbook.');
    const book = new PriceBook(wb, biff);
    if (!book.catalog.length) throw new Error('None of the product tabs (PVC M2+22, ABS M2+22, PP M2+22, Melamine, Veneer, Screw, Accessories for distributor) were found.');
    return book;
  }

  // ---- structure ---------------------------------------------------------------

  private findMultiplierCells(): Map<string, string> {
    const out = new Map<string, string>();
    for (const [name, sd] of this.wb.sheets) {
      if (name === MAIN) continue;
      for (const [addr, raw] of sd.cells) {
        if (raw.f && /^Main!\$?C\$?13\s*\+/i.test(raw.f)) { out.set(name, addr); break; }
      }
    }
    return out;
  }

  // Which sheet's multiplier drives a product tab: the one its formulas refer to most.
  private sourceSheetFor(tab: string, multiplierCells: Map<string, string>): string | null {
    const sd = this.wb.sheets.get(tab);
    if (!sd) return null;
    const counts = new Map<string, number>();
    for (const raw of sd.cells.values()) {
      if (!raw.f) continue;
      // references with no sheet prefix point at the tab itself
      const unqualified = raw.f.replace(/'[^']+'!\$?[A-Z]+\$?\d+(:\$?[A-Z]+\$?\d+)?|[A-Za-z0-9_.]+!\$?[A-Z]+\$?\d+(:\$?[A-Z]+\$?\d+)?/g, '');
      const sawLocal = /(^|[^A-Za-z0-9_])\$?[A-Z]{1,3}\$?\d+/.test(unqualified);
      for (const m of raw.f.matchAll(/(?:'([^']+)'|([A-Za-z_][A-Za-z0-9_.]*))!/g)) {
        const name = m[1] ?? m[2];
        counts.set(name, (counts.get(name) ?? 0) + 1);
      }
      if (sawLocal) counts.set(tab, (counts.get(tab) ?? 0) + 1);
    }
    let best: string | null = null;
    let bestCount = 0;
    for (const [name, n] of counts) {
      if (multiplierCells.has(name) && n > bestCount) { best = name; bestCount = n; }
    }
    return best;
  }

  // The text a cell prints (a header like "Price for 0,45mm" is a number with a format).
  private shown(tab: string, addr: string, ev: Evaluator): string {
    const raw = this.wb.sheets.get(tab)?.cells.get(addr);
    return firstLine(formatCell(ev.value(tab, addr), raw?.z, { style: 'eu' }));
  }

  private layoutFor(tab: string, ev: Evaluator): SectionLayout | null {
    const sd = this.wb.sheets.get(tab);
    const bs = this.biff.sheets.get(tab);
    if (!sd || !bs) return null;
    const area = bs.print.area ?? { r1: 0, c1: 0, r2: sd.maxRow - 1, c2: sd.maxCol - 1 };

    let headerRow = -1;
    for (let r = area.r1; r <= Math.min(area.r2, area.r1 + 30) && headerRow < 0; r++) {
      if (firstLine(ev.value(tab, `B${r + 1}`)).toLowerCase() === NAME_HEADER) headerRow = r;
    }
    if (headerRow < 0) return null;

    let lastRow = area.r2;
    for (let r = headerRow + 1; r <= area.r2; r++) {
      if (firstLine(ev.value(tab, `B${r + 1}`)).startsWith('>>')) { lastRow = r - 1; break; }
    }

    const visibleCol = (c: number) => !sd.hiddenCols.has(indexToCol(c + 1)) && (sd.colWidthPt.get(c) ?? 48) > 0.5;
    const columns: SectionLayout['columns'] = [];
    for (let c = colToIndex('C') - 1; c <= area.c2; c++) {
      if (!visibleCol(c)) continue;
      if (firstLine(ev.value(tab, `${indexToCol(c + 1)}${headerRow + 1}`)) === '') continue;
      columns.push({ id: indexToCol(c + 1), index: c });
    }
    // Columns the Excel hides (the other thicknesses of PP, the base paper of melamine) can be asked for
    // in an offer. One that only repeats a visible header (Veneer's second 22 mm) is not offered.
    const shownHeaders = new Set(columns.map((c) => this.shown(tab, `${c.id}${headerRow + 1}`, ev)));
    for (let c = colToIndex('C') - 1; c <= area.c2; c++) {
      if (visibleCol(c)) continue;
      const id = indexToCol(c + 1);
      const head = this.shown(tab, `${id}${headerRow + 1}`, ev);
      if (!head || shownHeaders.has(head)) continue;
      shownHeaders.add(head);
      columns.push({ id, index: c, hidden: true });
    }
    columns.sort((a, b) => a.index - b.index);

    const dataRows: number[] = [];
    const hiddenRows = new Set<number>();
    for (let r = headerRow + 1; r <= lastRow; r++) {
      // rows the Excel hides (other thicknesses) are product rows too, offered on request
      const hidden = sd.hiddenRows.has(r) || (sd.rowHeightPt.get(r) ?? 15) <= 0.5;
      const hasContent = [{ index: 1 }, ...columns].some(({ index }) => {
        const raw = sd.cells.get(`${indexToCol(index + 1)}${r + 1}`);
        return !!raw && (raw.f !== undefined || (raw.v !== null && raw.v !== ''));
      });
      const hasName = firstLine(ev.value(tab, `B${r + 1}`)) !== '';
      if (hasContent && hasName) {
        dataRows.push(r);
        if (hidden) hiddenRows.add(r);
      }
    }
    if (!dataRows.some((r) => !hiddenRows.has(r))) return null;

    const titleAddr = ['A1', 'B1'].find((a) => firstLine(ev.value(tab, a)) !== '') ?? 'A1';
    return { tab, titleAddr, headerRow, firstRow: headerRow + 1, lastRow, columns, dataRows, hiddenRows };
  }

  // The text of the non-price cells in a row (thickness, quality...), for the picker.
  private detailOf(tab: string, r: number, layout: SectionLayout, ev: Evaluator): string {
    const sd = this.wb.sheets.get(tab)!;
    const opts = { style: 'eu' as NumberStyle };
    return layout.columns
      .slice(0, 2)
      .map(({ id }) => {
        const raw = sd.cells.get(`${id}${r + 1}`);
        const v = ev.value(tab, `${id}${r + 1}`);
        // numbers with a unit format (0,40 mm) are descriptive; plain prices are not
        return raw && typeof v === 'number' && /mm|gsm|sheets|sets/.test(raw.z ?? '') ? formatCell(v, raw.z, opts) : typeof v === 'string' ? firstLine(v) : '';
      })
      .filter(Boolean)
      .join(' · ');
  }

  // ---- evaluation ---------------------------------------------------------------

  private evaluator(params: OfferParams, ctx: OfferContext): Evaluator {
    const rate = params.currency === 'USD' ? params.usdRate : 1;
    const overrides: Record<string, Value> = {
      [`${MAIN}!C5`]: ctx.name ?? '',
      [`${MAIN}!C6`]: ctx.company ?? '',
      [`${MAIN}!C7`]: ctx.address ?? '',
      [`${MAIN}!C8`]: ctx.country ?? '',
      [`${MAIN}!C9`]: ctx.contactLine1 ?? (ctx.tel ? `Tel: ${ctx.tel}` : ''),
      [`${MAIN}!C10`]: ctx.contactLine2 ?? (ctx.email ? `Email: ${ctx.email}` : ''),
      [`${MAIN}!F5`]: excelSerial(ctx.date),
      [`${MAIN}!F6`]: ctx.preparedBy,
      [`${MAIN}!F7`]: params.currency === 'USD' ? '$ - USD' : '€ - EUR',
      [`${MAIN}!F8`]: params.deliveryTerm,
      [`${MAIN}!F9`]: params.paymentTerm,
      [`${MAIN}!F10`]: params.dispatchTime,
      [`${MAIN}!C13`]: rate,
      [`${MAIN}!C14`]: params.transportPct,
    };
    // a missing width repeats the last one, so a formula never reads an empty cell
    const widthAt = (slot: number) => params.widths[slot] ?? params.widths[params.widths.length - 1] ?? this.defaults?.widths[slot] ?? 22;
    for (let i = 0; i < 3; i++) overrides[`${MAIN}!C${22 + i}`] = widthAt(i);
    for (const [key, slot] of this.fixedWidth) overrides[key] = widthAt(slot);
    // the surcharge/discount cells of the Main page (PVC, ABS, PP)
    for (const [tab, cell] of this.surcharge) {
      overrides[`${MAIN}!${cell}`] = params.adjust[tab] ?? this.defaults?.adjust[tab] ?? 0;
    }
    for (const [cell, v] of Object.entries(params.cellOverrides ?? {})) overrides[cell] = v;
    return this.wb.evaluator(overrides);
  }

  private formatOptions(params: OfferParams) {
    return { style: params.numberStyle, currencySymbol: params.currency === 'USD' ? '$' : undefined };
  }

  // Compares every formula the offer relies on against the value Excel saved, with
  // the workbook's own inputs untouched. Anything other than a clean match means
  // the template changed in a way the evaluator doesn't understand yet.
  selfCheck(): { formulas: number; mismatches: number; examples: string[] } {
    const ev = this.wb.evaluator();
    let formulas = 0;
    let mismatches = 0;
    const examples: string[] = [];
    const checked = new Set<string>([MAIN, MOQ_TAB, ...PRODUCT_TABS, ...this.sourceSheets]);
    for (const [sheet, sd] of this.wb.sheets) {
      if (!checked.has(sheet)) continue;
      for (const [addr, raw] of sd.cells) {
        if (raw.f === undefined || raw.err) continue;
        formulas++;
        let mine: Value;
        try { mine = ev.cell(sheet, addr); } catch { mine = '#ERR'; }
        const saved = raw.v;
        const ok =
          typeof mine === 'number' && typeof saved === 'number'
            ? Math.abs(mine - saved) <= 1e-9 * Math.max(1, Math.abs(saved))
            : mine === saved || (mine === false && saved === 0) || (mine === 0 && saved === null) || (typeof saved === 'string' && typeof mine === 'string');
        if (!ok) {
          mismatches++;
          if (examples.length < 5) examples.push(`${sheet}!${addr}`);
        }
      }
    }
    return { formulas, mismatches, examples };
  }

  // ---- the price of one square metre (for the proforma) -----------------------------------------------------------------------------

  // The price of one m² of edgebanding: the base price pages ("PVC m2", "ABS m2", "PP M2") list a price per square metre for each kind of
  // decor (a row) and each thickness (a column). The kind is one of the TECE price categories: 1 plain colours, 2 wood, 3 high gloss plain,
  // 4 high gloss wood, 5 intense plain colours. Returns null when this price list has no such price.
  m2Price(product: 'PVC' | 'ABS' | 'PP', category: number, thickness: number, params: OfferParams): { price: number; sheet: string; cell: string; thickness: number } | null {
    const sheet = product === 'PVC' ? 'PVC m2' : product === 'ABS' ? 'ABS m2' : 'PP M2';
    const sd = this.wb.sheets.get(sheet);
    if (!sd) return null;
    const wanted = M2_ROWS[product][category];
    if (!wanted) return null;
    const flat = (s: unknown) => String(s ?? '').replace(/\s+/g, ' ').trim().toLowerCase();
    const base = this.evaluator(params, EMPTY_CONTEXT);
    // the thickness heads are on the row that starts with "Product name and description"
    let head = -1;
    for (let r = 1; r <= 40 && head < 0; r++) if (flat(base.value(sheet, `B${r}`)) === NAME_HEADER) head = r;
    if (head < 0) return null;
    let row = -1;
    for (let r = head + 1; r <= head + 14 && row < 0; r++) if (flat(base.value(sheet, `B${r}`)).startsWith(wanted)) row = r;
    if (row < 0) return null;
    // the first column whose head is this thickness
    for (let c = 3; c <= 12; c++) {
      const col = indexToCol(c + 1);
      const h = base.value(sheet, `${col}${head}`);
      if (typeof h !== 'number' || Math.abs(h - thickness) > 0.0005) continue;
      const v = base.number(sheet, `${col}${row}`);
      return v !== null && v > 0 ? { price: v, sheet, cell: `${col}${row}`, thickness: h } : null;
    }
    return null;
  }

  // The thicknesses the base price page of a product has a price for.
  m2Thicknesses(product: 'PVC' | 'ABS' | 'PP', params: OfferParams): number[] {
    const sheet = product === 'PVC' ? 'PVC m2' : product === 'ABS' ? 'ABS m2' : 'PP M2';
    if (!this.wb.sheets.has(sheet)) return [];
    const base = this.evaluator(params, EMPTY_CONTEXT);
    const out = new Set<number>();
    for (let r = 1; r <= 40; r++) {
      if (String(base.value(sheet, `B${r}`) ?? '').replace(/\s+/g, ' ').trim().toLowerCase() !== NAME_HEADER) continue;
      for (let c = 3; c <= 12; c++) {
        const h = base.value(sheet, `${indexToCol(c + 1)}${r}`);
        if (typeof h === 'number' && h > 0 && h < 10) out.add(h);
      }
      break;
    }
    return [...out].sort((a, b) => a - b);
  }

  // The terms and the bank details printed under the Proforma tab of the workbook (so the proforma carries what the template says).
  proformaTexts(): { terms: string[]; bankEur: string[]; bankUsd: string[] } | null {
    const sd = this.wb.sheets.get('Proforma');
    if (!sd) return null;
    const ev = this.evaluator(this.defaults, EMPTY_CONTEXT);
    const col = (c: string, from: number, to: number) => {
      const out: string[] = [];
      for (let r = from; r <= to; r++) {
        const v = firstLine(ev.value('Proforma', `${c}${r}`));
        if (v) out.push(v);
      }
      return out;
    };
    // find where the terms and the two bank blocks start
    let terms = -1;
    let eur = -1;
    let usd = -1;
    for (let r = 1; r <= sd.maxRow + 1; r++) {
      const a = firstLine(ev.value('Proforma', `A${r}`));
      if (a.startsWith('>> Terms')) terms = r;
      for (const c of ['AF', 'AE', 'AD', 'AG']) {
        const t = firstLine(ev.value('Proforma', `${c}${r}`));
        if (/bank details for euro/i.test(t)) eur = r;
        if (/bank details for usd/i.test(t)) usd = r;
      }
    }
    if (terms < 0) return null;
    const bankCol = ['AF', 'AE', 'AD', 'AG'].find((c) => /bank details/i.test(firstLine(ev.value('Proforma', `${c}${eur > 0 ? eur : terms}`)))) ?? 'AF';
    return {
      terms: col('A', terms + 1, terms + 12).filter((t) => !/^(delivery|payment|dispatch)/i.test(t)),
      bankEur: eur > 0 ? col(bankCol, eur + 1, eur + 8) : [],
      bankUsd: usd > 0 ? col(bankCol, usd + 1, usd + 8) : [],
    };
  }

  // What each product cell would print with these settings (for the picker's live prices).
  preview(params: OfferParams): PreviewSection[] {
    const opts = this.formatOptions(params);
    return this.layouts.map((layout) => {
      const ev = this.evaluator({ ...params, transportPct: params.pagePct?.[layout.tab] ?? params.transportPct }, EMPTY_CONTEXT);
      const sd = this.wb.sheets.get(layout.tab)!;
      const cells: PreviewSection['cells'] = {};
      for (const r of layout.dataRows) {
        cells[r + 1] = {};
        for (const { id } of layout.columns) {
          const raw = sd.cells.get(`${id}${r + 1}`);
          cells[r + 1][id] = raw ? formatCell(ev.value(layout.tab, `${id}${r + 1}`), raw.z, opts) : '';
        }
      }
      return { sheet: layout.tab, cells };
    });
  }

  // ---- printing -----------------------------------------------------------------

  // A whole worksheet that is a document of its own (the MOQ pages, the packaging details), printed as the Excel draws it.
  renderDocument(kind: 'moq' | 'packaging', params: OfferParams, ctx: OfferContext): Promise<Buffer> {
    const tab = kind === 'moq' ? MOQ_TAB : PACKAGING_TAB;
    if (!this.wb.sheets.has(tab) || !this.biff.sheets.has(tab)) return Promise.reject(new Error(`The price list has no ${tab} tab.`));
    const doc = new PDFDocument({ autoFirstPage: false, margin: 0, info: { Title: `tece ${tab}`, Author: 'tece' } });
    const chunks: Buffer[] = [];
    doc.on('data', (c: Buffer) => chunks.push(c));
    const done = new Promise<Buffer>((resolve, reject) => {
      doc.on('end', () => resolve(Buffer.concat(chunks)));
      doc.on('error', reject);
    });
    registerSheetFonts(doc);
    drawSheet({
      doc, sheet: this.wb.sheets.get(tab)!, biff: this.biff, biffSheet: this.biff.sheets.get(tab)!, ev: this.evaluator(params, ctx), format: this.formatOptions(params),
      hideRows: new Set(), hideCols: new Set(), letterhead: loadLetterhead(), tr: ctx.tr,
    });
    doc.end();
    return done;
  }

  // style: 'classic' prints each worksheet as Excel draws it; 'tece' draws the same pages, rows and columns in the TECE design
  render(params: OfferParams, ctx: OfferContext, selections: SectionSelection[], includeMoq: boolean, style: 'classic' | 'tece' = 'classic'): Promise<Buffer> {
    const doc = new PDFDocument({ autoFirstPage: false, margin: 0, info: { Title: 'tece offer', Author: 'tece' } });
    const chunks: Buffer[] = [];
    doc.on('data', (c: Buffer) => chunks.push(c));
    const done = new Promise<Buffer>((resolve, reject) => {
      doc.on('end', () => resolve(Buffer.concat(chunks)));
      doc.on('error', reject);
    });
    registerSheetFonts(doc);
    const letterhead = loadLetterhead();
    // widths come three at a time: the first three on the page itself, any further ones on an extra copy of it
    const groups: number[][] = [];
    for (let i = 0; i < params.widths.length; i += 3) groups.push(params.widths.slice(i, i + 3));
    if (!groups.length) groups.push(this.defaults.widths);
    const ev = this.evaluator({ ...params, widths: groups[0] }, ctx);
    const format = this.formatOptions(params);

    for (const layout of this.layouts) {
      const sel = selections.find((s) => s.sheet === layout.tab);
      if (!sel) continue;
      const sd = this.wb.sheets.get(layout.tab)!;
      const wantRows = new Set(sel.rows.map((r) => r - 1));
      const wantCols = new Set(sel.columns.map((c) => colToIndex(c) - 1));
      if (!layout.dataRows.some((r) => wantRows.has(r)) || !wantCols.size) continue;

      // hide unselected product rows; keep one blank spacer after each group that
      // still has rows, and drop spacers that would be left leading or doubled up
      const hideRows = new Set<number>();
      const showRows = new Set<number>();
      const kept: number[] = [];
      for (let r = layout.firstRow; r <= layout.lastRow; r++) {
        // a row the Excel hides (another thickness) is printed when the offer asks for it
        const hiddenInExcel = sd.hiddenRows.has(r) || (sd.rowHeightPt.get(r) ?? 15) <= 0.5;
        if (hiddenInExcel && !(layout.hiddenRows.has(r) && wantRows.has(r))) continue;
        if (layout.dataRows.includes(r)) {
          if (wantRows.has(r)) {
            kept.push(r);
            if (hiddenInExcel) showRows.add(r);
          } else hideRows.add(r);
        } else {
          const prev = kept[kept.length - 1];
          if (prev !== undefined && layout.dataRows.includes(prev)) kept.push(r);
          else hideRows.add(r);
        }
      }

      const hideCols = new Set<number>();
      const showCols = new Set<number>();
      for (const { index, hidden } of layout.columns) {
        if (!wantCols.has(index)) hideCols.add(index);
        else if (hidden) showCols.add(index); // a column the Excel hides (another thickness) that the offer asks for
      }

      const wcols = this.widthCols.get(layout.tab) ?? [];
      // this page may carry its own price increase / decrease; the others follow the offer's
      const tabParams: OfferParams = { ...params, transportPct: params.pagePct?.[layout.tab] ?? params.transportPct };
      // each copy of the page shows as many widths as the tab has width columns (Melamine has two, the others three)
      const per = Math.min(3, wcols.length || 3);
      const tabGroups: number[][] = [];
      if (wcols.length) for (let i = 0; i < params.widths.length; i += per) tabGroups.push(params.widths.slice(i, i + per));
      const used = wcols.length && tabGroups.length ? tabGroups : [groups[0]];
      if (style === 'tece') {
        // the TECE design: one page per product, every width as a column of it
        const area = this.biff.sheets.get(layout.tab)!.print.area ?? { r1: 0, c1: 0, r2: sd.maxRow - 1, c2: sd.maxCol - 1 };
        drawDesignedSheet({
          doc, sheet: sd, layout, wantRows, wantCols, area, format, ctx, params: tabParams,
          evGroups: used.map((g) => this.evaluator({ ...tabParams, widths: g }, ctx)), groupWidths: used, widthCols: wcols, letterhead,
        });
        continue;
      }
      for (const group of used) {
        // fewer than three widths in this group: the unused width columns are left out
        const hide = new Set(hideCols);
        for (const w of wcols) if (w.slot >= group.length) hide.add(w.index);
        drawSheet({
          doc, sheet: sd, biff: this.biff, biffSheet: this.biff.sheets.get(layout.tab)!,
          ev: this.evaluator({ ...tabParams, widths: group }, ctx), format,
          hideRows, hideCols: hide, showRows, showCols, letterhead,
        });
      }
    }

    if (includeMoq && this.hasMoq) {
      drawSheet({
        doc, sheet: this.wb.sheets.get(MOQ_TAB)!, biff: this.biff, biffSheet: this.biff.sheets.get(MOQ_TAB)!, ev, format,
        hideRows: new Set(), hideCols: new Set(), letterhead, tr: ctx.tr,
      });
    }

    doc.end();
    return done;
  }
}

