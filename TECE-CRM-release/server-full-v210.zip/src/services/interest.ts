// What a visitor is interested in: ticked products, anything else typed in,
// and the edge widths (mm). Linked to the offers: the ticked products decide
// which price pages are suggested, the widths become the offer's edge widths.

export interface InterestProduct {
  key: string;
  label: string;
  // Tab of the price workbook that prices this product (none for Metal).
  sheet: string | null;
}

export const INTEREST_PRODUCTS: InterestProduct[] = [
  { key: 'pvc', label: 'PVC', sheet: 'PVC M2+22' },
  { key: 'abs', label: 'ABS', sheet: 'ABS M2+22' },
  { key: 'pp', label: 'PP', sheet: 'PP M2+22' },
  { key: 'hybrid', label: 'Hybrid', sheet: 'Hybrid M2+22' },
  { key: 'digital', label: 'Digital', sheet: 'Digital M2+22' },
  { key: 'airtec', label: 'Airtec', sheet: 'Airtec' },
  { key: 'airabs', label: 'Air ABS', sheet: 'Air ABS' },
  { key: 'hotmelt', label: 'Hot melt', sheet: 'Hot_Melt' },
  { key: 'metal', label: 'Metal', sheet: null },
  { key: 'melamine', label: 'Melamine', sheet: 'Melamine' },
  { key: 'veneer', label: 'Veneer', sheet: 'Veneer' },
  { key: 'screw', label: 'Screw covers', sheet: 'Screw' },
  { key: 'machines', label: 'Machines', sheet: 'Accessories for distributor' },
];

export const PRODUCT_KEYS = new Set(INTEREST_PRODUCTS.map((p) => p.key));
// The widths offered as one-tap choices; any other width can be typed.
export const COMMON_WIDTHS = [22, 33, 44];

export interface Interest {
  products: string[];
  other: string;
  widths: number[];
}

function normalise(s: string): string {
  return s
    .normalize('NFD')
    .replace(/\p{Diacritic}/gu, '')
    .replace(/ı/g, 'i')
    .toLowerCase();
}

const RULES: { key: string; pattern: RegExp }[] = [
  { key: 'pvc', pattern: /\bpvc\b/ },
  { key: 'abs', pattern: /\babs\b/ },
  { key: 'pp', pattern: /\bpp\b|polipropilen|polypropylene/ },
  { key: 'metal', pattern: /\bmetal|alumin|\balu\b|\binox\b|stainless|paslanmaz|\bsteel\b|celik/ },
  { key: 'melamine', pattern: /melamin/ },
  { key: 'veneer', pattern: /veneer|kaplama|natural wood|dogal ahsap/ },
  { key: 'screw', pattern: /screw|vida/ },
  { key: 'hybrid', pattern: /hybrid|hibrit/ },
  { key: 'digital', pattern: /digital|dijital/ },
  { key: 'airtec', pattern: /airtec/ },
  { key: 'airabs', pattern: /air ?abs/ },
  { key: 'hotmelt', pattern: /hot ?melt/ },
  { key: 'machines', pattern: /machine|makine|makina|edge ?bander|kenar ?bantlama|bantlama|trimmer|rewinding|slitting|glue pot|accessor|aksesuar/ },
];

// Reads the words written on the form (the "Interested in" box, the work area
// and the handwritten notes) and ticks what they mention. Edge widths are only
// taken from the two short printed boxes or written with "mm", so a stray 22 or
// 33 in a phone number or quantity is not mistaken for a width.
export function detectInterest(parts: { interestedIn?: string | null; workArea?: string | null; notes?: string | null }): Interest {
  const boxes = normalise([parts.interestedIn, parts.workArea].filter(Boolean).join(' \n '));
  const all = normalise([parts.interestedIn, parts.workArea, parts.notes].filter(Boolean).join(' \n '));

  const products = RULES.filter((r) => r.pattern.test(all)).map((r) => r.key);

  const widths = new Set<number>();
  for (const w of COMMON_WIDTHS) {
    const bare = new RegExp(`(?<![\\d.,])${w}(?![\\d])`);
    const withMm = new RegExp(`(?<![\\d.,])${w}\\s*mm\\b`);
    if (bare.test(boxes) || withMm.test(all)) widths.add(w);
  }

  // Words in the box that no tick covers are kept as "other" so nothing written is lost.
  const written = (parts.interestedIn ?? '').trim();
  const other = written && products.length === 0 ? written : '';
  return { products, other, widths: [...widths].sort((a, b) => a - b) };
}

export function sanitiseWidths(value: unknown): number[] {
  if (!Array.isArray(value)) return [];
  const out = new Set<number>();
  for (const v of value) {
    const n = typeof v === 'number' ? v : parseInt(String(v), 10);
    if (Number.isInteger(n) && n >= 5 && n <= 1000) out.add(n);
  }
  return [...out].sort((a, b) => a - b);
}

export function sanitiseProducts(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return INTEREST_PRODUCTS.map((p) => p.key).filter((k) => value.includes(k));
}

// Reads the stored columns of a card.
export function parseInterest(card: { interest_products?: string | null; interest_other?: string | null; interest_widths?: string | null }): Interest {
  const parse = (s: string | null | undefined): unknown => {
    try { return s ? JSON.parse(s) : []; } catch { return []; }
  };
  return {
    products: sanitiseProducts(parse(card.interest_products)),
    other: (card.interest_other ?? '').trim(),
    widths: sanitiseWidths(parse(card.interest_widths)),
  };
}

type InterestCard = {
  interested_in?: string | null;
  work_area?: string | null;
  notes?: string | null;
  interest_products?: string | null;
  interest_other?: string | null;
  interest_widths?: string | null;
};

// The card's ticks. Cards saved before the tick boxes existed have none stored
// yet, so they are read from the words on the form instead.
export function interestOf(card: InterestCard): Interest {
  if (card.interest_products == null && card.interest_other == null && card.interest_widths == null) {
    return detectInterest({ interestedIn: card.interested_in, workArea: card.work_area, notes: card.notes });
  }
  return parseInterest(card);
}

// "PVC, ABS, Other: wood grain" for the Excel, report and dashboard.
export function interestLabel(card: InterestCard): string {
  const i = interestOf(card);
  const names = INTEREST_PRODUCTS.filter((p) => i.products.includes(p.key)).map((p) => p.label);
  if (i.other) names.push(`Other: ${i.other}`);
  // Cards from before the tick boxes: show the words written on the form.
  if (names.length === 0) return (card.interested_in ?? '').trim();
  return names.join(', ');
}

export function widthsLabel(card: InterestCard): string {
  const w = interestOf(card).widths;
  return w.length ? `${w.join(', ')} mm` : '';
}
