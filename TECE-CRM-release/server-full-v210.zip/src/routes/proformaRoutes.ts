import { Router, type Response } from 'express';
import multer from 'multer';
import { db } from '../db/connection';
import { requireAdmin, requireAuth, type AuthedRequest } from '../middleware/auth';
import { cardModel, type CardRow } from '../models/cardModel';
import { activityModel } from '../models/activityModel';
import { settingsModel } from '../models/settingsModel';
import { canSeeCard } from '../services/visibility';
import { priceMarketFor } from '../services/priceMarket';
import { activePriceBook } from '../services/priceBook/store';
import { colorBySap, colorDbStatus, importColorDatabase, searchColors } from '../services/colorDb';
import {
  linesFromFreeText, linesFromTable, parseOrderFile, parseOrderText, priceProforma, type Adjustment, type LineInput, type Mapping, type ProformaData, type ProformaHeader,
} from '../services/proforma';
import { archivePdf } from '../services/archive';
import { audit } from '../services/audit';
import { priceReview } from '../services/opportunities';
import { customerLevels } from '../services/customerLevel';
import { parseExcelProforma } from '../services/excelProformaPrices';
import { cleanDoc, docLines, importDocs, memoryFor, priceMap, removeDoc, type DocInput } from '../services/customerPrices';
import { forwardToStaff } from '../services/forwardMail';
import { proformaFileName, renderProformaPdf, renderProformaXlsx, type ProformaStyle } from '../services/proformaPdf';

const router = Router();
router.use(requireAuth);

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 15 * 1024 * 1024 } });

const str = (v: unknown, max = 300) => String(v ?? '').trim().slice(0, max);
const nul = (v: unknown): number | null => {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
};

// What the browser sends is cleaned here: every text is cut to size, every number checked.
export function cleanData(body: Record<string, unknown> | undefined): ProformaData {
  const b = (body ?? {}) as Record<string, unknown>;
  const h = (b.header ?? {}) as Record<string, unknown>;
  const header: ProformaHeader = {
    name: str(h.name, 120), company: str(h.company, 160), address: str(h.address, 400), tel: str(h.tel, 80), email: str(h.email, 200), sapNumber: str(h.sapNumber, 40),
    preparedBy: str(h.preparedBy, 120), date: /^\d{4}-\d{2}-\d{2}$/.test(str(h.date, 10)) ? str(h.date, 10) : new Date().toISOString().slice(0, 10), reference: str(h.reference, 80),
    deliveryTerm: str(h.deliveryTerm, 200), paymentTerm: str(h.paymentTerm, 300), dispatchTime: str(h.dispatchTime, 300), notes: str(h.notes, 600),
  };
  const lines: LineInput[] = (Array.isArray(b.lines) ? b.lines : []).slice(0, 400).map((x) => {
    const l = (x ?? {}) as Record<string, unknown>;
    return {
      code: str(l.code, 80), description: str(l.description, 200), sap: str(l.sap, 30), meters: nul(l.meters), thickness: nul(l.thickness), width: nul(l.width), rollLength: nul(l.rollLength),
      priceM2: nul(l.priceM2), sapSource: (['column', 'row', 'code', 'typed'] as const).find((s) => s === l.sapSource) ?? null,
    };
  });
  const adjustments: Adjustment[] = (Array.isArray(b.adjustments) ? b.adjustments : []).slice(0, 8).map((x) => {
    const a = (x ?? {}) as Record<string, unknown>;
    return { label: str(a.label, 80), mode: a.mode === 'amount' ? 'amount' : 'percent', value: nul(a.value) ?? 0 };
  });
  return { header, currency: b.currency === 'USD' ? 'USD' : 'EUR', usdRate: nul(b.usdRate) ?? 1.1, transportPct: nul(b.transportPct) ?? 0, lines, adjustments, ...(b.useMemory === false ? { useMemory: false } : {}), ...(b.useLevel === true ? { useLevel: true } : {}) };
}

// the customer's own prices (from their SAP proformas) go into the data, only for this customer and only when they have some
export function withMemory(data: ProformaData, card: CardRow | null): ProformaData {
  // the customer's SAP prices are used ONLY in the offer (Offer > Prices from SAP files). A proforma is never priced from them automatically.
  if (!card || data.useMemory !== true) return data;
  const prices = priceMap(card.id, data.currency);
  if (!Object.keys(prices).length) return data;
  // the customer's usual level against the list is an estimate for products they never bought: only when the person ticks it for this proforma
  let levels: Record<string, number> | undefined;
  if (data.useLevel === true) { try { levels = customerLevels(card.id, data.currency); } catch { /* the level is only a help: the list price stays */ } }
  return { ...data, memory: { prices, ...(levels ? { levels } : {}) } };
}

function openCard(req: AuthedRequest, res: Response, id: unknown): CardRow | null {
  const card = cardModel.findById(parseInt(String(id), 10));
  if (!card) { res.status(404).json({ error: 'Customer not found' }); return null; }
  if (!canSeeCard(req.user, card)) { res.status(403).json({ error: 'You do not have access to this record' }); return null; }
  return card;
}

// the price list of this customer's market (null when there is none, or the person may not use it)
function bookFor(req: AuthedRequest, card: CardRow | null) {
  const market = priceMarketFor(req.user!, card?.market ?? req.user!.market);
  return market ? activePriceBook(market)?.book ?? null : null;
}

// ---- the prices of an old customer, learned from their SAP proformas ----------------------------------------------------------------------------
router.get('/memory/:cardId', (req: AuthedRequest, res) => {
  const card = openCard(req, res, req.params.cardId);
  if (!card) return;
  res.json(memoryFor(card.id));
});
router.post('/memory/:cardId/import', (req: AuthedRequest, res) => {
  const card = openCard(req, res, req.params.cardId);
  if (!card) return;
  const docs = (Array.isArray(req.body?.docs) ? req.body.docs : []).slice(0, 60).map((x: unknown) => cleanDoc(x)).filter((d: DocInput | null): d is DocInput => !!d);
  if (!docs.length) return res.status(400).json({ error: 'No priced lines were found in these files.' });
  const before = memoryFor(card.id).count;
  const r = importDocs(card.id, docs, req.user!.id);
  audit(req.user, card.id, 'prices', 'Customer own prices', `${before} products`, `${memoryFor(card.id).count} products`, `from SAP proforma ${docs.map((d: DocInput) => d.proformaNo).join(', ')}`);
  activityModel.add({ userId: req.user!.id, cardId: card.id, type: 'documents', text: `Prices learned from ${r.docs} SAP proforma(s): ${docs.map((d: DocInput) => d.proformaNo).join(', ')}` });
  res.json({ ...r, memory: memoryFor(card.id) });
});
// Excel proformas (older orders, one .xls each): read here and returned in the same shape as a PDF read in the browser, so the person checks the customer and the prices are learned
router.post('/memory/parse-excel', (req: AuthedRequest, res) => {
  upload.array('files', 30)(req, res, (uploadErr) => {
    if (uploadErr) return res.status(400).json({ error: 'The files could not be received (up to 15 MB each).' });
    const files = (req.files ?? []) as Express.Multer.File[];
    const docs = files.map((f) => {
      try { return { ...parseExcelProforma(f.buffer), fileName: f.originalname, unreadable: false }; }
      catch { return { proformaNo: '', date: '', customer: '', currency: '' as const, adjustPct: 0, subTotal: null, grand: null, lines: [], skipped: 0, warnings: ['This file could not be opened as an Excel proforma.'], fileName: f.originalname, unreadable: true }; }
    });
    res.json({ docs });
  });
});
router.delete('/memory/:cardId/doc/:docId', (req: AuthedRequest, res) => {
  const card = openCard(req, res, req.params.cardId);
  if (!card) return;
  removeDoc(card.id, parseInt(String(req.params.docId), 10));
  audit(req.user, card.id, 'prices', 'Customer own prices', 'a proforma', 'forgotten', `proforma id ${req.params.docId}`);
  res.json(memoryFor(card.id));
});
// the lines of an earlier order: the next order starts from them
router.get('/memory/:cardId/doc/:docId/lines', (req: AuthedRequest, res) => {
  const card = openCard(req, res, req.params.cardId);
  if (!card) return;
  const d = docLines(card.id, parseInt(String(req.params.docId), 10));
  if (!d) return res.status(404).json({ error: 'Not found' });
  res.json(d);
});

// a proforma whose own prices are far below the standard: Abdullah gets a review (nobody is stopped)
export function reviewProforma(user: { id: number; display_name?: string | null; username?: string }, card: CardRow | null, data: ProformaData, book: ReturnType<typeof bookFor>): void {
  if (!card || !data.memory) return;
  const priced = priceProforma(data, book);
  let actual = 0; let standard = 0;
  for (const l of priced.lines) if (l.priceSource === 'memory' && l.listPriceM2 && l.m2) { actual += (l.priceM2 ?? 0) * l.m2; standard += l.listPriceM2 * l.m2; }
  if (standard <= 0) return;
  priceReview(user, card.id, { indexPct: Math.round((actual / standard - 1) * 1000) / 10, gap: Math.round((actual - standard) * 100) / 100, goods: Math.round(actual * 100) / 100, currency: data.currency, note: `${priced.lines.filter((l) => l.priceSource === 'memory').length} lines at the customer's own prices` });
}

// ---- the colour database ----------------------------------------------------------------------------------------------------------------
router.get('/colors/status', (_req, res) => {
  res.json(colorDbStatus());
});

// Everybody may look a colour up (the person typing a proforma); only an admin replaces the database.
router.get('/colors/search', (req, res) => {
  res.json(searchColors(str(req.query.q, 80), Math.min(40, Math.max(1, parseInt(String(req.query.limit ?? '25'), 10) || 25))));
});
router.get('/colors/by-sap', (req, res) => {
  res.json(colorBySap(str(req.query.sap, 30)));
});
router.post('/colors/import', requireAdmin, (req, res) => {
  upload.single('file')(req, res, (uploadErr) => {
    if (uploadErr) return res.status(400).json({ error: uploadErr.message });
    if (!req.file) return res.status(400).json({ error: 'Choose the colour database (.xlsx) to upload.' });
    try {
      res.status(201).json(importColorDatabase(req.file.buffer, req.file.originalname));
    } catch (err) {
      res.status(422).json({ error: (err as Error).message });
    }
  });
});

// ---- reading an order -------------------------------------------------------------------------------------------------------------------
// A file (Excel / CSV) or pasted text. Plain lines ("12000 Black color, 22mm x 2mm 5000 meter") become order lines at once; a table gets its columns guessed
// (the person can correct them), then /lines turns the rows into order lines.
router.post('/parse', (req: AuthedRequest, res) => {
  upload.single('file')(req, res, (uploadErr) => {
    if (uploadErr) return res.status(400).json({ error: uploadErr.message });
    const product = ['PVC', 'ABS', 'PP'].includes(str(req.body?.product, 4)) ? (str(req.body.product, 4) as 'PVC' | 'ABS' | 'PP') : null;
    try {
      if (req.file) return res.json({ mode: 'table', table: parseOrderFile(req.file.buffer, str(req.body?.sheet, 60) || undefined) });
      const text = str(req.body?.text, 60000);
      if (!text) return res.status(400).json({ error: 'Paste the order or choose a file.' });
      const table = parseOrderText(text);
      // a pasted table that names its columns is read as a table; anything else line by line
      if (table.headerFound && table.mapping.meters !== undefined) return res.json({ mode: 'table', table });
      res.json({ mode: 'lines', lines: linesFromFreeText(text, { product }) });
    } catch (err) {
      console.error('Reading an order failed:', err);
      res.status(422).json({ error: 'This order could not be read. Try pasting the text, or add the lines by hand.' });
    }
  });
});

router.post('/lines', (req, res) => {
  const rows = Array.isArray(req.body?.rows) ? (req.body.rows as unknown[]).slice(0, 1000).map((r) => (Array.isArray(r) ? r.map((c) => str(c, 200)) : [])) : [];
  const m = (req.body?.mapping ?? {}) as Record<string, unknown>;
  const mapping: Mapping = {};
  for (const f of ['code', 'description', 'sap', 'meters', 'rolls', 'thickness', 'width', 'rollLength'] as const) if (Number.isInteger(m[f]) && (m[f] as number) >= 0) mapping[f] = m[f] as number;
  res.json({ lines: linesFromTable(rows, mapping, { thickness: nul(req.body?.thickness), width: nul(req.body?.width) }) });
});

// ---- pricing and documents ----------------------------------------------------------------------------------------------------------------
// The starting point for a customer: the details of the customer, and the terms of the price list (the same as the offer's).
router.get('/start/:cardId', (req: AuthedRequest, res) => {
  const card = openCard(req, res, req.params.cardId);
  if (!card) return;
  const book = bookFor(req, card);
  const header: ProformaHeader = {
    name: card.name ?? '', company: card.company ?? '', address: card.address ?? '', tel: card.tel || card.mobile || '', email: card.email ?? '', sapNumber: card.sap ?? '',
    preparedBy: req.user!.display_name || req.user!.username, date: new Date().toISOString().slice(0, 10), reference: '',
    deliveryTerm: book?.defaults.deliveryTerm ?? '', paymentTerm: book?.defaults.paymentTerm ?? '', dispatchTime: book?.defaults.dispatchTime ?? '', notes: '',
  };
  const style = settingsModel.get('offer_style') === 'classic' ? 'standard' : 'tece';
  res.json({ header, currency: book?.defaults.currency ?? 'EUR', usdRate: 1.1, hasPriceList: !!book, colors: colorDbStatus(), defaultStyle: style });
});

router.post('/price', (req: AuthedRequest, res) => {
  const card = req.body?.cardId ? openCard(req, res, req.body.cardId) : null;
  if (req.body?.cardId && !card) return;
  res.json(priceProforma(withMemory(cleanData(req.body?.data), card), bookFor(req, card)));
});

router.post('/pdf', async (req: AuthedRequest, res) => {
  const card = req.body?.cardId ? openCard(req, res, req.body.cardId) : null;
  if (req.body?.cardId && !card) return;
  const data = withMemory(cleanData(req.body?.data), card);
  const style: ProformaStyle = req.body?.style === 'standard' ? 'standard' : 'tece';
  try {
    const pdf = await renderProformaPdf(data, bookFor(req, card), style);
    reviewProforma(req.user!, card, data, bookFor(req, card));
    if (card) archivePdf({ kind: 'proforma', cardId: card.id, title: `Proforma ${data.header.company || data.header.name || ''}${nul(req.body?.version) ? ` v${nul(req.body?.version)}` : ''}`, fileName: proformaFileName(data.header.company || data.header.name, 'pdf', nul(req.body?.version) ?? undefined), pdf, userId: req.user!.id });
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="${proformaFileName(data.header.company || data.header.name, 'pdf', nul(req.body?.version) ?? undefined)}"`);
    res.send(pdf);
  } catch (err) {
    console.error('Proforma PDF failed:', err);
    res.status(500).json({ error: 'The proforma could not be made.' });
  }
});

// the proforma as it is on the screen, made into a PDF and forwarded to a colleague (internal; nothing goes to the customer)
router.post('/forward', async (req: AuthedRequest, res) => {
  const card = req.body?.cardId ? openCard(req, res, req.body.cardId) : null;
  if (req.body?.cardId && !card) return;
  const data = withMemory(cleanData(req.body?.data), card);
  const style: ProformaStyle = req.body?.style === 'standard' ? 'standard' : 'tece';
  try {
    const pdf = await renderProformaPdf(data, bookFor(req, card), style);
    const name = data.header.company || data.header.name || '';
    const r = await forwardToStaff({
      sender: req.user!, staffId: Number(req.body?.userId), note: str(req.body?.note, 1500), what: `Proforma ${name}`.trim(),
      attachments: [{ filename: proformaFileName(name, 'pdf', nul(req.body?.version) ?? undefined), content: pdf, contentType: 'application/pdf' }],
    });
    res.json({ ok: true, ...r });
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

router.post('/xlsx', async (req: AuthedRequest, res) => {
  const card = req.body?.cardId ? openCard(req, res, req.body.cardId) : null;
  if (req.body?.cardId && !card) return;
  const data = withMemory(cleanData(req.body?.data), card);
  try {
    const xlsx = await renderProformaXlsx(data, bookFor(req, card));
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${proformaFileName(data.header.company || data.header.name, 'xlsx', nul(req.body?.version) ?? undefined)}"`);
    res.send(xlsx);
  } catch (err) {
    console.error('Proforma Excel failed:', err);
    res.status(500).json({ error: 'The Excel file could not be made.' });
  }
});

// ---- saved proformas (with versions) -------------------------------------------------------------------------------------------------------
interface SavedRow { id: number; card_id: number; created_by: number | null; title: string | null; version: number; parent_id: number | null; data: string; created_at: string; updated_at: string }

const summaryOf = (r: SavedRow) => {
  let lines = 0;
  try { lines = (JSON.parse(r.data) as { lines?: unknown[] }).lines?.length ?? 0; } catch { /* an unreadable draft is listed anyway */ }
  return { id: r.id, title: r.title, version: r.version, parentId: r.parent_id, lines, createdAt: r.created_at, updatedAt: r.updated_at };
};

router.get('/card/:cardId', (req: AuthedRequest, res) => {
  const card = openCard(req, res, req.params.cardId);
  if (!card) return;
  res.json((db.prepare('SELECT * FROM proformas WHERE card_id = ? ORDER BY COALESCE(parent_id, id) DESC, version DESC').all(card.id) as unknown as SavedRow[]).map(summaryOf));
});

router.get('/saved/:id', (req: AuthedRequest, res) => {
  const row = db.prepare('SELECT * FROM proformas WHERE id = ?').get(parseInt(String(req.params.id), 10)) as SavedRow | undefined;
  if (!row || !openCard(req, res, row.card_id)) return;
  res.json({ ...summaryOf(row), data: JSON.parse(row.data) });
});

// Save: the first time it is version 1. "Save as a new version" (newVersion: true) keeps the earlier ones and numbers the next (v2, v3 ...).
router.post('/card/:cardId', (req: AuthedRequest, res) => {
  const card = openCard(req, res, req.params.cardId);
  if (!card) return;
  const data = cleanData(req.body?.data);
  const book = bookFor(req, card);
  const priced = priceProforma(data, book);
  const title = str(req.body?.title, 120) || `Proforma ${new Date().toISOString().slice(0, 10)}`;
  const existing = req.body?.id ? (db.prepare('SELECT * FROM proformas WHERE id = ? AND card_id = ?').get(parseInt(String(req.body.id), 10), card.id) as SavedRow | undefined) : undefined;
  let id: number;
  let version = 1;
  if (existing && req.body?.newVersion !== true) {
    db.prepare("UPDATE proformas SET data = ?, title = ?, updated_at = datetime('now') WHERE id = ?").run(JSON.stringify(data), title, existing.id);
    id = existing.id;
    version = existing.version;
  } else {
    const root = existing ? existing.parent_id ?? existing.id : null;
    version = root ? ((db.prepare('SELECT MAX(version) AS v FROM proformas WHERE id = ? OR parent_id = ?').get(root, root) as { v: number }).v ?? 1) + 1 : 1;
    id = Number(db.prepare('INSERT INTO proformas (card_id, created_by, title, version, parent_id, data) VALUES (?, ?, ?, ?, ?, ?)').run(card.id, req.user!.id, title, version, root, JSON.stringify(data)).lastInsertRowid);
    activityModel.add({
      userId: req.user!.id, cardId: card.id, type: 'file', imported: false,
      text: `Proforma${version > 1 ? ` v${version}` : ''} made: ${data.lines.length} lines, ${priced.totals.grand.toLocaleString('en-GB')} ${data.currency}`,
    });
  }
  res.status(201).json({ id, version });
});

router.delete('/saved/:id', (req: AuthedRequest, res) => {
  const row = db.prepare('SELECT * FROM proformas WHERE id = ?').get(parseInt(String(req.params.id), 10)) as SavedRow | undefined;
  if (!row || !openCard(req, res, row.card_id)) return;
  db.prepare('DELETE FROM proformas WHERE id = ?').run(row.id);
  res.json({ ok: true });
});

export default router;
