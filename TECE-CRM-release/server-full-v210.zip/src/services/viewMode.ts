import { AsyncLocalStorage } from 'node:async_hooks';
import { userModel } from '../models/userModel';

// "Salesperson" or "Manager" - the switch in the top bar. In manager mode the customers of the people who report to this person
// are open to them as well (their names, contact details and account details); in salesperson mode only their own work shows.
// The mode travels with the request (the browser sends it in a header), so no function needs an extra parameter.
interface Ctx { userId: number; manager: boolean; ids?: number[]; names?: string[] }
const als = new AsyncLocalStorage<Ctx>();

export const viewMode = {
  run<T>(userId: number, manager: boolean, fn: () => T): T { return als.run({ userId, manager }, fn); },
  // everybody below this person (their ids and names) - only while the request is in manager mode
  team(userId: number): { ids: number[]; names: string[] } {
    const c = als.getStore();
    if (!c || !c.manager || c.userId !== userId) return { ids: [], names: [] };
    if (!c.ids) {
      const users = userModel.listAll();
      const ok = (u: { is_active: number; is_assistant: number; assists_id: number | null }) => !!u.is_active && !u.is_assistant && !u.assists_id;
      const seen = new Set<number>([userId]); let level = [userId]; const out: typeof users = [];
      for (let d = 0; level.length && d < 12; d += 1) {
        const next: number[] = [];
        for (const u of users) if (u.manager_id !== null && level.includes(u.manager_id) && !seen.has(u.id) && ok(u)) { seen.add(u.id); out.push(u); next.push(u.id); }
        level = next;
      }
      c.ids = out.map((u) => u.id);
      c.names = out.map((u) => u.display_name).filter((n): n is string => !!n);
    }
    return { ids: c.ids, names: c.names ?? [] };
  },
};
