// E-mail safety: nothing leaves the CRM with a hole in it.
// The checks run in one place (sendThankYouEmail), so every route that sends mail gets them:
//  - a merge field that is empty or was never filled in ("{{name}}", "undefined", "Dear ,")
//  - a thank-you for a "fair" that is not a fair ("Direct contacts", "Domestic customers")
//  - a name with a stray space ("Dear Emir ,")
import { db } from '../db/connection';
import { memoTables } from '../db/dataVersion';

// The CRM keeps these two as pseudo-fairs: a bucket for visits, calls, e-mails and SAP customers.
// They are places a record came from, not events a person visited.
const NOT_FAIRS = new Set(['direct contacts', 'domestic customers']);

// the default exhibition ("Database": where imported records land) is not a fair either
const defaultNames = memoTables(['exhibitions'], (): Set<string> => {
  try { return new Set((db.prepare('SELECT lower(trim(name)) AS n FROM exhibitions WHERE COALESCE(is_default, 0) = 1').all() as { n: string }[]).map((r) => r.n)); } catch { return new Set(); }
});
export function isRealFair(name: string | null | undefined): boolean {
  const n = (name ?? '').trim().toLowerCase();
  return n.length > 0 && !NOT_FAIRS.has(n) && !defaultNames().has(n);
}

// the name of the fair only when it is a real one
export const realFairName = (name: string | null | undefined): string | null => (isRealFair(name) ? (name ?? '').trim() : null);

// "  Emir   " -> "Emir"; "Emir ," -> "Emir"; empty parts vanish
export function cleanName(s: string | null | undefined): string {
  return (s ?? '')
    .replace(/[ ​]/g, ' ')
    .replace(/\s+/g, ' ')
    .replace(/[\s,;:]+$/g, '')
    .replace(/^[\s,;:]+/g, '')
    .trim();
}

export interface MailProblem {
  code: 'empty' | 'unresolved' | 'gap' | 'greeting' | 'not-a-fair' | 'no-fair';
  message: string;
}

// only the forms that take a name ("Dear ,"): a plain "Hello," is the deliberate greeting for a contact without a name
const GREETING_EMPTY = /^\s*(Dear|Sayın|Estimado\/a|Уважаемый\(ая\))\s*,\s*(\r?\n|$)/im;

// Looks at the final text. kind 'thank_you' needs a real fair: a thank-you for a visit that never happened must not go out.
export function mailProblems(input: { subject: string; body: string; kind?: string | null; fairName?: string | null }): MailProblem[] {
  const out: MailProblem[] = [];
  const subject = input.subject ?? '';
  const body = input.body ?? '';
  const all = `${subject}\n${body}`;
  if (!subject.trim()) out.push({ code: 'empty', message: 'The subject is empty.' });
  if (!body.trim()) out.push({ code: 'empty', message: 'The text is empty.' });

  const holes = all.match(/\{\{[^}]*\}\}|\{[a-z_]{2,}\}|<<[^>]*>>|\bundefined\b|\bnull\b|\bNaN\b/gi);
  if (holes) out.push({ code: 'unresolved', message: `A field was not filled in: ${Array.from(new Set(holes.map((h) => h.trim()))).slice(0, 4).join(', ')}.` });

  if (/\S[ \t]+,/.test(all)) out.push({ code: 'gap', message: 'There is a stray space before a comma (an empty or untrimmed name).' });
  if (/\b(at|for|from|with|about|of|to)[ \t]+[.,;](?!\w)/i.test(all)) out.push({ code: 'gap', message: 'A sentence ends where a name should be.' });
  if (GREETING_EMPTY.test(body)) out.push({ code: 'greeting', message: 'The greeting has no name.' });

  const mentionsPseudo = Array.from(NOT_FAIRS).find((p) => all.toLowerCase().includes(p));
  if (mentionsPseudo) out.push({ code: 'not-a-fair', message: `"${mentionsPseudo}" is not a fair, the text must not name it.` });

  if (input.kind === 'thank_you' && !isRealFair(input.fairName)) {
    out.push({ code: 'no-fair', message: 'This record does not name a real fair, so a thank-you for a visit cannot be sent. Write a personal e-mail or an introduction instead.' });
  }
  return out;
}

export class MailBlockedError extends Error {
  problems: MailProblem[];
  status = 422;
  constructor(problems: MailProblem[]) {
    super(`Not sent: ${problems.map((p) => p.message).join(' ')}`);
    this.name = 'MailBlockedError';
    this.problems = problems;
  }
}

// ids of the exhibitions that are real fairs (not the "Direct contacts" / "Domestic customers" buckets)
export function realFairIds(): Set<number> {
  try {
    const rows = db.prepare('SELECT id, name FROM exhibitions').all() as { id: number; name: string }[];
    return new Set(rows.filter((r) => isRealFair(r.name)).map((r) => r.id));
  } catch {
    return new Set();
  }
}

// the fair a card belongs to, by name (null when the record has none)
export function fairNameOfCard(cardId: number | null | undefined): string | null {
  if (!cardId) return null;
  try {
    const row = db.prepare('SELECT e.name AS name FROM cards c JOIN exhibitions e ON e.id = c.exhibition_id WHERE c.id = ?').get(cardId) as { name: string } | undefined;
    return row?.name ?? null;
  } catch {
    return null;
  }
}
