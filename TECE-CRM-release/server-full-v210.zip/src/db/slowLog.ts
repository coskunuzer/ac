import type { DatabaseSync } from 'node:sqlite';
import { dropAllKept, noteTableWrite } from './dataVersion';

// Remembers the slowest database questions and web requests, so "the CRM is slow" can be answered with names instead of guesses.
export interface SlowRow { at: string; ms: number; what: string }
const rows: SlowRow[] = [];
const keep = (r: SlowRow) => { rows.push(r); if (rows.length > 300) rows.shift(); };
export const slowRows = (): SlowRow[] => [...rows].reverse();
export const noteSlow = (what: string, ms: number): void => {
  if (ms >= 400) keep({ at: new Date().toISOString(), ms: Math.round(ms), what: what.slice(0, 300) });
  // the request that ended right after the server was held up is the one that held it (see watchServer)
  if (held && performance.now() - held.at < 4000 && ms >= held.ms * 0.6) { const h = held; held = null; reportHeld(h.ms, what); }
  else if (ms >= 800) lastDone = { at: performance.now(), ms, what };
};

// ---- "the whole CRM stood still" --------------------------------------------------------------------------------------------------
// This server answers one thing at a time. When one answer needs seconds of work (not waiting: work), everybody else waits behind it - in the
// usage log that shows as ten requests of one page all taking the same 5 or 15 seconds. A clock that should tick twice a second notices when it
// could not, and writes down who held the server: in the list of Admin > slow, and as a "slow" line of the usage log (page "(server)"), so the
// next usage log names the cause instead of the victims.
let held: { at: number; ms: number } | null = null;
let lastDone: { at: number; ms: number; what: string } | null = null; // a long request that ended a moment before the clock noticed
let lastSql = '';
let lastReport = 0;
let saveHeld: ((ms: number, what: string) => void) | null = null;
function reportHeld(ms: number, what: string): void {
  keep({ at: new Date().toISOString(), ms: Math.round(ms), what: `SERVER HELD UP by ${what}`.slice(0, 300) });
  if (ms < 2000 || Date.now() - lastReport < 10_000) return;
  lastReport = Date.now();
  try { saveHeld?.(Math.round(ms), what); } catch { /* the log is not worth failing for */ }
}
export function watchServer(db: DatabaseSync): void {
  saveHeld = (ms, what) => { db.prepare("INSERT INTO ux_events (user_id, session, at, kind, route, target, extra) VALUES (NULL, 'server', ?, 'slow', '(server)', ?, ?)").run(new Date().toISOString(), `held up by ${what}`.replace(/\s+/g, ' ').slice(0, 90), JSON.stringify({ ms })); };
  const EVERY = 500;
  let due = performance.now() + EVERY;
  setInterval(() => {
    const now = performance.now();
    const late = now - due;
    due = now + EVERY;
    // one that nobody claimed (a background job, not a request): named by the last question it asked the database
    if (held && now - held.at >= 4000) { const h = held; held = null; reportHeld(h.ms, `a background job (last question: ${lastSql.replace(/\s+/g, ' ').slice(0, 60)})`); }
    if (late >= 1000) {
      if (lastDone && now - lastDone.at < 600 && lastDone.ms >= late * 0.6) { reportHeld(late, lastDone.what); lastDone = null; }
      else held = { at: now, ms: late };
    }
  }, EVERY).unref();
}

// What a statement writes to: null for a plain read. `wide` = its reach is not known for sure (a delete or a replace can cascade to other
// tables, anything that is not a simple insert / update): then everything that is kept in memory is dropped.
// `counted` = an insert / update / delete, whose own count of changed rows can be trusted (0 = nothing was written).
function writeTarget(sql: string): { table: string | null; wide: boolean; counted: boolean; cascade?: boolean } | null {
  const s = sql.replace(/^(\s|--[^\n]*\n|\/\*[\s\S]*?\*\/)+/, '');
  if (/^(select|explain|values)\b/i.test(s)) return null;
  if (/^pragma\b/i.test(s)) return null;
  if (/^with\b/i.test(s) && !/\b(insert|update|delete|replace)\b/i.test(s)) return null;
  const ins = /^insert\s+(or\s+(\w+)\s+)?into\s+["`[]?(\w+)/i.exec(s);
  if (ins) return { table: ins[3], wide: (ins[2] ?? '').toLowerCase() === 'replace', counted: true, cascade: (ins[2] ?? '').toLowerCase() === 'replace' };
  const upd = /^update\s+(or\s+\w+\s+)?["`[]?(\w+)/i.exec(s);
  if (upd) return { table: upd[2], wide: false, counted: true };
  const del = /^(?:delete\s+from|replace\s+into)\s+["`[]?(\w+)/i.exec(s);
  if (del) return { table: del[1], wide: true, counted: true, cascade: true };
  return { table: null, wide: true, counted: false };
}
// A delete / replace reaches other tables only when its table is the parent of a foreign key with an ON DELETE action, or has a trigger.
// Those tables are found from the schema (again whenever the schema changes); a delete from any other table counts as a write to that table only.
let reachStamp = -1; let reaching = new Set<string>();
function reachesOthers(prepare: (sql: string) => any, table: string): boolean {
  try {
    const v = Number((prepare('PRAGMA schema_version').get() as any)?.schema_version ?? 0);
    if (v !== reachStamp) {
      const out = new Set<string>();
      const tables = prepare("SELECT name, type, tbl_name FROM sqlite_master WHERE type IN ('table', 'trigger')").all() as { name: string; type: string; tbl_name: string }[];
      for (const t of tables) {
        if (t.type === 'trigger') { out.add(t.tbl_name.toLowerCase()); continue; }
        for (const fk of prepare(`PRAGMA foreign_key_list("${t.name.replace(/"/g, '""')}")`).all() as { table: string; on_delete: string }[]) {
          if (!/^(no action|restrict)$/i.test(fk.on_delete || 'NO ACTION')) out.add(String(fk.table).toLowerCase());
        }
      }
      reaching = out; reachStamp = v;
    }
    return reaching.has(table.toLowerCase());
  } catch { return true; }
}

/* eslint-disable @typescript-eslint/no-explicit-any */
// Wraps the database once:
//  - a statement is compiled once and kept (the same 1,200 questions are asked again and again; compiling one costs more than running
//    most of them - a page that asked 3,000 small questions spent a third of its time compiling),
//  - every statement is timed (the slow ones are remembered for Admin > slow),
//  - every write is reported to db/dataVersion.ts, so small lists kept in memory are dropped the moment their table changes.
export function timeStatements(db: DatabaseSync, limitMs = 120): void {
  const prepare = db.prepare.bind(db) as any;
  const compiled = new Map<string, any>();
  const MAX_KEPT = 1500;
  const build = (sql: string) => {
    const st = prepare(sql);
    const target = writeTarget(sql);
    for (const m of ['all', 'get', 'run']) {
      const orig = st[m].bind(st);
      st[m] = (...a: any[]) => {
        lastSql = sql;
        const t = performance.now();
        try {
          const r = orig(...a);
          if (target && !(m === 'run' && target.counted && r && Number(r.changes) === 0)) noteTableWrite(target.table, target.cascade ? reachesOthers(prepare, target.table!) : target.wide);
          return r;
        } finally {
          const ms = performance.now() - t;
          if (ms >= limitMs) keep({ at: new Date().toISOString(), ms: Math.round(ms), what: 'SQL ' + sql.replace(/\s+/g, ' ').slice(0, 300) });
        }
      };
    }
    // rows that are read one at a time (the big Excel exports) get a statement of their own: a kept one could be started again by another request half-way
    st.iterate = (...a: any[]) => { if (target) noteTableWrite(target.table, true); return prepare(sql).iterate(...a); };
    return st;
  };
  (db as any).prepare = (sql: string) => {
    let st = compiled.get(sql);
    if (st) return st;
    st = build(sql);
    if (sql.length <= 8000) {
      if (compiled.size >= MAX_KEPT) compiled.delete(compiled.keys().next().value as string);
      compiled.set(sql, st);
    }
    return st;
  };
  const exec = db.exec.bind(db) as any;
  (db as any).exec = (sql: string) => {
    try { return exec(sql); } finally {
      // a script, a delete, a rollback: what is kept in memory may no longer be true
      if (!/^\s*(begin|commit|end|pragma|savepoint|release)\b[^;]*;?\s*$/i.test(sql)) dropAllKept();
    }
  };
}
