// Two records of the same company get the same key: "Dizajn-DN d.o.o.", "DIZAJN DN doo" and "dizajn dn" all become "dizajndn".
// Legal endings and filler words are dropped; a key shorter than 3 letters is no key at all (nothing is matched on it).
const FILLER = new Set([
  'ltd', 'limited', 'llc', 'inc', 'incorporated', 'corp', 'corporation', 'co', 'company', 'gmbh', 'ag', 'kg', 'sa', 'sas', 'sarl', 'srl', 'spa', 'sl', 'slu',
  'bv', 'nv', 'oy', 'ab', 'as', 'aps', 'doo', 'dooel', 'zoo', 'sro', 'kft', 'ood', 'eood', 'ad', 'plc', 'pty', 'pte', 'sdn', 'bhd', 'jsc', 'ooo', 'oao', 'tic',
  'san', 'sti', 'ticaret', 'sanayi', 'anonim', 'sirketi', 'limitet', 've', 'the', 'and', 'et', 'und', 'dis', 'ith', 'ihr', 'pazarlama', 'ltda', 'sac', 'eirl', 'cia',
]);

export function companyKey(name: string | null | undefined): string | null {
  if (!name) return null;
  const words = name
    .replace(/İ/g, 'i')
    .normalize('NFD')
    .replace(/\p{Diacritic}/gu, '')
    .replace(/ı/g, 'i')
    .toLowerCase()
    // "S.R.L." and "d.o.o." are one word (srl, doo)
    .replace(/\b([a-z])\.\s?/g, '$1')
    .replace(/&/g, ' ')
    .replace(/[^a-z0-9]+/g, ' ')
    .split(' ')
    .filter(Boolean);
  const kept = words.filter((w) => !FILLER.has(w));
  const key = (kept.length ? kept : words).join('');
  return key.length >= 3 ? key : null;
}
