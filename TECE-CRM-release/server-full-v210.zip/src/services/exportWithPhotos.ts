import fs from 'fs';
import path from 'path';
import archiver from 'archiver';
import type { Response } from 'express';
import type { CardRow } from '../models/cardModel';
import type { Exhibition } from '../models/exhibitionModel';
import { buildCardsWorkbook } from './excelExport';
import { paths } from '../config/env';

// Streams a .zip containing the same .xlsx as the plain export, plus an
// images/ folder with every card's original uploaded photo, named so it's
// obvious which record it belongs to when browsing the folder by hand.
export async function streamCardsZipWithPhotos(
  res: Response,
  cards: CardRow[],
  exhibitionsById: Map<number, Exhibition>,
  filenameSuffix: string
): Promise<void> {
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', `attachment; filename="exhibition-cards${filenameSuffix}.zip"`);

  const archive = archiver('zip', { zlib: { level: 9 } });
  archive.on('error', (err) => {
    console.error('Zip export failed:', err);
    if (!res.headersSent) res.status(500);
    res.end();
  });
  archive.pipe(res);

  const workbookBuffer = await buildCardsWorkbook(cards, exhibitionsById);
  archive.append(Buffer.from(workbookBuffer), { name: 'records.xlsx' });

  for (const card of cards) {
    const fullPath = path.join(paths.uploadsDir, card.image_path);
    if (card.image_path && fs.existsSync(fullPath)) {
      const ext = path.extname(card.image_path);
      // \p{L}/\p{N} (Unicode letter/number, requires the 'u' flag) keep
      // accented names intact (Pejović, Şakuşić, etc.) - plain \w is
      // ASCII-only and silently drops every accented letter.
      const label = (card.name || card.company || 'unnamed').replace(/[^\p{L}\p{N}\- ]/gu, '').trim() || 'unnamed';
      archive.file(fullPath, { name: `images/${card.id}-${label}${ext}` });
    }
  }

  await archive.finalize();
}
