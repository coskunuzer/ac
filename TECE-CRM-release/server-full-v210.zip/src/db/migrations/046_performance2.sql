-- Performance, round 2: who looks after a SAP customer (an admin's correction beats everything else), and the AI's full suggestion per customer.
CREATE TABLE IF NOT EXISTS perf_rep_override (
  sap_no TEXT PRIMARY KEY,
  rep TEXT NOT NULL,
  by_user INTEGER,
  at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS perf_suggestions (
  sap_no TEXT PRIMARY KEY,
  body TEXT NOT NULL,
  made_at TEXT NOT NULL DEFAULT (datetime('now'))
);
