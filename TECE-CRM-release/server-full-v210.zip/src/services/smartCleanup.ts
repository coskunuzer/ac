import { db } from '../db/connection';
import { cardModel, SQL_LEADS } from '../models/cardModel';
import { askJson } from './perfActions';
import { duplicateGroups, mergeCards, type DupGroup } from './duplicates';
import { moveToJunk } from './junk';
import { norm } from './smartSearch';
import type { Viewer } from './visibility';

// The smart clean-up for the admin. Two jobs, both cheap:
//  1. duplicates: the same company in several records. Found by rules (no AI); the sure ones are put together in one click.
//  2. companies that are out of our league (a restaurant, a school, nonsense). Rules catch the obvious ones for free; the AI sees only the doubtful ones, 60 names in one short question,
//     and each company is judged once (the verdict is kept). Nothing is deleted: the companies go to the junk folder, where an admin can bring them back.

// ---- the free rules ----------------------------------------------------------------------------------------------------------------
// words of a company that has nothing to do with furniture or panels (several languages)
const OUT = ['restaurant', 'restoran', 'restaurante', 'cafe', 'kafe', 'cafeteria', 'bar ', 'pub ', 'hotel', 'otel', 'hostel', 'motel', 'hospital', 'hastane', 'clinic', 'klinik', 'pharmacy', 'eczane', 'farmacia', 'dental', 'dis hekimi', 'school', 'okul', 'colegio', 'escuela', 'university', 'universite', 'universidad', 'kindergarten', 'kres', 'bank', 'banka', 'banco', 'insurance', 'sigorta', 'seguros', 'church', 'kilise', 'mosque', 'cami', 'bakery', 'firin', 'panaderia', 'supermarket', 'supermercado', 'grocery', 'bakkal', 'butcher', 'kasap', 'airline', 'havayolu', 'travel agency', 'turizm', 'tourism', 'turismo', 'real estate', 'emlak', 'inmobiliaria', 'law firm', 'avukat', 'abogado', 'notary', 'noter', 'beauty', 'guzellik', 'salon', 'kuafor', 'barber', 'hairdress', 'clothing', 'giyim', 'ropa', 'fashion', 'moda', 'jewel', 'kuyumcu', 'joyeria', 'optic', 'optik', 'gym', 'fitness', 'spa ', 'wedding', 'dugun', 'florist', 'cicek', 'car wash', 'oto yikama', 'taxi', 'taksi', 'driving school', 'sürücü', 'surucu', 'mobile phone', 'telefon', 'computer', 'bilgisayar', 'software', 'yazilim', 'advertis', 'reklam', 'printing house', 'matbaa', 'photograph', 'foto', 'cinema', 'sinema', 'theatre', 'tiyatro', 'museum', 'muze', 'zoo ', 'pet shop', 'veteriner', 'veterinary', 'funeral', 'cenaze', 'tobacco', 'tutun', 'cigar', 'casino', 'kumar', 'bet ', 'nightclub', 'disco', 'massage', 'masaj', 'tattoo', 'dovme'];
// words of a company that may well buy edgebanding: never flagged by a rule
const IN = ['mobil', 'furniture', 'mueble', 'meuble', 'mobel', 'mobili', 'kitchen', 'mutfak', 'cocina', 'cuisine', 'kuche', 'cabinet', 'dolap', 'wood', 'ahsap', 'madera', 'bois', 'holz', 'legno', 'panel', 'board', 'mdf', 'chipboard', 'particle', 'plywood', 'laminat', 'melamin', 'veneer', 'kaplama', 'edge', 'kenar', 'kant', 'cant', 'carpent', 'marangoz', 'carpinter', 'joiner', 'schreiner', 'door', 'kapi', 'puerta', 'wardrobe', 'gardrop', 'interior', 'ic mimar', 'decor', 'dekor', 'workshop', 'atolye', 'timber', 'lumber', 'plast', 'pvc', 'abs', 'profil', 'doors', 'shopfit', 'joinery', 'millwork', 'closet', 'casework', 'mebel', 'nabytok', 'namestaj', 'furnit'];
// a name that is no name: only digits, one repeated letter, no vowels at all, a keyboard run
const nonsense = (n: string): boolean => {
  const s = n.replace(/[^a-z0-9]/g, '');
  if (s.length < 3) return true;
  if (/^\d+$/.test(s)) return true;
  if (/^(.)\1{3,}$/.test(s)) return true;
  if (/^(test|asdf|qwer|xxxx|aaaa|none|null|n a|na|unknown|bilinmiyor)$/.test(s)) return true;
  if (s.length >= 6 && !/[aeiouy]/.test(s)) return true;
  if (/(qwert|asdfg|zxcvb|12345)/.test(s)) return true;
  return false;
};

export interface Candidate { id: number; company: string | null; name: string | null; email: string | null; website: string | null; country: string | null; city: string | null; work_area: string | null; interested_in: string | null }
export type Verdict = 'remove' | 'keep' | 'unsure';
export interface Judged { id: number; verdict: Verdict; why: string; source: 'rule' | 'ai' }

export function ruleVerdict(c: Candidate): Judged | null {
  const company = norm(c.company); const name = norm(c.name);
  const text = ` ${company} ${norm(c.work_area)} ${norm(c.interested_in)} ${norm(c.website)} `;
  if (IN.some((w) => text.includes(w))) return { id: c.id, verdict: 'keep', why: 'Looks like our trade', source: 'rule' };
  if (!company && !name) return { id: c.id, verdict: 'remove', why: 'No name at all', source: 'rule' };
  if (company ? nonsense(company) && (!name || nonsense(name)) : nonsense(name)) return { id: c.id, verdict: 'remove', why: 'Not a real name', source: 'rule' };
  const hit = OUT.find((w) => text.includes(` ${w}`) || text.includes(w + ' ') || (w.length > 5 && text.includes(w)));
  if (hit) return { id: c.id, verdict: 'remove', why: `Not our trade (${hit.trim()})`, source: 'rule' };
  return null;
}

// the leads nobody has worked on, that have not been judged yet: only these can be removed here (a company with a note, an offer or a SAP number is never touched)
const CANDIDATES = `SELECT id, company, name, email, website, country, city, work_area, interested_in FROM cards
  WHERE ${SQL_LEADS} AND (sap IS NULL OR TRIM(sap) = '') AND exit_status IS NULL
    AND id NOT IN (SELECT card_id FROM cleanup_suggestions)
    AND NOT EXISTS (SELECT 1 FROM offers_sent o WHERE o.card_id = cards.id)
    AND NOT EXISTS (SELECT 1 FROM activities a WHERE a.card_id = cards.id AND a.type IN ('note','call','visit','meeting','sample','offer','thank_you','email','documents'))
    AND NOT EXISTS (SELECT 1 FROM complaints c WHERE c.card_id = cards.id)
    AND NOT EXISTS (SELECT 1 FROM opportunities op WHERE op.card_id = cards.id)
  ORDER BY id`;

export function candidates(limit: number): Candidate[] {
  return db.prepare(`${CANDIDATES} LIMIT ?`).all(limit) as unknown as Candidate[];
}
export function candidateCount(): number {
  return (db.prepare(`SELECT COUNT(*) AS n FROM (${CANDIDATES})`).get() as { n: number }).n;
}

const save = (j: Judged) => db.prepare("INSERT INTO cleanup_suggestions (card_id, verdict, why, source) VALUES (?, ?, ?, ?) ON CONFLICT(card_id) DO UPDATE SET verdict = excluded.verdict, why = excluded.why, source = excluded.source, at = datetime('now')").run(j.id, j.verdict, j.why.slice(0, 120), j.source);

// ---- the AI sees only the doubtful ones: one short line each, 60 in one question ----------------------------------------------------
const domain = (w: string | null) => (w ?? '').replace(/^https?:\/\//i, '').replace(/^www\./i, '').split('/')[0].slice(0, 40);
async function askBatch(list: Candidate[]): Promise<Judged[] | null> {
  const lines = list.map((c) => `${c.id}|${(c.company || c.name || '').slice(0, 50)}|${c.country ?? ''}|${domain(c.website)}|${(c.work_area ?? c.interested_in ?? '').slice(0, 40)}`).join('\n');
  const j = await askJson([
    'TECE makes edgebanding (PVC, ABS, PP, melamine edge tape) for furniture and wood panels. Its customers are furniture makers, kitchen and cabinet makers, joiners, panel and board distributors, shopfitters, door makers and edgebanding traders.',
    'Below are companies from a big lead list, one per line: id|name|country|web domain|what they do. For each id say whether it is worth keeping as a lead. remove = clearly NOT a possible buyer (a restaurant, a school, a shop for clothes, a law firm, nonsense, a private person with no trade); keep = a possible buyer or related to wood, furniture, building or panels; unsure = you cannot tell from this line. When in doubt say unsure, never remove.',
    'Answer as JSON {r:[{id, v: "remove"|"keep"|"unsure", w: why in at most 6 words}]} with every id once.',
    lines,
  ].join('\n\n'), { type: 'OBJECT', properties: { r: { type: 'ARRAY', items: { type: 'OBJECT', properties: { id: { type: 'INTEGER' }, v: { type: 'STRING' }, w: { type: 'STRING' } }, required: ['id', 'v'] } } }, required: ['r'] });
  if (!j || !Array.isArray(j.r)) return null;
  const ids = new Set(list.map((c) => c.id));
  return (j.r as { id?: number; v?: string; w?: string }[]).filter((x) => x.id !== undefined && ids.has(Number(x.id))).map((x) => ({ id: Number(x.id), verdict: x.v === 'remove' ? 'remove' as const : x.v === 'keep' ? 'keep' as const : 'unsure' as const, why: String(x.w ?? '').slice(0, 80) || 'AI', source: 'ai' as const }));
}

// scan: rules first (free), then (if asked) the AI for the doubtful ones, up to `max` companies
export async function scan(opts: { ai: boolean; max: number }): Promise<{ looked: number; byRule: number; byAi: number; doubtful: number; aiCalls: number; aiFailed: boolean }> {
  const out = { looked: 0, byRule: 0, byAi: 0, doubtful: 0, aiCalls: 0, aiFailed: false };
  const rows = candidates(Math.max(60, opts.max * 4));
  const doubtful: Candidate[] = [];
  for (const c of rows) {
    out.looked += 1;
    const v = ruleVerdict(c);
    if (v) { save(v); out.byRule += 1; } else doubtful.push(c);
  }
  out.doubtful = doubtful.length;
  if (opts.ai) {
    const todo = doubtful.slice(0, opts.max);
    for (let i = 0; i < todo.length; i += 60) {
      const batch = todo.slice(i, i + 60);
      const r = await askBatch(batch);
      out.aiCalls += 1;
      if (!r) { out.aiFailed = true; break; }
      for (const j of r) { save(j); out.byAi += 1; }
    }
  }
  return out;
}

export interface Suggestion { id: number; company: string | null; name: string | null; country: string | null; website: string | null; email: string | null; why: string; source: string; at: string }
export function suggestions(verdict: Verdict, limit = 400): Suggestion[] {
  return db.prepare('SELECT c.id, c.company, c.name, c.country, c.website, c.email, s.why, s.source, s.at FROM cleanup_suggestions s JOIN cards c ON c.id = s.card_id WHERE s.verdict = ? ORDER BY s.at DESC, c.id LIMIT ?').all(verdict, limit) as unknown as Suggestion[];
}
export function summary(): { toCheck: number; remove: number; keep: number; unsure: number } {
  const n = (v: string) => (db.prepare('SELECT COUNT(*) AS n FROM cleanup_suggestions WHERE verdict = ?').get(v) as { n: number }).n;
  return { toCheck: candidateCount(), remove: n('remove'), keep: n('keep'), unsure: n('unsure') };
}
export function markKeep(ids: number[]): number {
  let n = 0;
  for (const id of ids) { save({ id, verdict: 'keep', why: 'Kept by a person', source: 'rule' }); db.prepare("UPDATE cleanup_suggestions SET source = 'person' WHERE card_id = ?").run(id); n += 1; }
  return n;
}

// removing = to the junk folder (an admin can bring it back); only a lead that is still untouched is moved
export function removeToJunk(ids: number[], userId: number): { moved: number; skipped: number } {
  let moved = 0; let skipped = 0;
  const ok = new Set((db.prepare(`SELECT id FROM (${CANDIDATES.replace('AND id NOT IN (SELECT card_id FROM cleanup_suggestions)', '')}) WHERE id IN (${ids.map((n) => Math.trunc(n)).join(',') || '0'})`).all() as { id: number }[]).map((r) => r.id));
  for (const id of ids) {
    const card = ok.has(id) ? cardModel.findById(id) : undefined;
    if (!card) { skipped += 1; continue; }
    try { moveToJunk(card, `Clean-up: ${(db.prepare('SELECT why FROM cleanup_suggestions WHERE card_id = ?').get(id) as { why: string } | undefined)?.why ?? 'not our trade'}`, userId); db.prepare('DELETE FROM cleanup_suggestions WHERE card_id = ?').run(id); moved += 1; } catch { skipped += 1; }
  }
  return { moved, skipped };
}

// ---- duplicates: how sure are we ---------------------------------------------------------------------------------------------------
export interface DupInfo { group: DupGroup; sure: boolean; blocker: string | null }
export function dupInfo(viewer: Viewer, limit = 400): DupInfo[] {
  return duplicateGroups(viewer, limit).map((g) => {
    const saps = new Set(g.members.map((m) => (db.prepare('SELECT sap FROM cards WHERE id = ?').get(m.id) as { sap: string | null } | undefined)?.sap?.trim()).filter(Boolean));
    const strong = g.reasons.length >= 2 || (g.reasons.length === 1 && /name/i.test(g.reasons[0]) && g.members.every((m) => !!m.country || !!m.city));
    const blocker = saps.size > 1 ? 'Two different SAP numbers' : null;
    return { group: g, sure: strong && !blocker && g.members.length <= 6, blocker };
  });
}
export function mergeSure(viewer: Viewer, userId: number, only?: string[]): { groups: number; records: number; failed: number } {
  let groups = 0; let records = 0; let failed = 0;
  for (const info of dupInfo(viewer, 600)) {
    if (!info.sure || (only && !only.includes(info.group.key))) continue;
    const keep = info.group.keep;
    let ok = true;
    for (const m of info.group.members) {
      if (m.id === keep) continue;
      try { mergeCards(keep, m.id, userId, { prices: 'newest', complaints: 'move' }); records += 1; } catch { ok = false; failed += 1; }
    }
    if (ok) groups += 1;
  }
  return { groups, records, failed };
}
