import crypto from 'crypto';
import { Router, type Response } from 'express';
import multer from 'multer';
import { screenshotText } from '../services/screenshotText';
import { db } from '../db/connection';
import { requireAdmin, requireAuth, type AuthedRequest } from '../middleware/auth';
import { needAi } from '../services/aiBudget';
import { audit } from '../services/audit';
import { EDIT_FIELDS, explain, makePlan, runPlan } from '../services/assistant';

// The admin assistant (chat): it can read everything (read-only SQL written by the AI and checked by the server). A change is only PROPOSED and
// happens when the admin presses Apply (and can be undone).
const router = Router();
router.use(requireAuth, requireAdmin);

interface Proposal { ids: number[]; field: string; value: string; at: number; previous?: Map<number, string | null> }
const proposals = new Map<string, Proposal>();
const prune = () => { const old = Date.now() - 60 * 60 * 1000; for (const [k, p] of proposals) if (p.at < old) proposals.delete(k); };

const shots = multer({ storage: multer.memoryStorage(), limits: { fileSize: 12 * 1024 * 1024, files: 4 } });

async function chat(req: AuthedRequest, res: Response) {
  const question = String(req.body?.question ?? '').trim().slice(0, 6000);
  if (!question) return res.status(400).json({ error: 'Write a question first.' });
  const history = (Array.isArray(req.body?.history) ? req.body.history : []).slice(-3).map((h: { q?: string; a?: string }) => `Admin: ${String(h.q ?? '').slice(0, 300)}\nAssistant: ${String(h.a ?? '').slice(0, 400)}`).join('\n');
  const first = await makePlan(question, history);
  if (!first) return res.status(503).json({ ai: true, error: 'The AI could not answer just now. Try again.' });
  if (first.mode === 'chat') return res.json({ type: 'text', text: first.reply || 'Ask me anything about your customers, sales, balances, orders, complaints or the team, and I will look it up.' });

  let run;
  try { run = await runPlan(question, history, first); } catch (err) {
    return res.json({ type: 'text', text: `I could not run that query: ${(err as Error).message}. Try asking it differently.` });
  }
  const { plan, tables } = run;

  if (plan.mode === 'edit') {
    const spec = EDIT_FIELDS[plan.editField];
    if (!spec) return res.json({ type: 'text', text: `I can change: ${Object.values(EDIT_FIELDS).map((s) => s.label).join('; ')}. Which one do you want?` });
    if (spec.allowed && !spec.allowed(plan.editValue)) return res.json({ type: 'text', text: `"${plan.editValue}" is not a valid value for ${spec.label}.` });
    const t = tables[0];
    const idCol = t.columns.indexOf('id');
    if (idCol < 0) return res.json({ type: 'text', text: 'The list of customers to change must have their id. Ask again.' });
    const wanted = [...new Set(t.rows.map((r) => Number(r[idCol])).filter((n) => Number.isInteger(n) && n > 0))];
    const ids = wanted.length ? (db.prepare(`SELECT id FROM cards WHERE id IN (${wanted.map(() => '?').join(',')})`).all(...wanted) as { id: number }[]).map((r) => r.id) : [];
    if (!ids.length) return res.json({ type: 'text', text: 'No customer matches that, so there is nothing to change.' });
    prune();
    const token = crypto.randomBytes(8).toString('hex');
    proposals.set(token, { ids, field: plan.editField, value: plan.editValue, at: Date.now() });
    const first15 = ids.slice(0, 15);
    const show = db.prepare(`SELECT id, company, country, stage, person, handling FROM cards WHERE id IN (${first15.map(() => '?').join(',')})`).all(...first15) as Record<string, string | number | null>[];
    const cols = ['id', 'company', 'country', 'stage', 'person', 'handling'];
    return res.json({ type: 'edit', token, title: plan.title, field: spec.label, value: plan.editValue || '(by country)', total: ids.length, table: { title: plan.title, sql: t.sql, columns: cols, rows: show.map((o) => cols.map((c) => o[c] ?? null)), total: show.length, truncated: ids.length > show.length } });
  }

  const text = plan.explain ? await explain(question, tables) : null;
  if (plan.explain && !text) return res.status(503).json({ ai: true, error: 'The AI could not write the analysis just now. Try again.' });
  res.json({ type: 'result', title: plan.title, text, tables });
}
router.post('/chat', needAi, (req: AuthedRequest, res) => void chat(req, res));

// the question comes with screenshots (pasted into the chat): they are read into text first, then the question goes on as usual
router.post('/chat-image', needAi, shots.array('photos', 4), async (req: AuthedRequest, res) => {
  const files = (req.files as Express.Multer.File[] | undefined) ?? [];
  let history: unknown[] = [];
  try { history = JSON.parse(String(req.body?.history ?? '[]')) as unknown[]; } catch { history = []; }
  const asked = String(req.body?.question ?? '').trim();
  const text = files.length ? await screenshotText(files.map((f) => ({ data: f.buffer, mime: f.mimetype || 'image/png' })), 'They come from a CRM or an e-mail of an edgebanding company.') : null;
  if (files.length && !text) return res.status(503).json({ ai: true, error: 'The AI could not read the screenshot just now. Paste the text, or try again.' });
  req.body = { question: `${asked || 'What does this show, and what should I do?'}${text ? `\n\n[Text of the screenshot]\n${text}` : ''}`.slice(0, 6000), history };
  await chat(req, res);
});

router.post('/apply', (req: AuthedRequest, res) => {
  const p = proposals.get(String(req.body?.token ?? ''));
  if (!p || p.previous) return res.status(404).json({ error: 'This proposal has expired or was already applied. Ask again.' });
  const col = EDIT_FIELDS[p.field].column;
  const get = db.prepare(`SELECT ${col} AS v FROM cards WHERE id = ?`);
  const set = db.prepare(`UPDATE cards SET ${col} = ?, updated_at = datetime('now') WHERE id = ?`);
  const value = p.value === '' ? null : p.value;
  p.previous = new Map();
  db.exec('BEGIN');
  try {
    for (const id of p.ids) { const old = (get.get(id) as { v: string | null } | undefined)?.v ?? null; p.previous.set(id, old); set.run(value, id); if (p.ids.length <= 500) audit(req.user, id, 'assistant', p.field, old, value, 'by the AI assistant'); }
    db.exec('COMMIT');
  } catch (err) {
    db.exec('ROLLBACK');
    p.previous = undefined;
    console.error('Assistant apply failed:', err);
    return res.status(500).json({ error: 'The change could not be applied.' });
  }
  res.json({ ok: true, changed: p.ids.length });
});

router.post('/undo', (req: AuthedRequest, res) => {
  const p = proposals.get(String(req.body?.token ?? ''));
  if (!p?.previous) return res.status(404).json({ error: 'Nothing to undo.' });
  const col = EDIT_FIELDS[p.field].column;
  const set = db.prepare(`UPDATE cards SET ${col} = ?, updated_at = datetime('now') WHERE id = ?`);
  db.exec('BEGIN');
  try { for (const [id, v] of p.previous) set.run(v, id); db.exec('COMMIT'); } catch (err) { db.exec('ROLLBACK'); throw err; }
  proposals.delete(String(req.body.token));
  res.json({ ok: true });
});

export default router;
