-- Audit log: who changed what (price, owner, rating, handling, the customer's own prices ...)
CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  at TEXT NOT NULL DEFAULT (datetime('now')),
  user_id INTEGER,
  user_name TEXT,
  card_id INTEGER,
  action TEXT NOT NULL,          -- change | prices | assistant | review
  field TEXT,
  old_value TEXT,
  new_value TEXT,
  note TEXT
);
CREATE INDEX IF NOT EXISTS idx_audit_card ON audit_log(card_id, at);
CREATE INDEX IF NOT EXISTS idx_audit_at ON audit_log(at);

-- Opportunities: an offer or proforma that was made, followed until it is won or lost
CREATE TABLE IF NOT EXISTS opportunities (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  card_id INTEGER NOT NULL REFERENCES cards(id) ON DELETE CASCADE,
  kind TEXT NOT NULL DEFAULT 'offer',            -- offer | proforma | other
  title TEXT NOT NULL,
  value REAL,
  currency TEXT NOT NULL DEFAULT 'EUR',
  status TEXT NOT NULL DEFAULT 'open',           -- open | won | lost
  expected_date TEXT,
  sap_order_no TEXT,                             -- the SAP order / proforma number, when it is known
  lost_reason TEXT,
  competitor TEXT,
  note TEXT,
  source_ref TEXT,                               -- offers_sent:12 / proforma:3 (so the same one is not made twice)
  created_by INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  closed_at TEXT,
  snoozed_until TEXT
);
CREATE INDEX IF NOT EXISTS idx_opp_card ON opportunities(card_id, status);
CREATE UNIQUE INDEX IF NOT EXISTS idx_opp_ref ON opportunities(source_ref) WHERE source_ref IS NOT NULL;

-- Price review: a proforma for a customer whose own prices are far below the standard (Abdullah looks at it; it never stops the work)
CREATE TABLE IF NOT EXISTS price_reviews (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  card_id INTEGER NOT NULL REFERENCES cards(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  created_by INTEGER,
  index_pct REAL,
  gap REAL,
  currency TEXT,
  goods REAL,
  note TEXT,
  reviewed_at TEXT,
  reviewed_by INTEGER,
  review_note TEXT
);
CREATE INDEX IF NOT EXISTS idx_pr_open ON price_reviews(reviewed_at, created_at);

-- Competitors and their battle cards (written by people; the AI only tailors them)
CREATE TABLE IF NOT EXISTS competitors (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  kind TEXT NOT NULL DEFAULT 'edge',             -- edge (edgebanding maker) | board (board maker: Egger, Kronospan ...) | other
  region TEXT,
  card_json TEXT NOT NULL DEFAULT '{}',          -- { summary, strengths[], weaknesses[], complaints[], angle[], questions[], avoid[], proof[], sources[] }
  verified INTEGER NOT NULL DEFAULT 0,           -- 1 when a person confirmed the card
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_by INTEGER
);
-- Where the customer buys edgebanding (the boards are in card_boards already)
CREATE TABLE IF NOT EXISTS card_suppliers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  card_id INTEGER NOT NULL REFERENCES cards(id) ON DELETE CASCADE,
  competitor_id INTEGER REFERENCES competitors(id) ON DELETE SET NULL,
  name TEXT,                                     -- when the supplier is not in the list
  source TEXT NOT NULL DEFAULT 'told',           -- told | site | guess
  share_pct INTEGER,
  note TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  created_by INTEGER
);
CREATE INDEX IF NOT EXISTS idx_cs_card ON card_suppliers(card_id);
CREATE TABLE IF NOT EXISTS card_approach (
  card_id INTEGER PRIMARY KEY REFERENCES cards(id) ON DELETE CASCADE,
  basis_hash TEXT,
  body_json TEXT,
  made_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Ledger: pairs a person fixed by hand (an invoice and the payment that settled it)
CREATE TABLE IF NOT EXISTS ledger_pins (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sap TEXT NOT NULL,
  invoice_tx INTEGER NOT NULL,
  payment_tx INTEGER NOT NULL,
  by_user INTEGER,
  at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (invoice_tx, payment_tx)
);
