import type { CardRow } from '../models/cardModel';
import type { OfferParams, PriceBook, SectionSelection } from './priceBook';
import { translateStrings, type Lang } from './translate';

export interface OfferPdfInput {
  card: CardRow;
  preparedBy: string;
  book: PriceBook;
  params: OfferParams;
  selections: SectionSelection[];
  includeMoq: boolean;
  date: Date;
  // 'tece' (the TECE design) or 'classic' (each worksheet as Excel draws it)
  style?: 'classic' | 'tece';
  // the language of the offer; only the TECE design can be translated (the Excel design prints the worksheets as they are)
  language?: Lang;
}

// The offer is the price workbook printed: customer details go into its Main tab
// and each product tab is drawn as Excel would draw it.
export async function renderOfferPdf(input: OfferPdfInput): Promise<Buffer> {
  const { card } = input;
  // the old Excel design is English only: another language always uses the TECE design
  const lang: Lang = input.language ?? 'en';
  const style = lang !== 'en' ? 'tece' : input.style ?? 'classic';
  const ctx = {
    name: card.name,
    company: card.company,
    address: card.address,
    country: card.country,
    tel: card.tel,
    email: card.email,
    preparedBy: input.preparedBy,
    date: input.date,
  };
  const draw = (extra: { lang?: string; tr?: (s: string) => string }) =>
    input.book.render(input.params, { ...ctx, ...extra }, input.selections, input.includeMoq, style);
  if (lang === 'en') return draw({});
  // first pass: find every text of the workbook that is on the pages; then translate them (the AI, remembered) and draw for real
  const seen = new Set<string>();
  await draw({ lang, tr: (s) => (seen.add(s), s) });
  const done = await translateStrings([...seen], lang);
  return draw({ lang, tr: (s) => done.get(s) ?? s });
}

// The MOQ pages and the packaging details in the language of the customer (the texts of the sheet are translated by the AI, once, and remembered).
export async function renderDocumentPdf(book: PriceBook, kind: 'moq' | 'packaging', params: OfferParams, ctx: Parameters<PriceBook['renderDocument']>[2], language: Lang | undefined): Promise<Buffer> {
  const lang: Lang = language ?? 'en';
  if (lang === 'en') return book.renderDocument(kind, params, ctx);
  const seen = new Set<string>();
  await book.renderDocument(kind, params, { ...ctx, lang, tr: (s) => (seen.add(s), s) });
  const done = await translateStrings([...seen], lang);
  return book.renderDocument(kind, params, { ...ctx, lang, tr: (s) => done.get(s) ?? s });
}
