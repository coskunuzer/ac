import fs from 'fs';
import sharp from 'sharp';
import { env } from '../config/env';
import { buildCardJsonSchema, type CardExtractionResult, type ExtractedCardFields } from '../schema/cardSchema';
import { COUNTRY_NAMES } from '../data/countries';
import { userModel } from '../models/userModel';
import { allEmailsValid } from './emailAddresses';
import { INSIGHT_RULES, normaliseInsight, ruleInsight } from './aiInsight';
import { detectInterest } from './interest';

const GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models';
// gemini-2.5-flash/pro were retired for new users after this app was first
// built. There is no escalation tier here on purpose: this account's plan
// has zero quota for every "pro" model (confirmed directly - gemini-pro-latest
// and gemini-3.6-pro both fail, one with 404 not-found, one with a 429 quota
// error naming gemini-3.1-pro at "limit: 0") so an escalation call could
// never succeed regardless of which pro model name is used. gemini-3.6-flash
// already reads these forms well; anything it can't confidently read is
// surfaced to the human reviewer via field_status instead of guessed at by
// a second model call.
export const DEFAULT_MODEL = 'gemini-3.6-flash';
const MAX_IMAGE_DIMENSION = 2000;

const SYSTEM_PROMPT = `You read a photographed paper exhibition visitor form for a Turkish edgebanding company (tece). Each form has a printed field grid (Name, Company, Address, Country, Tel, Email), often with a visitor's business card physically stapled on top of or beside it, a large handwritten free-text notes area (usually in Turkish), two printed boxes ("Interested in:" and "Work Area:"), and a footer strip (Date, Person, Rate - Rate is written like "3/10"; ignore any "Fair:" field on the footer, it is not needed).

Rules:
- The photo may be only a business card (or two), with no form around it: then read everything from the card, and leave the footer fields (date, person, rate) and the notes empty.
- If a business card is stapled to the form, prefer its printed text over the form's own grid for name/company/address/country/tel/email - it is the more reliable source.
- Sometimes two (rarely three) business cards are attached to one form. Then: name, company, address and country come from the FIRST card only (the card matching the form's own Name field if it has one, otherwise the top-most / left-most card). For tel and email, collect the phone numbers and the email addresses from ALL the cards: separate emails with ", " and phones with "; ", the first card's first. Everything printed on the second card (name, job title, company, address, phones, emails, website) goes into the notes field on its own line starting "Second business card: " (a third one starts "Third business card: "), after the handwritten notes. With a single card, none of this applies.
- Transcribe the handwritten notes verbatim, in the original language. Do NOT translate them.
- For "rate", extract only the numeric rating (e.g. "3/10" -> 3), not the denominator.
- The "country" and "person" fields are each constrained to a fixed list of allowed values (given in the schema) - match the handwriting/print to the closest allowed value. For "person" specifically, the handwriting is often just a first name or nickname (e.g. "Abdullah" should match "Abdullah Coskunuzer" if that's the only allowed value starting with Abdullah) - pick the closest match, or null if nothing reasonably matches.
- "position" is the visitor's job title (from the business card or the form), e.g. "Purchasing Manager" - not a company name, and not written into the notes.
- Never invent a value. If a field is blank on the form or genuinely illegible, its value must be null and its status "not_found".
- Use "uncertain" status for a field you could partially read or had to guess at (messy handwriting, ambiguous abbreviation) - do not mark a guess as "found".

${INSIGHT_RULES}`;

async function downscaleImage(filePath: string): Promise<{ base64: string; mediaType: string }> {
  const buffer = await sharp(filePath)
    .rotate()
    .resize({ width: MAX_IMAGE_DIMENSION, height: MAX_IMAGE_DIMENSION, fit: 'inside', withoutEnlargement: true })
    .jpeg({ quality: 85 })
    .toBuffer();
  return { base64: buffer.toString('base64'), mediaType: 'image/jpeg' };
}

// Gemini intermittently returns a plain 503 ("model overloaded") or 429
// (rate limited) even on a perfectly valid request - observed directly while
// diagnosing a real failed upload: the exact same request succeeded on one
// attempt and got a bare 503 on the next two. Neither is worth surfacing as
// a hard failure to the user, so these are retried a couple of times before
// giving up. A 4xx like 400 (bad request) is NOT retried - it will fail the
// same way every time.
class GeminiApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

const RETRY_DELAYS_MS = [1500, 3500];

function isTransient(err: unknown): boolean {
  if (err instanceof GeminiApiError) return err.status === 429 || err.status >= 500;
  // A fetch-level failure (DNS hiccup, connection reset, timeout) is also
  // worth one retry rather than an immediate blank-record fallback.
  return err instanceof TypeError;
}

async function callGeminiOnce(
  base64: string,
  mediaType: string,
  model: string,
  personEnum: string[],
  withInsight: boolean
): Promise<CardExtractionResult> {
  const res = await fetch(`${GEMINI_API_URL}/${model}:generateContent`, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-goog-api-key': env.geminiApiKey,
    },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
      contents: [
        {
          role: 'user',
          parts: [{ inlineData: { mimeType: mediaType, data: base64 } }],
        },
      ],
      generationConfig: {
        responseMimeType: 'application/json',
        responseSchema: buildCardJsonSchema(personEnum, withInsight),
        temperature: 0.2,
      },
    }),
  });

  if (!res.ok) {
    throw new GeminiApiError(res.status, `Gemini extraction failed (${res.status}): ${await res.text()}`);
  }

  const data = (await res.json()) as {
    candidates?: { content?: { parts?: { text?: string }[] }; finishReason?: string }[];
  };

  const candidate = data.candidates?.[0];
  const text = candidate?.content?.parts?.[0]?.text;
  if (!text) {
    throw new Error(`Gemini extraction returned no content (finishReason: ${candidate?.finishReason ?? 'unknown'})`);
  }
  return JSON.parse(text) as CardExtractionResult;
}

async function callGemini(
  base64: string,
  mediaType: string,
  model: string,
  personEnum: string[]
): Promise<CardExtractionResult> {
  // The AI also reads what the notes ask us to do, in the same call. If the API ever
  // refuses that part of the request, the form is still read the old way.
  let withInsight = true;
  const maxAttempts = RETRY_DELAYS_MS.length + 1;
  let lastErr: unknown;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      return await callGeminiOnce(base64, mediaType, model, personEnum, withInsight);
    } catch (err) {
      lastErr = err;
      if (withInsight && err instanceof GeminiApiError && err.status === 400) {
        console.warn('Gemini refused the request with insight, reading the form without it:', err.message.slice(0, 200));
        withInsight = false;
        attempt -= 1;
        continue;
      }
      if (attempt === maxAttempts || !isTransient(err)) throw err;
      console.warn(
        `Gemini call failed (attempt ${attempt}/${maxAttempts}), retrying: ${(err as Error).message}`
      );
      await new Promise((resolve) => setTimeout(resolve, RETRY_DELAYS_MS[attempt - 1]));
    }
  }
  throw lastErr;
}

function applySanityChecks(result: CardExtractionResult, personEnum: string[]): CardExtractionResult {
  const { fields, fieldStatus } = result;
  const status = { ...fieldStatus };

  // May hold several addresses (a second business card): every one must look valid.
  if (fields.email && !allEmailsValid(fields.email)) {
    status.email = 'uncertain';
  }
  // A literal 0 out of 10 is implausible for this business context - it
  // almost always means the model defaulted an empty box to 0 instead of
  // returning null, so treat it the same as "nothing was written" rather
  // than a real rating.
  if (fields.rate === 0) {
    fields.rate = null;
    status.rate = 'not_found';
  } else if (fields.rate !== null && (fields.rate < 1 || fields.rate > 10)) {
    status.rate = 'uncertain';
  }
  // The model has been observed reporting a field as "not_found" while
  // still returning a stray value for it - keep the two consistent so the
  // UI never shows a number next to a "not found, please fill in" flag.
  if (status.rate === 'not_found' && fields.rate !== null) {
    fields.rate = null;
  }
  // Defense in depth in case the model doesn't perfectly respect the enum
  // constraint on these two schema-constrained fields.
  if (fields.country !== null && !COUNTRY_NAMES.includes(fields.country)) {
    status.country = 'uncertain';
  }
  if (fields.person !== null && personEnum.length > 0 && !personEnum.includes(fields.person)) {
    status.person = 'uncertain';
  }

  // The insight is checked like everything else; without one (or with the AI down) it is read
  // from the words in plain rules, so the rest of the app always has an answer.
  const found = detectInterest({ interestedIn: fields.interestedIn, workArea: fields.workArea, notes: fields.notes });
  const insight = result.insight
    ? normaliseInsight(result.insight, 'ai')
    : ruleInsight({ notes: fields.notes, interested_in: fields.interestedIn, products: found.products, widths: found.widths, other: found.other });
  // An empty Work Area is filled from what the AI worked out about the company - marked as a guess.
  if (!fields.workArea && insight.companyActivity) {
    fields.workArea = insight.companyActivity;
    status.workArea = 'uncertain';
  }
  return { fields, fieldStatus: status, insight };
}

export interface ExtractionOutcome {
  result: CardExtractionResult;
  model: string;
}

export async function extractCardFromImage(filePath: string): Promise<ExtractionOutcome> {
  if (!env.geminiApiKey) {
    throw new Error('GEMINI_API_KEY is not configured on the server');
  }
  if (!fs.existsSync(filePath)) {
    throw new Error(`Image file not found: ${filePath}`);
  }

  const { base64, mediaType } = await downscaleImage(filePath);
  const personEnum = userModel
    .listActive()
    .map((u) => u.display_name)
    .filter((name): name is string => !!name);

  const result = applySanityChecks(await callGemini(base64, mediaType, DEFAULT_MODEL, personEnum), personEnum);
  return { result, model: DEFAULT_MODEL };
}

export type { ExtractedCardFields };
