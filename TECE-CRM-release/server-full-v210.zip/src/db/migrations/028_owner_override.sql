-- A customer that was given to somebody other than the usual person of its country (or city) is seen by that person only
-- (and by admins). 1 = the person set on the customer is the only one who looks after it.
ALTER TABLE cards ADD COLUMN owner_override INTEGER NOT NULL DEFAULT 0;
