-- Files attached to a newsletter (a PDF catalogue, a price list ...): they go with every e-mail of the campaign.
CREATE TABLE IF NOT EXISTS newsletter_files (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  newsletter_id INTEGER NOT NULL REFERENCES newsletters(id) ON DELETE CASCADE,
  original_name TEXT NOT NULL,
  stored_name TEXT NOT NULL,
  size INTEGER NOT NULL DEFAULT 0,
  mime TEXT,
  uploaded_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_nl_files ON newsletter_files(newsletter_id);
