-- Who looks after each country (the "Sales Manager" / "Operation Manager"
-- columns of the country list). Names are staff display names, the same
-- way a card's Person field works, so a rename in Users needs a re-save here.
CREATE TABLE IF NOT EXISTS country_assignments (
  key TEXT PRIMARY KEY,
  country TEXT NOT NULL,
  continent TEXT,
  responsible TEXT,
  assistant TEXT,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
