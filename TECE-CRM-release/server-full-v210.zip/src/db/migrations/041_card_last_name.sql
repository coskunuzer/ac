-- The last name of the first person at a company (the other people have theirs in card_contacts).
ALTER TABLE cards ADD COLUMN last_name TEXT;
