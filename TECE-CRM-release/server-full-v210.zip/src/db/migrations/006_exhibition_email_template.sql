ALTER TABLE exhibitions ADD COLUMN email_template_subject TEXT;
ALTER TABLE exhibitions ADD COLUMN email_template_body TEXT;
