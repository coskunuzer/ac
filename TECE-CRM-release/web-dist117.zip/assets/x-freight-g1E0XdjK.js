// Freight desk (Nakliye): the open work of Operations in the order it is done - ask for quotes, wait, compare and approve the best,
// look at the e-mails nobody could read, send the documents. Two sheets do the real work: comparing the quotes of one request and deciding,
// and turning goods that are ready into a request that only has to be confirmed.
import { h, Fragment, useState, useEffect, useMemo, useRef, useCallback, api, Link, Icon, cx, errText, Ring, Chip, Skel, toast } from "./x-kit-1W3jRMzJ.js";

// The Nakliye screens are written in Turkish for everybody (the people of Operations work in Turkish), so these parts are Turkish as well.
// Every text is kept under its English sentence: set LANG to "en" and the desk is English.
const LANG = "tr";
const TR = {
  "Today's work": "Bugünün işi",
  "What needs you now, in the order it is done.": "Şu an sizi bekleyenler, yapılma sırasıyla.",
  "Ask for quotes": "Teklif iste", "Wait for answers": "Yanıt bekle", "Decide": "Karar ver", "E-mails to look at": "Bakılacak e-postalar", "Send documents": "Belgeleri gönder",
  "Nothing is waiting. Well done.": "Bekleyen iş yok. Elinize sağlık.",
  "The shipping mailbox is not set up: requests and approvals cannot be e-mailed.": "Nakliye posta kutusu ayarlı değil: talepler ve onaylar e-postayla gönderilemez.",
  "An admin types the password on the Ayarlar tab.": "Yönetici şifreyi Ayarlar sekmesinden girer.",
  "Test mode is on: e-mails go only to {a}, not to the firms.": "Test modu açık: e-postalar firmalara değil yalnızca {a} adresine gider.",
  "Quotes to decide": "Karar bekleyen teklifler", "Every firm has answered first, then the oldest.": "Önce tüm firmaları yanıtlamış olanlar, sonra en eskiler.",
  "Compare and approve": "Karşılaştır ve onayla", "Compare the quotes": "Teklifleri karşılaştır", "Open": "Aç",
  "best": "en iyi", "next": "sonraki", "{n} quotes": "{n} teklif", "1 quote": "1 teklif", "all firms answered": "tüm firmalar yanıtladı", "{a} of {b} answered": "{b} firmadan {a} yanıt",
  "{n} to be typed by hand": "{n} tanesi elle girilecek", "{n} not all-in": "{n} tanesi all-in değil", "counter offer waiting": "karşı teklif bekliyor",
  "no price that can be compared yet": "henüz karşılaştırılabilir fiyat yok", "{h} h ago": "{h} sa önce", "{d} days ago": "{d} gün önce", "just now": "az önce",
  "Waiting for answers": "Yanıt beklenenler", "Nobody has answered these yet.": "Bunlara henüz kimse yanıt vermedi.",
  "sent to {n} firms": "{n} firmaya gönderildi", "Remind {n} firms": "{n} firmaya hatırlat", "Send the reminder to {n} silent firms?": "Sessiz kalan {n} firmaya hatırlatma gönderilsin mi?",
  "Reminder sent to {n} firms": "{n} firmaya hatırlatma gitti", "reminded": "hatırlatıldı", "a reminder can go after {h} h": "hatırlatma {h} sa sonra gönderilebilir", "Add firms": "Firma ekle",
  "To ask for quotes": "Teklif istenecekler", "Sales asked for these first; then the goods that are ready and have no request yet.": "Önce satışın istedikleri; sonra sevke hazır olup talebi olmayanlar.",
  "Sales asked": "Satış istedi", "Ready to ship": "Sevke hazır", "{n} lots": "{n} parti", "oldest {d} days": "en eskisi {d} gün", "Last time": "Geçen sefer", "same country": "aynı ülke",
  "Not needed": "Gerek yok", "Remove this ask of Sales?": "Satışın bu isteği kaldırılsın mı?", "See all {n}": "{n} tanesinin hepsini gör",
  "Unknown sender": "Tanınmayan gönderici", "Price could not be read": "Fiyat okunamadı", "E-mail did not go out": "E-posta gitmedi", "Reply could not be read": "Yanıt okunamadı",
  "Take it as a quote": "Teklif olarak al", "Ignore": "Yok say", "Send again": "Tekrar gönder", "Type the price": "Fiyatı gir", "Freight": "Navlun", "Extras": "Ek masraf", "Save the price": "Fiyatı kaydet",
  "Taken as a quote": "Teklif olarak alındı", "Price saved": "Fiyat kaydedildi", "Sent again": "Tekrar gönderildi", "Could not be sent": "Gönderilemedi",
  "Documents to send": "Gönderilecek belgeler", "Invoices of the last 45 days whose documents have not gone out. Late ones first.": "Son 45 günün belgeleri henüz gitmemiş faturaları. Gecikenler önce.",
  "late": "gecikti", "invoice": "fatura", "I send them": "Ben gönderiyorum", "Sent": "Gönderildi", "Mark the documents of {a} as sent?": "{a} belgeleri gönderildi olarak işaretlensin mi?",
  "with you ({a})": "sizde ({a})", "Customer page": "Müşteri sayfası", "A reminder was added to your to-dos": "Yapılacaklarınıza hatırlatma eklendi", "Marked as sent": "Gönderildi olarak işaretlendi",
  "Yes": "Evet", "Cancel": "Vazgeç", "Close": "Kapat", "Could not load": "Yüklenemedi", "Something went wrong": "Bir şey ters gitti", "Saving ...": "Kaydediliyor ...", "Sending ...": "Gönderiliyor ...",
  // compare
  "Request": "Talep", "pallets": "palet", "sent {t}": "{t} gönderildi", "Best price": "En iyi fiyat", "Next one": "Sonraki", "Average": "Ortalama", "Last shipment": "Son sevkiyat",
  "for this customer": "bu müşteri için", "to this country": "bu ülkeye", "{a} more": "{a} fazla", "the only price": "tek fiyat",
  "Compared in euro: 1 € = {a} $ (the rate of Performance). The amount the firm wrote is never changed.": "Karşılaştırma avro üzerinden: 1 € = {a} $ (Performans kuru). Firmanın yazdığı tutar değiştirilmez.",
  "1 € = {a} ₺ ({m})": "1 € = {a} ₺ ({m})", "Best": "En iyi", "Approve": "Onayla", "Approve the best": "En iyiyi onayla", "Approved": "Onaylandı", "Rejected": "Reddedildi", "Counter offer sent": "Karşı teklif gitti",
  "To be typed": "Elle girilecek", "Not all-in": "All-in değil", "Waiting for your decision": "Karar bekliyor",
  "freight {a} + extras {b}": "navlun {a} + ek {b}", "per kg": "kg başına", "per pallet": "palet başına", "{a} more than the best ({p}%)": "en iyiden {a} fazla (%{p})",
  "no rate for {c}: not compared": "{c} için kur yok: karşılaştırılmadı", "Left out of the price": "Fiyata dahil değil", "Ask for the all-in price": "All-in fiyat iste", "Asked for the all-in price": "All-in fiyat soruldu",
  "The firm's answer": "Firmanın yanıtı", "Show all": "Tamamını göster", "Show less": "Daha az", "answered {a} of {b} requests, won {c}": "{b} talepten {a} yanıt, {c} kazandı",
  "Counter offer": "Karşı teklif", "Your price": "Sizin fiyatınız", "Send the counter offer": "Karşı teklifi gönder", "Reject": "Reddet", "Reject the quote of {a}? They get an e-mail.": "{a} teklifi reddedilsin mi? Firmaya e-posta gider.",
  "Their counter offer: {a}": "Karşı teklifimiz: {a}", "The last e-mail to this firm did not go out": "Bu firmaya son e-posta gitmedi",
  "Silent firms": "Yanıt vermeyenler", "{h} h without an answer": "{h} saattir yanıt yok", "Nobody is silent.": "Sessiz kalan yok.", "Ask more firms": "Daha fazla firmaya sor",
  "These firms serve this destination and were not asked.": "Bu firmalar bu varışa hizmet veriyor ve onlara sorulmadı.", "Send to {n} firms": "{n} firmaya gönder", "Sent to {n} more firms": "{n} firmaya daha gönderildi",
  "Every firm that serves this destination was asked.": "Bu varışa hizmet veren tüm firmalara soruldu.",
  "All details and e-mails": "Tüm ayrıntılar ve yazışmalar", "Close without choosing": "Kimseyi seçmeden kapat", "Close this request without choosing anybody? Every firm is told.": "Talep kimse seçilmeden kapatılsın mı? Tüm firmalara bilgi verilir.",
  "You are approving": "Onaylıyorsunuz", "What happens now": "Şimdi ne olacak", "gets the approval": "onay e-postası alır", "get the rejection": "ret e-postası alır", "are told the request is closed": "talep kapandı bilgisi alır",
  "gets the summary": "özet e-postası alır", "The request is closed. This cannot be taken back.": "Talep kapanır. Bu işlem geri alınamaz.", "Yes, approve {a}": "Evet, {a} onayla",
  "The mailbox is not set up, so none of these e-mails can go out. Tell the firms yourself.": "Posta kutusu ayarlı değil; bu e-postaların hiçbiri gidemez. Firmalara siz haber verin.",
  "Approved: {a}, {b}": "Onaylandı: {a}, {b}", "No quote yet.": "Henüz teklif yok.", "This request is closed.": "Bu talep kapalı.", "closed": "kapalı",
  // ask
  "Ask for freight quotes": "Nakliye teklifi iste", "Check, then send. Nothing else is needed.": "Kontrol edin ve gönderin. Başka bir şey gerekmez.", "Orders that go": "Gidecek siparişler", "Destination": "Varış",
  "City": "Şehir", "Country": "Ülke", "How": "Taşıma türü", "Pallets": "Palet", "Weight, kg": "Ağırlık, kg", "Ready": "Hazır olma", "optional": "isteğe bağlı",
  "taken from this customer's last request": "bu müşterinin son talebinden alındı", "taken from the last request to this country": "bu ülkeye son talepten alındı", "chosen by which firms go there": "oraya giden firmalara göre seçildi",
  "In the price (all-in)": "Fiyata dahil olacaklar (all-in)", "Firms": "Firmalar", "{a} of {b} chosen": "{b} firmadan {a} seçili", "answers {p}%": "%{p} yanıtlıyor", "new": "yeni", "last": "son",
  "No firm serves this destination with this way of transport. Change the way, or add a firm on the Taşıma firmaları tab.": "Bu varışa bu taşıma türüyle hizmet veren firma yok. Türü değiştirin ya da Taşıma firmaları sekmesinden firma ekleyin.",
  "The e-mail the firms get": "Firmalara gidecek e-posta", "Send to {n} firms?": "{n} firmaya gönderilsin mi?", "Yes, send": "Evet, gönder", "Choose at least one firm.": "En az bir firma seçin.", "The destination country is needed.": "Varış ülkesi gerekli.",
  "Request {id} is out: sent to {n} firms.": "Talep {id} çıktı: {n} firmaya gönderildi.", "Could not go to": "Gidemeyenler", "Open the request": "Talebi aç", "Note of Sales": "Satışın notu", "Choose at least one order.": "En az bir sipariş seçin.",
  "All": "Hepsi", "None": "Hiçbiri", "Request {id} was made, but it could not be sent to any firm.": "Talep {id} oluşturuldu ama hiçbir firmaya gönderilemedi.",
};
const fill = (s, v) => (v ? s.replace(/\{(\w+)\}/g, (m, k) => (k in v ? String(v[k]) : m)) : s);
const t = (en, v) => fill(LANG === "tr" ? TR[en] || en : en, v);

const num = (v, d = 0) => (v == null ? "-" : Number(v).toLocaleString("tr-TR", { maximumFractionDigits: d }));
const money = (v, c, d) => (v == null ? "-" : `${num(v, d ?? (Math.abs(v) < 100 ? 2 : 0))} ${c || ""}`.trim());
const eurText = (v) => (v == null ? "-" : `€${num(v, Math.abs(v) < 100 ? 2 : 0)}`);
const agoText = (hours) => (hours == null ? "" : hours < 1 ? t("just now") : hours < 48 ? t("{h} h ago", { h: hours }) : t("{d} days ago", { d: Math.round(hours / 24) }));
const place = (r) => [r.city, r.country].filter(Boolean).join(", ") || "-";
const day = (iso) => (iso ? new Date(`${String(iso).slice(0, 10)}T12:00:00Z`).toLocaleDateString("tr-TR", { day: "numeric", month: "short", timeZone: "UTC" }) : "");
const parse = (s) => Number(String(s == null ? "" : s).replace(/\s/g, "").replace(/\.(?=\d{3}(\D|$))/g, "").replace(",", ".")) || 0;
const changed = () => window.dispatchEvent(new Event("xs:changed"));
const openCompare = (id) => window.dispatchEvent(new CustomEvent("xs:compare", { detail: { id } }));
const openAsk = (sap) => window.dispatchEvent(new CustomEvent("xs:ask", { detail: { sap } }));

// a button that asks once before it acts: the question takes its place, with yes and no
function ConfirmButton({ label, question, yes, onYes, className = "tc-btn tc-btn--secondary tc-btn--sm", icon, disabled }) {
  const [ask, setAsk] = useState(false);
  const [busy, setBusy] = useState(false);
  if (!ask) return h("button", { type: "button", className, disabled, onClick: () => setAsk(true) }, icon ? h(Icon, { n: icon, size: 16 }) : null, label);
  return h("span", { className: "xs-confirm", role: "alertdialog", "aria-label": question },
    h("span", null, question),
    h("button", { type: "button", className: "tc-btn tc-btn--sm", disabled: busy, autoFocus: true, onClick: async () => { setBusy(true); try { await onYes(); } finally { setBusy(false); setAsk(false); } } }, busy ? "..." : yes || t("Yes")),
    h("button", { type: "button", className: "tc-btn tc-btn--ghost tc-btn--sm", disabled: busy, onClick: () => setAsk(false) }, t("Cancel")),
  );
}
const run = async (fn, okText) => {
  try { const r = await fn(); if (r && r.ok === false) { toast(r.error || t("Something went wrong"), "bad"); return null; } if (okText) toast(okText, "good"); changed(); return r || true; } catch (e) { toast(errText(e, t("Something went wrong")), "bad"); return null; }
};

// type the price of a reply the system could not read
function PriceEntry({ quoteId, onDone, compact }) {
  const [f, setF] = useState({ price: "", extra: "", currency: "EUR" });
  const [busy, setBusy] = useState(false);
  const save = async (e) => {
    e.preventDefault();
    if (!(parse(f.price) > 0)) return;
    setBusy(true);
    const ok = await run(() => api.post(`/shipping/quotes/${quoteId}/price`, { price: parse(f.price), extra: parse(f.extra), currency: f.currency }), t("Price saved"));
    setBusy(false);
    if (ok && onDone) onDone();
  };
  return h("form", { className: cx("xs-price", compact && "xs-price--compact"), onSubmit: save },
    h("label", null, h("span", null, t("Freight")), h("input", { inputMode: "decimal", value: f.price, placeholder: "0", onChange: (e) => setF({ ...f, price: e.target.value }) })),
    h("label", null, h("span", null, t("Extras")), h("input", { inputMode: "decimal", value: f.extra, placeholder: "0", onChange: (e) => setF({ ...f, extra: e.target.value }) })),
    h("label", null, h("span", null, " "), h("select", { value: f.currency, "aria-label": "Para birimi", onChange: (e) => setF({ ...f, currency: e.target.value }) }, ["EUR", "USD", "TRY"].map((c) => h("option", { key: c }, c)))),
    h("button", { type: "submit", className: "tc-btn tc-btn--sm", disabled: busy || !(parse(f.price) > 0) }, busy ? t("Saving ...") : t("Save the price")),
  );
}

function Warnings({ cfg }) {
  if (!cfg) return null;
  if (!cfg.mailboxReady) return h("p", { className: "xs-warn xs-warn--bad", role: "alert" }, h(Icon, { n: "warning", size: 20 }), h("span", null, h("b", null, t("The shipping mailbox is not set up: requests and approvals cannot be e-mailed.")), " ", t("An admin types the password on the Ayarlar tab.")));
  if (cfg.testMode) return h("p", { className: "xs-warn", role: "status" }, h(Icon, { n: "info", size: 20 }), h("span", null, t("Test mode is on: e-mails go only to {a}, not to the firms.", { a: cfg.testEmail || "?" })));
  return null;
}

// ================= the desk (the first tab) =================
function Section({ id, n, icon, title, hint, children, more }) {
  return h("section", { className: "xs-sec", id: "xs-" + id, "aria-labelledby": "xs-h-" + id },
    h("header", null, h("span", { className: "xs-sec-n" }, n), h("div", null, h("h2", { id: "xs-h-" + id }, h(Icon, { n: icon, size: 20 }), title), hint ? h("p", null, hint) : null), more || null),
    children,
  );
}

function DecideCard({ r }) {
  const b = r.best;
  return h("article", { className: cx("xs-card", r.allAnswered && "xs-card--go") },
    h("div", { className: "xs-card-main" },
      h("div", { className: "xs-card-top" }, h("b", { className: "xs-id" }, r.id), r.allAnswered ? h(Chip, { tone: "good", icon: "check-circle" }, t("all firms answered")) : h(Chip, null, t("{a} of {b} answered", { a: r.answered, b: r.asked })), h("span", { className: "xs-ago" }, agoText(r.hours))),
      h("h3", null, place(r)),
      h("p", { className: "xs-sub" }, [r.mode, r.pallets ? `${r.pallets} ${t("pallets")}` : "", r.kg ? `${num(r.kg)} kg` : "", r.customer].filter(Boolean).join(" · ")),
      h("div", { className: "xs-flags" },
        r.manual ? h(Chip, { tone: "warn", icon: "edit" }, t("{n} to be typed by hand", { n: r.manual })) : null,
        r.notAllIn ? h(Chip, { tone: "warn" }, t("{n} not all-in", { n: r.notAllIn })) : null,
        r.countered ? h(Chip, null, t("counter offer waiting")) : null,
        !r.allAnswered && r.silent.length ? h("span", { className: "xs-silent" }, r.silent.map((s) => s.name).join(", "), " · ", t("{h} h without an answer", { h: Math.max(...r.silent.map((s) => s.hours || 0)) })) : null,
      ),
    ),
    h("div", { className: "xs-card-price" },
      b ? h(Fragment, null,
        h("span", null, t("best"), " · ", b.firm),
        h("b", null, money(b.total, b.currency)),
        b.currency !== "EUR" && b.eur != null ? h("small", null, "≈ " + eurText(b.eur)) : null,
        r.second ? h("small", null, t("next"), " ", money(r.second.total, r.second.currency), r.savingEur != null ? ` (+${eurText(r.savingEur)})` : "") : h("small", null, t("the only price")),
      ) : h("span", { className: "xs-none" }, t("no price that can be compared yet")),
      h("button", { type: "button", className: "tc-btn tc-btn--md", onClick: () => openCompare(r.id) }, h(Icon, { n: "fact-check", size: 20 }), t("Compare and approve")),
    ),
  );
}

function WaitCard({ r, cfg }) {
  const wait = Math.max(0, cfg.remindHours - r.hours);
  return h("article", { className: "xs-row" },
    h("div", { className: "xs-row-main" },
      h("b", { className: "xs-id" }, r.id), h("span", { className: "xs-row-title" }, place(r)),
      h("small", null, [r.mode, r.customer, t("sent to {n} firms", { n: r.asked }), agoText(r.hours)].filter(Boolean).join(" · ")),
    ),
    h("div", { className: "xs-row-acts" },
      r.canRemind > 0
        ? h(ConfirmButton, { label: t("Remind {n} firms", { n: r.canRemind }), icon: "notifications-active", question: t("Send the reminder to {n} silent firms?", { n: r.canRemind }), onYes: () => run(async () => { const x = await api.post(`/shipping/requests/${encodeURIComponent(r.id)}/remind`); toast(t("Reminder sent to {n} firms", { n: x.sent }), "good"); return x; }) })
        : h("span", { className: "xs-muted" }, r.silent.length && r.silent.every((s) => s.reminded) ? t("reminded") : wait > 0 ? t("a reminder can go after {h} h", { h: wait }) : ""),
      h("button", { type: "button", className: "tc-btn tc-btn--secondary tc-btn--sm", onClick: () => openCompare(r.id) }, t("Open")),
    ),
  );
}

function AskCard({ a }) {
  return h("article", { className: cx("xs-row", a.kind === "ask" && "xs-row--hot") },
    h("div", { className: "xs-row-main" },
      h("span", { className: "xs-row-title" }, a.kind === "ask" ? h(Chip, { tone: "bad", icon: "campaign" }, t("Sales asked")) : null, a.cardId ? h(Link, { to: `/cards/${a.cardId}/review` }, a.customer) : a.customer),
      h("small", null, [place(a), a.lots ? t("{n} lots", { n: a.lots }) : "", a.kg ? `${num(a.kg)} kg` : "", a.value ? money(a.value, a.currency) : "", a.days != null && a.lots ? t("oldest {d} days", { d: a.days }) : ""].filter(Boolean).join(" · ")),
      a.note ? h("em", null, "“" + a.note + "”", a.from ? " — " + a.from : "") : a.kind === "ask" && a.from ? h("small", null, a.from, a.askedHours != null ? " · " + agoText(a.askedHours) : "") : null,
      a.last ? h("small", { className: "xs-last" }, h(Icon, { n: "history", size: 16 }), t("Last time"), ": ", h("b", null, a.last.firm), " ", money(a.last.total, a.last.currency), a.last.pallets ? ` · ${a.last.pallets} ${t("pallets")}` : "", " · ", day(a.last.date), a.last.same === "country" ? ` (${t("same country")})` : "") : null,
    ),
    h("div", { className: "xs-row-acts" },
      a.kind === "ask" ? h(ConfirmButton, { label: t("Not needed"), className: "tc-btn tc-btn--ghost tc-btn--sm", question: t("Remove this ask of Sales?"), onYes: () => run(() => api.post(`/shipping/asks/${a.askId}/dismiss`)) }) : null,
      a.openRequest
        ? h("button", { type: "button", className: "tc-btn tc-btn--secondary tc-btn--sm", onClick: () => openCompare(a.openRequest) }, t("Request"), " ", a.openRequest)
        : h("button", { type: "button", className: "tc-btn tc-btn--sm", onClick: () => openAsk(a.sap) }, h(Icon, { n: "send", size: 16 }), t("Ask for quotes")),
    ),
  );
}

function MailCard({ m }) {
  const [typing, setTyping] = useState(false);
  const label = m.what === "held" ? t("Unknown sender") : m.what === "review" ? t("Price could not be read") : m.what === "failed_out" ? t("E-mail did not go out") : t("Reply could not be read");
  return h("article", { className: "xs-row xs-row--mail" },
    h("div", { className: "xs-row-main" },
      h("span", { className: "xs-row-title" }, h(Chip, { tone: m.what === "failed_out" ? "bad" : "warn", icon: m.what === "failed_out" ? "error" : "mail" }, label), m.firm || m.address),
      h("small", null, [m.requestId ? `#${m.requestId}` : "", m.firm ? m.address : "", m.what === "failed_out" ? m.error : ""].filter(Boolean).join(" · ")),
      m.what !== "failed_out" && m.snippet ? h("p", { className: "xs-snip" }, m.snippet) : null,
      typing && m.quoteId ? h(PriceEntry, { quoteId: m.quoteId, compact: true, onDone: () => setTyping(false) }) : null,
    ),
    h("div", { className: "xs-row-acts" },
      m.what === "held" ? h(Fragment, null,
        h("button", { type: "button", className: "tc-btn tc-btn--sm", onClick: () => run(() => api.post(`/shipping/messages/${m.id}/approve`), t("Taken as a quote")) }, t("Take it as a quote")),
        h(ConfirmButton, { label: t("Ignore"), className: "tc-btn tc-btn--ghost tc-btn--sm", question: t("Ignore") + "?", onYes: () => run(() => api.post(`/shipping/messages/${m.id}/dismiss`)) }),
      ) : null,
      m.what === "review" && m.quoteId && !typing ? h("button", { type: "button", className: "tc-btn tc-btn--sm", onClick: () => setTyping(true) }, h(Icon, { n: "edit", size: 16 }), t("Type the price")) : null,
      m.what === "failed_out" ? h("button", { type: "button", className: "tc-btn tc-btn--sm", onClick: () => run(async () => { const r = await api.post(`/shipping/messages/${m.id}/resend`); return r && r.ok === false ? { ok: false, error: `${t("Could not be sent")}: ${r.error || ""}` } : r; }, t("Sent again")) }, h(Icon, { n: "refresh", size: 16 }), t("Send again")) : null,
      m.requestId ? h("button", { type: "button", className: "tc-btn tc-btn--secondary tc-btn--sm", onClick: () => openCompare(m.requestId) }, t("Open")) : null,
    ),
  );
}

function DocCard({ d }) {
  const mark = (status, ok) => run(() => api.post("/shipping/exports/mark", { key: d.key, status }), ok);
  return h("article", { className: cx("xs-row", d.late && "xs-row--hot") },
    h("div", { className: "xs-row-main" },
      h("span", { className: "xs-row-title" }, d.late ? h(Chip, { tone: "bad", icon: "alarm" }, t("late")) : null, d.cardId ? h(Link, { to: `/cards/${d.cardId}/review` }, d.customer) : d.customer),
      h("small", null, [`${t("invoice")} ${d.invoice}`, day(d.date), t("{d} days ago", { d: d.days }), money(d.amount, d.currency, 2), d.country].filter(Boolean).join(" · ")),
      d.docs.state === "working" ? h("small", { className: "xs-last" }, h(Icon, { n: "person-check", size: 16 }), t("with you ({a})", { a: d.docs.by || "?" })) : null,
    ),
    h("div", { className: "xs-row-acts" },
      d.docs.state !== "working" ? h("button", { type: "button", className: "tc-btn tc-btn--secondary tc-btn--sm", onClick: () => mark("working", t("A reminder was added to your to-dos")) }, t("I send them")) : null,
      h(ConfirmButton, { label: t("Sent"), icon: "check", className: "tc-btn tc-btn--sm", question: t("Mark the documents of {a} as sent?", { a: d.invoice }), onYes: () => mark("sent", t("Marked as sent")) }),
    ),
  );
}

export function FreightDesk({ go }) {
  const [d, setD] = useState(null);
  const [err, setErr] = useState(null);
  const load = useCallback(() => { api.get("/shipping/desk").then((x) => { setD(x); setErr(null); }).catch((e) => setErr(errText(e, t("Could not load")))); }, []);
  useEffect(() => {
    load();
    const again = () => load();
    window.addEventListener("xs:changed", again);
    const tick = window.setInterval(() => { if (!document.hidden) load(); }, 60000);
    return () => { window.removeEventListener("xs:changed", again); window.clearInterval(tick); };
  }, [load]);
  if (err && !d) return h("p", { className: "tx-err", role: "alert" }, err);
  if (!d) return h(Skel, { height: 360 });
  const c = d.counts;
  const steps = [["ask", "send", t("Ask for quotes"), c.ask], ["wait", "hourglass-empty", t("Wait for answers"), c.waiting], ["decide", "fact-check", t("Decide"), c.decide], ["mails", "mail", t("E-mails to look at"), c.mails], ["docs", "description", t("Send documents"), c.docs]];
  const total = c.ask + c.waiting + c.decide + c.mails + c.docs;
  const jump = (id) => { const el = document.getElementById("xs-" + id); if (el) el.scrollIntoView({ behavior: "smooth", block: "start" }); };
  return h("div", { className: "xs-desk", "data-no-tr": "" },
    h("section", { className: "xs-hero" },
      h("div", { className: "xs-hero-head" },
        h("div", null, h("h2", null, t("Today's work")), h("p", null, total ? t("What needs you now, in the order it is done.") : t("Nothing is waiting. Well done."))),
        h("button", { type: "button", className: "tc-btn tc-btn--md xf-btn-onink", onClick: () => go("new") }, h(Icon, { n: "add", size: 20 }), "Yeni talep"),
      ),
      h("ol", { className: "xs-steps" }, steps.map(([id, icon, label, n], i) =>
        h("li", { key: id }, h("button", { type: "button", className: cx(n > 0 && "has", id === "decide" && n > 0 && "is-go"), onClick: () => jump(id) }, h("span", { className: "xs-step-n" }, n), h("span", { className: "xs-step-l" }, h(Icon, { n: icon, size: 16 }), label), i < steps.length - 1 ? h(Icon, { n: "chevron-right", size: 20, className: "xs-step-arrow" }) : null)))),
    ),
    d.cfg.testMode && d.cfg.mailboxReady ? h(Warnings, { cfg: d.cfg }) : null,
    d.decide.length ? h(Section, { id: "decide", n: 3, icon: "fact-check", title: t("Quotes to decide"), hint: t("Every firm has answered first, then the oldest.") }, h("div", { className: "xs-cards" }, d.decide.map((r) => h(DecideCard, { key: r.id, r })))) : null,
    h("div", { className: "xs-cols" },
      h("div", null,
        h(Section, { id: "ask", n: 1, icon: "send", title: t("To ask for quotes"), hint: t("Sales asked for these first; then the goods that are ready and have no request yet."), more: c.ask > d.ask.length ? h("button", { type: "button", className: "tc-link xs-more", onClick: () => go("ready") }, t("See all {n}", { n: c.ask })) : null },
          d.ask.length ? d.ask.map((a) => h(AskCard, { key: a.kind + a.sap, a })) : h("p", { className: "xs-empty" }, h(Icon, { n: "check-circle", size: 20 }), "Sevke hazır, talebi olmayan sipariş yok.")),
        h(Section, { id: "wait", n: 2, icon: "hourglass-empty", title: t("Waiting for answers"), hint: d.waiting.length ? t("Nobody has answered these yet.") : null },
          d.waiting.length ? d.waiting.map((r) => h(WaitCard, { key: r.id, r, cfg: d.cfg })) : h("p", { className: "xs-empty" }, h(Icon, { n: "check-circle", size: 20 }), "Yanıtsız talep yok.")),
      ),
      h("div", null,
        h(Section, { id: "mails", n: 4, icon: "mail", title: t("E-mails to look at"), more: c.mails > d.mails.length ? h("button", { type: "button", className: "tc-link xs-more", onClick: () => go("replies") }, t("See all {n}", { n: c.mails })) : null },
          d.mails.length ? d.mails.map((m) => h(MailCard, { key: m.id, m })) : h("p", { className: "xs-empty" }, h(Icon, { n: "check-circle", size: 20 }), "Bakılacak e-posta yok.")),
        h(Section, { id: "docs", n: 5, icon: "description", title: t("Documents to send"), hint: d.docs.length ? t("Invoices of the last 45 days whose documents have not gone out. Late ones first.") : null, more: c.docs > d.docs.length ? h("button", { type: "button", className: "tc-link xs-more", onClick: () => go("exports") }, t("See all {n}", { n: c.docs })) : null },
          d.docs.length ? d.docs.map((x) => h(DocCard, { key: x.key, d: x })) : h("p", { className: "xs-empty" }, h(Icon, { n: "check-circle", size: 20 }), "Gönderilecek belge yok.")),
      ),
    ),
  );
}

// ================= the sheets =================
function Sheet({ title, sub, onClose, wide, children, foot }) {
  const ref = useRef(null);
  useEffect(() => {
    const onKey = (e) => { if ((e.key || "") === "Escape") { e.stopPropagation(); onClose(); } };
    document.addEventListener("keydown", onKey, true);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    if (ref.current) ref.current.focus();
    return () => { document.removeEventListener("keydown", onKey, true); document.body.style.overflow = prev; };
  }, []);
  return h("div", { className: "xs-scrim", "data-no-tr": "", onMouseDown: (e) => { if (e.target === e.currentTarget) onClose(); } },
    h("div", { className: cx("xs-sheet", wide && "xs-sheet--wide"), role: "dialog", "aria-modal": "true", "aria-label": title, tabIndex: -1, ref },
      h("header", { className: "xs-sheet-head" }, h("div", null, h("h2", null, title), sub ? h("p", null, sub) : null), h("button", { type: "button", className: "xs-x", "aria-label": t("Close"), onClick: onClose }, h(Icon, { n: "close", size: 24 }))),
      h("div", { className: "xs-sheet-body" }, children),
      foot ? h("footer", { className: "xs-sheet-foot" }, foot) : null,
    ),
  );
}

function Reply({ text }) {
  const [all, setAll] = useState(false);
  if (!text) return null;
  const long = text.length > 220 || text.split("\n").length > 5;
  return h("div", { className: "xs-reply" }, h("span", null, t("The firm's answer")), h("p", null, all || !long ? text : text.slice(0, 220).split("\n").slice(0, 5).join("\n") + " …"), long ? h("button", { type: "button", className: "tc-link", onClick: () => setAll((a) => !a) }, all ? t("Show less") : t("Show all")) : null);
}

const STATUS = { accepted: ["good", "Approved"], rejected: ["", "Rejected"], countered: ["", "Counter offer sent"], manual: ["warn", "To be typed"] };

function QuoteCol({ q, c, isBest, open, onAccept, reload }) {
  const [counter, setCounter] = useState(null);
  const st = q.status === "open" ? (q.allIn ? null : ["warn", "Not all-in"]) : STATUS[q.status];
  const act = (fn, ok) => run(fn, ok).then((r) => { if (r) reload(); return r; });
  return h("article", { className: cx("xs-q", isBest && "xs-q--best", q.status === "accepted" && "xs-q--won", (q.status === "rejected") && "xs-q--off") },
    h("header", null,
      h("div", { className: "xs-q-tags" }, isBest ? h("span", { className: "xs-q-best" }, h(Icon, { n: "trophy", size: 16 }), t("Best")) : q.rank ? h("span", { className: "xs-q-rank" }, q.rank + ".") : null, st ? h(Chip, { tone: st[0] || undefined }, t(st[1])) : null),
      h("h3", null, q.firm),
      q.history ? h("small", null, t("answered {a} of {b} requests, won {c}", { a: q.history.answered, b: q.history.asked, c: q.history.won })) : null,
    ),
    h("div", { className: "xs-q-price" },
      q.status === "manual" ? h("b", { className: "xs-q-none" }, "?") : h("b", null, money(q.total != null ? q.total : q.base, q.currency)),
      q.allIn && q.currency !== "EUR" ? (q.eur != null ? h("span", null, "≈ " + eurText(q.eur)) : h("span", { className: "xs-bad" }, t("no rate for {c}: not compared", { c: q.currency || "?" }))) : null,
      q.extra ? h("small", null, t("freight {a} + extras {b}", { a: money(q.base, q.currency), b: money(q.extra, q.currency) })) : null,
    ),
    h("dl", { className: "xs-q-facts" },
      q.perKg != null ? h("div", null, h("dt", null, t("per kg")), h("dd", null, eurText(q.perKg))) : null,
      q.perPallet != null ? h("div", null, h("dt", null, t("per pallet")), h("dd", null, eurText(q.perPallet))) : null,
    ),
    q.rank > 1 && q.diffBest != null ? h("p", { className: "xs-q-diff" }, t("{a} more than the best ({p}%)", { a: eurText(q.diffBest), p: q.diffBestPct })) : null,
    q.outItems ? h("p", { className: "xs-q-out" }, h(Icon, { n: "warning", size: 16 }), h("span", null, h("b", null, t("Left out of the price")), ": ", q.outItems)) : null,
    q.status === "countered" && q.counter ? h("p", { className: "xs-q-diff" }, t("Their counter offer: {a}", { a: money(q.counter, q.currency) })) : null,
    q.mailFailed ? h("p", { className: "xs-q-out" }, h(Icon, { n: "error", size: 16 }), h("span", null, h("b", null, t("The last e-mail to this firm did not go out")), q.mailFailed.error ? ": " + q.mailFailed.error : "", " ", h("button", { type: "button", className: "tc-link", onClick: () => act(async () => { const r = await api.post(`/shipping/messages/${q.mailFailed.id}/resend`); return r && r.ok === false ? { ok: false, error: `${t("Could not be sent")}: ${r.error || ""}` } : r; }, t("Sent again")) }, t("Send again")))) : null,
    h(Reply, { text: q.reply && q.reply.text }),
    open ? h("div", { className: "xs-q-acts" },
      q.status === "manual" ? h(PriceEntry, { quoteId: q.id, onDone: reload }) : null,
      q.status === "open" && q.allIn ? h("button", { type: "button", className: cx("tc-btn tc-btn--md", !isBest && "tc-btn--secondary"), onClick: () => onAccept(q) }, h(Icon, { n: "check", size: 20 }), t("Approve")) : null,
      q.status === "open" && !q.allIn ? h("button", { type: "button", className: "tc-btn tc-btn--md", onClick: () => act(() => api.post(`/shipping/quotes/${q.id}/ask-all-in`), t("Asked for the all-in price")) }, t("Ask for the all-in price")) : null,
      q.status === "open" && !q.allIn ? h(PriceEntry, { quoteId: q.id, onDone: reload }) : null,
      q.status === "open" && q.allIn ? (counter === null
        ? h("button", { type: "button", className: "tc-btn tc-btn--ghost tc-btn--sm", onClick: () => setCounter("") }, t("Counter offer"))
        : h("form", { className: "xs-counter", onSubmit: (e) => { e.preventDefault(); if (parse(counter) > 0) act(() => api.post(`/shipping/quotes/${q.id}/counter`, { price: parse(counter) }), t("Counter offer sent")).then((r) => r && setCounter(null)); } },
            h("label", null, h("span", null, t("Your price"), " (", q.currency, ")"), h("input", { inputMode: "decimal", autoFocus: true, value: counter, onChange: (e) => setCounter(e.target.value) })),
            h("button", { type: "submit", className: "tc-btn tc-btn--sm", disabled: !(parse(counter) > 0) }, t("Send the counter offer")),
            h("button", { type: "button", className: "tc-btn tc-btn--ghost tc-btn--sm", onClick: () => setCounter(null) }, t("Cancel")),
          )) : null,
      ["open", "manual", "countered"].includes(q.status) ? h(ConfirmButton, { label: t("Reject"), className: "tc-btn tc-btn--ghost tc-btn--sm", question: t("Reject the quote of {a}? They get an e-mail.", { a: q.firm }), onYes: () => act(() => api.post(`/shipping/quotes/${q.id}/reject`)) }) : null,
    ) : null,
  );
}

function CompareSheet({ id, onClose, go }) {
  const [c, setC] = useState(null);
  const [err, setErr] = useState(null);
  const [accept, setAccept] = useState(null);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(null);
  const [pick, setPick] = useState(new Set());
  const reload = useCallback(() => api.get(`/shipping/requests/${encodeURIComponent(id)}/compare`).then((x) => { setC(x); setErr(null); }).catch((e) => setErr(errText(e, t("Could not load")))), [id]);
  useEffect(() => { reload(); }, [reload]);
  if (err && !c) return h(Sheet, { title: `${t("Request")} #${id}`, onClose }, h("p", { className: "tx-err", role: "alert" }, err));
  if (!c) return h(Sheet, { title: `${t("Request")} #${id}`, onClose, wide: true }, h(Skel, { height: 320 }));
  const r = c.request;
  const open = r.status === "open";
  const best = c.quotes.find((q) => q.id === c.best) || null;
  const second = c.quotes.find((q) => q.rank === 2) || null;
  const rate = c.cfg.rates;
  const usesUsd = c.quotes.some((q) => q.currency === "USD");
  const usesTry = c.quotes.some((q) => q.currency === "TRY");
  async function doAccept() {
    setBusy(true);
    const q = accept;
    const res = await run(() => api.post(`/shipping/quotes/${q.id}/accept`));
    setBusy(false);
    if (res) { setAccept(null); setDone(q); reload(); }
  }
  const others = accept ? c.quotes.filter((q) => q.id !== accept.id && ["open", "countered", "manual"].includes(q.status)) : [];
  const sub = h(Fragment, null, [r.mode, r.pallets ? `${r.pallets} ${t("pallets")}` : "", r.kg ? `${num(r.kg)} kg` : "", r.customer, t("sent {t}", { t: agoText(r.hours) })].filter(Boolean).join(" · "));
  return h(Sheet, {
    title: `#${r.id} · ${place(r)}`, sub, onClose, wide: true,
    foot: h(Fragment, null,
      h("button", { type: "button", className: "tc-btn tc-btn--secondary tc-btn--md", onClick: () => { onClose(); go("requests", { r: r.id }); } }, h(Icon, { n: "forum", size: 20 }), t("All details and e-mails")),
      open ? h(ConfirmButton, { label: t("Close without choosing"), className: "tc-btn tc-btn--ghost tc-btn--md", question: t("Close this request without choosing anybody? Every firm is told."), onYes: async () => { const x = await run(() => api.post(`/shipping/requests/${encodeURIComponent(r.id)}/close`)); if (x) reload(); } }) : null,
      h("span", { className: "xs-foot-gap" }),
      open && best ? h("button", { type: "button", className: "tc-btn tc-btn--md", onClick: () => setAccept(best) }, h(Icon, { n: "trophy", size: 20 }), t("Approve the best"), ": ", best.firm, " · ", money(best.total, best.currency)) : null,
    ),
  },
    h(Warnings, { cfg: c.cfg }),
    done ? h("p", { className: "xs-done", role: "status" }, h(Icon, { n: "check-circle", size: 24 }), t("Approved: {a}, {b}", { a: done.firm, b: money(done.total, done.currency) })) : !open ? h("p", { className: "xs-warn" }, h(Icon, { n: "lock", size: 20 }), t("This request is closed.")) : null,
    h("div", { className: "xs-sum" },
      h("div", { className: "xs-sum-ring" }, h(Ring, { value: c.asked - c.silent.length, max: c.asked, size: 64, stroke: 6, tone: c.silent.length ? "" : "good" }, `${c.asked - c.silent.length}/${c.asked}`), h("span", null, c.silent.length ? t("{a} of {b} answered", { a: c.asked - c.silent.length, b: c.asked }) : t("all firms answered"))),
      h("div", null, h("span", null, t("Best price")), h("b", null, best ? money(best.total, best.currency) : "-"), best ? h("small", null, best.firm, best.perKg != null ? ` · ${eurText(best.perKg)} / kg` : "") : null),
      h("div", null, h("span", null, t("Next one")), h("b", null, second ? money(second.total, second.currency) : "-"), second ? h("small", null, t("{a} more", { a: eurText(second.diffBest) }), ` · ${second.firm}`) : best ? h("small", null, t("the only price")) : null),
      h("div", null, h("span", null, t("Average")), h("b", null, c.avgEur != null ? eurText(c.avgEur) : "-"), best && c.avgEur != null && best.eur != null && c.quotes.filter((q) => q.rank).length > 1 ? h("small", null, `${t("best")}: -${Math.round(((c.avgEur - best.eur) / c.avgEur) * 100)}%`) : null),
      h("div", null, h("span", null, t("Last shipment")), h("b", null, c.last ? money(c.last.total, c.last.currency) : "-"), c.last ? h("small", null, c.last.firm, " · ", day(c.last.date), " · ", c.last.same === "customer" ? t("for this customer") : t("to this country")) : null),
    ),
    usesUsd || usesTry ? h("p", { className: "xs-rate" }, h(Icon, { n: "currency-exchange", size: 16 }), usesUsd ? t("Compared in euro: 1 € = {a} $ (the rate of Performance). The amount the firm wrote is never changed.", { a: num(rate.usdPerEur, 2) }) : "", usesTry && rate.tryPerEur ? " " + t("1 € = {a} ₺ ({m})", { a: num(rate.tryPerEur, 2), m: rate.tryMonth }) : "") : null,
    c.quotes.length ? h("div", { className: "xs-qs", style: { "--n": Math.min(c.quotes.length, 4) } }, c.quotes.map((q) => h(QuoteCol, { key: q.id, q, c, isBest: open && q.id === c.best, open, onAccept: setAccept, reload }))) : h("p", { className: "xs-empty" }, h(Icon, { n: "hourglass-empty", size: 20 }), t("No quote yet.")),
    open ? h("div", { className: "xs-two" },
      h("section", { className: "xs-box" },
        h("h3", null, t("Silent firms"), c.silent.length ? h("span", null, c.silent.length) : null),
        c.silent.length ? h(Fragment, null,
          h("ul", { className: "xs-silents" }, c.silent.map((s) => h("li", { key: s.forwarderId }, h("b", null, s.name), h("small", null, t("{h} h without an answer", { h: s.hours ?? "?" }), s.remindedAt ? " · " + t("reminded") : "", s.mailFailed ? " · " + t("E-mail did not go out") : ""), s.mailFailed ? h("button", { type: "button", className: "tc-link", onClick: () => run(async () => { const x = await api.post(`/shipping/messages/${s.mailFailed.id}/resend`); return x && x.ok === false ? { ok: false, error: `${t("Could not be sent")}: ${x.error || ""}` } : x; }, t("Sent again")).then((x) => x && reload()) }, t("Send again")) : null))),
          c.canRemind > 0
            ? h(ConfirmButton, { label: t("Remind {n} firms", { n: c.canRemind }), icon: "notifications-active", question: t("Send the reminder to {n} silent firms?", { n: c.canRemind }), onYes: async () => { const x = await run(async () => { const y = await api.post(`/shipping/requests/${encodeURIComponent(r.id)}/remind`); toast(t("Reminder sent to {n} firms", { n: y.sent }), "good"); return y; }); if (x) reload(); } })
            : h("small", { className: "xs-muted" }, c.remindAfterHours > 0 ? t("a reminder can go after {h} h", { h: c.remindAfterHours }) : t("reminded")),
        ) : h("p", { className: "xs-muted" }, t("Nobody is silent.")),
      ),
      h("section", { className: "xs-box" },
        h("h3", null, t("Ask more firms")),
        c.more.length ? h(Fragment, null,
          h("p", { className: "xs-muted" }, t("These firms serve this destination and were not asked.")),
          h("div", { className: "xs-picks" }, c.more.map((f) => h("button", { key: f.id, type: "button", "aria-pressed": pick.has(f.id), title: f.why, onClick: () => setPick((p) => { const n = new Set(p); if (n.has(f.id)) n.delete(f.id); else n.add(f.id); return n; }) }, f.name, f.asked ? h("small", null, t("answers {p}%", { p: Math.round((f.answered / f.asked) * 100) })) : h("small", null, t("new"))))),
          pick.size ? h(ConfirmButton, { label: t("Send to {n} firms", { n: pick.size }), icon: "send", className: "tc-btn tc-btn--sm", question: t("Send to {n} firms?", { n: pick.size }), yes: t("Yes, send"), onYes: async () => { const x = await run(async () => { const y = await api.post(`/shipping/requests/${encodeURIComponent(r.id)}/add-firms`, { forwarderIds: [...pick] }); if (y.failed && y.failed.length) toast(`${t("Could not go to")}: ${y.failed.map((f) => `${f.name} (${f.error})`).join("; ")}`, "bad"); if (y.added) toast(t("Sent to {n} more firms", { n: y.added }), "good"); return y; }); if (x) { setPick(new Set()); reload(); } } }) : null,
        ) : h("p", { className: "xs-muted" }, t("Every firm that serves this destination was asked.")),
      ),
    ) : null,
    accept ? h("div", { className: "xs-accept", role: "alertdialog", "aria-label": t("You are approving") },
      h("div", { className: "xs-accept-box" },
        h("span", { className: "xs-kicker" }, t("You are approving")),
        h("h3", null, accept.firm), h("b", { className: "xs-accept-price" }, money(accept.total, accept.currency), accept.currency !== "EUR" && accept.eur != null ? h("small", null, " ≈ " + eurText(accept.eur)) : null),
        accept.id !== c.best && best ? h("p", { className: "xs-q-out" }, h(Icon, { n: "warning", size: 16 }), h("span", null, t("{a} more than the best ({p}%)", { a: eurText(accept.diffBest), p: accept.diffBestPct }), " — ", t("Best"), ": ", best.firm, " ", money(best.total, best.currency))) : null,
        h("h4", null, t("What happens now")),
        h("ul", null,
          h("li", null, h(Icon, { n: "check-circle", size: 16 }), h("span", null, h("b", null, accept.firm), " ", t("gets the approval"))),
          others.length ? h("li", null, h(Icon, { n: "block", size: 16 }), h("span", null, h("b", null, others.map((o) => o.firm).join(", ")), " ", t("get the rejection"))) : null,
          c.silent.length ? h("li", null, h(Icon, { n: "mail", size: 16 }), h("span", null, h("b", null, c.silent.map((s) => s.name).join(", ")), " ", t("are told the request is closed"))) : null,
          c.cfg.managerEmail ? h("li", null, h(Icon, { n: "summarize", size: 16 }), h("span", null, h("b", null, c.cfg.managerEmail), " ", t("gets the summary"))) : null,
          h("li", null, h(Icon, { n: "lock", size: 16 }), h("span", null, t("The request is closed. This cannot be taken back."))),
        ),
        !c.cfg.mailboxReady ? h("p", { className: "xs-warn xs-warn--bad" }, h(Icon, { n: "warning", size: 20 }), h("span", null, t("The mailbox is not set up, so none of these e-mails can go out. Tell the firms yourself."))) : c.cfg.testMode ? h("p", { className: "xs-warn" }, h(Icon, { n: "info", size: 20 }), h("span", null, t("Test mode is on: e-mails go only to {a}, not to the firms.", { a: c.cfg.testEmail || "?" }))) : null,
        h("div", { className: "xs-accept-acts" },
          h("button", { type: "button", className: "tc-btn tc-btn--md", disabled: busy, autoFocus: true, onClick: doAccept }, busy ? t("Sending ...") : t("Yes, approve {a}", { a: accept.firm })),
          h("button", { type: "button", className: "tc-btn tc-btn--ghost tc-btn--md", disabled: busy, onClick: () => setAccept(null) }, t("Cancel")),
        ),
      ),
    ) : null,
  );
}

function AskSheet({ sap, onClose, go }) {
  const [p, setP] = useState(null);
  const [err, setErr] = useState(null);
  const [f, setF] = useState(null);
  const [lots, setLots] = useState(null);
  const [firms, setFirms] = useState(new Set());
  const [charges, setCharges] = useState(null);
  const [preview, setPreview] = useState(null);
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(null);
  const [msg, setMsg] = useState(null);
  const load = useCallback((mode) => api.get(`/shipping/ready/plan?sap=${encodeURIComponent(sap)}${mode ? `&mode=${encodeURIComponent(mode)}` : ""}`).then((x) => {
    setP(x);
    setErr(null);
    setFirms(new Set(x.proposals.slice(0, 6).map((w) => w.id)));
    setF((old) => (old ? { ...old, mode: x.mode } : { city: x.city || "", country: x.country || "", mode: x.mode, pallets: "", kg: x.kg ? String(x.kg) : "", ready: "Sevke hazır" }));
    setLots((old) => old || new Set(x.lots.map((l) => l.sd)));
    setCharges((old) => old || new Set(x.charges.filter((c) => c.defaultOn).map((c) => c.nameTr)));
  }).catch((e) => setErr(errText(e, t("Could not load")))), [sap]);
  useEffect(() => { load(); }, [load]);
  const chosen = useMemo(() => (p && lots ? p.lots.filter((l) => lots.has(l.sd)) : []), [p, lots]);
  const text = useMemo(() => {
    if (!p || !f) return "";
    const dest = [f.city, f.country].filter(Boolean).join(", ") || "-";
    const kg = parse(f.kg);
    return chosen.length ? `${p.customer} için sevke hazır sipariş (${chosen.map((l) => l.sd).join(", ")}). Varış: ${dest}. ${parse(f.pallets) ? `${parse(f.pallets)} palet, ` : ""}Toplam ${kg ? `${num(kg)} kg` : "ağırlık belirtilmemiş"}. ${f.mode}.` : `${p.customer} için nakliye teklifi. Varış: ${dest}. ${parse(f.pallets) ? `${parse(f.pallets)} palet. ` : ""}${kg ? `${num(kg)} kg. ` : ""}${f.mode}.`;
  }, [p, f, chosen]);
  const body = () => ({ text, cargo: "", charges: [...(charges || [])], country: f.country, countryIso: f.country === p.country ? p.iso : null, city: f.city, mode: f.mode, pallets: parse(f.pallets) || null, weightKg: parse(f.kg) || null, size: "", ready: f.ready, pickup: "Bursa, Türkiye", cardId: p.cardId, askId: p.askId, forwarderIds: [...firms] });
  const toggleLot = (sd) => setLots((old) => { const n = new Set(old); if (n.has(sd)) n.delete(sd); else n.add(sd); const kg = p.lots.filter((l) => n.has(l.sd)).reduce((a, l) => a + l.kg, 0); setF((x) => ({ ...x, kg: kg ? String(kg) : "" })); return n; });
  async function showPreview() {
    if (preview) { setPreview(null); return; }
    const first = p.proposals.find((w) => firms.has(w.id));
    if (!first) { setMsg(t("Choose at least one firm.")); return; }
    try { setPreview(await api.post("/shipping/preview", { ...body(), forwarderId: first.id })); } catch (e) { setMsg(errText(e, t("Could not load"))); }
  }
  function ask() {
    setMsg(null);
    if (!f.country.trim()) return setMsg(t("The destination country is needed."));
    if (!firms.size) return setMsg(t("Choose at least one firm."));
    if (p.lots.length && !chosen.length) return setMsg(t("Choose at least one order."));
    setConfirm(true);
  }
  async function send() {
    setBusy(true);
    try {
      const res = await api.post("/shipping/requests", body());
      setDone(res);
      changed();
    } catch (e) {
      setMsg(errText(e, t("Something went wrong")));
    } finally {
      setBusy(false);
      setConfirm(false);
    }
  }
  if (err && !p) return h(Sheet, { title: t("Ask for freight quotes"), onClose }, h("p", { className: "tx-err", role: "alert" }, err));
  if (!p || !f) return h(Sheet, { title: t("Ask for freight quotes"), onClose }, h(Skel, { height: 300 }));
  if (done) return h(Sheet, { title: t("Ask for freight quotes"), sub: p.customer, onClose, foot: h(Fragment, null, h("button", { type: "button", className: "tc-btn tc-btn--md", onClick: () => { onClose(); openCompare(done.id); } }, t("Open the request")), h("button", { type: "button", className: "tc-btn tc-btn--ghost tc-btn--md", onClick: onClose }, t("Close"))) },
    h("p", { className: cx("xs-done", !done.sent && "xs-done--bad"), role: "status" }, h(Icon, { n: done.sent ? "check-circle" : "error", size: 24 }), done.sent ? t("Request {id} is out: sent to {n} firms.", { id: done.id, n: done.sent }) : t("Request {id} was made, but it could not be sent to any firm.", { id: done.id })),
    done.failed && done.failed.length ? h("div", { className: "xs-warn xs-warn--bad" }, h(Icon, { n: "warning", size: 20 }), h("span", null, h("b", null, t("Could not go to")), ": ", done.failed.map((x) => `${x.name} (${x.error})`).join("; "))) : null,
  );
  const why = p.modeWhy === "customer" ? t("taken from this customer's last request") : p.modeWhy === "country" ? t("taken from the last request to this country") : t("chosen by which firms go there");
  return h(Sheet, {
    title: t("Ask for freight quotes"), sub: h(Fragment, null, h("b", null, p.customer), " · ", t("Check, then send. Nothing else is needed.")), onClose,
    foot: confirm
      ? h(Fragment, null, h("span", { className: "xs-foot-q" }, t("Send to {n} firms?", { n: firms.size })), h("span", { className: "xs-foot-gap" }), h("button", { type: "button", className: "tc-btn tc-btn--ghost tc-btn--md", disabled: busy, onClick: () => setConfirm(false) }, t("Cancel")), h("button", { type: "button", className: "tc-btn tc-btn--md", disabled: busy, autoFocus: true, onClick: send }, busy ? t("Sending ...") : t("Yes, send")))
      : h(Fragment, null, h("button", { type: "button", className: "tc-btn tc-btn--ghost tc-btn--md", onClick: showPreview }, h(Icon, { n: "visibility", size: 20 }), t("The e-mail the firms get")), msg ? h("span", { className: "tx-err", role: "alert" }, msg) : null, h("span", { className: "xs-foot-gap" }), h("button", { type: "button", className: "tc-btn tc-btn--md", disabled: !firms.size || !p.cfg.mailboxReady, title: p.cfg.mailboxReady ? undefined : t("The shipping mailbox is not set up: requests and approvals cannot be e-mailed."), onClick: ask }, h(Icon, { n: "send", size: 20 }), t("Send to {n} firms", { n: firms.size }))),
  },
    h(Warnings, { cfg: p.cfg }),
    p.askNote ? h("p", { className: "xs-note" }, h(Icon, { n: "campaign", size: 20 }), h("span", null, h("b", null, t("Note of Sales"), p.askFrom ? ` (${p.askFrom})` : "", ": "), p.askNote)) : null,
    p.lots.length ? h("section", { className: "xs-box" },
      h("h3", null, t("Orders that go"), h("span", null, `${chosen.length}/${p.lots.length}`)),
      h("div", { className: "xs-lots" }, p.lots.map((l) => h("label", { key: l.sd, className: cx(lots.has(l.sd) && "is-on") }, h("input", { type: "checkbox", checked: lots.has(l.sd), onChange: () => toggleLot(l.sd) }), h("b", null, l.sd), h("span", null, day(l.date)), h("span", null, num(l.kg), " kg"), h("span", null, money(l.value, l.currency))))),
    ) : null,
    h("section", { className: "xs-box" },
      h("h3", null, t("Destination")),
      h("div", { className: "xs-fields" },
        h("label", null, h("span", null, t("City")), h("input", { value: f.city, onChange: (e) => setF({ ...f, city: e.target.value }) })),
        h("label", null, h("span", null, t("Country")), h("input", { value: f.country, onChange: (e) => setF({ ...f, country: e.target.value }) })),
        h("label", null, h("span", null, t("How")), h("select", { value: f.mode, onChange: (e) => { setF({ ...f, mode: e.target.value }); setPreview(null); load(e.target.value); } }, p.modes.map((m) => h("option", { key: m }, m)))),
        h("label", null, h("span", null, t("Pallets"), " (", t("optional"), ")"), h("input", { inputMode: "numeric", value: f.pallets, onChange: (e) => setF({ ...f, pallets: e.target.value }) })),
        h("label", null, h("span", null, t("Weight, kg")), h("input", { inputMode: "decimal", value: f.kg, onChange: (e) => setF({ ...f, kg: e.target.value }) })),
        h("label", null, h("span", null, t("Ready")), h("input", { value: f.ready, onChange: (e) => setF({ ...f, ready: e.target.value }) })),
      ),
      h("small", { className: "xs-muted" }, f.mode, ": ", why, p.last ? ` · ${t("Last shipment")}: ${p.last.firm} ${money(p.last.total, p.last.currency)} (${day(p.last.date)})` : ""),
    ),
    h("section", { className: "xs-box" },
      h("h3", null, t("Firms"), h("span", null, t("{a} of {b} chosen", { a: firms.size, b: p.proposals.length })), p.proposals.length ? h("span", { className: "xs-allnone" }, h("button", { type: "button", className: "tc-link", onClick: () => setFirms(new Set(p.proposals.map((w) => w.id))) }, t("All")), h("button", { type: "button", className: "tc-link", onClick: () => setFirms(new Set()) }, t("None"))) : null),
      p.proposals.length ? h("div", { className: "xs-firms" }, p.proposals.map((w) => h("label", { key: w.id, className: cx(firms.has(w.id) && "is-on") },
        h("input", { type: "checkbox", checked: firms.has(w.id), onChange: () => { setPreview(null); setFirms((old) => { const n = new Set(old); if (n.has(w.id)) n.delete(w.id); else n.add(w.id); return n; }); } }),
        h("span", null, h("b", null, w.name), h("small", null, [w.why, w.asked ? t("answers {p}%", { p: Math.round((w.answered / w.asked) * 100) }) : t("new"), w.lastPrice ? `${t("last")} ${w.lastPrice}` : ""].filter(Boolean).join(" · "))),
      ))) : h("p", { className: "xs-warn" }, h(Icon, { n: "warning", size: 20 }), h("span", null, t("No firm serves this destination with this way of transport. Change the way, or add a firm on the Taşıma firmaları tab."))),
    ),
    h("section", { className: "xs-box" },
      h("h3", null, t("In the price (all-in)")),
      h("div", { className: "xs-picks" }, p.charges.map((c) => h("button", { key: c.id, type: "button", "aria-pressed": charges.has(c.nameTr), onClick: () => { setPreview(null); setCharges((old) => { const n = new Set(old); if (n.has(c.nameTr)) n.delete(c.nameTr); else n.add(c.nameTr); return n; }); } }, c.nameTr))),
    ),
    preview ? h("section", { className: "xs-box xs-preview" }, h("h3", null, t("The e-mail the firms get")), h("small", { className: "xs-muted" }, preview.to.join(", "), " · ", preview.subject), h("pre", null, preview.body)) : null,
  );
}

// mounted once on the Nakliye page: opens the two sheets when asked (from the desk, the "Sevke hazır" tab and the request drawer)
export function FreightSheets({ go, onChanged }) {
  const [sheet, setSheet] = useState(null);
  useEffect(() => {
    const cmp = (e) => setSheet({ kind: "compare", id: e.detail.id });
    const ask = (e) => setSheet({ kind: "ask", sap: e.detail.sap });
    const ch = () => { if (onChanged) onChanged(); };
    window.addEventListener("xs:compare", cmp);
    window.addEventListener("xs:ask", ask);
    window.addEventListener("xs:changed", ch);
    return () => { window.removeEventListener("xs:compare", cmp); window.removeEventListener("xs:ask", ask); window.removeEventListener("xs:changed", ch); };
  }, [onChanged]);
  if (!sheet) return null;
  const close = () => setSheet(null);
  return sheet.kind === "compare" ? h(CompareSheet, { key: sheet.id, id: sheet.id, onClose: close, go }) : h(AskSheet, { key: sheet.sap, sap: sheet.sap, onClose: close, go });
}

// in the drawer of a request: the way to the comparison
export function CompareBar({ id, n }) {
  return h("div", { className: "xs-bar", "data-no-tr": "" }, h("button", { type: "button", className: "tc-btn tc-btn--md", onClick: () => openCompare(id) }, h(Icon, { n: "fact-check", size: 20 }), t("Compare the quotes"), n ? ` (${n})` : ""));
}
