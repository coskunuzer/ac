// View only ("peek"): the customers of my own countries that another person looks after. A salesperson exploring a country sees that a company is
// already somebody's customer (and how much it buys), so it is not recorded again under a slightly different name. Nothing here changes a
// customer: the server gives a limited summary (GET /api/peek/:id) with no e-mails, phones or notes.
//  - PeekGroup: the "In your countries - looked after by others" part of the global search
//  - PeekHost: mounted once next to the search; opens the panel when a peek is asked for (window event "x-peek")
//  - PeekPanel: the read-only panel with the warning
//  - PeekCountry: the same list in the Country explorer (Customers tab)
//  - PeekWarn: the warning on Add a customer while the company / e-mail / phone is typed
import { h, Fragment, useState, useEffect, useRef, api, useT, Icon, cx, errText, eur, Link } from "./x-kit-1W3jRMzJ.js";

const openPeek = (id) => window.dispatchEvent(new CustomEvent("x-peek", { detail: { id } }));

const ownerLine = (t, r) => (r.owner ? t("Looked after by {name}", { name: r.owner }) : t("Nobody looks after it yet"));

function Row({ r, t, onLook, as = "li" }) {
  return h(as, { className: "xp-row", "data-existing": r.existing || undefined },
    h("span", { className: "xp-row-ic", "aria-hidden": "true" }, h(Icon, { n: "visibility", size: 20 })),
    h("div", { className: "xp-row-who" },
      h("button", { type: "button", className: "xp-row-name", onClick: () => onLook(r.id) }, r.company || "#" + r.id),
      h("span", { className: "xp-row-tags" },
        h("span", { className: "xp-tag xp-tag--view" }, t("View only")),
        r.existing ? h("span", { className: "xp-tag xp-tag--buy" }, t("Existing customer")) : null),
      h("small", null, [r.city, r.country].filter(Boolean).join(", "), " · ", h("b", null, ownerLine(t, r)))),
    h("button", { type: "button", className: "tc-btn tc-btn--secondary tc-btn--sm xp-row-look", onClick: () => onLook(r.id) }, t("Look")));
}

// ---- the group in the global search (inside its list)
export function PeekGroup({ rows, onPick }) {
  const t = useT();
  if (!rows || !rows.length) return null;
  // the search closes (it listens to Esc), then the panel opens
  const look = (id) => { onPick && onPick(); document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true })); openPeek(id); };
  return h(Fragment, null,
    h("li", { className: "qs-group xp-group", "aria-hidden": "true" }, t("In your countries — looked after by others (view only)")),
    rows.map((r) => h(Row, { key: "p" + r.id, r, t, onLook: look })));
}

// ---- mounted once (next to the global search): shows the panel when asked
let hosts = 0;
export function PeekHost() {
  const [id, setId] = useState(null);
  const mine = useRef(false);
  useEffect(() => {
    if (hosts > 0) return undefined; // only one host answers
    hosts += 1; mine.current = true;
    const on = (e) => { const v = e.detail && Number(e.detail.id); if (v) setId(v); };
    window.addEventListener("x-peek", on);
    return () => { hosts -= 1; mine.current = false; window.removeEventListener("x-peek", on); };
  }, []);
  return id ? h(PeekPanel, { key: id, id, onClose: () => setId(null) }) : null;
}

const STATUS = { existing: ["good", "Existing customer"], prospect: ["warn", "Prospect"], lead: ["", "Lead"], lost: ["", "Lost"] };
const fmtDay = (iso) => (iso ? new Intl.DateTimeFormat(document.documentElement.lang === "tr" ? "tr-TR" : "en-GB", { day: "numeric", month: "short", year: "numeric", timeZone: "UTC" }).format(new Date(iso.slice(0, 10) + "T12:00:00Z")) : "–");

// ---- the read-only panel
export function PeekPanel({ id, onClose }) {
  const t = useT();
  const [d, setD] = useState(null);
  const [err, setErr] = useState(null);
  const [ask, setAsk] = useState(null); // null | "" (typing) | "sent:<names>"
  const [busy, setBusy] = useState(false);
  const [askErr, setAskErr] = useState(null); // a failed "Ask": said under the form, the summary stays
  const ref = useRef(null);
  useEffect(() => {
    let alive = true;
    api.get(`/peek/${id}`).then((x) => alive && setD(x)).catch((e) => alive && setErr(errText(e, t("Could not load"))));
    return () => { alive = false; };
  }, [id]);
  useEffect(() => {
    const onKey = (e) => { if ((e.key || "") === "Escape") { e.stopPropagation(); onClose(); } };
    document.addEventListener("keydown", onKey, true);
    if (ref.current) ref.current.focus();
    return () => document.removeEventListener("keydown", onKey, true);
  }, []);
  const send = async () => {
    if (busy) return;
    setBusy(true); setAskErr(null);
    try { const r = await api.post(`/peek/${id}/ask`, { message: (ask || "").trim() }); setAsk("sent:" + r.to.join(", ")); }
    catch (e) { setAskErr(errText(e, t("Could not send it."))); }
    finally { setBusy(false); }
  };
  const name = d && d.owner;
  const st = d && STATUS[d.status];
  const o = d && d.orders;
  let body;
  if (err) body = h("p", { className: "xp-err", role: "alert" }, err);
  else if (!d) body = h("div", { className: "xp-skel" }, h("span", null), h("span", null), h("span", null));
  else if (d.open) body = h("div", { className: "xp-open" },
    h("p", null, t("You can open this customer normally.")),
    h(Link, { className: "tc-btn tc-btn--md", to: `/cards/${id}/review`, onClick: onClose }, t("Open the customer")));
  else body = h(Fragment, null,
    h("div", { className: "xp-warn", role: "note" },
      h(Icon, { n: "lock", size: 24 }),
      h("div", null,
        h("b", null, name ? t("View only. {name} looks after this customer.", { name }) : t("View only. Nobody looks after this customer yet.")),
        h("p", null, name ? t("Do not create it again — talk to {name}.", { name }) : t("Do not create it again — ask an admin to give it to you.")))),
    h("div", { className: "xp-facts" },
      h("div", { className: "xp-fact" }, h("span", null, t("Status")), h("b", null, h("span", { className: cx("xk-chip", st && st[0] && "xk-chip--" + st[0]) }, t(st ? st[1] : "Lead")))),
      h("div", { className: "xp-fact" }, h("span", null, t("Looked after by")), h("b", null, name || t("Nobody yet"))),
      h("div", { className: "xp-fact" }, h("span", null, t("Place")), h("b", null, [d.city, d.country].filter(Boolean).join(", ") || "–")),
      h("div", { className: "xp-fact" }, h("span", null, t("Last contact")), h("b", null, fmtDay(d.lastContact)), d.contacts12m ? h("small", null, t("Contacts in the last 12 months: {n}", { n: d.contacts12m })) : null),
      d.website ? h("div", { className: "xp-fact" }, h("span", null, t("Web site")), h("b", null, h("a", { href: /^https?:/i.test(d.website) ? d.website : "https://" + d.website, target: "_blank", rel: "noreferrer" }, d.website.replace(/^https?:\/\//i, "").replace(/\/$/, "")))) : null,
      d.sap ? h("div", { className: "xp-fact" }, h("span", null, t("SAP number")), h("b", null, d.sap)) : null),
    h("section", { className: "xp-sales" },
      h("h3", null, t("Orders and sales")),
      o && (o.count || o.last || o.thisYearEur || o.lastYearEur)
        ? h("div", { className: "xp-stats" },
          h("div", { className: "xp-stat" }, h("b", null, o.count != null ? o.count : "–"), h("span", null, t("orders"))),
          h("div", { className: "xp-stat" }, h("b", null, fmtDay(o.last)), h("span", null, t("last order"))),
          o.money ? h("div", { className: "xp-stat" }, h("b", null, eur(o.thisYearEur, { short: true })), h("span", null, t("invoiced in {y}", { y: o.year }))) : null,
          o.money ? h("div", { className: "xp-stat" }, h("b", null, eur(o.lastYearEur, { short: true })), h("span", null, t("invoiced in {y}", { y: o.year - 1 }))) : null,
          o.money && o.lifetimeEur != null ? h("div", { className: "xp-stat" }, h("b", null, eur(o.lifetimeEur, { short: true })), h("span", null, t("since the first order"))) : null)
        : h("p", { className: "xp-mu" }, t("No orders in SAP.")),
      h("p", { className: "xp-mu" }, t("Open offers: {n}", { n: d.openOffers }), " · ", t("Offers sent: {n}", { n: d.offersSent }), d.lastOffer ? " · " + t("last on {d}", { d: fmtDay(d.lastOffer) }) : "")),
    h("p", { className: "xp-mu xp-note" }, h(Icon, { n: "info", size: 16 }), " ", t("E-mails, phones and notes are not shown: they belong to the person who looks after the customer.")));
  const foot = d && !d.open && !err
    ? (ask && ask.startsWith("sent:")
      ? h("p", { className: "xp-sent", role: "status" }, h(Icon, { n: "check-circle", size: 20 }), " ", t("Sent. {name} sees it in their to-dos.", { name: ask.slice(5) }))
      : ask !== null
        ? h("div", { className: "xp-ask" },
          h("input", { className: "input", value: ask, maxLength: 200, autoFocus: true, placeholder: t("What do you want to ask? (optional)"), onChange: (e) => setAsk(e.target.value), onKeyDown: (e) => { if ((e.key || "") === "Enter") { e.preventDefault(); send(); } } }),
          h("button", { type: "button", className: "tc-btn tc-btn--md", disabled: busy, onClick: send }, h(Icon, { n: "send", size: 20 }), busy ? t("Sending…") : t("Send")),
          h("button", { type: "button", className: "tc-btn tc-btn--secondary tc-btn--md", onClick: () => { setAsk(null); setAskErr(null); } }, t("Cancel")),
          askErr ? h("p", { className: "xp-err", role: "alert" }, askErr) : null)
        : h(Fragment, null,
          h("button", { type: "button", className: "tc-btn tc-btn--md", onClick: () => setAsk("") }, h(Icon, { n: "chat", size: 20 }), name && d.ownerIsUser ? t("Ask {name}", { name }) : t("Ask an admin")),
          h("button", { type: "button", className: "tc-btn tc-btn--secondary tc-btn--md", onClick: onClose }, t("Close"))))
    : null;
  return h("div", { className: "xp-scrim", onMouseDown: (e) => { if (e.target === e.currentTarget) onClose(); } },
    h("div", { className: "xp-sheet", role: "dialog", "aria-modal": "true", "aria-label": (d && d.company) || t("View only"), tabIndex: -1, ref },
      h("header", { className: "xp-head" },
        h("div", null, h("span", { className: "xp-eyebrow" }, h(Icon, { n: "visibility", size: 16 }), t("View only")), h("h2", null, (d && d.company) || (d && d.open ? t("Customer") : "…"))),
        h("button", { type: "button", className: "xp-x", "aria-label": t("Close"), onClick: onClose }, h(Icon, { n: "close", size: 24 }))),
      h("div", { className: "xp-body" }, body),
      foot ? h("footer", { className: "xp-foot" }, foot) : null));
}

// ---- the Country explorer: the customers of this country that others look after
export function PeekCountry({ country }) {
  const t = useT();
  const [q, setQ] = useState("");
  const [rows, setRows] = useState(null);
  const [open, setOpen] = useState(null);
  const [limit, setLimit] = useState(8);
  useEffect(() => {
    let alive = true;
    const tm = setTimeout(() => {
      api.get(`/peek/search?country=${encodeURIComponent(country)}&q=${encodeURIComponent(q.trim())}&limit=${limit + 1}`).then((r) => alive && setRows(r.rows)).catch(() => alive && setRows([]));
    }, q ? 250 : 0);
    return () => { alive = false; clearTimeout(tm); };
  }, [country, q, limit]);
  if (rows && !rows.length && !q) return null; // nothing to look at here (or not my country)
  return h("section", { className: "card-surface xp-country" },
    h("div", { className: "xp-country-head" },
      h("div", null,
        h("h3", null, h(Icon, { n: "visibility", size: 20 }), " ", t("Looked after by others (view only)")),
        h("p", { className: "xp-mu" }, t("Customers of {c} that you can only look at: a colleague looks after them, or nobody does yet. Look before you add a company, so it is not recorded twice.", { c: country }))),
      h("input", { className: "input", type: "search", value: q, placeholder: t("Search a company"), "aria-label": t("Search a company"), onChange: (e) => setQ(e.target.value) })),
    rows === null ? h("div", { className: "xp-skel" }, h("span", null), h("span", null))
      : rows.length ? h(Fragment, null,
        h("ul", { className: "xp-list" }, rows.slice(0, limit).map((r) => h(Row, { key: r.id, r, t, onLook: setOpen }))),
        rows.length > limit && limit < 59 ? h("button", { type: "button", className: "tc-btn tc-btn--secondary tc-btn--sm xp-more", onClick: () => setLimit((n) => Math.min(59, n + 20)) }, t("Show more")) : null)
        : h("p", { className: "xp-mu" }, t("Nobody found.")),
    open ? h(PeekPanel, { key: open, id: open, onClose: () => setOpen(null) }) : null);
}

// ---- Add a customer: the company (or e-mail, or phone) is already somebody else's in my countries
export function PeekWarn({ company, email, phone }) {
  const t = useT();
  const [rows, setRows] = useState([]);
  const [open, setOpen] = useState(null);
  useEffect(() => {
    const c = (company || "").trim(), e = (email || "").trim(), p = (phone || "").replace(/\D/g, "");
    if (c.length < 3 && !e.includes("@") && p.length < 7) { setRows([]); return undefined; }
    let alive = true;
    const tm = setTimeout(() => {
      api.get(`/peek/check?company=${encodeURIComponent(c)}&email=${encodeURIComponent(e)}&phone=${encodeURIComponent(p)}`).then((r) => alive && setRows(r.rows)).catch(() => void 0);
    }, 450);
    return () => { alive = false; clearTimeout(tm); };
  }, [company, email, phone]);
  if (!rows.length) return null;
  return h("div", { className: "xp-dup", role: "status", style: { gridColumn: "1 / -1" } },
    h(Icon, { n: "warning", size: 24 }),
    h("div", null,
      h("b", null, rows.some((r) => r.owner) ? t("This company is already a customer of a colleague") : t("This company is already in the CRM")),
      h("ul", null, rows.map((r) => h("li", { key: r.id },
        h("span", null, h("b", null, r.company || "#" + r.id), " · ", [r.city, r.country].filter(Boolean).join(", "), " · ", ownerLine(t, r), r.existing ? " · " + t("Existing customer") : ""),
        h("button", { type: "button", className: "tc-btn tc-btn--secondary tc-btn--sm", onClick: () => setOpen(r.id) }, h(Icon, { n: "visibility", size: 16 }), t("View it"))))),
      h("small", null, rows[0].owner ? t("Do not create it again — talk to {name}.", { name: rows[0].owner }) : t("Do not create it again — ask an admin to give it to you."))),
    open ? h(PeekPanel, { key: open, id: open, onClose: () => setOpen(null) }) : null);
}
