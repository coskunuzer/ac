// The quick dock on the right edge: To-do (real to-dos with a day: type one and press Enter) and Radar (customers to keep an eye on).
// It replaces the two drag-only boxes: everything can now be typed, ticked off, moved to another day - and dragging onto it still works.
import { h, Fragment, useState, useEffect, useMemo, useRef, useCallback, api, Link, useLocation, useT, Icon, cx, errText, todayIso, dayDiff, shortDate, toast, burst } from "./x-kit-br2FMvy0.js";
import { c as CustomerPicker } from "./index-ZdOFbgVe.js";

const addDays = (iso, n) => new Date(Date.parse(iso + "T12:00:00Z") + n * 864e5).toISOString().slice(0, 10);
const nextMonday = (iso) => { const d = new Date(iso + "T12:00:00Z").getUTCDay(); return addDays(iso, ((8 - d) % 7) || 7); };
const typing = (el) => !!el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.tagName === "SELECT" || el.isContentEditable);

// what was dropped: a link to a customer (its page), or a line of text
function dropped(dt) {
  const uri = dt.getData("text/uri-list") || dt.getData("URL") || dt.getData("text/plain") || "";
  const html = dt.getData("text/html");
  const text = html ? (new DOMParser().parseFromString(html, "text/html").body.textContent || "").replace(/\s+/g, " ").trim() : "";
  const m = uri.match(/\/cards\/(\d+)/) || uri.match(/^card:(\d+)$/);
  if (m) return { cardId: parseInt(m[1], 10), label: text };
  const plain = (dt.getData("text/plain") || text).trim();
  return plain && !/^https?:\/\//i.test(plain) && !/^stop:\d+$/.test(plain) ? { label: plain.slice(0, 200) } : null;
}

// "call them tomorrow" -> the day, and the text without the word (English and Turkish)
function readDay(text, today) {
  const rules = [
    [/\s+(today|bugün)$/i, () => today],
    [/\s+(tomorrow|yarın)$/i, () => addDays(today, 1)],
    [/\s+(next week|haftaya|gelecek hafta)$/i, () => nextMonday(today)],
    [/\s+in (\d{1,2}) days?$/i, (m) => addDays(today, parseInt(m[1], 10))],
    [/\s+(\d{1,2}) gün sonra$/i, (m) => addDays(today, parseInt(m[1], 10))],
    [/\s+(mon|tue|wed|thu|fri|sat|sun)[a-z]*$/i, (m) => { const want = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"].indexOf(m[1].toLowerCase()); const d = new Date(today + "T12:00:00Z").getUTCDay(); return addDays(today, ((want - d + 7) % 7) || 7); }],
  ];
  for (const [re, fn] of rules) { const m = text.match(re); if (m) return { text: text.replace(re, "").trim(), day: fn(m) }; }
  return { text, day: null };
}

function TodoRow({ todo, today, onDone, onMove, onDelete, close }) {
  const t = useT();
  const late = todo.dueDate < today ? dayDiff(todo.dueDate, today) : 0;
  return h("li", { className: cx("xd-todo", late > 0 && "is-late", todo.doneAt && "is-done"), draggable: !todo.doneAt, "data-todo": todo.doneAt ? undefined : todo.id, "data-day": todo.dueDate },
    h("input", { type: "checkbox", checked: !!todo.doneAt, onChange: (e) => onDone(todo, e.target), "aria-label": todo.text }),
    h("div", { className: "xd-todo-main" },
      h("span", null, todo.text),
      h("small", null,
        todo.company ? (todo.cardId ? h(Link, { to: `/cards/${todo.cardId}/review`, onClick: close }, todo.company) : todo.company) : null,
        todo.company ? " · " : "",
        late > 0 ? h("b", null, late === 1 ? t("1 day late") : t("{n} days late", { n: late })) : todo.dueDate === today ? t("today") : shortDate(todo.dueDate),
      ),
    ),
    todo.doneAt ? null : h("div", { className: "xd-todo-tools" },
      h("button", { type: "button", title: t("Tomorrow"), "aria-label": t("Move to tomorrow"), onClick: () => onMove(todo, addDays(today, 1)) }, "+1"),
      h("button", { type: "button", title: t("Next week"), "aria-label": t("Move to next week"), onClick: () => onMove(todo, nextMonday(today)) }, h(Icon, { n: "snooze", size: 16 })),
      h("button", { type: "button", title: t("Delete"), "aria-label": t("Delete"), onClick: () => onDelete(todo) }, h(Icon, { n: "close", size: 16 })),
    ),
  );
}

export function QuickDock() {
  const t = useT();
  const loc = useLocation();
  const [tab, setTab] = useState(null); // null = closed
  const [todos, setTodos] = useState(null);
  const [watch, setWatch] = useState([]);
  const [text, setText] = useState("");
  const [due, setDue] = useState("today");
  const [date, setDate] = useState("");
  const [card, setCard] = useState(null);
  const [withCard, setWithCard] = useState(false);
  const [radarPick, setRadarPick] = useState(null);
  const [over, setOver] = useState(null);
  const [err, setErr] = useState(null);
  const [showDone, setShowDone] = useState(false);
  const [allLate, setAllLate] = useState(false);
  const inputRef = useRef(null);
  const today = todayIso();
  const load = useCallback(() => {
    api.get("/todos").then(setTodos).catch(() => setTodos((x) => x || []));
    api.get("/watch").then(setWatch).catch(() => undefined);
  }, []);
  useEffect(() => {
    load();
    const again = () => load();
    window.addEventListener("tece:logged", again);
    return () => window.removeEventListener("tece:logged", again);
  }, [load]);
  // the customer page that is open is offered as the customer of a new to-do
  const here = useMemo(() => { const m = loc.pathname.match(/^\/cards\/(\d+)\//); return m ? parseInt(m[1], 10) : null; }, [loc.pathname]);
  useEffect(() => {
    const onKey = (e) => {
      const key = e.key || "";
      if (key === "Escape" && tab) { setTab(null); return; }
      if (typing(e.target) || e.ctrlKey || e.metaKey || e.altKey) return;
      if ((key === "t" || key === "T") && !/^\/(sprint|fairs\/\d+\/focus)/.test(window.location.pathname)) { e.preventDefault(); setTab("todo"); }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [tab]);
  useEffect(() => { if (tab === "todo" && inputRef.current) inputRef.current.focus(); }, [tab]);
  const parsed = useMemo(() => readDay(text.trim(), today), [text, today]);
  const dueDay = parsed.day || (due === "today" ? today : due === "tomorrow" ? addDays(today, 1) : due === "week" ? nextMonday(today) : date || today);

  async function addTodo(e) {
    if (e) e.preventDefault();
    const what = parsed.text;
    if (!what) return;
    setErr(null);
    try {
      const cardId = withCard ? (card ? card.id : here) : null;
      const made = await api.post("/todos", { text: what, dueDate: dueDay, cardId: cardId || undefined });
      setTodos((list) => [made, ...(list || []).filter((x) => x.id !== made.id)]);
      setText("");
      setCard(null);
      window.dispatchEvent(new Event("tece:logged"));
    } catch (e2) {
      if (e2 && e2.status === 409) { setErr(t("This to-do is already on your list.")); return; }
      setErr(errText(e2, t("Could not save")));
    }
  }
  async function done(todo, box) {
    const to = !todo.doneAt;
    setTodos((list) => list.map((x) => (x.id === todo.id ? { ...x, doneAt: to ? new Date().toISOString() : null } : x)));
    if (to && box) { const r = box.getBoundingClientRect(); burst(r.left + 8, r.top + 8, 14); }
    try { await api.post(`/todos/${todo.id}/done`, { done: to }); window.dispatchEvent(new Event("tece:logged")); } catch (e) { toast(errText(e, t("Could not save")), "bad"); load(); }
  }
  async function move(todo, day) {
    setTodos((list) => list.map((x) => (x.id === todo.id ? { ...x, dueDate: day } : x)));
    try { await api.patch(`/todos/${todo.id}`, { dueDate: day }); } catch (e) { toast(errText(e, t("Could not save")), "bad"); load(); }
  }
  async function remove(todo) {
    setTodos((list) => list.filter((x) => x.id !== todo.id));
    try { await api.delete(`/todos/${todo.id}`); toast(t("To-do deleted"), null, { label: t("Undo"), run: async () => { try { await api.post("/todos", { text: todo.text, dueDate: todo.dueDate, cardId: todo.cardId || undefined }); load(); } catch { /* it stays deleted */ } } }); } catch (e) { toast(errText(e, t("Could not delete")), "bad"); load(); }
  }
  async function addWatch(list, item) {
    try { await api.post("/watch", { list, cardId: item.cardId, label: item.label }); load(); } catch (e) { setErr(errText(e, t("Could not save"))); }
  }
  const watchDel = async (w) => { await api.delete(`/watch/${w.id}`).catch(() => undefined); load(); };
  const watchNote = async (w, note) => { if (note !== (w.note || "")) { await api.patch(`/watch/${w.id}`, { note }).catch(() => undefined); load(); } };
  // a parked line (dropped text) becomes a real to-do for today
  async function schedule(w) {
    try { await api.post("/todos", { text: w.label, dueDate: today, cardId: w.cardId || undefined }); } catch (e) { if (!(e && e.status === 409)) { toast(errText(e, t("Could not save")), "bad"); return; } }
    await api.delete(`/watch/${w.id}`).catch(() => undefined);
    load();
  }
  const dropOn = (list) => ({
    onDragOver: (e) => { if (document.body.hasAttribute("data-cal-drag")) return; e.preventDefault(); e.dataTransfer.dropEffect = "copy"; if (over !== list) setOver(list); },
    onDragLeave: (e) => { if (!e.currentTarget.contains(e.relatedTarget)) setOver((o) => (o === list ? null : o)); },
    onDrop: (e) => {
      if (document.body.hasAttribute("data-cal-drag")) return;
      e.preventDefault(); e.stopPropagation(); setOver(null);
      const item = dropped(e.dataTransfer);
      if (!item) { setErr(t("Drop a customer or a line of text here.")); return; }
      setTab(list);
      if (list === "radar") addWatch("radar", item);
      else if (item.cardId) addWatch("todo", item);
      else api.post("/todos", { text: item.label, dueDate: today }).then(load).catch((e2) => setErr(errText(e2, t("Could not save"))));
    },
  });

  const open = (todos || []).filter((x) => !x.doneAt);
  const late = open.filter((x) => x.dueDate < today);
  const now = open.filter((x) => x.dueDate === today);
  const later = open.filter((x) => x.dueDate > today);
  const finished = (todos || []).filter((x) => x.doneAt).slice(0, 30);
  const radar = watch.filter((w) => w.list === "radar");
  const parked = watch.filter((w) => w.list === "todo");
  const urgent = late.length + now.length;
  const group = (title, list, cls) => (list.length ? h("section", { className: cx("xd-group", cls) }, h("h3", null, title, h("span", null, list.length)), h("ul", null, list.map((x) => h(TodoRow, { key: x.id, todo: x, today, onDone: done, onMove: move, onDelete: remove, close: () => setTab(null) })))) : null);
  const close = () => setTab(null);
  return h(Fragment, null,
    h("div", { className: "xd-handle", role: "group", "aria-label": t("Quick things to do") },
      h("button", { type: "button", className: cx("xd-tab", urgent > 0 && "has-work"), "aria-expanded": tab === "todo", "data-over": over === "todo" || undefined, title: t("To-do") + " (T)", onClick: () => setTab(tab === "todo" ? null : "todo"), ...dropOn("todo") }, h(Icon, { n: "checklist", size: 20 }), h("span", null, t("To-do")), urgent > 0 ? h("b", null, urgent) : null),
      h("button", { type: "button", className: "xd-tab", "aria-expanded": tab === "radar", "data-over": over === "radar" || undefined, title: t("Radar"), onClick: () => setTab(tab === "radar" ? null : "radar"), ...dropOn("radar") }, h(Icon, { n: "bookmark", size: 20 }), h("span", null, t("Radar")), radar.length > 0 ? h("b", null, radar.length) : null),
    ),
    tab ? h(Fragment, null,
      h("div", { className: "xd-scrim", onClick: close, "aria-hidden": "true" }),
      h("aside", { className: "xd-panel", role: "dialog", "aria-label": tab === "todo" ? t("To-do") : t("Radar"), "data-over": over === tab || undefined, ...dropOn(tab) },
        h("header", null,
          h("div", { className: "xd-tabs", role: "tablist" },
            h("button", { type: "button", role: "tab", "aria-selected": tab === "todo", onClick: () => setTab("todo") }, h(Icon, { n: "checklist", size: 20 }), t("To-do"), open.length ? h("span", null, open.length) : null),
            h("button", { type: "button", role: "tab", "aria-selected": tab === "radar", onClick: () => setTab("radar") }, h(Icon, { n: "bookmark", size: 20 }), t("Radar"), radar.length ? h("span", null, radar.length) : null),
          ),
          h("button", { type: "button", className: "xd-close", "aria-label": t("Close"), onClick: close }, h(Icon, { n: "close", size: 20 })),
        ),
        err ? h("p", { className: "tx-err", role: "alert" }, err) : null,
        tab === "todo"
          ? h(Fragment, null,
              h("form", { className: "xd-add", onSubmit: addTodo },
                h("div", { className: "xd-add-line" },
                  h(Icon, { n: "add", size: 20 }),
                  h("input", { ref: inputRef, value: text, onChange: (e) => { setText(e.target.value); if (err) setErr(null); }, placeholder: t("What is to be done? Press Enter"), "aria-label": t("A new to-do"), maxLength: 300 }),
                ),
                h("div", { className: "xd-add-opts" },
                  [["today", "Today"], ["tomorrow", "Tomorrow"], ["week", "Next week"]].map(([k, label]) => h("button", { key: k, type: "button", "aria-pressed": !parsed.day && due === k, onClick: () => setDue(k) }, t(label))),
                  h("label", { className: cx("xd-date", !parsed.day && due === "date" && "is-on") }, h(Icon, { n: "event", size: 16 }), h("input", { type: "date", value: date, min: today, "aria-label": t("Another day"), onChange: (e) => { setDate(e.target.value); setDue(e.target.value ? "date" : "today"); } })),
                  parsed.day ? h("span", { className: "xd-read" }, h(Icon, { n: "event-available", size: 16 }), shortDate(parsed.day)) : null,
                ),
                here || withCard
                  ? h("label", { className: "xd-link" }, h("input", { type: "checkbox", checked: withCard, onChange: (e) => setWithCard(e.target.checked) }), here && !card ? t("For the customer that is open") : t("For a customer"))
                  : h("button", { type: "button", className: "xd-linkbtn", onClick: () => setWithCard(true) }, h(Icon, { n: "person", size: 16 }), t("For a customer")),
                withCard && !here ? h("div", { className: "xd-pick" }, h(CustomerPicker, { value: card, onPick: setCard })) : null,
              ),
              todos === null ? h("span", { className: "tx-skel", style: { height: 120, display: "block" } }) : open.length === 0 && parked.length === 0
                ? h("div", { className: "xd-empty" }, h(Icon, { n: "task-alt", size: 32 }), h("b", null, t("Nothing to do. Enjoy it.")), h("span", null, t("Type above, or drag a customer or a line of text onto this panel.")))
                : h(Fragment, null,
                    group(t("Late"), allLate ? late : late.slice(0, 12), "is-late"),
                    late.length > 12 && !allLate ? h("button", { type: "button", className: "xd-linkbtn", onClick: () => setAllLate(true) }, t("Show all {n} late to-dos", { n: late.length })) : null,
                    group(t("Today"), now),
                    group(t("Coming"), later.slice(0, 40)),
                    later.length > 40 ? h("p", { className: "tx-small tx-muted" }, h(Link, { to: "/calendar", onClick: close }, t("{n} more in the calendar", { n: later.length - 40 }))) : null,
                    parked.length ? h("section", { className: "xd-group" }, h("h3", null, t("Parked, without a day"), h("span", null, parked.length)), h("ul", null, parked.map((w) => h("li", { key: w.id, className: "xd-todo" },
                      h("button", { type: "button", className: "xd-sched", title: t("Do it today"), onClick: () => schedule(w) }, h(Icon, { n: "event-available", size: 16 })),
                      h("div", { className: "xd-todo-main" }, w.cardId ? h(Link, { to: `/cards/${w.cardId}/review`, onClick: close }, w.label) : h("span", null, w.label), w.note ? h("small", null, w.note) : null),
                      h("div", { className: "xd-todo-tools" }, h("button", { type: "button", "aria-label": t("Remove"), onClick: () => watchDel(w) }, h(Icon, { n: "close", size: 16 }))),
                    )))) : null,
                  ),
              finished.length ? h("section", { className: "xd-group xd-done" },
                h("button", { type: "button", className: "xd-done-toggle", "aria-expanded": showDone, onClick: () => setShowDone((s) => !s) }, h(Icon, { n: showDone ? "keyboard-arrow-up" : "keyboard-arrow-down", size: 16 }), t("Done this week"), h("span", null, finished.length)),
                showDone ? h("ul", null, finished.map((x) => h(TodoRow, { key: x.id, todo: x, today, onDone: done, onMove: move, onDelete: remove, close }))) : null,
              ) : null,
              h("footer", null, h(Link, { to: "/calendar", onClick: close }, h(Icon, { n: "calendar-month", size: 16 }), t("Open the calendar")), h("span", null, h("kbd", null, "T"), " ", t("opens this from any page"))),
            )
          : h(Fragment, null,
              h("div", { className: "xd-add" },
                h("p", { className: "xd-hint" }, t("Customers to keep an eye on. Add one here, or drag a customer onto this panel from any list.")),
                h("div", { className: "xd-pick" }, h(CustomerPicker, { value: radarPick, onPick: (c) => { if (c) { addWatch("radar", { cardId: c.id, label: c.label }); setRadarPick(null); } } })),
              ),
              radar.length === 0
                ? h("div", { className: "xd-empty" }, h(Icon, { n: "bookmark", size: 32 }), h("b", null, t("Nobody on your radar yet.")), h("span", null, t("A customer you do not want to lose sight of belongs here.")))
                : h("ul", { className: "xd-radar" }, radar.map((w) => h("li", { key: w.id },
                    h("div", { className: "xd-radar-top" },
                      w.cardId ? h(Link, { to: `/cards/${w.cardId}/review`, onClick: close }, w.label) : h("b", null, w.label),
                      w.country ? h("small", null, w.country) : null,
                      h("button", { type: "button", "aria-label": t("Remove"), onClick: () => watchDel(w) }, h(Icon, { n: "close", size: 16 })),
                    ),
                    h("input", { type: "text", defaultValue: w.note || "", placeholder: t("Why? A note for yourself"), "aria-label": t("A note (optional)"), onBlur: (e) => watchNote(w, e.target.value) }),
                    w.cardId ? h("div", { className: "xd-radar-acts" },
                      h(Link, { to: `/cards/${w.cardId}/review?tab=send&sub=personal`, onClick: close }, h(Icon, { n: "mail", size: 16 }), t("Write")),
                      h("button", { type: "button", onClick: () => { setTab("todo"); setWithCard(true); setCard({ id: w.cardId, label: w.label }); } }, h(Icon, { n: "add", size: 16 }), t("To-do")),
                    ) : null,
                  ))),
            ),
      ),
    ) : null,
  );
}
