import fs from 'fs';
import path from 'path';
import { Router, type NextFunction, type Response } from 'express';
import multer from 'multer';
import * as XLSX from 'xlsx';
import { db } from '../db/connection';
import { paths } from '../config/env';
import { requireAdmin, requireAuth, type AuthedRequest } from '../middleware/auth';
import { cardModel } from '../models/cardModel';
import { useAi } from '../services/aiBudget';
import { activeSnoozes, addAsk, clearSnooze, finishAsk, openAsks, openAskCount, readyList, snooze } from '../services/shipDispatch';
import { closeReminder, latestExports, markExport, rollReminders, takeExport } from '../services/shipExports';
import { mailboxPassword, resendShipMail, saveShipConfig, shipConfig } from '../services/shipMail';
import { approveHeld, dismissMessage, pollMailbox } from '../services/shipMailbox';
import { allCountries, applyImport, countryName, listForwarders, matchPlace, processRows, proposedFor, regions, saveForwarder, saveRegion, serves, type ImportResult } from '../services/shipPlaces';
import { acceptQuote, askAllIn, closeRequest, counterQuote, pasteReply, rejectQuote, remindSilent, setManualPrice, applyReply } from '../services/shipQuotes';
import { readRequest, requestBody, sendRequest, updateRequest, addFirms } from '../services/shipRequests';
import { compare as deskCompare, desk as deskHome, readyPlan } from '../services/shipDesk';
import { listCharges, saveCharges } from '../services/shipCharges';
import { subjectOf } from '../services/shipQuotes';
import { findForwarder } from '../services/shipPlaces';
import { renderTablePdf } from '../services/tablePdf';
import { importOld, type OldExport } from '../services/shipOldImport';
import { firmSheet, sheetApply, sheetPlan } from '../services/shipFirmSheet';
import { listTemplates, previewTemplate, resetTemplate, saveTemplate } from '../services/shipTemplates';
import { confirmManually, jobStatus as verifyJob, overview as verifyOverview, saveVideo, startSending as startVerify, videoInfo } from '../services/shipVerify';

const router = Router();
router.use(requireAuth);
// only Operations (and admins): everybody else gets nothing, not even a hint that the section exists
function requireShip(req: AuthedRequest, res: Response, next: NextFunction) {
  const u = req.user as (AuthedRequest['user'] & { can_ship?: number; perms?: { menu: string[] } | null }) | undefined;
  // a person with a permissions row uses Nakliye when "Nakliye" is on their menu; everybody else as before
  if (u && (u.role === 'admin' || (u.perms ? u.perms.menu.includes('nak') : u.can_ship === 1))) return next();
  res.status(404).json({ error: 'Not found' });
}
router.use(requireShip);

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 8 * 1024 * 1024 } });
const asInt = (v: unknown) => parseInt(String(v), 10);
const str = (v: unknown, max = 4000) => String(v ?? '').trim().slice(0, max);
const guard = (fn: (req: AuthedRequest, res: Response) => Promise<unknown> | unknown) => async (req: AuthedRequest, res: Response) => {
  try { await fn(req, res); } catch (e) { console.error('Shipping route failed:', req.method, req.path, e); if (!res.headersSent) res.status(500).json({ error: (e as Error).message || 'Something went wrong' }); }
};

// ---- what needs attention (the menu badge, the tab badges) -------------------------------------------------------------------------------------
router.get('/overview', guard((_req, res) => {
  const n = (sql: string) => (db.prepare(sql).get() as { n: number }).n;
  const cfg = shipConfig();
  res.json({
    openRequests: n("SELECT COUNT(*) AS n FROM ship_requests WHERE status = 'open' AND archived = 0"),
    toDecide: n("SELECT COUNT(DISTINCT request_id) AS n FROM ship_quotes q JOIN ship_requests r ON r.id = q.request_id WHERE r.status = 'open' AND q.status IN ('open', 'manual')"),
    needLook: n("SELECT COUNT(*) AS n FROM ship_messages WHERE direction = 'in' AND status IN ('held', 'review', 'failed')"),
    failedOut: n("SELECT COUNT(*) AS n FROM ship_messages WHERE direction = 'out' AND status = 'failed'"),
    asks: openAskCount(),
    lateExports: latestExports(30, cfg.lateDays).rows.filter((r) => r.late).length,
    mailboxReady: !!cfg.user && cfg.hasPassword, testMode: cfg.testMode,
  });
}));

// ---- the freight desk: the open work in the order it is done (one call for the first screen), the comparison of the quotes of a request,
// more firms for an open request, and the goods that are ready turned into a request that only has to be confirmed
router.get('/desk', guard((_req, res) => { rollReminders(); res.json(deskHome()); }));
router.get('/requests/:id/compare', guard((req, res) => { const c = deskCompare(String(req.params.id)); return c ? res.json(c) : res.status(404).json({ error: 'Talep bulunamadı.' }); }));
router.post('/requests/:id/add-firms', guard(async (req, res) => {
  const ids = (Array.isArray(req.body?.forwarderIds) ? req.body.forwarderIds : []).map(asInt).filter(Number.isInteger);
  if (!ids.length) return res.status(400).json({ error: 'En az bir firma seçin.' });
  try { res.json(await addFirms(String(req.params.id), ids, req.user!.id)); } catch (e) { res.status(400).json({ error: (e as Error).message }); }
}));
router.get('/ready/plan', guard((req, res) => {
  const sap = str(req.query.sap, 40);
  const p = sap ? readyPlan(sap, str(req.query.mode, 40) || null) : null;
  return p ? res.json({ ...p, charges: listCharges().filter((c) => c.active) }) : res.status(404).json({ error: 'Bu müşteri için sevke hazır sipariş yok.' });
}));

// ---- verifying the e-mail addresses of the firms: one e-mail to every address, with the video ------------------------------------------------------------
const videoUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 60 * 1024 * 1024 } });
// the wording of the e-mails Nakliye sends (admins only): list, preview, save, back to the built-in text
router.get('/templates', requireAdmin, guard((_req, res) => res.json(listTemplates())));
router.post('/templates/preview', requireAdmin, guard((req, res) => res.json(previewTemplate(str(req.body?.key, 40), str(req.body?.lang, 4), req.body?.subject ?? null, String(req.body?.body ?? '')))));
router.put('/templates/:key/:lang', requireAdmin, guard((req, res) => {
  try { saveTemplate(str(req.params.key, 40), str(req.params.lang, 4), req.body?.subject ?? null, String(req.body?.body ?? ''), req.user!.id); res.json({ ok: true }); } catch (e) { res.status(400).json({ error: (e as Error).message }); }
}));
router.delete('/templates/:key/:lang', requireAdmin, guard((req, res) => { resetTemplate(str(req.params.key, 40), str(req.params.lang, 4)); res.json({ ok: true }); }));
router.get('/verify/overview', guard((_req, res) => { res.json({ ...verifyOverview(), job: verifyJob() }); }));
router.get('/verify/status', guard((_req, res) => { res.json(verifyJob()); }));
router.post('/verify/video', videoUpload.single('file'), guard((req, res) => {
  const f = (req as unknown as { file?: { buffer: Buffer; originalname: string; mimetype: string } }).file;
  if (!f) return res.status(400).json({ error: 'Choose the video file.' });
  if (!/\.mp4$/i.test(f.originalname) && !/video\/mp4/.test(f.mimetype)) return res.status(400).json({ error: 'The video must be an MP4 file.' });
  saveVideo(f.buffer);
  res.json({ video: videoInfo() });
}));
router.post('/verify/send', guard((req, res) => {
  const r = startVerify(req.user!.id, { forwarderIds: Array.isArray(req.body?.forwarderIds) ? (req.body.forwarderIds as unknown[]).map(Number) : [], attach: req.body?.attach !== false, onlyUnconfirmed: req.body?.onlyUnconfirmed !== false });
  if (!r.ok) return res.status(400).json({ error: r.error });
  res.json(r);
}));
router.post('/verify/manual', guard((req, res) => { res.json({ ok: confirmManually(Number(req.body?.forwarderId), String(req.body?.email ?? ''), req.user!.id) }); }));

// ---- the firms and the regions --------------------------------------------------------------------------------------------------------------------
router.get('/forwarders', guard((_req, res) => res.json({ forwarders: listForwarders(), regions: regions(), countries: allCountries() })));
router.post('/forwarders', guard((req, res) => { try { res.status(201).json({ id: saveForwarder(null, req.body ?? {}) }); } catch (e) { res.status(400).json({ error: (e as Error).message }); } }));
const firmLog = (id: number, action: string, userId: number) => { const f = findForwarder(id); if (f) db.prepare('INSERT INTO ship_firm_log (forwarder_id, name, action, snapshot, user_id) VALUES (?, ?, ?, ?, ?)').run(id, f.name, action, JSON.stringify(f), userId); };
router.put('/forwarders/:id', guard((req, res) => { try { firmLog(asInt(req.params.id), 'edited', req.user!.id); res.json({ id: saveForwarder(asInt(req.params.id), req.body ?? {}) }); } catch (e) { res.status(400).json({ error: (e as Error).message }); } }));
// delete a firm: it leaves the list; the requests and offers it took part in keep its name (history is never lost)
router.delete('/forwarders/:id', guard((req, res) => {
  const id = asInt(req.params.id);
  const f = findForwarder(id);
  if (!f) return res.status(404).json({ error: 'Firma bulunamadı.' });
  const open = db.prepare("SELECT COUNT(*) AS n FROM ship_request_fw w JOIN ship_requests r ON r.id = w.request_id WHERE w.forwarder_id = ? AND r.status = 'open' AND w.answered_at IS NULL AND w.cancelled_at IS NULL").get(id) as { n: number };
  if (open.n > 0) return res.status(400).json({ error: `${f.name} açık ${open.n} talepte yanıt bekleniyor. Önce talebi kapatın ya da firmayı silmek yerine pasif yapın.` });
  firmLog(id, 'deleted', req.user!.id);
  db.prepare('DELETE FROM ship_forwarders WHERE id = ?').run(id);
  res.json({ ok: true });
}));
// the whole list as an Excel file, and back (changes are shown first; nothing is applied by the preview)
router.get('/forwarders/export.xlsx', guard((_req, res) => {
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', `attachment; filename="tasima-firmalari-${new Date().toISOString().slice(0, 10)}.xlsx"`);
  res.send(firmSheet());
}));
const sheetRows = (req: AuthedRequest): unknown[][] => {
  if (!req.file) return [];
  const wb = XLSX.read(req.file.buffer, { type: 'buffer' });
  return XLSX.utils.sheet_to_json<unknown[]>(wb.Sheets[wb.SheetNames[0]], { header: 1, defval: '' });
};
router.post('/forwarders/sheet/preview', upload.single('file'), guard((req, res) => {
  const plan = sheetPlan(sheetRows(req));
  if (!plan.length) return res.status(400).json({ error: 'Dosyada firma satırı bulunamadı.' });
  res.json({ actions: plan.map(({ input: _i, ...a }) => a) });
}));
router.post('/forwarders/sheet/apply', upload.single('file'), guard((req, res) => res.json(sheetApply(sheetRows(req), req.user!.id))));
// everything we know about one firm: the requests it was asked, whether it answered, the mails that did not go, and replies that came from another address (a wrong address is the usual reason for silence)
router.get('/forwarders/:id/history', guard((req, res) => {
  const id = asInt(req.params.id);
  const f = findForwarder(id);
  if (!f) return res.status(404).json({ error: 'Firma bulunamadı.' });
  const requests = db.prepare(`SELECT w.request_id AS id, r.country, r.city, r.mode, r.status, r.created_at, w.sent_at, w.answered_at, w.reminded_at, w.cancelled_at,
      (SELECT total || ' ' || COALESCE(currency, '') FROM ship_quotes q WHERE q.request_id = w.request_id AND q.forwarder_id = w.forwarder_id AND total IS NOT NULL ORDER BY q.id DESC LIMIT 1) AS price,
      (SELECT status FROM ship_quotes q WHERE q.request_id = w.request_id AND q.forwarder_id = w.forwarder_id ORDER BY q.id DESC LIMIT 1) AS quote_status
    FROM ship_request_fw w JOIN ship_requests r ON r.id = w.request_id WHERE w.forwarder_id = ? ORDER BY r.created_at DESC LIMIT 100`).all(id) as unknown as { id: string; sent_at: string | null; answered_at: string | null; cancelled_at: string | null; created_at: string }[];
  const messages = db.prepare("SELECT id, direction, kind, request_id, address, subject, status, error, created_at FROM ship_messages WHERE forwarder_id = ? ORDER BY id DESC LIMIT 120").all(id) as unknown as { direction: string; address: string | null; status: string; error: string | null }[];
  const ids = requests.map((r) => r.id);
  // replies about this firm's requests that came from an address we do not know (held), and bounces
  const strays = ids.length ? db.prepare(`SELECT id, request_id, address, subject, status, created_at FROM ship_messages WHERE direction = 'in' AND forwarder_id IS NULL AND request_id IN (${ids.map(() => '?').join(',')}) ORDER BY id DESC LIMIT 40`).all(...ids) as unknown as { address: string | null }[] : [];
  const known = new Set(f.emails.map((e) => e.toLowerCase()));
  const senders = new Map<string, number>();
  for (const m of messages) if (m.direction === 'in' && m.address) senders.set(m.address.toLowerCase(), (senders.get(m.address.toLowerCase()) ?? 0) + 1);
  const strangers = [...new Set([...strays.map((m) => String(m.address ?? '').toLowerCase()), ...[...senders.keys()].filter((a) => !known.has(a))])].filter((a) => a && !/mailer-daemon|postmaster/.test(a));
  const sent = requests.filter((r) => r.sent_at);
  const answered = sent.filter((r) => r.answered_at);
  const failedOut = messages.filter((m) => m.direction === 'out' && m.status === 'failed');
  const bounces = strays.filter((m) => /mailer-daemon|postmaster/i.test(String(m.address ?? '')));
  const hints: string[] = [];
  if (failedOut.length) hints.push(`${failedOut.length} e-posta gitmedi (${[...new Set(failedOut.map((m) => m.error ?? 'hata'))].slice(0, 2).join('; ')}). Adres hatalı olabilir.`);
  if (bounces.length) hints.push(`${bounces.length} e-posta geri döndü (adres bulunamadı ya da posta kutusu dolu).`);
  if (sent.length >= 2 && answered.length === 0) hints.push(`${sent.length} talep gitti ama hiç yanıt gelmedi: kayıtlı adresler yanlış olabilir. Firmayı arayıp doğru adresi öğrenin.`);
  if (strangers.length) hints.push(`Yanıtlar kayıtlı olmayan adres(ler)den geldi: ${strangers.join(', ')}. Doğruysa firmaya ekleyin.`);
  res.json({
    firm: f, hints, strangers,
    stats: { asked: sent.length, answered: answered.length, failedOut: failedOut.length, bounces: bounces.length, lastReply: answered.map((r) => r.answered_at).sort().pop() ?? null, lastAsked: sent.map((r) => r.sent_at).sort().pop() ?? null },
    requests, messages, strays,
    log: db.prepare('SELECT id, action, created_at FROM ship_firm_log WHERE forwarder_id = ? ORDER BY id DESC LIMIT 30').all(id),
  });
}));
// the address a reply came from is added to the firm
router.post('/forwarders/:id/add-email', guard((req, res) => {
  const id = asInt(req.params.id);
  const f = findForwarder(id);
  const email = str(req.body?.email, 200).toLowerCase();
  if (!f) return res.status(404).json({ error: 'Firma bulunamadı.' });
  if (!/^[^\s@,;<>]+@[^\s@,;<>]+\.[^\s@,;<>]+$/.test(email)) return res.status(400).json({ error: 'Geçerli bir e-posta adresi değil.' });
  firmLog(id, 'edited (address added)', req.user!.id);
  saveForwarder(id, { ...f, emails: [...new Set([...f.emails, email])] });
  res.json({ ok: true });
}));
router.put('/regions/:name', guard((req, res) => { saveRegion(String(req.params.name), (Array.isArray(req.body?.countries) ? req.body.countries : []).map(String).filter((c: string) => /^[A-Z]{2}$/.test(c))); res.json({ regions: regions() }); }));
router.get('/place', guard((req, res) => res.json(matchPlace(str(req.query.q, 80)))));

// a table of firms: an Excel / CSV file, or rows pasted (the client sends the rows as text); the answer says what would happen. Nothing is saved yet.
router.post('/forwarders/import/preview', upload.single('file'), guard((req, res) => {
  let rows: string[][] = [];
  if (req.file) {
    const wb = XLSX.read(req.file.buffer, { type: 'buffer' });
    rows = XLSX.utils.sheet_to_json<unknown[]>(wb.Sheets[wb.SheetNames[0]], { header: 1, defval: '' }).map((r) => r.map((c) => String(c ?? '').trim()));
  } else if (Array.isArray(req.body?.rows)) rows = req.body.rows.map((r: unknown[]) => r.map((c) => String(c ?? '').trim()));
  const result = processRows(rows);
  if (!result) return res.status(400).json({ error: 'Tabloda satır bulunamadı.' });
  res.json({ rows, result });
}));
router.post('/forwarders/import/apply', guard((req, res) => {
  const rows: string[][] = (req.body?.rows ?? []).map((r: unknown[]) => r.map((c) => String(c ?? '')));
  const result: ImportResult | null = processRows(rows);
  if (!result) return res.status(400).json({ error: 'Tabloda satır bulunamadı.' });
  res.json(applyImport(result, (req.body?.answers ?? {}) as Record<string, string>));
}));

const chargesOf = (v: unknown): string[] => (Array.isArray(v) ? v : []).map((x) => str(x, 140)).filter(Boolean).slice(0, 20);

// ---- a new request: read the pasted text, propose the firms, send ----------------------------------------------------------------------------------------------------
router.post('/read', guard(async (req, res) => {
  const text = str(req.body?.text, 6000);
  if (!text) return res.status(400).json({ error: 'Talep metnini yapıştırın.' });
  let ai = false;
  if (req.body?.ai !== false) ai = useAi(req.user!, res);
  if (res.headersSent) return;
  const p = await readRequest(text, ai);
  res.json({ ...p, proposals: proposedFor(p.iso || null, p.mode) });
}));
router.get('/proposals', guard((req, res) => res.json(proposedFor(str(req.query.iso, 2) || null, str(req.query.mode, 40) || 'Karayolu'))));
router.post('/requests', guard(async (req, res) => {
  const b = req.body ?? {};
  const ids = (Array.isArray(b.forwarderIds) ? b.forwarderIds : []).map(asInt).filter(Number.isInteger);
  if (!ids.length) return res.status(400).json({ error: 'En az bir firma seçin.' });
  // only the destination is required: pallets, weight and size are not always known (several lines, different pallets)
  if (!str(b.country)) return res.status(400).json({ error: 'Varış ülkesi gerekli.' });
  const cardId = b.cardId ? asInt(b.cardId) : null;
  if (cardId && !cardModel.findById(cardId)) return res.status(400).json({ error: 'Müşteri bulunamadı.' });
  res.status(201).json(await sendRequest({ text: str(b.text, 6000), country: str(b.country, 80), countryIso: str(b.countryIso, 2) || null, city: str(b.city, 80), mode: str(b.mode, 40), pallets: Number(b.pallets) > 0 ? Math.round(Number(b.pallets)) : null, weightKg: Number(b.weightKg) > 0 ? Number(b.weightKg) : null, cargo: str(b.cargo, 1500), charges: chargesOf(b.charges), size: str(b.size, 60), ready: str(b.ready, 80), pickup: str(b.pickup, 80), cardId, exportKey: str(b.exportKey, 300) || null, forwarderIds: ids, userId: req.user!.id, askId: b.askId ? asInt(b.askId) : null }));
}));

// the e-mail one firm would get (shown before sending)
router.post('/preview', guard((req, res) => {
  const b = req.body ?? {};
  const f = findForwarder(asInt(b.forwarderId));
  if (!f) return res.status(404).json({ error: 'Firma bulunamadı.' });
  const lang = b.lang === 'tr' || b.lang === 'en' ? b.lang : f.lang;
  res.json({ subject: subjectOf({ id: 'YYYYMMDD-NN', mode: str(b.mode, 40) || 'Karayolu', country: str(b.country), city: str(b.city) }), lang, to: f.emails, body: requestBody({ country: str(b.country) || null, city: str(b.city) || null, pallets: Number(b.pallets) || null, weightKg: Number(b.weightKg) || null, size: str(b.size, 60), ready: str(b.ready, 80), pickup: str(b.pickup, 80) || 'Bursa, Türkiye', text: str(b.text, 6000), cargo: str(b.cargo, 1500), charges: chargesOf(b.charges) }, f.contact, lang) });
}));

// the list of items a forwarder is asked to include in the price (ticked per request); an admin keeps it
router.get('/charges', guard((_req, res) => res.json(listCharges())));
router.put('/charges', requireAdmin, guard((req, res) => res.json(saveCharges(Array.isArray(req.body?.charges) ? req.body.charges : []))));

// an open request is UPDATED (more quantity, one more supplier, a changed term) instead of asked again
router.post('/requests/:id/update', guard(async (req, res) => {
  const note = str(req.body?.note, 2000);
  if (!note) return res.status(400).json({ error: 'Neyin değiştiğini yazın.' });
  try {
    res.json(await updateRequest(String(req.params.id), { note, cargo: str(req.body?.cargo, 1500) || undefined, charges: Array.isArray(req.body?.charges) ? chargesOf(req.body.charges) : undefined, addForwarderIds: (Array.isArray(req.body?.addForwarderIds) ? req.body.addForwarderIds : []).map(asInt).filter(Number.isInteger), userId: req.user!.id }));
  } catch (e) { res.status(400).json({ error: (e as Error).message }); }
}));
router.get('/requests', guard((req, res) => {
  const status = str(req.query.status, 10);
  const rows = db.prepare(`SELECT r.*, (SELECT COUNT(*) FROM ship_request_fw f WHERE f.request_id = r.id AND f.sent_at IS NOT NULL) AS asked, (SELECT COUNT(*) FROM ship_quotes q WHERE q.request_id = r.id) AS quotes,
      (SELECT COUNT(*) FROM ship_quotes q WHERE q.request_id = r.id AND q.status IN ('open','manual')) AS to_decide, (SELECT forwarder_name || '|' || COALESCE(total, '') || ' ' || COALESCE(currency, '') FROM ship_quotes WHERE id = r.accepted_quote) AS accepted,
      c.company AS customer FROM ship_requests r LEFT JOIN cards c ON c.id = r.card_id WHERE r.archived = ?${status === 'open' || status === 'closed' ? ' AND r.status = ?' : ''} ORDER BY r.id DESC LIMIT 300`).all(...(status === 'open' || status === 'closed' ? [req.query.archived === '1' ? 1 : 0, status] : [req.query.archived === '1' ? 1 : 0]));
  res.json(rows);
}));
router.get('/requests/:id', guard((req, res) => {
  const id = String(req.params.id);
  const request = db.prepare('SELECT r.*, c.company AS customer FROM ship_requests r LEFT JOIN cards c ON c.id = r.card_id WHERE r.id = ?').get(id);
  if (!request) return res.status(404).json({ error: 'Talep bulunamadı.' });
  res.json({
    request, cfg: { remindHours: shipConfig().remindHours },
    firms: db.prepare('SELECT * FROM ship_request_fw WHERE request_id = ? ORDER BY forwarder_name').all(id),
    quotes: db.prepare('SELECT * FROM ship_quotes WHERE request_id = ? ORDER BY total IS NULL, total, id').all(id),
    // the mail text comes with the request so the person reads the firm's reply right here, without opening anything else
    messages: db.prepare('SELECT id, direction, kind, forwarder_id, quote_id, address, subject, substr(body, 1, 3000) AS body, attachments, status, error, created_at, sent_at FROM ship_messages WHERE request_id = ? ORDER BY id DESC').all(id),
    events: db.prepare('SELECT e.*, u.display_name AS user_name FROM ship_events e LEFT JOIN users u ON u.id = e.user_id WHERE e.request_id = ? ORDER BY e.id DESC').all(id),
  });
}));
router.post('/requests/:id/close', guard(async (req, res) => res.json(await closeRequest(String(req.params.id), req.user!.id))));
router.post('/requests/:id/remind', guard(async (req, res) => res.json(await remindSilent(String(req.params.id), req.user!.id))));
router.post('/requests/:id/archive', guard((req, res) => { db.prepare('UPDATE ship_requests SET archived = ? WHERE id = ?').run(req.body?.archived === false ? 0 : 1, String(req.params.id)); res.json({ ok: true }); }));
router.post('/requests/:id/paste-reply', guard(async (req, res) => { const r = await pasteReply(String(req.params.id), asInt(req.body?.forwarderId), str(req.body?.text, 8000), req.user!.id); res.status(r.ok ? 200 : 400).json(r); }));

// ---- decisions ---------------------------------------------------------------------------------------------------------------------------------------------
const decide = (fn: (id: number, req: AuthedRequest) => Promise<{ ok: boolean; error?: string }> | { ok: boolean; error?: string }) => guard(async (req, res) => { const r = await fn(asInt(req.params.id), req); res.status(r.ok ? 200 : 400).json(r); });
router.post('/quotes/:id/accept', decide((id, req) => acceptQuote(id, req.user!.id)));
router.post('/quotes/:id/reject', decide((id, req) => rejectQuote(id, req.user!.id)));
router.post('/quotes/:id/counter', decide((id, req) => counterQuote(id, Number(req.body?.price), req.user!.id)));
router.post('/quotes/:id/price', decide((id, req) => setManualPrice(id, Number(req.body?.price), str(req.body?.currency, 6) || 'EUR', req.user!.id, Number(req.body?.extra) || 0)));
router.post('/quotes/:id/ask-all-in', decide((id, req) => askAllIn(id, req.user!.id)));

// ---- the messages ---------------------------------------------------------------------------------------------------------------------------------------------
router.get('/messages', guard((req, res) => {
  const dir = req.query.direction === 'out' ? 'out' : 'in';
  const status = str(req.query.status, 20);
  res.json(db.prepare(`SELECT m.id, m.direction, m.kind, m.request_id, m.address, m.subject, m.status, m.error, m.created_at, m.attachments FROM ship_messages m WHERE m.direction = ?${status ? ' AND m.status = ?' : ''} ORDER BY m.id DESC LIMIT 200`).all(...(status ? [dir, status] : [dir])));
}));
router.get('/messages/:id', guard((req, res) => {
  const m = db.prepare('SELECT * FROM ship_messages WHERE id = ?').get(asInt(req.params.id));
  return m ? res.json(m) : res.status(404).json({ error: 'Not found' });
}));
// the reply is read into a quote at once (it used to wait for the next round of the mailbox, so the price showed minutes later - or never, without a mailbox)
router.post('/messages/:id/approve', guard(async (req, res) => {
  const r = approveHeld(asInt(req.params.id), req.user!.id);
  if (r.ok) { try { await applyReply(asInt(req.params.id)); } catch (e) { console.error('Reading an approved shipping reply failed:', e); } }
  res.json(r);
}));
router.post('/messages/:id/dismiss', guard((req, res) => { dismissMessage(asInt(req.params.id)); res.json({ ok: true }); }));
router.post('/messages/:id/resend', guard(async (req, res) => res.json(await resendShipMail(asInt(req.params.id)))));
router.get('/files/*rest', (req: AuthedRequest, res) => {
  const rel = String((req.params as Record<string, unknown>).rest ?? '').replace(/,/g, '/');
  const base = path.resolve(paths.uploadsDir, '..', 'shipping');
  const file = path.resolve(base, rel);
  if (!file.startsWith(base + path.sep) || !fs.existsSync(file)) return res.status(404).json({ error: 'Not found' });
  res.download(file);
});
router.post('/poll', guard(async (_req, res) => res.json(await pollMailbox())));

// ---- VF04: what is ready to dispatch, back orders silenced, asks from Sales --------------------------------------------------------------------------------------------
router.get('/ready', guard((req, res) => res.json({ ...readyList(req.query.silenced === '1'), asks: openAsks() })));
router.post('/ready/snooze', guard((req, res) => {
  const sap = str(req.body?.sap, 40);
  if (!sap) return res.status(400).json({ error: 'Müşteri seçin.' });
  res.status(201).json({ id: snooze({ sap, sdNo: str(req.body?.sdNo, 40) || null, until: str(req.body?.until, 10) || null, reason: str(req.body?.reason, 200), userId: req.user!.id }) });
}));
router.post('/ready/snooze/:id/clear', guard((req, res) => { clearSnooze(asInt(req.params.id)); res.json({ ok: true }); }));
router.get('/ready/snoozed', guard((_req, res) => res.json(activeSnoozes())));
router.post('/asks', guard((req, res) => res.status(201).json({ id: addAsk({ sap: str(req.body?.sap, 40), sdNos: (Array.isArray(req.body?.sdNos) ? req.body.sdNos : []).map(String), note: str(req.body?.note, 400) || null, userId: req.user!.id }) })));
router.post('/asks/:id/dismiss', guard((req, res) => { finishAsk(asInt(req.params.id), 'dismissed', req.user!.id, null); res.json({ ok: true }); }));
// the text of a new request made from what is ready: the person only has to add the pallets
router.post('/ready/draft', guard((req, res) => {
  const sap = str(req.body?.sap, 40);
  const rows = db.prepare('SELECT sd_no, billing_date, customer, country, city, net_value, currency, weight FROM export_dispatch_queue WHERE sap_no = ? ORDER BY billing_date').all(sap) as unknown as { sd_no: string; customer: string; country: string | null; city: string | null; net_value: number | null; currency: string; weight: number | null }[];
  if (!rows.length) return res.status(404).json({ error: 'Bu müşteri için sevke hazır sipariş yok.' });
  const wanted = new Set((Array.isArray(req.body?.sdNos) ? req.body.sdNos : []).map(String));
  const use = wanted.size ? rows.filter((r) => wanted.has(r.sd_no)) : rows;
  const kg = Math.round(use.reduce((a, r) => a + (r.weight ?? 0), 0));
  const card = db.prepare("SELECT id, country, city FROM cards WHERE TRIM(sap) = ? LIMIT 1").get(sap.trim()) as { id: number; country: string | null; city: string | null } | undefined;
  const dest = [rows[0].city || card?.city, rows[0].country || card?.country].filter(Boolean).join(', ');
  const ask = db.prepare("SELECT id FROM ship_asks WHERE sap_no = ? AND status = 'open' ORDER BY id DESC LIMIT 1").get(sap) as { id: number } | undefined;
  res.json({ text: `${rows[0].customer} için sevke hazır sipariş (${use.map((r) => r.sd_no).join(', ')}). Varış: ${dest}. Toplam ${kg ? `${kg.toLocaleString('tr-TR')} kg` : 'ağırlık belirtilmemiş'}. Karayolu.`, cardId: card?.id ?? null, askId: ask?.id ?? null, sap });
}));

// ---- the home page of Operations: what is ready, which documents wait, where there are few transporters (newest first) ------------------------------------------------
// only the invoices of the last 45 days are followed: older ones were sent long ago
const FOLLOW_DAYS = 45;
router.get('/dashboard', guard((_req, res) => {
  const cfg = shipConfig();
  const n = (sql: string) => (db.prepare(sql).get() as { n: number }).n;
  rollReminders();
  const ready = readyList(false).customers;
  const lastDate = (c: (typeof ready)[number]) => c.rows.map((r) => r.date ?? '').sort().pop() ?? '';
  const byCur = new Map<string, { value: number; kg: number }>();
  for (const c of ready) { const o = byCur.get(c.currency) ?? { value: 0, kg: 0 }; o.value += c.value; o.kg += c.weight; byCur.set(c.currency, o); }
  const exp = latestExports(FOLLOW_DAYS, cfg.lateDays).rows.filter((r) => r.docs.state !== 'sent' && r.docs.state !== 'ignored');
  // countries people ask about (ledger exports, ready goods, past requests) against the active firms that serve them
  const demand = new Map<string, number>();
  const want = (name: string | null | undefined, w = 1) => { const p = name ? matchPlace(name) : null; if (p?.type === 'country') demand.set(p.iso, (demand.get(p.iso) ?? 0) + w); };
  for (const r of latestExports(365, 0).rows) want(r.country);
  for (const c of readyList(true).customers) want(c.country, 2);
  for (const r of db.prepare('SELECT country_iso AS iso FROM ship_requests WHERE country_iso IS NOT NULL').all() as { iso: string }[]) demand.set(r.iso, (demand.get(r.iso) ?? 0) + 2);
  const firms = listForwarders().filter((f) => f.active);
  const few = [...demand.entries()].map(([iso, d]) => ({ iso, name: countryName(iso), demand: d, firms: firms.filter((f) => f.modes.some((m) => serves(f, iso, m))).length }))
    .filter((x) => x.firms <= 2).sort((a, b) => a.firms - b.firms || b.demand - a.demand).slice(0, 5);
  res.json({
    counts: { openRequests: n("SELECT COUNT(*) AS n FROM ship_requests WHERE status = 'open' AND archived = 0"), toDecide: n("SELECT COUNT(DISTINCT request_id) AS n FROM ship_quotes q JOIN ship_requests r ON r.id = q.request_id WHERE r.status = 'open' AND q.status IN ('open', 'manual')"), asks: openAskCount(), needLook: n("SELECT COUNT(*) AS n FROM ship_messages WHERE direction = 'in' AND status IN ('held', 'review', 'failed')") },
    ready: { customers: ready.length, lots: ready.reduce((a, c) => a + c.rows.length, 0), totals: [...byCur.entries()].map(([currency, o]) => ({ currency, value: Math.round(o.value), kg: Math.round(o.kg) })), list: ready.slice().sort((a, b) => lastDate(b).localeCompare(lastDate(a))).slice(0, 5).map((c) => ({ sap: c.sap, customer: c.customer, country: c.country, cardId: c.cardId, value: c.value, currency: c.currency, weight: c.weight, lots: c.rows.length, last: lastDate(c), request: c.request, ask: c.ask })) },
    docs: { count: exp.length, late: exp.filter((r) => r.late).length, list: exp.slice(0, 5) },
    // the open freight requests (the ones with offers to decide first) and the e-mails that need a person
    requests: db.prepare(`SELECT r.id, r.city, r.country, r.mode, r.created_at, c.company AS customer, (SELECT COUNT(*) FROM ship_request_fw f WHERE f.request_id = r.id AND f.sent_at IS NOT NULL) AS asked,
        (SELECT COUNT(*) FROM ship_quotes q WHERE q.request_id = r.id) AS quotes, (SELECT COUNT(*) FROM ship_quotes q WHERE q.request_id = r.id AND q.status IN ('open','manual')) AS to_decide,
        (SELECT MIN(total) FROM ship_quotes q WHERE q.request_id = r.id AND q.status IN ('open','countered') AND total > 0) AS best, (SELECT currency FROM ship_quotes q WHERE q.request_id = r.id AND q.status IN ('open','countered') AND total > 0 ORDER BY total LIMIT 1) AS best_cur
        FROM ship_requests r LEFT JOIN cards c ON c.id = r.card_id WHERE r.status = 'open' AND r.archived = 0 ORDER BY to_decide DESC, r.id DESC LIMIT 8`).all(),
    mails: db.prepare("SELECT id, request_id, address, subject, status, created_at, substr(body, 1, 160) AS snippet FROM ship_messages WHERE direction = 'in' AND status IN ('held', 'review', 'failed') ORDER BY id DESC LIMIT 6").all(),
    few,
  });
}));

// ---- the latest exports and their documents ---------------------------------------------------------------------------------------------------------------------------
router.get('/exports', guard((req, res) => { rollReminders(); res.json(latestExports(Math.min(asInt(req.query.days) || FOLLOW_DAYS, FOLLOW_DAYS), shipConfig().lateDays)); }));
router.post('/exports/mark', guard((req, res) => {
  const key = str(req.body?.key, 400);
  if (!key) return res.status(400).json({ error: 'Kayıt anahtarı yok.' });
  const status = ['sent', 'none', 'ignored', 'working'].includes(req.body?.status) ? req.body.status : 'sent';
  const row = latestExports(120, 0).rows.find((x) => x.key === key);
  if (status === 'working') {
    if (!row) return res.status(404).json({ error: 'İhracat kaydı bulunamadı.' });
    takeExport(key, req.user!.id, row);
    return res.json({ ok: true });
  }
  if (row && (status === 'sent' || status === 'ignored' || status === 'none')) closeReminder(row);
  const logInfo = row ? { action: status === 'sent' ? 'sent' : status === 'ignored' ? 'handed_to_sales' : (row.docs.state === 'ignored' ? 'followed_again' : 'cleared'), role: req.user!.role === 'admin' ? 'admin' : 'operations', customer: row.customer, invoice: row.invoice } : undefined;
  markExport(key, req.user!.id, { status, how: req.body?.how === 'crm' ? 'crm' : 'manual', note: str(req.body?.note, 200) || null, mailId: req.body?.mailId ? asInt(req.body.mailId) : null, to: str(req.body?.to, 200) || null, files: (Array.isArray(req.body?.files) ? req.body.files : []).map(String), notMail: req.body?.notMail ? asInt(req.body.notMail) : null, log: logInfo });
  res.json({ ok: true });
}));

// ---- the weekly report ------------------------------------------------------------------------------------------------------------------------------------------------------
function weekReport(weekStart: string) {
  const addDays = (d: string, n: number) => new Date(Date.parse(`${d}T12:00:00Z`) + n * 86400000).toISOString().slice(0, 10);
  const one = (from: string) => {
    const to = addDays(from, 7);
    const c = (sql: string, ...p: string[]) => (db.prepare(sql).get(...p) as { n: number }).n;
    const money = db.prepare("SELECT currency, SUM(total) AS amount FROM ship_quotes WHERE status = 'accepted' AND updated_at >= ? AND updated_at < ? GROUP BY currency").all(from, to) as { currency: string; amount: number }[];
    return {
      sent: c("SELECT COUNT(*) AS n FROM ship_requests WHERE created_at >= ? AND created_at < ?", from, to), received: c("SELECT COUNT(*) AS n FROM ship_quotes WHERE received_at >= ? AND received_at < ?", from, to),
      accepted: c("SELECT COUNT(*) AS n FROM ship_quotes WHERE status = 'accepted' AND updated_at >= ? AND updated_at < ?", from, to), rejected: c("SELECT COUNT(*) AS n FROM ship_quotes WHERE status = 'rejected' AND updated_at >= ? AND updated_at < ?", from, to),
      pending: c("SELECT COUNT(*) AS n FROM ship_quotes WHERE status IN ('open','manual') AND received_at >= ? AND received_at < ?", from, to), money,
    };
  };
  const days = Array.from({ length: 7 }, (_, i) => {
    const d = addDays(weekStart, i);
    const c = (sql: string) => (db.prepare(sql).get(d, addDays(d, 1)) as { n: number }).n;
    return { date: d, sent: c('SELECT COUNT(*) AS n FROM ship_requests WHERE created_at >= ? AND created_at < ?'), received: c('SELECT COUNT(*) AS n FROM ship_quotes WHERE received_at >= ? AND received_at < ?'), money: db.prepare("SELECT currency, SUM(total) AS amount FROM ship_quotes WHERE status = 'accepted' AND updated_at >= ? AND updated_at < ? GROUP BY currency").all(d, addDays(d, 1)) as { currency: string; amount: number }[] };
  });
  return { weekStart, weekEnd: addDays(weekStart, 6), ...one(weekStart), previous: one(addDays(weekStart, -7)), days };
}
const mondayOf = (v: unknown) => {
  const d = /^\d{4}-\d{2}-\d{2}$/.test(String(v ?? '')) ? new Date(`${v}T12:00:00Z`) : new Date();
  d.setUTCDate(d.getUTCDate() - ((d.getUTCDay() + 6) % 7));
  return d.toISOString().slice(0, 10);
};
router.get('/report', guard((req, res) => res.json(weekReport(mondayOf(req.query.week)))));
router.get('/report.pdf', guard(async (req, res) => {
  const r = weekReport(mondayOf(req.query.week));
  const fmt = (m: { currency: string; amount: number }[]) => m.map((x) => `${Math.round(x.amount).toLocaleString('tr-TR')} ${x.currency}`).join(' + ') || '-';
  const pdf = await renderTablePdf({
    title: 'Nakliye haftalık raporu', subtitle: `${r.weekStart} - ${r.weekEnd}`,
    facts: [`${r.sent} talep gönderildi`, `${r.received} teklif geldi`, `${r.accepted} kabul`, `${r.rejected} red`, `kabul edilen tutar ${fmt(r.money)}`],
    sections: [
      { heading: 'Geçen haftayla karşılaştırma', columns: [{ label: 'Gösterge', w: 260 }, { label: 'Bu hafta', w: 160, right: true }, { label: 'Geçen hafta', w: 160, right: true }], rows: [['Gönderilen talep', String(r.sent), String(r.previous.sent)], ['Gelen teklif', String(r.received), String(r.previous.received)], ['Kabul edilen', String(r.accepted), String(r.previous.accepted)], ['Reddedilen', String(r.rejected), String(r.previous.rejected)], ['Kabul edilen tutar', fmt(r.money), fmt(r.previous.money)]] },
      { heading: 'Günlük', columns: [{ label: 'Gün', w: 140 }, { label: 'Talep', w: 120, right: true }, { label: 'Teklif', w: 120, right: true }, { label: 'Kabul edilen tutar', w: 220, right: true }], rows: r.days.map((d) => [d.date, String(d.sent), String(d.received), fmt(d.money)]) },
    ],
    landscape: false,
  });
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `inline; filename="nakliye-rapor-${r.weekStart}.pdf"`);
  res.send(pdf);
}));

// ---- settings (admin) -------------------------------------------------------------------------------------------------------------------------------------------------------------
router.get('/config', requireAdmin, guard((_req, res) => res.json(shipConfig())));
router.put('/config', requireAdmin, guard((req, res) => { saveShipConfig(req.body ?? {}); res.json(shipConfig()); }));
router.post('/config/check', requireAdmin, guard(async (_req, res) => {
  const out: { smtp: string; imap: string } = { smtp: 'not checked', imap: 'not checked' };
  if (!mailboxPassword()) return res.json({ smtp: 'Şifre girilmemiş', imap: 'Şifre girilmemiş' });
  const c = shipConfig();
  try { const nodemailer = await import('nodemailer'); await nodemailer.createTransport({ host: c.smtpHost, port: c.smtpPort, secure: c.smtpPort === 465, auth: { user: c.user, pass: mailboxPassword() } }).verify(); out.smtp = 'Tamam'; } catch (e) { out.smtp = `Olmadı: ${(e as Error).message}`.slice(0, 200); }
  try { const { ImapFlow } = await import('imapflow'); const cl = new ImapFlow({ host: c.imapHost, port: c.imapPort, secure: c.imapPort === 993, auth: { user: c.user, pass: mailboxPassword() }, logger: false }); await cl.connect(); await cl.logout(); out.imap = 'Tamam'; } catch (e) { out.imap = `Olmadı: ${(e as Error).message}`.slice(0, 200); }
  res.json(out);
}));
// the history of the old Nakliye app (the JSON made by tools/export-old-nakliye.cjs): admin only, safe to run twice (requests already here are skipped)
const bigUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 40 * 1024 * 1024 } });
router.post('/import-old', requireAdmin, bigUpload.single('file'), guard((req, res) => {
  if (!req.file) return res.status(400).json({ error: 'JSON dosyasını seçin.' });
  let data: OldExport;
  try { data = JSON.parse(req.file.buffer.toString('utf8')) as OldExport; } catch { return res.status(400).json({ error: 'Bu dosya okunamadı (JSON değil).' }); }
  if (!data?.tables || typeof data.tables !== 'object') return res.status(400).json({ error: 'Bu dosya eski Nakliye dışa aktarımına benzemiyor.' });
  res.json(importOld(data, req.user!.id));
}));
router.get('/countries', guard((_req, res) => res.json(allCountries().map((c) => ({ iso: c.iso, name: countryName(c.iso) })))));

export default router;
