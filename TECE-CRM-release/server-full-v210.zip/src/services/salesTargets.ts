import { db } from '../db/connection';
import { countryModel } from '../models/countryModel';
import { countryMap } from './intelCountry';
import { adjustedMonths } from './intelExclude';

// Revenue targets and forecasts (Sena's list, point 2).
//   Target    = what management gave for the month / the year (the company, and the part given to each sales person)
//   Actual    = invoiced in SAP (the Sales intelligence summary of the SAP sales list: net EUR, the group companies left out)
//   Expected  = what will probably be invoiced by the end of the month / the year: today's actual plus what is still to come
//   Gap       = what is left to reach the target / the expected difference to the target
// The sales person types a forecast at the start of the month; at the end of the month the system forecast, the person's forecast and the actual stand side by side.

const GROUPCOS = /TECE\s*DE[CK]|TEZER/i;
export const FORECAST_GRACE_DAY = 10; // a sales person may type or change the forecast of the month until this day of the month
const r0 = (v: number) => Math.round(v);
const ym2 = (y: number, m: number) => `${y}-${String(m).padStart(2, '0')}`;
export const shiftYm = (ym: string, n: number): string => { let y = +ym.slice(0, 4), m = +ym.slice(5, 7) + n; while (m < 1) { m += 12; y--; } while (m > 12) { m -= 12; y++; } return ym2(y, m); };
export const daysIn = (ym: string): number => new Date(Date.UTC(+ym.slice(0, 4), +ym.slice(5, 7), 0)).getUTCDate();
const monthsRange = (a: string, b: string): string[] => { const o: string[] = []; for (let m = a; m <= b; m = shiftYm(m, 1)) o.push(m); return o; };
export const normName = (s: string): string => String(s || '').toLowerCase().replace(/ı/g, 'i').normalize('NFD').replace(/\p{Diacritic}/gu, '').replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
const title = (s: string) => s.toLowerCase().replace(/(^|\s)(\p{L})/gu, (_m, a: string, b: string) => a + b.toLocaleUpperCase('tr'));

export type Channel = 'all' | 'export' | 'domestic';
export interface Dated { cut: string; ym: string; day: number; days: number; finished: boolean; firstYm: string }

// the last day with data: the sales list is uploaded now and then, so "today" in the report is the last invoice day, not the calendar day
export function dataCut(): string | null { return (db.prepare('SELECT MAX(last_date) d FROM intel_cust').get() as { d: string | null }).d; }

// ---- who looks after a customer (the CRM card, else the person of the country, else the sales person SAP shows)
export interface Rep { key: string; userId: number | null; name: string }
interface UserRow { id: number; display_name: string; market: string | null; is_assistant: number | null }
export function repResolver(): { repOfCust: Map<string, Rep>; users: Map<string, Rep>; reps: Map<string, Rep> } {
  const urows = db.prepare('SELECT id, display_name, market, is_assistant FROM users WHERE is_active = 1').all() as unknown as UserRow[];
  const users = new Map<string, Rep>();
  for (const u of urows) { if (u.is_assistant) continue; const k = normName(u.display_name); if (k && !users.has(k)) users.set(k, { key: k, userId: u.id, name: u.display_name }); }
  const reps = new Map<string, Rep>();
  const words = (k: string) => new Set(k.split(' ')); const sub = (a: string, b: string) => { const wb = words(b); return [...words(a)].every((w) => wb.has(w)); };
  const rep = (name: string): Rep | null => { const k = normName(name); if (!k) return null; let u = users.get(k); if (!u) { const c = [...users.values()].filter((x) => sub(x.key, k)); if (c.length === 1) u = c[0]; } if (u) { reps.set(u.key, u); return u; } let r = reps.get(k); if (!r) { r = { key: k, userId: null, name: title(name) }; reps.set(k, r); } return r; };
  const cards = new Map<string, string>();
  for (const c of db.prepare("SELECT sap, person FROM cards WHERE sap IS NOT NULL AND TRIM(sap) <> '' AND person IS NOT NULL AND TRIM(person) <> ''").all() as { sap: string; person: string }[]) if (!cards.has(c.sap.trim())) cards.set(c.sap.trim(), c.person);
  const cm = countryMap();
  const out = new Map<string, Rep>();
  for (const c of db.prepare('SELECT code, rep FROM intel_cust').all() as { code: string; rep: string | null }[]) {
    const country = cm.get(c.code)?.country ?? '';
    const name = cards.get(c.code) || (country ? countryModel.findByCountry(country)?.responsible : null) || c.rep || '';
    const r = rep(name); if (r) out.set(c.code, r);
  }
  return { repOfCust: out, users, reps };
}

// ---- the series
const groupCodes = (): Set<string> => new Set((db.prepare('SELECT code, name FROM intel_cust').all() as { code: string; name: string }[]).filter((c) => GROUPCOS.test(c.name || '')).map((c) => c.code));
export function companySeries(channel: Channel = 'all'): Map<string, number> {
  const byYmCh = new Map<string, { ym: string; ch: number; eur: number }>(); // the month totals without the accounts that are marked "not a customer"
  for (const r of adjustedMonths()) { const k = `${r.ym}|${r.ch}`; const o = byYmCh.get(k) ?? { ym: r.ym, ch: r.ch, eur: 0 }; o.eur += r.eur; byYmCh.set(k, o); }
  const rows = [...byYmCh.values()];
  const m = new Map<string, number>();
  for (const r of rows) { if (r.ch >= 10) continue; if (channel === 'export' && r.ch !== 0) continue; if (channel === 'domestic' && r.ch !== 1) continue; m.set(r.ym, (m.get(r.ym) ?? 0) + r.eur); }
  return m;
}
export function repSeries(channel: Channel = 'all'): { byRep: Map<string, Map<string, number>>; unassigned: Map<string, number>; res: ReturnType<typeof repResolver> } {
  const res = repResolver(); const grp = groupCodes();
  const byRep = new Map<string, Map<string, number>>(), un = new Map<string, number>();
  const rows = db.prepare("SELECT period, customer, SUM(eur) eur FROM intel_fact WHERE period NOT LIKE '%-00' AND customer NOT IN (SELECT code FROM intel_excluded) GROUP BY period, customer").all() as { period: string; customer: string; eur: number }[];
  for (const r of rows) {
    if (grp.has(r.customer)) continue;
    if (channel === 'export' && !r.customer.startsWith('1202')) continue;
    if (channel === 'domestic' && !r.customer.startsWith('1201')) continue;
    const rep = res.repOfCust.get(r.customer);
    const tgt = rep ? (byRep.get(rep.key) ?? byRep.set(rep.key, new Map()).get(rep.key)!) : un;
    tgt.set(r.period, (tgt.get(r.period) ?? 0) + r.eur);
  }
  return { byRep, unassigned: un, res };
}

// ---- the forecast of the system: only the months BEFORE the month are used (so a past month is judged honestly)
const avg = (a: number[]) => (a.length ? a.reduce((s, v) => s + v, 0) / a.length : 0);
export function sysForecast(series: Map<string, number>, ym: string): number | null {
  const have = [...series.keys()].filter((k) => k < ym);
  if (have.length < 6) return null;
  const v = (k: number) => series.get(shiftYm(ym, -k)) ?? 0;
  const l3 = avg([1, 2, 3].map(v)), l12 = avg(Array.from({ length: 12 }, (_, i) => v(i + 1)));
  const parts = [l3, l12];
  const ly = series.get(shiftYm(ym, -12));
  if (ly !== undefined && ly > 0) {
    const a = [1, 2, 3, 4, 5, 6].reduce((s, k) => s + v(k), 0), b = [13, 14, 15, 16, 17, 18].reduce((s, k) => s + v(k), 0);
    const ratio = b > 0 ? Math.min(1.5, Math.max(0.6, a / b)) : 1;
    parts.push(ly * ratio);
  }
  return Math.max(0, avg(parts));
}

// share of a month that is usually invoiced by each day (the last 24 closed months, weighted by revenue)
export function dayCurve(cut: string): number[] {
  const cm = cut.slice(0, 7); const first = shiftYm(cm, -24);
  const grp = groupCodes();
  const tot = new Map<string, number>(); const byDay = new Map<string, number[]>();
  for (const e of db.prepare('SELECT customer, d, eur FROM intel_events WHERE customer NOT IN (SELECT code FROM intel_excluded) AND d >= ? AND d < ?').all(`${first}-01`, `${cm}-01`) as { customer: string; d: string; eur: number }[]) {
    if (grp.has(e.customer)) continue;
    const m = e.d.slice(0, 7), day = +e.d.slice(8, 10);
    tot.set(m, (tot.get(m) ?? 0) + e.eur);
    const a = byDay.get(m) ?? (byDay.set(m, Array(32).fill(0)).get(m)!); a[day] += e.eur;
  }
  const cum = Array(32).fill(0); let sumTot = 0;
  for (const [m, a] of byDay) { const t = tot.get(m) ?? 0; if (t <= 0) continue; sumTot += t; let c = 0; const dim = daysIn(m); for (let d = 1; d <= 31; d++) { c += a[d]; cum[d] += d > dim ? t : c; } }
  return cum.map((v, d) => (d === 0 || sumTot <= 0 ? 0 : Math.min(1, v / sumTot)));
}

// invoiced in the same month of the year before up to the same day of the month (what the month had at this point last year)
function sameDaysLastYear(cm: string, day: number): number {
  const ly = `${+cm.slice(0, 4) - 1}-${cm.slice(5, 7)}`; const grp = groupCodes(); let t = 0;
  for (const e of db.prepare('SELECT customer, d, eur FROM intel_events WHERE customer NOT IN (SELECT code FROM intel_excluded) AND d >= ? AND d <= ?').all(`${ly}-01`, `${ly}-${String(Math.min(day, daysIn(ly))).padStart(2, '0')}`) as { customer: string; d: string; eur: number }[]) if (!grp.has(e.customer)) t += e.eur;
  return t;
}
export interface Exp { point: number; lo: number; hi: number }
// what the month will probably end at, from what is invoiced so far (run rate by the usual shape of a month) and the forecast
export function expectedMonth(actual: number, fc: number | null, day: number, days: number, curve: number[], finished: boolean, spread: { lo: number; hi: number }): Exp {
  if (finished) return { point: actual, lo: actual, hi: actual };
  const s = curve[Math.min(day, 31)] || 0;
  const run = s > 0.08 ? actual / s : null;
  let point: number;
  if (run !== null && fc !== null) { const w = Math.min(0.85, Math.max(0.15, s)); point = w * run + (1 - w) * fc; }
  else point = run ?? fc ?? actual;
  point = Math.max(actual, point);
  return { point, lo: Math.max(actual, point * spread.lo), hi: Math.max(point, point * spread.hi) };
}
// how wrong the estimate of the month was at the same day of the month in the past (the 10th and 90th percentile of actual / estimate)
export function monthSpread(series: Map<string, number>, cut: string, day: number, curve: number[], events: Map<string, number[]>): { lo: number; hi: number; n: number } {
  const cm = cut.slice(0, 7); const ratios: number[] = [];
  for (let k = 1; k <= 18; k++) {
    const m = shiftYm(cm, -k); const fin = series.get(m); if (!fin || fin <= 0) continue;
    const fc = sysForecast(series, m); const ev = events.get(m); if (!ev) continue;
    let a = 0; for (let d = 1; d <= Math.min(day, daysIn(m)); d++) a += ev[d] ?? 0;
    const e = expectedMonth(a, fc, day, daysIn(m), curve, false, { lo: 1, hi: 1 });
    if (e.point > 0) ratios.push(fin / e.point);
  }
  if (ratios.length < 4) return { lo: 0.75, hi: 1.3, n: ratios.length };
  ratios.sort((a, b) => a - b);
  const q = (p: number) => ratios[Math.min(ratios.length - 1, Math.max(0, Math.round(p * (ratios.length - 1))))];
  return { lo: Math.min(1, q(0.1)), hi: Math.max(1, q(0.9)), n: ratios.length };
}
export function eventsByMonth(cut: string): Map<string, number[]> {
  const grp = groupCodes(); const out = new Map<string, number[]>();
  for (const e of db.prepare('SELECT customer, d, eur FROM intel_events WHERE customer NOT IN (SELECT code FROM intel_excluded) AND d >= ?').all(`${shiftYm(cut.slice(0, 7), -19)}-01`) as { customer: string; d: string; eur: number }[]) {
    if (grp.has(e.customer)) continue;
    const m = e.d.slice(0, 7); const a = out.get(m) ?? (out.set(m, Array(32).fill(0)).get(m)!); a[+e.d.slice(8, 10)] += e.eur;
  }
  return out;
}

// ---- targets
export interface TargetVal { amount: number | null; src: 'set' | 'derived' | 'none' }
const tget = (period: string, userId: number): number | null => { const r = db.prepare('SELECT amount_eur a FROM sales_targets WHERE period = ? AND user_id = ?').get(period, userId) as { a: number } | undefined; return r ? r.a : null; };
// a month without its own target takes its share of the yearly target (by how the last years' months were: the shape of the year)
export function monthTarget(ym: string, userId: number, series: Map<string, number>): TargetVal {
  const own = tget(ym, userId); if (own !== null) return { amount: own, src: 'set' };
  const yr = tget(ym.slice(0, 4), userId); if (yr === null) return { amount: null, src: 'none' };
  const y = +ym.slice(0, 4); let sh = 0, all = 0;
  for (const py of [y - 1, y - 2, y - 3]) { let a = 0, b = 0; for (let m = 1; m <= 12; m++) { const v = series.get(ym2(py, m)) ?? 0; b += v; if (m === +ym.slice(5, 7)) a = v; } if (b > 0) { sh += a / b; all++; } }
  const share = all ? sh / all : 1 / 12;
  // months that have their own target take theirs out first
  let fixed = 0, free = 0; for (let m = 1; m <= 12; m++) { const t = tget(ym2(y, m), userId); if (t !== null) fixed += t; else free++; }
  if (free === 0) return { amount: null, src: 'none' };
  return { amount: Math.max(0, yr - fixed) * (all ? share / sharesOfFree(y, userId, series, all) : 1 / free), src: 'derived' };
}
// the shares of the months that have no target of their own add up to the whole of what is left
function sharesOfFree(y: number, userId: number, series: Map<string, number>, _all: number): number {
  let tot = 0;
  for (let m = 1; m <= 12; m++) { if (tget(ym2(y, m), userId) !== null) continue; let sh = 0, n = 0; for (const py of [y - 1, y - 2, y - 3]) { let b = 0, a = 0; for (let mm = 1; mm <= 12; mm++) { const v = series.get(ym2(py, mm)) ?? 0; b += v; if (mm === m) a = v; } if (b > 0) { sh += a / b; n++; } } tot += n ? sh / n : 1 / 12; }
  return tot || 1;
}
export function yearTarget(year: number, userId: number, series: Map<string, number>): TargetVal {
  const yr = tget(String(year), userId); if (yr !== null) return { amount: yr, src: 'set' };
  let sum = 0, n = 0; for (let m = 1; m <= 12; m++) { const t = tget(ym2(year, m), userId); if (t !== null) { sum += t; n++; } }
  return n === 12 ? { amount: sum, src: 'derived' } : { amount: null, src: 'none' }; // a year is only a target when it is given, or all twelve months are
}
export function setTarget(period: string, userId: number, amount: number | null, by: number): void {
  if (!/^\d{4}(-\d{2})?$/.test(period)) throw new Error('The period must be a year (2027) or a month (2027-03).');
  const before = tget(period, userId);
  if (amount === null || !Number.isFinite(amount) || amount <= 0) db.prepare('DELETE FROM sales_targets WHERE period = ? AND user_id = ?').run(period, userId);
  else db.prepare("INSERT INTO sales_targets (period, user_id, amount_eur, set_by, updated_at) VALUES (?, ?, ?, ?, datetime('now')) ON CONFLICT(period, user_id) DO UPDATE SET amount_eur = excluded.amount_eur, set_by = excluded.set_by, updated_at = excluded.updated_at").run(period, userId, amount, by);
  const after = amount !== null && Number.isFinite(amount) && amount > 0 ? amount : null;
  if (before !== after) db.prepare('INSERT INTO sales_targets_log (period, user_id, before_eur, after_eur, by_user) VALUES (?, ?, ?, ?, ?)').run(period, userId, before, after, by);
}

// ---- the forecast of a sales person
export interface RepFc { amount: number; note: string | null; first_at: string; updated_at: string }
export function repForecast(userId: number, ym: string): RepFc | null { return (db.prepare('SELECT amount_eur amount, note, first_at, updated_at FROM sales_forecasts WHERE user_id = ? AND ym = ?').get(userId, ym) as unknown as RepFc | undefined) ?? null; }
export function canEditForecast(ym: string, cut: string, admin: boolean): boolean {
  if (admin) return true;
  const cm = cut.slice(0, 7);
  if (ym > cm) return true;                              // a coming month can be planned
  if (ym < cm) return false;                             // a past month is closed
  return +cut.slice(8, 10) <= FORECAST_GRACE_DAY;        // the month in progress: until the grace day
}
export function saveForecast(userId: number, ym: string, amount: number | null, note: string, by: number): void {
  if (!/^\d{4}-\d{2}$/.test(ym)) throw new Error('Choose a month.');
  if (amount === null) { db.prepare('DELETE FROM sales_forecasts WHERE user_id = ? AND ym = ?').run(userId, ym); db.prepare('INSERT INTO sales_forecasts_log (user_id, ym, amount_eur, note, by_user) VALUES (?, ?, 0, ?, ?)').run(userId, ym, 'removed', by); return; }
  if (!Number.isFinite(amount) || amount < 0) throw new Error('Type the amount in euro.');
  db.prepare("INSERT INTO sales_forecasts (user_id, ym, amount_eur, note, updated_at) VALUES (?, ?, ?, ?, datetime('now')) ON CONFLICT(user_id, ym) DO UPDATE SET amount_eur = excluded.amount_eur, note = excluded.note, updated_at = excluded.updated_at").run(userId, ym, amount, note || null);
  db.prepare('INSERT INTO sales_forecasts_log (user_id, ym, amount_eur, note, by_user) VALUES (?, ?, ?, ?, ?)').run(userId, ym, amount, note || null, by);
}

// ---- the whole screen
export interface RepLine {
  key: string; userId: number | null; name: string; target: number | null; targetSrc: string; actual: number; expected: Exp; gap: number | null; sys: number | null;
  forecast: RepFc | null; canEdit: boolean; l12: number;
}
export interface Overview {
  ready: boolean; message?: string; cut: string; ym: string; day: number; days: number; elapsed: number; finished: boolean; dataAgeDays: number; channel: Channel;
  scope: 'all' | 'own';
  openOrders: null | { dueThisMonth: number; pastDue: number; lines: number };
  company: null | { target: TargetVal; actual: number; expected: Exp; gap: number | null; toGo: number | null; sys: number | null; repForecasts: number; pace: number | null };
  year: null | { year: number; target: TargetVal; ytd: number; expected: Exp; variance: number | null; toGo: number | null; monthsSet: number; lastYear: number; lastYtd: number };
  reps: RepLine[]; allocated: number; unassignedActual: number; unallocated: number | null;
  months: { ym: string; target: number | null; actual: number; expected: number | null; sys: number | null }[];
  history: { ym: string; target: number | null; sys: number | null; reps: number | null; actual: number; repCount: number }[];
  accuracy: { system: { wape: number | null; bias: number | null; n: number }; byRep: { key: string; name: string; n: number; repErr: number | null; sysErr: number | null }[] };
  spread: { lo: number; hi: number; n: number };
  graceDay: number;
}

export function overview(opts: { ym?: string; channel: Channel; viewer: { id: number; admin: boolean; seeAll: boolean; name: string } }): Overview {
  const cut = dataCut();
  const base = { cut: cut ?? '', channel: opts.channel, graceDay: FORECAST_GRACE_DAY };
  if (!cut) return { ready: false, message: 'There is no sales data yet. An admin opens Sales intelligence and loads the history.', ym: '', day: 0, days: 0, elapsed: 0, finished: false, dataAgeDays: 0, scope: 'own', openOrders: null, company: null, year: null, reps: [], allocated: 0, unassignedActual: 0, unallocated: null, months: [], history: [], accuracy: { system: { wape: null, bias: null, n: 0 }, byRep: [] }, spread: { lo: 0.75, hi: 1.3, n: 0 }, ...base };
  const cm = cut.slice(0, 7);
  const ym = opts.ym && /^\d{4}-\d{2}$/.test(opts.ym) ? opts.ym : cm;
  const year = +ym.slice(0, 4);
  const series = companySeries(opts.channel);
  const { byRep, unassigned, res } = repSeries(opts.channel);
  const curve = dayCurve(cut); const ev = eventsByMonth(cut);
  const isCur = ym === cm, past = ym < cm, future = ym > cm;
  const day = isCur ? +cut.slice(8, 10) : past ? daysIn(ym) : 0, days = daysIn(ym);
  const cutDay = +cut.slice(8, 10);
  const spread = monthSpread(series, cut, Math.max(1, cutDay), curve, ev);
  const today = new Date().toISOString().slice(0, 10);
  const dataAgeDays = Math.max(0, Math.round((Date.UTC(+today.slice(0, 4), +today.slice(5, 7) - 1, +today.slice(8, 10)) - Date.UTC(+cut.slice(0, 4), +cut.slice(5, 7) - 1, +cut.slice(8, 10))) / 864e5));
  const expMonth = (s: Map<string, number>, m: string): { actual: number; sys: number | null; e: Exp } => {
    const actual = s.get(m) ?? 0; const sys = sysForecast(s, m);
    const mIsCur = m === cm, mPast = m < cm;
    const e = mPast ? { point: actual, lo: actual, hi: actual } : m > cm ? { point: sys ?? 0, lo: (sys ?? 0) * spread.lo, hi: (sys ?? 0) * spread.hi } : expectedMonth(actual, sys, cutDay, daysIn(m), curve, false, spread);
    void mIsCur; return { actual, sys, e };
  };

  // reps shown: a person with a target, a forecast or any invoice in the last 12 months
  const l12Of = (m: Map<string, number>) => { let t = 0; for (let k = 1; k <= 12; k++) t += m.get(shiftYm(cm, -k)) ?? 0; return t; };
  const repKeys = new Map<string, Rep>();
  for (const [k, m] of byRep) { const r = res.reps.get(k); if (r && l12Of(m) > 0) repKeys.set(k, r); }
  for (const r of db.prepare('SELECT DISTINCT user_id FROM sales_targets WHERE user_id > 0 UNION SELECT DISTINCT user_id FROM sales_forecasts').all() as { user_id: number }[]) {
    const u = db.prepare('SELECT id, display_name FROM users WHERE id = ?').get(r.user_id) as { id: number; display_name: string } | undefined;
    if (u) { const k = normName(u.display_name); repKeys.set(k, { key: k, userId: u.id, name: u.display_name }); }
  }
  const lines: RepLine[] = [];
  for (const [k, r] of repKeys) {
    const s = byRep.get(k) ?? new Map<string, number>();
    const { actual, sys, e } = expMonth(s, ym);
    const t: TargetVal = r.userId ? monthTarget(ym, r.userId, s) : { amount: null, src: 'none' };
    const f = r.userId ? repForecast(r.userId, ym) : null;
    lines.push({ key: k, userId: r.userId, name: r.name, target: t.amount === null ? null : r0(t.amount), targetSrc: t.src, actual: r0(actual), expected: { point: r0(e.point), lo: r0(e.lo), hi: r0(e.hi) }, gap: t.amount === null ? null : r0(t.amount - actual), sys: sys === null ? null : r0(sys), forecast: f, canEdit: !!r.userId && (opts.viewer.admin || opts.viewer.id === r.userId) && canEditForecast(ym, cut, opts.viewer.admin), l12: r0(l12Of(s)) });
  }
  lines.sort((a, b) => b.l12 - a.l12 || a.name.localeCompare(b.name));
  const mine = lines.filter((l) => l.userId === opts.viewer.id);
  const shown = opts.viewer.seeAll ? lines : mine;

  // the company
  const cAct = expMonth(series, ym);
  const cT = monthTarget(ym, 0, series);
  const repFcSum = (db.prepare('SELECT SUM(amount_eur) s FROM sales_forecasts WHERE ym = ?').get(ym) as { s: number | null }).s ?? 0;
  const allocated = lines.reduce((s, l) => s + (l.target ?? 0), 0);
  const unAct = unassigned.get(ym) ?? 0;
  // what is still to be delivered (ZSD0013, export): orders whose delivery date is this month, and orders already past it - invoices that are waiting to happen
  const oo = db.prepare("SELECT SUM(CASE WHEN substr(delivery_date, 1, 7) = ? THEN value_eur ELSE 0 END) due, SUM(CASE WHEN delivery_date < ? THEN value_eur ELSE 0 END) past, COUNT(*) n FROM export_production_backlog WHERE delivery_date IS NOT NULL AND delivery_date <> ''").get(ym, ym + '-01') as { due: number | null; past: number | null; n: number };
  const openOrders = opts.viewer.seeAll && oo.n > 0 ? { dueThisMonth: r0(oo.due ?? 0), pastDue: r0(oo.past ?? 0), lines: oo.n } : null;
  const company = opts.viewer.seeAll ? {
    target: { amount: cT.amount === null ? null : r0(cT.amount), src: cT.src }, actual: r0(cAct.actual), expected: { point: r0(cAct.e.point), lo: r0(cAct.e.lo), hi: r0(cAct.e.hi) },
    gap: cT.amount === null ? null : r0(cT.amount - cAct.actual), toGo: cT.amount === null ? null : r0(Math.max(0, cT.amount - cAct.actual)), sys: cAct.sys === null ? null : r0(cAct.sys), repForecasts: r0(repFcSum),
    pace: cT.amount && !future ? cAct.actual / cT.amount : null,
  } : null;

  // the year: what is invoiced in the months of the year so far + what is expected for the rest
  const yT = yearTarget(year, 0, series);
  let ytd = 0; for (let m = 1; m <= 12; m++) { const k = ym2(year, m); if (k <= cm) ytd += series.get(k) ?? 0; }
  const sim = new Map(series); let yearPoint = ytd, yLo = ytd, yHi = ytd;
  const curE = year === +cm.slice(0, 4) ? expectedMonth(series.get(cm) ?? 0, sysForecast(series, cm), cutDay, daysIn(cm), curve, false, spread) : null;
  if (curE) { yearPoint += curE.point - (series.get(cm) ?? 0); yLo += curE.lo - (series.get(cm) ?? 0); yHi += curE.hi - (series.get(cm) ?? 0); sim.set(cm, curE.point); }
  for (let m = 1; m <= 12; m++) { const k = ym2(year, m); if (k <= cm || year > +cm.slice(0, 4) + 1) continue; const f = sysForecast(sim, k) ?? 0; sim.set(k, f); yearPoint += f; yLo += f * 0.9; yHi += f * 1.1; }
  if (year > +cm.slice(0, 4)) { yearPoint = 0; for (let m = 1; m <= 12; m++) { const k = ym2(year, m); const f = sysForecast(sim, k) ?? 0; sim.set(k, f); yearPoint += f; } yLo = yearPoint * 0.85; yHi = yearPoint * 1.15; }
  let monthsSet = 0; for (let m = 1; m <= 12; m++) if (tget(ym2(year, m), 0) !== null) monthsSet++;
  let lastYear = 0, lastYtd = 0; for (let m = 1; m <= 12; m++) { const v = series.get(ym2(year - 1, m)) ?? 0; lastYear += v; if (ym2(year, m) < cm || (ym2(year, m) <= cm && year !== +cm.slice(0, 4))) lastYtd += v; }
  if (year === +cm.slice(0, 4)) lastYtd += sameDaysLastYear(cm, cutDay);
  const yearBlock = opts.viewer.seeAll ? {
    year, target: { amount: yT.amount === null ? null : r0(yT.amount), src: yT.src }, ytd: r0(ytd), expected: { point: r0(yearPoint), lo: r0(yLo), hi: r0(yHi) },
    variance: yT.amount === null ? null : r0(yearPoint - yT.amount), toGo: yT.amount === null ? null : r0(Math.max(0, yT.amount - ytd)), monthsSet, lastYear: r0(lastYear), lastYtd: r0(lastYtd),
  } : null;

  // the twelve months of the year
  const months = [];
  for (let m = 1; m <= 12; m++) {
    const k = ym2(year, m); const s2 = opts.viewer.seeAll ? series : (mine[0] ? byRep.get(mine[0].key) ?? new Map() : new Map());
    const t = opts.viewer.seeAll ? monthTarget(k, 0, series) : (mine[0]?.userId ? monthTarget(k, mine[0].userId, s2) : { amount: null, src: 'none' as const });
    const e = k < cm ? null : k === cm ? expMonth(s2, k).e.point : sysForecast(sim.size && opts.viewer.seeAll ? sim : s2, k);
    months.push({ ym: k, target: t.amount === null ? null : r0(t.amount), actual: r0(s2.get(k) ?? 0), expected: e === null ? null : r0(e), sys: sysForecast(s2, k) === null ? null : r0(sysForecast(s2, k)!) });
  }

  // the last 12 closed months: target, the system's forecast, the people's forecasts, the actual (the accuracy of each)
  const history: Overview['history'] = [];
  const repAcc = new Map<string, { name: string; n: number; re: number; se: number }>();
  let wSum = 0, aSum = 0, bSum = 0, wn = 0;
  for (let k = 12; k >= 1; k--) {
    const m = shiftYm(cm, -k); const a = series.get(m);
    if (a === undefined) continue;
    const sys = sysForecast(series, m);
    if (sys !== null) { wSum += Math.abs(a - sys); aSum += a; bSum += sys - a; wn++; }
    const fcs = db.prepare('SELECT user_id, amount_eur FROM sales_forecasts WHERE ym = ?').all(m) as { user_id: number; amount_eur: number }[];
    const t = monthTarget(m, 0, series);
    history.push({ ym: m, target: t.amount === null ? null : r0(t.amount), sys: sys === null ? null : r0(sys), reps: fcs.length ? r0(fcs.reduce((s, f) => s + f.amount_eur, 0)) : null, actual: r0(a), repCount: fcs.length });
    for (const f of fcs) {
      const rp = [...repKeys.values()].find((r) => r.userId === f.user_id); if (!rp) continue;
      const s = byRep.get(rp.key); const ra = s?.get(m) ?? 0; const rsys = s ? sysForecast(s, m) : null;
      const x = repAcc.get(rp.key) ?? { name: rp.name, n: 0, re: 0, se: 0 };
      const den = Math.max(ra, 1);
      x.n++; x.re += Math.abs(f.amount_eur - ra) / den; if (rsys !== null) x.se += Math.abs(rsys - ra) / den; else x.se += NaN; repAcc.set(rp.key, x);
    }
  }
  const accuracy = {
    system: { wape: aSum > 0 && wn ? wSum / aSum : null, bias: aSum > 0 && wn ? bSum / aSum : null, n: wn },
    byRep: [...repAcc].filter(([k]) => opts.viewer.seeAll || mine[0]?.key === k).map(([key, x]) => ({ key, name: x.name, n: x.n, repErr: x.n ? x.re / x.n : null, sysErr: Number.isNaN(x.se) || !x.n ? null : x.se / x.n })),
  };

  return {
    ready: true, ...base, ym, day, days, elapsed: isCur ? day / days : past ? 1 : 0, finished: past, dataAgeDays, scope: opts.viewer.seeAll ? 'all' : 'own',
    openOrders, company, year: yearBlock, reps: shown, allocated: r0(allocated), unassignedActual: r0(opts.viewer.seeAll ? unAct : 0), unallocated: opts.viewer.seeAll && cT.amount !== null ? r0(cT.amount - allocated) : null,
    months, history: opts.viewer.seeAll ? history : [], accuracy, spread,
  };
}

// a proposal for dividing a target between the sales people: by their share of the last 12 months
export function proposeShares(channel: Channel): { key: string; userId: number | null; name: string; l12: number; share: number }[] {
  const cut = dataCut(); if (!cut) return [];
  const cm = cut.slice(0, 7); const { byRep, res } = repSeries(channel);
  const rows: { key: string; userId: number | null; name: string; l12: number; share: number }[] = [];
  let tot = 0;
  for (const [k, m] of byRep) { const r = res.reps.get(k); if (!r) continue; let t = 0; for (let i = 1; i <= 12; i++) t += m.get(shiftYm(cm, -i)) ?? 0; if (t > 0) { rows.push({ key: k, userId: r.userId, name: r.name, l12: r0(t), share: 0 }); tot += t; } }
  for (const r of rows) r.share = tot > 0 ? r.l12 / tot : 0;
  return rows.sort((a, b) => b.l12 - a.l12);
}
export { monthsRange };
