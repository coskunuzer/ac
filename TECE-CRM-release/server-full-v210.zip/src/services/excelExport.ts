import ExcelJS from 'exceljs';
import type { CardRow } from '../models/cardModel';
import type { Exhibition } from '../models/exhibitionModel';
import { offerLogModel, type OfferEntry } from '../models/pricingModels';
import { FOLLOW_UP_LABEL, followUpFor, groupByCard } from './followUp';
import { interestLabel, widthsLabel } from './interest';
import { offerWanted, parseInsight } from './aiInsight';

type CardColumnKey = keyof CardRow | 'exhibitionName' | 'interestLabel' | 'interestWidths' | 'offerWanted' | 'companyInfo' | 'followUp' | 'offersSent' | 'lastOfferAt' | 'lastOfferPercent' | 'lastOfferCurrency' | 'lastOfferPages' | 'lastOfferFiles';

const COLUMNS: Array<{ header: string; key: CardColumnKey; width: number; format?: string }> = [
  { header: 'Fair', key: 'exhibitionName', width: 22 },
  { header: 'Name', key: 'name', width: 20 },
  { header: 'Company', key: 'company', width: 24 },
  { header: 'Position', key: 'position', width: 22 },
  { header: 'Address', key: 'address', width: 28 },
  { header: 'Country', key: 'country', width: 14 },
  { header: 'Tel', key: 'tel', width: 16 },
  { header: 'Email', key: 'email', width: 24 },
  { header: 'Interested In', key: 'interestLabel', width: 24 },
  { header: 'Edge widths', key: 'interestWidths', width: 12 },
  { header: 'Discount / addition set on scan', key: 'offer_percent', width: 14, format: '+0.0%;-0.0%;0%' },
  { header: 'Work Area', key: 'work_area', width: 20 },
  { header: 'Form Date', key: 'form_date', width: 14 },
  { header: 'Person', key: 'person', width: 16 },
  { header: 'Rate', key: 'rate', width: 8 },
  { header: 'Offer wanted', key: 'offerWanted', width: 14 },
  { header: 'About the company (AI)', key: 'companyInfo', width: 60 },
  { header: 'Notes', key: 'notes', width: 50 },
  { header: 'Status', key: 'status', width: 14 },
  { header: 'Recorded At', key: 'created_at', width: 20 },
  { header: 'What we did', key: 'followUp', width: 16 },
  { header: 'Emails sent', key: 'offersSent', width: 10 },
  { header: 'Last sent (UTC)', key: 'lastOfferAt', width: 18 },
  { header: 'Last offer price change', key: 'lastOfferPercent', width: 14, format: '+0.0%;-0.0%;0%' },
  { header: 'Last offer currency', key: 'lastOfferCurrency', width: 10 },
  { header: 'Last offer pages', key: 'lastOfferPages', width: 40 },
  { header: 'Last documents', key: 'lastOfferFiles', width: 28 },
];

const OFFER_COLUMNS: Array<{ header: string; width: number; format?: string }> = [
  { header: 'Sent at (UTC)', width: 18 },
  { header: 'What was sent', width: 16 },
  { header: 'Fair', width: 22 },
  { header: 'Company', width: 24 },
  { header: 'Name', width: 20 },
  { header: 'Country', width: 14 },
  { header: 'Sent to', width: 26 },
  { header: 'Person on card', width: 16 },
  { header: 'Sent by', width: 16 },
  { header: 'Price increase / decrease', width: 14, format: '+0.0%;-0.0%;0%' },
  { header: 'Currency', width: 9 },
  { header: '1 EUR = USD', width: 10 },
  { header: 'Pages in the offer', width: 46 },
  { header: 'Documents attached', width: 30 },
  { header: 'Subject', width: 34 },
  { header: 'Price list file', width: 30 },
];

const pct = (n: number) => `${n > 0 ? '+' : ''}${Math.round(n * 1000) / 10}%`;

// "PVC (all products, surcharge +5%), ABS, MOQ pages" - the pages that went out.
export function describeOfferPages(o: OfferEntry): string {
  const pages = o.pages.map((p) => {
    const bits = [p.products, p.surcharge ? `surcharge ${pct(p.surcharge)}` : ''].filter(Boolean);
    return bits.length ? `${p.title} (${bits.join(', ')})` : p.title;
  });
  if (o.includeMoq) pages.push('MOQ pages');
  return pages.join(', ');
}

function styleHeader(sheet: ExcelJS.Worksheet) {
  const headerRow = sheet.getRow(1);
  headerRow.font = { bold: true, color: { argb: 'FFFFFFFF' } };
  headerRow.eachCell((cell) => {
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1F3864' } };
  });
  sheet.views = [{ state: 'frozen', ySplit: 1 }];
}

export async function buildCardsWorkbook(
  cards: CardRow[],
  exhibitionsById: Map<number, Exhibition>
): Promise<ExcelJS.Buffer> {
  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet('Cards');

  sheet.columns = COLUMNS.map((c) => ({ header: c.header, key: c.key, width: c.width, style: c.format ? { numFmt: c.format } : undefined }));
  styleHeader(sheet);

  // What was sent to each customer: the newest send per card for the summary
  // columns, every send on its own row in the "Offers sent" sheet.
  const cardIds = new Set(cards.map((c) => c.id));
  const offers = offerLogModel.listForIdSet(cardIds); // newest first
  const byCard = groupByCard(offers);

  for (const card of cards) {
    const sent = byCard.get(card.id) ?? [];
    const follow = followUpFor(card, sent);
    const last = sent.find((e) => e.kind === 'offer') ?? sent[0];
    sheet.addRow({
      ...card,
      exhibitionName: exhibitionsById.get(card.exhibition_id)?.name ?? '',
      interestLabel: interestLabel(card),
      interestWidths: widthsLabel(card),
      offerWanted: card.send_offer === 1 ? 'Yes' : card.send_offer === 0 ? 'No' : offerWanted(card) ? 'Suggested by AI' : '',
      companyInfo: (() => {
        const i = parseInsight(card.ai_insight);
        return i ? [i.companyType, i.companyProfile, i.websiteSummary ? `Web site: ${i.websiteSummary}` : ''].filter(Boolean).join(' - ') : '';
      })(),
      followUp: follow.label,
      offersSent: follow.count || '',
      lastOfferAt: follow.at?.slice(0, 16) ?? '',
      lastOfferPercent: last?.kind === 'offer' ? last.percent ?? '' : '',
      lastOfferCurrency: last?.kind === 'offer' ? last.currency ?? '' : '',
      lastOfferPages: last?.kind === 'offer' ? describeOfferPages(last) : '',
      lastOfferFiles: last?.attachments.join(', ') ?? '',
    });
  }
  sheet.autoFilter = { from: { row: 1, column: 1 }, to: { row: 1, column: COLUMNS.length } };

  const offerSheet = workbook.addWorksheet('Sent log');
  offerSheet.columns = OFFER_COLUMNS.map((c) => ({ header: c.header, width: c.width, style: c.format ? { numFmt: c.format } : undefined }));
  styleHeader(offerSheet);
  const cardsById = new Map(cards.map((c) => [c.id, c]));
  for (const o of [...offers].reverse()) {
    const card = cardsById.get(o.cardId)!;
    offerSheet.addRow([
      o.sentAt.slice(0, 16),
      o.kind === 'offer' ? 'Price offer' : o.kind === 'documents' ? 'Documents' : o.kind === 'personal' ? 'Personal e-mail' : 'Thank-you note',
      exhibitionsById.get(card.exhibition_id)?.name ?? '',
      card.company ?? '',
      card.name ?? '',
      card.country ?? '',
      o.sentTo ?? card.email ?? '',
      card.person ?? '',
      o.sentBy ?? '',
      o.percent ?? '',
      o.currency ?? '',
      o.usdRate ?? '',
      describeOfferPages(o),
      o.attachments.join(', '),
      o.subject ?? '',
      o.priceList ?? '',
    ]);
  }
  offerSheet.autoFilter = { from: { row: 1, column: 1 }, to: { row: 1, column: OFFER_COLUMNS.length } };

  return workbook.xlsx.writeBuffer();
}
