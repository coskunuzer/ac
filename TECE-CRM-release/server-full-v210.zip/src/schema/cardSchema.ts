import { COUNTRY_NAMES } from '../data/countries';
import type { AiInsight } from '../services/aiInsight';
import { INSIGHT_SCHEMA } from '../services/aiInsight';

export type FieldStatus = 'found' | 'uncertain' | 'not_found';

export interface ExtractedCardFields {
  name: string | null;
  company: string | null;
  address: string | null;
  country: string | null;
  tel: string | null;
  email: string | null;
  position: string | null;
  interestedIn: string | null;
  workArea: string | null;
  date: string | null;
  person: string | null;
  rate: number | null;
  notes: string | null;
}

export type FieldStatusMap = Record<keyof ExtractedCardFields, FieldStatus>;

export interface CardExtractionResult {
  fields: ExtractedCardFields;
  fieldStatus: FieldStatusMap;
  // read together with the form: what the notes ask us to do
  insight?: AiInsight | null;
}

// Gemini's structured-output schema is an OpenAPI-3.0-subset dialect, not
// plain JSON Schema: uppercase type names, `nullable: true` instead of a
// `type: [x, 'null']` union, and no `additionalProperties` support at all
// (including it risks a 400 from the API).
function fieldProps(personEnum: string[]) {
  return {
    name: { type: 'STRING', nullable: true, description: 'Visitor full name, prefer the stapled business card over the printed form grid. If several business cards are attached, the FIRST card\'s person only.' },
    company: { type: 'STRING', nullable: true, description: 'Company name, prefer the stapled business card. If several cards are attached, the first card\'s company.' },
    address: { type: 'STRING', nullable: true, description: 'Company address, prefer the stapled business card. If several cards are attached, the first card\'s address.' },
    // No `enum` constraint here (unlike `person` below) - a ~195-entry enum
    // (the full country list) makes this model reject the whole request
    // with a bare "Request contains an invalid argument" (confirmed via
    // direct API testing: every other field works, only `country` with its
    // full enum fails). The frontend dropdown already limits what a human
    // can pick, and applySanityChecks() in aiExtraction.ts already flags
    // the AI's answer as "uncertain" if it doesn't exactly match
    // COUNTRY_NAMES, so free-text here is a safe fallback, not a real gap.
    country: {
      type: 'STRING',
      nullable: true,
      description: 'Country, spelled out in full English (e.g. "Turkey", "United States"). Null if not present on the form.',
    },
    tel: {
      type: 'STRING',
      nullable: true,
      description:
        'Phone number. If several business cards are attached, the phone numbers from ALL of them, separated by "; " (first card\'s number first).',
    },
    email: {
      type: 'STRING',
      nullable: true,
      description:
        'Email address. If several business cards are attached, the email addresses from ALL of them, separated by ", " (first card\'s address first). Only real addresses, no other text.',
    },
    position: { type: 'STRING', nullable: true, description: 'The visitor\'s job title / position in English or as printed on the business card (for example "Purchasing Manager", "Owner"). Null if not shown.' },
    interestedIn: { type: 'STRING', nullable: true, description: 'Contents of the printed "Interested in:" box.' },
    workArea: { type: 'STRING', nullable: true, description: 'Contents of the printed "Work Area:" box.' },
    date: { type: 'STRING', nullable: true, description: 'Contents of the footer "Date:" field.' },
    person: personEnum.length
      ? {
          type: 'STRING',
          nullable: true,
          enum: personEnum,
          description:
            'The staff member named in the footer "Person:" field, matched to the closest entry in the allowed list (the handwriting is often just a first name or nickname, e.g. "Abdullah" for "Abdullah Coskunuzer" - match it to the closest full name). Null if no reasonable match.',
        }
      : {
          type: 'STRING',
          nullable: true,
          description: 'The staff member named in the footer "Person:" field.',
        },
    rate: { type: 'INTEGER', nullable: true, description: 'The numeric rating out of 10 from the footer "Rate:" field, e.g. "3/10" -> 3. Just the number, not the denominator.' },
    notes: {
      type: 'STRING',
      nullable: true,
      description:
        'Full verbatim transcription of the handwritten free-text notes, in the original language (do NOT translate). If a SECOND (or third) business card is attached, add after the handwritten notes a new line "Second business card: <everything printed on it - name, job title, company, address, phones, emails, website>" (and "Third business card: ..." likewise).',
    },
  } as const;
}

const FIELD_KEYS = [
  'name', 'company', 'address', 'country', 'tel', 'email', 'position', 'interestedIn',
  'workArea', 'date', 'person', 'rate', 'notes',
] as const;

const FIELD_STATUS_PROPS = Object.fromEntries(
  FIELD_KEYS.map((key) => [key, { type: 'STRING', enum: ['found', 'uncertain', 'not_found'] }])
);

export function buildCardJsonSchema(personEnum: string[], withInsight = true) {
  return {
    type: 'OBJECT',
    properties: {
      ...(withInsight ? { insight: INSIGHT_SCHEMA } : {}),
      fields: {
        type: 'OBJECT',
        properties: fieldProps(personEnum),
        required: [...FIELD_KEYS],
      },
      fieldStatus: {
        type: 'OBJECT',
        description:
          'For each field, "found" if clearly read from the image, "uncertain" if partially legible or a best guess, "not_found" if blank on the form or fully illegible. Never guess a value and mark it "found" - if unsure, use "uncertain".',
        properties: FIELD_STATUS_PROPS,
        required: [...FIELD_KEYS],
      },
    },
    required: withInsight ? ['fields', 'fieldStatus', 'insight'] : ['fields', 'fieldStatus'],
  } as const;
}
