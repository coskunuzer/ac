import { db } from '../db/connection';

export type TemplateKind = 'thank_you' | 'offer';

export interface EmailTemplateRow {
  id: number;
  kind: TemplateKind;
  name: string;
  subject: string;
  body: string;
  is_default: number;
  created_at: string;
}

export const TEXT_LANGUAGES = ['ru', 'tr', 'es', 'fr'] as const;
export type TextLanguage = (typeof TEXT_LANGUAGES)[number];
export const isTextLanguage = (v: unknown): v is TextLanguage => typeof v === 'string' && (TEXT_LANGUAGES as readonly string[]).includes(v);

export interface TemplateTranslation { lang: TextLanguage; subject: string; body: string }

export const emailTemplateModel = {
  // the same text written in another language (the text itself is the English one)
  translations(templateId: number): TemplateTranslation[] {
    return db.prepare('SELECT lang, subject, body FROM email_template_translations WHERE template_id = ? ORDER BY lang').all(templateId) as unknown as TemplateTranslation[];
  },

  translation(templateId: number, lang: string): TemplateTranslation | undefined {
    return db.prepare('SELECT lang, subject, body FROM email_template_translations WHERE template_id = ? AND lang = ?').get(templateId, lang) as TemplateTranslation | undefined;
  },

  setTranslation(templateId: number, lang: TextLanguage, subject: string, body: string): void {
    db.prepare(
      'INSERT INTO email_template_translations (template_id, lang, subject, body) VALUES (?, ?, ?, ?) ON CONFLICT(template_id, lang) DO UPDATE SET subject = excluded.subject, body = excluded.body'
    ).run(templateId, lang, subject, body);
  },

  deleteTranslation(templateId: number, lang: string): void {
    db.prepare('DELETE FROM email_template_translations WHERE template_id = ? AND lang = ?').run(templateId, lang);
  },

  list(kind?: TemplateKind): EmailTemplateRow[] {
    return (kind
      ? db.prepare('SELECT * FROM email_templates WHERE kind = ? ORDER BY is_default DESC, name').all(kind)
      : db.prepare('SELECT * FROM email_templates ORDER BY kind, is_default DESC, name').all()) as unknown as EmailTemplateRow[];
  },

  find(id: number): EmailTemplateRow | undefined {
    return db.prepare('SELECT * FROM email_templates WHERE id = ?').get(id) as EmailTemplateRow | undefined;
  },

  defaultFor(kind: TemplateKind): EmailTemplateRow | undefined {
    return (db.prepare('SELECT * FROM email_templates WHERE kind = ? AND is_default = 1 LIMIT 1').get(kind) ??
      db.prepare('SELECT * FROM email_templates WHERE kind = ? ORDER BY id LIMIT 1').get(kind)) as EmailTemplateRow | undefined;
  },

  create(input: { kind: TemplateKind; name: string; subject: string; body: string }): EmailTemplateRow {
    const first = !this.defaultFor(input.kind);
    const r = db
      .prepare('INSERT INTO email_templates (kind, name, subject, body, is_default) VALUES (?, ?, ?, ?, ?)')
      .run(input.kind, input.name, input.subject, input.body, first ? 1 : 0);
    return this.find(r.lastInsertRowid as number)!;
  },

  update(id: number, input: { name: string; subject: string; body: string }): EmailTemplateRow | undefined {
    db.prepare('UPDATE email_templates SET name = ?, subject = ?, body = ? WHERE id = ?').run(input.name, input.subject, input.body, id);
    return this.find(id);
  },

  setDefault(id: number): void {
    const t = this.find(id);
    if (!t) return;
    db.prepare('UPDATE email_templates SET is_default = 0 WHERE kind = ?').run(t.kind);
    db.prepare('UPDATE email_templates SET is_default = 1 WHERE id = ?').run(id);
  },

  // The default can't be deleted while it is the only one of its kind.
  delete(id: number): boolean {
    const t = this.find(id);
    if (!t) return false;
    if (this.list(t.kind).length <= 1) return false;
    db.prepare('DELETE FROM email_template_translations WHERE template_id = ?').run(id);
    db.prepare('DELETE FROM email_templates WHERE id = ?').run(id);
    if (t.is_default) {
      const next = this.list(t.kind)[0];
      if (next) this.setDefault(next.id);
    }
    return true;
  },
};
