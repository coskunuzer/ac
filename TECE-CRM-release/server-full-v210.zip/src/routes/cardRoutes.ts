import fs from 'fs';
import { moveToJunk } from '../services/junk';
import { ownPrices } from '../services/offerOverrides';
import type { PriceBook } from '../services/priceBook';
import { offerMemoryFor } from '../services/pricingAnalysis';
import path from 'path';
import archiver from 'archiver';
import { Router, type Response } from 'express';
import { upload } from '../middleware/upload';
import { requireAuth, requireAdmin, type AuthedRequest } from '../middleware/auth';
import { cardModel, STAGES, type CardRow } from '../models/cardModel';
import { extractCardFromImage } from '../services/aiExtraction';
import { MailBlockedError, mailProblems } from '../services/emailSafety';
import { adviseEmailKind } from '../services/emailKind';
import { interpolateTemplate, resolveOfferTemplate, resolveTemplate, sendThankYouEmail, templateChoices, type EmailAttachment } from '../services/thankYouEmail';
import { userModel } from '../models/userModel';
import { exhibitionModel } from '../models/exhibitionModel';
import { sanitizeHtml, htmlToPlain } from '../services/sanitizeHtml';
import { libraryModel, offerLogModel, type OfferSummary } from '../models/pricingModels';
import { paths } from '../config/env';
import { activePriceBook } from '../services/priceBook/store';
import { priceMarketFor } from '../services/priceMarket';
import { sanitiseOffer } from '../services/offerRequest';
import { renderDocumentPdf, renderOfferPdf } from '../services/offerPdf';
import { recommend } from '../services/offerRecommend';
import { applyCountryDefaults } from '../services/countryAssignment';
import { followUpFor, groupByCard } from '../services/followUp';
import { splitEmails } from '../services/emailAddresses';
import { compressScan } from '../services/scanImage';
import { absoluteFolder, listCustomerFiles, removeCustomerFolder, resolveCustomerFile, saveOfferPdf, syncCustomerFolder } from '../services/customerFiles';
import { buildCardsWorkbook } from '../services/excelExport';
import { guessWebsite, lookupWebsite } from '../services/websiteLookup';
import { buildSignature, styleFor } from '../services/signature';
import { INTEREST_PRODUCTS, detectInterest, interestOf } from '../services/interest';
import { analyseCard, bulgariaWanted, offerWanted, parseInsight, ruleInsight, type AiInsight } from '../services/aiInsight';
import { aiAllowance, needAi, useAi } from '../services/aiBudget';
import { SQL_CLEANABLE, SQL_EXHIBITION, SQL_RATING, SQL_VERDICT } from '../models/cardModel';
import { enrichCompany } from '../services/companyEnrich';
import { countryKey, countryModel } from '../models/countryModel';
import { accessOf, canSeeCard, myCityKeys, myCountryKeys, visibilitySql } from '../services/visibility';
import { numericOf, placeOf } from '../services/geo';
import { isoOf } from '../services/phone';
import { canonicalCountry } from '../models/countryModel';
import { COUNTRY_NAMES } from '../data/countries';
import { cityModel, cityKey } from '../models/cityModel';
import { guessCityFromAddress, resolveCity } from '../data/turkeyPlaces';
import { exhibitionModel as exhibitions } from '../models/exhibitionModel';
import { asMarket } from '../models/userModel';
import { db } from '../db/connection';
import { cleanRoles, recipientsFor, rolesOf } from '../services/contactRoles';
import { distributorModel } from '../models/distributorModel';
import { settingsModel } from '../models/settingsModel';
import { activityModel, HUMAN_TYPES, type ActivityType } from '../models/activityModel';
import multer from 'multer';
import { smartFill } from '../services/smartFill';
import { summariseChat } from '../services/logChat';
import { companyKey } from '../services/companyKey';
import { audit, auditDiff } from '../services/audit';
import { DISQUALIFY_REASONS, LOST_REASONS, PIPELINE_STAGES, followLegacyStage, healthOf, legacyStage, leadSources } from '../services/pipeline';
import { blackOfCard, holdOfCard } from '../services/perfAnalytics';
import { CARRIERS, SAMPLE_CHOICES, meetingNotesMail, readNotePhotos, sampleMails, sampleRecipients } from '../services/noteAssist';
import { contactModel } from '../models/contactModel';
import { duplicateCount, duplicateGroups, findDuplicates, mergeCards, mergePreview } from '../services/duplicates';
import { rateCards, rateOneWithRules } from '../services/aiRating';
import { latestExports } from '../services/shipExports';
import { ledgerFor } from '../services/ledgerMatch';
import { setsFor } from '../services/perfAnalytics';
import { canDeleteCard, canJunkCard, isProtected, removeCard, startWebsiteSearch, websiteStatus } from '../services/bulkCustomers';
import { languageOf, setLanguageByRule } from '../services/offerLanguage';
import { isLang, translateEmail, type Lang } from '../services/translate';
import { deleteUploadedFile, isUploadable, saveUploadedFile } from '../services/customerFiles';
import { logDiscountChange } from '../services/priceHistory';
import { interestLabel } from '../services/interest';
import { enabledTabs, offerCatalog } from '../services/offerTabs';
import { archivePdf } from '../services/archive';
import { addBrand, boardsOf, listBrands, setBoards } from '../services/boardBrands';
import { applyNotesToBoards } from '../services/noteInterest';
import { renderTablePdf } from '../services/tablePdf';
import { refreshOwnerOverride } from '../services/ownership';
import { analysePhone, splitNumbers, tidyPhones, whatsappLink } from '../services/phone';
import { createSampleFromNote } from '../services/tracking';
import { addBusinessDays, todayIstanbul, todoModel } from '../services/todos';
import { aiAvailable, bulkLeftToday, bulkLimit, checkCompany, checkStatus, markCandidates, setBulkLimit, SQL_UNREAD, spendBulk, startChecks, startQuickChecks } from '../services/companyCheck';
import { DEFAULT_MATCHED_BRANDS, PRIMARY_BRAND, matchedBrands, setMatchedBrands } from '../services/companyScoring';
import { logAi, runForCard } from '../services/aiLog';
import { aiFailureMessage } from '../services/aiGate';
import { cleanData as cleanProformaData, withMemory as proformaWithMemory, reviewProforma } from './proformaRoutes';
import { addOpportunity } from '../services/opportunities';
import { priceProforma as priceProformaLines } from '../services/proforma';
import { proformaFileName, renderProformaPdf, renderProformaXlsx } from '../services/proformaPdf';
import type { ExtractedCardFields, FieldStatusMap } from '../schema/cardSchema';

// Combined size of everything attached to one email - most mail servers
// refuse messages over 20-25 MB.
const MAX_ATTACHMENT_BYTES = 20 * 1024 * 1024;

function asciiSlug(s: string): string {
  return s.normalize('NFD').replace(/\p{Diacritic}/gu, '').replace(/[^A-Za-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40) || 'customer';
}

const router = Router();

router.use(requireAuth);

// (answered before the routes of one customer: these are not a customer)
router.get('/sample-options', (_req, res) => res.json({ choices: SAMPLE_CHOICES, carriers: CARRIERS, to: sampleRecipients() }));

const BLANK_FIELDS: ExtractedCardFields = {
  name: null, company: null, address: null, country: null, tel: null, email: null, position: null,
  interestedIn: null, workArea: null, date: null, person: null, rate: null, notes: null,
};

const ALL_NOT_FOUND: FieldStatusMap = Object.fromEntries(
  Object.keys(BLANK_FIELDS).map((k) => [k, 'not_found'])
) as FieldStatusMap;

// A new customer belongs to the market of the person who adds it (an admin can choose).
function marketForNew(user: NonNullable<AuthedRequest['user']>, requested: unknown): 'export' | 'domestic' {
  if (user.role === 'admin' && typeof requested === 'string' && requested) return asMarket(requested);
  return asMarket(user.market);
}

// The list the domestic customers live in (the app files every customer under a fair or a list).
function domesticList(userId: number) {
  const found = exhibitions.listAll().find((e) => e.name === 'Domestic customers');
  return found ?? exhibitions.create({ name: 'Domestic customers', location: 'Customers in Turkey', createdBy: userId });
}

// The list a customer lands in when they were not met at a fair (a visit, an e-mail, a call ...).
function directList(userId: number) {
  const found = exhibitions.listAll().find((e) => e.name === 'Direct contacts');
  return found ?? exhibitions.create({ name: 'Direct contacts', location: 'Visits, e-mails, calls and recommendations', createdBy: userId });
}

// Defaults for a customer in Turkey: the country is Turkey, the city comes from what was written (or from the address) and
// the person is whoever looks after that city. (The export rules - person by country - do not apply to them.)
function applyDomesticDefaults(fields: ExtractedCardFields, status: FieldStatusMap, cityInput: unknown) {
  const written = typeof cityInput === 'string' ? cityInput : '';
  const city = resolveCity(written).city ?? guessCityFromAddress(fields.address);
  const base = applyCountryDefaults({ ...fields, country: null }, status);
  const next: ExtractedCardFields = { ...base.fields, country: fields.country || 'Turkey' };
  const st = { ...base.status } as FieldStatusMap;
  if (!next.person) {
    const owner = cityModel.findByCity(city)?.responsible;
    if (owner) {
      next.person = owner;
      st.person = 'uncertain';
    }
  }
  return { fields: next, status: st, city };
}

// Admin sees every card. A plain staff member only gets to view/edit/send
// for a card if they uploaded it themselves, or the card's "Person" field
// (the responsible staff member) is their own display name - confirmed
// directly by the user: "if my co-worker scans and puts my name as
// responsible, I will still be able to view/edit/send email".
function canAccessCard(user: AuthedRequest['user'], card: CardRow): boolean {
  return canSeeCard(user, card);
}

router.post('/upload', upload.single('image'), async (req: AuthedRequest, res) => {
  const market = marketForNew(req.user!, req.body?.market);
  let exhibitionId = parseInt(req.body?.exhibitionId, 10);
  if (!exhibitionId) exhibitionId = (market === 'domestic' ? domesticList(req.user!.id) : directList(req.user!.id)).id;
  if (!exhibitionId) {
    return res.status(400).json({ error: 'exhibitionId is required' });
  }
  if (!req.file) {
    return res.status(400).json({ error: 'image file is required' });
  }

  // Even if the AI call fails entirely (bad key, network issue, unreadable
  // photo), the uploaded photo is never lost - a blank record is created so
  // staff can still fill it in by hand from the Review page, flagged so
  // they know AI extraction didn't run at all.
  let fields = BLANK_FIELDS;
  let fieldStatus = ALL_NOT_FOUND;
  let extractionModel = 'none (AI extraction failed)';
  let extractionError: string | null = null;
  let insight: AiInsight | null = null;

  try {
    const { result, model } = await extractCardFromImage(req.file.path);
    fields = result.fields;
    fieldStatus = result.fieldStatus;
    insight = result.insight ?? null;
    extractionModel = model;
  } catch (err) {
    console.error('Extraction failed:', err);
    extractionError = (err as Error).message;
  }

  // Today's date when the paper has none, and the country's usual person - also on a blank
  // card, when the AI could not read the form.
  let city: string | null = null;
  if (market === 'domestic') {
    const dom = applyDomesticDefaults(fields, fieldStatus, req.body?.city);
    fields = dom.fields;
    fieldStatus = dom.status;
    city = dom.city;
  } else {
    const withDefaults = applyCountryDefaults(fields, fieldStatus);
    fields = withDefaults.fields;
    fieldStatus = withDefaults.status;
  }

  // The AI read the full-quality photo above; the copy that is kept is shrunk (about 90 % smaller).
  const storedName = await compressScan(path.basename(req.file.path));

  const card = cardModel.createFromExtraction({
    exhibitionId,
    uploadedBy: req.user!.id,
    imagePath: storedName,
    fields,
    fieldStatus,
    extractionModel,
    extractionError,
    insight,
    market,
    city,
    source: typeof req.body?.source === 'string' ? req.body.source : null,
    stage: typeof req.body?.stage === 'string' && STAGES.has(req.body.stage) ? req.body.stage : null,
    language: typeof req.body?.language === 'string' ? req.body.language : null,
  });
  syncCustomerFolder(card.id);
  refreshOwnerOverride(card.id);
  logActivity(req.user!, card, 'scan', [fields.company, fields.name].filter(Boolean).join(' - ') || 'A form was scanned');
  rateOneWithRules(card.id);
  setLanguageByRule(card.id);
  res.status(201).json({ ...card, field_status: JSON.parse(card.field_status), interest: interestOf(card), insight: parseInsight(card.ai_insight), extractionError, duplicates: findDuplicates(card, req.user!) });
});

// A customer who was not scanned from a form: typed in by hand (a customer from before, a contact from
// a list, somebody met somewhere else). It lands in any fair or list, ready for offers and e-mails.
router.post('/', async (req: AuthedRequest, res) => {
  const b = (req.body ?? {}) as Record<string, unknown>;
  const text = (v: unknown, max = 300) => (typeof v === 'string' && v.trim() ? v.trim().slice(0, max) : null);
  const market = marketForNew(req.user!, b.market);
  let exhibitionId = parseInt(String(b.exhibitionId ?? ''), 10);
  if (!exhibitionId) exhibitionId = (market === 'domestic' ? domesticList(req.user!.id) : directList(req.user!.id)).id;
  if (!exhibitionId || !exhibitionModel.findById(exhibitionId)) return res.status(400).json({ error: 'Choose the fair or list this customer belongs to.' });
  const fields: ExtractedCardFields = {
    ...BLANK_FIELDS,
    name: text(b.name, 120),
    company: text(b.company, 160),
    address: text(b.address, 300),
    country: text(b.country, 80),
    tel: tidyPhones(text(b.tel, 80), text(b.country, 80)),
    email: text(b.email, 200),
    position: text(b.position, 120),
    workArea: text(b.workArea, 200),
    interestedIn: text(b.interestedIn, 300),
    notes: text(b.notes, 2000),
    rate: Number.isInteger(b.rate) && (b.rate as number) >= 1 && (b.rate as number) <= 10 ? (b.rate as number) : null,
    person: text(b.person, 120),
    date: null,
  };
  if (!fields.name && !fields.company && !fields.email) return res.status(400).json({ error: 'Write at least a name, a company or an e-mail address.' });
  const leadSource = text(b.leadSource, 80);
  if (!leadSource || !leadSources().includes(leadSource)) return res.status(400).json({ error: 'Choose where this lead came from (Lead source).' });
  if (fields.email && !splitEmails(fields.email).length) return res.status(400).json({ error: 'That e-mail address does not look right.' });
  const found = detectInterest({ interestedIn: fields.interestedIn, workArea: fields.workArea, notes: fields.notes });
  // a customer typed in is read by the plain rules - the AI is asked for only when somebody presses the button on the customer
  const insight = ruleInsight({ notes: fields.notes, interested_in: fields.interestedIn, work_area: fields.workArea, products: found.products, widths: found.widths, other: found.other || null });
  const allFound = { ...ALL_NOT_FOUND, ...Object.fromEntries(Object.keys(BLANK_FIELDS).map((k) => [k, 'found'])) } as FieldStatusMap;
  let city: string | null = null;
  let withDefaults: { fields: ExtractedCardFields; status: FieldStatusMap };
  if (market === 'domestic') {
    const dom = applyDomesticDefaults(fields, allFound, b.city);
    withDefaults = dom;
    city = dom.city;
  } else {
    withDefaults = applyCountryDefaults(fields, allFound);
  }
  const card = cardModel.createFromExtraction({
    exhibitionId,
    uploadedBy: req.user!.id,
    imagePath: '',
    fields: withDefaults.fields,
    fieldStatus: withDefaults.status,
    extractionModel: 'typed-in',
    status: 'confirmed',
    insight,
    market,
    city,
    source: typeof b.source === 'string' ? b.source : null,
    stage: typeof b.stage === 'string' && STAGES.has(b.stage) ? b.stage : null,
    website: text(b.website, 200),
    language: typeof b.language === 'string' ? b.language : null,
    mobile: tidyPhones(text(b.mobile, 80), text(b.country, 80)),
    fax: text(b.fax, 80),
    sap: req.user!.role === 'admin' ? text(b.sap, 40) : null,
  });
  db.prepare('UPDATE cards SET lead_source = ? WHERE id = ?').run(leadSource, card.id);
  syncCustomerFolder(card.id);
  refreshOwnerOverride(card.id);
  applyNotesToBoards(card.id, fields.notes, fields.interestedIn, fields.workArea); // the producers named in the notes become the panel interest
  logActivity(req.user!, card, 'created', [fields.company, fields.name].filter(Boolean).join(' - ') || 'Added by hand');
  rateOneWithRules(card.id);
  setLanguageByRule(card.id);
  res.status(201).json({ ...card, field_status: JSON.parse(card.field_status), interest: interestOf(card), insight: parseInsight(card.ai_insight), duplicates: findDuplicates(card, req.user!) });
});

// Everything about the signed-in person's customers as a ZIP: for each customer
// the scan, the details and every offer that was sent, plus an Excel of the
// records. A staff member gets their own customers (the ones they scanned or are
// responsible for); an admin gets all of them.
router.get('/export-zip', async (req: AuthedRequest, res) => {
  const exhibitionId = req.query.exhibitionId ? parseInt(String(req.query.exhibitionId), 10) : undefined;
  const isAdmin = req.user!.role === 'admin';
  const cards = cardModel.search({
    exhibitionId,
    visibleTo: req.user!,
  });
  if (cards.length === 0) return res.status(404).json({ error: 'There are no records to download yet.' });

  const exhibitionsById = new Map(exhibitionModel.listAll().map((e) => [e.id, e]));
  const stamp = new Date().toISOString().slice(0, 10);
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', `attachment; filename="tece-${asciiSlug(isAdmin ? 'all-customers' : req.user!.display_name || req.user!.username)}-${stamp}.zip"`);
  const archive = archiver('zip', { zlib: { level: 6 } });
  archive.on('error', (err) => {
    console.error('Personal export failed:', err);
    res.end();
  });
  archive.pipe(res);
  for (const c of cards) {
    syncCustomerFolder(c.id);
    const fresh = cardModel.findById(c.id);
    if (!fresh?.archive_dir) continue;
    // <exhibition>/<customer> - the sales person level is dropped, it is all theirs
    archive.directory(absoluteFolder(fresh.archive_dir), fresh.archive_dir.split(path.sep).slice(1).join('/'));
  }
  archive.append(Buffer.from(await buildCardsWorkbook(cards, exhibitionsById)), { name: 'records.xlsx' });
  await archive.finalize();
});

// A web address to start from for this customer: one written on the form, or the
// company part of their work email (never a personal gmail/hotmail address).
router.get('/:id/website-guess', (req: AuthedRequest, res) => {
  const card = cardModel.findById(parseInt(String(req.params.id), 10));
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  res.json({ guess: guessWebsite(card) });
});

// Reads the customer's web site and suggests a short line for the Work area.
router.post('/website-lookup', async (req, res) => {
  try {
    res.json(await lookupWebsite(String(req.body?.url ?? '')));
  } catch (err) {
    const cause = (err as { cause?: { code?: string } }).cause?.code;
    const code = (err as { code?: string }).code ?? cause;
    const message = code === 'ENOTFOUND' ? 'That web site could not be found.' : cause === 'UND_ERR_CONNECT_TIMEOUT' || (err as Error).name === 'TimeoutError' ? 'The web site took too long to answer.' : (err as Error).message;
    res.status(422).json({ error: message || 'Could not read that web site.' });
  }
});

// Reads some written words ("PVC 0.4 x 22, melamin") and says which products and
// edge widths they mention - the Review page uses it to tick the boxes.
router.post('/interest-detect', (req, res) => {
  const text = String(req.body?.text ?? '').slice(0, 4000);
  res.json(detectInterest({ interestedIn: text }));
});

// Lets the AI read the notes of every customer it has not read yet (records from before this
// existed, plain-word readings): 60 at a time, only the customers the person may see.
router.post('/analyse-missing', requireAdmin, needAi, async (req: AuthedRequest, res) => {
  const exhibitionId = req.body?.exhibitionId ? parseInt(String(req.body.exhibitionId), 10) : undefined;
  const todo = cardModel
    .search({ exhibitionId, visibleTo: req.user! })
    .filter((c) => c.stage !== 'lead' && parseInsight(c.ai_insight)?.source !== 'ai')
    .slice(0, 60);
  let done = 0;
  for (let i = 0; i < todo.length; i += 5) {
    await Promise.all(
      todo.slice(i, i + 5).map(async (c) => {
        const interest = interestOf(c);
        const insight = await analyseCard(c, { products: interest.products, widths: interest.widths, other: interest.other || null });
        cardModel.setInsight(c.id, insight);
        if (insight.source === 'ai') done += 1;
      })
    );
  }
  const left = cardModel.search({ exhibitionId, visibleTo: req.user! }).filter((c) => parseInsight(c.ai_insight)?.source !== 'ai').length;
  res.json({ read: done, tried: todo.length, left });
});

// ---- the same company twice, the people under a company, files, and the AI's rating ----

const fileUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 15 * 1024 * 1024, files: 8 } });

// A customer this person may open, or null (the answer has been sent).
function openCard(req: AuthedRequest, res: Response): CardRow | null {
  const card = cardModel.findById(parseInt(String(req.params.id), 10));
  if (!card) {
    res.status(404).json({ error: 'Not found' });
    return null;
  }
  if (!canAccessCard(req.user, card)) {
    res.status(403).json({ error: 'You do not have access to this record' });
    return null;
  }
  return card;
}

// The numbers on the tabs of the customer list.
router.get('/segments', (req: AuthedRequest, res) => {
  res.json(cardModel.segmentCounts(req.user!));
});

router.get('/duplicate-groups', (req: AuthedRequest, res) => {
  res.json(duplicateGroups(req.user!));
});

// How many companies appear more than once (the badge on the customer list).
router.get('/duplicate-count', (req: AuthedRequest, res) => {
  res.json({ count: duplicateCount(req.user!) });
});

router.get('/:id/duplicates', (req: AuthedRequest, res) => {
  const card = openCard(req, res);
  if (card) res.json(findDuplicates(card, req.user!));
});

// Put another record of the same company under this one (its person becomes a contact, its history moves over).
// the two records side by side before they are put together
router.get('/:id/merge-preview', (req: AuthedRequest, res) => {
  const a = openCard(req, res);
  if (!a) return;
  const b = cardModel.findById(parseInt(String(req.query.other ?? ''), 10));
  if (!b || b.id === a.id) return res.status(400).json({ error: 'Choose the other record.' });
  if (!canAccessCard(req.user, b)) return res.status(403).json({ error: 'You do not have access to that record' });
  res.json(mergePreview(a.id, b.id));
});
router.post('/:id/merge', (req: AuthedRequest, res) => {
  const keep = openCard(req, res);
  if (!keep) return;
  const from = cardModel.findById(parseInt(String(req.body?.fromId ?? ''), 10));
  if (!from || from.id === keep.id) return res.status(400).json({ error: 'Choose the other record to merge.' });
  if (!canAccessCard(req.user, from)) return res.status(403).json({ error: 'You do not have access to that record' });
  if (from.market !== keep.market && req.user!.role !== 'admin') return res.status(403).json({ error: 'Export and domestic customers cannot be merged.' });
  try {
    const o = (req.body?.options ?? {}) as Record<string, unknown>;
    const pickOf = (v: unknown) => (v === 'keep' || v === 'other' ? v : undefined);
    const f = (o.fields ?? {}) as Record<string, unknown>;
    const merged = mergeCards(keep.id, from.id, req.user!.id, {
      prices: ['both', 'keep', 'other', 'newest'].includes(String(o.prices)) ? (o.prices as 'both' | 'keep' | 'other' | 'newest') : 'both',
      complaints: o.complaints === 'leave' ? 'leave' : 'move',
      fields: { sap: pickOf(f.sap), person: pickOf(f.person), offer_percent: pickOf(f.offer_percent), rate: pickOf(f.rate), website: pickOf(f.website), address: pickOf(f.address) },
    });
    rateOneWithRules(merged.id);
    res.json({ ...merged, field_status: JSON.parse(merged.field_status), interest: interestOf(merged), insight: parseInsight(merged.ai_insight) });
  } catch (err) {
    console.error('Merge failed:', err);
    res.status(500).json({ error: 'Could not merge these records.' });
  }
});

// The board producers (Kronospan, Egger ...): the list, and the ones of one customer.
router.get('/board-brands', (_req, res) => {
  res.json(listBrands());
});
router.post('/board-brands', (req: AuthedRequest, res) => {
  if (req.user!.role !== 'admin') return res.status(403).json({ error: 'Only an admin adds a board producer to the list.' });
  const b = addBrand(String(req.body?.name ?? ''));
  if (!b) return res.status(400).json({ error: 'Write the name.' });
  res.status(201).json(b);
});
router.put('/:id/boards', (req: AuthedRequest, res) => {
  const card = openCard(req, res);
  if (!card) return;
  const ids = (Array.isArray(req.body?.brandIds) ? req.body.brandIds : []).map((n: unknown) => Number(n));
  res.json(setBoards(card.id, ids));
});

// The products to tick under "Interested in": the ones whose price page the admin has switched on (Admin > Price lists), and Metal.
router.get('/interest-products', (_req, res) => {
  const on = new Set(enabledTabs());
  res.json(INTEREST_PRODUCTS.filter((p) => !p.sheet || on.has(p.sheet) || (p.sheet === 'PP M2+22' && on.has('PP M2'))).map((p) => ({ key: p.key, label: p.label })));
});

// The people at this company: the first one is on the customer itself, the others are listed under it.
router.get('/:id/contacts', (req: AuthedRequest, res) => {
  const card = openCard(req, res);
  if (!card) return;
  res.json({ primary: { name: card.name, position: card.position, email: card.email, tel: card.tel, roles: rolesOf((card as unknown as { contact_roles?: string | null }).contact_roles) }, contacts: contactModel.list(card.id) });
});
// what the first person (the one on the customer itself) is for
router.patch('/:id/primary-roles', (req: AuthedRequest, res) => {
  const card = openCard(req, res);
  if (!card) return;
  db.prepare("UPDATE cards SET contact_roles = ?, updated_at = datetime('now') WHERE id = ?").run(cleanRoles(req.body?.roles), card.id);
  res.json({ roles: rolesOf(cleanRoles(req.body?.roles)) });
});
router.post('/:id/contacts', (req: AuthedRequest, res) => {
  const card = openCard(req, res);
  if (!card) return;
  const c = contactModel.add(card.id, req.body ?? {});
  if (!c) return res.status(400).json({ error: 'Write at least a name or an e-mail address.' });
  syncCustomerFolder(card.id);
  res.status(201).json(contactModel.list(card.id));
});
// the scan (photo of the business card or form) of one of the other people
router.post('/:id/contacts/:cid/scan', upload.single('scan'), (req: AuthedRequest, res) => {
  const card = openCard(req, res);
  if (!card) return;
  const cur = contactModel.find(parseInt(String(req.params.cid), 10));
  if (!cur || cur.cardId !== card.id) return res.status(404).json({ error: 'Not found' });
  if (!req.file) return res.status(400).json({ error: 'Choose a photo.' });
  contactModel.update(cur.id, { scanPath: req.file.filename });
  res.json(contactModel.list(card.id));
});
router.patch('/:id/contacts/:cid', (req: AuthedRequest, res) => {
  const card = openCard(req, res);
  if (!card) return;
  const cur = contactModel.find(parseInt(String(req.params.cid), 10));
  if (!cur || cur.cardId !== card.id) return res.status(404).json({ error: 'Not found' });
  contactModel.update(cur.id, req.body ?? {});
  res.json(contactModel.list(card.id));
});
router.delete('/:id/contacts/:cid', (req: AuthedRequest, res) => {
  const card = openCard(req, res);
  if (!card) return;
  const cur = contactModel.find(parseInt(String(req.params.cid), 10));
  if (!cur || cur.cardId !== card.id) return res.status(404).json({ error: 'Not found' });
  contactModel.remove(cur.id);
  res.json(contactModel.list(card.id));
});

// Add files (photos, PDFs, drawings ...) to the customer.
router.post('/:id/files', fileUpload.array('files', 8), (req: AuthedRequest, res) => {
  const card = openCard(req, res);
  if (!card) return;
  const files = (req.files as Express.Multer.File[] | undefined) ?? [];
  if (!files.length) return res.status(400).json({ error: 'Choose a file first.' });
  const saved: string[] = [];
  const refused: string[] = [];
  for (const f of files) {
    const name = Buffer.from(f.originalname, 'latin1').toString('utf8');
    if (!isUploadable(name)) {
      refused.push(name);
      continue;
    }
    if (saveUploadedFile(card.id, name, f.buffer)) saved.push(name);
  }
  if (saved.length) logActivity(req.user!, card, 'file', saved.join(', '));
  res.status(saved.length ? 201 : 400).json({ saved, refused, error: saved.length ? undefined : 'These file types are not accepted (use images, PDF, Word, Excel, PowerPoint, text or ZIP).' });
});
router.delete('/:id/files', (req: AuthedRequest, res) => {
  const card = openCard(req, res);
  if (!card) return;
  if (!deleteUploadedFile(card.id, String(req.query.name ?? ''))) return res.status(404).json({ error: 'Only files you added can be deleted.' });
  res.json({ ok: true });
});

// Translate the subject and message of an e-mail into the customer's language (the AI).
router.post('/:id/translate', async (req: AuthedRequest, res) => {
  const card = openCard(req, res);
  if (!card) return;
  const lang = req.body?.language;
  if (!isLang(lang) || lang === 'en') return res.status(400).json({ error: 'Choose a language.' });
  if (!useAi(req.user!, res)) return;
  const subject = String(req.body?.subject ?? '');
  const body = String(req.body?.body ?? '');
  const done = await translateEmail(subject, body, lang);
  if (!done) return res.status(503).json({ ai: true, error: aiFailureMessage('The AI could not translate this just now (no AI key, or it did not answer). The text stays as it is.') });
  res.json(done);
});

// Rate this customer with the AI now.
router.post('/:id/ai-rate', async (req: AuthedRequest, res) => {
  const card = openCard(req, res);
  if (!card) return;
  if (!aiAvailable()) return res.status(503).json({ error: 'The AI is not set up on the server (no AI key).' });
  if (!useAi(req.user!, res)) return;
  const check = await checkCompany(card.id, req.body?.force === true);
  if (!check) return res.status(502).json({ ai: true, error: aiFailureMessage('The company could not be scored just now. Try again.') });
  const fresh = cardModel.findById(card.id)!;
  res.json({ ai_rate: fresh.ai_rate, ai_rate_reason: fresh.ai_rate_reason, ai_rate_source: fresh.ai_rate_source, byAi: true, company_score: fresh.company_score });
});

// The choices for the list's drop-downs: the countries and the people that occur.
router.get('/facets', (req: AuthedRequest, res) => {
  const countries = (db.prepare("SELECT DISTINCT country FROM cards WHERE country IS NOT NULL AND country != '' ORDER BY country").all() as { country: string }[]).map((r) => r.country);
  const people = (db.prepare("SELECT DISTINCT person FROM cards WHERE person IS NOT NULL AND person != '' ORDER BY person").all() as { person: string }[]).map((r) => r.person);
  const cityRows = (db.prepare("SELECT DISTINCT city FROM cards WHERE market = 'domestic' AND city IS NOT NULL AND city != '' ORDER BY city").all() as { city: string }[]).map((r) => r.city);
  const businessTypes = (db.prepare("SELECT DISTINCT json_extract(lead_info, '$.businessType') AS b FROM cards WHERE lead_info IS NOT NULL").all() as { b: string | null }[]).map((r) => r.b).filter((b): b is string => !!b).sort();
  if (req.user!.role === 'admin') return res.json({ countries, people, cities: cityRows, markets: ['export', 'domestic'], businessTypes });
  const access = accessOf(req.user!);
  const seesExport = access.markets.has('export') || req.user!.market !== 'domestic';
  const seesDomestic = access.markets.has('domestic') || req.user!.market === 'domestic';
  res.json({
    countries: seesExport ? countries.filter((c) => access.countries.has(countryKey(c)) || access.markets.has('export')) : [],
    people: access.markets.size ? people : people.filter((p) => p === req.user!.display_name),
    cities: seesDomestic ? cityRows.filter((c) => access.cities.has(cityKey(c)) || access.markets.has('domestic')) : [],
    markets: [...new Set([req.user!.market === 'domestic' ? 'domestic' : 'export', ...access.markets])],
    businessTypes,
  });
});

// The filters of the customer list (the list and "select many at once" use the same).
const SORTS = ['score', 'company', 'ai', 'score_asc', 'ai_asc', 'purchase', 'company_desc', 'place', 'place_desc', 'stage', 'stage_desc', 'last_contact', 'last_contact_desc', 'next'];
function listQuery(req: AuthedRequest): Omit<Parameters<typeof cardModel.searchPaged>[0], 'page' | 'pageSize'> {
  const str = (k: string) => (typeof req.query[k] === 'string' && (req.query[k] as string).trim() ? (req.query[k] as string).trim() : undefined);
  return {
    exhibitionId: req.query.exhibitionId ? parseInt(String(req.query.exhibitionId), 10) || undefined : undefined,
    text: str('q'),
    country: str('country'),
    person: str('person'),
    stage: str('stage'),
    status: str('status'),
    market: str('market'),
    city: str('city'),
    segment: str('segment'),
    source: str('source'),
    group: str('group'),
    websiteCheck: str('websiteCheck'),
    tier: str('tier'),
    thankYou: str('thankYou') === 'sent' ? 'sent' : str('thankYou') === 'not' ? 'not' : undefined,
    offer: ['sent', 'not', 'wanted'].includes(str('offer') ?? '') ? (str('offer') as 'sent' | 'not' | 'wanted') : undefined,
    bulgaria: str('bulgaria') === 'yes',
    hasEmail: str('hasEmail') === 'yes',
    noEmail: str('hasEmail') === 'no',
    rated: str('rated') === 'none' ? 'none' : str('rated') === 'hot' ? 'hot' : undefined,
    sample: str('sample') === 'missing' ? 'missing' : str('sample') === 'sent' ? 'sent' : undefined,
    businessType: str('businessType'),
    board: str('board'),
    verdict: str('verdict'),
    scoreTier: str('scoreTier'),
    priority: str('priority'),
    touched: str('touched') === 'none' ? 'none' : str('touched') === 'mine' ? 'mine' : undefined,
    sort: SORTS.includes(str('sort') ?? '') ? (str('sort') as NonNullable<Parameters<typeof cardModel.searchPaged>[0]['sort']>) : 'newest',
    aiMin: str('aiMin') !== undefined && Number.isFinite(parseInt(str('aiMin')!, 10)) ? parseInt(str('aiMin')!, 10) : undefined,
    visibleTo: req.user!,
  };
}

// The ids of the customers that match the filters and that this person may delete (up to 5,000): for ticking many at once.
router.get('/ids', (req: AuthedRequest, res) => {
  const limit = Math.min(5000, Math.max(1, parseInt(String(req.query.limit ?? '5000'), 10) || 5000));
  const mine = { countries: myCountryKeys(req.user!.display_name), cities: myCityKeys(req.user!.display_name) };
  const rows = cardModel.searchPaged({ ...listQuery(req), page: 1, pageSize: Math.min(5000, limit * (req.user!.role === 'admin' ? 1 : 4)) }).rows;
  const ids = rows.filter((c) => canDeleteCard(req.user!, c, mine)).slice(0, limit).map((c) => c.id);
  res.json({ ids });
});

// Set the country of many customers at once (the ticked ones that have none, or any ticked export customer). The person of the country
// looks after those that had nobody, and the language follows the country when none was chosen.
router.post('/set-country', (req: AuthedRequest, res) => {
  const ids = Array.isArray(req.body?.ids) ? (req.body.ids as unknown[]).map((n) => Math.trunc(Number(n))).filter((n) => Number.isFinite(n)).slice(0, 5000) : [];
  const country = canonicalCountry(String(req.body?.country ?? '').trim()) as string;
  if (!country || !COUNTRY_NAMES.includes(country)) return res.status(400).json({ error: 'Choose a country from the list.' });
  const owner = countryModel.findByCountry(country)?.responsible ?? null;
  const mine = { countries: myCountryKeys(req.user!.display_name), cities: myCityKeys(req.user!.display_name) };
  let changed = 0;
  let skipped = 0;
  db.exec('BEGIN');
  try {
    for (const id of ids) {
      const card = cardModel.findById(id);
      if (!card) continue;
      if (card.market === 'domestic' || !canDeleteCard(req.user!, card, mine)) { skipped += 1; continue; }
      cardModel.update(id, { country, ...(!card.person && owner && req.user!.role === 'admin' ? { person: owner } : {}) });
      refreshOwnerOverride(id);
      setLanguageByRule(id);
      changed += 1;
    }
    db.exec('COMMIT');
  } catch (err) {
    db.exec('ROLLBACK');
    console.error('Set country failed:', err);
    return res.status(500).json({ error: 'Could not set the country' });
  }
  res.json({ changed, skipped });
});

// Delete the ticked customers (only the ones this person may delete).
router.post('/bulk-delete', (req: AuthedRequest, res) => {
  const ids = Array.isArray(req.body?.ids) ? (req.body.ids as unknown[]).map((n) => Math.trunc(Number(n))).filter((n) => Number.isFinite(n)).slice(0, 5000) : [];
  const mine = { countries: myCountryKeys(req.user!.display_name), cities: myCityKeys(req.user!.display_name) };
  let deleted = 0;
  let refused = 0;
  let kept = 0;
  db.exec('BEGIN');
  try {
    for (const id of ids) {
      const card = cardModel.findById(id);
      if (!card) continue;
      if (!canDeleteCard(req.user!, card, mine)) {
        refused += 1;
        continue;
      }
      // existing and important customers stay, whoever ticks them
      if (isProtected(card)) {
        kept += 1;
        continue;
      }
      removeCard(card);
      deleted += 1;
    }
    db.exec('COMMIT');
  } catch (err) {
    db.exec('ROLLBACK');
    console.error('Bulk delete failed:', err);
    return res.status(500).json({ error: 'Could not delete these customers.' });
  }
  res.json({ deleted, refused, kept });
});

// Put several ticked records of one company together: one is kept (the existing / most worked one unless a person chooses), everything of the others moves under it.
router.post('/bulk-merge', (req: AuthedRequest, res) => {
  const ids = [...new Set((Array.isArray(req.body?.ids) ? (req.body.ids as unknown[]) : []).map((n) => Math.trunc(Number(n))).filter((n) => Number.isFinite(n)))].slice(0, 30);
  const cards = ids.map((i) => cardModel.findById(i)).filter((c): c is CardRow => !!c && canAccessCard(req.user, c));
  if (cards.length < 2) return res.status(400).json({ error: 'Tick at least two customers to put together.' });
  if (req.user!.role !== 'admin' && new Set(cards.map((c) => c.market)).size > 1) return res.status(403).json({ error: 'Export and domestic customers cannot be merged.' });
  const work = (c: CardRow) => (isProtected(c) ? 1000 : 0) + (c.stage && c.stage !== 'lead' ? 100 : 0) + ((db.prepare("SELECT COUNT(*) AS n FROM activities WHERE card_id = ? AND type != 'ai'").get(c.id) as { n: number }).n) + (c.email ? 1 : 0);
  const wanted = cards.find((c) => c.id === Math.trunc(Number(req.body?.keepId)));
  const keep = wanted ?? [...cards].sort((a, b) => work(b) - work(a) || a.id - b.id)[0];
  try {
    let merged = 0;
    for (const c of cards) {
      if (c.id === keep.id) continue;
      mergeCards(keep.id, c.id, req.user!.id, { prices: 'both', complaints: 'move', fields: {} });
      merged += 1;
    }
    rateOneWithRules(keep.id);
    res.json({ keptId: keep.id, kept: keep.company || keep.name, merged });
  } catch (err) {
    console.error('Bulk merge failed:', err);
    res.status(500).json({ error: 'Could not put these records together.' });
  }
});

// The AI's rating is irrelevant or wrong: take the person's own rating instead.
router.post('/:id/ai-rate/mine', (req: AuthedRequest, res) => {
  const card = openCard(req, res);
  if (!card) return;
  if (card.rate === null || card.rate === undefined) return res.status(400).json({ error: 'Give your own rating first.' });
  cardModel.setAiRate(card.id, card.rate, 'Copied from your own rating', 'person');
  audit(req.user, card.id, 'change', 'AI rating', card.ai_rate, card.rate, 'Own rating copied over the AI rating');
  const fresh = cardModel.findById(card.id)!;
  res.json({ ai_rate: fresh.ai_rate, ai_rate_reason: fresh.ai_rate_reason, ai_rate_source: fresh.ai_rate_source });
});

// ---- telephone numbers (admin): each number checked, with its country code; a mobile goes to the Mobile (WhatsApp) field ----
router.post('/phones-fix', requireAdmin, (req: AuthedRequest, res) => {
  const dryRun = req.body?.dryRun !== false;
  const rows = db.prepare("SELECT id, country, tel, mobile FROM cards WHERE TRIM(COALESCE(tel, '')) != '' OR TRIM(COALESCE(mobile, '')) != ''").all() as { id: number; country: string | null; tel: string | null; mobile: string | null }[];
  const report = { checked: rows.length, changed: 0, movedToMobile: 0, invalid: 0, needCountry: 0, examples: [] as { id: number; before: string; after: string }[] };
  const update = db.prepare('UPDATE cards SET tel = ?, mobile = ? WHERE id = ?');
  if (!dryRun) db.exec('BEGIN');
  try {
    for (const r of rows) {
      const nums = [...new Set([...splitNumbers(r.mobile), ...splitNumbers(r.tel)])];
      const mobiles: string[] = [];
      const others: string[] = [];
      let bad = false;
      for (const n of nums) {
        const a = analysePhone(n, r.country);
        if (a.e164 && a.kind === 'mobile') mobiles.push(a.e164);
        else if (a.e164) others.push(a.e164);
        else { others.push(n); bad = true; if (!r.country) report.needCountry += 1; }
      }
      if (bad) report.invalid += 1;
      const mobile = [...new Set(mobiles)].join(' / ') || null;
      const tel = [...new Set(others)].join(' / ') || null;
      if (mobile === (r.mobile ?? null) && tel === (r.tel ?? null)) continue;
      report.changed += 1;
      if (mobile && !(r.mobile ?? '').trim()) report.movedToMobile += 1;
      if (report.examples.length < 8) report.examples.push({ id: r.id, before: [r.mobile, r.tel].filter(Boolean).join(' | '), after: [mobile, tel].filter(Boolean).join(' | ') });
      if (!dryRun) update.run(tel, mobile, r.id);
    }
    if (!dryRun) db.exec('COMMIT');
  } catch (err) {
    if (!dryRun) db.exec('ROLLBACK');
    throw err;
  }
  res.json({ dryRun, ...report });
});

// ---- the customer map: how many customers in each country (and city), for the customers this person may see ----
const MAP_FILTERS: Record<string, string> = {
  all: '',
  existing: "stage = 'customer'",
  potential: "COALESCE(stage, '') NOT IN ('customer', 'lost')",
  exhibition: SQL_EXHIBITION,
  top: `(json_extract(company_score, '$.purchase.tier') = 'Hot' OR COALESCE(${SQL_RATING}, 0) >= 8)`,
  review: "status = 'needs_review'",
  junk: "stage = 'lost'",
};
router.get('/map', (req: AuthedRequest, res) => {
  const f = typeof req.query.f === 'string' && f_ok(req.query.f) ? req.query.f : 'all';
  const params: Record<string, string | number> = {};
  const vis = visibilitySql(req.user!, params);
  const conds = [vis, MAP_FILTERS[f]].filter(Boolean);
  const exhibitionId = parseInt(String(req.query.exhibitionId ?? ''), 10);
  if (exhibitionId) { conds.push('exhibition_id = @exhibitionId'); params.exhibitionId = exhibitionId; }
  if (req.query.market === 'export' || req.query.market === 'domestic') { conds.push('market = @market'); params.market = String(req.query.market); }
  const rows = db
    .prepare(`SELECT country, city, market, COUNT(*) AS n FROM cards${conds.length ? ` WHERE ${conds.join(' AND ')}` : ''} GROUP BY country, city, market`)
    .all(params) as { country: string | null; city: string | null; market: string; n: number }[];

  const byCountry = new Map<string, { country: string; iso: string | null; count: number; located: number }>();
  const byCity = new Map<string, { city: string; country: string; iso: string | null; lat: number; lon: number; count: number }>();
  let noCountry = 0;
  let total = 0;
  for (const r of rows) {
    total += r.n;
    // the domestic team's customers are in Turkey
    const country = r.market === 'domestic' ? 'Turkey' : (canonicalCountry((r.country ?? '').trim()) as string);
    if (!country) { noCountry += r.n; continue; }
    const c = byCountry.get(country) ?? { country, iso: isoOf(country), count: 0, located: 0 };
    c.count += r.n;
    const p = placeOf(r.city, country);
    if (p) {
      c.located += r.n;
      const k = `${country}|${p.name}`;
      const e = byCity.get(k) ?? { city: p.name, country, iso: c.iso, lat: p.lat, lon: p.lon, count: 0 };
      e.count += r.n;
      byCity.set(k, e);
    }
    byCountry.set(country, c);
  }
  res.json({
    filter: f,
    total,
    noCountry,
    countries: [...byCountry.values()].map((c) => ({ ...c, numeric: c.iso ? numericOf(c.iso) : null })).sort((a, b) => b.count - a.count),
    cities: [...byCity.values()].sort((a, b) => b.count - a.count),
  });
});
const f_ok = (v: string) => Object.prototype.hasOwnProperty.call(MAP_FILTERS, v);

// How many AI questions this person has left today.
router.get('/ai-allowance', (req: AuthedRequest, res) => {
  res.json(aiAllowance(req.user!));
});

// "Check with the AI": what the company does and how well it fits TECE, from a web search. One customer now, or the ticked ones in the background.
router.post('/ai-check', requireAdmin, needAi, (req: AuthedRequest, res) => {
  const ids = Array.isArray(req.body?.ids) ? (req.body.ids as unknown[]).map((n) => Math.trunc(Number(n))).filter((n) => Number.isFinite(n)).slice(0, 300) : [];
  const allowed = ids.filter((id) => { const c = cardModel.findById(id); return !!c && canAccessCard(req.user, c); });
  if (!allowed.length) return res.status(400).json({ error: 'Tick the customers to check first.' });
  res.json(startChecks(allowed));
});
// ---- lead clean-up (admin): the AI looks at the leads, then the ones with no information / unrelated / not suitable go at once ----
const VERDICTS = ['none', 'unrelated', 'unsuitable'];
router.get('/cleanup-summary', requireAdmin, (_req, res) => {
  const one = (sql: string, p: Record<string, string> = {}) => (db.prepare(`SELECT COUNT(*) AS n FROM cards WHERE ${sql}`).get(p) as { n: number }).n;
  res.json({
    leads: one(SQL_CLEANABLE),
    unchecked: one(`${SQL_CLEANABLE} AND company_check IS NULL`),
    checked: one(`${SQL_CLEANABLE} AND company_check IS NOT NULL`),
    fit: one(`${SQL_CLEANABLE} AND ${SQL_VERDICT} = 'fit'`),
    tiers: Object.fromEntries(
      (db.prepare("SELECT COALESCE(json_extract(company_score, '$.purchase.tier'), CASE WHEN json_extract(company_score, '$.status') = 'no_website' THEN 'Candidate' ELSE NULL END) AS t, COUNT(*) AS n FROM cards WHERE company_score IS NOT NULL GROUP BY t").all() as { t: string | null; n: number }[]).map((r) => [r.t ?? 'Other', r.n])
    ),
    none: one(`${SQL_CLEANABLE} AND ${SQL_VERDICT} = 'none'`),
    unrelated: one(`${SQL_CLEANABLE} AND ${SQL_VERDICT} = 'unrelated'`),
    unsuitable: one(`${SQL_CLEANABLE} AND ${SQL_VERDICT} = 'unsuitable'`),
    countries: (db.prepare(`SELECT country, COUNT(*) AS n FROM cards WHERE ${SQL_CLEANABLE} AND company_check IS NULL AND country IS NOT NULL AND country != '' GROUP BY country ORDER BY n DESC LIMIT 60`).all() as { country: string; n: number }[]),
    candidates: one("json_extract(company_score, '$.status') = 'no_website'"),
    quick: one(`${SQL_CLEANABLE} AND json_extract(company_check, '$.quick') = 1`),
    bulk: { limit: bulkLimit(), left: bulkLeftToday() },
    check: checkStatus(),
  });
});
// The big AI runs are limited per day (so the cost stays under control).
router.put('/bulk-limit', requireAdmin, (req, res) => {
  setBulkLimit(Number(req.body?.limit));
  res.json({ limit: bulkLimit(), left: bulkLeftToday() });
});
// Companies with no web site cannot be read by the AI: they are marked "candidate to verify" at once, free of cost.
router.post('/mark-candidates', requireAdmin, (_req, res) => {
  res.json({ marked: markCandidates() });
});
// The quick check: about 25 companies per AI question, no web sites read. For the clean-up of leads with no information.
router.post('/quick-check-next', requireAdmin, needAi, (req: AuthedRequest, res) => {
  const limit = Math.max(1, Math.min(1000, parseInt(String(req.body?.limit ?? '1000'), 10) || 1000));
  const country = typeof req.body?.country === 'string' && req.body.country.trim() ? req.body.country.trim() : null;
  const rows = db
    .prepare(`SELECT id FROM cards WHERE ${SQL_CLEANABLE} AND company_check IS NULL AND TRIM(COALESCE(company, '')) != ''${country ? ' AND country = @country' : ''} ORDER BY id LIMIT @limit`)
    .all({ limit, ...(country ? { country } : {}) }) as { id: number }[];
  if (!rows.length) return res.status(400).json({ error: 'No leads are waiting for a check.' });
  res.json(startQuickChecks(rows.map((r) => r.id)));
});
// The next leads that the AI has not looked at yet (a number, optionally one country).
router.post('/ai-check-next', requireAdmin, needAi, (req: AuthedRequest, res) => {
  const left = bulkLeftToday();
  if (left <= 0) return res.status(429).json({ error: `The daily limit of ${bulkLimit()} companies is reached. Try again tomorrow, or raise the limit.` });
  const limit = Math.max(1, Math.min(left, 500, parseInt(String(req.body?.limit ?? '100'), 10) || 100));
  const country = typeof req.body?.country === 'string' && req.body.country.trim() ? req.body.country.trim() : null;
  // only companies with a web site that are not rated yet: a rated company is never read again
  const rows = db
    .prepare(`SELECT id FROM cards WHERE ${SQL_CLEANABLE} AND ${SQL_UNREAD} AND TRIM(COALESCE(company, '')) != ''${country ? ' AND country = @country' : ''} ORDER BY id LIMIT @limit`)
    .all({ limit, ...(country ? { country } : {}) }) as { id: number }[];
  if (!rows.length) return res.status(400).json({ error: 'No leads are waiting for the AI check.' });
  spendBulk(rows.length);
  res.json(startChecks(rows.map((r) => r.id)));
});
// Delete every clean-up lead with this verdict at once. Fairs, customers who buy from us and companies that came with an e-mail or a web site are never touched.
router.post('/cleanup', requireAdmin, (req: AuthedRequest, res) => {
  const verdict = String(req.body?.verdict ?? '');
  if (!VERDICTS.includes(verdict)) return res.status(400).json({ error: 'Choose what to delete: no information, unrelated or not suitable.' });
  const limit = Math.max(1, Math.min(5000, parseInt(String(req.body?.limit ?? '1000'), 10) || 1000));
  const rows = db.prepare(`SELECT * FROM cards WHERE ${SQL_CLEANABLE} AND ${SQL_VERDICT} = @verdict ORDER BY id LIMIT @limit`).all({ verdict, limit }) as unknown as CardRow[];
  for (const c of rows) removeCard(c);
  res.json({ deleted: rows.length });
});
// The board brands that TECE has matching decors for (they earn Decor points in the Fit Score).
router.get('/scoring-settings', requireAdmin, (_req, res) => {
  res.json({ primary: PRIMARY_BRAND, brands: matchedBrands(), defaults: DEFAULT_MATCHED_BRANDS });
});
router.put('/scoring-settings', requireAdmin, (req, res) => {
  const brands = Array.isArray(req.body?.brands) ? req.body.brands.map(String) : [];
  res.json({ primary: PRIMARY_BRAND, brands: setMatchedBrands(brands), defaults: DEFAULT_MATCHED_BRANDS });
});
router.get('/ai-check-status', (_req, res) => {
  res.json(checkStatus());
});
router.post('/:id/ai-check', async (req: AuthedRequest, res) => {
  const card = cardModel.findById(parseInt(String(req.params.id), 10));
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  if (!aiAvailable()) return res.status(503).json({ error: 'The AI is not set up on the server (no AI key).' });
  if (!useAi(req.user!, res)) return;
  const check = await checkCompany(card.id);
  if (!check) return res.status(502).json({ ai: true, error: aiFailureMessage('The AI could not find out about this company. Try again, or add the web site and check again.') });
  const fresh = cardModel.findById(card.id)!;
  res.json({ check, ai_rate: fresh.ai_rate, ai_rate_reason: fresh.ai_rate_reason, website: fresh.website, email: fresh.email });
});

// Look the ticked companies up on the web: a company with a web site gets it, the others are marked "no web site".
router.post('/find-websites', requireAdmin, needAi, (req: AuthedRequest, res) => {
  const ids = Array.isArray(req.body?.ids) ? (req.body.ids as unknown[]).map((n) => Math.trunc(Number(n))).filter((n) => Number.isFinite(n)).slice(0, 2000) : [];
  const mine = { countries: myCountryKeys(req.user!.display_name), cities: myCityKeys(req.user!.display_name) };
  const allowed = ids.filter((id) => {
    const c = cardModel.findById(id);
    return !!c && canDeleteCard(req.user!, c, mine) && !(c.website ?? '').trim();
  });
  if (!allowed.length) return res.status(400).json({ error: 'Tick leads without a web site that you look after.' });
  res.json(startWebsiteSearch(allowed));
});
router.get('/website-status', (_req, res) => {
  res.json(websiteStatus());
});

// The customer list, one page at a time, filtered in the database (the customer database has ~40,000 rows).
// Is this person (a WhatsApp number, an e-mail, a company name) a customer already? Then they become the second contact, not a second customer.
router.get('/find-by-contact', (req: AuthedRequest, res) => {
  const digits = (v: unknown) => String(v ?? '').replace(/\D/g, '');
  const phone = digits(req.query.phone).slice(-9);
  const email = String(req.query.email ?? '').trim().toLowerCase().split(/[,;\s]+/)[0] ?? '';
  const company = String(req.query.company ?? '').trim();
  const hits = new Map<number, { id: number; company: string | null; name: string | null; match: string }>();
  const add = (id: number, how: string) => { if (hits.has(id)) return; const c = cardModel.findById(id); if (c && canSeeCard(req.user, c)) hits.set(id, { id, company: c.company, name: c.name, match: how }); };
  if (phone.length >= 7) {
    for (const r of db.prepare("SELECT id, tel, mobile FROM cards WHERE COALESCE(tel,'') != '' OR COALESCE(mobile,'') != ''").all() as { id: number; tel: string | null; mobile: string | null }[]) if (digits(r.tel).endsWith(phone) || digits(r.mobile).endsWith(phone)) add(r.id, 'phone');
    for (const r of db.prepare("SELECT card_id AS id, tel, mobile FROM card_contacts WHERE COALESCE(tel,'') != '' OR COALESCE(mobile,'') != ''").all() as { id: number; tel: string | null; mobile: string | null }[]) if (digits(r.tel).endsWith(phone) || digits(r.mobile).endsWith(phone)) add(r.id, 'phone');
  }
  if (email.includes('@')) {
    for (const r of db.prepare('SELECT id FROM cards WHERE LOWER(email) LIKE ?').all(`%${email}%`) as { id: number }[]) add(r.id, 'email');
    for (const r of db.prepare('SELECT card_id AS id FROM card_contacts WHERE LOWER(email) LIKE ?').all(`%${email}%`) as { id: number }[]) add(r.id, 'email');
  }
  if (company.length >= 3) for (const r of db.prepare('SELECT id FROM cards WHERE company_key = ? LIMIT 5').all(companyKey(company)) as { id: number }[]) add(r.id, 'company');
  res.json({ rows: [...hits.values()].slice(0, 5).map((h) => ({ ...h, hasFirstContact: !!(cardModel.findById(h.id)?.name ?? '').trim(), contacts: contactModel.list(h.id).length })) });
});

router.get('/page', (req: AuthedRequest, res) => {
  const page = Math.max(1, parseInt(String(req.query.page ?? '1'), 10) || 1);
  const pageSize = Math.min(200, Math.max(10, parseInt(String(req.query.pageSize ?? '50'), 10) || 50));
  const { rows, total } = cardModel.searchPaged({ ...listQuery(req), page, pageSize });
  const mine = { countries: myCountryKeys(req.user!.display_name), cities: myCityKeys(req.user!.display_name) };
  const sent = groupByCard(offerLogModel.listForCards(rows.map((c) => c.id)));
  // when somebody last wrote a note, called or visited each of these customers
  const ids = rows.map((c) => Math.trunc(c.id)).join(',') || '0';
  const last = new Map(
    (db
      .prepare(`SELECT card_id, MAX(created_at) AS at FROM activities WHERE card_id IN (${ids}) AND type IN ('note', 'call', 'visit', 'meeting', 'sample') GROUP BY card_id`)
      .all() as { card_id: number; at: string }[]).map((r) => [r.card_id, r.at])
  );
  // the money of each customer that has an SAP account (strict: only the accounts this person may see, and only when sales figures are switched on for them)
  const accts = new Map<number, { health: string; ytd: number; prevYtd: number; balance: number; overdue: number; currency: string }>();
  try {
    const pm = (req.user as { perms?: { money: string[] } | null }).perms;
    if (!pm || pm.money.includes('ledger')) {
      const sets = setsFor(req.user!);
      for (const a of [...sets.live, ...sets.dead]) if (a.cardId) accts.set(a.cardId, { health: a.health, ytd: Math.round(a.ytd), prevYtd: Math.round(a.prevYtd), balance: Math.round(a.balance), overdue: Math.round(a.overdue), currency: a.currency });
    }
  } catch (err) { console.error('List money failed:', err); }
  res.json({
    page,
    pageSize,
    total,
    items: rows.map((c) => ({
      ...c,
      money: accts.get(c.id) ?? null,
      field_status: JSON.parse(c.field_status),
      interest: interestOf(c),
      insight: parseInsight(c.ai_insight),
      offer_wanted: offerWanted(c),
      bulgaria_candidate: bulgariaWanted(c),
      follow_up: followUpFor(c, sent.get(c.id) ?? []),
      last_contact_at: last.get(c.id) ?? null,
      can_delete: canDeleteCard(req.user!, c, mine) || canJunkCard(req.user!, c, mine),
      wa: whatsappLink(c, req.user!.display_name || req.user!.username),
    })),
  });
});

router.get('/', (req: AuthedRequest, res) => {
  const exhibitionId = req.query.exhibitionId ? parseInt(req.query.exhibitionId as string, 10) : undefined;
  const text = (req.query.q as string) || undefined;
  const country = (req.query.country as string) || undefined;
  const isAdmin = req.user!.role === 'admin';
  const cards = cardModel.search({
    exhibitionId,
    text,
    country,
    visibleTo: req.user!,
  });
  // What we have done with each customer: offer, documents, thank-you only, or nothing.
  const sent = groupByCard(offerLogModel.listForIdSet(new Set(cards.map((c) => c.id))));
  res.json(cards.map((c) => ({ ...c, field_status: JSON.parse(c.field_status), interest: interestOf(c), insight: parseInsight(c.ai_insight), offer_wanted: offerWanted(c), bulgaria_candidate: bulgariaWanted(c), follow_up: followUpFor(c, sent.get(c.id) ?? []) })));
});

router.get('/:id', (req: AuthedRequest, res) => {
  const card = cardModel.findById(parseInt(String(req.params.id), 10));
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  res.json({ ...card, boards: boardsOf(card.id), field_status: JSON.parse(card.field_status), interest: interestOf(card), insight: parseInsight(card.ai_insight), wa: whatsappLink(card, req.user!.display_name || req.user!.username) });
});

router.patch('/:id', (req: AuthedRequest, res) => {
  const id = parseInt(String(req.params.id), 10);
  const existing = cardModel.findById(id);
  if (!existing) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, existing)) return res.status(403).json({ error: 'You do not have access to this record' });
  const body = { ...(req.body || {}) };
  // which team a customer belongs to is for an admin to say
  if (req.user!.role !== 'admin') { delete body.market; delete body.sap; }
  // who looks after a customer can be chosen when the form is scanned and checked; after it is saved only an admin changes it
  if (req.user!.role !== 'admin' && existing.status === 'confirmed' && body.person !== undefined && (body.person || null) !== (existing.person || null)) {
    return res.status(403).json({ error: 'Only an admin can change who looks after this customer once it is saved.' });
  }
  // Staff fixed the city of a domestic customer and no person is set: suggest the city's owner.
  const marketAfter = body.market === undefined ? existing.market : asMarket(body.market);
  const personNow = body.person === undefined ? existing.person : body.person;
  if (marketAfter === 'domestic' && body.city && !personNow) {
    const owner = cityModel.findByCity(String(body.city))?.responsible;
    if (owner) body.person = owner;
  }
  // Staff fixed the country and no person is set: suggest the country's owner.
  if (marketAfter === 'domestic') body.country = body.country ?? existing.country;
  // A person that is already there (or typed in this save) is left alone.
  const personAfter = body.person === undefined ? existing.person : body.person;
  if (marketAfter !== 'domestic' && body.country && countryKey(String(body.country)) !== countryKey(existing.country ?? '') && !personAfter) {
    const owner = countryModel.findByCountry(String(body.country))?.responsible;
    if (owner) body.person = owner;
  }
  // phone numbers are written with + and the country code (when they are valid)
  const placeNow = (body.country === undefined ? existing.country : body.country) as string | null;
  if (typeof body.tel === 'string') body.tel = tidyPhones(body.tel, placeNow);
  if (typeof body.mobile === 'string') body.mobile = tidyPhones(body.mobile, placeNow);
  const updated = cardModel.update(id, body);
  if (updated && (body.notes !== undefined || body.interested_in !== undefined || body.work_area !== undefined)) applyNotesToBoards(id, updated.notes, updated.interested_in, updated.work_area);
  auditDiff(req.user, existing as unknown as Record<string, unknown>, updated as unknown as Record<string, unknown>);
  if (body.stage !== undefined) followLegacyStage(id);
  refreshOwnerOverride(id);
  // a person's own rating counts for the points of the mission board
  if (updated && body.rate !== undefined && updated.rate !== null && (existing.rate ?? null) !== updated.rate) activityModel.add({ userId: req.user!.id, cardId: id, type: 'rated', text: `Rated ${updated.rate}/10` });
  if (updated && (existing.stage ?? '') !== (updated.stage ?? '')) {
    activityModel.add({ userId: req.user!.id, cardId: id, type: 'stage', text: `${existing.stage ?? 'visitor'} -> ${updated.stage ?? 'visitor'}` });
  }
  // the customer's discount level moved: kept for their "Price changes" file
  if (updated && (existing.offer_percent ?? 0) !== (updated.offer_percent ?? 0)) {
    logDiscountChange(id, req.user!.display_name || req.user!.username, existing.offer_percent, updated.offer_percent);
  }
  syncCustomerFolder(id);
  res.json({ ...updated!, field_status: JSON.parse(updated!.field_status), interest: interestOf(updated!) });
});

// Re-runs AI extraction against the already-stored photo, in place - lets
// staff recover from a transient Gemini failure (e.g. a 503) without
// re-photographing the form or creating a duplicate record.
router.post('/:id/retry-extraction', async (req: AuthedRequest, res) => {
  const id = parseInt(String(req.params.id), 10);
  const card = cardModel.findById(id);
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });

  // visitors imported from a badge export have no photo to read
  if (!card.image_path) return res.status(400).json({ error: 'This record has no photo to read - it was imported, not scanned.' });
  const imagePath = path.join(paths.uploadsDir, card.image_path);
  try {
    const { result, model } = await extractCardFromImage(imagePath);
    const withOwner = applyCountryDefaults(result.fields, result.fieldStatus);
    const updated = cardModel.applyExtraction(id, {
      fields: withOwner.fields,
      fieldStatus: withOwner.status,
      extractionModel: model,
      extractionError: null,
      insight: result.insight ?? null,
    })!;
    syncCustomerFolder(id);
    res.json({ ...updated, field_status: JSON.parse(updated.field_status), interest: interestOf(updated), insight: parseInsight(updated.ai_insight), extractionError: null });
  } catch (err) {
    console.error('Retry extraction failed:', err);
    const extractionError = (err as Error).message;
    cardModel.setExtractionError(id, extractionError);
    const updated = cardModel.findById(id)!;
    res.json({ ...updated, field_status: JSON.parse(updated.field_status), interest: interestOf(updated), insight: parseInsight(updated.ai_insight), extractionError });
  }
});

// Reads the notes again (also for visitors imported without a photo) and refreshes what the AI
// suggests: thank-you, offer, products, reminder. Nothing the staff typed is overwritten.
router.post('/:id/analyse', async (req: AuthedRequest, res) => {
  const id = parseInt(String(req.params.id), 10);
  const card = cardModel.findById(id);
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  if (!useAi(req.user!, res)) return;
  const interest = interestOf(card);
  const insight = await runForCard(id, () => analyseCard(card, { products: interest.products, widths: interest.widths, other: interest.other || null }));
  cardModel.setInsight(id, insight);
  if (insight.source === 'ai') logAi(id, 'AI read the notes again and wrote the insight (products, offer, reminder)');
  // and what the company's own web site says
  await runForCard(id, () => enrichCompany(id));
  const updated = cardModel.findById(id)!;
  res.json({ ...updated, field_status: JSON.parse(updated.field_status), interest: interestOf(updated), insight: parseInsight(updated.ai_insight) });
});

// What people do with a customer is kept (and feeds the daily team report). A lead that is worked on is
// no longer "just a lead".
function logActivity(user: NonNullable<AuthedRequest['user']>, card: CardRow, type: ActivityType, text: string | null, photos: string[] = []): number {
  const activityId = activityModel.add({ userId: user.id, cardId: card.id, type, text, photos });
  if (card.stage === 'lead' && type !== 'stage' && type !== 'created' && type !== 'scan') {
    cardModel.update(card.id, { stage: 'contacted' });
    followLegacyStage(card.id);
    activityModel.add({ userId: user.id, cardId: card.id, type: 'stage', text: 'Lead -> Contacted' });
  }
  return activityId;
}

// The notes and the history of one customer, newest first.
router.get('/:id/activity', (req: AuthedRequest, res) => {
  const card = cardModel.findById(parseInt(String(req.params.id), 10));
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  res.json(activityModel.forCard(card.id));
});

// A note, a call, a visit or a meeting - with text and/or photos (taken with the phone, a page of notes, the
// stand, the customer's factory). Photos are shrunk like the scans.
router.post('/:id/notes', upload.array('photos', 6), async (req: AuthedRequest, res) => {
  const card = cardModel.findById(parseInt(String(req.params.id), 10));
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  const files = (req.files as Express.Multer.File[] | undefined) ?? [];
  const text = typeof req.body?.text === 'string' ? req.body.text.trim() : '';
  const type = HUMAN_TYPES.includes(req.body?.type) ? (req.body.type as ActivityType) : 'note';
  if (!text && files.length === 0) return res.status(400).json({ error: 'Write something or add a photo.' });
  const photos: string[] = [];
  for (const f of files) photos.push(await compressScan(path.basename(f.path)));
  const noteId = logActivity(req.user!, card, type, text || null, photos);
  if (type === 'sample') createSampleFromNote(card.id, req.user!.id, text, noteId); // so a tracking number can be added to it later
  // "create a to-do to follow up in N business days"
  const followUp = parseInt(String(req.body?.followUpDays ?? ''), 10);
  if (Number.isFinite(followUp) && followUp > 0) {
    const what = text ? text.replace(/\s+/g, ' ').slice(0, 80) : 'the note';
    todoModel.add({ userId: req.user!.id, cardId: card.id, text: `Follow up: ${what}`, dueDate: addBusinessDays(todayIstanbul(), followUp) });
  }
  syncCustomerFolder(card.id);
  res.status(201).json(activityModel.forCard(card.id));
});

router.delete('/:id/notes/:activityId', (req: AuthedRequest, res) => {
  const card = cardModel.findById(parseInt(String(req.params.id), 10));
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  const a = activityModel.find(parseInt(String(req.params.activityId), 10));
  if (!a || a.cardId !== card.id) return res.status(404).json({ error: 'Not found' });
  // only what a person wrote, and only by them (or an admin)
  if (!HUMAN_TYPES.includes(a.type) || (a.userId !== req.user!.id && req.user!.role !== 'admin')) return res.status(403).json({ error: 'You can only delete your own notes.' });
  activityModel.delete(a.id);
  res.json(activityModel.forCard(card.id));
});

// An admin deletes anybody; everybody else only a "just lead" of a country (or city) they look after.
router.delete('/:id', (req: AuthedRequest, res) => {
  const id = parseInt(String(req.params.id), 10);
  const card = cardModel.findById(id);
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canDeleteCard(req.user!, card) && !canJunkCard(req.user!, card)) {
    const pm = (req.user as { perms?: { actions: string[] } | null }).perms;
    const rating = card.rate ?? (card.ai_rate_source === 'ai' ? card.ai_rate : null);
    const reason = pm && !pm.actions.includes('del') ? 'Deleting is not switched on for you. Ask the admin.'
      : card.delete_locked ? 'The admin who uploaded this list keeps its records: only an admin can delete them.'
      : isProtected(card) || (card.stage && !['lead', 'contacted', 'lost'].includes(card.stage)) ? 'This is an existing customer or an open deal and cannot be deleted. Ask an admin.'
      : rating !== null && rating !== undefined && rating >= 5 ? 'This record is rated 5 or higher, so it is important. Ask an admin to delete it.'
      : 'You can only delete records of the countries (cities) you look after, or that carry your name.';
    return res.status(403).json({ error: reason });
  }
  // an existing or important customer is never deleted for good: send it to the junk folder (it can be brought back) or merge it into another record
  if (isProtected(card)) {
    if (req.user!.role !== 'admin') return res.status(403).json({ error: 'This is an existing or important customer and cannot be deleted.' });
    moveToJunk(card, 'Moved to junk by an admin (an existing customer is never deleted for good)', req.user!.id);
    return res.json({ ok: true, junked: true });
  }
  // only an admin deletes a customer for good; anybody else's delete sends it to the junk folder (theirs and the admin's), where it can be brought back
  if (req.user!.role === 'admin') removeCard(card);
  else moveToJunk(card, 'Deleted by the sales person', req.user!.id);
  res.json({ ok: true });
});

// the shipments (export invoices) of one customer and who sends the documents: Operations (waiting / working / sent) or Sales ("do not follow" = Sales sends from their own files)
router.get('/:id/shipments', (req: AuthedRequest, res) => {
  const card = cardModel.findById(parseInt(String(req.params.id), 10));
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  if (!(card.sap ?? '').trim()) return res.json({ rows: [] });
  const rows = latestExports(365, 0).rows.filter((r) => r.cardId === card.id).map((r) => ({ key: r.key, date: r.date, invoice: r.invoice, amount: r.amount, currency: r.currency, tracked: r.days <= 45, days: r.days, state: r.docs.state, by: r.docs.by ?? null, at: r.docs.at ?? null, to: r.docs.to ?? null }));
  res.json({ rows });
});

// the invoices page of one customer: every invoice of the last year from the account ledger, paid or not, and (export invoices) who has sent the documents
router.get('/:id/invoices', (req: AuthedRequest, res) => {
  const card = cardModel.findById(parseInt(String(req.params.id), 10));
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  const sap = (card.sap ?? '').trim();
  const from = new Date(); from.setMonth(from.getMonth() - 12);
  const led = sap ? ledgerFor(sap, from.toISOString().slice(0, 10)) : null;
  const ex = new Map(latestExports(365, 0).rows.filter((r) => r.cardId === card.id).map((r) => [r.key.split('|').slice(1).join('|'), r]));
  const today = Date.now();
  const rows = (led?.rows ?? []).filter((r) => r.kind === 'invoice').map((r) => {
    const e = ex.get(`${r.date}|${r.description}`);
    return { id: r.id, date: r.date, invoice: e?.invoice ?? r.description, amount: r.amount, status: r.status, short: r.short, daysOld: Math.floor((today - Date.parse(`${r.date}T12:00:00Z`)) / 86400000), docs: e ? { key: e.key, tracked: e.days <= 45, state: e.docs.state, by: e.docs.by ?? null, to: e.docs.to ?? null } : null };
  }).sort((a, b) => b.date.localeCompare(a.date) || b.id - a.id);
  res.json({ company: card.company, sap, currency: led?.currency ?? null, summary: led?.summary ?? null, rows });
});

// CC list: the person set on this card (who may differ from the country's
// usual owner) plus the country's assistant, whoever that is.
function resolveCc(card: CardRow): { ccEmail: string | null; ccWarning: string | null } {
  const emails: string[] = [];
  const warnings: string[] = [];
  const add = (label: string, name: string | null) => {
    if (!name) return;
    const person = userModel.findByDisplayName(name);
    if (!person) return void warnings.push(`No user found for ${label} "${name}" — add them on the Users page. They will not be CC'd.`);
    if (!person.email) return void warnings.push(`${label} "${name}" has no email on file — they will not be CC'd.`);
    const email = person.email;
    if (!emails.some((e) => e.toLowerCase() === email.toLowerCase())) emails.push(email);
  };

  if (card.person) add('staff member', card.person);
  else warnings.push('No responsible person is set on this card.');
  add('assistant', countryModel.findByCountry(card.country)?.assistant ?? null);

  return { ccEmail: emails.length ? emails.join(', ') : null, ccWarning: warnings.length ? warnings.join(' ') : null };
}

// The next step for this customer (read from SAP history first, then the e-mails and notes): the customer page leads with it.
router.get('/:id/next-step', (req: AuthedRequest, res) => {
  const card = cardModel.findById(parseInt(String(req.params.id), 10));
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  const a = adviseEmailKind(card);
  res.json({ kind: a.kind, reason: a.reason, fair: a.fair, hasEmail: !!card.email?.trim() });
});

router.get('/:id/thank-you-template', (req: AuthedRequest, res) => {
  const card = cardModel.findById(parseInt(String(req.params.id), 10));
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });

  // The responsible person's own custom template (set on their user
  // account) takes priority over the generic default.
  const responsible = card.person ? userModel.findByDisplayName(card.person) : undefined;
  const customTemplate =
    responsible?.email_template_subject && responsible?.email_template_body
      ? { subject: responsible.email_template_subject, body: responsible.email_template_body }
      : null;
  const exhibition = exhibitionModel.findById(card.exhibition_id);
  const fairName = exhibition?.name ?? null;
  const exhibitionTemplate =
    exhibition?.email_template_subject && exhibition?.email_template_body
      ? { subject: exhibition.email_template_subject, body: exhibition.email_template_body }
      : null;
  const template = resolveTemplate(card, fairName, customTemplate, exhibitionTemplate);
  const { ccEmail, ccWarning } = resolveCc(card);
  res.json({
    ...template,
    // which kind of e-mail suits this customer (from the history on record), and what is wrong with the text as it stands
    advice: adviseEmailKind(card),
    problems: mailProblems({ subject: template.subject, body: template.body, kind: 'thank_you', fairName }),
    // the offer is its own email with its own text
    offer: resolveOfferTemplate(card, fairName),
    // every text the admin offers, to switch between on the send page
    choices: templateChoices(card, fairName),
    // the sender's own e-mail styles (My account), filled in for this customer
    mine: (db.prepare('SELECT id, name, kind, subject, body FROM user_texts WHERE user_id = ? ORDER BY name').all(req.user!.id) as { id: number; name: string; kind: string; subject: string; body: string }[]).map((t) => ({ id: t.id, name: t.name, kind: t.kind, ...interpolateTemplate({ subject: t.subject, body: t.body }, { card, fairName }) })),
    // added under the text of both emails, for whoever is sending
    signature: buildSignature(req.user, styleFor(req.user)).text,
    replyTo: req.user!.email,
    toEmail: splitEmails(card.email).join(', ') || card.email,
    // an offer or a proforma goes to the person who buys (when the company has several people and one is marked as purchasing)
    toPurchasing: (() => { const p = recipientsFor(card, 'purchasing'); return p.basis === 'role' ? { emails: p.emails, names: p.names } : null; })(),
    ccEmail,
    ccWarning,
    // set when the visitor's country has a distributor: the thank-you is the reply that points to them
    distributor: distributorModel.forCard(card) ?? null,
  });
});

// Suggested offer lines for this visitor, read from their "Interested in",
// "Work area" and handwritten notes. Suggestions only - staff review them.
// what an OLD customer (with uploaded SAP proformas) pays today, as the starting percentages of the offer; null for everybody else
function safeMemory(user: Parameters<typeof offerMemoryFor>[0], cardId: number, book?: PriceBook) {
  try {
    const m = offerMemoryFor(user, cardId, null);
    const own = book ? ownPrices(book, cardId) : null;
    if (!m && !own) return null;
    return { ...(m ?? { currency: own!.currency, overall: null, pagePct: {}, parts: [] }), own };
  } catch { return null; }
}
router.get('/:id/offer-recommendations', (req: AuthedRequest, res) => {
  const card = cardModel.findById(parseInt(String(req.params.id), 10));
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  const market = priceMarketFor(req.user!, card.market);
  const active = market ? activePriceBook(market) : null;
  if (!active) return res.json({ recommendations: [], suggestMoq: false, widths: [], uncovered: [], percent: null, noPriceList: market ? `No ${market === 'domestic' ? 'domestic ' : ''}price list has been uploaded yet.` : 'Your account does not have the price list of this customer\'s market.' });
  const { recommendations, suggestMoq, widths, uncovered } = recommend(card, offerCatalog(active.book.catalog));
  const design = resolveOfferStyle(card, req.user);
  res.json({ recommendations, suggestMoq: suggestMoq && active.book.hasMoq, hasMoq: active.book.hasMoq, hasPackaging: active.book.hasPackaging, widths, uncovered, percent: card.offer_percent, memory: safeMemory(req.user!, card.id, active.book), design: design.style, designFrom: design.from, customerDesign: card.offer_style ?? '' });
});

// 'combined' = one PDF with every page (the preview); 'parts' = one PDF per price page and one for MOQ
// (what is sent: the customer can forward just the PVC or just the ABS offer).
// Which design the offer is drawn in: what was chosen for this offer, else the customer's, else the sender's
// own, else the company's.
function resolveOfferStyle(card: CardRow, user: { offer_style?: string | null } | undefined, chosen?: unknown): { style: 'tece' | 'classic'; from: 'offer' | 'customer' | 'person' | 'company' } {
  const ok = (v: unknown): v is 'tece' | 'classic' => v === 'tece' || v === 'classic';
  if (ok(chosen)) return { style: chosen, from: 'offer' };
  if (ok(card.offer_style)) return { style: card.offer_style, from: 'customer' };
  if (ok(user?.offer_style)) return { style: user!.offer_style as 'tece' | 'classic', from: 'person' };
  return { style: settingsModel.get('offer_style') === 'classic' ? 'classic' : 'tece', from: 'company' };
}

async function buildOfferPdf(card: CardRow, user: NonNullable<AuthedRequest['user']>, rawOffer: unknown, mode: 'combined' | 'parts' = 'combined', styleOverride?: unknown, languageOverride?: unknown) {
  const language = isLang(languageOverride) ? languageOverride : languageOf(card);
  const market = priceMarketFor(user, card.market);
  if (!market) return { error: 'Your account does not have the price list of this customer\'s market.' } as const;
  const active = activePriceBook(market);
  if (!active) return { error: `No ${market === 'domestic' ? 'domestic ' : ''}price list has been uploaded yet - ask an admin to upload it under Price list.` } as const;
  const request = sanitiseOffer(rawOffer, active.book);
  if (!request.selections.length && !request.includeMoq) return { error: 'Add at least one product page to the offer first.' } as const;
  const render = (selections: typeof request.selections, includeMoq: boolean) =>
    renderOfferPdf({
      card,
      preparedBy: user.display_name || user.username,
      book: active.book,
      params: request.params,
      selections,
      includeMoq,
      date: new Date(),
      // the offer's look: the TECE design (default) or each worksheet as Excel draws it
      style: resolveOfferStyle(card, user, styleOverride).style,
      language,
    });
  if (mode === 'combined') return { pdf: await render(request.selections, request.includeMoq), parts: [] as { title: string; pdf: Buffer }[], request, priceListId: active.row.id } as const;
  const parts: { title: string; pdf: Buffer }[] = [];
  for (const sel of request.selections) {
    const section = active.book.catalog.find((c) => c.sheet === sel.sheet);
    const title = (section?.title ?? sel.sheet).replace(/^offer for\s+/i, '').split('|')[0].trim() || sel.sheet;
    parts.push({ title, pdf: await render([sel], false) });
  }
  if (request.includeMoq) parts.push({ title: 'MOQ', pdf: await render([], true) });
  return { pdf: null, parts, request, priceListId: active.row.id } as const;
}

router.post('/:id/offer-preview', async (req: AuthedRequest, res) => {
  const card = cardModel.findById(parseInt(String(req.params.id), 10));
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  try {
    const built = await buildOfferPdf(card, req.user!, req.body?.offer, 'combined', req.body?.style ?? req.body?.offer?.style, req.body?.offer?.language);
    if ('error' in built) return res.status(400).json({ error: built.error });
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'inline; filename="offer-preview.pdf"');
    res.send(built.pdf);
  } catch (err) {
    console.error('Offer preview failed:', err);
    res.status(500).json({ error: 'Could not build the offer PDF.' });
  }
});

// What went out, in words and numbers, kept with the record: the price
// increase / decrease percentage, currency, which pages (with their surcharge),
// the attachments and the subject.
function offerSummary(
  sentTo: string | null,
  subject: string,
  offer: { params: unknown; selections: unknown } | null,
  documentTitles: string[],
  market = 'export'
): OfferSummary {
  const params = (offer?.params ?? {}) as { transportPct?: number; currency?: 'EUR' | 'USD'; usdRate?: number; adjust?: Record<string, number>; includeMoq?: boolean; pagePct?: Record<string, number>; widths?: number[] };
  const selections = (Array.isArray(offer?.selections) ? offer!.selections : []) as { sheet: string; rows: unknown[] }[];
  const catalog = activePriceBook(market)?.book.catalog ?? [];
  return {
    subject,
    sentTo,
    percent: offer ? params.transportPct ?? 0 : null,
    currency: offer ? params.currency ?? null : null,
    usdRate: offer && params.currency === 'USD' ? params.usdRate ?? null : null,
    pages: selections.map((s) => {
      const section = catalog.find((c) => c.sheet === s.sheet);
      const all = section?.rows.length ?? s.rows.length;
      return {
        title: (section?.title ?? s.sheet).replace(/^offer for\s+/i, '').split('|')[0].trim(),
        surcharge: section?.adjustLabel ? params.adjust?.[s.sheet] ?? null : null,
        products: s.rows.length === all ? 'all products' : `${s.rows.length} of ${all} products`,
        percent: params.pagePct?.[s.sheet] ?? params.transportPct ?? 0,
      };
    }),
    widths: offer ? params.widths : undefined,
    includeMoq: !!params.includeMoq,
    attachments: documentTitles,
  };
}

// Everything that has been sent to this customer with a price offer or documents.
router.get('/:id/offers', (req: AuthedRequest, res) => {
  const card = cardModel.findById(parseInt(String(req.params.id), 10));
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  const entries = offerLogModel.listForCard(card.id);
  res.json({ followUp: followUpFor(card, entries), entries });
});

// Test mode: the address everything goes to ('' = nowhere to send a test to, null = a real send).
function testAddress(req: AuthedRequest): string | null {
  const wanted = req.body?.test === true || settingsModel.get('test_mode') === '1';
  if (!wanted) return null;
  return settingsModel.get('test_email') || req.user?.email || '';
}

// Two separate emails go to a customer: the thank-you note, and the offer (with
// documents). Same pipeline, different content and different bookkeeping.
async function handleSend(kind: 'thank_you' | 'offer' | 'personal' | 'proforma', req: AuthedRequest, res: Response) {
  const id = parseInt(String(req.params.id), 10);
  const card = cardModel.findById(id);
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  // a customer with an old debt of €10,000 or more gets no new offer or proforma until an admin lifts the hold (see services/perfAnalytics.ts)
  if (kind === 'offer' || kind === 'proforma') {
    const hold = holdOfCard(card.id);
    if (hold) return res.status(403).json({ error: `CREDIT HOLD: this customer owes €${Math.round(hold.balance).toLocaleString('en-US')} and has not shipped for 12 months. New quotes and orders are blocked until an admin lifts the hold (Performance page).`, hold: true });
    // a black account (pays very late) is not blocked, but the sender has to confirm that they know
    const black = blackOfCard(card.id);
    if (black && req.body?.riskAcknowledged !== true && req.body?.test !== true) {
      return res.status(409).json({ error: `BLACK ACCOUNT: this customer pays very late (${Math.round(black.overdue).toLocaleString('en-US')} ${black.currency} is overdue, the oldest invoice by ${black.oldestOver} days). Please check with finance before you send a new offer or proforma.`, risk: true });
    }
  }
  // Staff can add or remove addresses on the send page (To and CC). Without that,
  // the visitor's own address(es) - there may be two from two business cards - and
  // the usual CC (the person on the card and the country's assistant) are used.
  const asList = (value: unknown): string[] | null =>
    Array.isArray(value) ? splitEmails(value.map(String).join(',')) : typeof value === 'string' ? splitEmails(value) : null;
  const recipients = asList(req.body?.to) ?? splitEmails(card.email);
  if (!recipients.length) {
    return res.status(400).json({
      error: req.body?.to !== undefined
        ? 'Add at least one valid email address under To.'
        : card.email ? 'The visitor email on this card is not a valid address' : 'This card has no visitor email on file',
    });
  }

  // a personal e-mail written in the rich editor: the cleaned HTML is the e-mail, the plain text goes along with it
  const html = kind === 'personal' && typeof req.body?.html === 'string' ? sanitizeHtml(req.body.html) : '';
  const subject = req.body?.subject;
  const body = html ? htmlToPlain(html) : req.body?.body;
  // Test mode (admin switch) or a test send from the page: everything goes to the test address and nothing is recorded
  const testTo = testAddress(req);
  if (testTo === '') return res.status(400).json({ error: 'There is no test address. Add your e-mail under My account, or set one under Email texts (test mode).' });
  // a thank-you note carries no offer and no documents
  const offer = kind === 'offer' ? req.body?.offer : undefined;
  const attachmentIds = kind === 'offer' || kind === 'personal' ? req.body?.attachmentIds : [];
  if (!subject || !body) {
    return res.status(400).json({ error: 'subject and body are required' });
  }

  const toLower = new Set(recipients.map((r) => r.toLowerCase()));
  const distributorMail = distributorModel.forCountry(card.country)?.email?.toLowerCase() ?? null;
  // the distributor is never copied in on an offer; and not at all on a customer kept direct (TECE works them itself, no exclusivity)
  const ccList = (asList(req.body?.cc) ?? splitEmails(resolveCc(card).ccEmail ?? '')).filter((c) => !toLower.has(c.toLowerCase()) && !(distributorMail && (kind !== 'thank_you' || card.handling === 'direct') && c.toLowerCase() === distributorMail));

  // Attachments: the generated offer PDF (re-priced here from the workbook,
  // never trusted from the browser) plus any library documents ticked.
  const attachments: EmailAttachment[] = [];
  let offerRecord: { params: unknown; selections: unknown; priceListId: number } | null = null;
  let sentDocTitles: string[] = [];
  const generatedTitles: string[] = [];
  let sentProforma: { title: string; value: number; currency: string } | null = null;
  let offerParts: { title: string; pdf: Buffer }[] = [];
  try {
    if (offer) {
      const built = await buildOfferPdf(card, req.user!, offer, 'parts', (offer as { style?: unknown } | undefined)?.style, (offer as { language?: unknown } | undefined)?.language);
      if ('error' in built) return res.status(400).json({ error: built.error });
      offerParts = built.parts;
      const date = new Date().toISOString().slice(0, 10).replace(/-/g, '');
      // one PDF per price page (PVC, ABS ...) and one for MOQ
      for (const part of built.parts) {
        attachments.push({
          filename: `TECE-${asciiSlug(part.title)}-offer-${asciiSlug(card.company || card.name || 'customer')}-${date}.pdf`,
          content: part.pdf,
          contentType: 'application/pdf',
        });
      }
      offerRecord = {
        params: { ...built.request.params, includeMoq: built.request.includeMoq },
        selections: built.request.selections,
        priceListId: built.priceListId,
      };
    }

    // The MOQ pages and the packaging details are documents made from the price list; they are ticked with the other documents
    const generatedKinds = kind === 'offer' && Array.isArray(req.body?.generatedDocs) ? ([...new Set(req.body.generatedDocs)].filter((k) => k === 'moq' || k === 'packaging') as ('moq' | 'packaging')[]) : [];
    if (generatedKinds.length) {
      const market = priceMarketFor(req.user!, card.market);
      const active = market ? activePriceBook(market) : null;
      if (!active) return res.status(400).json({ error: 'There is no price list to make the MOQ or packaging pages from.' });
      const docLanguage = isLang((offer as { language?: unknown } | undefined)?.language) ? (offer as { language: Lang }).language : isLang(req.body?.language) ? (req.body.language as Lang) : languageOf(card);
      const styleCtx = { name: card.name, company: card.company, address: card.address, country: card.country, tel: card.tel, email: card.email, preparedBy: req.user!.display_name || req.user!.username, date: new Date() };
      const date = new Date().toISOString().slice(0, 10).replace(/-/g, '');
      for (const g of generatedKinds) {
        if (g === 'moq' ? !active.book.hasMoq : !active.book.hasPackaging) continue;
        const pdf = await renderDocumentPdf(active.book, g, active.book.defaults, styleCtx, docLanguage);
        const title = g === 'moq' ? 'MOQ' : 'Packaging details';
        generatedTitles.push(title);
        attachments.push({ filename: `TECE-${asciiSlug(title)}-${date}.pdf`, content: pdf, contentType: 'application/pdf' });
      }
    }

    // a proforma made on the Proforma tab goes as a PDF (and, when asked, the Excel with the SAP order sheet), like the offer
    if (kind === 'proforma') {
      const data = proformaWithMemory(cleanProformaData(req.body?.data), card);
      if (!data.lines.some((l) => l.sap || l.description || l.meters)) return res.status(400).json({ error: 'The proforma has no lines yet.' });
      const pMarket = priceMarketFor(req.user!, card.market);
      const pBook = pMarket ? activePriceBook(pMarket)?.book ?? null : null;
      const pdf = await renderProformaPdf(data, pBook, req.body?.style === 'standard' ? 'standard' : 'tece');
      const who = data.header.company || data.header.name || card.company || 'customer';
      attachments.push({ filename: proformaFileName(who, 'pdf'), content: pdf, contentType: 'application/pdf' });
      if (req.body?.withExcel === true) attachments.push({ filename: proformaFileName(who, 'xlsx'), content: await renderProformaXlsx(data, pBook), contentType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      generatedTitles.push('Proforma');
      if (!testTo) {
        const priced = priceProformaLines(data, pBook);
        sentProforma = { title: `Proforma ${who}`, value: priced.totals.grand, currency: data.currency };
        reviewProforma(req.user!, card, data, pBook);
      }
      if (!testTo) { saveOfferPdf(id, pdf, null, 'Proforma'); archivePdf({ kind: 'proforma', cardId: id, title: `Proforma sent to ${who}`, fileName: proformaFileName(who, 'pdf'), pdf, userId: req.user!.id }); }
    }

    const wantedIds = (Array.isArray(attachmentIds) ? attachmentIds : []).filter((n): n is number => Number.isInteger(n));
    const docs = libraryModel.findMany(wantedIds);
    if (docs.length !== new Set(wantedIds).size) {
      return res.status(400).json({ error: 'One of the selected documents is no longer in the library - refresh and try again.' });
    }
    sentDocTitles = [...generatedTitles, ...docs.map((d) => d.title)];
    for (const doc of docs) {
      const full = path.join(paths.libraryDir, doc.stored_name);
      if (!fs.existsSync(full)) return res.status(400).json({ error: `The file for "${doc.title}" is missing on the server.` });
      attachments.push({ filename: doc.original_name, path: full, contentType: doc.mime_type });
    }

    const totalBytes = attachments.reduce((sum, a) => sum + (a.content?.length ?? (a.path ? fs.statSync(a.path).size : 0)), 0);
    if (totalBytes > MAX_ATTACHMENT_BYTES) {
      return res.status(400).json({
        error: `Attachments total ${(totalBytes / 1048576).toFixed(1)} MB - the limit is ${MAX_ATTACHMENT_BYTES / 1048576} MB. Untick a document.`,
      });
    }

    if (kind === 'offer' && !offerRecord && attachments.length === 0) {
      return res.status(400).json({ error: 'Add the price offer or a document to send.' });
    }

    // Replies go to the person sending, not to the company mailbox; their
    // signature is added under the text.
    await sendThankYouEmail({
      to: recipients.join(', '),
      cc: ccList.join(', ') || null,
      subject,
      body,
      bodyHtml: html || undefined,
      attachments,
      replyTo: req.user!.email,
      signature: buildSignature(req.user, styleFor(req.user)),
      testTo: testTo || null,
      record: { cardId: id, userId: req.user!.id, kind: offerRecord ? 'offer' : attachments.length ? 'documents' : kind },
    });
    if (testTo) return res.json({ test: true, sentTo: testTo });
  } catch (err) {
    if (err instanceof MailBlockedError) return res.status(422).json({ error: err.message, problems: err.problems });
    console.error('Send thank-you failed:', err);
    return res.status(502).json({ error: 'Failed to send email', message: (err as Error).message });
  }

  // Every email is kept in the customer's history: a price offer, documents
  // only, or just the thank-you note.
  // an offer or a proforma that went out is an opportunity to follow (made once)
  if (offerRecord || sentProforma) {
    addOpportunity({ cardId: id, kind: sentProforma ? 'proforma' : 'offer', title: sentProforma?.title ?? `Offer: ${(offerRecord!.selections as { sheet: string }[]).map((s) => s.sheet.replace(/ M2.*$/i, '')).join(', ').slice(0, 100) || subject}`, value: sentProforma?.value ?? null, currency: sentProforma?.currency, userId: req.user!.id });
  }
  offerLogModel.record({
    cardId: id,
    priceListId: offerRecord?.priceListId ?? null,
    createdBy: req.user!.id,
    params: offerRecord?.params ?? null,
    selections: offerRecord?.selections ?? [],
    attachmentIds: (Array.isArray(attachmentIds) ? attachmentIds : []).filter((n): n is number => Number.isInteger(n)),
    summary: offerSummary(recipients.join(', '), subject, offerRecord && generatedTitles.includes('MOQ') ? { ...offerRecord, params: { ...(offerRecord.params as object), includeMoq: true } } : offerRecord, sentDocTitles, card.market),
    kind: offerRecord ? 'offer' : attachments.length ? 'documents' : kind === 'personal' ? 'personal' : 'thank_you',
  });

  activityModel.add({
    userId: req.user!.id,
    cardId: id,
    type: offerRecord ? 'offer' : attachments.length ? 'documents' : kind === 'personal' ? 'email' : 'thank_you',
    text: offerRecord
      ? `${(offerRecord.selections as { sheet: string }[]).map((s) => s.sheet.replace(/ M2.*$/i, '')).join(', ')}${(offerRecord.params as { transportPct?: number }).transportPct ? ` (${Math.round(((offerRecord.params as { transportPct?: number }).transportPct ?? 0) * 1000) / 10} %)` : ''}`
      : subject,
  });
  if (card.stage === 'lead') {
    cardModel.update(id, { stage: 'contacted' });
    followLegacyStage(id);
    activityModel.add({ userId: req.user!.id, cardId: id, type: 'stage', text: 'lead -> contacted' });
  }
  // An introduction to a potential customer keeps the lead alive: it stays a lead (contacted), the e-mail is on its history, and a follow-up in 7 days is set
  // (unless a date is already there), so the radar and the follow-up list bring it back if nobody answers.
  if (kind === 'personal' && req.body?.intro === true && req.body?.test !== true) {
    const fresh = cardModel.findById(id);
    if (fresh && ['lead', 'contacted'].includes(fresh.stage ?? 'lead') && !fresh.exit_status && !fresh.follow_up_date) {
      db.prepare("UPDATE cards SET follow_up_date = date('now', '+7 days'), updated_at = datetime('now') WHERE id = ?").run(id);
      activityModel.add({ userId: req.user!.id, cardId: id, type: 'note', text: 'Introduction e-mail sent. Follow-up set in 7 days.' });
    }
  }

  // a potential customer who has now been sent an offer is at the "offer sent" step
  if (offerRecord && !['quoted', 'customer', 'lost'].includes(cardModel.findById(id)?.stage ?? '')) {
    const before = cardModel.findById(id)?.stage ?? null;
    cardModel.update(id, { stage: 'quoted' });
    followLegacyStage(id); // sending an offer moves a prospect to stage 5 (offer / negotiation)
    activityModel.add({ userId: req.user!.id, cardId: id, type: 'stage', text: `${before ?? 'visitor'} -> quoted` });
  }

  // Only the thank-you note counts as "thank-you sent"; an offer is tracked in the history.
  if (kind === 'thank_you') cardModel.markThankYouSent(id);

  // The customer's folder keeps the offer exactly as the customer received it.
  const sentParams = offerRecord?.params as { transportPct?: number; widths?: number[] } | undefined;
  if (offerParts.length) {
    for (const part of offerParts) saveOfferPdf(id, part.pdf, sentParams?.transportPct ?? null, part.title);
    // What was sent stays on the customer: the discount / addition, the pages (as ticked products)
    // and the edge widths, so the record and the next offer start from it.
    const sentSheets = new Set((offerRecord?.selections as { sheet: string }[]).map((s) => s.sheet));
    const sentProducts = INTEREST_PRODUCTS.filter((p) => p.sheet && sentSheets.has(p.sheet)).map((p) => p.key);
    cardModel.update(id, {
      offerPercent: sentParams?.transportPct ?? 0,
      interestProducts: [...new Set([...interestOf(card).products, ...sentProducts])],
      interestWidths: sentParams?.widths,
    });
    syncCustomerFolder(id);
  } else syncCustomerFolder(id);

  const updated = cardModel.findById(id)!;
  res.json({ ...updated, field_status: JSON.parse(updated.field_status), interest: interestOf(updated), insight: parseInsight(updated.ai_insight) });
}

// Passes a contact to the Bulgaria office (TECE Dekor Ltd, Asli): an e-mail with the customer's
// details and what they asked for, copied to the sender. Sent when somebody presses the button.
const BULGARIA_CONTACT = 'asli.kaya@tecedekor.eu';
router.post('/:id/send-to-bulgaria', async (req: AuthedRequest, res) => {
  const id = parseInt(String(req.params.id), 10);
  const card = cardModel.findById(id);
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  const to = settingsModel.get('bulgaria_email') || BULGARIA_CONTACT;
  const testTo = testAddress(req);
  if (testTo === '') return res.status(400).json({ error: 'There is no test address. Add your e-mail under My account.' });
  const insight = parseInsight(card.ai_insight);
  const fair = exhibitionModel.findById(card.exhibition_id)?.name ?? '';
  const sender = req.user!.display_name || req.user!.username;
  const interest = interestOf(card);
  const line = (label: string, value: string | null | undefined) => (value && String(value).trim() ? `${label}: ${String(value).trim()}` : null);
  const body = [
    'Hello Asli,',
    `I am passing you a contact${fair ? ` from ${fair}` : ''} for the Kronospan collection (small quantity).`,
    [
      line('Company', card.company),
      line('Contact', [card.name, card.position].filter(Boolean).join(', ')),
      line('Country', card.country),
      line('Email', card.email),
      line('Phone', card.tel),
      line('Address', card.address),
      line('Interested in', [interestLabel(card), interest.widths.length ? interest.widths.join(', ') + ' mm' : ''].filter(Boolean).join(' - ')),
    ].filter(Boolean).join('\n'),
    insight?.bulgariaReason ? `Why Bulgaria: ${insight.bulgariaReason}` : '',
    card.notes ? `Notes from the stand: ${card.notes}` : '',
    insight?.summary ? `In short: ${insight.summary}` : '',
    insight?.companyProfile ? `About the company: ${insight.companyProfile}` : '',
    `Met by: ${card.person || sender}`,
    'Please contact them directly. Thank you.',
    'Best wishes',
  ].filter(Boolean).join('\n\n');
  try {
    await sendThankYouEmail({
      to,
      cc: req.user!.email || null,
      subject: `Contact for the Kronospan collection - ${card.company || card.name || 'customer'}${card.country ? ` (${card.country})` : ''}`,
      body,
      replyTo: req.user!.email,
      signature: buildSignature(req.user, styleFor(req.user)),
      testTo: testTo || null,
      record: { cardId: id, userId: req.user!.id, kind: 'bulgaria' },
    });
    if (testTo) return res.json({ test: true, sentTo: testTo });
  } catch (err) {
    console.error('Sending to the Bulgaria office failed:', err);
    return res.status(502).json({ error: 'Failed to send email', message: (err as Error).message });
  }
  cardModel.markBulgariaSent(id);
  activityModel.add({ userId: req.user!.id, cardId: id, type: 'bulgaria', text: 'Details sent to the Bulgaria office' });
  const updated = cardModel.findById(id)!;
  res.json({ ...updated, field_status: JSON.parse(updated.field_status), interest: interestOf(updated), insight: parseInsight(updated.ai_insight), sentTo: to });
});

// Several customers to Asli in ONE e-mail: a PDF with a page-section for each (details, what they asked for, every note), tick them in the list and press "Send to Asli".
router.post('/bulk-send-to-bulgaria', async (req: AuthedRequest, res) => {
  const ids = [...new Set((Array.isArray(req.body?.ids) ? (req.body.ids as unknown[]) : []).map((n) => Math.trunc(Number(n))).filter((n) => Number.isFinite(n)))].slice(0, 60);
  const cards = ids.map((i) => cardModel.findById(i)).filter((c): c is CardRow => !!c && canAccessCard(req.user, c));
  if (!cards.length) return res.status(400).json({ error: 'Tick at least one customer.' });
  const testTo = testAddress(req);
  if (testTo === '') return res.status(400).json({ error: 'There is no test address. Add your e-mail under My account.' });
  const to = settingsModel.get('bulgaria_email') || BULGARIA_CONTACT;
  const sender = req.user!.display_name || req.user!.username;
  const sections = cards.map((card) => {
    const insight = parseInsight(card.ai_insight);
    const interest = interestOf(card);
    const brands = boardsOf(card.id).map((b) => b.name).join(', ');
    const rows: string[][] = ([
      ['Contact', [card.name, card.position].filter(Boolean).join(', ')], ['Country', [card.city, card.country].filter(Boolean).join(', ')], ['E-mail', card.email ?? ''], ['Phone', [card.tel, card.mobile].filter(Boolean).join(' / ')],
      ['Web site', card.website ?? ''], ['Address', card.address ?? ''], ['Interested in', [interestLabel(card), interest.widths.length ? interest.widths.join(', ') + ' mm' : ''].filter(Boolean).join(' - ')], ['Panel interest', brands],
      ['Why Asli', insight?.bulgariaReason ?? ''], ['Notes', card.notes ?? ''], ['In short', insight?.summary ?? ''], ['Met by', card.person || sender],
    ] as string[][]).filter((r) => r[1] && String(r[1]).trim());
    return { heading: card.company || card.name || `Customer #${card.id}`, columns: [{ label: 'Detail', w: 110 }, { label: '', w: 420 }], rows };
  });
  const pdf = await renderTablePdf({ title: 'Contacts for Asli', subtitle: `${cards.length} contacts · from ${sender} · ${new Date().toLocaleDateString('en-GB')}`, sections, landscape: false });
  try {
    await sendThankYouEmail({
      to, cc: req.user!.email || null, subject: `${cards.length} contacts for the Kronospan collection - ${sender}`,
      body: ['Hello Asli,', `I am passing you ${cards.length} contacts (details and notes are in the attached PDF): ${cards.map((c) => c.company || c.name).filter(Boolean).slice(0, 12).join(', ')}${cards.length > 12 ? ' ...' : ''}.`, 'Please contact them directly. Thank you.', 'Best wishes'].join('\n\n'),
      attachments: [{ filename: `contacts-for-asli-${new Date().toISOString().slice(0, 10)}.pdf`, content: pdf, contentType: 'application/pdf' }],
      replyTo: req.user!.email, signature: buildSignature(req.user, styleFor(req.user)), testTo: testTo || null,
      record: { cardId: cards[0].id, userId: req.user!.id, kind: 'bulgaria' },
    });
  } catch (err) {
    console.error('Sending the contacts to the Bulgaria office failed:', err);
    return res.status(502).json({ error: 'Failed to send email', message: (err as Error).message });
  }
  if (testTo) return res.json({ test: true, sentTo: testTo, count: cards.length });
  for (const c of cards) { cardModel.markBulgariaSent(c.id); activityModel.add({ userId: req.user!.id, cardId: c.id, type: 'bulgaria', text: 'Details sent to the Bulgaria office (in a PDF with other contacts)' }); }
  res.json({ sentTo: to, count: cards.length });
});

router.post('/:id/send-thank-you', (req: AuthedRequest, res) => handleSend('thank_you', req, res));
router.post('/:id/send-offer', (req: AuthedRequest, res) => handleSend('offer', req, res));
// a personal e-mail: the person's own words (special notes), no offer and no template
router.post('/:id/send-personal', (req: AuthedRequest, res) => handleSend('personal', req, res));
// the introduction e-mail of the customer page: rich text (colours, pictures), the catalogue and other library documents ticked, the lead is kept alive
router.post('/:id/send-intro', (req: AuthedRequest, res) => { req.body = { ...(req.body ?? {}), intro: true }; return handleSend('personal', req, res); });
router.post('/:id/send-proforma', (req: AuthedRequest, res) => handleSend('proforma', req, res));

// Send an earlier offer (or documents) again: the same pages and documents, priced from the price list as it is now, to the people as they are now
// (a contact may have changed since). The body is "to", "cc" and, when wanted, "subject" and "body".
router.post('/:id/offers/:entryId/resend', async (req: AuthedRequest, res) => {
  const card = cardModel.findById(parseInt(String(req.params.id), 10));
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  const row = db.prepare('SELECT params, selections, attachment_ids, kind FROM offers_sent WHERE id = ? AND card_id = ?').get(parseInt(String(req.params.entryId), 10), card.id) as
    | { params: string | null; selections: string | null; attachment_ids: string | null; kind: string } | undefined;
  if (!row || (row.kind !== 'offer' && row.kind !== 'documents')) return res.status(404).json({ error: 'Only an offer or documents can be sent again.' });
  const parse = (s: string | null, fallback: unknown) => { try { return s ? JSON.parse(s) : fallback; } catch { return fallback; } };
  const params = parse(row.params, null) as (Record<string, unknown> & { includeMoq?: boolean }) | null;
  const selections = parse(row.selections, []) as unknown[];
  const fresh = resolveOfferTemplate(card, null);
  req.body = {
    ...req.body,
    subject: req.body?.subject || fresh.subject,
    body: req.body?.body || fresh.body,
    attachmentIds: parse(row.attachment_ids, []),
    ...(row.kind === 'offer' && params ? { offer: { params, selections, includeMoq: !!params.includeMoq } } : {}),
    generatedDocs: params?.includeMoq ? ['moq'] : [],
  };
  return handleSend('offer', req, res);
});

// The customer's folder: the scan, the details and every offer sent.
router.get('/:id/files', (req: AuthedRequest, res) => {
  const card = cardModel.findById(parseInt(String(req.params.id), 10));
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  res.json(listCustomerFiles(card.id));
});

router.get('/:id/files/download', (req: AuthedRequest, res) => {
  const card = cardModel.findById(parseInt(String(req.params.id), 10));
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  const file = resolveCustomerFile(card.id, String(req.query.name ?? ''));
  if (!file) return res.status(404).json({ error: 'File not found' });
  res.download(file, path.basename(file));
});

// ---- a note: read it from the photos, write the e-mail to the customer, ask for samples ----------------------------------------------
router.post('/:id/notes/read', upload.array('photos', 6), async (req: AuthedRequest, res) => {
  const card = cardModel.findById(parseInt(String(req.params.id), 10));
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  const files = (req.files as Express.Multer.File[] | undefined) ?? [];
  if (!files.length) return res.status(400).json({ error: 'Add a photo of the note first.' });
  if (!useAi(req.user!, res)) { for (const f of files) fs.unlink(f.path, () => undefined); return; }
  try {
    const images = files.map((f) => ({ data: fs.readFileSync(f.path), mime: f.mimetype || 'image/jpeg' }));
    const text = await readNotePhotos(images);
    if (!text) return res.status(503).json({ ai: true, error: aiFailureMessage('The AI could not read the photo just now. Write the note, or try again.') });
    res.json({ text });
  } finally {
    for (const f of files) fs.unlink(f.path, () => undefined);
  }
});

// ---- smart fill: a pasted message and / or screenshots (WhatsApp, e-mail, card) become the fields of a new customer ----------------------
router.post('/ai-fill', upload.array('photos', 6), async (req: AuthedRequest, res) => {
  const files = (req.files as Express.Multer.File[] | undefined) ?? [];
  const cleanup = () => { for (const f of files) fs.unlink(f.path, () => undefined); };
  const text = String(req.body?.text ?? '').trim();
  if (!text && !files.length) return res.status(400).json({ error: 'Paste the message or add a screenshot first.' });
  if (!useAi(req.user!, res)) { cleanup(); return; }
  try {
    const images = files.map((f) => ({ data: fs.readFileSync(f.path), mime: f.mimetype || 'image/jpeg' }));
    const out = await smartFill(text, images);
    if (!out || !out.ai) return res.status(503).json({ ai: true, error: aiFailureMessage('The AI could not read this just now. Fill the form by hand, or try again.') });
    res.json(out);
  } finally { cleanup(); }
});

// ---- log a chat or an e-mail: the AI writes the record, a person checks it, then it goes in the history (and a follow-up, when needed)
router.post('/:id/log-chat/preview', upload.array('photos', 6), async (req: AuthedRequest, res) => {
  const files = (req.files as Express.Multer.File[] | undefined) ?? [];
  const cleanup = () => { for (const f of files) fs.unlink(f.path, () => undefined); };
  const card = cardModel.findById(parseInt(String(req.params.id), 10));
  if (!card) { cleanup(); return res.status(404).json({ error: 'Not found' }); }
  if (!canAccessCard(req.user, card)) { cleanup(); return res.status(403).json({ error: 'You do not have access to this record' }); }
  const text = String(req.body?.text ?? '').trim();
  if (!text && !files.length) return res.status(400).json({ error: 'Paste the chat or the e-mail, or add a screenshot first.' });
  if (!useAi(req.user!, res)) { cleanup(); return; }
  try {
    const out = await summariseChat(text, files.map((f) => ({ data: fs.readFileSync(f.path), mime: f.mimetype || 'image/jpeg' })), { company: card.company || card.name || '', sender: req.user!.display_name || req.user!.username });
    if (!out) return res.status(503).json({ ai: true, error: aiFailureMessage('The AI could not read this just now. Write the note by hand, or try again.') });
    res.json(out);
  } finally { cleanup(); }
});
router.post('/:id/log-chat/save', (req: AuthedRequest, res) => {
  const card = cardModel.findById(parseInt(String(req.params.id), 10));
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  const text = String(req.body?.text ?? '').trim().slice(0, 3000);
  if (!text) return res.status(400).json({ error: 'Write the note first.' });
  const channel = req.body?.channel === 'email' ? 'E-mail' : req.body?.channel === 'whatsapp' ? 'WhatsApp' : 'Chat';
  activityModel.add({ userId: req.user!.id, cardId: card.id, type: 'note', text: `${channel}: ${text}` });
  const fu = req.body?.followUp as { text?: string; date?: string } | null | undefined;
  if (fu?.text && /^\d{4}-\d{2}-\d{2}$/.test(String(fu.date))) db.prepare('INSERT INTO todos (user_id, card_id, text, due_date) VALUES (?, ?, ?, ?)').run(req.user!.id, card.id, String(fu.text).slice(0, 300), String(fu.date));
  res.status(201).json({ ok: true });
});

// the people of this customer who can get an e-mail (the record itself and its other people)
function mailRecipients(card: CardRow): { name: string; email: string }[] {
  const out: { name: string; email: string }[] = [];
  const seen = new Set<string>();
  const add = (name: string | null, email: string | null) => { for (const e of splitEmails(email ?? '')) { if (!seen.has(e.toLowerCase())) { seen.add(e.toLowerCase()); out.push({ name: name ?? '', email: e }); } } };
  add([card.name, card.last_name].filter(Boolean).join(' ') || card.company, card.email);
  for (const c of contactModel.list(card.id)) add([c.name, c.lastName].filter(Boolean).join(' '), c.email);
  return out;
}

router.post('/:id/notes/email-draft', async (req: AuthedRequest, res) => {
  const card = cardModel.findById(parseInt(String(req.params.id), 10));
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  const text = String(req.body?.text ?? '').trim();
  if (!text) return res.status(400).json({ error: 'Write the note first.' });
  const lang = isLang(req.body?.language) ? req.body.language : isLang(card.language) ? card.language : 'en';
  if (!useAi(req.user!, res)) return;
  const mail = await meetingNotesMail(card, text, lang, req.user!.display_name || req.user!.username);
  res.json({ ...mail, language: lang, recipients: mailRecipients(card), me: req.user!.email });
});

router.get('/:id/mail-recipients', (req: AuthedRequest, res) => {
  const card = cardModel.findById(parseInt(String(req.params.id), 10));
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  res.json({ recipients: mailRecipients(card), me: req.user!.email, language: card.language });
});


// the request goes to production (what to prepare) and to shipping (how to send it), and is written down as a "sample sent" entry
router.post('/:id/sample-request', async (req: AuthedRequest, res) => {
  const card = cardModel.findById(parseInt(String(req.params.id), 10));
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  const items = (Array.isArray(req.body?.items) ? req.body.items : []).map(String).filter((k: string) => k in SAMPLE_CHOICES);
  const custom = String(req.body?.custom ?? '').trim().slice(0, 600);
  const carrier = CARRIERS.includes(String(req.body?.carrier)) ? String(req.body.carrier) : '';
  const note = String(req.body?.note ?? '').trim().slice(0, 600);
  if (!items.length) return res.status(400).json({ error: 'Choose at least one sample.' });
  if (items.includes('custom') && !custom) return res.status(400).json({ error: 'Write which edgebanding sample you need.' });
  const sender = req.user!.display_name || req.user!.username;
  const mails = sampleMails(card, items, custom, carrier, note, sender);
  const to = sampleRecipients();
  const testTo = testAddress(req);
  if (testTo === '') return res.status(400).json({ error: 'There is no test address. Add your e-mail under My account.' });
  const signature = buildSignature(req.user, styleFor(req.user));
  const failed: string[] = [];
  for (const [who, addr, mail] of [['production', to.prep, mails.prep], ['shipping', to.ship, mails.ship]] as const) {
    try {
      await sendThankYouEmail({ to: addr, cc: req.user!.email || null, subject: mail.subject, body: mail.body, replyTo: req.user!.email, signature, testTo, record: { cardId: card.id, userId: req.user!.id, kind: 'sample_request' } });
    } catch (err) {
      console.error(`Sample request to ${who} failed:`, err);
      failed.push(`${who} (${addr}): ${(err as Error).message}`);
    }
  }
  if (failed.length) return res.status(502).json({ error: `The e-mail could not be sent - ${failed.join('; ')}` });
  if (testTo) return res.json({ test: true, sentTo: testTo });
  // the samples are kept with what they are (the customer is told this later) so the tracking number can be added when they leave
  const sampleRow = Number(db.prepare('INSERT INTO card_samples (card_id, user_id, items, note, carrier) VALUES (?, ?, ?, ?, ?)').run(card.id, req.user!.id, items.map((k: string) => (k === 'custom' ? `Edgebanding sample: ${custom}` : SAMPLE_CHOICES[k])).join('\n'), note || null, carrier || null).lastInsertRowid);
  const sampleNote = logActivity(req.user!, card, 'sample', `Sample request: ${items.map((k: string) => (k === 'custom' ? `edgebanding sample (${custom})` : SAMPLE_CHOICES[k])).join(', ')}${carrier ? ` - ${carrier}` : ''}${note ? ` - ${note}` : ''}`);
  db.prepare('UPDATE card_samples SET activity_id = ? WHERE id = ?').run(sampleNote, sampleRow);
  res.json({ ok: true });
});

// ---- the sales pipeline -----------------------------------------------------------------------------------------------------------
router.get('/pipeline/options', (_req, res) => res.json({ stages: PIPELINE_STAGES, lostReasons: LOST_REASONS, disqualifyReasons: DISQUALIFY_REASONS, leadSources: leadSources() }));

router.get('/:id/health', (req: AuthedRequest, res) => {
  const card = cardModel.findById(parseInt(String(req.params.id), 10));
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  res.json(healthOf(card.sap));
});

// a stage of the six, and / or the lead source
router.patch('/:id/pipeline', (req: AuthedRequest, res) => {
  const id = parseInt(String(req.params.id), 10);
  const card = cardModel.findById(id);
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  const b = (req.body ?? {}) as Record<string, unknown>;
  if (b.leadSource !== undefined) {
    const v = String(b.leadSource ?? '').trim();
    if (v && !leadSources().includes(v) && v !== card.lead_source) return res.status(400).json({ error: 'Choose one of the lead sources of the list.' });
    // one field: the old "where we met" follows the lead source, so the two never disagree
    const old = /^Trade Fair/.test(v) ? 'fair' : /^Website/.test(v) ? 'website' : /^Referral/.test(v) ? 'referral' : /^AI Lead/.test(v) ? 'database' : v ? 'other' : null;
    db.prepare("UPDATE cards SET lead_source = ?, source = COALESCE(?, source), updated_at = datetime('now') WHERE id = ?").run(v || null, old, id);
    audit(req.user, id, 'change', 'Lead source', card.lead_source, v || null);
  }
  if (b.handling !== undefined) {
    // who works this customer: by country (empty), forward to the distributor, or direct
    const h = String(b.handling ?? '');
    if (h && h !== 'distributor' && h !== 'direct') return res.status(400).json({ error: 'Choose by country, the distributor or direct.' });
    db.prepare("UPDATE cards SET handling = ?, updated_at = datetime('now') WHERE id = ?").run(h || null, id);
    audit(req.user, id, 'change', 'Who works this customer', card.handling, h || null);
    activityModel.add({ userId: req.user!.id, cardId: id, type: 'stage', text: h === 'direct' ? 'Kept direct: TECE works this customer itself (not forwarded to the distributor).' : h === 'distributor' ? 'To be forwarded to the distributor.' : 'Handling follows the country again.' });
  }
  if (b.stage !== undefined) {
    const n = parseInt(String(b.stage), 10);
    if (!(n >= 1 && n <= 6)) return res.status(400).json({ error: 'The stage is 1 to 6.' });
    if ((card.sap ?? '').trim()) return res.status(400).json({ error: 'This customer has a SAP number: its health is worked out from the invoices.' });
    db.prepare("UPDATE cards SET pipeline_stage = ?, stage = ?, exit_status = NULL, exit_reason = NULL, exit_note = NULL, follow_up_date = NULL, updated_at = datetime('now') WHERE id = ?").run(n, legacyStage(n), id);
    activityModel.add({ userId: req.user!.id, cardId: id, type: 'stage', text: `Stage ${n}: ${PIPELINE_STAGES[n - 1]}` });
  }
  const after = cardModel.findById(id)!;
  res.json({ pipeline_stage: after.pipeline_stage, exit_status: after.exit_status, exit_reason: after.exit_reason, exit_note: after.exit_note, follow_up_date: after.follow_up_date, lead_source: after.lead_source, handling: after.handling, stage: after.stage });
});

// an exit state: on hold (with the day to come back), lost (with the reason), disqualified (with the reason)
router.post('/:id/exit', (req: AuthedRequest, res) => {
  const id = parseInt(String(req.params.id), 10);
  const card = cardModel.findById(id);
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  if ((card.sap ?? '').trim()) return res.status(400).json({ error: 'A customer with a SAP number has no exit state: see its account health.' });
  const status = String(req.body?.status ?? '');
  const reason = String(req.body?.reason ?? '').trim();
  const note = String(req.body?.note ?? '').trim().slice(0, 500);
  const follow = String(req.body?.followUpDate ?? '').trim();
  if (status === 'on_hold') {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(follow)) return res.status(400).json({ error: 'Choose the follow-up date.' });
    if (!note) return res.status(400).json({ error: 'Write a short note (for example: revisit after the catalogue update).' });
  } else if (status === 'lost') {
    if (!LOST_REASONS.includes(reason)) return res.status(400).json({ error: 'Choose the reason it was lost.' });
  } else if (status === 'disqualified') {
    if (!DISQUALIFY_REASONS.includes(reason)) return res.status(400).json({ error: 'Choose the reason it is disqualified.' });
  } else return res.status(400).json({ error: 'Unknown exit state.' });
  // not a fit: the contact goes to the junk folder (only an admin sees it, and can bring it back)
  if (status === 'disqualified') {
    moveToJunk(card, `Disqualified: ${reason}${note ? ` (${note})` : ''}`, req.user!.id);
    audit(req.user!, null, 'change', 'disqualified: moved to junk', null, reason, card.company || card.name || `#${id}`);
    return res.json({ ok: true, junked: true });
  }
  db.prepare("UPDATE cards SET exit_status = ?, exit_reason = ?, exit_note = ?, follow_up_date = ?, stage = ?, pipeline_stage = COALESCE(pipeline_stage, 1), updated_at = datetime('now') WHERE id = ?")
    .run(status, status === 'on_hold' ? null : reason, note || null, status === 'on_hold' ? follow : null, status === 'on_hold' ? card.stage : 'lost', id);
  if (status === 'on_hold') todoModel.add({ userId: req.user!.id, cardId: id, text: `Follow up (on hold): ${note}`, dueDate: follow });
  activityModel.add({ userId: req.user!.id, cardId: id, type: 'stage', text: `${status === 'on_hold' ? 'On hold until ' + follow : status === 'lost' ? 'Lost: ' + reason : 'Disqualified: ' + reason}${note ? ' (' + note + ')' : ''}` });
  res.json({ ok: true });
});

router.post('/:id/exit/clear', (req: AuthedRequest, res) => {
  const id = parseInt(String(req.params.id), 10);
  const card = cardModel.findById(id);
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canAccessCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  const n = card.pipeline_stage ?? 1;
  db.prepare("UPDATE cards SET exit_status = NULL, exit_reason = NULL, exit_note = NULL, follow_up_date = NULL, stage = ?, updated_at = datetime('now') WHERE id = ?").run(legacyStage(n), id);
  activityModel.add({ userId: req.user!.id, cardId: id, type: 'stage', text: 'Back in the pipeline' });
  res.json({ ok: true });
});

export default router;
