import sharp from 'sharp';
import { askJsonParts } from './noteAssist';
import { EDGEBAND_CONTEXT } from './edgebandingKnowledge';
import { COUNTRY_NAMES } from '../data/countries';
import { canonicalCountry } from '../models/countryModel';

// "Smart fill": a pasted message (WhatsApp, e-mail, a note) and / or screenshots become a customer. ONE AI question reads the screenshots and the text
// together (no separate reading step: half the cost, and nothing is lost between two steps). What is not said stays empty.
export interface SmartFields {
  name: string; company: string; position: string; country: string; city: string; email: string; tel: string; mobile: string; fax: string; address: string; website: string;
  workArea: string; interestedIn: string; notes: string; language: string;
}
const EMPTY: SmartFields = { name: '', company: '', position: '', country: '', city: '', email: '', tel: '', mobile: '', fax: '', address: '', website: '', workArea: '', interestedIn: '', notes: '', language: '' };

const str = (v: unknown, max = 600) => String(v ?? '').trim().slice(0, max);
const SCHEMA = {
  type: 'OBJECT',
  properties: Object.fromEntries(Object.keys(EMPTY).map((k) => [k, { type: 'STRING' }])),
  required: Object.keys(EMPTY),
};

// a screenshot is shrunk first (a phone screenshot is huge: it costs time and credits and gains nothing); any format the phone makes is turned into JPEG
async function shrink(i: { data: Buffer; mime: string }): Promise<{ data: Buffer; mime: string }> {
  try {
    const data = await sharp(i.data).rotate().resize({ width: 1800, height: 2600, fit: 'inside', withoutEnlargement: true }).jpeg({ quality: 82 }).toBuffer();
    return { data, mime: 'image/jpeg' };
  } catch {
    return i;
  }
}

export async function smartFill(text: string, images: { data: Buffer; mime: string }[]): Promise<{ fields: SmartFields; read: string; ai: boolean } | null> {
  const pasted = text.trim();
  if (!pasted && !images.length) return null;
  const shots = await Promise.all(images.slice(0, 6).map(shrink));
  const instructions = [
    EDGEBAND_CONTEXT,
    'A TECE sales person gives you a WhatsApp chat, an e-mail, a note, a business card or a quick description - as text and / or screenshots. Make ONE customer record from all of it. In a chat, the customer is the OTHER person (not the TECE sales person, not "You").',
    'Fill: name (contact person, first and last), company, position (job title), country (ONE name from the list), city, email (all addresses, comma separated; only addresses that are written, never guessed), tel (office phone), mobile (mobile / WhatsApp number; the number a WhatsApp chat is with is a mobile), fax, address, website, workArea (what the company does, e.g. "kitchen maker", "panel dealer"), interestedIn (what they want from TECE: material, widths, thickness, decor codes, quantities, timing - short and exact), notes (a short English summary of the conversation: what was asked, promised, the next step; keep numbers, colours and dates exactly), language (the language the customer writes in: en, tr, ru, es or fr).',
    `Country list: ${COUNTRY_NAMES.join(', ')}. If the country is not written, work it out from the phone prefix, the city, the domain or the language - but leave it empty when unsure.`,
    'Empty string when the material does not say it. Never copy the TECE side (our own name, e-mail, number) into the customer.',
    pasted ? `Text:\n${pasted.slice(0, 9000)}` : 'There is no typed text: read the screenshots.',
  ].join('\n\n');
  const parts: unknown[] = [{ text: instructions }, ...shots.map((i) => ({ inlineData: { mimeType: i.mime, data: i.data.toString('base64') } }))];
  const j = await askJsonParts(parts, SCHEMA, 0.1);
  if (!j) return { fields: { ...EMPTY, notes: pasted.slice(0, 1500) }, read: '', ai: false };
  const fields = { ...EMPTY };
  for (const k of Object.keys(EMPTY) as (keyof SmartFields)[]) fields[k] = str(j[k], k === 'notes' || k === 'interestedIn' ? 1500 : 300);
  const c = fields.country ? (canonicalCountry(fields.country) as string) : '';
  fields.country = COUNTRY_NAMES.includes(c) ? c : '';
  if (!['en', 'tr', 'ru', 'es', 'fr'].includes(fields.language)) fields.language = '';
  return { fields, read: '', ai: true };
}
