import { db } from '../db/connection';
import { settingsModel } from '../models/settingsModel';
import { niceName } from './niceName';

// Once: names that were written entirely in capitals ("LAJTER-BUTOR KFT", "JOSE SCHWARTZ") become "Lajter-Butor KFT", "Jose Schwartz". Only names that are ALL capitals are
// changed, the legal forms (LLC, S.R.L, KFT ...) stay, and the same fix is applied whenever a record is saved afterwards (cardModel.update).
export function fixCapitalNames(): number {
  if (settingsModel.get('names_nice_v1') === 'done') return 0;
  let n = 0;
  try {
    db.exec('BEGIN');
    const cards = db.prepare('SELECT id, name, company FROM cards').all() as { id: number; name: string | null; company: string | null }[];
    const up = db.prepare('UPDATE cards SET name = ?, company = ? WHERE id = ?');
    for (const c of cards) {
      const nm = niceName(c.name, true); const co = niceName(c.company);
      if (nm !== (c.name ?? '') || co !== (c.company ?? '')) { up.run(nm || null, co || null, c.id); n += 1; }
    }
    try {
      const people = db.prepare('SELECT id, name FROM card_contacts').all() as { id: number; name: string | null }[];
      const upc = db.prepare('UPDATE card_contacts SET name = ? WHERE id = ?');
      for (const p of people) { const nm = niceName(p.name, true); if (nm !== (p.name ?? '')) { upc.run(nm || null, p.id); n += 1; } }
    } catch { /* no contacts table yet */ }
    db.exec('COMMIT');
    settingsModel.set('names_nice_v1', 'done');
  } catch (err) { try { db.exec('ROLLBACK'); } catch { /* nothing open */ } console.error('Name fix failed:', err); }
  if (n) console.log(`Names written in capitals were fixed on ${n} records.`);
  return n;
}
