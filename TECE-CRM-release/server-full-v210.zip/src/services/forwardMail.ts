import { settingsModel } from '../models/settingsModel';
import { userModel } from '../models/userModel';
import { sendThankYouEmail, type EmailAttachment } from './thankYouEmail';

// Forward a document (a statement, a proforma, a price list) to a colleague. Internal: the e-mail is in Turkish, it comes from the system and
// the replies go to the person who forwarded it.
export interface StaffOption { id: number; name: string; email: string }

export function staffOptions(exceptId?: number): StaffOption[] {
  return userModel.listAll()
    .filter((u) => u.is_active && u.email && !u.area && u.display_name && u.id !== exceptId)
    .map((u) => ({ id: u.id, name: u.display_name as string, email: u.email as string }))
    .sort((a, b) => a.name.localeCompare(b.name));
}

export async function forwardToStaff(input: {
  sender: { id: number; display_name?: string | null; username?: string; email?: string | null };
  staffId: number;
  what: string; // e.g. "Hesap ekstresi: ACME"
  note?: string;
  attachments?: EmailAttachment[];
  extraHtml?: string;
}): Promise<{ to: string; name: string; test: boolean }> {
  const to = staffOptions().find((s) => s.id === input.staffId);
  if (!to) throw new Error('Choose a colleague with an e-mail address.');
  const from = input.sender.display_name || input.sender.username || 'Bir çalışma arkadaşınız';
  const note = (input.note ?? '').trim().slice(0, 1500);
  const test = settingsModel.get('test_mode') === '1';
  await sendThankYouEmail({
    to: to.email,
    cc: input.sender.email && input.sender.email !== to.email ? input.sender.email : null,
    subject: `${input.what} (${from} iletti)`,
    body: `Merhaba ${to.name.split(/\s+/)[0]},\n\n${from} sizinle bir belge paylaştı: ${input.what}.\n${note ? `\nNot: ${note}\n` : ''}\nBelge ekte. Müşteriye hiçbir şey gönderilmedi.`,
    attachments: input.attachments,
    extraHtml: input.extraHtml,
    replyTo: input.sender.email ?? null,
    signature: { text: 'TECE müşteri sistemi', html: '<div style="font-family:Arial,sans-serif;color:#5e6676;font-size:12px">TECE müşteri sistemi</div>' },
    testTo: test ? settingsModel.get('test_email') || input.sender.email || null : null,
  });
  return { to: to.email, name: to.name, test };
}
