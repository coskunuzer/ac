import { Router } from 'express';
import { requireAuth, type AuthedRequest } from '../middleware/auth';
import { dayOf, ping, secondsBetween, secondsPerDay, shiftDay } from '../services/usage';

const router = Router();
router.use(requireAuth);

// The open page says "I am here and active" (every 30 seconds).
router.post('/ping', (req: AuthedRequest, res) => {
  const s = typeof req.body?.seconds === 'number' ? req.body.seconds : 30;
  ping(req.user!.id, Number.isFinite(s) ? s : 30);
  res.json({ ok: true });
});

// My time in the app: today, this week, this month, and the last 7 days.
router.get('/mine', (req: AuthedRequest, res) => {
  const id = req.user!.id;
  const today = dayOf();
  const sum = (days: number) => secondsBetween([id], shiftDay(today, -(days - 1)), today).get(id) ?? 0;
  res.json({ today: sum(1), week: sum(7), month: sum(30), days: secondsPerDay(id, shiftDay(today, -6), today) });
});

export default router;
