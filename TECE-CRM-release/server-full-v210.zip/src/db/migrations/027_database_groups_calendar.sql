-- The customer database comes in three groups, and people can connect their Google Calendar.

-- Which group of the uploaded database a company is in: existing (they buy from us), reachable (we have an e-mail or a web site),
-- no_contact (neither). Empty for everybody who was added by hand or met at a fair.
ALTER TABLE cards ADD COLUMN contact_group TEXT;
-- What the web-site search found out: found (and the address was written on the customer) or none.
ALTER TABLE cards ADD COLUMN website_check TEXT;
CREATE INDEX IF NOT EXISTS idx_cards_contact_group ON cards(contact_group);

-- A person's Google Calendar (the permission they gave us, to read and write their meetings).
CREATE TABLE IF NOT EXISTS google_calendar (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  email TEXT,
  refresh_token TEXT NOT NULL,
  connected_at TEXT NOT NULL DEFAULT (datetime('now'))
);
