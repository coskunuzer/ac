import { Router } from 'express';
import { db } from '../db/connection';
import { requireAdmin, requireAuth, type AuthedRequest } from '../middleware/auth';
import { cardModel } from '../models/cardModel';
import { canSeeCard } from '../services/visibility';

// The audit log: an admin reads all of it (filters: person, field, customer, period); a person reads the changes of a customer they may see.
const router = Router();
router.use(requireAuth);

const COLS = "a.id, a.at, a.user_name AS who, a.card_id AS cardId, COALESCE(c.company, c.name) AS customer, a.action, a.field, a.old_value AS oldValue, a.new_value AS newValue, a.note";

router.get('/', requireAdmin, (req, res) => {
  const q = req.query as Record<string, string>;
  const where: string[] = ['1 = 1']; const p: (string | number)[] = [];
  if (q.who) { where.push('a.user_name LIKE ?'); p.push(`%${q.who}%`); }
  if (q.field) { where.push('a.field = ?'); p.push(q.field); }
  if (q.action) { where.push('a.action = ?'); p.push(q.action); }
  if (q.card) { where.push('a.card_id = ?'); p.push(parseInt(q.card, 10) || 0); }
  if (q.q) { where.push('(c.company LIKE ? OR c.name LIKE ? OR a.old_value LIKE ? OR a.new_value LIKE ? OR a.note LIKE ? OR a.field LIKE ?)'); p.push(...Array(6).fill(`%${q.q}%`)); }
  if (/^\d{4}-\d{2}-\d{2}$/.test(q.from ?? '')) { where.push('a.at >= ?'); p.push(q.from); }
  const rows = db.prepare(`SELECT ${COLS} FROM audit_log a LEFT JOIN cards c ON c.id = a.card_id WHERE ${where.join(' AND ')} ORDER BY a.id DESC LIMIT 500`).all(...p);
  const fields = (db.prepare('SELECT DISTINCT field FROM audit_log WHERE field IS NOT NULL ORDER BY field').all() as { field: string }[]).map((r) => r.field);
  const people = (db.prepare('SELECT DISTINCT user_name FROM audit_log WHERE user_name IS NOT NULL ORDER BY user_name').all() as { user_name: string }[]).map((r) => r.user_name);
  res.json({ rows, fields, people });
});

router.get('/card/:id', (req: AuthedRequest, res) => {
  const card = cardModel.findById(parseInt(String(req.params.id), 10));
  if (!card) return res.status(404).json({ error: 'Not found' });
  if (!canSeeCard(req.user, card)) return res.status(403).json({ error: 'You do not have access to this record' });
  res.json({ rows: db.prepare(`SELECT ${COLS} FROM audit_log a LEFT JOIN cards c ON c.id = a.card_id WHERE a.card_id = ? ORDER BY a.id DESC LIMIT 60`).all(card.id) });
});

export default router;
