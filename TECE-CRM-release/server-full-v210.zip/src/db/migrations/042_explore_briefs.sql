-- The short briefing about a country (or a city of Turkey) shown on the daily "explore the leads" card; written by the AI, kept for three weeks.
CREATE TABLE IF NOT EXISTS explore_briefs (
  place TEXT NOT NULL,
  market TEXT NOT NULL,
  lang TEXT NOT NULL,
  body TEXT NOT NULL,
  made_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (place, market, lang)
);
