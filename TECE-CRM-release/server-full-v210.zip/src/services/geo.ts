import countries from 'i18n-iso-countries';
import en from 'i18n-iso-countries/langs/en.json';
import cityList from '../data/cities.json';
import { isoOf } from './phone';

countries.registerLocale(en);

// The map of the customers: a bundled list of about 4,500 major cities (every city of 100,000 people, every capital and the 81 provinces of Turkey)
// puts a customer's city on the map; a customer whose city is not in it stays at country level.

const norm = (s: string) => s.normalize('NFD').replace(/\p{Diacritic}/gu, '').replace(/ı/g, 'i').replace(/İ/g, 'i').toLowerCase().replace(/[^a-z0-9]/g, '');

type Row = [string, string, number, number];
let index: Map<string, Row> | null = null;
function load(): Map<string, Row> {
  if (!index) {
    index = new Map();
    for (const r of cityList as Row[]) index.set(`${norm(r[0])}|${r[1]}`, r);
  }
  return index;
}

// the place of a city on the map, or null when it is not one of the major cities
export function placeOf(city: string | null | undefined, country: string | null | undefined): { name: string; lat: number; lon: number } | null {
  if (!city || !country) return null;
  const iso = isoOf(country);
  if (!iso) return null;
  const r = load().get(`${norm(city)}|${iso}`);
  return r ? { name: r[0], lat: r[2], lon: r[3] } : null;
}

// the number that the world map (world-atlas) uses for a country
export const numericOf = (iso: string): string | null => countries.alpha2ToNumeric(iso) ?? null;
