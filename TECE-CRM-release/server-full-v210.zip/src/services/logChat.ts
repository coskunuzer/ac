import sharp from 'sharp';
import { askJsonParts } from './noteAssist';
import { EDGEBAND_CONTEXT } from './edgebandingKnowledge';

// "Log a chat or e-mail": the text (or screenshots) of a WhatsApp chat or an e-mail is made into a short record for the customer's history, with what was asked,
// what was promised and the next step. A person reads and corrects it before it is saved.
export interface ChatLog { channel: 'whatsapp' | 'email' | 'other'; summary: string; asked: string; promised: string; quantities: string; nextStep: string; followUpDays: number | null }
const SCHEMA = { type: 'OBJECT', properties: { channel: { type: 'STRING' }, summary: { type: 'STRING' }, asked: { type: 'STRING' }, promised: { type: 'STRING' }, quantities: { type: 'STRING' }, nextStep: { type: 'STRING' }, followUpDays: { type: 'INTEGER' } }, required: ['channel', 'summary', 'asked', 'promised', 'quantities', 'nextStep'] };

export async function summariseChat(text: string, images: { data: Buffer; mime: string }[], who: { company: string; sender: string }): Promise<ChatLog | null> {
  const shots = await Promise.all(images.slice(0, 6).map(async (i) => { try { return { data: await sharp(i.data).rotate().resize({ width: 1800, height: 2600, fit: 'inside', withoutEnlargement: true }).jpeg({ quality: 82 }).toBuffer(), mime: 'image/jpeg' }; } catch { return i; } }));
  const prompt = [
    EDGEBAND_CONTEXT,
    `A TECE sales person (${who.sender}) pasted a chat or an e-mail with the customer ${who.company || '(a customer)'}, as text and / or screenshots. Write the record for the customer's history, in English, short and exact.`,
    'channel: whatsapp, email or other. summary: 2-4 sentences of what the conversation was about. asked: what the customer asked or wants (products, sizes, decor codes, quantities, prices). promised: what TECE promised (or "nothing"). quantities: the quantities, prices and dates named, exactly as written (or empty). nextStep: the one next step for TECE. followUpDays: in how many days to follow up (an integer), or 0 when nothing is needed. Never invent anything that is not in the conversation.',
    text.trim() ? `Text:\n${text.trim().slice(0, 9000)}` : 'There is no typed text: read the screenshots.',
  ].join('\n\n');
  const j = await askJsonParts([{ text: prompt }, ...shots.map((i) => ({ inlineData: { mimeType: i.mime, data: i.data.toString('base64') } }))], SCHEMA, 0.1);
  if (!j) return null;
  const s = (v: unknown, n: number) => String(v ?? '').trim().slice(0, n);
  const days = Number(j.followUpDays);
  return { channel: j.channel === 'email' ? 'email' : j.channel === 'whatsapp' ? 'whatsapp' : 'other', summary: s(j.summary, 700), asked: s(j.asked, 500), promised: s(j.promised, 400), quantities: s(j.quantities, 400), nextStep: s(j.nextStep, 300), followUpDays: Number.isFinite(days) && days > 0 ? Math.min(60, Math.round(days)) : null };
}
