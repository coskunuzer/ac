-- Append-only logs of the Shipping section (never changed, never deleted): every move of the documents of an export, and every change of a forwarder.
-- They are kept for the follow-up of how the section is used and for improving the screens.
CREATE TABLE IF NOT EXISTS ship_doc_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  invoice_key TEXT NOT NULL,
  customer TEXT,
  invoice TEXT,
  action TEXT NOT NULL,            -- taken (Operations took it) | sent (marked sent) | handed_to_sales (do not follow) | followed_again | cleared | sales_shared
  by_role TEXT,                    -- operations | sales | admin
  user_id INTEGER,
  note TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_ship_doc_log_key ON ship_doc_log (invoice_key);

CREATE TABLE IF NOT EXISTS ship_firm_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  forwarder_id INTEGER,
  name TEXT,
  action TEXT NOT NULL,            -- edited | deleted
  snapshot TEXT,                   -- the firm as it was before the change (JSON)
  user_id INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
