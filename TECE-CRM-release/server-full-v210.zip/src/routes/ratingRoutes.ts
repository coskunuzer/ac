import { Router } from 'express';
import { requireAdmin, requireAuth, type AuthedRequest } from '../middleware/auth';
import { aiDailyLimit, needAi, setAiDailyLimit } from '../services/aiBudget';
import { ratingStatus, startRating } from '../services/aiRating';

const router = Router();
router.use(requireAuth);

// How far the AI rating is: how many customers have one, and whether a run is going.
router.get('/status', (_req, res) => {
  res.json(ratingStatus());
});

// Start rating: everybody (admin) or only the customers this person may see (at most 400 at a time).
// (the batch rating without web sites is not used any more: the company scoring reads the web site - Customers > "Check with the AI")
router.post('/start', requireAdmin, needAi, (req: AuthedRequest, res) => {
  const scope = req.body?.scope === 'all' ? 'all' : 'mine';
  startRating(scope, req.user!);
  res.json(ratingStatus());
});


// The AI questions each person may ask a day (admins have no limit).
router.get('/limit', requireAdmin, (_req, res) => {
  res.json({ limit: aiDailyLimit() });
});
router.put('/limit', requireAdmin, (req, res) => {
  const n = typeof req.body?.limit === 'number' ? req.body.limit : parseInt(String(req.body?.limit ?? ''), 10);
  if (!Number.isFinite(n)) return res.status(400).json({ error: 'limit must be a number' });
  res.json({ limit: setAiDailyLimit(n) });
});

export default router;
