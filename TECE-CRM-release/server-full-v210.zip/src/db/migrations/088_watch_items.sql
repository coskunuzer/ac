-- The two boxes on the right edge ("Radar" and "To-do"): customers and accounts a person drags there to follow later. Private to the person.
CREATE TABLE IF NOT EXISTS watch_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  list TEXT NOT NULL,            -- 'radar' | 'todo'
  card_id INTEGER,
  label TEXT NOT NULL,
  note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_watch_user ON watch_items (user_id, list);
