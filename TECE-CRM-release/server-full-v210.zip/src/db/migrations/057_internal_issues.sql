-- Internal complaints: things the company has to know even when the customer says nothing (less meters sent than ordered, a wrong colour found at packing ...).
-- Not official: no complaint number, nothing is shown to the customer or to sales as a status. Only the admin and quality read them all.
CREATE TABLE IF NOT EXISTS internal_issues (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_by INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  kind TEXT NOT NULL DEFAULT 'other',
  title TEXT NOT NULL,
  description TEXT,
  card_id INTEGER,
  customer_name TEXT,
  order_no TEXT,
  product_code TEXT,
  unit TEXT NOT NULL DEFAULT 'm',
  ordered_qty REAL,
  shipped_qty REAL,
  severity TEXT NOT NULL DEFAULT 'normal',          -- low | normal | high
  customer_aware INTEGER,                           -- 1 = the customer already knows / complained, 0 = the customer does not know
  cost_est REAL,
  currency TEXT NOT NULL DEFAULT 'EUR',
  status TEXT NOT NULL DEFAULT 'new',               -- new | review | with_dept | closed
  source_dept TEXT,                                 -- where it went wrong
  result TEXT,
  action TEXT,
  closed_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_ii_status ON internal_issues(status, created_at);
CREATE TABLE IF NOT EXISTS internal_issue_tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  issue_id INTEGER NOT NULL REFERENCES internal_issues(id) ON DELETE CASCADE,
  department TEXT NOT NULL,
  owner_user_id INTEGER,
  due_date TEXT,
  instruction TEXT,
  answer TEXT,
  state TEXT NOT NULL DEFAULT 'open',               -- open | answered | accepted
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  answered_at TEXT
);
CREATE TABLE IF NOT EXISTS internal_issue_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  issue_id INTEGER NOT NULL REFERENCES internal_issues(id) ON DELETE CASCADE,
  user_id INTEGER,
  at TEXT NOT NULL DEFAULT (datetime('now')),
  kind TEXT NOT NULL,
  note TEXT
);
CREATE TABLE IF NOT EXISTS internal_issue_files (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  issue_id INTEGER NOT NULL REFERENCES internal_issues(id) ON DELETE CASCADE,
  stored_name TEXT NOT NULL,
  original_name TEXT,
  uploaded_by INTEGER,
  uploaded_at TEXT NOT NULL DEFAULT (datetime('now'))
);
