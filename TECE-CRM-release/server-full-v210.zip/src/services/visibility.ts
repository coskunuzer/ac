import { db } from '../db/connection';
import { countryKey, countryModel } from '../models/countryModel';
import { cityKey, cityModel } from '../models/cityModel';
import { accessModel } from '../models/accessModel';
import type { CardRow } from '../models/cardModel';
import { viewMode } from './viewMode';
import { memoTables, memoTablesBy } from '../db/dataVersion';

// Who sees which customer - the most important rule of the app.
//
// An admin sees everybody. Anybody else sees only:
//  - the customers that have their name as the responsible person,
//  - export customers of the countries they are responsible for - but ONLY customers that belong to a staff member (a customer with
//    nobody's name on it is seen by admins only, even in a country somebody is responsible for), domestic customers of the cities they are
//    responsible for (an export person never sees a domestic customer and the other way round),
//  - whatever an admin has additionally granted them (a whole market, a country or a city) - except a customer that was
//    given to one particular person (owner_override): that one is seen by that person and by admins only,
//  - the forms they have just scanned until they have confirmed them - so a visitor that belongs to somebody
//    else can still be scanned and checked.
export interface Viewer {
  id: number;
  role: string;
  display_name: string | null;
  market?: string;
}

type CardLike = Pick<CardRow, 'uploaded_by' | 'person' | 'country' | 'status'> & { market?: string | null; city?: string | null; owner_override?: number | null };

export function myCountryKeys(name: string | null): Set<string> {
  if (!name) return new Set();
  return new Set(countryModel.listAll().filter((r) => r.responsible === name).map((r) => countryKey(r.country)));
}

export function myCityKeys(name: string | null): Set<string> {
  if (!name) return new Set();
  return new Set(cityModel.listAll().filter((r) => r.responsible === name).map((r) => r.key));
}

interface Access {
  markets: Set<string>;
  countries: Set<string>;
  cities: Set<string>;
  // only what an admin granted (not the person's own region): the region of a person never shows them a customer that carries another name
  grantedCountries: Set<string>;
  grantedCities: Set<string>;
}

// Worked out for every customer of a list when it was asked one customer at a time: the answer for a person is kept until the country list,
// the city list or somebody's extra access changes (those writes are reported the moment they happen, see db/dataVersion.ts).
const keptAccess = memoTablesBy(['user_access', 'country_assignments', 'city_assignments'], (key: string) => {
  const cut = key.indexOf('|');
  return accessOfRaw({ id: Number(key.slice(0, cut)), role: 'user', display_name: key.slice(cut + 1) || null });
});
const sharedAccess = (viewer: Viewer): Access => keptAccess(`${viewer.id}|${viewer.display_name ?? ''}`);
// callers outside this file get their own copy (they may change it)
export function accessOf(viewer: Viewer): Access {
  const a = sharedAccess(viewer);
  return { markets: new Set(a.markets), countries: new Set(a.countries), cities: new Set(a.cities), grantedCountries: new Set(a.grantedCountries), grantedCities: new Set(a.grantedCities) };
}
function accessOfRaw(viewer: Viewer): Access {
  const grants = accessModel.forUser(viewer.id);
  const countries = myCountryKeys(viewer.display_name);
  const cities = myCityKeys(viewer.display_name);
  const markets = new Set<string>();
  const grantedCountries = new Set<string>();
  const grantedCities = new Set<string>();
  for (const g of grants) {
    if (g.kind === 'country') { countries.add(countryKey(g.value)); grantedCountries.add(countryKey(g.value)); }
    else if (g.kind === 'city') { cities.add(cityKey(g.value)); grantedCities.add(cityKey(g.value)); }
    else markets.add(g.value);
  }
  return { markets, countries, cities, grantedCountries, grantedCities };
}

export function visibilityFor(viewer: Viewer): (card: CardLike) => boolean {
  if (viewer.role === 'admin') return () => true;
  const a = sharedAccess(viewer);
  const mine = new Set(viewMode.team(viewer.id).names); // manager mode: the customers of the people below them
  return (card) => {
    if (card.uploaded_by === viewer.id && card.status === 'needs_review') return true;
    if (card.person && card.person === viewer.display_name) return true;
    if (card.person && mine.has(card.person)) return true;
    if (card.owner_override) return false;
    if (!(card.person ?? '').trim()) return false; // belongs to nobody: admins only
    const market = card.market === 'domestic' ? 'domestic' : 'export';
    // the card carries somebody else's name here: the person of its region does NOT see it, only what an admin granted
    if (a.markets.has(market)) return true;
    if (market === 'domestic') return !!card.city && a.grantedCities.has(cityKey(card.city));
    return !!card.country && a.grantedCountries.has(countryKey(card.country));
  };
}

// The same rule as a piece of SQL for the paged list (the customer database has tens of thousands of rows).
// Returns null for an admin (no restriction); fills `params` with what the SQL refers to.
export function visibilitySql(viewer: Viewer, params: Record<string, string | number>): string | null {
  if (viewer.role === 'admin') return null;
  const a = sharedAccess(viewer);
  const parts = ["(uploaded_by = @viewerId AND status = 'needs_review')"];
  params.viewerId = viewer.id;
  if (viewer.display_name) {
    parts.push('person = @viewerName');
    params.viewerName = viewer.display_name;
  }
  const under = viewMode.team(viewer.id).names; // manager mode: the customers of the people below them
  under.forEach((n, i) => { params[`vm${i}`] = n; });
  if (under.length) parts.push(`person IN (${under.map((_, i) => `@vm${i}`).join(',')})`);
  // a customer given to one particular person is not seen through a country, a city or a market grant
  const open = "owner_override = 0 AND TRIM(COALESCE(person, '')) != ''";
  for (const m of a.markets) {
    parts.push(`(${open} AND ${m === 'domestic' ? "market = 'domestic'" : "market != 'domestic'"})`);
  }
  const spelled = spellings().countries
    .filter((c) => a.grantedCountries.has(countryKey(c)));
  spelled.forEach((c, i) => { params[`vc${i}`] = c; });
  if (spelled.length) parts.push(`(${open} AND market != 'domestic' AND country IN (${spelled.map((_, i) => `@vc${i}`).join(',')}))`);
  const cities = spellings().cities
    .filter((c) => a.grantedCities.has(cityKey(c)));
  cities.forEach((c, i) => { params[`vt${i}`] = c; });
  if (cities.length) parts.push(`(${open} AND market = 'domestic' AND city IN (${cities.map((_, i) => `@vt${i}`).join(',')}))`);
  return `(${parts.join(' OR ')})`;
}

// every spelling of a country / a city that customers carry (asked for each list a person opens): kept until a customer is written
const spellings = memoTables(['cards'], () => ({
  countries: (db.prepare("SELECT DISTINCT country FROM cards WHERE market != 'domestic' AND country IS NOT NULL AND country != ''").all() as { country: string }[]).map((r) => r.country),
  cities: (db.prepare("SELECT DISTINCT city FROM cards WHERE market = 'domestic' AND city IS NOT NULL AND city != ''").all() as { city: string }[]).map((r) => r.city),
}));

export function canSeeCard(viewer: Viewer | undefined, card: CardRow): boolean {
  return !!viewer && visibilityFor(viewer)(card);
}

export function filterVisible<T extends CardLike>(viewer: Viewer, cards: T[]): T[] {
  const ok = visibilityFor(viewer);
  return cards.filter(ok);
}

// Which markets' numbers a person may see in aggregates (a total of countries or customers).
export function marketsOf(viewer: Viewer): Set<string> {
  if (viewer.role === 'admin') return new Set(['export', 'domestic']);
  const m = new Set<string>([viewer.market === 'domestic' ? 'domestic' : 'export']);
  for (const x of sharedAccess(viewer).markets) m.add(x);
  return m;
}
