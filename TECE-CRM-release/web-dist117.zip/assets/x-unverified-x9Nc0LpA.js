// Unverified customers: records that are just a name. An admin or the brand manager downloads them as Excel, deletes the rows of companies
// that do not exist, fills the e-mail / web site / phone of the real ones, uploads the file back, checks the preview and applies it.
// Deleted customers go to the junk folder (they can be brought back). Server: routes/unverifiedRoutes.ts, services/unverified.ts.
import { h, Fragment, useState, useEffect, useRef, api, Link, useAuth, useT, Icon, cx, errText, Chip, Stat, Skel, Empty, toast, burst, loc, isTr } from "./x-kit-1W3jRMzJ.js";

const RULES = [
  ["email", "No e-mail"],
  ["web", "No web site"],
  ["phone", "No phone or mobile"],
  ["sap", "No SAP number"],
  ["orders", "No orders, deals or prices"],
  ["offers", "No offers or e-mails sent"],
  ["contacts", "No contact person with an e-mail or phone"],
  ["activity", "Nobody worked on it (no note, call, visit, meeting, task)"],
];
const allOn = () => Object.fromEntries(RULES.map(([k]) => [k, true]));
const n0 = (v) => (v || 0).toLocaleString(loc());
// a stamp the server keeps in UTC, shown in Istanbul time in the user's language
const stamp = (v) => { const d = new Date(String(v || "").replace(" ", "T") + (/[zZ]|[+-]\d\d:?\d\d$/.test(String(v || "")) ? "" : "Z")); return isNaN(d) ? String(v || "").slice(0, 16) : new Intl.DateTimeFormat(loc(), { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit", timeZone: "Europe/Istanbul" }).format(d); };
const day = (s) => (s ? String(s).slice(0, 10) : "");
// the same rule as the server (routes/unverifiedRoutes.ts): an admin, or the brand manager; not an assistant working for somebody
const mayUse = (u) => !!u && !u.actor && (u.role === "admin" || u.area === "brand" || (!!u.perms && u.perms.preset === "brand"));
// the texts of the preview come from the server in English: the fixed ones are in the dictionary, the ones with a name in them are rebuilt here
function say(t, s) {
  if (!s) return "";
  let m = /^(.*) - recognised by its company name: (.*)$/.exec(s);
  if (m) return say(t, m[1]) + " - " + t("recognised by its company name: that customer is kept, nothing in the row is used");
  m = /^The ID belongs to "(.*)": the row is kept, nothing in it is used$/.exec(s);
  if (m) return t("The ID belongs to \"{c}\": the row is kept, nothing in it is used", { c: m[1] });
  m = /^(E-mail|Website|Phone): "(.*)" does not look right$/.exec(s);
  if (m) return t(m[1]) + ": \"" + m[2] + "\" " + t("does not look right");
  m = /^(E-mail|Website|Phone): already "(.*)", not overwritten$/.exec(s);
  if (m) return t(m[1]) + ": " + t("already \"{v}\", not overwritten", { v: m[2] });
  m = /^(\d+)% of the rows are missing from the file\./.exec(s);
  if (m) return t("{p}% of the rows are missing from the file. If the file was cut short by mistake, do not go on.", { p: m[1] });
  m = /^A newer list was downloaded on (.*) UTC\. This file is the older one \((.*)\)/.exec(s);
  if (m) return t("A newer list was downloaded on {a} UTC. This file is the older one ({b}): only its own customers can be deleted.", { a: m[1], b: m[2] });
  return t(s);
}

function saveBlob(blob, name) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

// one list of the preview, folded when long
function PlanList({ title, tone, icon, rows, render, open }) {
  if (!rows.length) return null;
  return h("details", { className: cx("xu-list", tone && "xu-list--" + tone), open: open || rows.length <= 6 },
    h("summary", null, h(Icon, { n: icon, size: 20 }), h("b", null, title), h("span", { className: "xu-list-n" }, n0(rows.length))),
    h("ul", null, rows.slice(0, 400).map((r, i) => h("li", { key: (r.id || "") + "-" + i }, render(r)))),
    rows.length > 400 ? h("p", { className: "tx-muted xu-more" }, "+ " + n0(rows.length - 400)) : null,
  );
}

export function UnverifiedPage() {
  const t = useT();
  const { user } = useAuth();
  const isAdmin = !!user && user.role === "admin";
  const [rules, setRules] = useState(allOn);
  const [f, setF] = useState({ market: "", country: "", source: "", before: "" });
  const [sum, setSum] = useState(null);
  const [err, setErr] = useState(null);
  const [denied, setDenied] = useState(false);
  const [loading, setLoading] = useState(false);
  const [busy, setBusy] = useState("");
  const [plan, setPlan] = useState(null);
  const [planErr, setPlanErr] = useState(null);
  const [confirmN, setConfirmN] = useState("");
  const [sure, setSure] = useState(false);
  const [done, setDone] = useState(null);
  const [drag, setDrag] = useState(false);
  const [n, setN] = useState(0);
  const fileRef = useRef(null);
  const allowed = mayUse(user);
  const criteria = { rules, ...f };
  const key = JSON.stringify(criteria);

  useEffect(() => {
    if (!allowed) return undefined;
    let alive = true;
    setLoading(true);
    const id = setTimeout(() => {
      api.post("/unverified/summary", criteria)
        .then((d) => { if (alive) { setSum(d); setErr(null); } })
        .catch((e) => { if (!alive) return; if (e && e.status === 403) setDenied(true); setErr(errText(e, t("Could not load"))); })
        .finally(() => alive && setLoading(false));
    }, 250);
    return () => { alive = false; clearTimeout(id); };
  }, [key, n]);

  async function download() {
    setBusy("download");
    try {
      const blob = await api.postForBlob("/unverified/download", { ...criteria, lang: isTr() ? "tr" : "en" });
      saveBlob(blob, "unverified-customers-" + new Date().toISOString().slice(0, 10) + ".xlsx");
      toast(t("List downloaded. Delete the rows of companies that do not exist, then upload it here."), "good");
      setN((x) => x + 1);
    } catch (e) {
      toast(errText(e, t("Could not download")), "bad");
    } finally {
      setBusy("");
    }
  }

  async function upload(file) {
    if (!file) return;
    setPlan(null); setPlanErr(null); setDone(null); setSure(false); setConfirmN("");
    if (!/\.xlsx$/i.test(file.name)) { setPlanErr(t("Upload the Excel file (.xlsx) you downloaded here.")); return; }
    setBusy("upload");
    try {
      const fd = new FormData();
      fd.append("file", file);
      setPlan(await api.post("/unverified/preview", fd));
    } catch (e) {
      setPlanErr(errText(e, t("Could not read the file")));
    } finally {
      setBusy("");
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  async function applyPlan(ev) {
    setBusy("apply");
    try {
      const r = await api.post("/unverified/apply", { previewId: plan.previewId, confirm: confirmN });
      setDone(r);
      setPlan(null);
      setN((x) => x + 1);
      const b = ev && ev.currentTarget ? ev.currentTarget.getBoundingClientRect() : null;
      if (b) burst(b.left + b.width / 2, b.top);
      toast(t("Done: {a} moved to junk, {b} completed.", { a: r.moved, b: r.enriched }), "good");
    } catch (e) {
      toast(errText(e, t("Could not apply")), "bad");
      setSure(false);
    } finally {
      setBusy("");
    }
  }

  const set = (k) => (e) => setF((o) => ({ ...o, [k]: e.target.value }));
  const junkLink = isAdmin ? "/admin/junk" : "/my-junk";
  const toDelete = plan ? plan.toDelete.length : 0;
  const filled = plan ? plan.enrich.reduce((a, e) => a + e.fields.length, 0) : 0;
  const needN = plan && plan.needConfirm !== null;
  const canApply = plan && (toDelete > 0 || filled > 0 || plan.notes.length > 0) && (!needN || Number(confirmN) === plan.needConfirm);

  if (denied || !allowed) return h("div", { className: "tx-page xu" },
    h("div", { className: "tx-ph" }, h("div", { className: "tx-ph-main" }, h("h1", { className: "tc-title tc-title--sm" }, h("b", null, t("Unverified customers"))))),
    h(Empty, { icon: "lock", title: t("Only an admin or the brand manager can clean up unverified customers.") }, t("Ask an admin if you think you should have it.")));
  return h("div", { className: "tx-page xu" },
    h("div", { className: "tx-ph" },
      h("div", { className: "tx-ph-main" },
        h("h1", { className: "tc-title tc-title--sm" }, h("b", null, t("Unverified customers"))),
        h("p", { className: "tx-lead" }, t("Customers that are just a name: nobody knows if they exist. Download the list, delete the rows of the ones that do not exist, complete the real ones, and upload it back.")),
      ),
      h("div", { className: "tx-bar" },
        h(Link, { className: "tc-btn tc-btn--secondary tc-btn--md", to: junkLink }, h(Icon, { n: "inventory-2" }), t("Junk folder")),
      ),
    ),
    h("ol", { className: "xu-steps", "aria-label": t("How it works") },
      [["filter-list", "Choose who counts"], ["download", "Download the list"], ["table-chart", "Delete rows, fill e-mails in Excel"], ["upload", "Upload and check"], ["check-circle", "Apply"]].map(([ic, l], i) =>
        h("li", { key: l, className: cx(i === 3 && plan && "on", i === 4 && done && "on") }, h("span", { className: "xu-step-n" }, i + 1), h(Icon, { n: ic, size: 20 }), h("span", null, t(l)))),
    ),
    err ? h("p", { className: "tx-err", role: "alert" }, err) : null,

    h("div", { className: "xu-grid" },
      h("section", { className: "xu-card xu-rules", "aria-labelledby": "xu-rules-t" },
        h("h2", { className: "xu-h2", id: "xu-rules-t" }, h(Icon, { n: "rule", size: 20 }), t("What counts as unverified")),
        h("p", { className: "tx-muted xu-sub" }, t("A customer is on the list when all the ticked points are true.")),
        h("div", { className: "xu-checks" }, RULES.map(([k, l]) =>
          h("label", { key: k, className: "tc-check xu-check" },
            h("input", { type: "checkbox", checked: rules[k], onChange: (e) => setRules((o) => ({ ...o, [k]: e.target.checked })) }),
            h("span", null, t(l))))),
        h("div", { className: "xu-filters" },
          h("label", { className: "xu-f" }, h("span", null, t("Market")),
            h("select", { className: "xu-sel", value: f.market, onChange: set("market") },
              h("option", { value: "" }, t("All markets")), h("option", { value: "export" }, t("Export")), h("option", { value: "domestic" }, t("Domestic")))),
          h("label", { className: "xu-f" }, h("span", null, t("Country")),
            h("select", { className: "xu-sel", value: f.country, onChange: set("country") },
              h("option", { value: "" }, t("All countries")),
              (sum ? sum.countries : []).map((c) => h("option", { key: c.v, value: c.v }, c.v + " (" + n0(c.n) + ")")),
              f.country && sum && !sum.countries.some((c) => c.v === f.country) ? h("option", { value: f.country }, f.country) : null)),
          h("label", { className: "xu-f" }, h("span", null, t("Source")),
            h("select", { className: "xu-sel", value: f.source, onChange: set("source") },
              h("option", { value: "" }, t("All sources")),
              (sum ? sum.sources : []).map((c) => h("option", { key: c.v, value: c.v }, c.v + " (" + n0(c.n) + ")")),
              f.source && sum && !sum.sources.some((c) => c.v === f.source) ? h("option", { value: f.source }, f.source) : null)),
          h("label", { className: "xu-f" }, h("span", null, t("Created before")),
            h("input", { className: "xu-sel", type: "date", value: f.before, onChange: set("before") })),
        ),
        h("button", { type: "button", className: "tc-btn tc-btn--ghost tc-btn--sm", onClick: () => { setRules(allOn()); setF({ market: "", country: "", source: "", before: "" }); } }, h(Icon, { n: "undo", size: 16 }), t("Back to the standard rules")),
      ),

      h("section", { className: "xu-card xu-count", "aria-live": "polite" },
        !sum ? h(Skel, { height: 180 }) : h(Fragment, null,
          h("span", { className: "xu-eyebrow" }, sum.scope === "everybody" ? t("In the whole database") : t("Among the customers you may see")),
          h("b", { className: cx("xu-big", loading && "xu-dim") }, n0(sum.count)),
          h("span", { className: "xu-big-l" }, t("customers are just a name")),
          sum.count !== sum.all ? h("small", { className: "tx-muted" }, t("{n} without the filters", { n: n0(sum.all) })) : null,
          sum.keptAnyway > 0 ? h("p", { className: "xu-note" }, h(Icon, { n: "lock", size: 16 }), t("{n} of them can never be deleted from the file (rated 5+, locked, or somebody worked on them).", { n: n0(sum.keptAnyway) })) : null,
          h("button", { type: "button", className: "tc-btn tc-btn--md xu-cta", disabled: !sum.count || busy === "download", onClick: download },
            h(Icon, { n: "download", size: 20 }), busy === "download" ? t("Preparing the file…") : t("Download list (.xlsx)")),
          h("p", { className: "tx-small tx-muted" }, sum.count > 20000 ? t("The file holds the first 20,000. Use the filters for the rest.") : t("The file explains itself on its first sheet.")),
          sum.scope !== "everybody" ? h("p", { className: "tx-small tx-muted" }, t("You see the customers you may see and the ones you brought in. An admin sees all of them.")) : null,
        ),
      ),
    ),

    sum && sum.sample.length > 0 ? h("section", { className: "xu-card", "aria-labelledby": "xu-sample-t" },
      h("h2", { className: "xu-h2", id: "xu-sample-t" }, h(Icon, { n: "visibility", size: 20 }), t("A look at the list"), h("span", { className: "xu-list-n" }, t("first {n}", { n: sum.sample.length }))),
      h("div", { className: "xu-table-wrap" },
        h("table", { className: "tc-table tc-table--data tc-table--sm xu-table" },
          h("thead", null, h("tr", null, ["Company", "Name", "Country", "Source", "Created", "Owner"].map((c) => h("th", { key: c }, t(c))))),
          h("tbody", null, sum.sample.map((r) => h("tr", { key: r.id },
            h("td", null, h(Link, { className: "tc-link", to: "/cards/" + r.id }, r.company || "#" + r.id)),
            h("td", null, r.name || "–"), h("td", null, r.country || r.city || "–"), h("td", null, r.source || "–"), h("td", null, day(r.created_at)), h("td", null, r.owner || h("span", { className: "tx-muted" }, t("nobody")))))),
        ),
      ),
    ) : sum && sum.count === 0 ? h(Empty, { icon: "verified", title: t("Nobody is just a name.") }, t("No customer matches these rules. Untick a point to widen the list.")) : null,

    h("section", { className: "xu-card xu-up", "aria-labelledby": "xu-up-t" },
      h("h2", { className: "xu-h2", id: "xu-up-t" }, h(Icon, { n: "upload", size: 20 }), t("Upload the edited file")),
      h("label", {
        className: cx("xu-drop", drag && "xu-drop--on", busy === "upload" && "xu-dim"),
        onDragOver: (e) => { e.preventDefault(); setDrag(true); },
        onDragLeave: () => setDrag(false),
        onDrop: (e) => { e.preventDefault(); setDrag(false); upload(e.dataTransfer.files && e.dataTransfer.files[0]); },
      },
        h("input", { ref: fileRef, type: "file", accept: ".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", className: "xu-file", onChange: (e) => upload(e.target.files && e.target.files[0]) }),
        h(Icon, { n: "table-chart", size: 32 }),
        h("b", null, busy === "upload" ? t("Reading the file…") : t("Drop the Excel file here, or click to choose it")),
        h("span", null, t("Nothing changes yet: you will see what will happen first.")),
      ),
      planErr ? h("p", { className: "xu-warn xu-warn--bad", role: "alert" }, h(Icon, { n: "warning", size: 20 }), planErr) : null,
    ),

    plan ? h("section", { className: "xu-card xu-plan", "aria-labelledby": "xu-plan-t" },
      h("h2", { className: "xu-h2", id: "xu-plan-t" }, h(Icon, { n: "fact-check", size: 20 }), t("What will happen")),
      h("p", { className: "tx-muted xu-sub" }, t("List #{id} downloaded {d} by {who}: {a} customers. The file has {b} rows.", { id: plan.batchId, d: stamp(plan.downloadedAt), who: plan.downloadedBy || "–", a: n0(plan.batchRows), b: n0(plan.fileRows) })),
      plan.warnings.map((w, i) => h("p", { key: i, className: "xu-warn", role: "alert" }, h(Icon, { n: "warning", size: 20 }), say(t, w))),
      h("div", { className: "xu-stats" },
        h(Stat, { n: n0(plan.kept), label: t("kept") }),
        h(Stat, { n: n0(plan.enrich.filter((e) => e.fields.length).length), label: t("completed"), sub: filled ? t("{n} fields filled", { n: filled }) : null, tone: filled ? "good" : "" }),
        h(Stat, { n: n0(toDelete), label: t("to the junk folder"), tone: toDelete ? "alert" : "" }),
        h(Stat, { n: n0(plan.protectedRows.length), label: t("missing but kept (safety)") }),
        h(Stat, { n: n0(plan.ignored.length), label: t("rows ignored") }),
      ),
      h(PlanList, { title: t("Deleted from the file: these go to the junk folder"), tone: "bad", open: true, icon: "delete", rows: plan.toDelete, render: (r) => h(Fragment, null, h(Link, { className: "tc-link", to: "/cards/" + r.id, target: "_blank" }, r.company), r.country ? h("small", null, r.country) : null) }),
      h(PlanList, { title: t("Completed: empty fields that will be filled"), tone: "good", icon: "edit-note", rows: plan.enrich.filter((e) => e.fields.length || e.skipped.length), render: (r) => h(Fragment, null, h("b", null, r.company), r.fields.map((x) => h(Chip, { key: x.field, tone: "good" }, x.value)), r.skipped.map((x, i) => h("small", { key: i, className: "xu-skip" }, say(t, x)))) }),
      h(PlanList, { title: t("Notes that will be added"), icon: "edit-note", rows: plan.notes, render: (r) => h(Fragment, null, h("b", null, r.company), h("small", null, r.text)) }),
      h(PlanList, { title: t("Missing from the file but kept"), tone: "warn", icon: "lock", rows: plan.protectedRows, render: (r) => h(Fragment, null, h("b", null, r.company), h("small", null, say(t, r.reason))) }),
      h(PlanList, { title: t("Rows ignored"), icon: "info", rows: plan.ignored, render: (r) => h(Fragment, null, h("b", null, t("Row {n}", { n: r.row })), r.company ? h("span", null, r.company) : null, h("small", null, say(t, r.reason))) }),
      h("div", { className: "xu-safety" },
        h("b", null, h(Icon, { n: "verified", size: 16 }), t("Safety rules applied")),
        h("ul", null,
          h("li", null, t("Only customers that were in this download can be deleted; customers added later are never touched.")),
          h("li", null, t("Never deleted: locked by an admin, a SAP number, orders, offers, somebody worked on it, rated 5 or higher, an e-mail, web site, phone or contact person, or changed after the download.")),
          h("li", null, t("A value a customer already has is never overwritten.")),
          h("li", null, t("Deleted customers go to the junk folder with all their data, and can be brought back.")),
        ),
      ),
      needN ? h("label", { className: "xu-confirm" },
        h("span", null, t("Many rows are missing. To be sure the file was not cut short, type {n} (the number of customers that will be deleted).", { n: plan.needConfirm })),
        h("input", { className: "tc-input", inputMode: "numeric", value: confirmN, onChange: (e) => setConfirmN(e.target.value.replace(/[^\d]/g, "")), placeholder: String(plan.needConfirm), "aria-label": t("Number of customers that will be deleted") })) : null,
      h("div", { className: "xu-actions" },
        h("button", { type: "button", className: "tc-btn tc-btn--ghost tc-btn--md", onClick: () => { setPlan(null); setSure(false); } }, t("Cancel")),
        !canApply ? h("button", { type: "button", className: "tc-btn tc-btn--md", disabled: true }, toDelete || filled || plan.notes.length ? t("Type the number to go on") : t("Nothing to change"))
          : !sure ? h("button", { type: "button", className: cx("tc-btn tc-btn--md", toDelete > 0 && "tc-btn--danger"), onClick: () => setSure(true) },
            h(Icon, { n: toDelete ? "delete" : "check-circle", size: 20 }), toDelete ? t("Move {n} to junk and save the changes", { n: n0(toDelete) }) : t("Save the changes"))
          : h("button", { type: "button", className: cx("tc-btn tc-btn--md", toDelete > 0 && "tc-btn--danger"), disabled: busy === "apply", onClick: applyPlan, autoFocus: true },
            h(Icon, { n: "check-circle", size: 20 }), busy === "apply" ? t("Working…") : toDelete ? t("Yes, move {n} customers to the junk folder", { n: n0(toDelete) }) : t("Yes, save")),
      ),
    ) : null,

    done ? h("section", { className: "xu-card xu-done", role: "status" },
      h(Icon, { n: "check-circle", size: 32 }),
      h("div", null,
        h("b", null, t("The list is cleaned up.")),
        h("p", null, t("{a} moved to the junk folder · {b} completed ({c} fields) · {d} notes added · {e} kept.", { a: n0(done.moved), b: n0(done.enriched), c: n0(done.filled), d: n0(done.noted), e: n0(done.kept + done.protected + done.keptNow) })),
        done.keptNow > 0 ? h("p", { className: "tx-small" }, t("{n} were kept at the last moment: somebody worked on them after the preview.", { n: done.keptNow })) : null,
        done.moved > 0 ? h(Link, { className: "tc-btn tc-btn--secondary tc-btn--sm", to: junkLink }, h(Icon, { n: "undo", size: 16 }), t("Open the junk folder to bring one back")) : null,
      ),
    ) : null,

    sum && sum.recent.length > 0 ? h("section", { className: "xu-card", "aria-labelledby": "xu-recent-t" },
      h("h2", { className: "xu-h2", id: "xu-recent-t" }, h(Icon, { n: "inventory-2", size: 20 }), t("Downloaded lists")),
      h("ul", { className: "xu-recent" }, sum.recent.map((b) => h("li", { key: b.id },
        h("b", null, "#" + b.id), h("span", null, String(b.created_at).slice(0, 16)), h("span", null, b.by_name || ""), h("span", null, t("{n} customers", { n: n0(b.row_count) })),
        b.applied_at ? h(Chip, { tone: "good", icon: "check-circle" }, t("used: {a} to junk, {b} completed", { a: b.result ? b.result.moved : 0, b: b.result ? b.result.enriched : 0 })) : h(Chip, null, t("waiting for the file")),
      ))),
    ) : null,
  );
}

// a small block for the Brand page: how many customers are just a name, and the way to the tool
export function UnverifiedNudge() {
  const t = useT();
  const { user } = useAuth();
  const allowed = mayUse(user);
  const [sum, setSum] = useState(null);
  useEffect(() => { if (!allowed) return undefined; let alive = true; api.post("/unverified/summary", {}).then((d) => alive && setSum(d)).catch(() => void 0); return () => { alive = false; }; }, [allowed]);
  if (!allowed || !sum) return null;
  return h("section", { className: "xu-nudge" },
    h(Icon, { n: "cleaning-services", size: 24 }),
    h("div", null,
      h("b", null, sum.count > 0 ? t("{n} customers are just a name", { n: n0(sum.count) }) : t("Nobody is just a name.")),
      h("span", null, t("No e-mail, no web site, no phone, nobody worked on them. Check them in Excel and delete the ones that do not exist."))),
    h(Link, { className: "tc-btn tc-btn--secondary tc-btn--sm", to: "/unverified-customers" }, t("Unverified customers"), h(Icon, { n: "arrow-forward", size: 16 })),
  );
}
