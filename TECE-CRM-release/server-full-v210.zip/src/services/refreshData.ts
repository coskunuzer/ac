import { db } from '../db/connection';
import { cardModel, type CardRow } from '../models/cardModel';
import { countryModel } from '../models/countryModel';
import { analyseCard, parseInsight } from './aiInsight';
import { enrichCompany } from './companyEnrich';
import { syncCustomerFolder } from './customerFiles';
import { interestOf } from './interest';

// "Update all existing records with the latest features", in small batches so one request never
// takes long. For every customer: the AI reads the notes (next steps, offer wanted, products,
// company information), the company's web site is read, products the notes mention are ticked,
// an empty responsible person is filled from the country list, and the customer's folder is
// renamed / refreshed. Nothing a person typed is overwritten: ticks are only added, and the
// work area and the responsible person are only filled when they were empty.

export interface RefreshProgress {
  total: number;
  next: number | null; // offset of the next batch, null when finished
  processed: number;
  aiRead: number; // read by the AI
  plainRead: number; // read from the plain words (the AI could not be reached)
  alreadyRead: number; // had a full AI reading from before
  sitesFound: number; // company web sites read
  personFilled: number;
  folders: number;
}

function needsReading(card: CardRow): boolean {
  const i = parseInsight(card.ai_insight);
  if (!i || i.source !== 'ai') return true;
  // read by the AI before the company information existed
  return !i.companyProfile && !i.companyType && !i.approach;
}

async function refreshCard(card: CardRow, p: RefreshProgress): Promise<void> {
  if (needsReading(card)) {
    const interest = interestOf(card);
    const insight = await analyseCard(card, { products: interest.products, widths: interest.widths, other: interest.other || null });
    cardModel.setInsight(card.id, insight);
    cardModel.mergeInterest(card.id, insight.products, insight.widths);
    if (card.offer_percent === null && insight.discountPercent) cardModel.update(card.id, { offerPercent: insight.discountPercent / 100 });
    if (insight.source === 'ai') p.aiRead += 1;
    else p.plainRead += 1;
  } else {
    p.alreadyRead += 1;
  }

  if (!card.person?.trim()) {
    const owner = countryModel.findByCountry(card.country)?.responsible;
    if (owner) {
      cardModel.setPersonIfEmpty(card.id, owner);
      p.personFilled += 1;
    }
  }

  await enrichCompany(card.id);
  if (parseInsight(cardModel.findById(card.id)?.ai_insight)?.websiteSummary) p.sitesFound += 1;
  if (syncCustomerFolder(card.id)) p.folders += 1;
}

export async function refreshBatch(offset: number, limit = 12, concurrency = 4): Promise<RefreshProgress> {
  // the customer database (leads) is not part of this: it has tens of thousands of rows and they are read on demand
  // Only the numbers of the customers are read to find the batch (before, every batch read all ~20,000 customers in full - notes, AI texts and all -
  // which held the whole server for seconds, batch after batch, while the update ran).
  const all = db.prepare("SELECT id FROM cards WHERE stage IS NULL OR stage != 'lead' ORDER BY id").all() as { id: number }[];
  const batch = all.slice(offset, offset + limit).map((r) => cardModel.findById(r.id)).filter((c): c is CardRow => !!c);
  const p: RefreshProgress = { total: all.length, next: offset + limit < all.length ? offset + limit : null, processed: batch.length, aiRead: 0, plainRead: 0, alreadyRead: 0, sitesFound: 0, personFilled: 0, folders: 0 };
  const queue = [...batch];
  await Promise.all(
    Array.from({ length: Math.min(concurrency, queue.length) }, async () => {
      for (let card = queue.shift(); card; card = queue.shift()) {
        try {
          await refreshCard(card, p);
        } catch (err) {
          console.error('Refreshing record', card.id, 'failed:', err);
        }
      }
    })
  );
  return p;
}
