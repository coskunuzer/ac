import zlib from 'zlib';

// Minimal Enhanced Metafile (EMF) player for the vector logos stored in the
// price workbook (filled bezier paths). It draws path fills/strokes with the
// selected brush/pen colours; text and bitmaps are not supported.

export interface Emf {
  records: Buffer;
  bounds: { left: number; top: number; right: number; bottom: number };
}

// The workbook stores EMF pictures deflate-compressed behind a 34-byte metafile header
// (given here without the leading picture id).
export function decodeEmfBlip(blip: Buffer): Emf | null {
  try {
    const compressed = blip.readUInt8(32) === 0;
    let data = blip.subarray(34);
    if (compressed) data = zlib.inflateSync(data);
    if (data.readUInt32LE(0) !== 1) return null;
    return {
      records: data,
      bounds: { left: data.readInt32LE(8), top: data.readInt32LE(12), right: data.readInt32LE(16), bottom: data.readInt32LE(20) },
    };
  } catch {
    return null;
  }
}

const rgb = (v: number) => `#${[v & 0xff, (v >> 8) & 0xff, (v >> 16) & 0xff].map((n) => n.toString(16).padStart(2, '0')).join('')}`;

interface PdfLike {
  save(): unknown;
  restore(): unknown;
  moveTo(x: number, y: number): unknown;
  lineTo(x: number, y: number): unknown;
  bezierCurveTo(a: number, b: number, c: number, d: number, e: number, f: number): unknown;
  closePath(): unknown;
  fill(color?: string, rule?: string): unknown;
  stroke(color?: string): unknown;
  fillAndStroke(fill?: string, stroke?: string, rule?: string): unknown;
  clip(rule?: string): unknown;
  lineWidth(w: number): unknown;
}

export function drawEmf(doc: PdfLike, emf: Emf, x: number, y: number, w: number, h: number) {
  const b = emf.bounds;
  const bw = Math.max(1, b.right - b.left + 1);
  const bh = Math.max(1, b.bottom - b.top + 1);
  // logical -> device (window/viewport mapping), then device -> the target box
  let winOrg = [0, 0], winExt = [1, 1], vpOrg = [0, 0], vpExt = [1, 1];
  const devX = (lx: number) => (lx - winOrg[0]) * (vpExt[0] / winExt[0]) + vpOrg[0];
  const devY = (ly: number) => (ly - winOrg[1]) * (vpExt[1] / winExt[1]) + vpOrg[1];
  const px = (lx: number) => x + ((devX(lx) - b.left) / bw) * w;
  const py = (ly: number) => y + ((devY(ly) - b.top) / bh) * h;

  const brushes = new Map<number, string | null>();
  const pens = new Map<number, { color: string | null; width: number }>();
  let fillColor: string | null = '#000000';
  let pen: { color: string | null; width: number } = { color: '#000000', width: 1 };
  let evenOdd = false;
  let cx = 0;
  let cy = 0;

  const data = emf.records;
  let pos = 0;
  doc.save();
  while (pos + 8 <= data.length) {
    const type = data.readUInt32LE(pos);
    const size = data.readUInt32LE(pos + 4);
    if (size < 8) break;
    const r = data.subarray(pos, pos + size);
    const i32 = (o: number) => r.readInt32LE(o);
    const i16 = (o: number) => r.readInt16LE(o);

    const poly = (first: 'move' | 'continue', kind: 'bezier' | 'line', wide = false) => {
      const n = r.readUInt32LE(24);
      const o = 28;
      const step = wide ? 8 : 4;
      const pt = (k: number) =>
        (wide ? [px(i32(o + k * step)), py(i32(o + k * step + 4))] : [px(i16(o + k * step)), py(i16(o + k * step + 2))]) as [number, number];
      let k = 0;
      if (first === 'move' && n > 0) { const [mx, my] = pt(0); doc.moveTo(mx, my); k = 1; }
      if (kind === 'bezier') {
        for (; k + 2 < n; k += 3) {
          const [a1, a2] = pt(k), [b1, b2] = pt(k + 1), [c1, c2] = pt(k + 2);
          doc.bezierCurveTo(a1, a2, b1, b2, c1, c2);
        }
      } else {
        for (; k < n; k++) { const [lx, ly] = pt(k); doc.lineTo(lx, ly); }
      }
    };

    switch (type) {
      case 9: winExt = [i32(8) || 1, i32(12) || 1]; break; // SETWINDOWEXTEX
      case 10: winOrg = [i32(8), i32(12)]; break; // SETWINDOWORGEX
      case 11: vpExt = [i32(8) || 1, i32(12) || 1]; break; // SETVIEWPORTEXTEX
      case 12: vpOrg = [i32(8), i32(12)]; break; // SETVIEWPORTORGEX
      case 19: evenOdd = i32(8) === 1; break; // SETPOLYFILLMODE (1 = alternate)
      case 2: poly('move', 'bezier', true); break; // POLYBEZIER
      case 3: poly('move', 'line', true); doc.closePath(); break; // POLYGON
      case 4: poly('move', 'line', true); break; // POLYLINE
      case 5: poly('continue', 'bezier', true); break; // POLYBEZIERTO
      case 6: poly('continue', 'line', true); break; // POLYLINETO
      case 33: doc.save(); break; // SAVEDC
      case 34: doc.restore(); break; // RESTOREDC
      case 39: // CREATEBRUSHINDIRECT
        brushes.set(r.readUInt32LE(8), r.readUInt32LE(12) === 1 ? null : rgb(r.readUInt32LE(16)));
        break;
      case 95: // EXTCREATEPEN
        pens.set(r.readUInt32LE(8), { color: (r.readUInt32LE(28) & 0xf) === 5 ? null : rgb(r.readUInt32LE(40)), width: r.readUInt32LE(32) });
        break;
      case 37: { // SELECTOBJECT
        const h = r.readUInt32LE(8);
        if (h & 0x80000000) {
          const stock = h & 0x7fffffff;
          if (stock === 0) fillColor = '#ffffff';
          else if (stock === 4) fillColor = '#000000';
          else if (stock === 5) fillColor = null;
          else if (stock === 8) pen = { color: null, width: 0 };
          else if (stock === 7) pen = { color: '#000000', width: 1 };
        } else if (brushes.has(h)) fillColor = brushes.get(h) ?? null;
        else if (pens.has(h)) pen = pens.get(h)!;
        break;
      }
      case 27: cx = i32(8); cy = i32(12); doc.moveTo(px(cx), py(cy)); break; // MOVETOEX
      case 54: cx = i32(8); cy = i32(12); doc.lineTo(px(cx), py(cy)); break; // LINETO
      case 85: poly('move', 'bezier'); break; // POLYBEZIER16
      case 88: poly('continue', 'bezier'); break; // POLYBEZIERTO16
      case 86: case 87: poly('move', 'line'); if (type === 86) doc.closePath(); break; // POLYGON16 / POLYLINE16
      case 89: poly('continue', 'line'); break; // POLYLINETO16
      case 91: { // POLYPOLYGON16
        const nPolys = r.readUInt32LE(24);
        let o = 32 + nPolys * 4;
        for (let p = 0; p < nPolys; p++) {
          const count = r.readUInt32LE(32 + p * 4);
          for (let k = 0; k < count; k++) {
            const lx = px(r.readInt16LE(o)), ly = py(r.readInt16LE(o + 2));
            if (k === 0) doc.moveTo(lx, ly); else doc.lineTo(lx, ly);
            o += 4;
          }
          doc.closePath();
        }
        break;
      }
      case 61: doc.closePath(); break; // CLOSEFIGURE
      case 62: if (fillColor) doc.fill(fillColor, evenOdd ? 'even-odd' : 'non-zero'); break; // FILLPATH
      case 63: // STROKEANDFILLPATH
        doc.lineWidth(Math.max(0.2, pen.width * (w / bw)));
        if (fillColor && pen.color) doc.fillAndStroke(fillColor, pen.color, evenOdd ? 'even-odd' : 'non-zero');
        else if (fillColor) doc.fill(fillColor, evenOdd ? 'even-odd' : 'non-zero');
        break;
      case 64: if (pen.color) { doc.lineWidth(Math.max(0.2, pen.width * (w / bw))); doc.stroke(pen.color); } break; // STROKEPATH
      case 67: doc.clip(evenOdd ? 'even-odd' : 'non-zero'); break; // SELECTCLIPPATH
    }
    pos += size;
  }
  doc.restore();
}
