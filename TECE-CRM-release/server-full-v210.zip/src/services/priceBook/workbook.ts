import * as XLSX from 'xlsx';
import { evaluateFormula, FormulaError, type Resolver, type Value } from './formula';

export interface RawCell {
  v: Value;
  f?: string;
  err?: string;
  // Number format as saved in the workbook (e.g. "0.000") - used so the PDF
  // shows prices with the same precision as the Excel does.
  z?: string;
}

export interface CellRange {
  r1: number;
  c1: number;
  r2: number;
  c2: number;
}

export interface SheetData {
  name: string;
  cells: Map<string, RawCell>;
  hiddenCols: Set<string>;
  comments: Map<string, string>;
  maxRow: number;
  maxCol: number;
  // Layout, used to print the sheet the way Excel does (all indexes 0-based).
  merges: CellRange[];
  colWidthPt: Map<number, number>;
  rowHeightPt: Map<number, number>;
  hiddenRows: Set<number>;
  fills: Map<string, string>; // "A1" -> RGB hex
  margins: { left: number; right: number; top: number; bottom: number; header: number; footer: number };
}

export function colToIndex(col: string): number {
  let n = 0;
  for (const ch of col) n = n * 26 + (ch.charCodeAt(0) - 64);
  return n;
}

export function indexToCol(index: number): string {
  let s = '';
  let n = index;
  while (n > 0) {
    const rem = (n - 1) % 26;
    s = String.fromCharCode(65 + rem) + s;
    n = Math.floor((n - 1) / 26);
  }
  return s;
}

export function splitAddr(addr: string): { col: string; row: number } {
  const m = /^([A-Z]+)(\d+)$/.exec(addr);
  if (!m) throw new Error(`Bad cell address: ${addr}`);
  return { col: m[1], row: parseInt(m[2], 10) };
}

export class Workbook {
  readonly sheets = new Map<string, SheetData>();

  static parse(buffer: Buffer): Workbook {
    const raw = XLSX.read(buffer, { type: 'buffer', cellFormula: true, cellStyles: true, cellNF: true });
    const wb = new Workbook();
    for (const name of raw.SheetNames) {
      const ws = raw.Sheets[name];
      const cells = new Map<string, RawCell>();
      const comments = new Map<string, string>();
      let maxRow = 0;
      let maxCol = 0;
      for (const addr of Object.keys(ws)) {
        if (addr[0] === '!') continue;
        const c = ws[addr] as XLSX.CellObject;
        const { col, row } = splitAddr(addr);
        maxRow = Math.max(maxRow, row);
        maxCol = Math.max(maxCol, colToIndex(col));
        const cell: RawCell = { v: null };
        if (c.t === 'e') cell.err = c.w && c.w.startsWith('#') ? c.w : '#REF!';
        else if (c.t === 'n' || c.t === 's' || c.t === 'b') cell.v = c.v as Value;
        else if (c.t === 'd') cell.v = null;
        if (c.f) cell.f = c.f;
        if (c.z && typeof c.z === 'string') cell.z = c.z;
        if (cell.v === undefined) cell.v = null;
        cells.set(addr, cell);
        if (c.c && c.c.length) comments.set(addr, c.c.map((x) => x.t).join(' ').replace(/\s+/g, ' ').trim());
      }
      const hiddenCols = new Set<string>();
      const colWidthPt = new Map<number, number>();
      (ws['!cols'] || []).forEach((c, i) => {
        if (!c) return;
        if (c.hidden) hiddenCols.add(indexToCol(i + 1));
        if (typeof c.wpx === 'number') colWidthPt.set(i, c.wpx * 0.75);
      });
      const rowHeightPt = new Map<number, number>();
      const hiddenRows = new Set<number>();
      (ws['!rows'] || []).forEach((r, i) => {
        if (!r) return;
        if (r.hidden) hiddenRows.add(i);
        if (typeof r.hpt === 'number') rowHeightPt.set(i, r.hpt);
      });
      const merges: CellRange[] = (ws['!merges'] || []).map((m) => ({ r1: m.s.r, c1: m.s.c, r2: m.e.r, c2: m.e.c }));
      const fills = new Map<string, string>();
      for (const addr of cells.keys()) {
        const style = (ws[addr] as XLSX.CellObject | undefined)?.s as { patternType?: string; fgColor?: { rgb?: string } } | undefined;
        if (style && style.patternType === 'solid' && style.fgColor?.rgb) fills.set(addr, style.fgColor.rgb.toUpperCase());
      }
      const m = ws['!margins'] || {};
      const margins = {
        left: m.left ?? 0.7, right: m.right ?? 0.7, top: m.top ?? 0.75, bottom: m.bottom ?? 0.75,
        header: m.header ?? 0.3, footer: m.footer ?? 0.3,
      };
      wb.sheets.set(name, { name, cells, hiddenCols, comments, maxRow, maxCol, merges, colWidthPt, rowHeightPt, hiddenRows, fills, margins });
    }
    return wb;
  }

  evaluator(overrides: Record<string, Value> = {}): Evaluator {
    return new Evaluator(this, overrides);
  }
}

export class Evaluator implements Resolver {
  private memo = new Map<string, Value | FormulaError>();
  private active = new Set<string>();
  private overrides: Map<string, Value>;

  constructor(private wb: Workbook, overrides: Record<string, Value>) {
    this.overrides = new Map(Object.entries(overrides));
  }

  // Throws a FormulaError for error cells, like Excel propagates them.
  cell(sheet: string, addr: string): Value {
    const key = `${sheet}!${addr}`;
    if (this.overrides.has(key)) return this.overrides.get(key) ?? null;

    const cached = this.memo.get(key);
    if (cached instanceof FormulaError) throw cached;
    if (cached !== undefined) return cached;

    const sd = this.wb.sheets.get(sheet);
    if (!sd) throw new FormulaError('#REF!');
    const raw = sd.cells.get(addr);
    if (!raw) return null;

    if (raw.err) {
      const e = new FormulaError(raw.err);
      this.memo.set(key, e);
      throw e;
    }
    if (raw.f === undefined) return raw.v;

    if (this.active.has(key)) throw new FormulaError('#REF!');
    this.active.add(key);
    try {
      const result = evaluateFormula(raw.f, sheet, this);
      const value = result === null ? 0 : result;
      this.memo.set(key, value);
      return value;
    } catch (e) {
      const err = e instanceof FormulaError ? e : new FormulaError('#VALUE!');
      this.memo.set(key, err);
      throw err;
    } finally {
      this.active.delete(key);
    }
  }

  range(sheet: string, from: string, to: string): Value[] {
    const a = splitAddr(from);
    const b = splitAddr(to);
    const out: Value[] = [];
    for (let r = Math.min(a.row, b.row); r <= Math.max(a.row, b.row); r++) {
      for (let c = Math.min(colToIndex(a.col), colToIndex(b.col)); c <= Math.max(colToIndex(a.col), colToIndex(b.col)); c++) {
        out.push(this.cell(sheet, `${indexToCol(c)}${r}`));
      }
    }
    return out;
  }

  // Non-throwing read: error cells come back as null.
  value(sheet: string, addr: string): Value {
    try {
      return this.cell(sheet, addr);
    } catch {
      return null;
    }
  }

  number(sheet: string, addr: string): number | null {
    const v = this.value(sheet, addr);
    return typeof v === 'number' && Number.isFinite(v) ? v : null;
  }
}
