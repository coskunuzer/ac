-- Update 14 November: SWIFT copies (money on its way) and tracking of samples.

-- A customer says "I paid" and sends the SWIFT copy, but the money needs a few days to reach the account. Until the ledger shows it, that amount is
-- counted as "on its way": it is taken off the overdue figure, so no payment reminder or statement goes out for it. It resolves itself when the
-- ledger shows the money (or a person cancels it).
CREATE TABLE IF NOT EXISTS perf_swift (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sap_no TEXT NOT NULL,
  amount REAL NOT NULL,
  currency TEXT NOT NULL,
  swift_date TEXT NOT NULL,               -- the day of the SWIFT copy
  invoices TEXT,                          -- JSON list of invoice keys ("date|description") the payment is for; empty = oldest first
  note TEXT,
  status TEXT NOT NULL DEFAULT 'waiting', -- waiting | arrived | cancelled
  resolved_at TEXT,
  created_by INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_perf_swift_sap ON perf_swift (sap_no, status);

-- Every sample note becomes a sample record, so a tracking number can be added later, and the delivery is followed.
ALTER TABLE card_samples ADD COLUMN activity_id INTEGER;
ALTER TABLE card_samples ADD COLUMN delivery_status TEXT;     -- in_transit | out_for_delivery | delivered | problem | unknown
ALTER TABLE card_samples ADD COLUMN delivery_detail TEXT;     -- the latest event of the courier
ALTER TABLE card_samples ADD COLUMN delivered_at TEXT;
ALTER TABLE card_samples ADD COLUMN checked_at TEXT;
