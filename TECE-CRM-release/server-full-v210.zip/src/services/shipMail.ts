import nodemailer from 'nodemailer';
import { db } from '../db/connection';
import { env } from '../config/env';
import { settingsModel } from '../models/settingsModel';

// The shipping mailbox (nakliye@tece.com.tr): requests go out from it and the replies are read from it. Its login is typed by an admin in the settings
// (never shown again, never logged). Every message that goes out is kept with its text and its status, so a failed one is never lost.
export interface ShipConfig { user: string; hasPassword: boolean; smtpHost: string; smtpPort: number; imapHost: string; imapPort: number; fromName: string; managerEmail: string; remindHours: number; lateDays: number; testMode: boolean; testEmail: string }
const num = (v: string | null, d: number) => (v && Number.isFinite(Number(v)) ? Number(v) : d);

export function shipConfig(): ShipConfig {
  const host = settingsModel.get('ship_smtp_host') || env.smtp.host || 'mail.tece.com.tr';
  return {
    user: settingsModel.get('ship_mail_user') || 'nakliye@tece.com.tr', hasPassword: !!settingsModel.get('ship_mail_password'),
    smtpHost: host, smtpPort: num(settingsModel.get('ship_smtp_port'), 465), imapHost: settingsModel.get('ship_imap_host') || host, imapPort: num(settingsModel.get('ship_imap_port'), 993),
    fromName: settingsModel.get('ship_from_name') || 'TECE Dekor - Operasyon', managerEmail: settingsModel.get('ship_manager_email') || '',
    remindHours: num(settingsModel.get('ship_remind_hours'), 24), lateDays: num(settingsModel.get('ship_late_days'), 3),
    testMode: settingsModel.get('test_mode') === '1', testEmail: settingsModel.get('test_email') || '',
  };
}
export function saveShipConfig(input: Partial<Record<'user' | 'password' | 'smtpHost' | 'smtpPort' | 'imapHost' | 'imapPort' | 'fromName' | 'managerEmail' | 'remindHours' | 'lateDays', string | number>>): void {
  const set = (k: string, v: unknown) => { if (v !== undefined && String(v).trim() !== '') settingsModel.set(k, String(v).trim()); };
  set('ship_mail_user', input.user); set('ship_mail_password', input.password); set('ship_smtp_host', input.smtpHost); set('ship_smtp_port', input.smtpPort);
  set('ship_imap_host', input.imapHost); set('ship_imap_port', input.imapPort); set('ship_from_name', input.fromName);
  if (input.managerEmail !== undefined) settingsModel.set('ship_manager_email', String(input.managerEmail).trim());
  set('ship_remind_hours', input.remindHours); set('ship_late_days', input.lateDays);
}
export const mailboxPassword = (): string => settingsModel.get('ship_mail_password') || '';
export const mailboxReady = (): boolean => !!shipConfig().user && !!mailboxPassword();

const transport = () => {
  const c = shipConfig();
  return nodemailer.createTransport({ host: c.smtpHost, port: c.smtpPort, secure: c.smtpPort === 465, auth: { user: c.user, pass: mailboxPassword() } });
};

export interface OutMail { to: string[]; cc?: string[]; subject: string; body: string; inReplyTo?: string | null; kind: string; requestId?: string | null; forwarderId?: number | null; quoteId?: number | null; userId?: number | null; html?: string; attachments?: { filename: string; path: string }[] }

// writes the message first (pending), then sends it; the row says what happened. Test mode: everything goes to the test address only.
export async function sendShipMail(m: OutMail): Promise<{ id: number; ok: boolean; error?: string }> {
  const c = shipConfig();
  const key = `<ship-${Date.now()}-${Math.random().toString(36).slice(2, 10)}@tece.com.tr>`;
  const to = [...new Set(m.to.map((a) => a.trim().toLowerCase()).filter(Boolean))];
  const id = Number(db.prepare("INSERT INTO ship_messages (direction, kind, request_id, forwarder_id, quote_id, address, subject, body, msg_key, in_reply_to, status, user_id) VALUES ('out', ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?)")
    .run(m.kind, m.requestId ?? null, m.forwarderId ?? null, m.quoteId ?? null, to.join(', '), m.subject, m.body, key, m.inReplyTo ?? null, m.userId ?? null).lastInsertRowid);
  if (!mailboxReady()) { db.prepare("UPDATE ship_messages SET status = 'failed', error = ? WHERE id = ?").run('The shipping mailbox is not set up yet (Admin > Shipping).', id); return { id, ok: false, error: 'The shipping mailbox is not set up yet.' }; }
  const test = c.testMode;
  if (test && !c.testEmail) { db.prepare("UPDATE ship_messages SET status = 'failed', error = ? WHERE id = ?").run('Test mode is on but there is no test address.', id); return { id, ok: false, error: 'Test mode is on but there is no test address.' }; }
  try {
    db.prepare('UPDATE ship_messages SET attempts = attempts + 1 WHERE id = ?').run(id);
    await transport().sendMail({
      from: `"${c.fromName}" <${c.user}>`, replyTo: c.user, messageId: key, inReplyTo: m.inReplyTo || undefined, references: m.inReplyTo || undefined,
      to: test ? c.testEmail : to.join(', '), cc: test ? undefined : m.cc?.join(', '),
      subject: test ? `[TEST] ${m.subject}` : m.subject, text: test ? `TEST - this e-mail would have gone to: ${to.join(', ')}\n\n----------\n\n${m.body}` : m.body,
      attachments: m.attachments,
    });
    db.prepare("UPDATE ship_messages SET status = 'sent', sent_at = datetime('now'), error = ? WHERE id = ?").run(test ? `TEST: sent to ${c.testEmail} only` : null, id);
    return { id, ok: true };
  } catch (err) {
    const msg = String((err as Error).message ?? err).slice(0, 300);
    db.prepare("UPDATE ship_messages SET status = 'failed', error = ? WHERE id = ?").run(msg, id);
    return { id, ok: false, error: msg };
  }
}

// a failed e-mail sent again by a person (never automatically)
export async function resendShipMail(id: number): Promise<{ ok: boolean; error?: string }> {
  const r = db.prepare("SELECT * FROM ship_messages WHERE id = ? AND direction = 'out' AND status IN ('failed', 'pending')").get(id) as { address: string; subject: string; body: string; kind: string; request_id: string | null; forwarder_id: number | null; quote_id: number | null; in_reply_to: string | null; user_id: number | null } | undefined;
  if (!r) return { ok: false, error: 'Not found' };
  db.prepare("UPDATE ship_messages SET status = 'dismissed' WHERE id = ?").run(id);
  const res = await sendShipMail({ to: r.address.split(/[,;\s]+/).filter(Boolean), subject: r.subject, body: r.body, inReplyTo: r.in_reply_to, kind: r.kind, requestId: r.request_id, forwarderId: r.forwarder_id, quoteId: r.quote_id, userId: r.user_id });
  return { ok: res.ok, error: res.error };
}

export const logEvent = (requestId: string | null, quoteId: number | null, kind: string, text: string, userId: number | null, imported = false): void => {
  db.prepare('INSERT INTO ship_events (request_id, quote_id, kind, text, user_id, imported) VALUES (?, ?, ?, ?, ?, ?)').run(requestId, quoteId, kind, text.slice(0, 500), userId, imported ? 1 : 0);
};
