import path from 'path';
import { Router } from 'express';
import multer from 'multer';
import ExcelJS from 'exceljs';
import { requireAuth, requireAdmin, type AuthedRequest } from '../middleware/auth';
import { COUNTRY_NAMES } from '../data/countries';
import { countryKey, countryModel } from '../models/countryModel';
import { userModel } from '../models/userModel';
import { importCountryList } from '../services/countryAssignment';

const router = Router();
router.use(requireAuth);

const listUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } });

// What the review page shows next to Person: who normally looks after the
// visitor's country. Any signed-in staff member may read it.
router.get('/lookup', (req, res) => {
  const found = countryModel.findByCountry(String(req.query.country ?? ''));
  res.json({ responsible: found?.responsible ?? null, assistant: found?.assistant ?? null });
});

// The signed-in person's own countries: where they are the responsible
// person, and where they are the assistant copied on emails.
router.get('/mine', (req: AuthedRequest, res) => {
  const name = req.user?.display_name;
  const all = name ? countryModel.listAll() : [];
  res.json({
    responsible: all.filter((r) => r.responsible === name).map((r) => r.country),
    assistant: all.filter((r) => r.assistant === name).map((r) => r.country),
  });
});

router.use(requireAdmin);

// Staff can be the responsible person; an assistant (email only, no login) or
// a staff member can be the assistant of a country.
function staffNames(): Set<string> {
  return new Set(userModel.listActive().map((u) => u.display_name).filter((n): n is string => !!n));
}
function assistantNames(): Set<string> {
  const names = staffNames();
  for (const u of userModel.listAssistants()) if (u.display_name) names.add(u.display_name);
  return names;
}

function tableRows() {
  const staff = staffNames();
  const assistants = assistantNames();
  const stored = new Map(countryModel.listAll().map((r) => [r.key, r]));
  const all = new Map<string, string>();
  for (const name of COUNTRY_NAMES) all.set(countryKey(name), name);
  for (const r of stored.values()) if (!all.has(r.key)) all.set(r.key, r.country);

  return [...all.entries()]
    .map(([key, name]) => {
      const r = stored.get(key);
      return {
        country: name,
        continent: r?.continent ?? null,
        responsible: r?.responsible ?? null,
        assistant: r?.assistant ?? null,
        // A name with no matching active user can't be CC'd.
        responsibleKnown: !r?.responsible || staff.has(r.responsible),
        assistantKnown: !r?.assistant || assistants.has(r.assistant),
      };
    })
    .sort((a, b) => a.country.localeCompare(b.country));
}

router.get('/', (_req, res) => {
  res.json(tableRows());
});

// Change one country's responsible person and/or assistant.
router.put('/', (req, res) => {
  const country = String(req.body?.country ?? '').trim();
  if (!country) return res.status(400).json({ error: 'country is required' });

  const allowed = { responsible: staffNames(), assistant: assistantNames() };
  const current = countryModel.findByCountry(country);
  const read = (field: 'responsible' | 'assistant'): string | null | { error: string } => {
    if (req.body?.[field] === undefined) return current?.[field] ?? null;
    const value = String(req.body[field] ?? '').trim();
    if (!value) return null;
    // Keep an unchanged imported name; anything new must be a real person.
    if (value !== current?.[field] && !allowed[field].has(value)) {
      return { error: field === 'responsible' ? `"${value}" is not an active staff member.` : `"${value}" is not a staff member or assistant.` };
    }
    return value;
  };
  const responsible = read('responsible');
  const assistant = read('assistant');
  if (responsible && typeof responsible === 'object') return res.status(400).json({ error: responsible.error });
  if (assistant && typeof assistant === 'object') return res.status(400).json({ error: assistant.error });

  countryModel.upsert({ country: current?.country ?? country, responsible, assistant });
  res.json(tableRows().find((r) => countryKey(r.country) === countryKey(country)));
});

// Upload the country list workbook (.xlsx, same columns as the original).
router.post('/import', listUpload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'file is required' });
  if (path.extname(req.file.originalname).toLowerCase() !== '.xlsx') {
    return res.status(400).json({ error: 'Please upload an Excel .xlsx file.' });
  }
  try {
    res.json(await importCountryList(req.file.buffer));
  } catch (err) {
    res.status(422).json({ error: (err as Error).message || 'Could not read that workbook.' });
  }
});

// Current list in the same layout, so it can be edited in Excel and uploaded again.
router.get('/export', async (_req, res) => {
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Sheet1');
  ws.columns = [
    { header: 'Country', key: 'country', width: 30 },
    { header: 'Continent', key: 'continent', width: 16 },
    { header: 'Sales Manager', key: 'responsible', width: 22 },
    { header: 'Sales Manager Email', key: 'responsibleEmail', width: 30 },
    { header: 'Assist', key: 'assistant', width: 22 },
    { header: 'Assist Email', key: 'assistantEmail', width: 30 },
  ];
  ws.getRow(1).font = { bold: true };
  const emails = new Map(userModel.listAll().filter((u) => u.display_name).map((u) => [u.display_name!, u.email ?? '']));
  for (const r of tableRows()) {
    ws.addRow({
      country: r.country,
      continent: r.continent ?? '',
      responsible: r.responsible ?? '',
      responsibleEmail: r.responsible ? emails.get(r.responsible) ?? '' : '',
      assistant: r.assistant ?? '',
      assistantEmail: r.assistant ? emails.get(r.assistant) ?? '' : '',
    });
  }
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', 'attachment; filename="country_list.xlsx"');
  await wb.xlsx.write(res);
  res.end();
});

export default router;
