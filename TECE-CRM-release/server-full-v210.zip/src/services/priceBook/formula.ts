// Minimal Excel formula evaluator - just what the tece price workbook uses
// (arithmetic, comparisons, IF / AND / SUM, cross-sheet refs). Evaluating the
// workbook's own formulas, instead of re-implementing its pricing rules, is
// what keeps the app's numbers identical to the Excel when a percentage
// changes. Anything outside this subset throws rather than guessing.

export class FormulaError extends Error {
  constructor(public code: string) {
    super(code);
  }
}

export type Value = number | string | boolean | null;

export interface Resolver {
  cell(sheet: string, addr: string): Value;
  range(sheet: string, from: string, to: string): Value[];
}

type Token =
  | { t: 'num'; v: number }
  | { t: 'str'; v: string }
  | { t: 'bool'; v: boolean }
  | { t: 'err'; v: string }
  | { t: 'ref'; sheet: string | null; from: string; to: string | null }
  | { t: 'fn'; v: string }
  | { t: 'op'; v: string };

const ERROR_LITERAL = /^#(REF!|DIV\/0!|N\/A|VALUE!|NAME\?|NUM!|NULL!)(\$?[A-Z]{1,3}\$?\d+)?/;
const REF_BODY = String.raw`\$?[A-Z]{1,3}\$?\d+(?::\$?[A-Z]{1,3}\$?\d+)?`;
const QUALIFIED_REF = new RegExp(String.raw`^('(?:[^']|'')+'|[A-Za-z_][A-Za-z0-9_.]*)!(${REF_BODY})`);
const PLAIN_REF = new RegExp(`^(${REF_BODY})(?![A-Za-z0-9_(])`);

function tokenize(src: string): Token[] {
  const out: Token[] = [];
  let i = 0;
  while (i < src.length) {
    const rest = src.slice(i);
    const ws = /^\s+/.exec(rest);
    if (ws) { i += ws[0].length; continue; }

    if (rest[0] === '"') {
      let j = 1;
      let s = '';
      while (j < rest.length) {
        if (rest[j] === '"') {
          if (rest[j + 1] === '"') { s += '"'; j += 2; continue; }
          break;
        }
        s += rest[j++];
      }
      out.push({ t: 'str', v: s });
      i += j + 1;
      continue;
    }

    const err = ERROR_LITERAL.exec(rest);
    if (err) { out.push({ t: 'err', v: '#' + err[1] }); i += err[0].length; continue; }

    const num = /^(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?/.exec(rest);
    if (num) { out.push({ t: 'num', v: parseFloat(num[0]) }); i += num[0].length; continue; }

    const q = QUALIFIED_REF.exec(rest);
    if (q) {
      let sheet = q[1];
      if (sheet.startsWith("'")) sheet = sheet.slice(1, -1).replace(/''/g, "'");
      const [from, to] = q[2].replace(/\$/g, '').split(':');
      out.push({ t: 'ref', sheet, from, to: to ?? null });
      i += q[0].length;
      continue;
    }

    const fn = /^([A-Za-z_][A-Za-z0-9_.]*)\(/.exec(rest);
    if (fn) { out.push({ t: 'fn', v: fn[1].toUpperCase() }); i += fn[0].length; continue; }

    const bool = /^(TRUE|FALSE)\b/i.exec(rest);
    if (bool) { out.push({ t: 'bool', v: bool[1].toUpperCase() === 'TRUE' }); i += bool[0].length; continue; }

    const ref = PLAIN_REF.exec(rest);
    if (ref) {
      const [from, to] = ref[1].replace(/\$/g, '').split(':');
      out.push({ t: 'ref', sheet: null, from, to: to ?? null });
      i += ref[0].length;
      continue;
    }

    const op = /^(<=|>=|<>|[=<>+\-*/^&%(),])/.exec(rest);
    if (op) { out.push({ t: 'op', v: op[1] }); i += op[1].length; continue; }

    throw new FormulaError('#NAME?');
  }
  return out;
}

function num(v: Value): number {
  if (v === null) return 0;
  if (typeof v === 'number') return v;
  if (typeof v === 'boolean') return v ? 1 : 0;
  const n = Number(v);
  if (v.trim() === '' || Number.isNaN(n)) throw new FormulaError('#VALUE!');
  return n;
}

function compare(a: Value, b: Value, op: string): boolean {
  const norm = (v: Value): number | string | boolean => (v === null ? 0 : v);
  let x = norm(a);
  let y = norm(b);
  if (typeof x === 'string' && typeof y === 'string') { x = x.toLowerCase(); y = y.toLowerCase(); }
  // Excel orders numbers < text < booleans when types differ.
  const rank = (v: number | string | boolean) => (typeof v === 'number' ? 0 : typeof v === 'string' ? 1 : 2);
  let c: number;
  if (rank(x) !== rank(y)) c = rank(x) - rank(y);
  else c = x < y ? -1 : x > y ? 1 : 0;
  switch (op) {
    case '=': return c === 0;
    case '<>': return c !== 0;
    case '<': return c < 0;
    case '>': return c > 0;
    case '<=': return c <= 0;
    default: return c >= 0;
  }
}

class Parser {
  private pos = 0;
  constructor(private tokens: Token[], private sheet: string, private r: Resolver) {}

  parse(): Value {
    const v = this.expr();
    if (this.pos < this.tokens.length) throw new FormulaError('#NAME?');
    return v;
  }

  private peek(): Token | undefined { return this.tokens[this.pos]; }
  private isOp(v: string): boolean { const t = this.peek(); return !!t && t.t === 'op' && t.v === v; }
  private eat(v: string): void { if (!this.isOp(v)) throw new FormulaError('#NAME?'); this.pos++; }

  // comparison < concat < additive < multiplicative < power < unary < postfix %
  private expr(): Value {
    let left = this.concat();
    for (;;) {
      const t = this.peek();
      if (t && t.t === 'op' && ['=', '<>', '<', '>', '<=', '>='].includes(t.v)) {
        this.pos++;
        left = compare(left, this.concat(), t.v);
      } else return left;
    }
  }

  private concat(): Value {
    let left = this.additive();
    while (this.isOp('&')) {
      this.pos++;
      const right = this.additive();
      left = String(left ?? '') + String(right ?? '');
    }
    return left;
  }

  private additive(): Value {
    let left = this.term();
    for (;;) {
      if (this.isOp('+')) { this.pos++; left = num(left) + num(this.term()); }
      else if (this.isOp('-')) { this.pos++; left = num(left) - num(this.term()); }
      else return left;
    }
  }

  private term(): Value {
    let left = this.power();
    for (;;) {
      if (this.isOp('*')) { this.pos++; left = num(left) * num(this.power()); }
      else if (this.isOp('/')) {
        this.pos++;
        const d = num(this.power());
        if (d === 0) throw new FormulaError('#DIV/0!');
        left = num(left) / d;
      } else return left;
    }
  }

  private power(): Value {
    let left = this.unary();
    while (this.isOp('^')) { this.pos++; left = Math.pow(num(left), num(this.unary())); }
    return left;
  }

  private unary(): Value {
    if (this.isOp('-')) { this.pos++; return -num(this.unary()); }
    if (this.isOp('+')) { this.pos++; return num(this.unary()); }
    let v = this.primary();
    while (this.isOp('%')) { this.pos++; v = num(v) / 100; }
    return v;
  }

  private primary(): Value {
    const t = this.peek();
    if (!t) throw new FormulaError('#NAME?');
    this.pos++;
    switch (t.t) {
      case 'num': return t.v;
      case 'str': return t.v;
      case 'bool': return t.v;
      case 'err': throw new FormulaError(t.v);
      case 'ref': {
        // A range where one value is expected resolves to its first cell
        // (what Excel does for a merged cell range).
        return this.r.cell(t.sheet ?? this.sheet, t.from);
      }
      case 'op': {
        if (t.v !== '(') throw new FormulaError('#NAME?');
        const v = this.expr();
        this.eat(')');
        return v;
      }
      case 'fn': return this.call(t.v);
    }
  }

  // Skips over an argument's tokens without evaluating it (for IF's unused branch).
  private skipArg(): void {
    let depth = 0;
    while (this.pos < this.tokens.length) {
      const t = this.tokens[this.pos];
      if (t.t === 'op' && t.v === '(') depth++;
      else if (t.t === 'fn') depth++; // the '(' is folded into the fn token
      else if (t.t === 'op' && t.v === ')') { if (depth === 0) return; depth--; }
      else if (t.t === 'op' && t.v === ',' && depth === 0) return;
      this.pos++;
    }
  }

  private args(): Value[] {
    // Evaluates args; ranges expand to their cells.
    const out: Value[] = [];
    if (this.isOp(')')) { this.pos++; return out; }
    for (;;) {
      const t = this.peek();
      if (t && t.t === 'ref' && t.to) {
        const next = this.tokens[this.pos + 1];
        if (next && next.t === 'op' && (next.v === ',' || next.v === ')')) {
          this.pos++;
          out.push(...this.r.range(t.sheet ?? this.sheet, t.from, t.to));
        } else out.push(this.expr());
      } else out.push(this.expr());
      if (this.isOp(',')) { this.pos++; continue; }
      this.eat(')');
      return out;
    }
  }

  private call(name: string): Value {
    if (name === 'IF') {
      const cond = this.expr();
      this.eat(',');
      const truthy = !!num(cond);
      let result: Value = false;
      if (truthy) {
        result = this.expr();
        if (this.isOp(',')) { this.pos++; this.skipArg(); }
      } else {
        this.skipArg();
        if (this.isOp(',')) { this.pos++; result = this.expr(); }
      }
      this.eat(')');
      return result;
    }
    const args = this.args();
    switch (name) {
      case 'AND': return args.every((a) => !!num(a));
      case 'OR': return args.some((a) => !!num(a));
      case 'SUM': return args.reduce<number>((s, a) => s + (typeof a === 'number' ? a : 0), 0);
      case 'MAX': return Math.max(...args.filter((a): a is number => typeof a === 'number'));
      case 'MIN': return Math.min(...args.filter((a): a is number => typeof a === 'number'));
      case 'ABS': return Math.abs(num(args[0]));
      case 'ROUND': {
        const f = Math.pow(10, num(args[1] ?? 0));
        return Math.round(num(args[0]) * f) / f;
      }
      default: throw new FormulaError('#NAME?');
    }
  }
}

export function evaluateFormula(formula: string, sheet: string, resolver: Resolver): Value {
  return new Parser(tokenize(formula), sheet, resolver).parse();
}
