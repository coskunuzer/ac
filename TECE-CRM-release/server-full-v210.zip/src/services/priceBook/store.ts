import fs from 'fs';
import path from 'path';
import { paths } from '../../config/env';
import { priceListModel, type PriceListRow } from '../../models/pricingModels';
import { PriceBook } from './index';

fs.mkdirSync(paths.priceListsDir, { recursive: true });

export interface PriceListSummary {
  tabs: { sheet: string; title: string; rows: number; columns: number }[];
  formulasChecked: number;
  hasMoq: boolean;
}

export class PriceListRejected extends Error {}

const cache = new Map<number, PriceBook>();

export function filePath(row: PriceListRow): string {
  return path.join(paths.priceListsDir, row.stored_name);
}

// The live price list of a market ('export' by default).
export function activePriceBook(market = 'export'): { row: PriceListRow; book: PriceBook } | null {
  const row = priceListModel.findActive(market);
  if (!row) return null;
  const cached = cache.get(row.id);
  if (cached) return { row, book: cached };
  const book = PriceBook.fromFile(filePath(row));
  cache.set(row.id, book);
  return { row, book };
}

export function installPriceList(buffer: Buffer, originalName: string, uploadedBy: number, market = 'export'): PriceListRow {
  const ext = path.extname(originalName).toLowerCase();
  if (ext !== '.xls') throw new PriceListRejected('Please upload the price template as an Excel 97-2003 (.xls) file - its layout and formatting are read directly from that format.');

  let book: PriceBook;
  try {
    book = PriceBook.fromBuffer(buffer);
  } catch (err) {
    throw new PriceListRejected((err as Error).message || 'This file could not be read as a price workbook.');
  }

  // Prices go straight to customers, so a workbook whose formulas this app
  // can't reproduce exactly is rejected rather than quoted from.
  const check = book.selfCheck();
  if (check.mismatches > 0) {
    throw new PriceListRejected(
      `${check.mismatches} price formula(s) (for example ${check.examples.join(', ')}) don't match the values Excel saved. ` +
        'Open the file in Excel, press Ctrl+Alt+F9 to recalculate, save it, and upload it again.'
    );
  }

  const storedName = `${Date.now()}-${Math.round(Math.random() * 1e9)}${ext}`;
  fs.writeFileSync(path.join(paths.priceListsDir, storedName), buffer);

  const summary: PriceListSummary = {
    tabs: book.catalog.map((s) => ({ sheet: s.sheet, title: s.title, rows: s.rows.length, columns: s.columns.length })),
    formulasChecked: check.formulas,
    hasMoq: book.hasMoq,
  };
  const row = priceListModel.create({ originalName, storedName, uploadedBy, summary, market });
  cache.set(row.id, book);
  return row;
}
