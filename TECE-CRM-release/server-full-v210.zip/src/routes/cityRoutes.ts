import { Router } from 'express';
import multer from 'multer';
import { importCityList } from '../services/cityListImport';
import { requireAuth, requireAdmin, type AuthedRequest } from '../middleware/auth';
import { PROVINCES } from '../data/turkeyPlaces';
import { cityModel } from '../models/cityModel';
import { userModel } from '../models/userModel';

const router = Router();
router.use(requireAuth);

// The cities of Turkey, for the drop-down on a domestic customer.
router.get('/names', (_req, res) => {
  res.json(PROVINCES);
});

// Who normally looks after a city (shown next to Person on the customer page).
router.get('/lookup', (req, res) => {
  const found = cityModel.findByCity(String(req.query.city ?? ''));
  res.json({ responsible: found?.responsible ?? null, assistant: found?.assistant ?? null });
});

// The signed-in person's own cities.
router.get('/mine', (req: AuthedRequest, res) => {
  const name = req.user?.display_name;
  const all = name ? cityModel.listAll() : [];
  res.json({
    responsible: all.filter((r) => r.responsible === name).map((r) => r.city),
    assistant: all.filter((r) => r.assistant === name).map((r) => r.city),
  });
});

router.use(requireAdmin);

function people(): { staff: string[]; assistants: string[] } {
  const staff = userModel.listActive().map((u) => u.display_name).filter((n): n is string => !!n);
  const assistants = [...staff, ...userModel.listAssistants().map((u) => u.display_name).filter((n): n is string => !!n)];
  return { staff, assistants };
}

// Every province (and any other place that has customers) with who looks after it and how many customers it has.
router.get('/', (_req, res) => {
  res.json({ rows: cityModel.withCustomerCounts(), ...people() });
});

// The city list as Excel (who looks after each city): check it first (dryRun=1), then apply. `choices` = {"Bursa": "Ahmet Abay"} for a city listed twice.
const cityUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } });
router.post('/import', cityUpload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Choose the Excel file first.' });
  let choices: Record<string, string> = {};
  try { choices = JSON.parse(String(req.body?.choices || '{}')); } catch { choices = {}; }
  try {
    res.json(importCityList({ buffer: req.file.buffer, dryRun: req.body?.dryRun === '1' || req.body?.dryRun === 'true', choices }));
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

router.put('/', (req, res) => {
  const rows = Array.isArray(req.body?.rows) ? (req.body.rows as { city?: unknown; responsible?: unknown; assistant?: unknown }[]) : [];
  const { staff, assistants } = people();
  const clean: { city: string; responsible: string | null; assistant: string | null }[] = [];
  for (const r of rows) {
    const city = String(r.city ?? '').trim();
    if (!city) continue;
    const responsible = typeof r.responsible === 'string' && r.responsible.trim() ? r.responsible.trim() : null;
    const assistant = typeof r.assistant === 'string' && r.assistant.trim() ? r.assistant.trim() : null;
    if (responsible && !staff.includes(responsible)) return res.status(400).json({ error: `"${responsible}" is not a person with an account.` });
    if (assistant && !assistants.includes(assistant)) return res.status(400).json({ error: `"${assistant}" is not a known person.` });
    clean.push({ city, responsible, assistant });
  }
  cityModel.upsertMany(clean);
  res.json({ saved: clean.length });
});

export default router;
