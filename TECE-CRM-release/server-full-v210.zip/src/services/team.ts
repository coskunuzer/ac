import { db } from '../db/connection';
import { activityModel, type Activity, type ActivityType } from '../models/activityModel';
import { cardModel } from '../models/cardModel';
import { evaluationModel, type Evaluation } from '../models/evaluationModel';
import { visibilityFor, type Viewer } from './visibility';
import { settingsModel } from '../models/settingsModel';
import { userModel, type PublicUser } from '../models/userModel';
import { sendThankYouEmail } from './thankYouEmail';
import { secondsBetween } from './usage';

// Who reports to whom, and what each person did on a day. A manager sees their own team (everybody below
// them, down the chain); an admin sees everybody. The same report is e-mailed to each manager in the evening.

const TZ = 'Europe/Istanbul';

export interface Person {
  id: number;
  name: string;
  managerId: number | null;
  managerName: string | null;
  photo: string | null;
  depth: number; // 0 = the person asking, 1 = reports to them, 2 = reports to those ...
  // the team: export, domestic (an admin works in both)
  market: 'export' | 'domestic' | 'both';
}

const login = (u: PublicUser) => !u.is_assistant && !u.assists_id && !!u.is_active;

// Everybody below this person, nearest first (a loop in the chain cannot hang it).
export function descendants(rootId: number, users: PublicUser[] = userModel.listAll()): { user: PublicUser; depth: number }[] {
  const out: { user: PublicUser; depth: number }[] = [];
  const seen = new Set<number>([rootId]);
  let level = [rootId];
  for (let depth = 1; level.length && depth < 12; depth += 1) {
    const next: number[] = [];
    for (const u of users) {
      if (u.manager_id !== null && level.includes(u.manager_id) && !seen.has(u.id) && login(u)) {
        seen.add(u.id);
        out.push({ user: u, depth });
        next.push(u.id);
      }
    }
    level = next;
  }
  return out;
}

// Would giving this person that manager make a loop?
export function wouldLoop(userId: number, managerId: number, users: PublicUser[] = userModel.listAll()): boolean {
  if (userId === managerId) return true;
  return descendants(userId, users).some((d) => d.user.id === managerId);
}

// An admin, and anybody an admin let watch the whole team (read-only), sees everybody.
// only an admin sees everybody; everyone else sees themselves and the people under them
const seesEveryone = (v: { role: string; can_oversee?: number }) => v.role === 'admin';

export function peopleFor(viewer: { id: number; role: string; can_oversee?: number }): Person[] {
  const users = userModel.listAll();
  const byId = new Map(users.map((u) => [u.id, u]));
  const toPerson = (u: PublicUser, depth: number): Person => ({
    id: u.id,
    name: u.display_name || u.username,
    managerId: u.manager_id,
    managerName: u.manager_id ? (byId.get(u.manager_id)?.display_name ?? null) : null,
    photo: u.photo_path,
    depth,
    market: u.role === 'admin' ? 'both' : u.market,
  });
  if (seesEveryone(viewer)) {
    // everybody, the people at the top first and their teams under them
    const all = users.filter(login);
    const roots = all.filter((u) => u.manager_id === null || !byId.get(u.manager_id!) || !login(byId.get(u.manager_id!)!));
    const out: Person[] = [];
    const seen = new Set<number>();
    const walk = (u: PublicUser, depth: number) => {
      if (seen.has(u.id)) return;
      seen.add(u.id);
      out.push(toPerson(u, depth));
      for (const c of all.filter((x) => x.manager_id === u.id)) walk(c, depth + 1);
    };
    roots.forEach((r) => walk(r, 0));
    all.forEach((u) => walk(u, 0)); // anyone caught in a loop still shows
    return out;
  }
  const me = byId.get(viewer.id);
  if (!me) return [];
  return [toPerson(me, 0), ...descendants(viewer.id, users).map((d) => toPerson(d.user, d.depth))];
}

// Start and end (UTC "YYYY-MM-DD HH:MM:SS") of a calendar day in the company's time zone.
export function dayRange(date: string): { from: string; to: string } {
  const offsetMinutes = (instant: Date) => {
    const parts = new Intl.DateTimeFormat('en-US', { timeZone: TZ, hour12: false, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' }).formatToParts(instant);
    const get = (t: string) => parseInt(parts.find((p) => p.type === t)!.value, 10);
    const asUtc = Date.UTC(get('year'), get('month') - 1, get('day'), get('hour') % 24, get('minute'), get('second'));
    return Math.round((asUtc - instant.getTime()) / 60000);
  };
  const startOfDay = (d: string) => {
    const guess = new Date(`${d}T00:00:00Z`);
    return new Date(guess.getTime() - offsetMinutes(guess) * 60000);
  };
  const next = new Date(`${date}T00:00:00Z`);
  next.setUTCDate(next.getUTCDate() + 1);
  const fmt = (d: Date) => d.toISOString().slice(0, 19).replace('T', ' ');
  return { from: fmt(startOfDay(date)), to: fmt(startOfDay(next.toISOString().slice(0, 10))) };
}

export function todayLocal(): string {
  return new Intl.DateTimeFormat('en-CA', { timeZone: TZ }).format(new Date());
}

export interface PersonDay {
  person: Person;
  activities: (Activity & { canOpen: boolean })[];
  counts: Partial<Record<ActivityType, number>>;
  // seconds spent in the app on that day
  appSeconds: number;
}

export function reportForDay(viewer: Viewer & { can_oversee?: number }, date: string): PersonDay[] {
  const people = peopleFor(viewer);
  const { from, to } = dayRange(date);
  const acts = activityModel.between(people.map((p) => p.id), from, to);
  // a person watching others can read what was done, but only open the customers they may see themselves
  const canSee = visibilityFor(viewer);
  const openable = new Map<number, boolean>();
  const canOpen = (cardId: number | null) => {
    if (!cardId) return false;
    if (!openable.has(cardId)) {
      const c = cardModel.findById(cardId);
      openable.set(cardId, !!c && canSee(c));
    }
    return openable.get(cardId)!;
  };
  const time = secondsBetween(people.map((p) => p.id), date, date);
  return people.map((person) => {
    const mine = acts.filter((a) => a.userId === person.id).map((a) => ({ ...a, canOpen: canOpen(a.cardId) }));
    const counts: PersonDay['counts'] = {};
    for (const a of mine) counts[a.type] = (counts[a.type] ?? 0) + 1;
    return { person, activities: mine, counts, appSeconds: time.get(person.id) ?? 0 };
  });
}

// ---- how much each person did over a period (the overview page, and the admin's evaluation) ----

// What a person is aiming for (set by an admin): contacts per working day, visits and offers per week.
export interface Goals {
  contactsDay: number;
  visitsWeek: number;
  offersWeek: number;
}
export function getGoals(): Goals {
  const num = (key: string, dflt: number) => {
    const v = parseInt(settingsModel.get(key) ?? '', 10);
    return Number.isFinite(v) && v >= 0 ? v : dflt;
  };
  return { contactsDay: num('goal_contacts_day', 8), visitsWeek: num('goal_visits_week', 3), offersWeek: num('goal_offers_week', 5) };
}
export function setGoals(g: Partial<Goals>): Goals {
  const clamp = (n: unknown, cur: number) => (Number.isFinite(Number(n)) ? Math.max(0, Math.min(500, Math.round(Number(n)))) : cur);
  const cur = getGoals();
  const next = { contactsDay: clamp(g.contactsDay, cur.contactsDay), visitsWeek: clamp(g.visitsWeek, cur.visitsWeek), offersWeek: clamp(g.offersWeek, cur.offersWeek) };
  settingsModel.set('goal_contacts_day', String(next.contactsDay));
  settingsModel.set('goal_visits_week', String(next.visitsWeek));
  settingsModel.set('goal_offers_week', String(next.offersWeek));
  return next;
}

export interface PersonSummary {
  person: Person;
  total: number; // everything recorded
  contacts: number; // notes, calls, visits, meetings: the times they were in touch
  customersTouched: number; // different customers they worked with
  newCustomers: number;
  sent: number; // e-mails, offers and documents sent
  offers: number;
  byType: Partial<Record<ActivityType, number>>;
  lastAt: string | null;
  customersOwned: number; // customers that have their name as the responsible person
  evaluation: Evaluation | null; // the admin's latest note (admins only)
  appSeconds: number; // time spent in the app over the period
}

export function summaryFor(viewer: Viewer & { can_oversee?: number }, date: string, days: number): { from: string; to: string; rows: PersonSummary[] } {
  const people = peopleFor(viewer);
  const first = new Date(`${date}T12:00:00Z`);
  first.setUTCDate(first.getUTCDate() - (days - 1));
  const from = dayRange(first.toISOString().slice(0, 10)).from;
  const to = dayRange(date).to;
  const acts = activityModel.between(people.map((p) => p.id), from, to);
  const owned = new Map<string, number>(
    (db.prepare("SELECT person, COUNT(*) AS n FROM cards WHERE person IS NOT NULL AND person != '' GROUP BY person").all() as { person: string; n: number }[]).map((r) => [r.person, r.n])
  );
  const evaluations = viewer.role === 'admin' ? evaluationModel.latestForAll() : new Map<number, Evaluation>();
  const firstDay = first.toISOString().slice(0, 10);
  const time = secondsBetween(people.map((p) => p.id), firstDay, date);
  const rows = people.map((person) => {
    const mine = acts.filter((a) => a.userId === person.id);
    const byType: PersonSummary['byType'] = {};
    for (const a of mine) byType[a.type] = (byType[a.type] ?? 0) + 1;
    const n = (...t: ActivityType[]) => t.reduce((s, k) => s + (byType[k] ?? 0), 0);
    return {
      person,
      total: mine.length,
      contacts: n('note', 'call', 'visit', 'meeting', 'sample'),
      customersTouched: new Set(mine.map((a) => a.cardId).filter((id): id is number => !!id)).size,
      newCustomers: n('scan', 'created'),
      sent: n('thank_you', 'offer', 'documents', 'email', 'bulgaria'),
      offers: n('offer'),
      byType,
      lastAt: mine.length ? mine[mine.length - 1].at : null,
      customersOwned: owned.get(person.name) ?? 0,
      evaluation: evaluations.get(person.id) ?? null,
      appSeconds: time.get(person.id) ?? 0,
    };
  });
  return { from, to, rows };
}

// ---- the evening e-mail to each manager -----------------------------------------------------

export const TYPE_LABEL: Record<ActivityType, string> = {
  note: 'Note', call: 'Call', visit: 'Visit', meeting: 'Meeting', sample: 'Sample sent', scan: 'New customer (scanned)', created: 'New customer',
  thank_you: 'Thank-you sent', offer: 'Offer sent', documents: 'Documents sent', bulgaria: 'Passed to Bulgaria', stage: 'Stage changed', file: 'File added', merged: 'Merged duplicate', rated: 'Rated a customer', email: 'Personal e-mail sent', ai: 'AI did something',
};

const timeOf = (utc: string) =>
  new Intl.DateTimeFormat('en-GB', { timeZone: TZ, hour: '2-digit', minute: '2-digit' }).format(new Date(`${utc.replace(' ', 'T')}Z`));

const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

function digestFor(manager: PublicUser, date: string): { subject: string; text: string; html: string } | null {
  const team = descendants(manager.id);
  if (!team.length) return null;
  const { from, to } = dayRange(date);
  const acts = activityModel.between(team.map((t) => t.user.id), from, to);
  const pretty = new Date(`${date}T12:00:00Z`).toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' });
  const text: string[] = [`Team report - ${pretty}`, ''];
  const html: string[] = [`<h2 style="font-family:Arial,sans-serif;color:#17243e;margin:0 0 4px">Team report</h2><p style="font-family:Arial,sans-serif;color:#5e6676;margin:0 0 16px">${esc(pretty)}</p>`];
  for (const { user, depth } of team) {
    const mine = acts.filter((a) => a.userId === user.id);
    const name = user.display_name || user.username;
    const indent = '   '.repeat(Math.max(0, depth - 1));
    text.push(`${indent}${name.toUpperCase()}${depth > 1 ? `  (reports to ${team.find((t) => t.user.id === user.manager_id)?.user.display_name ?? 'a team member'})` : ''}`);
    html.push(`<p style="font-family:Arial,sans-serif;margin:14px 0 4px;margin-left:${(depth - 1) * 18}px"><b style="color:#17243e">${esc(name)}</b></p>`);
    if (!mine.length) {
      text.push(`${indent}   No activity recorded.`, '');
      html.push(`<p style="font-family:Arial,sans-serif;color:#5e6676;margin:0 0 6px;margin-left:${(depth - 1) * 18 + 12}px">No activity recorded.</p>`);
      continue;
    }
    html.push(`<ul style="font-family:Arial,sans-serif;font-size:14px;color:#252525;margin:0 0 6px;padding-left:${(depth - 1) * 18 + 30}px">`);
    for (const a of mine) {
      const who = [a.company, a.contact, a.country].filter(Boolean).join(', ');
      const line = `${timeOf(a.at)}  ${TYPE_LABEL[a.type] ?? a.type}${who ? ` - ${who}` : ''}${a.text ? `: ${a.text.replace(/\s+/g, ' ').slice(0, 260)}` : ''}${a.photos.length ? `  [${a.photos.length} photo${a.photos.length === 1 ? '' : 's'}]` : ''}`;
      text.push(`${indent}   ${line}`);
      html.push(`<li style="margin-bottom:3px">${esc(line)}</li>`);
    }
    text.push('');
    html.push('</ul>');
  }
  return { subject: `TECE team report - ${pretty}`, text: text.join('\n'), html: html.join('') };
}

// Sends each manager the report of the people below them. In test mode everything goes to the test address.
export async function sendDigests(date: string, only?: number[]): Promise<{ sent: string[]; skipped: string[] }> {
  const sent: string[] = [];
  const skipped: string[] = [];
  const testTo = settingsModel.get('test_mode') === '1' ? settingsModel.get('test_email') || null : null;
  for (const manager of userModel.listAll().filter((u) => login(u) && (!only || only.includes(u.id)))) {
    const d = digestFor(manager, date);
    if (!d) continue;
    if (!manager.email) {
      skipped.push(`${manager.display_name ?? manager.username} (no e-mail address)`);
      continue;
    }
    await sendThankYouEmail({
      to: manager.email,
      subject: d.subject,
      body: d.text,
      signature: { text: 'TECE customer system', html: `<div style="font-family:Arial,sans-serif;color:#5e6676;font-size:12px">${d.html}<p style="margin-top:16px">TECE customer system</p></div>` },
      testTo,
    });
    sent.push(manager.display_name ?? manager.username);
  }
  return { sent, skipped };
}

// Once a day, after the set hour, when an admin has switched it on.
export function startDigestScheduler(): void {
  const tick = async () => {
    try {
      if (settingsModel.get('team_digest') !== '1') return;
      const hour = parseInt(settingsModel.get('team_digest_hour') ?? '18', 10);
      const now = new Intl.DateTimeFormat('en-GB', { timeZone: TZ, hour: '2-digit', hour12: false }).format(new Date());
      const today = todayLocal();
      if (parseInt(now, 10) < hour || settingsModel.get('team_digest_last') === today) return;
      settingsModel.set('team_digest_last', today);
      const r = await sendDigests(today);
      console.log(`Team report for ${today}: sent to ${r.sent.join(', ') || 'nobody'}${r.skipped.length ? `; skipped ${r.skipped.join(', ')}` : ''}`);
    } catch (err) {
      console.error('Team report e-mail failed:', err);
    }
  };
  setInterval(tick, 10 * 60 * 1000).unref();
}
